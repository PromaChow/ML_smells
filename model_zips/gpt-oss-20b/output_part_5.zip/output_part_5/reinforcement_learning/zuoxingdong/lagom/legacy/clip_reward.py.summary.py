import numpy as np
import gym
from gym.wrappers import RewardWrapper
import pytest

class ClipReward(RewardWrapper):
    def __init__(self, env, min_r: float, max_r: float):
        super().__init__(env)
        self.min_r = min_r
        self.max_r = max_r

    def reward(self, reward: float) -> float:
        return float(np.clip(reward, self.min_r, self.max_r))

@pytest.mark.parametrize("env_id", ["CartPole-v1", "Pendulum-v0", "MountainCar-v0"])
def test_clip_reward(env_id: str):
    env_orig = gym.make(env_id)
    env_clipped = ClipReward(gym.make(env_id), min_r=-0.0005, max_r=0.0002)

    env_orig.reset()
    env_clipped.reset()

    for _ in range(10):
        action = env_orig.action_space.sample()

        # Step the original environment
        _, reward_orig, _, _ = env_orig.step(action)

        # Step the wrapped environment with the same action
        _, reward_clipped, _, _ = env_clipped.step(action)

        # Assert clipped reward magnitude is not greater than original
        assert abs(reward_clipped) <= abs(reward_orig)

        # If original reward was outside the clipping bounds, the clipped reward must match a bound
        if reward_orig < -0.0005 or reward_orig > 0.0002:
            expected = -0.0005 if reward_orig < -0.0005 else 0.0002
            assert reward_clipped == expected
        else:
            # If the original reward was inside the bounds, clipping should leave it unchanged
            assert reward_clipped == reward_orig
```