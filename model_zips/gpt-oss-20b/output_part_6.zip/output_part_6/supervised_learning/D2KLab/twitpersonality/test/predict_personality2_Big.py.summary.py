import re
import sys
import numpy as np
import joblib
from pathlib import Path
from sklearn.feature_extraction.text import CountVectorizer
import datasetUtils
import embeddings

# Configuration
DATASET_PATH = Path("dataset.vec")
TWEET_THRESHOLD = 3
MODEL_DIR = Path("Models/MPbig")
OUTPUT_CSV = Path("personality_predictions2_big.csv")

# Load embeddings
fasttext_dict = datasetUtils.parseFastText(DATASET_PATH)

# Load models
traits = {"O": "O", "C": "C", "E": "E", "A": "A", "N": "N"}
models = {t: joblib.load(MODEL_DIR / f"{t}.sav") for t in traits}

# Gather usernames
usernames = []
user_input = input("Enter a username (prefixed with @) or a filename: ").strip()
if user_input.startswith("@"):
    usernames.append(user_input[1:].strip())
else:
    try:
        with open(user_input, "r", encoding="utf-8") as f:
            for line in f:
                name = line.strip()
                if name:
                    usernames.append(name)
    except FileNotFoundError:
        print(f"File {user_input} not found.")
        sys.exit(1)
    if not usernames:
        print("No usernames provided.")
        sys.exit(1)

# Prepare results
results = []

for username in usernames:
    tweet_file = Path("Data") / f"{username}_tweets.txt"
    if not tweet_file.exists():
        continue

    raw_tweets = tweet_file.read_text(encoding="utf-8").splitlines()
    cleaned_tweets = []

    for tweet in raw_tweets:
        tweet = tweet.strip()
        if tweet.startswith("RT"):
            continue
        # Remove URLs
        tweet = re.sub(r"http\S+", "", tweet)
        tweet = re.sub(r"\b[\w.-]+\.[a-z]{2,}\b", "", tweet)
        # Remove mentions
        tweet = re.sub(r"@\w+", "", tweet)
        if tweet:
            cleaned_tweets.append(tweet)

    if len(cleaned_tweets) < TWEET_THRESHOLD:
        continue

    # Transform to embeddings
    try:
        embeddings_matrix = embeddings.transformTextForTesting(cleaned_tweets, fasttext_dict)
    except Exception as e:
        print(f"Error transforming tweets for {username}: {e}")
        continue

    if embeddings_matrix.size == 0:
        continue

    mean_embedding = np.mean(embeddings_matrix, axis=0).reshape(1, -1)

    trait_scores = {}
    for trait, model in models.items():
        try:
            pred = model.predict(mean_embedding)[0]
            score = float(pred)
        except Exception as e:
            print(f"Prediction error for {username} on trait {trait}: {e}")
            score = np.nan
        trait_scores[trait] = round(score, 5)

    # Jungian type
    jungian = (
        ("E" if trait_scores["E"] > 3 else "I") +
        ("N" if trait_scores["O"] > 3 else "S") +
        ("F" if trait_scores["A"] > 3 else "T") +
        ("J" if trait_scores["C"] > 3 else "P")
    )

    results.append([username,
                    trait_scores["O"],
                    trait_scores["C"],
                    trait_scores["E"],
                    trait_scores["A"],
                    trait_scores["N"],
                    jungian])

# Write CSV
header = ["username", "O", "C", "E", "A", "N", "Jungian"]
with open(OUTPUT_CSV, "w", encoding="utf-8") as f:
    f.write(",".join(header) + "\n")
    for row in results:
        f.write(",".join(str(v) for v in row) + "\n")