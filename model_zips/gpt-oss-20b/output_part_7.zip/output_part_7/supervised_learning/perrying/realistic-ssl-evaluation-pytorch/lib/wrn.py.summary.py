import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.init import kaiming_normal_, xavier_normal_

def conv3x3(in_channels, out_channels, stride=1, bias=False):
    return nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=stride,
                     padding=1, bias=bias)

class BatchNorm2d(nn.BatchNorm2d):
    def __init__(self, num_features, eps=1e-5, momentum=0.1, affine=True, track_running_stats=True):
        super().__init__(num_features, eps, momentum, affine, track_running_stats)
        self.update_batch_stats = True

    def forward(self, input):
        if self.update_batch_stats:
            return super().forward(input)
        else:
            return F.batch_norm(
                input, self.running_mean, self.running_var,
                self.weight, self.bias,
                training=False, momentum=0, eps=self.eps
            )

def relu():
    return nn.LeakyReLU(negative_slope=0.1, inplace=True)

class residual(nn.Module):
    def __init__(self, in_channels, out_channels, stride=1, activate_before_residual=False):
        super().__init__()
        self.activate_before_residual = activate_before_residual
        self.stride = stride
        self.in_channels = in_channels
        self.out_channels = out_channels

        if self.activate_before_residual:
            self.bn1 = BatchNorm2d(in_channels)
        else:
            self.bn1 = BatchNorm2d(in_channels)

        self.conv1 = conv3x3(in_channels, out_channels, stride=stride, bias=False)
        self.bn2 = BatchNorm2d(out_channels)
        self.conv2 = conv3x3(out_channels, out_channels, stride=1, bias=False)

        if in_channels != out_channels or stride != 1:
            self.shortcut = nn.Sequential(
                conv3x3(in_channels, out_channels, stride=stride, bias=False),
                BatchNorm2d(out_channels)
            )
        else:
            self.shortcut = nn.Identity()

    def forward(self, x):
        if self.activate_before_residual:
            out = self.bn1(x)
            out = relu()(out)
            residual = out
        else:
            residual = x

        residual = self.conv1(residual)
        residual = self.bn2(residual)
        residual = relu()(residual)
        residual = self.conv2(residual)

        shortcut = self.shortcut(x)
        out = residual + shortcut
        return out

class WRN(nn.Module):
    def __init__(self, num_classes=10, width=1, transform_fn=None):
        super().__init__()
        self.transform_fn = transform_fn
        f = [16, 16 * width, 32 * width, 64 * width]

        self.conv1 = conv3x3(3, f[0], stride=1, bias=False)

        self.unit1 = nn.Sequential(
            residual(f[0], f[1], stride=1, activate_before_residual=True),
            residual(f[1], f[1], stride=1),
            residual(f[1], f[1], stride=1),
            residual(f[1], f[1], stride=1)
        )

        self.unit2 = nn.Sequential(
            residual(f[1], f[2], stride=2, activate_before_residual=False),
            residual(f[2], f[2], stride=1),
            residual(f[2], f[2], stride=1),
            residual(f[2], f[2], stride=1)
        )

        self.unit3 = nn.Sequential(
            residual(f[2], f[3], stride=2, activate_before_residual=False),
            residual(f[3], f[3], stride=1),
            residual(f[3], f[3], stride=1),
            residual(f[3], f[3], stride=1)
        )

        self.bn_final = BatchNorm2d(f[3])
        self.relu = relu()
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.linear = nn.Linear(f[3], num_classes)

        self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            elif isinstance(m, BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                xavier_normal_(m.weight)
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)

    def update_batch_stats(self, flag: bool):
        for m in self.modules():
            if isinstance(m, BatchNorm2d):
                m.update_batch_stats = flag

    def forward(self, x, return_feature=False):
        if self.transform_fn is not None and self.training:
            x = self.transform_fn(x)

        x = self.conv1(x)
        x = self.unit1(x)
        x = self.unit2(x)
        x = self.unit3(x)
        x = self.bn_final(x)
        x = self.relu(x)
        x = self.avgpool(x)
        f = torch.flatten(x, 1)
        c = self.linear(f)
        if return_feature:
            return c, f
        return c
