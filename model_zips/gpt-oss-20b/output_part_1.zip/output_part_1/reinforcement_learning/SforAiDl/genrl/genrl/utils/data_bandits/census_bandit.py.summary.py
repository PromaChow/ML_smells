import os
import pandas as pd
import torch
import urllib.request
import shutil


def download_data(url: str, dest_path: str) -> None:
    """Download a file from the given URL to the destination path."""
    os.makedirs(os.path.dirname(dest_path), exist_ok=True)
    with urllib.request.urlopen(url) as response, open(dest_path, 'wb') as out_file:
        shutil.copyfileobj(response, out_file)


def fetch_data_with_header(path: str) -> pd.DataFrame:
    """Read a CSV file with header into a DataFrame."""
    return pd.read_csv(path)


class CensusDataBandit:
    DEFAULT_URL = "https://archive.ics.uci.edu/ml/machine-learning-databases/00469/USCensus1990.csv"

    def __init__(
        self,
        data_path: str,
        download: bool = False,
        url: str | None = None,
        device: str = "cpu",
    ) -> None:
        self.device = torch.device(device)
        self._data_path = data_path

        if download:
            download_url = url if url is not None else self.DEFAULT_URL
            download_data(download_url, self._data_path)
            self._df = fetch_data_with_header(self._data_path)
        else:
            self._df = fetch_data_with_header(self._data_path)

        # Problem definition
        self.n_actions: int = len(self._df["dOccup"].unique())
        self.context_dim: int = self._df.shape[1] - 1
        self._len: int = len(self._df)

        # Internal state
        self._index: int = 0
        self._df = self._df.sample(frac=1, random_state=42).reset_index(drop=True)

    def reset(self) -> torch.Tensor:
        """Shuffle the dataset and reset the index."""
        self._df = self._df.sample(frac=1, random_state=42).reset_index(drop=True)
        self._index = 0
        return self._get_context()

    def _get_context(self) -> torch.Tensor:
        """Return the context tensor for the current example."""
        row = self._df.iloc[self._index]
        context = row.drop("dOccup").values.astype(float)
        return torch.tensor(context, device=self.device, dtype=torch.float32)

    def _compute_reward(self, action: int) -> tuple[int, int]:
        """Compute the reward for a given action."""
        true_action = self._df.iloc[self._index]["dOccup"] + 1  # adjust by +1
        reward = 1 if action == true_action else 0
        return reward, 1

    def step(self, action: int) -> tuple[torch.Tensor, int, int]:
        """Perform a step: return next context, reward, and binary indicator."""
        reward, binary = self._compute_reward(action)
        self._index += 1
        if self._index >= self._len:
            done = True
            next_context = torch.empty(0, device=self.device)
        else:
            done = False
            next_context = self._get_context()
        return next_context, reward, binary

    def __len__(self) -> int:
        return self._len
