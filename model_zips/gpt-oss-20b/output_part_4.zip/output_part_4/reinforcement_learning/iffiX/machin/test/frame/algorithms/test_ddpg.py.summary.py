import os
import math
import random
from collections import deque
from dataclasses import dataclass
from typing import Callable, Iterable, List, Tuple, Optional

import gymnasium as gym
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import pytest

# Decorator for Linux-only tests
def linux_only(func):
    def wrapper(*args, **kwargs):
        if os.name != "posix":
            pytest.skip("Linux only test")
        return func(*args, **kwargs)
    return wrapper

# Simple replay buffer
class ReplayBuffer:
    def __init__(self, capacity: int):
        self.capacity = capacity
        self.buffer = deque(maxlen=capacity)

    def push(self, state, action, reward, next_state, done):
        self.buffer.append((state, action, reward, next_state, done))

    def sample(self, batch_size: int):
        batch = random.sample(self.buffer, batch_size)
        state, action, reward, next_state, done = map(np.stack, zip(*batch))
        return state, action, reward, next_state, done

    def __len__(self):
        return len(self.buffer)

# Neural network modules
class ActorContinuous(nn.Module):
    def __init__(self, state_dim: int, action_dim: int, max_action: float):
        super().__init__()
        self.max_action = max_action
        self.net = nn.Sequential(
            nn.Linear(state_dim, 400),
            nn.ReLU(),
            nn.Linear(400, 300),
            nn.ReLU(),
            nn.Linear(300, action_dim),
            nn.Tanh()
        )

    def forward(self, state: torch.Tensor):
        return self.net(state) * self.max_action

class ActorDiscrete(nn.Module):
    def __init__(self, state_dim: int, action_dim: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, 400),
            nn.ReLU(),
            nn.Linear(400, 300),
            nn.ReLU(),
            nn.Linear(300, action_dim)
        )

    def forward(self, state: torch.Tensor):
        return self.net(state)

class Critic(nn.Module):
    def __init__(self, state_dim: int, action_dim: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim + action_dim, 400),
            nn.ReLU(),
            nn.Linear(400, 300),
            nn.ReLU(),
            nn.Linear(300, 1)
        )

    def forward(self, state: torch.Tensor, action: torch.Tensor):
        x = torch.cat([state, action], dim=1)
        return self.net(x)

# Ornstein-Uhlenbeck noise
class OUNoise:
    def __init__(self, action_dim: int, mu: float = 0.0, theta: float = 0.15, sigma: float = 0.2):
        self.action_dim = action_dim
        self.mu = mu
        self.theta = theta
        self.sigma = sigma
        self.state = np.ones(self.action_dim) * self.mu

    def reset(self):
        self.state = np.ones(self.action_dim) * self.mu

    def sample(self):
        dx = self.theta * (self.mu - self.state) + self.sigma * np.random.randn(self.action_dim)
        self.state += dx
        return self.state

# DDPG implementation
class DDPG:
    def __init__(
        self,
        env: gym.Env,
        actor_cls: Callable[..., nn.Module],
        critic_cls: Callable[..., nn.Module],
        actor_params: dict,
        critic_params: dict,
        lr: float = 1e-3,
        gamma: float = 0.99,
        tau: float = 0.005,
        buffer_capacity: int = 100000,
        batch_size: int = 64,
        lr_scheduler: Optional[optim.lr_scheduler._LRScheduler] = None,
        visualization: bool = False,
    ):
        self.env = env
        self.state_dim = env.observation_space.shape[0]
        if isinstance(env.action_space, gym.spaces.Box):
            self.action_dim = env.action_space.shape[0]
            self.max_action = float(env.action_space.high[0])
        else:
            self.action_dim = env.action_space.n
            self.max_action = 1.0

        self.actor = actor_cls(self.state_dim, self.action_dim, self.max_action, **actor_params)
        self.actor_target = actor_cls(self.state_dim, self.action_dim, self.max_action, **actor_params)
        self.actor_target.load_state_dict(self.actor.state_dict())
        self.actor_opt = optim.Adam(self.actor.parameters(), lr=lr)

        self.critic = critic_cls(self.state_dim, self.action_dim, **critic_params)
        self.critic_target = critic_cls(self.state_dim, self.action_dim, **critic_params)
        self.critic_target.load_state_dict(self.critic.state_dict())
        self.critic_opt = optim.Adam(self.critic.parameters(), lr=lr)

        self.gamma = gamma
        self.tau = tau
        self.buffer = ReplayBuffer(buffer_capacity)
        self.batch_size = batch_size
        self.lr_scheduler = lr_scheduler
        self.visualization = visualization
        self.ou_noise = OUNoise(self.action_dim)

    def act(self, state: np.ndarray) -> np.ndarray:
        state = torch.FloatTensor(state).unsqueeze(0)
        with torch.no_grad():
            action = self.actor(state).cpu().numpy()[0]
        if self.visualization:
            print("Act:", action)
        return action

    def act_with_noise(
        self,
        state: np.ndarray,
        noise_type: str = "normal",
        noise_std: float = 0.1,
        clip: bool = True
    ) -> np.ndarray:
        action = self.act(state)
        if noise_type == "uniform":
            noise = np.random.uniform(-noise_std, noise_std, size=action.shape)
        elif noise_type == "normal":
            noise = np.random.normal(0, noise_std, size=action.shape)
        elif noise_type == "clipped_normal":
            noise = np.clip(np.random.normal(0, noise_std, size=action.shape), -noise_std, noise_std)
        elif noise_type == "ou":
            noise = self.ou_noise.sample()
        else:
            raise ValueError(f"Unknown noise type: {noise_type}")
        noisy_action = action + noise
        if clip:
            noisy_action = np.clip(noisy_action, -self.max_action, self.max_action)
        return noisy_action

    def act_discrete(self, state: np.ndarray) -> int:
        state = torch.FloatTensor(state).unsqueeze(0)
        with torch.no_grad():
            logits = self.actor(state)
            probs = torch.softmax(logits, dim=-1)
            action = torch.argmax(probs, dim=-1).cpu().numpy()[0]
        return int(action)

    def act_discrete_with_noise(self, state: np.ndarray, temperature: float = 1.0) -> int:
        state = torch.FloatTensor(state).unsqueeze(0)
        with torch.no_grad():
            logits = self.actor(state)
            probs = torch.softmax(logits / temperature, dim=-1)
            action = torch.multinomial(probs, num_samples=1).cpu().numpy()[0]
        return int(action)

    def store_episode(self, state, action, reward, next_state, done):
        self.buffer.push(state, action, reward, next_state, done)

    def update(self, policy_update: bool = True, value_update: bool = True, target_update: bool = True):
        if len(self.buffer) < self.batch_size:
            return
        state, action, reward, next_state, done = self.buffer.sample(self.batch_size)
        state = torch.FloatTensor(state)
        action = torch.FloatTensor(action)
        reward = torch.FloatTensor(reward).unsqueeze(1)
        next_state = torch.FloatTensor(next_state)
        done = torch.FloatTensor(np.float32(done)).unsqueeze(1)

        with torch.no_grad():
            next_action = self.actor_target(next_state)
            target_q = self.critic_target(next_state, next_action)
            target_q = reward + (1 - done) * self.gamma * target_q

        current_q = self.critic(state, action)
        critic_loss = nn.functional.mse_loss(current_q, target_q)

        if value_update:
            self.critic_opt.zero_grad()
            critic_loss.backward()
            self.critic_opt.step()

        if policy_update:
            actor_loss = -self.critic(state, self.actor(state)).mean()
            self.actor_opt.zero_grad()
            actor_loss.backward()
            self.actor_opt.step()

        if target_update:
            for target_param, param in zip(self.critic_target.parameters(), self.critic.parameters()):
                target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)
            for target_param, param in zip(self.actor_target.parameters(), self.actor.parameters()):
                target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)

        if self.lr_scheduler is not None:
            self.lr_scheduler.step()

    def save(self, path: str):
        torch.save({
            "actor": self.actor.state_dict(),
            "critic": self.critic.state_dict(),
            "actor_target": self.actor_target.state_dict(),
            "critic_target": self.critic_target.state_dict()
        }, path)

    def load(self, path: str, map_location: str = "cpu"):
        data = torch.load(path, map_location=map_location)
        self.actor.load_state_dict(data["actor"])
        self.critic.load_state_dict(data["critic"])
        self.actor_target.load_state_dict(data["actor_target"])
        self.critic_target.load_state_dict(data["critic_target"])

# Helper to create DDPG instances
def make_ddpg_instances(env_name: str = "Pendulum-v0"):
    env = gym.make(env_name)
    instances = {}
    instances["ddpg"] = DDPG(
        env,
        ActorContinuous,
        Critic,
        actor_params={},
        critic_params={},
        lr=1e-3
    )
    instances["ddpg_vis"] = DDPG(
        env,
        ActorContinuous,
        Critic,
        actor_params={},
        critic_params={},
        lr=1e-3,
        visualization=True
    )
    instances["ddpg_disc"] = DDPG(
        env,
        ActorDiscrete,
        Critic,
        actor_params={},
        critic_params={},
        lr=1e-3
    )
    lr_sched = optim.lr_scheduler.LambdaLR(optim.Adam([torch.zeros(1)], lr=1e-3),
                                            lr_lambda=lambda step: 0.5 + 0.5 * math.cos(math.pi * step / 200000))
    instances["ddpg_lr"] = DDPG(
        env,
        ActorContinuous,
        Critic,
        actor_params={},
        critic_params={},
        lr=1e-3,
        lr_scheduler=lr_sched
    )
    instances["ddpg_train"] = DDPG(
        env,
        ActorContinuous,
        Critic,
        actor_params={},
        critic_params={},
        lr=1e-3,
        gamma=0.98,
        tau=0.01
    )
    return instances

# ----------------- Tests -----------------

@pytest.fixture(scope="module")
def ddpg_instances():
    return make_ddpg_instances()

def test_contiguous_act(ddpg_instances):
    ddpg = ddpg_instances["ddpg"]
    state = np.zeros(ddpg.state_dim)
    action = ddpg.act(state)
    assert action.shape == (ddpg.action_dim,)
    for noise in ["uniform", "normal", "clipped_normal", "ou"]:
        noisy = ddpg.act_with_noise(state, noise_type=noise, noise_std=0.5)
        assert noisy.shape == action.shape

def test_discrete_act(ddpg_instances):
    ddpg = ddpg_instances["ddpg_disc"]
    state = np.zeros(ddpg.state_dim)
    action = ddpg.act_discrete(state)
    assert isinstance(action, int)
    action = ddpg.act_discrete_with_noise(state, temperature=1.0)
    assert isinstance(action, int)

def test__criticize(ddpg_instances):
    ddpg = ddpg_instances["ddpg"]
    state = np.zeros(ddpg.state_dim)
    action = np.zeros(ddpg.action_dim)
    state_t = torch.FloatTensor(state).unsqueeze(0)
    action_t = torch.FloatTensor(action).unsqueeze(0)
    q_val = ddpg.critic(state_t, action_t)
    assert q_val.shape == (1, 1)

def test_store_episode(ddpg_instances):
    ddpg = ddpg_instances["ddpg"]
    state = np.zeros(ddpg.state_dim)
    action = np.zeros(ddpg.action_dim)
    reward = 1.0
    next_state = np.ones(ddpg.state_dim)
    done = False
    ddpg.store_episode(state, action, reward, next_state, done)
    assert len(ddpg.buffer) == 1

def test_update(ddpg_instances):
    ddpg = ddpg_instances["ddpg"]
    state = np.zeros(ddpg.state_dim)
    action = np.zeros(ddpg.action_dim)
    reward = 1.0
    next_state = np.ones(ddpg.state_dim)
    done = False
    for _ in range(3):
        ddpg.store_episode(state, action, reward, next_state, done)
    ddpg.update(policy_update=True, value_update=True, target_update=True)
    # No assertion on loss values; just ensure no exception

def test_save_load(ddpg_instances, tmp_path):
    ddpg = ddpg_instances["ddpg"]
    path = tmp_path / "ddpg.pt"
    ddpg.save(str(path))
    ddpg2 = DDPG(
        ddpg.env,
        ActorContinuous,
        Critic,
        actor_params={},
        critic_params={}
    )
    ddpg2.load(str(path))
    # Compare state dicts
    for key in ddpg.actor.state_dict():
        assert torch.allclose(ddpg.actor.state_dict()[key], ddpg2.actor.state_dict()[key])

def test_lr_scheduler(ddpg_instances):
    ddpg = ddpg_instances["ddpg_lr"]
    lr_sched = ddpg.lr_scheduler
    initial_lr = lr_sched.get_last_lr()[0]
    ddpg.update()
    new_lr = lr_sched.get_last_lr()[0]
    assert new_lr != initial_lr

def test_config_init(ddpg_instances):
    config = {
        "env": "Pendulum-v0",
        "actor_cls": ActorContinuous,
        "critic_cls": Critic,
        "actor_params": {},
        "critic_params": {},
        "lr": 1e-3,
        "gamma": 0.99,
        "tau": 0.005,
    }
    env = gym.make(config["env"])
    ddpg = DDPG(
        env,
        config["actor_cls"],
        config["critic_cls"],
        config["actor_params"],
        config["critic_params"],
        lr=config["lr"],
        gamma=config["gamma"],
        tau=config["tau"]
    )
    assert ddpg.gamma == config["gamma"]

def test_full_train(ddpg_instances):
    ddpg = ddpg_instances["ddpg_train"]
    env = ddpg.env
    solved_reward = -400
    solved_repeat = 5
    episode_rewards = []
    noise_interval = 10
    max_episodes = 200
    env.seed(0)
    for episode in range(max_episodes):
        state, _ = env.reset(seed=0)
        done = False
        ep_reward = 0.0
        steps = 0
        while not done:
            if steps % noise_interval == 0:
                action = ddpg.act_with_noise(state, noise_std=0.2)
            else:
                action = ddpg.act(state)
            next_state, reward, done, _, _ = env.step(action)
            ddpg.store_episode(state, action, reward, next_state, done)
            state = next_state
            ep_reward += reward
            steps += 1
        episode_rewards.append(ep_reward)
        if episode % 10 == 0 and episode > 0:
            ddpg.update(policy_update=True, value_update=True, target_update=True)
    smoothed = np.mean(episode_rewards[-solved_repeat:])
    assert smoothed >= solved_reward, f"Training did not converge, final reward: {smoothed}"

def test_lr_scheduler_invalid():
    with pytest.raises(TypeError):
        # missing positional arguments
        DDPG(
            env=gym.make("Pendulum-v0"),
            actor_cls=ActorContinuous,
            critic_cls=Critic,
            actor_params={},
            critic_params={},
            lr=1e-3,
            lr_scheduler=None
        )  # This should not raise, but test is placeholder for API misuse

# Note: test_full_train is marked as linux_only but executed here for demonstration
test_full_train = linux_only(test_full_train)