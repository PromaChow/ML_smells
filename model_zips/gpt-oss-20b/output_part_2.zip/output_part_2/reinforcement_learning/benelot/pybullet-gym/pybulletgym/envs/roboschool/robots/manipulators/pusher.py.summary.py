import numpy as np
from dm_control import mjcf
from dm_control.rl import robot

class Pusher(robot.MJCFBasedRobot):
    def __init__(self, random_state=None):
        # Configuration parameters
        self.min_target_placement_radius = 0.15
        self.max_target_placement_radius = 0.25
        self.min_object_to_target_distance = 0.05
        self.max_object_to_target_distance = 0.10
        self.zero_offset = np.array([0.5, 0.5, 0.0])

        self.random_state = random_state or np.random.RandomState()

        # Load MJCF model
        xml_path = "pusher.xml"
        super().__init__(xml_path=xml_path, action_dim=7, observation_dim=55)

        # Define joint names (ordered)
        self.joint_names = [
            "shoulder_joint", "elbow_joint", "wrist_joint",
            "finger_joint_1", "finger_joint_2",
            "finger_joint_3", "finger_joint_4"
        ]

        # Identify parts
        self.fingertip = self.robot.find("fingertip")
        self.target = self.robot.find("target")
        self.object = self.robot.find("object")

        # Identify sliders
        self.goal_slidex = self.robot.find("goal_slidex")
        self.goal_slidey = self.robot.find("goal_slidey")
        self.obj_slidex = self.robot.find("obj_slidex")
        self.obj_slidey = self.robot.find("obj_slidey")

    def robot_specific_reset(self):
        # Target position initialization
        vec = self.random_state.uniform(-1, 1, size=2)
        norm = np.linalg.norm(vec)
        if norm == 0:
            vec = np.array([1.0, 0.0])
        else:
            vec /= norm
        radius = self.random_state.uniform(
            self.min_target_placement_radius, self.max_target_placement_radius)
        target_pos_2d = vec * radius
        target_pos_3d = np.array([target_pos_2d[0], target_pos_2d[1], 0.0]) + self.zero_offset

        # Object position initialization
        dir_vec = self.random_state.uniform(-1, 1, size=2)
        norm_dir = np.linalg.norm(dir_vec)
        if norm_dir == 0:
            dir_vec = np.array([0.0, 1.0])
        else:
            dir_vec /= norm_dir
        dist = self.random_state.uniform(
            self.min_object_to_target_distance, self.max_object_to_target_distance)
        object_pos_2d = target_pos_2d + dir_vec * dist
        object_pos_3d = np.array([object_pos_2d[0], object_pos_2d[1], 0.0]) + self.zero_offset

        # Set slider values
        self.goal_slidex.set("value", target_pos_3d[0])
        self.goal_slidey.set("value", target_pos_3d[1])
        self.obj_slidex.set("value", object_pos_3d[0])
        self.obj_slidey.set("value", object_pos_3d[1])

        # Joint randomization
        for joint_name in self.joint_names:
            joint = self.robot.find(joint_name)
            joint.set("qpos", self.random_state.uniform(-np.pi, np.pi))

        # Ensure the physics is consistent
        self.physics.forward()

    def apply_action(self, action):
        clipped = np.clip(action, -1.0, 1.0) * 0.05
        for i, joint_name in enumerate(self.joint_names):
            joint = self.robot.find(joint_name)
            joint.set("ctrl", clipped[i])
        self.physics.step()

    def calc_state(self):
        joint_pos = []
        joint_vel = []
        for joint_name in self.joint_names:
            joint = self.robot.find(joint_name)
            joint_pos.append(joint.get("qpos"))
            joint_vel.append(joint.get("qvel"))

        joint_pos = np.array(joint_pos)
        joint_vel = np.array(joint_vel)

        to_target_vec = self.target.get("xpos") - self.object.get("xpos")

        fingertip_xyz = self.fingertip.get("xpos")
        object_xyz = self.object.get("xpos")
        target_xyz = self.target.get("xpos")

        observation = np.concatenate([
            joint_pos, joint_vel,
            to_target_vec,
            fingertip_xyz, object_xyz, target_xyz
        ])
        return observation.reshape(-1)[:55]
