import os
import tensorflow as tf

CPU_COUNT = os.cpu_count() or 1

def _flip_left_right(img: tf.Tensor) -> tf.Tensor:
    """Stateless left-right flip."""
    return tf.image.stateless_random_flip_left_right(img, seed=[1, 2])

def _pad_and_crop(img: tf.Tensor, orig_height: int, orig_width: int) -> tf.Tensor:
    """Add reflection padding of 4 pixels and randomly crop back to original size."""
    padded = tf.pad(img, paddings=[[4, 4], [4, 4], [0, 0]], mode="REFLECT")
    return tf.image.stateless_random_crop(
        padded,
        size=[orig_height, orig_width, 3],
        seed=[1, 2]
    )

def weak_augment(batch: tf.Tensor) -> tf.Tensor:
    """
    Apply weak augmentation: flip, pad, and random crop.
    `batch` shape: [batch, height, width, 3]
    """
    height, width = tf.shape(batch)[1], tf.shape(batch)[2]

    def _augment(img):
        img = _flip_left_right(img)
        img = _pad_and_crop(img, height, width)
        return img

    return tf.map_fn(
        _augment,
        batch,
        dtype=tf.float32,
        parallel_iterations=CPU_COUNT,
        back_prop=False
    )

def medium_augment(batch: tf.Tensor) -> tf.Tensor:
    """
    Apply medium augmentation: flip, brightness, contrast, hue, pad, and crop.
    """
    height, width = tf.shape(batch)[1], tf.shape(batch)[2]

    def _augment(img):
        img = _flip_left_right(img)
        img = tf.image.stateless_random_brightness(img, max_delta=0.35, seed=[1, 2])
        img = tf.image.stateless_random_contrast(img, lower=0.0, upper=0.4, seed=[1, 2])
        img = tf.image.stateless_random_hue(img, max_delta=0.2, seed=[1, 2])
        img = _pad_and_crop(img, height, width)
        return img

    return tf.map_fn(
        _augment,
        batch,
        dtype=tf.float32,
        parallel_iterations=CPU_COUNT,
        back_prop=False
    )

def strong_augment(batch: tf.Tensor, rand_jpeg_quality: bool = False) -> tf.Tensor:
    """
    Apply strong augmentation: flip, brightness, contrast, hue, saturation,
    optional JPEG quality compression, pad, and crop.
    """
    height, width = tf.shape(batch)[1], tf.shape(batch)[2]

    def _augment(img):
        img = _flip_left_right(img)
        img = tf.image.stateless_random_brightness(img, max_delta=0.75, seed=[1, 2])
        img = tf.image.stateless_random_contrast(img, lower=0.0, upper=0.8, seed=[1, 2])
        img = tf.image.stateless_random_hue(img, max_delta=0.3, seed=[1, 2])
        img = tf.image.stateless_random_saturation(img, lower=0.5, upper=2.0, seed=[1, 2])

        if rand_jpeg_quality:
            # Random JPEG quality between 50 and 100
            quality = tf.cast(
                tf.random.stateless_uniform(
                    shape=[1],
                    seed=[1, 2],
                    minval=50,
                    maxval=101,
                    dtype=tf.int32
                ),
                tf.int32
            )[0]
            # Encode and decode to apply quality
            img = tf.image.encode_jpeg(
                tf.cast(img, tf.uint8),
                quality=quality
            )
            img = tf.image.decode_jpeg(img, channels=3)
            img = tf.cast(img, tf.float32) / 255.0

        img = _pad_and_crop(img, height, width)
        return img

    return tf.map_fn(
        _augment,
        batch,
        dtype=tf.float32,
        parallel_iterations=CPU_COUNT,
        back_prop=False
    )

def random_rotate(batch: tf.Tensor) -> tuple[tf.Tensor, tf.Tensor]:
    """
    Rotate each image in the batch by a random multiple of 90 degrees.
    Returns rotated images and a tensor of rotation labels (0, 1, 2, 3).
    """
    batch_size = tf.shape(batch)[0]
    quarter = tf.math.floordiv(batch_size, 4)

    slices = [
        batch[0:quarter],
        batch[quarter:2 * quarter],
        batch[2 * quarter:3 * quarter],
        batch[3 * quarter:4 * quarter]
    ]

    rotated = [
        slices[0],                                            # 0°
        tf.image.rot90(slices[1], k=1),                       # 90°
        tf.image.rot90(slices[2], k=2),                       # 180°
        tf.image.rot90(slices[3], k=3)                        # 270°
    ]

    rotated_batch = tf.concat(rotated, axis=0)

    labels = tf.concat([
        tf.zeros([quarter], dtype=tf.int32),
        tf.ones([quarter], dtype=tf.int32),
        tf.fill([quarter], 2),
        tf.fill([quarter], 3)
    ], axis=0)

    return rotated_batch, labels
