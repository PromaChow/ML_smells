import gym
import numpy as np


class MockEnvironment(gym.Env):
    """
    A mock reinforcement learning environment with random dynamics and fixed seed.
    """

    def __init__(self, observ_shape, action_shape, min_duration, max_duration):
        super().__init__()
        self.observ_shape = observ_shape
        self.action_shape = action_shape
        self.min_duration = min_duration
        self.max_duration = max_duration

        # Random number generator with fixed seed for reproducibility
        self.rng = np.random.RandomState(0)

        # Track episode statistics
        self.steps = []
        self.durations = []

        # Define observation and action spaces
        low_obs = np.zeros(self.observ_shape, dtype=np.float32)
        high_obs = np.ones(self.observ_shape, dtype=np.float32)
        self.observation_space = gym.spaces.Box(low=low_obs, high=high_obs, dtype=np.float32)

        low_act = np.zeros(self.action_shape, dtype=np.float32)
        high_act = np.ones(self.action_shape, dtype=np.float32)
        self.action_space = gym.spaces.Box(low=low_act, high=high_act, dtype=np.float32)

    def reset(self):
        """
        Reset the environment to start a new episode.
        """
        # Determine episode duration (inclusive)
        duration = self.rng.randint(self.min_duration, self.max_duration + 1)
        self.durations.append(duration)
        self.steps.append(0)

        # Return initial observation
        return self._current_observation()

    def step(self, action):
        """
        Execute one time step within the environment.
        """
        if not self.action_space.contains(action):
            raise ValueError("Invalid action")

        # Increment step counter
        self.steps[-1] += 1

        # Generate reward
        reward = self._current_reward()

        # Determine if episode is done
        done = self.steps[-1] >= self.durations[-1]

        # Generate next observation
        observation = self._current_observation()

        # Info dictionary (empty)
        info = {}

        return observation, reward, done, info

    def _current_observation(self):
        """
        Generate a random observation.
        """
        return self.rng.rand(*self.observ_shape).astype(np.float32)

    def _current_reward(self):
        """
        Generate a random reward.
        """
        return float(self.rng.uniform(-1.0, 1.0))
