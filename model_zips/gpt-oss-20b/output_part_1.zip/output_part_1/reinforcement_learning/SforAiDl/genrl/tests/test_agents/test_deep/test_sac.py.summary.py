import os
import shutil
from genrl.envs import VectorEnv
from genrl.off_policy import SAC, OffPolicyTrainer
from genrl.architectures import MLP

def test_sac():
    # Environment setup
    env = VectorEnv(env_name="Pendulum-v0", num_envs=2)

    # Agent initialization
    policy_arch = MLP([1, 1])
    value_arch = MLP([1, 1])
    agent = SAC(policy_arch, value_arch)

    # Trainer configuration
    trainer = OffPolicyTrainer(
        env,
        agent,
        epochs=5,
        max_episode_steps=500,
        warmup_steps=10,
        start_step=10,
        log_dir="./logs",
        csv_log=True
    )

    # Training execution
    trainer.train()

    # Cleanup
    shutil.rmtree("./logs", ignore_errors=True)

def test_sac_shared():
    # Environment setup
    env = VectorEnv(env_name="Pendulum-v0", num_envs=2)

    # Agent initialization with shared layers
    shared_arch = MLP([1, 1])
    policy_arch = MLP([1, 1])
    value_arch = MLP([1, 1])
    agent = SAC(
        policy_arch,
        value_arch,
        shared_layers=shared_arch
    )

    # Trainer configuration
    trainer = OffPolicyTrainer(
        env,
        agent,
        epochs=5,
        max_episode_steps=500,
        warmup_steps=10,
        start_step=10,
        log_dir="./logs",
        csv_log=True
    )

    # Training execution
    trainer.train()

    # Cleanup
    shutil.rmtree("./logs", ignore_errors=True)

if __name__ == "__main__":
    test_sac()
    test_sac_shared()