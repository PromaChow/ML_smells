import unittest
import gym
import numpy as np

# Assume the agent classes and trainer are available in the current namespace
# from agents import QLearning, SARSA, ValueIterator
# from trainer import ClassicalTrainer

class TestQLearning(unittest.TestCase):
    def setUp(self):
        self.env = gym.make("FrozenLake-v0")
        self.agent = QLearning(self.env)

    def test_initial_state(self):
        self.assertTrue(np.all(self.agent.q == 0), "Q-table should be initialized to zeros")

    def test_update_and_action(self):
        state, action, reward, next_state = 3, 1, 3.1, 4
        self.agent.update(state, action, reward, next_state)
        self.assertAlmostEqual(self.agent.q[state, action], 0.031, places=5,
                               msg="Q-value should be updated by 0.031")
        self.assertEqual(self.agent.get_action(state, False), 1,
                         "Agent should select action 1 for state 3 after update")

class TestSARSA(unittest.TestCase):
    def setUp(self):
        self.env = gym.make("FrozenLake-v0")
        self.agent = SARSA(self.env)

    def test_initial_state(self):
        self.assertTrue(np.all(self.agent.q == 0), "Q-table should be initialized to zeros")
        self.assertTrue(np.all(self.agent.e == 0), "Eligibility trace should be initialized to zeros")

    def test_update_and_action(self):
        state, action, reward, next_state = 3, 1, 3.1, 4
        self.agent.update(state, action, reward, next_state)
        self.assertAlmostEqual(self.agent.q[state, action], 0.031, places=5,
                               msg="Q-value should be updated by 0.031")
        self.assertTrue(self.agent.e[state, action] > 0,
                        "Eligibility trace for (3,1) should be updated to a positive value")
        self.assertEqual(self.agent.get_action(state, False), 1,
                         "Agent should select action 1 for state 3 after update")

class TestValueIterator(unittest.TestCase):
    def test_training_and_evaluation(self):
        env = gym.make("FrozenLake-v0")
        agent = ValueIterator(env)
        trainer = ClassicalTrainer(agent=agent,
                                   mode="dyna",
                                   model="tabular",
                                   n_episodes=5,
                                   start_steps=0,
                                   evaluate_frequency=1)
        trainer.train()
        trainer.evaluate()
        # No explicit assertion; ensure no exceptions are raised during training/evaluation

if __name__ == "__main__":
    unittest.main()
