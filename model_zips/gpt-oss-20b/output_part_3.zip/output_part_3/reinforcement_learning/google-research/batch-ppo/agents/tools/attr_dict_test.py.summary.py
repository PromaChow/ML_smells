import unittest

class AttrDict(dict):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._locked = True

    def __getattr__(self, name):
        if name.startswith('__'):
            raise AttributeError(f"'{type(self).__name__}' object has no attribute '{name}'")
        return self.get(name, None)

    def __setattr__(self, name, value):
        if name.startswith('_'):
            object.__setattr__(self, name, value)
        else:
            if self._locked:
                raise RuntimeError("AttributeDict is immutable")
            super().__setitem__(name, value)

    @property
    def unlocked(self):
        return _UnlockContext(self)

class _UnlockContext:
    def __init__(self, obj):
        self._obj = obj

    def __enter__(self):
        self._obj._locked = False
        return self

    def __exit__(self, exc_type, exc, tb):
        self._obj._locked = True

class TestAttrDict(unittest.TestCase):
    def test_construction_from_dict(self):
        obj = AttrDict({'foo': 13, 'bar': 42})
        self.assertEqual(obj.foo, 13)
        self.assertEqual(obj.bar, 42)

    def test_construction_from_kwargs(self):
        obj = AttrDict(foo=13, bar=42)
        self.assertEqual(obj.foo, 13)
        self.assertEqual(obj.bar, 42)

    def test_attribute_presence_check(self):
        obj = AttrDict(foo=13)
        self.assertTrue('foo' in obj)
        self.assertFalse('bar' in obj)

    def test_access_non_existent_attribute(self):
        obj = AttrDict()
        self.assertIsNone(obj.foo)

    def test_prevention_of_magic_method_access(self):
        obj = AttrDict()
        with self.assertRaises(AttributeError):
            _ = obj.__getstate__

    def test_immutability_enforcement_creation(self):
        obj = AttrDict()
        with self.assertRaises(RuntimeError):
            obj.foo = 42

    def test_immutability_enforcement_modification(self):
        obj = AttrDict(foo=13)
        with self.assertRaises(RuntimeError):
            obj.foo = 42

    def test_unlocking_for_modification(self):
        obj = AttrDict(foo=13)
        with obj.unlocked:
            obj.foo = 42
        self.assertEqual(obj.foo, 42)

if __name__ == '__main__':
    unittest.main()
