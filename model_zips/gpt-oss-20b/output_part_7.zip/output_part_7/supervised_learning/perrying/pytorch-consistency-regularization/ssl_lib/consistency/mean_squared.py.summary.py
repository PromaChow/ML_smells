import torch
import torch.nn as nn
import torch.nn.functional as F

def mean_squared(y: torch.Tensor, target: torch.Tensor, mask: torch.Tensor | None = None) -> torch.Tensor:
    """
    Computes a custom mean squared error loss.

    Args:
        y: Raw logits, shape (N, C).
        target: Target probabilities, shape (N, C).
        mask: Optional mask to weight or zero out samples, shape broadcastable to (N,).

    Returns:
        Scalar loss value.
    """
    # 1. Apply softmax along dimension 1
    y_soft = torch.softmax(y, dim=1)

    # 2. Compute per-element MSE loss (no reduction)
    per_element_loss = F.mse_loss(y_soft, target, reduction="none")

    # 3. Average across dimension 1 to get per-sample loss
    per_sample_loss = per_element_loss.mean(dim=1)

    # 4. Apply mask if provided
    if mask is not None:
        per_sample_loss = per_sample_loss * mask

    # 5. Final average across all samples
    return per_sample_loss.mean()


class MeanSquared(nn.Module):
    """
    PyTorch module that wraps the custom mean squared error computation.
    """

    def __init__(self):
        super().__init__()

    def forward(self, y: torch.Tensor, target: torch.Tensor, mask: torch.Tensor | None = None) -> torch.Tensor:
        """
        Forward pass.

        Args:
            y: Raw logits, shape (N, C).
            target: Target probabilities, shape (N, C).
            mask: Optional mask, shape broadcastable to (N,).

        Returns:
            Scalar loss value.
        """
        # Detach target to prevent gradients flowing into it
        detached_target = target.detach()
        return mean_squared(y, detached_target, mask)