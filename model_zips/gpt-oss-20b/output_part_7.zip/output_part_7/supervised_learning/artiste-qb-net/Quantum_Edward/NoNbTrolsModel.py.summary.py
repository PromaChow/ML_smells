import numpy as np


class Model:
    def __init__(self, nb: int, na: int):
        self.nb = nb
        self.na = na


class NbTrolsModel:
    @staticmethod
    def static_prob_x(x: int, na: int, list1_angs, verbose: bool = False) -> float:
        """Placeholder implementation for static probability calculation."""
        if verbose:
            print(f"Computing static_prob_x for x={x}, na={na}")
        # Simple deterministic probability for demonstration
        return 1.0 / (2 ** na)


def ang_to_cs2_prob(angle: float, bit: int) -> float:
    """Map an angle to a probability based on the last bit of y."""
    if bit == 1:
        return np.cos(angle) ** 2
    else:
        return np.sin(angle) ** 2


class NoNbTrolsModel(Model, NbTrolsModel):
    def __init__(self, nb: int, na: int):
        super().__init__(nb, na)

    def get_shapes1(self) -> list[tuple[int, ...]]:
        powna = 2 ** self.na
        shapes = [(2 ** k,) for k in range(self.na)]
        shapes += [(powna,) for _ in range(self.nb)]
        return shapes

    def prob_x(self, x: int, list1_angs: list[float], verbose: bool = False) -> float:
        return NbTrolsModel.static_prob_x(x, self.na, list1_angs, verbose)

    def prob_y_given_x_and_angs_prior(
        self, y: int, x: int, list1_angs: list[float]
    ) -> float:
        # Convert y to binary vector of length nb
        ybin = [(y >> i) & 1 for i in range(self.nb)]
        prob = 1.0
        # Use the last nb angles
        angles = list1_angs[-self.nb :]
        for i, angle in enumerate(angles):
            bit = ybin[i]
            factor = ang_to_cs2_prob(angle, bit)
            prob *= factor
        return prob

    def gen_toy_data(self, nsam: int) -> tuple[np.ndarray, np.ndarray]:
        """Generate synthetic toy data for x and y."""
        x_nsam_na = np.random.randint(
            0, 2 ** self.na, size=(nsam, 2 ** self.na), dtype=np.int32
        )
        y_nsam_nb = np.random.randint(
            0, 2 ** self.nb, size=(nsam, 2 ** self.nb), dtype=np.int32
        )
        return x_nsam_na, y_nsam_nb


def main():
    nb = 3
    na = 2
    model = NoNbTrolsModel(nb, na)
    nsam = 10
    x_data, y_data = model.gen_toy_data(nsam)
    print("x_nsam_na:")
    print(x_data)
    print("\ny_nsam_nb:")
    print(y_data)


if __name__ == "__main__":
    main()
