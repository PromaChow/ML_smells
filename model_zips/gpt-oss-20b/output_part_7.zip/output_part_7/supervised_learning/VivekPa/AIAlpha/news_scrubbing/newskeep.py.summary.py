from collections import deque
import numpy as np
import pandas as pd
import apiprocessing.stories

datax = deque()

for story in apiprocessing.stories:
    x = [
        story.title,
        story.source.name,
        story.published_at.date(),
        story.sentiment.title.score,
        story.sentiment.body.score,
        ' '.join(story.summary.sentences),
        story.links.permalink
    ]
    datax.append(x)

storage = datax = np.array(list(datax))
df = pd.DataFrame(
    datax,
    columns=[
        'Title',
        'Source',
        'Date',
        'Title Sentiment',
        'Body Sentiment',
        'Summary',
        'Link'
    ]
)
df.index = df.index + 1
df.to_csv('export.csv', index=True)
print('Collected articles have been written to export.csv')