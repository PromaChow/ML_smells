import numpy as np
from sklearn.metrics import explained_variance_score

def explained_variance(y_true, y_pred, **kwargs) -> float:
    """
    Calculate the explained variance regression score.

    Parameters
    ----------
    y_true : list or list of lists
        Ground truth (correct) target values.
    y_pred : list or list of lists
        Estimated target values.
    **kwargs
        Additional keyword arguments passed to sklearn's explained_variance_score.

    Returns
    -------
    float
        The explained variance score.  It ranges from -∞ (worse than predicting zero)
        to 1.0 (perfect prediction).
    """
    y_true_arr = np.squeeze(np.array(y_true))
    y_pred_arr = np.squeeze(np.array(y_pred))
    assert y_true_arr.shape == y_pred_arr.shape, (
        f"Shape mismatch: y_true has shape {y_true_arr.shape}, "
        f"but y_pred has shape {y_pred_arr.shape}"
    )
    return float(explained_variance_score(y_true_arr, y_pred_arr, **kwargs))