import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from matplotlib.collections import PatchCollection
from matplotlib.colors import Normalize
from mpl_toolkits.basemap import Basemap

# 1. Data Loading and Grouping
df = pd.read_csv('aadhar_saturation.csv')
sat_list = [
    (name, group.iloc[:, 4].sum())
    for name, group in df.groupby('State Name')
]
sat_dict = dict(sat_list)

# 2. Map Initialization
m = Basemap(
    projection='merc',
    llcrnrlon=68, urcrnrlon=97,
    llcrnrlat=6, urcrnrlat=37,
    resolution='i',
    lat_ts=20,
    ax=plt.gca()
)
m.drawcoastlines()
m.drawcountries()
m.fillcontinents(color='lightgray', lake_color='steelblue')
m.drawmapboundary(fill_color='steelblue')

# 3. Shapefile Integration
m.readshapefile('India_SHP/INDIA', 'INDIA', drawbounds=False)

# 4. Saturation Value Mapping
polygons = []
states = []
saturation_values = []

for shape_info, shape in zip(m.INDIA_info, m.INDIA):
    name = shape_info.get('STATE', shape_info.get('NAME', 'Unknown'))
    sat_value = sat_dict.get(name, 0)
    polygons.append(Polygon(shape, True))
    states.append(name)
    saturation_values.append(sat_value)

# 5. Polygon and Color Preparation
df_poly = pd.DataFrame(
    {
        'polygon': polygons,
        'state': states,
        'saturation': saturation_values
    }
)

patch_collection = PatchCollection(
    df_poly['polygon'],
    cmap='Oranges_r',
    edgecolor='k',
    linewidths=0.5,
    zorder=2
)

norm = Normalize(
    vmin=min(df_poly['saturation']),
    vmax=max(df_poly['saturation'])
)
patch_collection.set_array(df_poly['saturation'])
patch_collection.set_norm(norm)

# 6. Visualization
fig = plt.figure(figsize=(15, 15))
ax = plt.gca()
ax.add_collection(patch_collection)
plt.colorbar(patch_collection, ax=ax, orientation='horizontal', pad=0.05, fraction=0.046)
ax.set_title('Aadhar Saturation', fontsize=16)

plt.show()
