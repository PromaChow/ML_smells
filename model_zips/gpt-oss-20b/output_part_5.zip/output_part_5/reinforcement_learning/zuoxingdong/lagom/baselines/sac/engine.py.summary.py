import time
from itertools import count
from dataclasses import dataclass, field
from typing import List, Dict, Any

def color_str(s: str, color: str = "green") -> str:
    colors = {"green": "\033[92m", "red": "\033[91m", "yellow": "\033[93m", "reset": "\033[0m"}
    return f"{colors.get(color, '')}{s}{colors['reset']}"

class Logger:
    def __init__(self, **kwargs):
        self.metrics = kwargs

    def dump(self, border: str = "-"):
        print(border)
        for k, v in self.metrics.items():
            print(f"{k}: {v}")
        print(border)

class BaseEngine:
    pass

@dataclass
class TrainConfig:
    timestep: int = 1000

@dataclass
class ReplayConfig:
    init_trial: int = 10

@dataclass
class LogConfig:
    freq: int = 5

@dataclass
class CheckpointConfig:
    num: int = 4

@dataclass
class EvalConfig:
    num: int = 2

@dataclass
class Config:
    train: TrainConfig = TrainConfig()
    replay: ReplayConfig = ReplayConfig()
    log: LogConfig = LogConfig()
    checkpoint: CheckpointConfig = CheckpointConfig()
    eval: EvalConfig = EvalConfig()

class Trajectory:
    def __init__(self, rewards: List[float]):
        self.rewards = rewards
        self.T = len(rewards)

class ReplayBuffer:
    def __init__(self):
        self.storage = []

    def add(self, traj: Trajectory):
        self.storage.append(traj)

class DummyAgent:
    def __init__(self):
        self.total_timestep = 0

    def collect_trajectory(self, env, mode: str = "train") -> Trajectory:
        rewards = [1.0 for _ in range(10)]
        return Trajectory(rewards)

    def learn(self, replay: ReplayBuffer, num_updates: int) -> Dict[str, Any]:
        self.total_timestep += num_updates * 10
        return {"loss": 0.01 * num_updates}

class EvalEnvironment:
    def __init__(self):
        self.running_return = 0.0
        self.running_horizon = 0

    def run(self, agent: DummyAgent, num_trajectories: int = 10) -> List[Trajectory]:
        trajectories = []
        for _ in range(num_trajectories):
            traj = agent.collect_trajectory(self, mode="eval")
            trajectories.append(traj)
            self.running_return += sum(traj.rewards)
            self.running_horizon += traj.T
        return trajectories

class Engine(BaseEngine):
    def __init__(self, config: Config, agent: DummyAgent, random_agent: DummyAgent,
                 replay: ReplayBuffer, eval_env: EvalEnvironment):
        self.config = config
        self.agent = agent
        self.random_agent = random_agent
        self.replay = replay
        self.eval_env = eval_env
        self.train_logs: List[Dict[str, Any]] = []
        self.eval_logs: List[Dict[str, Any]] = []
        self.checkpoint_count: int = 0

    def run(self):
        for iteration in count():
            if self.agent.total_timestep >= self.config.train.timestep:
                break

            t0 = time.time()

            if iteration < self.config.replay.init_trial:
                traj = self.random_agent.collect_trajectory(self.eval_env, mode="train")
            else:
                traj = self.agent.collect_trajectory(self.eval_env, mode="train")

            self.replay.add(traj)
            out_agent = self.agent.learn(self.replay, num_updates=traj.T)

            logger = Logger(
                train_iteration=iteration,
                num_seconds=time.time() - t0,
                **out_agent,
                episode_return=sum(traj.rewards),
                episode_horizon=traj.T,
                accumulated_trained_timesteps=self.agent.total_timestep
            )
            train_log = logger.metrics
            self.train_logs.append(train_log)

            if iteration == 0 or iteration % self.config.log.freq == 0:
                logger.dump(border='-' * 50)

            checkpoint_threshold = (self.config.checkpoint.num - self.checkpoint_count) / self.config.checkpoint.num
            if self.agent.total_timestep >= checkpoint_threshold * self.config.train.timestep:
                self.checkpoint_count += 1

            eval_threshold = (self.config.eval.num - len(self.eval_logs)) / self.config.eval.num
            if self.agent.total_timestep >= eval_threshold * self.config.train.timestep:
                self.eval_logs.append(self.eval())

        return self.train_logs, self.eval_logs

    def eval(self):
        t0 = time.time()
        trajectories = self.eval_env.run(self.agent, num_trajectories=10)

        online_return = sum(sum(traj.rewards) for traj in trajectories)
        online_horizon = sum(traj.T for traj in trajectories)

        logger = Logger(
            eval_iteration=len(self.eval_logs),
            num_seconds=time.time() - t0,
            accumulated_trained_timesteps=self.agent.total_timestep,
            online_return=online_return,
            online_horizon=online_horizon,
            running_return=self.eval_env.running_return,
            running_horizon=self.eval_env.running_horizon
        )
        eval_log = logger.metrics
        logger.dump(border=color_str('+' * 50, color='green'))
        return eval_log

# Example usage
if __name__ == "__main__":
    cfg = Config()
    agent = DummyAgent()
    random_agent = DummyAgent()
    replay = ReplayBuffer()
    eval_env = EvalEnvironment()
    engine = Engine(cfg, agent, random_agent, replay, eval_env)
    train_logs, eval_logs = engine.run()
    print("Training logs:", train_logs)
    print("Evaluation logs:", eval_logs)