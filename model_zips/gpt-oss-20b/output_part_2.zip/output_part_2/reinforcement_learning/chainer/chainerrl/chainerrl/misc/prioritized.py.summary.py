import random
from collections import deque

class FenwickTree:
    def __init__(self, size):
        self.n = size
        self.bit = [0.0] * (size + 1)

    def add(self, idx, delta):
        i = idx + 1
        while i <= self.n:
            self.bit[i] += delta
            i += i & -i

    def sum(self, idx):
        res = 0.0
        i = idx + 1
        while i > 0:
            res += self.bit[i]
            i -= i & -i
        return res

    def total(self):
        return self.sum(self.n - 1)

    def get(self, idx):
        if idx == 0:
            return self.sum(0)
        return self.sum(idx) - self.sum(idx - 1)

    def find_prefix(self, value):
        idx = 0
        bit_mask = 1 << (self.n.bit_length() - 1)
        while bit_mask:
            t = idx + bit_mask
            if t <= self.n and self.bit[t] < value:
                value -= self.bit[t]
                idx = t
            bit_mask >>= 1
        return idx  # 0‑based index


class MinTree:
    def __init__(self, size):
        self.n = size
        self.size = 1
        while self.size < self.n:
            self.size <<= 1
        self.tree = [float('inf')] * (2 * self.size)

    def update(self, idx, value):
        pos = self.size + idx
        self.tree[pos] = value
        pos >>= 1
        while pos >= 1:
            self.tree[pos] = min(self.tree[pos << 1], self.tree[(pos << 1) | 1])
            pos >>= 1

    def min(self):
        return self.tree[1]


class PrioritizedBuffer:
    def __init__(self, capacity, uniform_ratio=0.0):
        self.capacity = capacity
        self.uniform_ratio = uniform_ratio
        self.data = [None] * capacity
        self.priorities = [0.0] * capacity
        self.sum_tree = FenwickTree(capacity)
        self.min_tree = MinTree(capacity)
        self.max_priority = 0.0
        self.size = 0
        self.pos = 0
        self.wait_priority_after_sampling = False
        self.last_sampled_indices = []

    def append(self, datum, priority=None):
        if priority is None:
            priority = self.max_priority if self.max_priority > 0 else 1.0
        if self.size < self.capacity:
            self.size += 1
        else:
            old_priority = self.priorities[self.pos]
            self.sum_tree.add(self.pos, -old_priority)
        self.data[self.pos] = datum
        self.priorities[self.pos] = priority
        self.sum_tree.add(self.pos, priority)
        self.min_tree.update(self.pos, priority)
        if priority > self.max_priority:
            self.max_priority = priority
        self.pos = (self.pos + 1) % self.capacity

    def sample(self, batch_size):
        if self.size == 0:
            return [], [], []
        n_uniform = int(batch_size * self.uniform_ratio)
        n_prior = batch_size - n_uniform
        indices = []
        probs = []
        # Uniform sampling
        if n_uniform > 0:
            uniform_indices = random.sample(range(self.size), n_uniform)
            for idx in uniform_indices:
                prob = self.uniform_ratio / self.size
                indices.append(idx)
                probs.append(prob)
        # Prioritized sampling
        if n_prior > 0:
            total = self.sum_tree.total()
            for _ in range(n_prior):
                rand = random.random() * total
                idx = self.sum_tree.find_prefix(rand) + 1
                if idx >= self.size:
                    idx = self.size - 1
                priority = self.sum_tree.get(idx)
                prob = (1 - self.uniform_ratio) * priority / total
                indices.append(idx)
                probs.append(prob)
        self.last_sampled_indices = indices
        self.wait_priority_after_sampling = True
        sampled_data = [self.data[i] for i in indices]
        return sampled_data, indices, probs

    def set_last_priority(self, new_priorities):
        if not self.wait_priority_after_sampling:
            return
        assert len(new_priorities) == len(self.last_sampled_indices)
        for idx, new_p in zip(self.last_sampled_indices, new_priorities):
            old_p = self.priorities[idx]
            delta = new_p - old_p
            self.sum_tree.add(idx, delta)
            self.min_tree.update(idx, new_p)
            self.priorities[idx] = new_p
            if new_p > self.max_priority:
                self.max_priority = new_p
        self.wait_priority_after_sampling = False
        self.last_sampled_indices = []
        self.max_priority = max(self.priorities[:self.size]) if self.size > 0 else 0.0
        if self.size > 0:
            self.min_tree.min()
```