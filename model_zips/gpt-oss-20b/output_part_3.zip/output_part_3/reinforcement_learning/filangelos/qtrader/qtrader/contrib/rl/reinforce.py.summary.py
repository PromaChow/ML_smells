import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import Adam

class ReinforceAgent:
    def __init__(self, state_dim, action_dim, gamma=0.99, lr=0.001):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.gamma = gamma
        self.lr = lr
        self.model = self._build_model()
        self.states = []
        self.actions = []
        self.rewards = []

    def _build_model(self):
        model = Sequential()
        model.add(Dense(24, activation='relu', input_shape=(self.state_dim,)))
        model.add(Dense(24, activation='relu'))
        model.add(Dense(self.action_dim, activation='softmax'))
        model.compile(optimizer=Adam(learning_rate=self.lr),
                      loss='categorical_crossentropy')
        return model

    def act(self, state):
        state = np.array(state).reshape(1, -1)
        probs = self.model.predict(state, verbose=0)[0]
        action = np.random.choice(self.action_dim, p=probs)
        return action

    def store_transition(self, state, action, reward):
        self.states.append(state)
        self.actions.append(action)
        self.rewards.append(reward)

    def _discount_rewards(self):
        discounted = np.zeros_like(self.rewards, dtype=np.float32)
        running = 0.0
        for t in reversed(range(len(self.rewards))):
            running = running * self.gamma + self.rewards[t]
            discounted[t] = running
        mean = np.mean(discounted)
        std = np.std(discounted) if np.std(discounted) > 0 else 1.0
        return (discounted - mean) / std

    def train(self):
        if not self.states:
            return
        states_np = np.array(self.states)
        advantages = self._discount_rewards()
        targets = np.zeros((len(self.actions), self.action_dim))
        for i, action in enumerate(self.actions):
            targets[i, action] = advantages[i]
        self.model.fit(states_np, targets, epochs=1, verbose=0)

    def reset(self):
        self.states.clear()
        self.actions.clear()
        self.rewards.clear()