import torch
import random
from typing import List, Optional, Tuple

class TransitionDB:
    def __init__(self, device: str | torch.device = "cpu"):
        if isinstance(device, str):
            if "cuda" in device.lower() and torch.cuda.is_available():
                self.device = torch.device(device)
            else:
                self.device = torch.device("cpu")
        else:
            self.device = device

        self.db = {
            "contexts": [],
            "actions": [],
            "rewards": []
        }
        self.db_size: int = 0

    def add(self, context: torch.Tensor, action: int, reward: int) -> None:
        self.db["contexts"].append(context)
        self.db["actions"].append(action)
        self.db["rewards"].append(reward)
        self.db_size += 1

    def _sample_indices(self, num_samples: int) -> List[int]:
        if num_samples == 0:
            return []
        return random.sample(range(self.db_size), num_samples)

    def get_data(self, batch_size: Optional[int] = None) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        if self.db_size == 0:
            return (
                torch.empty(0, dtype=torch.float, device=self.device),
                torch.empty(0, dtype=torch.long, device=self.device),
                torch.empty(0, 1, dtype=torch.float, device=self.device),
            )

        n = self.db_size if batch_size is None else min(batch_size, self.db_size)
        indices = self._sample_indices(n)

        contexts = torch.stack([self.db["contexts"][i] for i in indices]).to(self.device).float()
        actions = torch.tensor([self.db["actions"][i] for i in indices], dtype=torch.long, device=self.device)
        rewards = torch.tensor([self.db["rewards"][i] for i in indices], dtype=torch.float, device=self.device).unsqueeze(-1)

        return contexts, actions, rewards

    def get_data_for_action(self, action: int, batch_size: Optional[int] = None) -> Tuple[torch.Tensor, torch.Tensor]:
        matching_indices = [i for i, a in enumerate(self.db["actions"]) if a == action]
        if not matching_indices:
            return (
                torch.empty(0, dtype=torch.float, device=self.device),
                torch.empty(0, 1, dtype=torch.float, device=self.device),
            )

        n = len(matching_indices) if batch_size is None else min(batch_size, len(matching_indices))
        indices = random.sample(matching_indices, n)

        contexts = torch.stack([self.db["contexts"][i] for i in indices]).to(self.device).float()
        rewards = torch.tensor([self.db["rewards"][i] for i in indices], dtype=torch.float, device=self.device).unsqueeze(-1)

        return contexts, rewards
