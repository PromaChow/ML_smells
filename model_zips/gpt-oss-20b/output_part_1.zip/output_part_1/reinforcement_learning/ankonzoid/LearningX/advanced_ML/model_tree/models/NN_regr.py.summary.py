import os
from tensorflow.keras import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import Adam
from sklearn.metrics import mean_squared_error


class NN_regressor:
    def __init__(self):
        pass

    def fit(self, X, y):
        os.environ["TF_CPP_MIN_LOG_LEVEL"] = "2"
        assert len(X.shape) == 2, "Input X must be a 2D array"

        self.model = Sequential([
            Dense(10, activation="relu", input_dim=X.shape[1]),
            Dense(10, activation="relu"),
            Dense(1, activation="relu")
        ])

        self.model.compile(optimizer=Adam(learning_rate=0.005), loss="mse")
        self.model.fit(X, y, epochs=100, verbose=False)

    def predict(self, X):
        return self.model.predict(X)

    def loss(self, y_true, y_pred):
        return mean_squared_error(y_true, y_pred)