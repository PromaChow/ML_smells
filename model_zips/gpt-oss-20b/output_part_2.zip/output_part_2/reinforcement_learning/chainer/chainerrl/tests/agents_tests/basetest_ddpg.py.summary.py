import gymnasium as gym
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from abc import ABC, abstractmethod
from collections import deque
from typing import Callable, Tuple, Any


# ----------------------------------------------------------------------
# Simple replay buffers
# ----------------------------------------------------------------------
class ReplayBuffer:
    def __init__(self, capacity: int):
        self.capacity = capacity
        self.buffer = deque(maxlen=capacity)

    def push(self, *transition):
        self.buffer.append(transition)

    def sample(self, batch_size: int):
        indices = np.random.choice(len(self.buffer), batch_size, replace=False)
        batch = [self.buffer[idx] for idx in indices]
        return map(np.array, zip(*batch))

    def __len__(self):
        return len(self.buffer)


class EpisodicReplayBuffer(ReplayBuffer):
    """Buffer that stores whole episodes."""
    def __init__(self, capacity: int):
        super().__init__(capacity)
        self.episode = []

    def push(self, *transition):
        self.episode.append(transition)
        if transition[-1].get("done", False):
            self.buffer.append(self.episode)
            self.episode = []


# ----------------------------------------------------------------------
# Explorer
# ----------------------------------------------------------------------
class LinearDecayEpsilonGreedy:
    def __init__(
        self,
        epsilon_start: float,
        epsilon_end: float,
        decay_steps: int,
        random_action_func: Callable[[], Any],
    ):
        self.epsilon_start = epsilon_start
        self.epsilon_end = epsilon_end
        self.decay_steps = decay_steps
        self.random_action_func = random_action_func
        self.step = 0

    def sample_action(self, deterministic_action):
        epsilon = self.epsilon_end + (self.epsilon_start - self.epsilon_end) * max(
            0, (self.decay_steps - self.step) / self.decay_steps
        )
        self.step += 1
        if np.random.rand() < epsilon:
            return self.random_action_func()
        return deterministic_action


# ----------------------------------------------------------------------
# Dummy environment
# ----------------------------------------------------------------------
class ABCEnv(gym.Env):
    metadata = {"render_modes": ["human"]}

    def __init__(self, discrete: bool = False, deterministic: bool = False):
        super().__init__()
        self.discrete = discrete
        self.deterministic = deterministic
        low = -1.0
        high = 1.0
        shape = (4,)
        self.observation_space = gym.spaces.Box(low=low, high=high, shape=shape, dtype=np.float32)
        self.action_space = gym.spaces.Box(low=low, high=high, shape=(2,), dtype=np.float32)
        self.state = self.observation_space.sample()

    def reset(self, *, seed=None, options=None):
        self.state = self.observation_space.sample()
        return self.state, {}

    def step(self, action):
        if self.deterministic:
            reward = 1.0
        else:
            reward = np.random.rand()
        self.state = self.observation_space.sample()
        done = False
        info = {"done": done}
        return self.state, reward, done, False, info

    def render(self, mode="human"):
        pass


# ----------------------------------------------------------------------
# Policy and Q-function stubs
# ----------------------------------------------------------------------
class FCLSTMDeterministicPolicy(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden_size=50, num_layers=2):
        super().__init__()
        self.lstm = nn.LSTM(obs_dim, hidden_size, num_layers, batch_first=True)
        self.out = nn.Linear(hidden_size, act_dim)

    def forward(self, x):
        _, (h, _) = self.lstm(x)
        return torch.tanh(self.out(h[-1]))


class FCLSTMSAQFunction(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden_size=50, num_layers=2):
        super().__init__()
        self.lstm = nn.LSTM(obs_dim + act_dim, hidden_size, num_layers, batch_first=True)
        self.out = nn.Linear(hidden_size, 1)

    def forward(self, obs, act):
        x = torch.cat([obs, act], dim=-1)
        _, (h, _) = self.lstm(x.unsqueeze(1))
        return self.out(h[-1])


class FCBNDeterministicPolicy(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden_size=50, num_layers=2):
        super().__init__()
        layers = []
        in_dim = obs_dim
        for _ in range(num_layers):
            layers.append(nn.Linear(in_dim, hidden_size))
            layers.append(nn.ReLU())
            in_dim = hidden_size
        layers.append(nn.Linear(hidden_size, act_dim))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return torch.tanh(self.net(x))


class FCBNLateActionSAQFunction(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden_size=50, num_layers=2):
        super().__init__()
        layers = []
        in_dim = obs_dim
        for _ in range(num_layers):
            layers.append(nn.Linear(in_dim, hidden_size))
            layers.append(nn.ReLU())
            in_dim = hidden_size
        self.later_net = nn.Sequential(*layers)
        self.out = nn.Linear(hidden_size + act_dim, 1)

    def forward(self, obs, act):
        h = self.later_net(obs)
        return self.out(torch.cat([h, act], dim=-1))


# ----------------------------------------------------------------------
# DDPG Agent
# ----------------------------------------------------------------------
class DDPGAgent:
    def __init__(
        self,
        policy,
        q_function,
        policy_lr: float,
        q_lr: float,
        buffer,
        explorer: LinearDecayEpsilonGreedy,
        device: torch.device,
    ):
        self.policy = policy.to(device)
        self.q_function = q_function.to(device)
        self.policy_optimizer = optim.Adam(self.policy.parameters(), lr=policy_lr)
        self.q_optimizer = optim.Adam(self.q_function.parameters(), lr=q_lr)
        self.buffer = buffer
        self.explorer = explorer
        self.device = device

    def act(self, obs, deterministic=False):
        obs_tensor = torch.tensor(obs, dtype=torch.float32, device=self.device).unsqueeze(0)
        with torch.no_grad():
            action = self.policy(obs_tensor).cpu().numpy().squeeze(0)
        if deterministic:
            return action
        return self.explorer.sample_action(action)

    def store_transition(self, *transition):
        self.buffer.push(*transition)

    def learn(self, batch_size: int):
        if len(self.buffer) < batch_size:
            return
        obs, act, rew, next_obs, done = self.buffer.sample(batch_size)

        obs = torch.tensor(obs, dtype=torch.float32, device=self.device)
        act = torch.tensor(act, dtype=torch.float32, device=self.device)
        rew = torch.tensor(rew, dtype=torch.float32, device=self.device)
        next_obs = torch.tensor(next_obs, dtype=torch.float32, device=self.device)
        done = torch.tensor(done, dtype=torch.float32, device=self.device)

        with torch.no_grad():
            next_act = self.policy(next_obs)
            target_q = self.q_function(next_obs, next_act).squeeze() + rew * (1 - done)
        current_q = self.q_function(obs, act).squeeze()
        q_loss = nn.functional.mse_loss(current_q, target_q)

        self.q_optimizer.zero_grad()
        q_loss.backward()
        self.q_optimizer.step()

        actor_loss = -self.q_function(obs, self.policy(obs)).mean()

        self.policy_optimizer.zero_grad()
        actor_loss.backward()
        self.policy_optimizer.step()


# ----------------------------------------------------------------------
# Base test class
# ----------------------------------------------------------------------
class _TestTraining:
    """Placeholder base class for tests."""
    def run_test(self):
        raise NotImplementedError


class _TestDDPGOnABC(_TestTraining, ABC):
    def __init__(self):
        self.device = torch.device("cpu")

    def make_env_and_successful_return(self, test: bool) -> Tuple[gym.Env, float]:
        env = ABCEnv(discrete=False, deterministic=test)
        successful_return = 1.0
        return env, successful_return

    def make_agent(self, env: gym.Env) -> DDPGAgent:
        obs_dim = env.observation_space.shape[0]
        act_dim = env.action_space.shape[0]

        policy, q_function = self.make_model(obs_dim, act_dim)
        buffer = self.make_replay_buffer()

        def random_action():
            return env.action_space.sample()

        explorer = LinearDecayEpsilonGreedy(
            epsilon_start=1.0,
            epsilon_end=0.2,
            decay_steps=1000,
            random_action_func=random_action,
        )

        agent = DDPGAgent(
            policy=policy,
            q_function=q_function,
            policy_lr=1e-4,
            q_lr=1e-3,
            buffer=buffer,
            explorer=explorer,
            device=self.device,
        )
        return agent

    @abstractmethod
    def make_model(self, obs_dim: int, act_dim: int) -> Tuple[nn.Module, nn.Module]:
        pass

    @abstractmethod
    def make_replay_buffer(self) -> ReplayBuffer:
        pass

    def run_test(self):
        env, success = self.make_env_and_successful_return(test=False)
        agent = self.make_agent(env)
        # Dummy training loop
        obs, _ = env.reset()
        for _ in range(10):
            action = agent.act(obs, deterministic=False)
            next_obs, reward, done, _, _ = env.step(action)
            agent.store_transition(obs, action, reward, next_obs, done)
            agent.learn(batch_size=4)
            if done:
                obs, _ = env.reset()
            else:
                obs = next_obs
        assert success == 1.0


# ----------------------------------------------------------------------
# Partially observable continuous test
# ----------------------------------------------------------------------
class _TestDDPGOnContinuousPOABC(_TestDDPGOnABC):
    def make_model(self, obs_dim: int, act_dim: int) -> Tuple[nn.Module, nn.Module]:
        policy = FCLSTMDeterministicPolicy(obs_dim, act_dim, hidden_size=50, num_layers=2)
        q_function = FCLSTMSAQFunction(obs_dim, act_dim, hidden_size=50, num_layers=2)
        return policy, q_function

    def make_replay_buffer(self) -> ReplayBuffer:
        return EpisodicReplayBuffer(capacity=100_000)


# ----------------------------------------------------------------------
# Fully observable continuous test
# ----------------------------------------------------------------------
class _TestDDPGOnContinuousABC(_TestDDPGOnABC):
    def make_model(self, obs_dim: int, act_dim: int) -> Tuple[nn.Module, nn.Module]:
        policy = FCBNDeterministicPolicy(obs_dim, act_dim, hidden_size=50, num_layers=2)
        q_function = FCBNLateActionSAQFunction(obs_dim, act_dim, hidden_size=50, num_layers=2)
        return policy, q_function

    def make_replay_buffer(self) -> ReplayBuffer:
        return ReplayBuffer(capacity=100_000)


# ----------------------------------------------------------------------
# Example usage
# ----------------------------------------------------------------------
if __name__ == "__main__":
    test_po = _TestDDPGOnContinuousPOABC()
    test_po.run_test()
    test_full = _TestDDPGOnContinuousABC()
    test_full.run_test()
