import gym
import torch
import torch.nn as nn
import torch.nn.functional as F
from lagom.networks import Module, make_fc
from lagom.heads import CategoricalHead, DiagGaussianHead
from lagom.agents import BaseAgent
from lagom.utils import pickle_dump
from lagom import spaces as lagom_spaces


class MLP(Module):
    def __init__(self, config, env, device):
        super().__init__()
        input_dim = lagom_spaces.flatdim(env.observation_space)
        hidden_sizes = config['nn.sizes']
        self.layers = nn.ModuleList()
        self.norms = nn.ModuleList()

        prev_dim = input_dim
        for hdim in hidden_sizes:
            fc = make_fc(prev_dim, hdim)
            norm = nn.LayerNorm(hdim)
            self.layers.append(fc)
            self.norms.append(norm)
            prev_dim = hdim

        self.to(device)

    def forward(self, x):
        for fc, norm in zip(self.layers, self.norms):
            x = fc(x)
            x = F.relu(x)
            x = norm(x)
        return x


class Agent(BaseAgent):
    def __init__(self, config, env, device):
        super().__init__()
        self.device = device
        self.config = config
        self.env = env

        self.feature_network = MLP(config, env, device)
        feature_dim = config['nn.sizes'][-1]

        if isinstance(env.action_space, gym.spaces.Discrete):
            self.action_head = CategoricalHead(feature_dim, env.action_space.n)
        elif isinstance(env.action_space, gym.spaces.Box):
            self.action_head = DiagGaussianHead(
                feature_dim,
                env.action_space.shape[0],
                init_std=config['agent.std0']
            )
        else:
            raise NotImplementedError("Unsupported action space type")

        self.total_timestep = 0

    def choose_action(self, x):
        x = torch.as_tensor(x, dtype=torch.float32, device=self.device)
        with torch.no_grad():
            features = self.feature_network(x)
            dist = self.action_head(features)
            action = dist.sample()
        action_np = action.cpu().numpy()
        if isinstance(self.env.action_space, gym.spaces.Discrete):
            action_np = int(action_np)
        else:
            action_np = action_np.astype(self.env.action_space.dtype)
        return action_np

    def learn(self, *args, **kwargs):
        pass

    def checkpoint(self, path):
        checkpoint = {
            'feature_network': self.feature_network.state_dict(),
            'action_head': self.action_head.state_dict(),
            'total_timestep': self.total_timestep
        }
        torch.save(checkpoint, path)

        if self.config.get('env', {}).get('normalize_obs', False):
            norm_path = f"{path}.norm"
            with open(norm_path, 'wb') as f:
                pickle_dump(
                    {
                        'mean': getattr(self.env.observation_space, 'mean', None),
                        'var': getattr(self.env.observation_space, 'var', None)
                    },
                    f
                )