import gym
import numpy as np
import traceback
import pybulletgym  # register PyBullet environments

# Identify MuJoCo environments
mujo_envs = [env_id for env_id in gym.envs.registry.env_specs if "MuJoCo" in env_id]

bugged_envs = []

for env_id in mujo_envs:
    try:
        env = gym.make(env_id)
        env.reset()
        # Sample a random action
        action_space = env.action_space
        if hasattr(action_space, "shape"):
            low = action_space.low
            high = action_space.high
            # Handle cases where low/high are scalars
            if np.isscalar(low):
                low = np.full(action_space.shape, low)
            if np.isscalar(high):
                high = np.full(action_space.shape, high)
            action = np.random.uniform(low=low, high=high, size=action_space.shape)
        elif hasattr(action_space, "n"):
            action = np.random.randint(action_space.n)
        else:
            action = action_space.sample()
        env.step(action)
        env.close()
        print(f"[SUCCESS] {env_id} initialized and ran a step without errors.")
    except Exception as e:
        print(f"[FAILURE] {env_id} raised an exception: {e}")
        traceback.print_exc()
        bugged_envs.append(env_id)

print("\nEnvironments with issues:")
for bad_env in bugged_envs:
    print(f" - {bad_env}")