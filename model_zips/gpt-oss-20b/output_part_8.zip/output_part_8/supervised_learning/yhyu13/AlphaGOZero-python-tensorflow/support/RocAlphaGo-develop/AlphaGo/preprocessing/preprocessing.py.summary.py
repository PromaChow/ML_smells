import numpy as np
from keras import backend as K

# Set Keras image dimension ordering to Theano format (channels first)
K.set_image_dim_ordering('th')

# Feature extraction functions
def get_board(state):
    """
    Creates a 3-channel tensor:
    - Channel 0: current player's stones
    - Channel 1: opponent's stones
    - Channel 2: empty spaces
    """
    board = state.board
    current = state.current_player
    own = (board == current).astype(np.float32)
    opp = (board == -current).astype(np.float32)
    empty = (board == 0).astype(np.float32)
    return np.stack([own, opp, empty], axis=0)


def get_turns_since(state):
    """
    Encodes age of stones using up to 8 planes.
    Plane i contains positions whose stones have age in [i, i+1).
    Empty positions get zeros.
    """
    max_age = 8
    board = state.board
    age = state.turns_since  # 2D array same shape as board
    planes = []
    for i in range(max_age):
        mask = (age >= i) & (age < i + 1) & (board != 0)
        planes.append(mask.astype(np.float32))
    return np.stack(planes, axis=0)


def get_liberties(state):
    """
    Encodes liberties per stone using up to 8 planes.
    Plane i contains positions whose stones have liberties in [i, i+1).
    Empty positions get zeros.
    """
    board = state.board
    size = board.shape[0]
    liberties = np.zeros_like(board, dtype=int)

    # Simple liberties calculation: count adjacent empty points
    for r in range(size):
        for c in range(size):
            if board[r, c] != 0:
                lib = 0
                for dr, dc in [(1,0),(-1,0),(0,1),(0,-1)]:
                    nr, nc = r+dr, c+dc
                    if 0 <= nr < size and 0 <= nc < size:
                        if board[nr, nc] == 0:
                            lib += 1
                liberties[r, c] = lib

    max_lib = 8
    planes = []
    for i in range(max_lib):
        mask = (liberties >= i) & (liberties < i + 1) & (board != 0)
        planes.append(mask.astype(np.float32))
    return np.stack(planes, axis=0)


def get_capture_size(state):
    """
    Encodes number of opponent stones that would be captured by playing at each empty point.
    Simplified: 0 for all positions.
    """
    size = state.board.shape[0]
    return np.zeros((1, size, size), dtype=np.float32)


def get_self_atari_size(state):
    """
    Encodes size of player's own group that would be put into atari by playing at each empty point.
    Simplified: 0 for all positions.
    """
    size = state.board.shape[0]
    return np.zeros((1, size, size), dtype=np.float32)


def get_liberties_after(state):
    """
    Encodes liberties after a move is played at each empty point.
    Simplified: 0 for all positions.
    """
    size = state.board.shape[0]
    return np.zeros((1, size, size), dtype=np.float32)


def get_ladder_capture(state):
    """
    Flags positions that are part of a ladder capture scenario.
    Simplified: 0 for all positions.
    """
    size = state.board.shape[0]
    return np.zeros((1, size, size), dtype=np.float32)


def get_ladder_escape(state):
    """
    Flags positions that are part of a ladder escape scenario.
    Simplified: 0 for all positions.
    """
    size = state.board.shape[0]
    return np.zeros((1, size, size), dtype=np.float32)


def get_sensibleness(state):
    """
    Encodes whether a move is 'sensible' (avoiding self-eyes).
    Simplified: 0 for all positions.
    """
    size = state.board.shape[0]
    return np.zeros((1, size, size), dtype=np.float32)


def get_legal(state):
    """
    Encodes legality of moves: 1 for legal empty points, 0 otherwise.
    Simplified: all empty points are legal.
    """
    board = state.board
    legal = (board == 0).astype(np.float32)
    return np.expand_dims(legal, axis=0)


# Mapping of feature names to (function, number of output planes)
FEATURES = {
    "board": (get_board, 3),
    "turns_since": (get_turns_since, 8),
    "liberties": (get_liberties, 8),
    "capture_size": (get_capture_size, 1),
    "self_atari_size": (get_self_atari_size, 1),
    "liberties_after": (get_liberties_after, 1),
    "ladder_capture": (get_ladder_capture, 1),
    "ladder_escape": (get_ladder_escape, 1),
    "sensibleness": (get_sensibleness, 1),
    "legal": (get_legal, 1),
}

DEFAULT_FEATURES = [
    "board",
    "turns_since",
    "liberties",
    "legal",
]

class Preprocess:
    def __init__(self, feature_names=None):
        if feature_names is None:
            feature_names = DEFAULT_FEATURES
        self.feature_names = feature_names
        self.feature_funcs = []
        self.total_planes = 0
        for name in self.feature_names:
            func, planes = FEATURES[name]
            self.feature_funcs.append(func)
            self.total_planes += planes

    def state_to_tensor(self, state):
        """
        Convert a game state into a tensor of shape
        (1, total_planes, board_size, board_size)
        """
        tensors = []
        for func in self.feature_funcs:
            tensors.append(func(state))
        concatenated = np.concatenate(tensors, axis=0)
        return np.expand_dims(concatenated, axis=0)
