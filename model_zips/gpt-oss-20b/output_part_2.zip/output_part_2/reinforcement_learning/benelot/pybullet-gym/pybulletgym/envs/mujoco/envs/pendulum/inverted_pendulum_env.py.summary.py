import numpy as np
import pybullet as p
from pybullet_envs.bullet.bullet_utils import BaseBulletEnv
from pybullet_envs.bullet.inverted_pendulum import InvertedPendulum
from pybullet_utils.mjcf_utils import SingleRobotEmptyScene


class InvertedPendulumMuJoCoEnv(BaseBulletEnv):
    def __init__(self, *args, **kwargs):
        robot = InvertedPendulum()
        super().__init__(robot=robot, *args, **kwargs)
        self.stateId = -1

    def create_single_player_scene(self):
        return SingleRobotEmptyScene(
            gravity=9.8,
            timestep=0.0165,
            frame_skip=1,
        )

    def reset(self, *args, **kwargs):
        if self.stateId >= 0:
            self._p.restoreState(self.stateId)
        obs = super().reset(*args, **kwargs)
        if self.stateId < 0:
            self.stateId = self._p.saveState()
        return obs

    def step(self, a):
        self.apply_action(a)
        self.scene.global_step()
        state = self.calc_state()
        reward = 1.0
        done = (
            not np.all(np.isfinite(state))
            or abs(state[1]) > 0.2
        )
        return state, reward, done, {}

    def apply_action(self, a):
        self.robot.apply_action(a)

    def calc_state(self):
        pos = self.robot.get_position()
        vel = self.robot.get_velocity()
        self.state = np.concatenate([pos, vel])
        return self.state

    def camera_adjust(self):
        cam_pos = [0, 1.2, 1.0]
        cam_target = [0, 0, 0.5]
        self._p.resetDebugVisualizerCamera(
            distance=2.0,
            yaw=0,
            pitch=-30,
            targetPosition=cam_target
        )