import numpy as np
from dataclasses import dataclass
from typing import Any, Optional

@dataclass
class Describe:
    count: int
    mean: Any
    std: Any
    min: Any
    max: Any
    repr_indent: str = ''
    repr_prefix: str = ''

    def __repr__(self) -> str:
        indent = '\t' * int(self.repr_indent) if isinstance(self.repr_indent, int) else self.repr_indent
        lines = [
            f"{self.repr_prefix}{indent}count: {self.count}",
            f"{self.repr_prefix}{indent}mean: {self.mean}",
            f"{self.repr_prefix}{indent}std: {self.std}",
            f"{self.repr_prefix}{indent}min: {self.min}",
            f"{self.repr_prefix}{indent}max: {self.max}"
        ]
        return '\n'.join(lines)

def describe(
    x: Any,
    axis: int = -1,
    repr_indent: str = '',
    repr_prefix: str = ''
) -> Optional[Describe]:
    if x is None or np.size(x) == 0:
        return None

    arr = np.asarray(x)

    if arr.ndim == 0:
        count = 1
    else:
        count = arr.shape[-1]

    mean = np.mean(arr, axis=axis)
    std = np.std(arr, axis=axis)
    minimum = np.min(arr, axis=axis)
    maximum = np.max(arr, axis=axis)

    return Describe(
        count=count,
        mean=mean,
        std=std,
        min=minimum,
        max=maximum,
        repr_indent=repr_indent,
        repr_prefix=repr_prefix
    )