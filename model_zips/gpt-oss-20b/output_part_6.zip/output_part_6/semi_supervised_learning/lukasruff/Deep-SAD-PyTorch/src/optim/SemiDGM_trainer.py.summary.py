import time
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import DataLoader
from sklearn.metrics import roc_auc_score

# ----------------------------
# Dummy dataset placeholder
# ----------------------------
class DummyDataset(torch.utils.data.Dataset):
    def __init__(self, num_samples=1000, num_features=20, num_classes=2):
        self.data = torch.randn(num_samples, num_features)
        self.labels = torch.randint(0, num_classes, (num_samples,))
        # semi-supervised mask: 0 for unlabeled, 1 for labeled
        self.semi_targets = torch.randint(0, 2, (num_samples,))

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return {
            "x": self.data[idx],
            "y": self.labels[idx],
            "semi": self.semi_targets[idx]
        }

# ----------------------------
# Simple autoencoder + classifier
# ----------------------------
class Net(nn.Module):
    def __init__(self, input_dim, latent_dim, num_classes):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 64),
            nn.ReLU(),
            nn.Linear(64, latent_dim)
        )
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, 64),
            nn.ReLU(),
            nn.Linear(64, input_dim),
            nn.Sigmoid()
        )
        self.classifier = nn.Linear(latent_dim, num_classes)

    def forward(self, x):
        z = self.encoder(x)
        recon = self.decoder(z)
        logits = self.classifier(z)
        return recon, logits

# ----------------------------
# Trainer
# ----------------------------
class SemiSupervisedTrainer:
    def __init__(
        self,
        net,
        train_loader,
        test_loader,
        alpha=0.1,
        lr=1e-3,
        weight_decay=0.0,
        epochs=10,
        lr_milestones=[5],
        device=None,
        num_workers=4
    ):
        self.net = net
        self.train_loader = train_loader
        self.test_loader = test_loader
        self.alpha = alpha
        self.epochs = epochs
        self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.net.to(self.device)

        self.optimizer = optim.Adam(self.net.parameters(), lr=lr, weight_decay=weight_decay)
        self.scheduler = optim.lr_scheduler.MultiStepLR(self.optimizer, milestones=lr_milestones, gamma=0.1)

        self.recon_criterion = nn.BCELoss(reduction="sum")
        self.class_criterion = nn.CrossEntropyLoss(reduction="sum")

    def _split_labeled_unlabeled(self, batch):
        x = batch["x"].to(self.device)
        y = batch["y"].to(self.device)
        semi = batch["semi"].to(self.device)
        mask = semi != 0
        x_labeled = x[mask]
        y_labeled = y[mask]
        x_unlabeled = x[~mask]
        return x_labeled, y_labeled, x_unlabeled

    def _elbo(self, x, y=None, labeled=True):
        recon, logits = self.net(x)
        recon_loss = self.recon_criterion(recon, x)
        if labeled:
            cls_loss = self.class_criterion(logits, y)
        else:
            cls_loss = torch.tensor(0.0, device=x.device)
        return recon_loss, cls_loss

    def train(self):
        train_start = time.perf_counter()
        for epoch in range(1, self.epochs + 1):
            self.net.train()
            epoch_loss = 0.0
            for batch in self.train_loader:
                self.optimizer.zero_grad()
                x_labeled, y_labeled, x_unlabeled = self._split_labeled_unlabeled(batch)

                # Labeled ELBO
                if x_labeled.size(0) > 0:
                    L_recon, L_cls = self._elbo(x_labeled, y_labeled, labeled=True)
                else:
                    L_recon, L_cls = torch.tensor(0.0, device=self.device), torch.tensor(0.0, device=self.device)

                # Unlabeled ELBO
                if x_unlabeled.size(0) > 0:
                    U_recon, _ = self._elbo(x_unlabeled, labeled=False)
                else:
                    U_recon = torch.tensor(0.0, device=self.device)

                loss = L_recon - self.alpha * L_cls + U_recon
                loss.backward()
                self.optimizer.step()

                epoch_loss += loss.item()
            self.scheduler.step()
            print(f"Epoch {epoch}/{self.epochs} - Loss: {epoch_loss / len(self.train_loader):.4f}")
        train_end = time.perf_counter()
        self.train_time = train_end - train_start

    def test(self):
        test_start = time.perf_counter()
        self.net.eval()
        all_scores = []
        all_labels = []
        total_loss = 0.0
        with torch.no_grad():
            for batch in self.test_loader:
                x = batch["x"].to(self.device)
                y = batch["y"].to(self.device)

                L_recon, L_cls = self._elbo(x, y, labeled=True)
                U_recon, _ = self._elbo(x, labeled=False)
                loss = L_recon + self.alpha * L_cls + U_recon
                total_loss += loss.item()

                # anomaly score from classifier's outlier logit (index 1)
                _, logits = self.net(x)
                scores = logits[:, 1].cpu().numpy()
                all_scores.append(scores)
                all_labels.append(y.cpu().numpy())
        test_end = time.perf_counter()
        self.test_time = test_end - test_start

        avg_test_loss = total_loss / len(self.test_loader)
        scores = np.concatenate(all_scores)
        labels = np.concatenate(all_labels)
        auc = roc_auc_score(labels, scores)
        print(f"Test Loss: {avg_test_loss:.4f} | AUC: {auc:.4f}")
        return auc

    def run(self):
        self.train()
        auc = self.test()
        return {
            "train_time": self.train_time,
            "test_time": self.test_time,
            "auc": auc
        }

# ----------------------------
# Usage example
# ----------------------------
if __name__ == "__main__":
    import numpy as np

    # Create dataset and loaders
    train_dataset = DummyDataset(num_samples=5000)
    test_dataset = DummyDataset(num_samples=1000)
    train_loader = DataLoader(train_dataset, batch_size=128, shuffle=True, num_workers=4)
    test_loader = DataLoader(test_dataset, batch_size=128, shuffle=False, num_workers=4)

    # Instantiate network
    net = Net(input_dim=20, latent_dim=10, num_classes=2)

    # Train and evaluate
    trainer = SemiSupervisedTrainer(
        net=net,
        train_loader=train_loader,
        test_loader=test_loader,
        alpha=0.1,
        lr=1e-3,
        weight_decay=1e-5,
        epochs=20,
        lr_milestones=[10, 15],
        num_workers=4
    )
    results = trainer.run()
    print(results)