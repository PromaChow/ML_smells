import torch
import torch.nn as nn
import torch.nn.functional as F


class DotAttention(nn.Module):
    def __init__(self, hidden_size: int):
        super().__init__()
        self.hidden_size = hidden_size

    def forward(self, lstm_out: torch.Tensor, hidden: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """
        lstm_out: [batch, seq_len, hidden_size]
        hidden:   [batch, hidden_size]
        """
        # Compute scores via dot product
        scores = torch.bmm(lstm_out, hidden.unsqueeze(2)).squeeze(2)  # [batch, seq_len]
        attn_weights = F.softmax(scores, dim=1)  # [batch, seq_len]
        context = torch.bmm(attn_weights.unsqueeze(1), lstm_out).squeeze(1)  # [batch, hidden_size]
        return context, attn_weights


class SoftAttention(nn.Module):
    def __init__(self, hidden_size: int):
        super().__init__()
        self.hidden_size = hidden_size
        self.W = nn.Linear(hidden_size, hidden_size, bias=False)
        self.U = nn.Linear(hidden_size, hidden_size, bias=False)
        self.v = nn.Linear(hidden_size, 1, bias=False)

    def forward(self, lstm_out: torch.Tensor, hidden: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """
        lstm_out: [batch, seq_len, hidden_size]
        hidden:   [batch, hidden_size]  (ignored in soft attention but kept for API consistency)
        """
        # Compute attention scores
        scores = self.v(torch.tanh(self.W(lstm_out) + self.U(hidden).unsqueeze(1))).squeeze(-1)  # [batch, seq_len]
        attn_weights = F.softmax(scores, dim=1)  # [batch, seq_len]
        context = torch.bmm(attn_weights.unsqueeze(1), lstm_out).squeeze(1)  # [batch, hidden_size]
        return context, attn_weights


class LSTM_Classifier(nn.Module):
    def __init__(self, inp_size: int, hidden_size: int, n_classes: int):
        super().__init__()
        self.lstm = nn.LSTM(
            input_size=inp_size,
            hidden_size=hidden_size,
            batch_first=True,
        )
        self.classifier = nn.Linear(hidden_size, n_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        x: [batch, time, features]
        """
        # Transpose to [batch, features, time]
        x = x.transpose(1, 2)
        lstm_out, _ = self.lstm(x)  # lstm_out: [batch, seq_len, hidden_size]
        final_hidden = lstm_out[:, -1, :]  # [batch, hidden_size]
        logits = self.classifier(final_hidden)  # [batch, n_classes]
        return logits


class LSTM_Attn_Classifier(nn.Module):
    def __init__(
        self,
        inp_size: int,
        hidden_size: int,
        n_classes: int,
        attn_type: str = "dot",
        return_attn_weights: bool = False,
    ):
        super().__init__()
        self.lstm = nn.LSTM(
            input_size=inp_size,
            hidden_size=hidden_size,
            batch_first=True,
        )
        if attn_type == "dot":
            self.attention = DotAttention(hidden_size)
        elif attn_type == "soft":
            self.attention = SoftAttention(hidden_size)
        else:
            raise ValueError(f"Unsupported attention type: {attn_type}")
        self.classifier = nn.Linear(hidden_size, n_classes)
        self.return_attn_weights = return_attn_weights

    def forward(self, x: torch.Tensor) -> torch.Tensor | tuple[torch.Tensor, torch.Tensor]:
        """
        x: [batch, time, features]
        """
        x = x.transpose(1, 2)
        lstm_out, (hn, _) = self.lstm(x)  # lstm_out: [batch, seq_len, hidden_size]
        hidden = hn.squeeze(0)  # [batch, hidden_size]
        attn_output, attn_weights = self.attention(lstm_out, hidden)
        logits = self.classifier(attn_output)
        if self.return_attn_weights:
            return logits, attn_weights
        return logits
