import networkx as nx
import numpy as np
import pylab

# Graph definition
points_list = [(0, 1), (1, 5), (5, 6), (5, 4), (1, 2), (2, 3), (2, 7)]
goal_node = 7
node_labels = {i: str(i) for i in range(8)}

G = nx.Graph()
G.add_nodes_from(range(8))
G.add_edges_from(points_list)

# Visualize the graph
pos = nx.spring_layout(G)
nx.draw(G, pos, with_labels=True, labels=node_labels,
        node_color='green', edge_color='blue', node_size=500, font_color='white')
pylab.title("Graph")
pylab.show()

# Reward matrix initialization
R = -np.ones((8, 8), dtype=int)
for src, dst in points_list:
    if dst == goal_node:
        R[src, dst] = 150
    elif src == goal_node:
        R[dst, src] = 150
    else:
        R[src, dst] = 0
        R[dst, src] = 0  # ensure symmetry
R[goal_node, goal_node] = 150

# Q-learning setup
Q = np.zeros((8, 8), dtype=int)
gamma = 0.8
initial_state = 1

def available_actions(state):
    return np.where(R[state, :] >= 0)[0]

def sample_next_action(actions):
    return np.random.choice(actions)

def update(current_state, action, gamma):
    max_future = np.max(Q[action, :])
    Q[current_state, action] = R[current_state, action] + gamma * max_future
    if max_future > 0:
        normalized = Q / Q.max() * 100 if Q.max() != 0 else Q
        return normalized
    return None

scores = []
for i in range(700):
    state = np.random.randint(0, 8)
    actions = available_actions(state)
    if actions.size == 0:
        continue
    action = sample_next_action(actions)
    result = update(state, action, gamma)
    if result is not None:
        scores.append(result.copy())
    else:
        scores.append(Q.copy())
    print(f"Iteration {i+1}, State {state}, Action {action}, Q updated")

# Path testing after training
current = 0
path = [current]
while current != goal_node:
    next_state = np.argmax(Q[current, :])
    path.append(next_state)
    current = next_state
print("Optimal path:", path)

# Visualization of training progress
pylab.figure()
pylab.plot(np.arange(1, 701), [np.mean(s) for s in scores])
pylab.title("Average Normalized Q over Iterations")
pylab.xlabel("Iteration")
pylab.ylabel("Average Normalized Q")
pylab.show()