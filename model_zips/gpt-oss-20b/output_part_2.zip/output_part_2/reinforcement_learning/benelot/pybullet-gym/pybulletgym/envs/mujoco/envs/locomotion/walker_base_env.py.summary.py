import pybullet as p
import pybullet_data
import numpy as np

class BaseBulletEnv:
    def __init__(self, robot, render=False):
        self.robot = robot
        self.render = render
        self.physics_client = p.connect(p.GUI if render else p.DIRECT)
        p.setAdditionalSearchPath(pybullet_data.getDataPath(), physicsClientId=self.physics_client)
        self.frame_skip = 4
        self.timestep = 0.0165 / self.frame_skip
        p.setTimeStep(self.timestep, physicsClientId=self.physics_client)
        self.floor_id = None

    def _reset(self):
        p.resetSimulation(physicsClientId=self.physics_client)
        p.setGravity(0, 0, -9.8, physicsClientId=self.physics_client)
        self.floor_id = p.loadURDF("plane.urdf", physicsClientId=self.physics_client)
        self.robot.reset(self.physics_client)

    def global_step(self):
        for _ in range(self.frame_skip):
            p.stepSimulation(physicsClientId=self.physics_client)

    def addToScene(self, body_id):
        pass

class StadiumScene:
    def __init__(self, physics_client, gravity=9.8, timestep=0.0165/4, frame_skip=4):
        self.physics_client = physics_client
        p.setGravity(0, 0, -gravity, physicsClientId=physics_client)
        p.setTimeStep(timestep, physicsClientId=physics_client)
        self.frame_skip = frame_skip

class DummyRobot:
    def __init__(self, urdf_path):
        self.urdf_path = urdf_path
        self.id = None
        self.base_link_index = 0
        self.joint_limits = [(-1.57, 1.57) for _ in range(12)]  # example limits
        self.num_joints = 12

    def reset(self, physics_client):
        if self.id is not None:
            p.removeBody(self.id, physicsClientId=physics_client)
        self.id = p.loadURDF(self.urdf_path, [0, 0, 0.5], physicsClientId=physics_client)
        p.resetBasePositionAndOrientation(self.id, [0, 0, 0.5], [0, 0, 0, 1], physicsClientId=physics_client)

    def apply_action(self, action, physics_client):
        for i in range(self.num_joints):
            p.setJointMotorControl2(bodyIndex=self.id,
                                    jointIndex=i,
                                    controlMode=p.TORQUE_CONTROL,
                                    force=action[i],
                                    physicsClientId=physics_client)

    def get_joint_states(self, physics_client):
        return p.getJointStates(self.id, range(self.num_joints), physicsClientId=physics_client)

    def get_base_position_and_orientation(self, physics_client):
        return p.getBasePositionAndOrientation(self.id, physicsClientId=physics_client)

class WalkerBaseMuJoCoEnv(BaseBulletEnv):
    def __init__(self, robot, render=False):
        super().__init__(robot, render)
        self.camera_x = 0.0
        self.walk_target_x = 0.0
        self.stateId = None
        self.scene = StadiumScene(self.physics_client, gravity=9.8, timestep=0.0165/4, frame_skip=4)

    def create_single_player_scene(self):
        # Scene already created in __init__ via StadiumScene
        pass

    def reset(self):
        if self.stateId is not None:
            p.restoreState(self.stateId, physicsClientId=self.physics_client)
        self._reset()
        p.configureDebugVisualizer(p.COV_ENABLE_RENDERING, 0, physicsClientId=self.physics_client)
        self.robot.reset(self.physics_client)
        p.configureDebugVisualizer(p.COV_ENABLE_RENDERING, 1, physicsClientId=self.physics_client)
        if self.stateId is None:
            self.stateId = p.saveState(physicsClientId=self.physics_client)
        return self.calc_state()

    def move_robot(self, position):
        p.resetBasePositionAndOrientation(self.robot.id, position, [0, 0, 0, 1], physicsClientId=self.physics_client)

    def calc_state(self):
        joint_states = self.robot.get_joint_states(self.physics_client)
        joint_positions = [state[0] for state in joint_states]
        joint_velocities = [state[1] for state in joint_states]
        base_pos, base_ori = self.robot.get_base_position_and_orientation(self.physics_client)
        base_vel, base_ang_vel = p.getBaseVelocity(self.robot.id, physicsClientId=self.physics_client)
        return np.concatenate([base_pos, base_ori, joint_positions, joint_velocities, base_vel, base_ang_vel])

    def step(self, action):
        self.robot.apply_action(action, self.physics_client)
        self.global_step()
        state = self.calc_state()
        base_pos, base_ori = self.robot.get_base_position_and_orientation(self.physics_client)
        _, _, _, _, _, _ = state
        _, _, _, _, _, _ = state
        # Alive check
        height = base_pos[2]
        _, _, _, pitch, _, _ = p.getEulerFromQuaternion(base_ori)
        alive_bonus = 1.0 if height > 0.7 and abs(pitch) < 0.1 else 0.0
        done = alive_bonus == 0.0
        # Progress reward (using potential energy difference)
        mass = p.getDynamicsInfo(self.robot.id, -1, physicsClientId=self.physics_client)[0]
        potential_energy = mass * 9.8 * height
        # For simplicity, assume previous potential energy stored in self.prev_potential
        if hasattr(self, 'prev_potential'):
            progress = potential_energy - self.prev_potential
        else:
            progress = 0.0
        self.prev_potential = potential_energy
        # Foot collision cost
        foot_collision_cost = 0.0
        contacts = p.getContactPoints(bodyA=self.robot.id, bodyB=self.floor_id, physicsClientId=self.physics_client)
        for contact in contacts:
            link_index = contact[3]
            if link_index in self.robot.joint_limits:  # treat all links as feet for demo
                foot_collision_cost += 1.0
        foot_collision_cost = -foot_collision_cost
        # Joint limit penalty
        joint_states = self.robot.get_joint_states(self.physics_client)
        joints_at_limit_cost = 0.0
        for i, (pos, _) in enumerate(joint_states):
            lower, upper = self.robot.joint_limits[i]
            if pos <= lower or pos >= upper:
                joints_at_limit_cost -= 0.01
        # Aggregate rewards
        rewards = [alive_bonus, progress, joints_at_limit_cost, foot_collision_cost]
        reward = sum(rewards)
        info = {"alive": alive_bonus, "progress": progress, "joints_at_limit_cost": joints_at_limit_cost,
                "feet_collision_cost": foot_collision_cost}
        return state, reward, done, info

    def camera_adjust(self):
        base_pos, _ = self.robot.get_base_position_and_orientation(self.physics_client)
        target_x = base_pos[0]
        self.camera_x += 0.05 * (target_x - self.camera_x)
        p.resetDebugVisualizerCamera(cameraDistance=1.5,
                                     cameraYaw=0,
                                     cameraPitch=-30,
                                     cameraTargetPosition=[self.camera_x, 0, 0.5],
                                     physicsClientId=self.physics_client)