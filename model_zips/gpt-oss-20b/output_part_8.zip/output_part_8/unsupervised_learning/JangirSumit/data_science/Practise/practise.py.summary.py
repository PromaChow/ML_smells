import pandas as pd

# Load the dataset
df = pd.read_csv("Practise/BostonHousing.csv")

# Select the first two rows and first two columns using integer-based indexing
subset = df.iloc[0:2, 0:2]

# Print the selected subset
print(subset)