import argparse
import json
import logging
import os
import random
import sys
from pathlib import Path

import gym
import numpy as np
import torch
import torch.nn as nn
from torch import optim
from torchrl.data import ReplayBuffer
from torchrl.envs import wrap_deepmind
from torchrl.modules import (
    DQN,
    DiscreteActionValue,
    Linear,
    NatureDQNHead,
    RMSpropGraves,
)
from torchrl.utils import set_seed
from torchviz import make_dot

# --------------------------------------------------------------------------- #
# Helper wrappers and utilities
# --------------------------------------------------------------------------- #
class ActionRandomization(gym.Wrapper):
    def __init__(self, env, seed=None):
        super().__init__(env)
        self.seed = seed

    def reset(self, **kwargs):
        observation = self.env.reset(**kwargs)
        return observation

    def step(self, action):
        return self.env.step(action)


def make_env(env_id, seed, eval_mode=False, render=False, monitor=False):
    env = gym.make(env_id)
    env.seed(seed)
    env.action_space.seed(seed)
    env.observation_space.seed(seed)
    env = wrap_deepmind(
        env,
        frame_stack=4,
        episode_life=not eval_mode,
        clip_rewards=not eval_mode,
        frame_skip=4,
    )
    if monitor:
        env = gym.wrappers.Monitor(
            env, str(Path("monitor") / f"{env_id}_{seed}"), force=True
        )
    if render:
        env = ActionRandomization(env, seed)
    return env


def phi(state):
    return np.asarray(state, dtype=np.float32) / 255.0


def save_graph(model, output_dir):
    dummy_input = torch.zeros(1, 4, 84, 84)
    dot = make_dot(model(dummy_input), params=dict(model.named_parameters()))
    dot.format = "png"
    dot.render(output_dir / "q_network", cleanup=True)


def load_pretrained(model, path_or_name):
    if os.path.isfile(path_or_name):
        state_dict = torch.load(path_or_name, map_location="cpu")
    else:
        # Placeholder for a download function
        state_dict = {}  # implement download logic if needed
    model.load_state_dict(state_dict, strict=False)
    return model


# --------------------------------------------------------------------------- #
# Argument parsing
# --------------------------------------------------------------------------- #
def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--env", default="PongNoFrameskip-v4")
    parser.add_argument("--output_dir", default="results")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--gpu", action="store_true")
    parser.add_argument("--demo", action="store_true")
    parser.add_argument("--pretrained", default=None)
    parser.add_argument("--log_level", default="INFO")
    parser.add_argument("--render", action="store_true")
    parser.add_argument("--monitor", action="store_true")
    parser.add_argument("--steps", type=int, default=1_000_000)
    parser.add_argument("--buffer_size", type=int, default=1_000_000)
    parser.add_argument("--eval_interval", type=int, default=50_000)
    parser.add_argument("--eval_n_steps", type=int, default=10_000)
    parser.add_argument("--n_best_episodes", type=int, default=10)
    parser.add_argument("--best_model_name", default="best.pt")
    parser.add_argument("--final_model_name", default="final.pt")
    args = parser.parse_args()
    return args


# --------------------------------------------------------------------------- #
# Main training and evaluation
# --------------------------------------------------------------------------- #
def main():
    args = parse_args()

    logging.basicConfig(
        level=getattr(logging, args.log_level.upper(), logging.INFO),
        format="[%(levelname)s] %(message)s",
    )
    log = logging.getLogger("dqn_atari")

    device = torch.device("cuda" if args.gpu and torch.cuda.is_available() else "cpu")
    log.info(f"Using device: {device}")

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Set seeds
    set_seed(args.seed, torch=True, numpy=True, python=True)

    # Environments
    train_env = make_env(
        args.env,
        seed=args.seed,
        eval_mode=False,
        render=args.render,
        monitor=args.monitor,
    )
    eval_env = make_env(
        args.env,
        seed=args.seed + 1,
        eval_mode=True,
        render=False,
        monitor=args.monitor,
    )

    n_actions = train_env.action_space.n
    obs_space = train_env.observation_space

    # Q-network
    q_network = nn.Sequential(
        NatureDQNHead(
            in_channels=4,
            channels=32,
            kernels=[8, 4, 3],
            strides=[4, 2, 1],
            paddings=[0, 0, 0],
            features=[128, 256, 256],
        ),
        nn.Linear(256 * 7 * 7, 512),
        nn.ReLU(),
        nn.Linear(512, n_actions),
        DiscreteActionValue(),
    ).to(device)

    save_graph(q_network, output_dir)

    # Optimizer
    optimizer = RMSpropGraves(
        q_network.parameters(),
        lr=2.5e-4,
        alpha=0.95,
        eps=1e-2,
    )

    # Replay buffer
    buffer = ReplayBuffer(capacity=args.buffer_size, device=device)

    # Exploration strategy
    epsilon_start = 1.0
    epsilon_final = 0.1
    epsilon_decay = 1_000_000

    def epsilon(step):
        frac = min(1.0, step / epsilon_decay)
        return epsilon_start + frac * (epsilon_final - epsilon_start)

    # Agent configuration
    gamma = 0.99
    target_update_interval = 10_000
    batch_size = 32

    best_reward = -float("inf")
    best_model_path = output_dir / args.best_model_name

    if args.pretrained:
        load_pretrained(q_network, args.pretrained)

    state = train_env.reset()
    state = phi(state)
    episode_reward = 0
    episode_step = 0
    step = 0

    if args.demo:
        log.info("Running demo mode")
        rewards = []
        for _ in range(args.n_best_episodes):
            env = eval_env
            obs = phi(env.reset())
            done = False
            total = 0
            while not done and episode_step < 4500:
                with torch.no_grad():
                    logits = q_network(torch.tensor(obs, device=device).unsqueeze(0))
                    action = logits.argmax().item()
                obs, r, done, _ = env.step(action)
                obs = phi(obs)
                total += r
                episode_step += 1
            rewards.append(total)
        log.info(
            f"Demo results - mean: {np.mean(rewards):.2f}, median: {np.median(rewards):.2f}, std: {np.std(rewards):.2f}"
        )
        return

    log.info("Starting training")
    while step < args.steps:
        # Epsilon-greedy action selection
        if random.random() < epsilon(step):
            action = train_env.action_space.sample()
        else:
            with torch.no_grad():
                logits = q_network(torch.tensor(state, device=device).unsqueeze(0))
                action = logits.argmax().item()

        next_state, reward, done, _ = train_env.step(action)
        next_state = phi(next_state)
        buffer.add(
            torch.tensor(state, device=device),
            torch.tensor(action, device=device),
            torch.tensor(reward, device=device),
            torch.tensor(done, device=device),
            torch.tensor(next_state, device=device),
        )
        state = next_state
        episode_reward += reward
        episode_step += 1
        step += 1

        if done:
            state = phi(train_env.reset())
            episode_reward = 0
            episode_step = 0

        # Training step
        if len(buffer) >= batch_size:
            batch = buffer.sample(batch_size)
            states = batch["states"]
            actions = batch["actions"].unsqueeze(1)
            rewards = batch["rewards"].unsqueeze(1)
            dones = batch["dones"].unsqueeze(1)
            next_states = batch["next_states"]

            q_values = q_network(states).gather(1, actions)
            with torch.no_grad():
                next_q_values = q_network(next_states).max(1, keepdim=True)[0]
                target = rewards + gamma * next_q_values * (1 - dones)
            loss = nn.functional.smooth_l1_loss(q_values, target)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        # Target network update
        if step % target_update_interval == 0:
            q_network.load_state_dict(q_network.state_dict())

        # Evaluation
        if step % args.eval_interval == 0 and step > 0:
            eval_rewards = []
            for _ in range(5):
                env = eval_env
                obs = phi(env.reset())
                done = False
                total = 0
                while not done:
                    with torch.no_grad():
                        logits = q_network(torch.tensor(obs, device=device).unsqueeze(0))
                        action = logits.argmax().item()
                    obs, r, done, _ = env.step(action)
                    obs = phi(obs)
                    total += r
                eval_rewards.append(total)
            mean_reward = np.mean(eval_rewards)
            log.info(f"Step {step}: Eval mean reward: {mean_reward:.2f}")
            if mean_reward > best_reward:
                best_reward = mean_reward
                torch.save(q_network.state_dict(), best_model_path)
                log.info(f"New best model saved with reward {best_reward:.2f}")

    # Post-training evaluation
    q_network.load_state_dict(torch.load(best_model_path))
    eval_rewards = []
    for _ in range(args.n_best_episodes):
        env = eval_env
        obs = phi(env.reset())
        done = False
        total = 0
        step_count = 0
        while not done and step_count < 4500:
            with torch.no_grad():
                logits = q_network(torch.tensor(obs, device=device).unsqueeze(0))
                action = logits.argmax().item()
            obs, r, done, _ = env.step(action)
            obs = phi(obs)
            total += r
            step_count += 1
        eval_rewards.append(total)

    stats = {
        "mean": float(np.mean(eval_rewards)),
        "median": float(np.median(eval_rewards)),
        "std": float(np.std(eval_rewards)),
    }
    with open(output_dir / "evaluation_stats.json", "w") as f:
        json.dump(stats, f, indent=4)
    log.info(f"Final evaluation stats: {stats}")


if __name__ == "__main__":
    main()
