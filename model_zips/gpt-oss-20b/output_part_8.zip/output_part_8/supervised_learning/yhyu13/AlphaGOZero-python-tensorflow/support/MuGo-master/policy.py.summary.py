import os
import numpy as np
import tensorflow as tf
import features  # Assumes features.py defines DEFAULT_FEATURES and extract_features

tf.compat.v1.disable_eager_execution()


class StatisticsCollector:
    def __init__(self):
        self.total_loss = 0.0
        self.total_accuracy = 0.0
        self.count = 0

    def update(self, loss, accuracy):
        self.total_loss += loss
        self.total_accuracy += accuracy
        self.count += 1

    def average(self):
        if self.count == 0:
            return 0.0, 0.0
        return self.total_loss / self.count, self.total_accuracy / self.count

    def reset(self):
        self.total_loss = 0.0
        self.total_accuracy = 0.0
        self.count = 0


class GoDNN:
    def __init__(
        self,
        board_size=19,
        layer_width=128,
        batch_size=64,
        log_dir="./logs",
        checkpoint_dir="./checkpoints",
        use_cpu=False,
    ):
        self.board_size = board_size
        self.k = layer_width
        self.batch_size = batch_size
        self.log_dir = log_dir
        self.checkpoint_dir = checkpoint_dir
        self.use_cpu = use_cpu

        self.num_input_planes = len(features.DEFAULT_FEATURES)
        self.global_step = tf.compat.v1.Variable(0, trainable=False, name="global_step")

        self._build_graph()
        self.sess = tf.compat.v1.Session()
        self.saver = tf.compat.v1.train.Saver(max_to_keep=5)
        self.summary_writer = tf.compat.v1.summary.FileWriter(self.log_dir, self.sess.graph)

        self.sess.run(tf.compat.v1.global_variables_initializer())
        self.stats = StatisticsCollector()

    def _conv_layer(
        self,
        inputs,
        out_channels,
        kernel_size,
        stride=1,
        name="conv",
        activation=True,
        padding="SAME",
    ):
        in_channels = inputs.shape[-1].value
        kernel_shape = [kernel_size, kernel_size, in_channels, out_channels]
        num_inputs = in_channels * kernel_size * kernel_size
        stddev = 1.0 / np.sqrt(num_inputs)

        with tf.compat.v1.variable_scope(name):
            weight = tf.compat.v1.get_variable(
                "W",
                shape=kernel_shape,
                initializer=tf.truncated_normal_initializer(stddev=stddev),
            )
            bias = tf.compat.v1.get_variable(
                "b",
                shape=[out_channels],
                initializer=tf.zeros_initializer(),
            )
            conv = tf.nn.conv2d(
                inputs, weight, strides=[1, stride, stride, 1], padding=padding
            )
            conv = tf.nn.bias_add(conv, bias)
            if activation:
                conv = tf.nn.relu(conv)
        return conv

    def _resnet_block(self, inputs, name="resnet"):
        with tf.compat.v1.variable_scope(name):
            conv1 = self._conv_layer(inputs, self.k, 3, name="conv1")
            conv2 = self._conv_layer(conv1, self.k, 3, activation=False, name="conv2")
            out = tf.nn.relu(conv2 + inputs)
        return out

    def _build_graph(self):
        with tf.device("/cpu:0" if self.use_cpu else "/gpu:0"):
            self.input = tf.compat.v1.placeholder(
                tf.float32,
                shape=[None, self.board_size, self.board_size, self.num_input_planes],
                name="input",
            )
            self.labels = tf.compat.v1.placeholder(
                tf.float32,
                shape=[None, self.board_size * self.board_size],
                name="labels",
            )

            # Initial conv layers
            conv5 = self._conv_layer(
                self.input, self.k, 5, name="conv5x5", padding="SAME"
            )
            conv1 = self._conv_layer(conv5, self.k, 1, name="conv1x1", padding="SAME")

            # 11 ResNet blocks
            res = conv1
            for i in range(11):
                res = self._resnet_block(res, name=f"resnet_{i}")

            # Final 1x1 conv to 1 plane
            logits_1x1 = self._conv_layer(
                res, 1, 1, name="final_conv", activation=False, padding="SAME"
            )
            logits_flat = tf.reshape(logits_1x1, [-1, self.board_size * self.board_size])

            self.logits = logits_flat
            self.probabilities = tf.nn.softmax(logits_flat, name="probabilities")

            # Loss and optimizer
            cross_entropy = tf.nn.softmax_cross_entropy_with_logits(
                logits=logits_flat, labels=self.labels
            )
            self.loss = tf.reduce_mean(cross_entropy)

            learning_rate = tf.train.exponential_decay(
                learning_rate=1e-2,
                global_step=self.global_step,
                decay_steps=4_000_000,
                decay_rate=0.5,
                staircase=True,
            )
            optimizer = tf.train.GradientDescentOptimizer(learning_rate)
            self.train_step = optimizer.minimize(self.loss, global_step=self.global_step)

            # Reinforce step
            self.reinforce_direction = tf.compat.v1.placeholder(
                tf.float32, shape=[], name="reinforce_dir"
            )
            reinforce_loss = self.loss * self.reinforce_direction
            self.reinforce_step = optimizer.minimize(
                reinforce_loss, global_step=self.global_step
            )

            # Accuracy
            pred = tf.argmax(self.logits, axis=1)
            true = tf.argmax(self.labels, axis=1)
            correct = tf.equal(pred, true)
            self.accuracy = tf.reduce_mean(tf.cast(correct, tf.float32))

            # Summaries
            tf.compat.v1.summary.scalar("loss", self.loss)
            tf.compat.v1.summary.scalar("accuracy", self.accuracy)
            for var in tf.compat.v1.trainable_variables():
                tf.compat.v1.summary.histogram(var.name, var)
            self.summary_op = tf.compat.v1.summary.merge_all()

    def train_minibatch(self, inputs, labels, reinforce_dir=1.0):
        feed = {
            self.input: inputs,
            self.labels: labels,
            self.reinforce_direction: reinforce_dir,
        }
        loss, acc, _ = self.sess.run(
            [self.loss, self.accuracy, self.train_step], feed_dict=feed
        )
        self.stats.update(loss, acc)
        return loss, acc

    def reinforce_batch(self, inputs, labels, reinforce_dir):
        feed = {
            self.input: inputs,
            self.labels: labels,
            self.reinforce_direction: reinforce_dir,
        }
        loss, _ = self.sess.run(
            [self.loss, self.reinforce_step], feed_dict=feed
        )
        return loss

    def run(self, board_position):
        features_vec = features.extract_features(board_position, normalize=True)
        logits = self.sess.run(
            self.logits, feed_dict={self.input: np.expand_dims(features_vec, axis=0)}
        )
        probs = logits.reshape(self.board_size, self.board_size)
        return probs

    def run_many(self, board_positions):
        feats = np.array(
            [features.extract_features(b, normalize=True) for b in board_positions]
        )
        logits = self.sess.run(
            self.logits, feed_dict={self.input: feats}
        )
        probs = logits.reshape(len(board_positions), self.board_size, self.board_size)
        return probs

    def training_loop(self, data_loader, epochs=10, log_every=100):
        for epoch in range(epochs):
            for step, (batch_inputs, batch_labels) in enumerate(data_loader):
                loss, acc = self.train_minibatch(batch_inputs, batch_labels)
                if step % log_every == 0:
                    avg_loss, avg_acc = self.stats.average()
                    summary = self.sess.run(self.summary_op, feed_dict={self.input: batch_inputs, self.labels: batch_labels})
                    self.summary_writer.add_summary(summary, self.global_step.eval(self.sess))
                    self.summary_writer.flush()
                    print(
                        f"Epoch {epoch} Step {step}: Loss={avg_loss:.4f} Acc={avg_acc:.4f}"
                    )
                    self.stats.reset()

    def save(self, path=None):
        if path is None:
            path = os.path.join(self.checkpoint_dir, "model.ckpt")
        self.saver.save(self.sess, path, global_step=self.global_step)

    def restore(self, path):
        self.saver.restore(self.sess, path)


# Example placeholder for features module (to be replaced with actual implementation)
# -----------------------------------------------------------------------
# In a real project, this would be in a separate features.py file.

# class features:
#     DEFAULT_FEATURES = ['black', 'white', 'turn', 'komi']  # Example
#
#     @staticmethod
#     def extract_features(board_position, normalize=False):
#         # Convert board_position to feature planes
#         # This is a stub; real implementation required.
#         return np.random.rand(
#             board_position.shape[0],
#             board_position.shape[1],
#             len(features.DEFAULT_FEATURES)
#         )
```