import numpy as np
import copy
from dataclasses import dataclass, field
from typing import Any, Callable, Optional, Tuple, List
from graphviz import Digraph


def mean_squared_error(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    return np.mean((y_true - y_pred) ** 2)


@dataclass
class Node:
    model: Any = None
    loss: float = np.inf
    depth: int = 0
    feature: Optional[int] = None
    threshold: Optional[float] = None
    left: Optional["Node"] = None
    right: Optional["Node"] = None
    X: Optional[np.ndarray] = None
    y: Optional[np.ndarray] = None
    n_samples: int = 0


class ModelTree:
    def __init__(
        self,
        base_model: Any,
        max_depth: int = 3,
        min_samples_leaf: int = 10,
        search_type: str = "greedy",
        grid_resolution: int = 10,
        loss_func: Optional[Callable[[np.ndarray, np.ndarray], float]] = None,
    ):
        self.base_model = base_model
        self.max_depth = max_depth
        self.min_samples_leaf = min_samples_leaf
        self.search_type = search_type.lower()
        self.grid_resolution = grid_resolution
        self.loss_func = loss_func or mean_squared_error
        self.root: Optional[Node] = None

    # ----------------------------------------------------------------------
    # Model fitting utilities
    # ----------------------------------------------------------------------
    def _fit_model(self, X: np.ndarray, y: np.ndarray) -> Tuple[Any, float]:
        model = copy.deepcopy(self.base_model)
        model.fit(X, y)
        y_pred = model.predict(X)
        loss = self.loss_func(y, y_pred)
        return model, loss

    def _create_node(self, X: np.ndarray, y: np.ndarray, depth: int) -> Node:
        model, loss = self._fit_model(X, y)
        node = Node(
            model=model,
            loss=loss,
            depth=depth,
            X=X,
            y=y,
            n_samples=X.shape[0],
        )
        return node

    # ----------------------------------------------------------------------
    # Splitting logic
    # ----------------------------------------------------------------------
    def _splitter(self, node: Node) -> Tuple[Optional[int], Optional[float], Optional[float]]:
        best_feature = None
        best_threshold = None
        best_loss = None

        X, y = node.X, node.y
        n_samples, n_features = X.shape

        for feature_idx in range(n_features):
            feature_values = X[:, feature_idx]
            if self.search_type == "greedy":
                thresholds = np.unique(feature_values)
            else:  # grid search
                thresholds = np.linspace(
                    feature_values.min() + 1e-5,
                    feature_values.max() - 1e-5,
                    num=self.grid_resolution,
                )

            for threshold in thresholds:
                left_mask = feature_values <= threshold
                right_mask = feature_values > threshold

                if np.sum(left_mask) < self.min_samples_leaf or np.sum(right_mask) < self.min_samples_leaf:
                    continue

                X_left, y_left = X[left_mask], y[left_mask]
                X_right, y_right = X[right_mask], y[right_mask]

                model_left, loss_left = self._fit_model(X_left, y_left)
                model_right, loss_right = self._fit_model(X_right, y_right)

                weighted_loss = (
                    loss_left * X_left.shape[0] + loss_right * X_right.shape[0]
                ) / n_samples

                if best_loss is None or weighted_loss < best_loss:
                    best_loss = weighted_loss
                    best_feature = feature_idx
                    best_threshold = threshold

        return best_feature, best_threshold, best_loss

    def _split_traverse_node(self, node: Node):
        if node.depth >= self.max_depth or node.n_samples <= 2 * self.min_samples_leaf:
            return

        best_feature, best_threshold, best_loss = self._splitter(node)

        if best_feature is None:
            return

        if best_loss >= node.loss:
            return

        node.feature = best_feature
        node.threshold = best_threshold

        X, y = node.X, node.y
        feature_values = X[:, best_feature]
        left_mask = feature_values <= best_threshold
        right_mask = feature_values > best_threshold

        X_left, y_left = X[left_mask], y[left_mask]
        X_right, y_right = X[right_mask], y[right_mask]

        node.left = self._create_node(X_left, y_left, node.depth + 1)
        node.right = self._create_node(X_right, y_right, node.depth + 1)

        self._split_traverse_node(node.left)
        self._split_traverse_node(node.right)

    # ----------------------------------------------------------------------
    # Public API
    # ----------------------------------------------------------------------
    def fit(self, X: np.ndarray, y: np.ndarray):
        X, y = np.asarray(X), np.asarray(y)
        self.root = self._create_node(X, y, depth=0)
        self._split_traverse_node(self.root)

    def _traverse(self, node: Node, sample: np.ndarray) -> Any:
        if node.feature is None or node.left is None or node.right is None:
            return node.model.predict(sample.reshape(1, -1))[0]
        if sample[node.feature] <= node.threshold:
            return self._traverse(node.left, sample)
        else:
            return self._traverse(node.right, sample)

    def predict(self, X: np.ndarray) -> np.ndarray:
        if self.root is None:
            raise RuntimeError("ModelTree has not been fitted yet.")
        X = np.asarray(X)
        return np.array([self._traverse(self.root, x) for x in X])

    def explain(self, X: np.ndarray) -> List[str]:
        if self.root is None:
            raise RuntimeError("ModelTree has not been fitted yet.")
        explanations = []

        def _traverse(node: Node, sample: np.ndarray, path: List[str]):
            if node.feature is None or node.left is None or node.right is None:
                path.append(f"Leaf: model loss={node.loss:.4f}")
                explanations.append(" -> ".join(path))
                return
            if sample[node.feature] <= node.threshold:
                path.append(
                    f"[X[{node.feature}] <= {node.threshold:.4f}] (left)"
                )
                _traverse(node.left, sample, path)
            else:
                path.append(
                    f"[X[{node.feature}] > {node.threshold:.4f}] (right)"
                )
                _traverse(node.right, sample, path)

        X = np.asarray(X)
        for x in X:
            _traverse(self.root, x, [])
        return explanations

    def loss(self, y_true: np.ndarray, y_pred: np.ndarray) -> float:
        return self.loss_func(y_true, y_pred)

    # ----------------------------------------------------------------------
    # Visualization
    # ----------------------------------------------------------------------
    def export_graphviz(
        self,
        filename: str = "model_tree",
        format: str = "png",
        rankdir: str = "TB",
    ):
        if self.root is None:
            raise RuntimeError("ModelTree has not been fitted yet.")

        dot = Digraph(
            filename=filename,
            format=format,
            graph_attr={"rankdir": rankdir},
            node_attr={"shape": "box", "style": "filled"},
        )

        def _node_id(node: Node) -> str:
            return f"node_{id(node)}"

        def _add_node(node: Node):
            if node is None:
                return
            node_id = _node_id(node)
            label = f"n_samples={node.n_samples}\\nloss={node.loss:.4f}"
            if node.feature is not None:
                label += f"\\nX[{node.feature}] <= {node.threshold:.4f}"
            dot.node(node_id, label=label, fillcolor="lightblue")
            if node.left:
                _add_node(node.left)
                dot.edge(node_id, _node_id(node.left))
            if node.right:
                _add_node(node.right)
                dot.edge(node_id, _node_id(node.right))

        _add_node(self.root)
        dot.render(filename, cleanup=True)
        return dot
