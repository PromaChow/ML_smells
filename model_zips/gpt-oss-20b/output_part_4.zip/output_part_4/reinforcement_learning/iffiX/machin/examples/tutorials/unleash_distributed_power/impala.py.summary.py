import gym
import torch
import torch.nn as nn
import torch.optim as optim
import torch.distributed as dist
import torch.distributed.rpc as rpc
from torch.nn.parallel import DistributedDataParallel as DDP
from machin.agent.learner import IMPALA
from machin.utils.torch_utils import model_server_helper
import time

# Actor network
class Actor(nn.Module):
    def __init__(self, obs_dim, act_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim, 128),
            nn.ReLU(),
            nn.Linear(128, act_dim),
            nn.Softmax(dim=-1)
        )

    def forward(self, x):
        return self.net(x)

# Critic network
class Critic(nn.Module):
    def __init__(self, obs_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 1)
        )

    def forward(self, x):
        return self.net(x)

def worker(rank, world_size):
    # Initialize RPC
    rpc.init_rpc("impala", rank=rank, world_size=world_size)

    # Create learner group for ranks 2 and 3
    learner_group = None
    if rank in (2, 3):
        learner_group = dist.new_group([2, 3])

    # Environment dimensions
    env = gym.make("CartPole-v0")
    obs_dim = env.observation_space.shape[0]
    act_dim = env.action_space.n

    # Build networks
    actor = Actor(obs_dim, act_dim)
    critic = Critic(obs_dim)

    # Wrap in DDP if learner
    if learner_group is not None:
        actor = DDP(actor, device_ids=[0], process_group=learner_group)
        critic = DDP(critic, device_ids=[0], process_group=learner_group)

    # Optimizer and loss
    optimizer = optim.Adam(list(actor.parameters()) + list(critic.parameters()), lr=1e-4)
    loss_fn = nn.MSELoss()

    # Model servers
    model_servers = [model_server_helper()]

    # IMPALA trainer
    impala = IMPALA(
        actor,
        critic,
        optimizer,
        loss_fn,
        rpc_group=rpc.get_rpc_backend_options(),
        model_servers=model_servers,
        batch_size=2,
    )
    impala.set_sync(False)

    # Synchronize all processes
    dist.barrier()

    if rank in (0, 1):
        # Worker logic
        smoothed_reward = 0.0
        episode_rewards = []
        for episode in range(2000):
            state = env.reset()
            trajectory = []
            episode_reward = 0.0
            for step in range(200):
                impala.manual_sync()
                state_t = torch.tensor(state, dtype=torch.float32).unsqueeze(0)
                probs = actor(state_t)
                action = torch.multinomial(probs, 1).item()
                next_state, reward, done, _ = env.step(action)
                trajectory.append((state, action, reward, done))
                episode_reward += reward
                state = next_state
                if done:
                    break
            impala.add_episode(trajectory)
            episode_rewards.append(episode_reward)
            smoothed_reward = 0.9 * smoothed_reward + 0.1 * episode_reward
            if episode % 10 == 0:
                print(f"Rank {rank} Episode {episode} Reward {episode_reward:.2f} Smoothed {smoothed_reward:.2f}")
            if len(episode_rewards) >= 5 and all(r >= 190 for r in episode_rewards[-5:]):
                print(f"Rank {rank} solved at episode {episode}")
                break
    else:
        # Learner logic
        updates = 0
        while updates < 10000:
            if impala.replay_buffer_size() >= 5:
                impala.update()
                updates += 1
            else:
                time.sleep(0.1)

    rpc.shutdown()

if __name__ == "__main__":
    world_size = 4
    torch.multiprocessing.spawn(worker, args=(world_size,), nprocs=world_size, join=True)