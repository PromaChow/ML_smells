import os
import socket
import random
import time
import traceback
import logging
import multiprocessing
from logging.handlers import QueueHandler, QueueListener

# Optional imports for reproducibility if available
try:
    import torch
except ImportError:  # pragma: no cover
    torch = None

try:
    import numpy as np
except ImportError:  # pragma: no cover
    np = None

# ------------------ 1. Initialization and Configuration ------------------ #
class SafeExit(RuntimeError):
    """Exception used to signal safe termination of worker processes."""
    pass


def find_free_port() -> int:
    """Return an unused TCP port."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("0.0.0.0", 0))
        return s.getsockname()[1]


# ------------------ 2. Process Execution Setup ------------------ #
def _configure_logger(queue: multiprocessing.Queue, name: str) -> logging.Logger:
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    handler = QueueHandler(queue)
    logger.handlers = [handler]
    return logger


def _seed_randomness(seed: int, rank: int) -> None:
    random.seed(seed + rank)
    if np is not None:
        np.random.seed(seed + rank)
    if torch is not None:
        torch.manual_seed(seed + rank)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed + rank)


def process_main(conn, log_queue, seed, rank):
    logger = _configure_logger(log_queue, f"worker-{rank}")
    _seed_randomness(seed, rank)
    logger.info(f"Process {rank} started with seed {seed + rank}")

    try:
        while True:
            try:
                task = conn.recv()
            except EOFError:
                logger.info(f"Process {rank} received EOF")
                break

            if task is None:  # Sentinel for graceful exit
                logger.info(f"Process {rank} received exit signal")
                break

            func, args, kwargs = task
            try:
                result = func(*args, **kwargs)
                conn.send(("ok", result))
            except Exception as exc:
                tb = traceback.format_exc()
                conn.send(("exc", (exc, tb)))
    except SafeExit:
        logger.info(f"Process {rank} exiting via SafeExit")
    finally:
        conn.close()


# ------------------ 3. Multiprocessing Context Setup ------------------ #
def get_multiprocessing_context() -> multiprocessing.Context:
    method = "forkserver" if os.name != "nt" else "spawn"
    ctx = multiprocessing.get_context(method)
    # Preload optional libraries for performance
    if method == "forkserver":
        try:
            import machin  # noqa: F401
        except Exception:  # pragma: no cover
            pass
    return ctx


# ------------------ 4. Process Management Fixture ------------------ #
def start_processes(num_workers: int = 3):
    ctx = get_multiprocessing_context()
    log_queue = ctx.Queue()
    listener = QueueListener(log_queue, *[logging.StreamHandler()])
    listener.start()

    processes = []
    pipes = []

    seed = random.randint(0, 2**32 - 1)
    for rank in range(num_workers):
        parent_conn, child_conn = ctx.Pipe()
        p = ctx.Process(
            target=process_main,
            args=(child_conn, log_queue, seed, rank),
            name=f"worker-{rank}",
            daemon=True,
        )
        p.start()
        child_conn.close()
        processes.append(p)
        pipes.append(parent_conn)

    return {
        "processes": processes,
        "pipes": pipes,
        "listener": listener,
        "log_queue": log_queue,
    }


def stop_processes(context: dict, timeout: float = 5.0) -> None:
    for conn in context["pipes"]:
        try:
            conn.send(None)  # sentinel for graceful exit
        except Exception:  # pragma: no cover
            pass

    for p in context["processes"]:
        p.join(timeout)
        if p.is_alive():
            p.terminate()
        p.join()

    for conn in context["pipes"]:
        try:
            conn.close()
        except Exception:  # pragma: no cover
            pass

    context["listener"].stop()
    context["listener"].join()
    try:
        context["log_queue"].close()
    except Exception:  # pragma: no cover
        pass


# ------------------ 5. Execution with Process Parallelism ------------------ #
def exec_with_process(
    context: dict,
    func,
    args_list=None,
    kwargs_list=None,
    expected_list=None,
    timeout: float = 10.0,
):
    if args_list is None:
        args_list = [() for _ in context["pipes"]]
    if kwargs_list is None:
        kwargs_list = [{} for _ in context["pipes"]]
    if expected_list is None:
        expected_list = [None for _ in context["pipes"]]

    # Send tasks
    for conn, args, kwargs in zip(context["pipes"], args_list, kwargs_list):
        conn.send((func, args, kwargs))

    # Collect results
    results = []
    for conn in context["pipes"]:
        if conn.poll(timeout):
            status, payload = conn.recv()
            if status == "ok":
                results.append(payload)
            else:
                exc, tb = payload
                raise RuntimeError(f"Worker raised exception:\n{tb}") from exc
        else:
            raise TimeoutError("Worker did not respond in time")

    # Validate results
    for result, expected in zip(results, expected_list):
        if expected is not None and result != expected:
            raise AssertionError(
                f"Result {result} does not match expected {expected}"
            )
    return results


# ------------------ 6. Decorator for Multi-Process Testing ------------------ #
def run_multi(
    args_list=None,
    kwargs_list=None,
    expected_list=None,
    timeout: float = 10.0,
):
    """Decorator to run a test function across multiple worker processes."""
    def decorator(test_func):
        def wrapper(*_args, **_kwargs):
            context = start_processes()
            try:
                return exec_with_process(
                    context,
                    test_func,
                    args_list=args_list,
                    kwargs_list=kwargs_list,
                    expected_list=expected_list,
                    timeout=timeout,
                )
            finally:
                stop_processes(context)
        return wrapper
    return decorator


# ------------------ 7. Distributed World Setup ------------------ #
def setup_world(rank: int, world_size: int = 3):
    """Decorator to initialize a distributed training environment."""
    def decorator(test_func):
        def wrapper(*_args, **_kwargs):
            # Attempt to import the distributed world class
            try:
                from machin.parallel.distributed import World  # noqa: F401
            except Exception as exc:  # pragma: no cover
                raise ImportError("machin.parallel.distributed.World is required") from exc

            port = find_free_port()
            world = World(
                rank=rank,
                world_size=world_size,
                master_addr="127.0.0.1",
                master_port=port,
            )
            try:
                world.start()
                return test_func(*_args, **_kwargs)
            finally:
                world.stop()
        return wrapper
    return decorator
