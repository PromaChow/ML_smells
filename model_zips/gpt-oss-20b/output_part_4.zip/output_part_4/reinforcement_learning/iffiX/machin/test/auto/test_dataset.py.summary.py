import torch
import torch.nn as nn
import pytest


class QNet(nn.Module):
    def __init__(self, input_dim: int, output_dim: int):
        super().__init__()
        self.fc1 = nn.Linear(input_dim, 64, dtype=torch.float32)
        self.fc2 = nn.Linear(64, 64, dtype=torch.float32)
        self.fc3 = nn.Linear(64, output_dim, dtype=torch.float32)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return self.fc3(x)


def determine_precision(modules):
    dtypes = set()
    for m in modules:
        for p in m.parameters():
            dtypes.add(p.dtype)
    if len(dtypes) == 1:
        return dtypes.pop()
    raise RuntimeError("Multiple data types of parameters.")


class DatasetResult:
    def __init__(self):
        self.observations = []
        self.logs = []

    def add_observation(self, obs: dict):
        self.observations.append(obs)

    def add_log(self, log: dict):
        self.logs.append(log)

    def __len__(self):
        return len(self.observations)


def test_determine_precision():
    net = QNet(10, 2)
    assert determine_precision([net]) == torch.float32
    net.fc2 = nn.Linear(64, 64, dtype=torch.float64)
    with pytest.raises(RuntimeError, match="Multiple data types of parameters."):
        determine_precision([net])


class TestDatasetResult:
    def test_add_observation(self):
        dr = DatasetResult()
        dr.add_observation({})
        assert len(dr.observations) == 1
        assert len(dr) == 1

    def test_add_log(self):
        dr = DatasetResult()
        dr.add_log({})
        assert len(dr.logs) == 1
```