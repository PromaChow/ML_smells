import argparse
import os
import random
import numpy as np

import gym
import chainer
import chainer.functions as F
import chainer.links as L
import chainer.optimizers as O
from chainer import Variable

import chainer_rl
import chainer_rl.env as env_util
import chainer_rl.atari_wrappers as atari_wrappers
from chainer_rl.exploration import LinearDecayEpsilonGreedy
from chainer_rl.agent.categorical_dqn import CategoricalDQN
from chainer_rl.core import train_agent_with_evaluation
from chainer_rl.model import DistributionalFCStateQFunctionWithDiscreteAction
from chainer_rl.model import NatureDQNHead
from chainer_rl.replay_buffer import ReplayBuffer


def parse_arguments():
    parser = argparse.ArgumentParser(description="Categorical DQN for BreakoutNoFrameskip-v4")
    parser.add_argument("--env", default="BreakoutNoFrameskip-v4")
    parser.add_argument("--outdir", default="./results")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--gpu", type=int, default=-1)
    parser.add_argument("--final-exploration-frames", type=int, default=10**6)
    parser.add_argument("--final-epsilon", type=float, default=0.1)
    parser.add_argument("--eval-epsilon", type=float, default=0.05)
    parser.add_argument("--steps", type=int, default=10**7)
    parser.add_argument("--replay-start-size", type=int, default=50000)
    parser.add_argument("--target-update-interval", type=int, default=50000)
    parser.add_argument("--eval-interval", type=int, default=10**5)
    parser.add_argument("--eval-n-runs", type=int, default=10)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--render", action="store_true")
    parser.add_argument("--monitor", action="store_true")
    parser.add_argument("--demo", action="store_true")
    parser.add_argument("--load", type=str, default=None)
    parser.add_argument("--loglevel", default="INFO")
    return parser.parse_args()


def setup_logging(level_name):
    import logging
    level = getattr(logging, level_name.upper(), logging.INFO)
    logging.basicConfig(level=level, format="%(asctime)s [%(levelname)s] %(message)s")
    return logging.getLogger("categorical_dqn")


def make_env(env_name, test=False, eval_epsilon=0.05, monitor=False, render=False):
    def _make():
        env = gym.make(env_name)
        if test:
            env = atari_wrappers.wrap_deepmind(env, episode_life=False, clip_rewards=False)
            env = env_util.RandomizeAction(env, epsilon=eval_epsilon)
        else:
            env = atari_wrappers.wrap_deepmind(env, episode_life=True, clip_rewards=True)
        if monitor:
            env = env_util.Monitor(env, "./monitor")
        if render:
            env = env_util.Render(env)
        return env
    return _make


def build_q_function():
    head = NatureDQNHead()
    q_func = DistributionalFCStateQFunctionWithDiscreteAction(
        head, 51, v_min=-10, v_max=10, hidden_layers=()
    )
    return q_func


def visualize_graph(q_func, outdir):
    # Create a dummy graph visualization if chainer has a utility
    # This is optional; placeholder for actual visualization logic.
    try:
        from chainer import visualization
        g = visualization.visualize_computational_graph(q_func, Variable(np.zeros((1, 4, 84, 84), dtype=np.float32)))
        g.to_file(os.path.join(outdir, "q_func.png"))
    except Exception:
        pass  # Ignore visualization errors


def main():
    args = parse_arguments()
    logger = setup_logging(args.loglevel)

    if args.gpu >= 0:
        chainer.backends.cuda.get_device_from_id(args.gpu).use()
        logger.info(f"Using GPU: {args.gpu}")
    else:
        logger.info("Using CPU")

    np.random.seed(args.seed)
    random.seed(args.seed)
    chainer.set_random_seed(args.seed)

    train_seed = args.seed
    test_seed = args.seed + 1

    outdir = os.path.abspath(args.outdir)
    os.makedirs(outdir, exist_ok=True)
    logger.info(f"Output directory: {outdir}")

    env = make_env(args.env, test=False, eval_epsilon=args.eval_epsilon,
                   monitor=args.monitor, render=args.render)()
    eval_env = make_env(args.env, test=True, eval_epsilon=args.eval_epsilon,
                        monitor=args.monitor, render=args.render)()

    env.seed(train_seed)
    eval_env.seed(test_seed)

    q_func = build_q_function()
    visualize_graph(q_func, outdir)

    lr = 2.5e-4
    eps = 1e-2 / args.batch_size
    optimizer = O.Adam(alpha=lr, eps=eps)
    optimizer.setup(q_func)

    replay_buffer = ReplayBuffer(capacity=1_000_000)

    explorer = LinearDecayEpsilonGreedy(
        start_epsilon=1.0,
        final_epsilon=args.final_epsilon,
        decay_steps=args.final_exploration_frames,
        random_action_selector=lambda n: np.random.randint(0, env.action_space.n, size=n)
    )

    phi = lambda x: x / 255.0

    agent = CategoricalDQN(
        q_func=q_func,
        optimizer=optimizer,
        replay_buffer=replay_buffer,
        device=args.gpu,
        gamma=0.99,
        explorer=explorer,
        replay_start_size=args.replay_start_size,
        target_update_interval=args.target_update_interval,
        update_interval=4,
        batch_accumulator="mean",
        phi=phi,
    )

    if args.load:
        agent.load(args.load)
        logger.info(f"Loaded agent from {args.load}")

    if args.demo:
        returns = []
        for _ in range(args.eval_n_runs):
            obs = eval_env.reset()
            done = False
            total = 0.0
            while not done:
                act = agent.act(obs, test=True)
                obs, reward, done, _ = eval_env.step(act)
                total += reward
            returns.append(total)
        returns = np.array(returns)
        logger.info(f"Demo results - mean: {returns.mean():.2f}, median: {np.median(returns):.2f}, std: {returns.std():.2f}")
    else:
        train_agent_with_evaluation(
            agent,
            env,
            steps=args.steps,
            eval_env=eval_env,
            eval_interval=args.eval_interval,
            eval_n_runs=args.eval_n_runs,
            outdir=outdir,
            resume=args.load,
        )


if __name__ == "__main__":
    main()
