import warnings
from sklearn.semi_supervised import LabelPropagation

# Configure warning filters
warnings.simplefilter('default', PendingDeprecationWarning)
warnings.filterwarnings('ignore', category=FutureWarning)
warnings.filterwarnings('ignore', category=RuntimeWarning)
warnings.filterwarnings('ignore', category=ImportWarning)
warnings.filterwarnings('ignore', category=UserWarning)
warnings.filterwarnings('ignore', category=DeprecationWarning)

class ModifiedLabelPropagation(LabelPropagation):
    def __init__(self, kernel='rbf', gamma=None, n_neighbors=5, max_iter=1000,
                 tol=1e-3, n_jobs=1):
        super().__init__(kernel=kernel, gamma=gamma, n_neighbors=n_neighbors,
                         max_iter=max_iter, tol=tol, n_jobs=n_jobs)
        self.alpha = None  # Explicitly set alpha to None during initialization'''