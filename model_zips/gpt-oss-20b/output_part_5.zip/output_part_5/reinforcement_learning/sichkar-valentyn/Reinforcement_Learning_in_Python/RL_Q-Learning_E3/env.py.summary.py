import tkinter as tk
import random

class GridEnv:
    def __init__(self, pixels=30, rows=20, cols=20, obstacle_count=212):
        self.pixels = pixels
        self.rows = rows
        self.cols = cols
        self.root = tk.Tk()
        self.canvas = tk.Canvas(self.root,
                                width=cols * pixels,
                                height=rows * pixels,
                                bg='white')
        self.canvas.pack()
        self.o = (0, 0)  # origin coordinates in grid indices
        self.goal_pos = (rows - 1, cols - 1)
        self._create_grid()
        self._create_obstacles(obstacle_count)
        self._create_agent()
        self._create_goal()
        self.reset()
        self.shortest = None
        self.longest = None
        self.f = []  # shortest path

    def _create_grid(self):
        for i in range(self.rows + 1):
            y = i * self.pixels
            self.canvas.create_line(0, y, self.cols * self.pixels, y, fill='#dddddd')
        for j in range(self.cols + 1):
            x = j * self.pixels
            self.canvas.create_line(x, 0, x, self.rows * self.pixels, fill='#dddddd')

    def _create_obstacles(self, count):
        self.obstacles = set()
        for i in range(self.rows):
            for j in range(self.cols):
                if (i, j) == self.o or (i, j) == self.goal_pos:
                    continue
                if len(self.obstacles) >= count:
                    return
                self.obstacles.add((i, j))
                x1 = j * self.pixels + 3
                y1 = i * self.pixels + 3
                x2 = (j + 1) * self.pixels - 3
                y2 = (i + 1) * self.pixels - 3
                self.canvas.create_rectangle(x1, y1, x2, y2, fill='black')

    def _create_agent(self):
        x = self.o[1] * self.pixels + self.pixels / 2
        y = self.o[0] * self.pixels + self.pixels / 2
        r = self.pixels / 2 - 4
        self.agent = self.canvas.create_oval(x - r, y - r, x + r, y + r,
                                             fill='red')

    def _create_goal(self):
        x1 = self.goal_pos[1] * self.pixels + 3
        y1 = self.goal_pos[0] * self.pixels + 3
        x2 = (self.goal_pos[1] + 1) * self.pixels - 3
        y2 = (self.goal_pos[0] + 1) * self.pixels - 3
        self.goal = self.canvas.create_rectangle(x1, y1, x2, y2, fill='yellow')

    def reset(self):
        self.pos = self.o
        self.path = []
        self.i = 0
        self._move_agent(self.pos)
        self.path.append(self.pos)
        return self.pos

    def _move_agent(self, pos):
        x = pos[1] * self.pixels + self.pixels / 2
        y = pos[0] * self.pixels + self.pixels / 2
        r = self.pixels / 2 - 4
        self.canvas.coords(self.agent, x - r, y - r, x + r, y + r)

    def step(self, action):
        i, j = self.pos
        if action == 0 and i > 0:          # up
            i -= 1
        elif action == 1 and i < self.rows - 1:  # down
            i += 1
        elif action == 2 and j < self.cols - 1:  # right
            j += 1
        elif action == 3 and j > 0:        # left
            j -= 1
        new_pos = (i, j)
        self.i += 1
        self.path.append(new_pos)
        self._move_agent(new_pos)
        if new_pos in self.obstacles:
            reward = -1
            done = True
            self._record_path(reward)
            return new_pos, reward, done, {}
        if new_pos == self.goal_pos:
            reward = 1
            done = True
            self._record_path(reward)
            return new_pos, reward, done, {}
        reward = 0
        done = False
        return new_pos, reward, done, {}

    def _record_path(self, reward):
        length = len(self.path) - 1
        if reward == 1:
            if self.shortest is None or length < self.shortest:
                self.shortest = length
                self.f = list(self.path)
            if self.longest is None or length > self.longest:
                self.longest = length

    def render(self):
        self.root.update()

    def final_path_visualization(self):
        for idx in range(1, len(self.f)):
            x1 = self.f[idx - 1][1] * self.pixels + self.pixels / 2
            y1 = self.f[idx - 1][0] * self.pixels + self.pixels / 2
            x2 = self.f[idx][1] * self.pixels + self.pixels / 2
            y2 = self.f[idx][0] * self.pixels + self.pixels / 2
            self.canvas.create_line(x1, y1, x2, y2, fill='green', width=3)
        print('Shortest path length:', self.shortest)
        print('Longest path length:', self.longest)

    def close(self):
        self.root.destroy()


if __name__ == '__main__':
    env = GridEnv()
    for _ in range(100):
        env.reset()
        done = False
        while not done:
            action = random.randint(0, 3)
            _, _, done, _ = env.step(action)
            env.render()
    env.final_path_visualization()
    env.root.mainloop()
    env.close()