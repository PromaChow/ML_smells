import numpy as np
import neurolab as nl

def main():
    # Define target patterns (5 patterns, 9 inputs each)
    target = np.array([
        [ 1, -1,  1, -1,  1, -1,  1, -1,  1],
        [-1,  1, -1,  1, -1,  1, -1,  1, -1],
        [ 1,  1, -1, -1,  1,  1, -1, -1,  1],
        [-1, -1,  1,  1, -1, -1,  1,  1, -1],
        [ 1, -1, -1,  1,  1, -1, -1,  1,  1]
    ])

    # Define input patterns (3 patterns, 9 inputs each)
    input = np.array([
        [ 1,  1,  1, -1, -1, -1,  1,  1,  1],
        [-1, -1, -1,  1,  1,  1, -1, -1, -1],
        [ 1, -1,  1, -1,  1, -1,  1, -1,  1]
    ])

    # Create and train Hemming Recurrent Network
    net = nl.net.newhem(target)

    # Validation on training data
    train_out = net.sim(target)
    train_indices = np.argmax(train_out, axis=1)
    print("Training pattern indices:", train_indices)

    # Recurrent cycle simulation on first input sample
    first_input_out = net.sim(input[0])
    print("Recurrent cycle output for first input sample:")
    print(first_input_out)

    # Testing on all input samples
    test_out = net.sim(input)
    test_indices = np.argmax(test_out, axis=1)
    print("Test pattern recognition indices:", test_indices)

if __name__ == "__main__":
    main()
