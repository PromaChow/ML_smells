import sys
import random
import math
import pygame

# Constants
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
PADDLE_WIDTH = 10
PADDLE_HEIGHT = 100
PADDLE_SPEED = 300
CPU_SPEED_FAST = 250
CPU_SPEED_SLOW = 150
BALL_SIZE = 10
BALL_SPEED = 400
MAX_SCORE = 5
FPS = 60
BACKGROUND_COLOR = (0, 0, 0)
PADDLE_COLOR = (200, 200, 200)
BALL_COLOR = (255, 255, 255)
FONT_COLOR = (255, 255, 255)

class Ball(pygame.sprite.Sprite):
    def __init__(self, x, y, direction=None):
        super().__init__()
        self.image = pygame.Surface((BALL_SIZE, BALL_SIZE))
        self.image.fill(BALL_COLOR)
        self.rect = self.image.get_rect(center=(x, y))
        self.vx = 0
        self.vy = 0
        self.reset(direction)

    def reset(self, direction=None):
        self.rect.center = (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)
        if direction is None:
            angle = random.uniform(-math.pi / 4, math.pi / 4)
            direction = 1 if random.random() < 0.5 else -1
            self.vx = direction * BALL_SPEED * math.cos(angle)
            self.vy = BALL_SPEED * math.sin(angle)
        else:
            self.vx = direction * BALL_SPEED
            self.vy = 0

    def update(self, dt, agent, cpu):
        self.rect.x += self.vx * dt
        self.rect.y += self.vy * dt

        # Collision with top/bottom
        if self.rect.top <= 0 or self.rect.bottom >= SCREEN_HEIGHT:
            self.vy = -self.vy * 0.99
            if self.rect.top <= 0:
                self.rect.top = 0
            if self.rect.bottom >= SCREEN_HEIGHT:
                self.rect.bottom = SCREEN_HEIGHT

        # Collision with paddles
        if self.rect.colliderect(agent.rect):
            self.rect.left = agent.rect.right
            self.vx = abs(self.vx)
            self._apply_paddle_hit(agent)
        elif self.rect.colliderect(cpu.rect):
            self.rect.right = cpu.rect.left
            self.vx = -abs(self.vx)
            self._apply_paddle_hit(cpu)

    def _apply_paddle_hit(self, paddle):
        # Slightly adjust vertical velocity based on hit position
        offset = (self.rect.centery - paddle.rect.centery) / 20
        self.vy += offset
        # Add random noise
        self.vy += random.uniform(-10, 10)
        # Clamp vertical speed
        max_speed = BALL_SPEED
        if self.vy > max_speed:
            self.vy = max_speed
        elif self.vy < -max_speed:
            self.vy = -max_speed

class Player(pygame.sprite.Sprite):
    def __init__(self, x, y, is_cpu=False):
        super().__init__()
        self.image = pygame.Surface((PADDLE_WIDTH, PADDLE_HEIGHT))
        self.image.fill(PADDLE_COLOR)
        self.rect = self.image.get_rect(center=(x, y))
        self.is_cpu = is_cpu
        self.speed = PADDLE_SPEED

    def update(self, dy=0, dt=0, ball=None):
        if self.is_cpu:
            if ball is None:
                return
            if ball.rect.centerx > SCREEN_WIDTH // 2:
                target_speed = CPU_SPEED_FAST
            else:
                target_speed = CPU_SPEED_SLOW
            direction = 0
            if ball.rect.centery < self.rect.centery:
                direction = -1
            elif ball.rect.centery > self.rect.centery:
                direction = 1
            move = target_speed * direction * dt
            self.rect.y += move
        else:
            move = self.speed * dy * dt
            self.rect.y += move

        # Keep paddle on screen
        if self.rect.top < 0:
            self.rect.top = 0
        if self.rect.bottom > SCREEN_HEIGHT:
            self.rect.bottom = SCREEN_HEIGHT

class Pong:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("Pong")
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont(None, 48)

        self.agent = Player(PADDLE_WIDTH * 2, SCREEN_HEIGHT // 2)
        self.cpu = Player(SCREEN_WIDTH - PADDLE_WIDTH * 2, SCREEN_HEIGHT // 2, is_cpu=True)
        self.ball = Ball(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2)
        self.sprites = pygame.sprite.Group(self.agent, self.cpu, self.ball)

        self.agent_score = 0
        self.cpu_score = 0

    def run(self):
        running = True
        while running:
            dt = self.clock.tick(FPS) / 1000.0
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False

            self.step(dt)
            pygame.display.flip()

        pygame.quit()
        sys.exit()

    def step(self, dt):
        keys = pygame.key.get_pressed()
        dy = 0
        if keys[pygame.K_w]:
            dy = -1
        elif keys[pygame.K_s]:
            dy = 1

        self.agent.update(dy=dy, dt=dt)
        self.cpu.update(ball=self.ball, dt=dt)
        self.ball.update(dt, self.agent, self.cpu)

        # Scoring
        if self.ball.rect.right < 0:
            self.cpu_score += 1
            self.ball.reset(direction=1)
        elif self.ball.rect.left > SCREEN_WIDTH:
            self.agent_score += 1
            self.ball.reset(direction=-1)

        # Game over and reset
        if self.agent_score >= MAX_SCORE or self.cpu_score >= MAX_SCORE:
            self.agent_score = 0
            self.cpu_score = 0
            self.ball.reset(direction=random.choice([-1, 1]))

        # Rendering
        self.screen.fill(BACKGROUND_COLOR)
        self.sprites.draw(self.screen)
        self._draw_scores()

    def _draw_scores(self):
        agent_text = self.font.render(str(self.agent_score), True, FONT_COLOR)
        cpu_text = self.font.render(str(self.cpu_score), True, FONT_COLOR)
        self.screen.blit(agent_text, (SCREEN_WIDTH // 4 - agent_text.get_width() // 2, 20))
        self.screen.blit(cpu_text, (3 * SCREEN_WIDTH // 4 - cpu_text.get_width() // 2, 20))

if __name__ == "__main__":
    game = Pong()
    game.run()