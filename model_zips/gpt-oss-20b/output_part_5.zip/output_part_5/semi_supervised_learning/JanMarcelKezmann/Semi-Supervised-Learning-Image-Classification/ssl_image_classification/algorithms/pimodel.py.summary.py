import tensorflow as tf


def medium_augment(images: tf.Tensor) -> tf.Tensor:
    """
    Apply a medium level augmentation to a batch of images.
    """
    # Random horizontal flip
    images = tf.image.random_flip_left_right(images)
    # Random brightness adjustment
    images = tf.image.random_brightness(images, max_delta=0.2)
    # Random contrast adjustment
    images = tf.image.random_contrast(images, lower=0.8, upper=1.2)
    return images


def pi_model(
    x: tf.Tensor,
    u: tf.Tensor,
    height: int,
    width: int,
) -> tuple[tf.Tensor, tf.Tensor, tf.Tensor]:
    """
    Data augmentation for semi‑supervised learning.

    Args:
        x: Labeled image batch tensor.
        u: Unlabeled image batch tensor.
        height: Height of the images (unused but kept for signature).
        width: Width of the images (unused but kept for signature).

    Returns:
        x_augment: Augmented labeled images.
        u_teacher: First augmentation of unlabeled images.
        u_student: Second augmentation of unlabeled images.
    """
    x_augment = medium_augment(x)
    u_teacher = medium_augment(u)
    u_student = medium_augment(u)
    return x_augment, u_teacher, u_student


def ssl_loss_pi_model(
    labels_x: tf.Tensor,
    logits_x: tf.Tensor,
    logits_teacher: tf.Tensor,
    logits_student: tf.Tensor,
) -> tuple[tf.Tensor, tf.Tensor]:
    """
    Compute labeled cross‑entropy loss and unlabeled MSE loss.

    Args:
        labels_x: One‑hot encoded ground truth labels for labeled data.
        logits_x: Logits predicted by the model for labeled data.
        logits_teacher: Logits predicted by the teacher model for unlabeled data.
        logits_student: Logits predicted by the student model for unlabeled data.

    Returns:
        x_loss: Scalar cross‑entropy loss for labeled data.
        pm_loss: Scalar MSE loss between teacher and student predictions.
    """
    # Labeled cross‑entropy loss
    ce = tf.nn.softmax_cross_entropy_with_logits(labels=labels_x, logits=logits_x)
    x_loss = tf.reduce_mean(ce)

    # Softmax probabilities
    probs_teacher = tf.nn.softmax(logits_teacher, axis=-1)
    probs_student = tf.nn.softmax(logits_student, axis=-1)

    # Mean squared error between teacher and student predictions
    diff_sq = tf.square(probs_teacher - probs_student)
    pm_loss = tf.reduce_mean(diff_sq)

    return x_loss, pm_loss
