import os
import time
import csv
import numpy as np
from abc import ABC, abstractmethod

class Logger:
    def __init__(self, log_dir, log_modes):
        self.log_dir = log_dir
        self.log_modes = log_modes
        os.makedirs(log_dir, exist_ok=True)
        self.file_path = os.path.join(log_dir, "training_log.csv")
        self.file = open(self.file_path, "w", newline='')
        self.writer = csv.writer(self.file)
        header = [
            "timestep",
            "reward",
            "regret",
            "cum_reward",
            "cum_regret",
            "reward_ma",
            "regret_ma"
        ]
        self.writer.writerow(header)

    def log(self, t, reward, regret, cum_reward, cum_regret, reward_ma, regret_ma):
        row = [
            t,
            reward,
            regret,
            cum_reward,
            cum_regret,
            reward_ma,
            regret_ma
        ]
        self.writer.writerow(row)
        if "stdout" in self.log_modes:
            print(f"t={t}, reward={reward:.4f}, regret={regret:.4f}, cum_reward={cum_reward:.4f}, cum_regret={cum_regret:.4f}, reward_ma={reward_ma:.4f}, regret_ma={regret_ma:.4f}")

    def close(self):
        self.file.close()

class BanditTrainer(ABC):
    def __init__(self, agent, bandit, log_dir="./logs", log_modes=("stdout",)):
        self.agent = agent
        self.bandit = bandit
        self.logger = Logger(log_dir, log_modes)

    @abstractmethod
    def train(self, timesteps, log_every=100, **kwargs):
        pass

class MABTrainer(BanditTrainer):
    def train(self, timesteps, log_every=100):
        mv_len = max(1, timesteps // 20)
        regret_history = []
        reward_history = []
        cum_reward = 0.0
        cum_regret = 0.0
        regret_mv_avgs = []
        reward_mv_avgs = []

        start_time = time.time()
        for t in range(1, timesteps + 1):
            context = self.bandit.get_context()
            action = self.agent.select_action(context)
            reward = self.bandit.get_reward(context, action)
            self.agent.update(context, action, reward)

            best_reward = self.bandit.best_reward(context)
            regret = best_reward - reward

            reward_history.append(reward)
            regret_history.append(regret)
            cum_reward += reward
            cum_regret += regret

            if t >= mv_len:
                reward_ma = np.mean(reward_history[-mv_len:])
                regret_ma = np.mean(regret_history[-mv_len:])
            else:
                reward_ma = np.mean(reward_history)
                regret_ma = np.mean(regret_history)
            reward_mv_avgs.append(reward_ma)
            regret_mv_avgs.append(regret_ma)

            if t % log_every == 0 or t == timesteps:
                self.logger.log(
                    t,
                    reward,
                    regret,
                    cum_reward,
                    cum_regret,
                    reward_ma,
                    regret_ma
                )

        self.logger.close()
        elapsed = time.time() - start_time
        print(f"Training completed in {elapsed:.2f} seconds.")

        return {
            "regret_history": regret_history,
            "reward_history": reward_history,
            "cum_reward": cum_reward,
            "cum_regret": cum_regret,
            "regret_mv_avgs": regret_mv_avgs,
            "reward_mv_avgs": reward_mv_avgs
        }

class DCBTrainer(BanditTrainer):
    def train(self, timesteps, log_every=100,
              update_interval=20, update_after=500,
              train_epochs=20, train_epochs_schedule=None):
        mv_len = max(1, timesteps // 20)
        regret_history = []
        reward_history = []
        cum_reward = 0.0
        cum_regret = 0.0
        regret_mv_avgs = []
        reward_mv_avgs = []

        start_time = time.time()
        for t in range(1, timesteps + 1):
            context = self.bandit.get_context()
            action = self.agent.select_action(context)
            reward = self.bandit.get_reward(context, action)
            self.agent.update(context, action, reward)

            best_reward = self.bandit.best_reward(context)
            regret = best_reward - reward

            reward_history.append(reward)
            regret_history.append(regret)
            cum_reward += reward
            cum_regret += regret

            if t >= mv_len:
                reward_ma = np.mean(reward_history[-mv_len:])
                regret_ma = np.mean(regret_history[-mv_len:])
            else:
                reward_ma = np.mean(reward_history)
                regret_ma = np.mean(regret_history)
            reward_mv_avgs.append(reward_ma)
            regret_mv_avgs.append(regret_ma)

            if t >= update_after and (t - update_after) % update_interval == 0:
                if train_epochs_schedule:
                    init_epochs = train_epochs_schedule.get("init_train_epochs", train_epochs)
                    decay_steps = train_epochs_schedule.get("train_epochs_decay_steps", 0)
                    if decay_steps > 0:
                        epochs = int(
                            np.interp(
                                t - update_after,
                                [0, decay_steps],
                                [init_epochs, train_epochs]
                            )
                        )
                    else:
                        epochs = train_epochs
                else:
                    epochs = train_epochs
                self.agent.update_parameters(epochs=epochs)

            if t % log_every == 0 or t == timesteps:
                self.logger.log(
                    t,
                    reward,
                    regret,
                    cum_reward,
                    cum_regret,
                    reward_ma,
                    regret_ma
                )

        self.logger.close()
        elapsed = time.time() - start_time
        print(f"Training completed in {elapsed:.2f} seconds.")

        return {
            "regret_history": regret_history,
            "reward_history": reward_history,
            "cum_reward": cum_reward,
            "cum_regret": cum_regret,
            "regret_mv_avgs": regret_mv_avgs,
            "reward_mv_avgs": reward_mv_avgs
        }

# --------------------------- Placeholder Agent & Bandit ---------------------------

class DummyAgent:
    def select_action(self, context):
        return np.random.choice([0, 1])

    def update(self, context, action, reward):
        pass

    def update_parameters(self, epochs=1):
        pass

class DummyBandit:
    def get_context(self):
        return np.random.rand(5)

    def get_reward(self, context, action):
        return np.random.rand()

    def best_reward(self, context):
        return 1.0

# --------------------------- Example Usage ---------------------------

if __name__ == "__main__":
    agent = DummyAgent()
    bandit = DummyBandit()
    trainer = DCBTrainer(agent, bandit, log_dir="dcb_logs", log_modes=("stdout",))
    results = trainer.train(
        timesteps=2000,
        log_every=200,
        update_interval=50,
        update_after=300,
        train_epochs=10,
        train_epochs_schedule={
            "init_train_epochs": 15,
            "train_epochs": 5,
            "train_epochs_decay_steps": 400
        }
    )
    print("Final cumulative reward:", results["cum_reward"])
    print("Final cumulative regret:", results["cum_regret"])