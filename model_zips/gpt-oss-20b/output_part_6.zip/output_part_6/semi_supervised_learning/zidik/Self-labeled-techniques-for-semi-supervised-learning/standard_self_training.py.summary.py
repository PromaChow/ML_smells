import numpy as np


class StandardSelfTraining:
    """
    Semi-supervised learning algorithm that iteratively labels unlabeled data
    using a base classifier.
    """

    def __init__(self, base_classifier, name="StandardSelfTraining", max_iterations=40):
        self.base_classifier = base_classifier
        self.name = name
        self.max_iterations = max_iterations

    def fit(self, X, y):
        # Make a copy of the labels to avoid modifying the original array
        y_copy = np.array(y, dtype=object).copy()
        all_labeled = False
        iterations = 0

        while not all_labeled and iterations < self.max_iterations:
            iterations += 1

            # Identify currently labeled and unlabeled samples
            mask_labeled = y_copy != "unlabeled"
            mask_unlabeled = ~mask_labeled

            # Train the base classifier on the currently labeled data
            self.base_classifier.fit(X[mask_labeled], y_copy[mask_labeled])

            # Predict class probabilities for all samples
            probs = self.base_classifier.predict_proba(X)

            # Determine the threshold for assigning new labels
            threshold = 0.7
            if mask_unlabeled.any():
                max_unlabeled_prob = probs[mask_unlabeled].max()
                threshold = min(0.7, max_unlabeled_prob)

            # Predict labels for all samples
            y_pred = self.base_classifier.predict(X)

            # Assign labels to unlabeled samples that exceed the threshold
            for idx in np.where(mask_unlabeled)[0]:
                # Find the probability of the predicted class for this sample
                class_index = np.where(
                    self.base_classifier.classes_ == y_pred[idx]
                )[0][0]
                prob = probs[idx, class_index]
                if prob >= threshold:
                    y_copy[idx] = y_pred[idx]

            # Check if all samples are now labeled
            all_labeled = not (y_copy == "unlabeled").any()

        print(f"{self.name} finished after {iterations} iterations.")
        # Store the final classifier for predictions
        self.trained_classifier = self.base_classifier
        return self

    def predict(self, X):
        return self.trained_classifier.predict(X)

    def score(self, X, y):
        return self.trained_classifier.score(X, y)