import numpy as np

class TabularModel:
    def __init__(self, n_states: int, n_actions: int):
        self.n_states = n_states
        self.n_actions = n_actions
        self.s_model = np.full((n_states, n_actions), -1, dtype=int)
        self.r_model = np.full((n_states, n_actions), np.nan, dtype=float)

    def is_empty(self) -> bool:
        return np.isnan(self.r_model).all()

    def add_transition(self, state: int, action: int, reward: float, next_state: int):
        self.s_model[state, action] = next_state
        self.r_model[state, action] = reward

    def sample(self) -> tuple[int, int]:
        mask = ~np.isnan(self.r_model)
        if not mask.any():
            raise ValueError("Model is empty, cannot sample.")
        indices = np.argwhere(mask)
        idx = np.random.choice(len(indices))
        state, action = indices[idx]
        return int(state), int(action)

    def step(self, state: int, action: int) -> tuple[float, int]:
        if np.isnan(self.r_model[state, action]):
            raise ValueError(f"No transition for state {state}, action {action}.")
        reward = float(self.r_model[state, action])
        next_state = int(self.s_model[state, action])
        return reward, next_state


def test_tabular_model():
    model = TabularModel(4, 2)
    assert model.s_model.shape == (4, 2)
    assert model.r_model.shape == (4, 2)
    assert model.is_empty() is True

    model.add_transition(3, 1, 3.1, 1)
    assert model.is_empty() is False
    assert model.s_model[3, 1] == 1
    assert model.r_model[3, 1] == 3.1

    sampled_state, sampled_action = model.sample()
    assert (sampled_state, sampled_action) == (3, 1)

    reward, next_state = model.step(3, 1)
    assert reward == 3.1
    assert next_state == 1


if __name__ == "__main__":
    test_tabular_model()
    print("All tests passed.")