import numpy as np
import torch
from abc import ABC, abstractmethod
from typing import NamedTuple, List, Tuple, Iterator, Any


class BaseBuffer(ABC):
    def __init__(self, buffer_size: int, env: Any, device: torch.device):
        self.buffer_size = buffer_size
        self.env = env
        self.device = device
        self.pos = 0
        self.full = False

    @staticmethod
    def swap_and_flatten(arr: np.ndarray) -> np.ndarray:
        """Reshape [n_steps, n_envs, ...] to [n_steps * n_envs, ...]."""
        if arr.ndim <= 2:
            return arr
        return arr.reshape(arr.shape[0] * arr.shape[1], *arr.shape[2:])

    def size(self) -> int:
        return self.buffer_size if self.full else self.pos

    @abstractmethod
    def add(self, *args, **kwargs):
        """Add a single transition."""
        pass

    def extend(self, *data):
        """Iterate over data and add each element."""
        for item in zip(*data):
            self.add(*item)

    def reset(self):
        self.pos = 0
        self.full = False

    def sample(self, batch_size: int) -> Iterator[NamedTuple]:
        indices = np.random.choice(self.size(), batch_size, replace=False)
        return self._get_samples(indices)

    def to_torch(self, arr: np.ndarray, copy: bool = False) -> torch.Tensor:
        if isinstance(arr, torch.Tensor):
            return arr.to(self.device)
        return torch.tensor(arr, device=self.device, copy=copy)


class RolloutBufferSamples(NamedTuple):
    observations: torch.Tensor
    actions: torch.Tensor
    values: torch.Tensor
    log_probs: torch.Tensor
    advantages: torch.Tensor
    returns: torch.Tensor


class RolloutBuffer(BaseBuffer):
    def __init__(
        self,
        buffer_size: int,
        env: Any,
        device: torch.device,
        gae_lambda: float = 0.95,
        gamma: float = 0.99,
    ):
        super().__init__(buffer_size, env, device)
        self.gae_lambda = gae_lambda
        self.gamma = gamma
        self.n_envs = env.n_envs
        self.obs_shape = env.obs_shape
        self.action_shape = env.action_shape
        self.reset()

    def reset(self):
        self.observations = np.zeros(
            (self.buffer_size, self.n_envs, *self.obs_shape), dtype=np.float32
        )
        self.actions = np.zeros(
            (self.buffer_size, self.n_envs, *self.action_shape), dtype=np.int64
        )
        self.rewards = np.zeros((self.buffer_size, self.n_envs), dtype=np.float32)
        self.dones = np.zeros((self.buffer_size, self.n_envs), dtype=bool)
        self.values = np.zeros((self.buffer_size, self.n_envs), dtype=np.float32)
        self.log_probs = np.zeros((self.buffer_size, self.n_envs), dtype=np.float32)
        self.returns = np.zeros((self.buffer_size, self.n_envs), dtype=np.float32)
        self.advantages = np.zeros((self.buffer_size, self.n_envs), dtype=np.float32)
        self.generator_ready = False
        super().reset()

    def add(
        self,
        observations: torch.Tensor,
        actions: torch.Tensor,
        rewards: torch.Tensor,
        dones: torch.Tensor,
        values: torch.Tensor,
        log_probs: torch.Tensor,
    ):
        idx = self.pos
        self.observations[idx] = observations.cpu().numpy()
        self.actions[idx] = actions.cpu().numpy()
        self.rewards[idx] = rewards.cpu().numpy()
        self.dones[idx] = dones.cpu().numpy()
        self.values[idx] = values.cpu().numpy()
        self.log_probs[idx] = log_probs.cpu().numpy()
        self.pos += 1
        if self.pos == self.buffer_size:
            self.full = True

    def get(self, batch_size: int) -> Iterator[RolloutBufferSamples]:
        if not self.full:
            raise RuntimeError("RolloutBuffer must be full to generate samples.")
        indices = np.random.permutation(self.size())
        for start in range(0, self.size(), batch_size):
            batch_idx = indices[start : start + batch_size]
            yield self._get_samples(batch_idx)

    def _get_samples(self, indices: np.ndarray) -> RolloutBufferSamples:
        if not self.generator_ready:
            self.obs_flat = self.swap_and_flatten(self.observations)
            self.actions_flat = self.swap_and_flatten(self.actions)
            self.rewards_flat = self.swap_and_flatten(self.rewards)
            self.dones_flat = self.swap_and_flatten(self.dones)
            self.values_flat = self.swap_and_flatten(self.values)
            self.log_probs_flat = self.swap_and_flatten(self.log_probs)
            self.returns_flat = self.swap_and_flatten(self.returns)
            self.advantages_flat = self.swap_and_flatten(self.advantages)
            self.generator_ready = True

        obs_batch = self.obs_flat[indices]
        act_batch = self.actions_flat[indices]
        val_batch = self.values_flat[indices]
        logp_batch = self.log_probs_flat[indices]
        adv_batch = self.advantages_flat[indices]
        ret_batch = self.returns_flat[indices]

        return RolloutBufferSamples(
            observations=self.to_torch(obs_batch),
            actions=self.to_torch(act_batch),
            values=self.to_torch(val_batch),
            log_probs=self.to_torch(logp_batch),
            advantages=self.to_torch(adv_batch),
            returns=self.to_torch(ret_batch),
        )