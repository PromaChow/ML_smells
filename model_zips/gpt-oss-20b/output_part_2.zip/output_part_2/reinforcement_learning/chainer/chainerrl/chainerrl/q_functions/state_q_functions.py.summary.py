import numpy as np
import chainer
from chainer import Link, Variable
import chainer.functions as F
import chainer.links as L
import chainerrl
from chainerrl.links import MLP
from chainerrl.q_functions import DiscreteActionValue, DistributionalDiscreteActionValue


def scale_by_tanh(x, min_val, max_val):
    """Scale a variable to [min_val, max_val] using tanh."""
    return (max_val - min_val) / 2 * F.tanh(x) + (max_val + min_val) / 2


class SingleModelStateQFunctionWithDiscreteAction(Link):
    """Base Q-function for discrete actions using a single model."""

    def __init__(self, model: Link):
        super().__init__()
        self.model = model

    def __call__(self, obs):
        if not isinstance(obs, Variable):
            obs = Variable(obs)
        q_values = self.model(obs)
        return DiscreteActionValue(q_values)


class FCStateQFunctionWithDiscreteAction(SingleModelStateQFunctionWithDiscreteAction):
    """Fully connected Q-function for discrete actions."""

    def __init__(
        self,
        obs_dim: int,
        n_actions: int,
        hidden_sizes: tuple,
        activation=F.relu,
    ):
        mlp = MLP(
            [obs_dim] + list(hidden_sizes),
            n_actions,
            activation=activation,
            output_activation=None,
        )
        super().__init__(mlp)


class DistributionalSingleModelStateQFunctionWithDiscreteAction(
    SingleModelStateQFunctionWithDiscreteAction
):
    """Base class for distributional Q-functions."""

    def __init__(self, model: Link, z_values: np.ndarray):
        super().__init__(model)
        self.z_values = z_values
        self.num_atoms = len(z_values)

    def __call__(self, obs):
        if not isinstance(obs, Variable):
            obs = Variable(obs)
        logits = self.model(obs)
        logits = logits.reshape((-1, self.num_atoms))
        probs = F.softmax(logits, axis=-1)
        return DistributionalDiscreteActionValue(probs, self.z_values)


class DistributionalFCStateQFunctionWithDiscreteAction(
    DistributionalSingleModelStateQFunctionWithDiscreteAction
):
    """Fully connected distributional Q-function for discrete actions."""

    def __init__(
        self,
        obs_dim: int,
        n_actions: int,
        z_values: np.ndarray,
        hidden_sizes: tuple,
        activation=F.relu,
    ):
        num_atoms = len(z_values)
        output_size = n_actions * num_atoms
        mlp = MLP(
            [obs_dim] + list(hidden_sizes),
            output_size,
            activation=activation,
            output_activation=None,
        )
        super().__init__(mlp, z_values)


class FCLSTMStateQFunction(Link):
    """FC + LSTM Q-function for discrete actions."""

    def __init__(
        self,
        obs_dim: int,
        n_actions: int,
        hidden_sizes: tuple,
        lstm_hidden_size: int,
    ):
        super().__init__()
        self.mlp = MLP(
            [obs_dim] + list(hidden_sizes),
            lstm_hidden_size,
            activation=F.relu,
            output_activation=None,
        )
        self.lstm = L.LSTM(
            input_size=lstm_hidden_size, hidden_size=lstm_hidden_size
        )
        self.out = L.Linear(lstm_hidden_size, n_actions)

    def __call__(self, obs):
        if not isinstance(obs, Variable):
            obs = Variable(obs)
        h = self.mlp(obs)
        h, c = self.lstm(h)
        q_values = self.out(h)
        return DiscreteActionValue(q_values)


class FCQuadraticStateQFunction(Link):
    """Quadratic Q-function for continuous actions with FC backbone."""

    def __init__(
        self,
        obs_dim: int,
        action_dim: int,
        hidden_sizes: tuple,
        activation=F.relu,
        min_action: np.ndarray = None,
        max_action: np.ndarray = None,
    ):
        super().__init__()
        self.action_dim = action_dim
        self.min_action = min_action
        self.max_action = max_action
        self.hidden = MLP(
            [obs_dim] + list(hidden_sizes),
            hidden_sizes[-1],
            activation=activation,
            output_activation=None,
        )
        self.mu = L.Linear(hidden_sizes[-1], action_dim)
        self.mat_diag = L.Linear(hidden_sizes[-1], action_dim)
        self.mat_non_diag = L.Linear(hidden_sizes[-1], action_dim * (action_dim - 1) // 2)
        self.bias = L.Linear(hidden_sizes[-1], 1)

    def _build_lower_triangular(self, diag, off_diag):
        batch, dim = diag.shape
        L_mat = F.zeros((batch, dim, dim), dtype=diag.dtype)
        idx = 0
        for i in range(dim):
            for j in range(i + 1):
                if i == j:
                    L_mat = F.set_subtensor(L_mat[:, i, j], diag[:, i])
                else:
                    L_mat = F.set_subtensor(L_mat[:, i, j], off_diag[:, idx])
                    idx += 1
        return L_mat

    def __call__(self, obs, action):
        if not isinstance(obs, Variable):
            obs = Variable(obs)
        if not isinstance(action, Variable):
            action = Variable(action)

        h = self.hidden(obs)
        mu = self.mu(h)
        mat_diag = self.mat_diag(h)
        mat_non_diag = self.mat_non_diag(h)
        bias = self.bias(h).squeeze(axis=1)

        if self.min_action is not None and self.max_action is not None:
            mu = scale_by_tanh(mu, self.min_action, self.max_action)

        L_mat = self._build_lower_triangular(mat_diag, mat_non_diag)
        A_mat = F.batch_matmul(L_mat, L_mat.transpose((0, 2, 1)))  # positive definite
        diff = action - mu
        diff = F.expand_dims(diff, axis=2)  # (B, d, 1)
        diff_T = F.transpose(diff, (0, 2, 1))  # (B, 1, d)
        inner = F.batch_matmul(F.batch_matmul(diff_T, A_mat), diff)  # (B,1,1)
        value = -0.5 * F.reshape(inner, (-1,)) + bias
        return value


class FCBNQuadraticStateQFunction(FCQuadraticStateQFunction):
    """Quadratic Q-function with batch-normalized FC backbone."""

    def __init__(
        self,
        obs_dim: int,
        action_dim: int,
        hidden_sizes: tuple,
        activation=F.relu,
        min_action: np.ndarray = None,
        max_action: np.ndarray = None,
    ):
        super().__init__(
            obs_dim,
            action_dim,
            hidden_sizes,
            activation,
            min_action,
            max_action,
        )
        # Replace hidden MLP with batch-normalized version
        bn_hidden = []
        for size in hidden_sizes:
            bn_hidden.append(L.BatchNormalization(size))
            bn_hidden.append(L.Linear(size, size, nobias=True))
        self.hidden = L.Sequential(*bn_hidden)
```