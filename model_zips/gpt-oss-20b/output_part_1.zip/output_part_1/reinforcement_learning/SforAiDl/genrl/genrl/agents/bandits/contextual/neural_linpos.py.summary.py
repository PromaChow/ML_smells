import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import torch.distributions as dist
import numpy as np

class DataBasedBandit:
    """Simple placeholder bandit with contextual features."""
    def __init__(self, n_actions: int, context_dim: int):
        self.n_actions = n_actions
        self.context_dim = context_dim

    def get_random_context(self):
        return torch.randn(self.context_dim)

class TransitionDB:
    """Database for storing transitions."""
    def __init__(self):
        self.contexts = []
        self.actions = []
        self.rewards = []
        self.latents = []

    def add(self, context, action, reward, latent=None):
        self.contexts.append(context)
        self.actions.append(action)
        self.rewards.append(reward)
        if latent is not None:
            self.latents.append(latent)

    def get_all(self):
        return torch.stack(self.contexts), torch.tensor(self.actions), torch.tensor(self.rewards)

    def get_by_action(self, action_idx):
        indices = [i for i, a in enumerate(self.actions) if a == action_idx]
        if not indices:
            return None, None
        latents = torch.stack([self.latents[i] for i in indices])
        rewards = torch.tensor([self.rewards[i] for i in indices])
        return latents, rewards

class NeuralBanditModel(nn.Module):
    """Feedforward neural network mapping context to latent representation."""
    def __init__(self, input_dim, hidden_dims, output_dim, lr=1e-3, dropout=False, eval_with_dropout=False):
        super().__init__()
        layers = []
        last_dim = input_dim
        for h in hidden_dims:
            layers.append(nn.Linear(last_dim, h))
            layers.append(nn.ReLU())
            last_dim = h
        self.feature_extractor = nn.Sequential(*layers)
        self.latent_layer = nn.Linear(last_dim, output_dim)
        self.dropout = nn.Dropout(0.5) if dropout else None
        self.eval_with_dropout = eval_with_dropout
        self.optimizer = optim.Adam(self.parameters(), lr=lr)

    def forward(self, x):
        x = self.feature_extractor(x)
        if self.dropout:
            x = self.dropout(x)
        return self.latent_layer(x)

    def train_on_data(self, contexts, rewards, epochs=5, batch_size=32, grad_clip=5.0):
        dataset = torch.utils.data.TensorDataset(contexts, rewards)
        loader = torch.utils.data.DataLoader(dataset, batch_size=batch_size, shuffle=True)
        self.train()
        for _ in range(epochs):
            for batch_ctx, batch_rwd in loader:
                self.optimizer.zero_grad()
                latent = self.forward(batch_ctx)
                loss = F.mse_loss(latent, batch_rwd.unsqueeze(-1))
                loss.backward()
                nn.utils.clip_grad_norm_(self.parameters(), grad_clip)
                self.optimizer.step()

class NeuralLinearPosteriorAgent:
    def __init__(
        self,
        bandit: DataBasedBandit,
        init_pulls: int = 3,
        hidden_dims: list = [50, 50],
        lambda_prior: float = 0.25,
        a0: float = 6.0,
        b0: float = 6.0,
        lr: float = 1e-3,
        grad_clip: float = 5.0,
        dropout: bool = False,
        eval_with_dropout: bool = True,
        nn_update_ratio: int = 100,
    ):
        self.bandit = bandit
        self.n_actions = bandit.n_actions
        self.context_dim = bandit.context_dim
        self.latent_dim = hidden_dims[-1]
        self.init_pulls = init_pulls
        self.lambda_prior = lambda_prior
        self.a0 = a0
        self.b0 = b0
        self.nn_update_ratio = nn_update_ratio

        self.model = NeuralBanditModel(
            input_dim=self.context_dim,
            hidden_dims=hidden_dims,
            output_dim=self.latent_dim,
            lr=lr,
            dropout=dropout,
            eval_with_dropout=eval_with_dropout,
        )

        self.mu = torch.zeros(self.n_actions, self.latent_dim + 1)
        self.cov = torch.eye(self.latent_dim + 1) / self.lambda_prior
        self.inv_cov = torch.inverse(self.cov)
        self.a = torch.full((self.n_actions,), a0)
        self.b = torch.full((self.n_actions,), b0)

        self.db = TransitionDB()
        self.latent_db = TransitionDB()

        self.t = 0
        self.update_count = 0

    def _sample_beta(self, action_idx):
        # Sample noise variance
        gamma_dist = dist.Gamma(self.a[action_idx], 1.0 / self.b[action_idx])
        sigma2 = 1.0 / gamma_dist.sample()
        # Sample regression coefficients
        try:
            mvn = dist.MultivariateNormal(self.mu[action_idx], self.cov)
            beta = mvn.sample()
        except RuntimeError:
            # Fall back to diagonal covariance
            diag_cov = torch.diag(self.cov.diag())
            mvn = dist.MultivariateNormal(self.mu[action_idx], diag_cov)
            beta = mvn.sample()
        return beta, sigma2

    def select_action(self, context: torch.Tensor):
        if self.t < self.init_pulls * self.n_actions:
            action = self.t % self.n_actions
        else:
            self.model.eval()
            z = self.model(context).detach()
            feature = torch.cat([z, torch.ones(1)])
            exp_rewards = torch.zeros(self.n_actions)
            for i in range(self.n_actions):
                beta, _ = self._sample_beta(i)
                exp_rewards[i] = beta @ feature
            action = torch.argmax(exp_rewards).item()
        self.t += 1
        return action

    def update_db(self, context: torch.Tensor, action: int, reward: float):
        self.db.add(context, action, reward, latent=None)
        self.model.eval()
        latent = self.model(context).detach()
        self.latent_db.add(context, action, reward, latent=latent)

    def _train_nn(self):
        ctxs, _ , _ = self.db.get_all()
        if ctxs.shape[0] == 0:
            return
        # Use latent as target to encourage diversity
        targets = torch.randn_like(ctxs[:, :self.latent_dim])  # placeholder
        self.model.train_on_data(ctxs, targets, epochs=3, batch_size=32)

    def _update_bayesian(self):
        for i in range(self.n_actions):
            z, y = self.latent_db.get_by_action(i)
            if z is None:
                continue
            ones = torch.ones(z.size(0), 1)
            X = torch.cat([z, ones], dim=1)  # (N, latent_dim+1)
            inv_cov_i = X.t() @ X + self.lambda_prior * torch.eye(self.latent_dim + 1)
            cov_i = torch.inverse(inv_cov_i)
            mu_i = cov_i @ X.t() @ y
            self.cov[i] = cov_i
            self.mu[i] = mu_i
            self.inv_cov[i] = inv_cov_i
            n = X.size(0)
            self.a[i] = self.a0 + n / 2.0
            y_t_y = (y * y).sum()
            mu_t_inv_cov_mu = mu_i @ inv_cov_i @ mu_i
            self.b[i] = self.b0 + (y_t_y - mu_t_inv_cov_mu) / 2.0

    def step(self, context: torch.Tensor):
        action = self.select_action(context)
        # Simulate reward (placeholder: random)
        reward = torch.randn(1).item()
        self.update_db(context, action, reward)
        if self.t % self.nn_update_ratio == 0:
            self._train_nn()
            self._update_bayesian()
        return action, reward

# Example usage
if __name__ == "__main__":
    bandit = DataBasedBandit(n_actions=5, context_dim=20)
    agent = NeuralLinearPosteriorAgent(bandit)
    for _ in range(200):
        ctx = bandit.get_random_context()
        act, rw = agent.step(ctx)
        print(f"Step {agent.t}: Action {act}, Reward {rw:.3f}")