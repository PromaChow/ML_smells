import numpy as np

def test_game(env, agent, test_episodes: int) -> float:
    reward_games = []
    for _ in range(test_episodes):
        obs = env.reset()
        rewards = 0.0
        done = False
        while not done:
            action = agent.act(obs)
            next_obs, reward, done, _ = env.step(action)
            rewards += reward
            obs = next_obs
        reward_games.append(rewards)
        env.reset()
    if not reward_games:
        return 0.0
    return float(np.mean(reward_games))