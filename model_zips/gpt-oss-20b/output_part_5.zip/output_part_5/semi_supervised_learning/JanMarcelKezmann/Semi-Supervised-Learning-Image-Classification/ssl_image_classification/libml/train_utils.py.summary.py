import tensorflow as tf


def weight_decay(model: tf.keras.Model, decay_rate: float = 0.01, layer_name: str | None = None) -> None:
    """Apply weight decay to trainable variables of a model."""
    for var in model.trainable_variables:
        if layer_name is None or layer_name in var.name:
            var.assign(var * (1.0 - decay_rate))


def ema(original_model: tf.keras.Model, ema_model: tf.keras.Model, ema_decay: float = 0.999) -> None:
    """Update EMA model weights based on the original model."""
    original_vars = original_model.variables
    ema_vars = ema_model.variables
    for orig_var, ema_var in zip(original_vars, ema_vars):
        if orig_var.trainable:
            new_value = (1.0 - ema_decay) * orig_var + ema_decay * ema_var
            ema_var.assign(new_value)
        else:
            ema_var.assign(tf.identity(orig_var))


def linear_rampup(epochs: int, pre_val_iter: int, epoch: int, iteration: int) -> tf.Tensor:
    """Compute a linear ramp‑up value between 0 and 1."""
    total_steps = tf.cast(epochs * pre_val_iter, tf.float32)
    current_step = tf.cast(epoch * pre_val_iter + iteration / pre_val_iter, tf.float32)
    ramp = current_step / total_steps
    return tf.clip_by_value(ramp, 0.0, 1.0)