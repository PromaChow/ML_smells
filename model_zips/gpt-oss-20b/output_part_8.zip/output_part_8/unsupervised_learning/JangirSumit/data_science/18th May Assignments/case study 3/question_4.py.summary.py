import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# 1. Define Data Points
X = [1, 2, 3, 4]
Y = [20, 21, 20.5, 20.8]

# 2. Simple Line Plot
plt.plot(X, Y)
plt.show()

# 3. Configure Line and Markers
plt.plot(X, Y)
plt.grid()
plt.show()

# 4. Rotate X-Axis Labels
plt.plot(X, Y)
plt.setp(plt.gca().get_xticklabels(), rotation=90, horizontalalignment='right')
plt.show()

# 5. Add Axis Labels
plt.plot(X, Y)
plt.xlabel('x')
plt.ylabel('y')
plt.show()

# 6. Attempt to Plot with Error Bars (incorrect)
y_error = [0.12, 0.13, 0.2, 0.1]
try:
    plt.plot(X, Y, yerr=y_error)  # this will raise an error
except TypeError:
    pass  # ignore the error for demonstration purposes

# 7. Set Figure Size and DPI
plt.figure(figsize=(3, 4), dpi=100)

# 8. Adjust Font Size
plt.rcParams.update({'font.size': 14})

# 9. Generate Random Data for Scatter Plot
x_rand = np.random.random(50)
y_rand = np.random.random(50)
plt.scatter(x_rand, y_rand)
plt.show()

# 10. Create DataFrame and Scatter Plot with Age-Based Size
df = pd.DataFrame({
    'preTestScore': np.random.randint(60, 100, 20),
    'postTestScore': np.random.randint(60, 100, 20),
    'age': np.random.randint(18, 65, 20),
    'female': np.random.randint(0, 2, 20)
})

plt.figure()
plt.scatter(df['preTestScore'], df['postTestScore'],
            s=df['age'] * 10, alpha=0.7, label='age')
plt.xlabel('preTestScore')
plt.ylabel('postTestScore')
plt.title('Scatter plot of pre vs post test scores')
plt.legend()
plt.show()

# 11. Scatter Plot with Color Based on Sex
plt.figure()
colors = df['female'].map({0: 'blue', 1: 'red'})
plt.scatter(df['preTestScore'], df['postTestScore'],
            c=colors, alpha=0.5, label='female')
plt.xlabel('preTestScore')
plt.ylabel('postTestScore')
plt.title('Scatter plot colored by sex')
plt.legend()
plt.show()