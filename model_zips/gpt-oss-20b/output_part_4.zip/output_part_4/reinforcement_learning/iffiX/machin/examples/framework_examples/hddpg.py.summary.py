import gym
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import random
from collections import deque
import sys

# Optional import from the Machin library
try:
    from machin.algorithms import HDDPG
except Exception:
    HDDPG = None

# Environment setup
env = gym.make("Pendulum-v0")
obs_dim = env.observation_space.shape[0]          # 3
act_dim = env.action_space.shape[0]              # 1
action_range = env.action_space.high[0]          # 2

max_episodes = 1000
max_steps = 200
noise_mean = 0.0
noise_std = 0.2
noise_mode = "normal"

solved_reward = -150
solved_repeat = 5

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
torch.manual_seed(0)
np.random.seed(0)
random.seed(0)

# Neural network definitions
class Actor(nn.Module):
    def __init__(self, obs_dim, act_dim, action_range):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim, 16),
            nn.ReLU(),
            nn.Linear(16, 16),
            nn.ReLU(),
            nn.Linear(16, act_dim),
            nn.Tanh(),
        )
        self.action_range = action_range

    def forward(self, state):
        return self.action_range * self.net(state)

class Critic(nn.Module):
    def __init__(self, obs_dim, act_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim + act_dim, 16),
            nn.ReLU(),
            nn.Linear(16, 16),
            nn.ReLU(),
            nn.Linear(16, 1),
        )

    def forward(self, state, action):
        x = torch.cat([state, action], dim=-1)
        return self.net(x)

# Instantiate networks and target copies
actor = Actor(obs_dim, act_dim, action_range).to(device)
critic = Critic(obs_dim, act_dim).to(device)
target_actor = Actor(obs_dim, act_dim, action_range).to(device)
target_critic = Critic(obs_dim, act_dim).to(device)

target_actor.load_state_dict(actor.state_dict())
target_critic.load_state_dict(critic.state_dict())

actor_optimizer = optim.Adam(actor.parameters(), lr=1e-4)
critic_optimizer = optim.Adam(critic.parameters(), lr=1e-3)
mse_loss = nn.MSELoss(reduction="sum")

# Replay buffer
class ReplayBuffer:
    def __init__(self, capacity):
        self.capacity = capacity
        self.buffer = deque(maxlen=capacity)

    def add(self, state, action, reward, next_state, done):
        self.buffer.append((state, action, reward, next_state, done))

    def sample(self, batch_size):
        batch = random.sample(self.buffer, batch_size)
        states, actions, rewards, next_states, dones = map(np.array, zip(*batch))
        return (
            torch.tensor(states, dtype=torch.float32).to(device),
            torch.tensor(actions, dtype=torch.float32).to(device),
            torch.tensor(rewards, dtype=torch.float32).unsqueeze(1).to(device),
            torch.tensor(next_states, dtype=torch.float32).to(device),
            torch.tensor(dones, dtype=torch.float32).unsqueeze(1).to(device),
        )

    def __len__(self):
        return len(self.buffer)

buffer = ReplayBuffer(100000)
batch_size = 64
gamma = 0.99
tau = 0.005

def soft_update(target, source, tau):
    for t, s in zip(target.parameters(), source.parameters()):
        t.data.copy_(t.data * (1 - tau) + s.data * tau)

# Training loop
smoothed_reward = 0.0
solved_counter = 0

for episode in range(1, max_episodes + 1):
    state_np = env.reset()
    state = torch.tensor(state_np, dtype=torch.float32).unsqueeze(0).to(device)
    episode_reward = 0.0
    steps_in_episode = 0

    for _ in range(max_steps):
        with torch.no_grad():
            action = actor(state)
        noise = torch.randn(act_dim, device=device) * noise_std + noise_mean
        noisy_action = action + noise
        noisy_action = torch.clamp(noisy_action, -action_range, action_range)
        action_np = noisy_action.cpu().numpy().flatten()
        next_state_np, reward, done, _ = env.step(action_np)
        next_state = torch.tensor(next_state_np, dtype=torch.float32).unsqueeze(0).to(device)
        episode_reward += reward

        buffer.add(state.cpu().numpy(), noisy_action.cpu().numpy(), reward, next_state_np, done)

        state = next_state
        steps_in_episode += 1

        if done:
            break

    smoothed_reward = 0.9 * smoothed_reward + 0.1 * episode_reward
    print(f"Episode {episode:4d} | Reward: {episode_reward:8.2f} | Smoothed: {smoothed_reward:8.2f}")

    if episode > 100 and len(buffer) >= batch_size:
        for _ in range(steps_in_episode):
            states_b, actions_b, rewards_b, next_states_b, dones_b = buffer.sample(batch_size)

            with torch.no_grad():
                next_actions = target_actor(next_states_b)
                target_q = target_critic(next_states_b, next_actions)
                y = rewards_b + gamma * (1 - dones_b) * target_q

            q_vals = critic(states_b, actions_b)
            critic_loss = mse_loss(q_vals, y)
            critic_optimizer.zero_grad()
            critic_loss.backward()
            critic_optimizer.step()

            actor_loss = -critic(states_b, actor(states_b)).mean()
            actor_optimizer.zero_grad()
            actor_loss.backward()
            actor_optimizer.step()

            soft_update(target_actor, actor, tau)
            soft_update(target_critic, critic, tau)

    if smoothed_reward >= solved_reward:
        solved_counter += 1
        if solved_counter >= solved_repeat:
            print(f"Solved after {episode} episodes!")
            break
    else:
        solved_counter = 0

env.close()
sys.exit(0)