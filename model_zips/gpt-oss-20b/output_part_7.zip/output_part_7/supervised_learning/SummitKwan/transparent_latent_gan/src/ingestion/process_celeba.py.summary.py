import argparse
import gzip
import os
import shutil
import tarfile
import urllib.request
from pathlib import Path
from typing import List

import numpy as np
from PIL import Image


DATA_ROOT = Path("./data/raw")


def download(url: str, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)

    def _reporthook(block_num, block_size, total_size):
        if total_size > 0:
            percent = block_num * block_size * 100 / total_size
            print(f"\rDownloading {dest.name}: {percent:.1f}%", end="")

    urllib.request.urlretrieve(url, dest.as_posix(), reporthook=_reporthook)
    print("\nDownload complete.")


def unzip(zip_path: Path, extract_to: Path) -> None:
    with zipfile.ZipFile(zip_path, "r") as zf:
        zf.extractall(extract_to)
    zip_path.unlink()


def reshape_celebA(celeb_dir: Path) -> None:
    image_paths = list(celeb_dir.rglob("*.jpg")) + list(celeb_dir.rglob("*.jpeg")) + list(
        celeb_dir.rglob("*.png")
    )
    images = []
    for img_path in image_paths:
        try:
            with Image.open(img_path) as img:
                img = img.convert("RGB")
                img = img.resize((64, 64), Image.LANCZOS)
                images.append(np.array(img))
        except Exception:
            continue
    if images:
        data = np.stack(images, axis=0)
        out_path = celeb_dir / "celeb_64.npy"
        np.save(out_path, data)
        print(f"Saved {len(images)} images to {out_path}")


def process_celebA() -> None:
    celeb_dir = DATA_ROOT / "celebA"
    if celeb_dir.exists():
        print("CelebA directory already exists. Skipping download.")
        return

    zip_url = (
        "https://www.dropbox.com/sh/8oqt9vytwxb3s4r/AADIKlz8PR9zr6Y20qbkunrba/"
        "Img/img_align_celeba.zip?dl=1&pv=1"
    )
    zip_path = DATA_ROOT / "img_align_celeba.zip"
    download(zip_url, zip_path)

    extract_dir = DATA_ROOT / "Img"
    with zipfile.ZipFile(zip_path, "r") as zf:
        zf.extractall(DATA_ROOT)

    extracted_subdir = DATA_ROOT / "Img" / "img_align_celeba"
    extracted_subdir.rename(celeb_dir)
    zip_path.unlink()
    print(f"Renamed extracted folder to {celeb_dir}")

    reshape_celebA(celeb_dir)


def process_cifar() -> None:
    cifar_dir = DATA_ROOT / "cifar-10-batches-py"
    if cifar_dir.exists():
        print("CIFAR directory already exists. Skipping download.")
        return

    tar_url = "https://www.cs.toronto.edu/~kriz/cifar-10-python.tar.gz"
    tar_path = DATA_ROOT / "cifar-10-python.tar.gz"
    download(tar_url, tar_path)

    with tarfile.open(tar_path, "r:gz") as tar:
        tar.extractall(DATA_ROOT)
    tar_path.unlink()
    print(f"Extracted CIFAR dataset to {cifar_dir}")


def process_mnist() -> None:
    mnist_dir = DATA_ROOT / "mnist"
    if mnist_dir.exists():
        print("MNIST directory already exists. Skipping download.")
        return
    mnist_dir.mkdir(parents=True, exist_ok=True)

    filenames = [
        "train-images-idx3-ubyte.gz",
        "train-labels-idx1-ubyte.gz",
        "t10k-images-idx3-ubyte.gz",
        "t10k-labels-idx1-ubyte.gz",
    ]
    base_url = "http://yann.lecun.com/exdb/mnist/"

    for fn in filenames:
        url = base_url + fn
        gz_path = mnist_dir / fn
        download(url, gz_path)

        out_path = mnist_dir / fn.replace(".gz", "")
        with gzip.open(gz_path, "rb") as f_in, open(out_path, "wb") as f_out:
            shutil.copyfileobj(f_in, f_out)
        gz_path.unlink()
        print(f"Decompressed {fn} to {out_path}")


def prepare_data_dir() -> None:
    DATA_ROOT.mkdir(parents=True, exist_ok=True)


def main() -> None:
    parser = argparse.ArgumentParser(description="Download and prepare datasets.")
    parser.add_argument(
        "datasets",
        nargs="+",
        choices=["celebA", "cifar", "mnist"],
        help="Datasets to download and process.",
    )
    args = parser.parse_args()

    prepare_data_dir()

    if "celebA" in args.datasets:
        process_celebA()
    if "cifar" in args.datasets:
        process_cifar()
    if "mnist" in args.datasets:
        process_mnist()


if __name__ == "__main__":
    main()