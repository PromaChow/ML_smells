import os
import sys
import numpy as np
import pybind11
from setuptools import setup, Extension
from setuptools.command.build_ext import build_ext

__version__ = '0.2.1'

include_dirs = [
    pybind11.get_include(),
    np.get_include(),
    os.path.abspath('./soinn')
]

source_files = [os.path.abspath('./python/soinn.cpp')]

extension = Extension(
    name='soinn',
    sources=source_files,
    include_dirs=include_dirs,
    language='c++'
)

def cpp_flag(compiler):
    """Return the flag to enforce C++14."""
    return '-std=c++14'

class BuildExt(build_ext):
    def build_extensions(self):
        compiler = self.compiler
        is_msvc = compiler.compiler_type == 'msvc'
        is_unix = compiler.compiler_type in ('unix', 'mingw32')
        is_macos = sys.platform == 'darwin'

        compile_args = []
        link_args = []

        if is_msvc:
            compile_args.extend(['/EHsc', '/openmp', '/O2'])
        elif is_unix:
            compile_args.extend(['-O3', '-march=native'])
            if is_macos:
                compile_args.extend(['-stdlib=libc++', '-mmacosx-version-min=10.7'])
            else:
                compile_args.extend(['-fopenmp', '-pthread'])
        else:
            # Fallback for other compilers
            compile_args.append(cpp_flag(compiler))

        for ext in self.extensions:
            ext.define_macros.append(('VERSION_INFO', f"'{self.distribution.get_version()}'"))
            ext.extra_compile_args = ext.extra_compile_args or []
            ext.extra_compile_args.extend(compile_args)
            ext.extra_compile_args.append(cpp_flag(compiler))
            ext.extra_link_args = ext.extra_link_args or []
            ext.extra_link_args.extend(link_args)

        build_ext.build_extensions(self)

setup(
    name='soinn',
    version=__version__,
    description='Python package with a C++ extension for the soinn library.',
    author='Author Name',
    url='https://github.com/author/soinn',
    ext_modules=[extension],
    install_requires=['numpy'],
    cmdclass={'build_ext': BuildExt},
    zip_safe=False
)