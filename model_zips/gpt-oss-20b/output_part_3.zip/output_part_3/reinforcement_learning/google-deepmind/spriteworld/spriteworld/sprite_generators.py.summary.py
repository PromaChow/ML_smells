import itertools
import numpy as np
import sprite
from typing import Callable, Iterable, List, Optional, Sequence, Any


def generate_sprites(
    factor_dist: Any,
    num_sprites: Any,
) -> Callable[[], List[sprite.Sprite]]:
    """
    Create a callable that generates a list of Sprite objects.

    Parameters
    ----------
    factor_dist : Any
        An object with a ``sample()`` method returning keyword arguments for Sprite.
    num_sprites : int or Callable[[], int]
        Number of sprites to generate or a callable returning that number.

    Returns
    -------
    Callable[[], List[sprite.Sprite]]
        A function that when called returns a list of generated Sprite instances.
    """

    def _generate() -> List[sprite.Sprite]:
        n = num_sprites() if callable(num_sprites) else num_sprites
        return [sprite.Sprite(**factor_dist.sample()) for _ in range(n)]

    return _generate


def chain_generators(
    *sprite_generators: Callable[[], List[sprite.Sprite]]
) -> Callable[[], List[sprite.Sprite]]:
    """
    Chain multiple sprite generators into a single generator.

    Parameters
    ----------
    *sprite_generators : Callable[[], List[sprite.Sprite]]
        Functions that each return a list of Sprite objects.

    Returns
    -------
    Callable[[], List[sprite.Sprite]]
        A function that returns a flattened list of all sprites from the input generators.
    """

    def _generate() -> List[sprite.Sprite]:
        lists = [gen() for gen in sprite_generators]
        return list(itertools.chain.from_iterable(lists))

    return _generate


def sample_generator(
    sprite_generators: Iterable[Callable[[], List[sprite.Sprite]]],
    p: Optional[Sequence[float]] = None,
) -> Callable[[], List[sprite.Sprite]]:
    """
    Randomly select a sprite generator based on provided probabilities.

    Parameters
    ----------
    sprite_generators : Iterable[Callable[[], List[sprite.Sprite]]]
        Iterable of sprite generator callables.
    p : Sequence[float], optional
        Probabilities for each generator. Must sum to 1. If None, uniform distribution is used.

    Returns
    -------
    Callable[[], List[sprite.Sprite]]
        A function that selects a generator and returns its sprite list.
    """

    gens = list(sprite_generators)
    if p is not None:
        p = np.array(p, dtype=float)
        p = p / p.sum()  # normalize

    def _generate() -> List[sprite.Sprite]:
        idx = np.random.choice(len(gens), p=p)
        return gens[idx]()

    return _generate


def shuffle(
    sprite_generator: Callable[[], List[sprite.Sprite]]
) -> Callable[[], List[sprite.Sprite]]:
    """
    Shuffle the order of sprites produced by a generator.

    Parameters
    ----------
    sprite_generator : Callable[[], List[sprite.Sprite]]
        A function that returns a list of Sprite objects.

    Returns
    -------
    Callable[[], List[sprite.Sprite]]
        A function that returns the shuffled list of sprites.
    """

    def _generate() -> List[sprite.Sprite]:
        sprites = sprite_generator()
        indices = np.arange(len(sprites))
        np.random.shuffle(indices)
        return [sprites[i] for i in indices]

    return _generate

__all__ = [
    "generate_sprites",
    "chain_generators",
    "sample_generator",
    "shuffle",
]