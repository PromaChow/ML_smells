import tensorflow as tf
import tensorflow_probability as tfp

def weak_augment(images):
    """Simple weak augmentation: random horizontal flip and random crop."""
    images = tf.image.random_flip_left_right(images)
    images = tf.image.random_crop(images, size=tf.shape(images))
    return images

def sharpen(probs, T):
    """Sharpen probabilities with temperature T."""
    p_t = probs ** (1.0 / T)
    return p_t / tf.reduce_sum(p_t, axis=-1, keepdims=True)

def mixup(inputs, targets, beta):
    """Apply mixup with beta-distributed coefficient."""
    batch_size = tf.shape(inputs)[0]
    lam = tfp.distributions.Beta(beta, beta).sample()
    lam = tf.maximum(lam, 1.0 - lam)
    index = tf.random.shuffle(tf.range(batch_size))
    mixed_inputs = lam * inputs + (1 - lam) * tf.gather(inputs, index)
    mixed_targets = lam * targets + (1 - lam) * tf.gather(targets, index)
    return mixed_inputs, mixed_targets

def ssl_loss_mixmatch(labels_x, logits_x, labels_u, logits_u):
    """Compute MixMatch loss: CE for labeled + MSE for unlabeled."""
    ce = tf.keras.losses.CategoricalCrossentropy(from_logits=True)
    mse = tf.keras.losses.MeanSquaredError()
    loss_x = ce(labels_x, logits_x)
    loss_u = mse(labels_u, tf.nn.softmax(logits_u, axis=-1))
    return loss_x + loss_u

@tf.function
def mixmatch_step(model, x, y, u, K=2, T=0.5, beta=0.75):
    """One MixMatch training step."""
    # 1. Augment labeled data
    x_aug = weak_augment(x)  # shape [batch, H, W, C]

    # 2. Augment unlabeled data K times
    u_aug = tf.stack([weak_augment(u) for _ in range(K)], axis=0)  # [K, batch, H, W, C]

    # 3. Predict logits for each augmented unlabeled sample
    logits_u = tf.map_fn(
        lambda u_k: model(u_k, training=True),
        u_aug,
        fn_output_signature=tf.float32
    )  # [K, batch, num_classes]

    # 4. Average logits, convert to probs, stop gradient, sharpen
    avg_logits = tf.reduce_mean(logits_u, axis=0)  # [batch, num_classes]
    probs = tf.nn.softmax(avg_logits, axis=-1)
    probs = tf.stop_gradient(probs)
    sharpened = sharpen(probs, T)  # [batch, num_classes]

    # 5. Concatenate K augmented unlabeled samples
    U = tf.reshape(u_aug, [K * tf.shape(u)[0], *u.shape[1:]])  # [K*batch, H, W, C]
    u_labels = tf.reshape(sharpened, [K * tf.shape(u)[0], -1])  # [K*batch, num_classes]

    # 6. Combine labeled and unlabeled data
    X_aug_U = tf.concat([x_aug, U], axis=0)  # [ (K+1)*batch, H, W, C]
    y_u_aug_labels = tf.concat([y, u_labels], axis=0)  # [ (K+1)*batch, num_classes]

    # 7. Shuffle
    indices = tf.random.shuffle(tf.range(tf.shape(X_aug_U)[0]))
    X_aug_U = tf.gather(X_aug_U, indices)
    y_u_aug_labels = tf.gather(y_u_aug_labels, indices)

    # 8. Mixup
    mixed_inputs, mixed_labels = mixup(X_aug_U, y_u_aug_labels, beta)

    # 9. Split mixed results back into K+1 parts
    mixed_parts = tf.split(mixed_inputs, K + 1, axis=0)
    label_parts = tf.split(mixed_labels, K + 1, axis=0)

    # 10. Forward pass for mixed inputs
    logits = tf.map_fn(
        lambda inp: model(inp, training=True),
        mixed_inputs,
        fn_output_signature=tf.float32
    )  # [(K+1)*batch, num_classes]
    logits_parts = tf.split(logits, K + 1, axis=0)

    # 11. Compute losses
    labels_x = label_parts[0]          # labeled part
    logits_x = logits_parts[0]          # logits for labeled part
    labels_u = tf.concat(label_parts[1:], axis=0)  # unlabeled part
    logits_u = tf.concat(logits_parts[1:], axis=0)  # logits for unlabeled part

    loss = ssl_loss_mixmatch(labels_x, logits_x, labels_u, logits_u)
    return loss
