import pandas as pd
import matplotlib.pyplot as plt
from scipy.cluster.hierarchy import linkage, dendrogram
from scipy.spatial.distance import squareform


def scatter_clusters(x_pos, y_pos, clusters, titles):
    """
    Plot scatter clusters with diamond markers and annotate points.
    """
    cluster_colors = {
        0: "#e41a1c",
        1: "#377eb8",
        2: "#4daf4a",
        3: "#984ea3",
        4: "#ff7f00",
        5: "#ffff33",
    }

    cluster_names = {k: "" for k in cluster_colors.keys()}

    df = pd.DataFrame(
        {
            "x": x_pos,
            "y": y_pos,
            "label": clusters,
            "title": titles,
        }
    )
    groups = df.groupby("label")

    fig, ax = plt.subplots(figsize=(10, 8))
    fig.patch.set_facecolor("#e6f7ff")

    for label, group in groups:
        ax.scatter(
            group["x"],
            group["y"],
            marker="D",
            linestyle="solid",
            edgecolor="black",
            facecolor=cluster_colors.get(label, "#000000"),
            label=cluster_names.get(label, ""),
        )

    ax.set_aspect("equal")
    ax.set_xticks([])
    ax.set_yticks([])

    if cluster_names:
        ax.legend(loc="best")

    for _, row in df.iterrows():
        ax.text(
            row["x"],
            row["y"],
            row["title"],
            fontsize=9,
            ha="center",
            va="center",
        )

    plt.show()


def dendogram(similarity_matrix, book_names):
    """
    Plot a hierarchical dendrogram using Ward's linkage.
    """
    # Convert similarity to distance
    distance_matrix = 1 - similarity_matrix
    condensed = squareform(distance_matrix)
    linkage_matrix = linkage(condensed, method="ward")

    fig, ax = plt.subplots(figsize=(15, 20))
    dendrogram(
        linkage_matrix,
        orientation="right",
        labels=book_names,
        ax=ax,
        leaf_font_size=10,
    )

    ax.set_xticks([])
    ax.tick_params(axis="y", which="both", length=0, width=0)
    ax.tick_params(axis="x", which="both", bottom=False, top=False, labelbottom=False)

    plt.tight_layout()
    plt.show()
