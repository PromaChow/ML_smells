import numpy as np

# Weight and bias initializations (random for demonstration purposes)
np.random.seed(42)
weights_dense1_w = np.random.randn(784, 128)
weights_dense1_b = np.random.randn(128)

weights_dense2_w = np.random.randn(128, 128)
weights_dense2_b = np.random.randn(128)

weights_final_w = np.random.randn(128, 10)
weights_final_b = np.random.randn(10)

def relu(x: np.ndarray) -> np.ndarray:
    return np.maximum(0, x)

def softmax(x: np.ndarray) -> np.ndarray:
    exps = np.exp(x - np.max(x, axis=1, keepdims=True))
    return exps / np.sum(exps, axis=1, keepdims=True)

def forward_pass(input_data: np.ndarray) -> np.ndarray:
    """
    Performs a forward pass through a three-layer dense neural network.
    Parameters:
        input_data (np.ndarray): Input array of shape (batch_size, 784).
    Returns:
        np.ndarray: Class probabilities of shape (batch_size, 10).
    """
    # First dense layer
    hidden1 = relu(input_data @ weights_dense1_w + weights_dense1_b)

    # Second dense layer
    hidden2 = relu(hidden1 @ weights_dense2_w + weights_dense2_b)

    # Final dense layer
    logits = hidden2 @ weights_final_w + weights_final_b
    output = softmax(logits)

    return output

if __name__ == "__main__":
    # Example usage with a batch of 64 samples
    batch_size = 64
    input_data = np.random.randn(batch_size, 784)
    predictions = forward_pass(input_data)
    print("Predictions shape:", predictions.shape)
    print("First sample probabilities:", predictions[0])