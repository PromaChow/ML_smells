import numpy as np
from sklearn.metrics import accuracy_score
from sklearn.linear_model import LogisticRegression

class SelfLearningModel:
    def __init__(self, basemodel, max_iter=10, prob_threshold=0.9):
        self.basemodel = basemodel
        self.max_iter = max_iter
        self.prob_threshold = prob_threshold
        self._platt = None
        self.is_platt = False

    def _get_proba(self, X):
        if hasattr(self.basemodel, "predict_proba"):
            return self.basemodel.predict_proba(X)
        else:
            preds = self.basemodel.predict(X)
            if self._platt is None:
                # Fallback uniform probabilities
                return np.vstack([np.full(len(preds), 0.5), np.full(len(preds), 0.5)]).T
            return self._platt.predict_proba(preds.reshape(-1, 1))

    def fit(self, X, y):
        X = np.asarray(X)
        y = np.asarray(y)

        labeled_mask = y != -1
        unlabeled_mask = y == -1

        labeledX = X[labeled_mask]
        labeledy = y[labeled_mask]
        unlabeledX = X[unlabeled_mask]

        self.basemodel.fit(labeledX, labeledy)

        if not hasattr(self.basemodel, "predict_proba"):
            pred_labels = self.basemodel.predict(labeledX)
            self._platt = LogisticRegression(solver="lbfgs", max_iter=100)
            self._platt.fit(pred_labels.reshape(-1, 1), labeledy)
            self.is_platt = True

        if unlabeledX.size > 0:
            unlabeledy = self.basemodel.predict(unlabeledX)
            unlabeledprob = self._get_proba(unlabeledX)
            prev_y = None
            for _ in range(self.max_iter):
                if prev_y is not None and np.array_equal(prev_y, unlabeledy):
                    break
                mask = (unlabeledprob[:, 0] > self.prob_threshold) | (
                    unlabeledprob[:, 1] > self.prob_threshold
                )
                if not np.any(mask):
                    break
                newX = np.vstack([labeledX, unlabeledX[mask]])
                newy = np.concatenate([labeledy, unlabeledy[mask]])
                self.basemodel.fit(newX, newy)
                if self.is_platt:
                    pred_labels_new = self.basemodel.predict(newX)
                    self._platt.fit(pred_labels_new.reshape(-1, 1), newy)
                unlabeledy = self.basemodel.predict(unlabeledX)
                unlabeledprob = self._get_proba(unlabeledX)
                prev_y = unlabeledy.copy()
        return self

    def predict(self, X):
        return self.basemodel.predict(X)

    def predict_proba(self, X):
        return self._get_proba(X)

    def score(self, X, y):
        preds = self.predict(X)
        return accuracy_score(y, preds)