import math
import torch


class AdditiveOU:
    def __init__(self, mu, theta, sigma, start_with_mu=True):
        """
        Additive Ornstein-Uhlenbeck process for exploration noise.

        Args:
            mu (float): Mean of the process.
            theta (float): Friction coefficient pulling the process toward mu.
            sigma (float): Scale of the noise.
            start_with_mu (bool): If True, initialize the process at mu without noise.
        """
        self.mu = float(mu)
        self.theta = float(theta)
        self.sigma = float(sigma)
        self.start_with_mu = bool(start_with_mu)
        self.ou_state = None
        self.t = 0

    def evolve(self):
        """
        Update the OU state using the dynamics:
            dx = theta * (mu - x) + sigma * dW
        where dW ~ N(0, 1) * sigma.
        """
        # Current state
        x = self.ou_state
        # Pull toward mean
        drift = self.theta * (self.mu - x)
        # Noise term
        noise = self.sigma * torch.randn_like(x)
        # Update state
        self.ou_state = x + drift + noise

    def select_action(self, greedy_action_func):
        """
        Select an action by adding OU noise to the greedy action.

        Args:
            greedy_action_func (callable): Function that returns the greedy action tensor.

        Returns:
            torch.Tensor: Noisy action.
        """
        # Obtain greedy action
        a = greedy_action_func()
        if self.ou_state is None:
            # Initialize OU state
            if self.start_with_mu:
                self.ou_state = torch.full_like(a, self.mu, dtype=a.dtype, device=a.device)
            else:
                sigma_stable = self.sigma / math.sqrt(2 * self.theta - self.theta ** 2)
                self.ou_state = torch.randn_like(a, dtype=a.dtype, device=a.device) * sigma_stable + self.mu
        else:
            self.evolve()

        # Compute noisy action
        noisy_action = a + self.ou_state

        # Logging
        print(f"t={self.t}, ou_state={self.ou_state}")

        # Update timestep
        self.t += 1

        return noisy_action

    def __repr__(self):
        return (f"{self.__class__.__name__}(mu={self.mu}, "
                f"theta={self.theta}, sigma={self.sigma})")
