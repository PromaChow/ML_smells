import numpy as np
import chainerrl
import pytest


@pytest.mark.parametrize('action_size', [1, 3])
@pytest.mark.parametrize('sigma_type', ['scalar', 'ndarray'])
def test_additive_ou(action_size, sigma_type):
    np.random.seed(0)

    def greedy_action_func():
        return np.zeros(action_size)

    if sigma_type == 'scalar':
        sigma = np.random.rand()
    else:
        sigma = np.random.rand(action_size)

    theta = np.random.rand()

    explorer = chainerrl.explorers.AdditiveOU(theta=theta, sigma=sigma)

    print(f'Initial theta: {theta}')
    print(f'Initial sigma ({sigma_type}): {sigma}')

    for t in range(100):
        base_action = greedy_action_func()
        action = explorer.select_action(t, base_action)
        print(f'Time {t}: {action}')
