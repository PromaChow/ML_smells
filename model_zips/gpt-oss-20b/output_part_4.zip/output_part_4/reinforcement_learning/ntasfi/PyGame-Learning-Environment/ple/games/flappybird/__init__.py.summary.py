import pygame
import random
import sys

# ----- Constants -----
SCREEN_WIDTH = 400
SCREEN_HEIGHT = 600
GRAVITY = 0.5
FLAP_VELOCITY = -10
MAX_FALL_SPEED = 10
PIPE_SPEED = 2
PIPE_GAP = 150
PIPE_WIDTH = 80
BASE_HEIGHT = 100
BASE_COLOR = (200, 200, 200)
BACKGROUND_COLOR = (135, 206, 235)
BIRD_ANIMATION_INTERVAL = 15
BASE_PENALTY = -100
BASE_REWARD = 1
PIPE_REWARD = 10
LIVES_START = 3
FPS = 60

class BirdPlayer:
    def __init__(self, start_pos):
        self.color = (random.randint(50, 255), random.randint(50, 255), random.randint(50, 255))
        self.images = [
            self.create_surface((34, 24), self.color),
            self.create_surface((34, 24), self.color),
            self.create_surface((34, 24), self.color)
        ]
        self.frame = 0
        self.frame_counter = 0
        self.rect = self.images[0].get_rect()
        self.rect.center = start_pos
        self.velocity = 0

    def create_surface(self, size, color):
        surf = pygame.Surface(size, pygame.SRCALPHA)
        pygame.draw.polygon(
            surf,
            color,
            [(0, size[1]), (size[0] / 2, 0), (size[0], size[1])]
        )
        return surf

    def flap(self):
        self.velocity = FLAP_VELOCITY

    def update(self):
        self.velocity += GRAVITY
        if self.velocity > MAX_FALL_SPEED:
            self.velocity = MAX_FALL_SPEED
        self.rect.y += int(self.velocity)
        self.frame_counter += 1
        if self.frame_counter >= BIRD_ANIMATION_INTERVAL:
            self.frame_counter = 0
            self.frame = (self.frame + 1) % 4
            if self.frame == 0:
                self.frame = 1
            if self.frame == 2:
                self.frame = 1

    def draw(self, screen):
        screen.blit(self.images[self.frame], self.rect)

class Pipe:
    def __init__(self, x_offset):
        self.width = PIPE_WIDTH
        self.gap_y = random.randint(100, SCREEN_HEIGHT - 100 - PIPE_GAP)
        self.top_rect = pygame.Rect(0, 0, self.width, self.gap_y)
        self.bottom_rect = pygame.Rect(0, self.gap_y + PIPE_GAP, self.width, SCREEN_HEIGHT - self.gap_y - PIPE_GAP)
        self.rect = pygame.Rect(x_offset, 0, self.width, SCREEN_HEIGHT)
        self.passed = False
        self.image_top = pygame.Surface((self.width, self.gap_y))
        self.image_top.fill((0, 255, 0))
        self.image_bottom = pygame.Surface((self.width, SCREEN_HEIGHT - self.gap_y - PIPE_GAP))
        self.image_bottom.fill((0, 255, 0))

    def reset(self, x_offset):
        self.gap_y = random.randint(100, SCREEN_HEIGHT - 100 - PIPE_GAP)
        self.top_rect = pygame.Rect(0, 0, self.width, self.gap_y)
        self.bottom_rect = pygame.Rect(0, self.gap_y + PIPE_GAP, self.width, SCREEN_HEIGHT - self.gap_y - PIPE_GAP)
        self.rect = pygame.Rect(x_offset, 0, self.width, SCREEN_HEIGHT)
        self.passed = False
        self.image_top = pygame.Surface((self.width, self.gap_y))
        self.image_top.fill((0, 255, 0))
        self.image_bottom = pygame.Surface((self.width, SCREEN_HEIGHT - self.gap_y - PIPE_GAP))
        self.image_bottom.fill((0, 255, 0))

    def update(self):
        self.rect.x -= PIPE_SPEED
        if self.rect.right < 0:
            self.rect.x = SCREEN_WIDTH + random.randint(0, 200)
            self.reset(self.rect.x)

    def draw(self, screen):
        screen.blit(self.image_top, (self.rect.x, 0))
        screen.blit(self.image_bottom, (self.rect.x, self.gap_y + PIPE_GAP))

class Backdrop:
    def __init__(self):
        self.base_rect = pygame.Rect(0, SCREEN_HEIGHT - BASE_HEIGHT, SCREEN_WIDTH, BASE_HEIGHT)
        self.base_x = 0
        self.base_image = pygame.Surface((SCREEN_WIDTH, BASE_HEIGHT))
        self.base_image.fill(BASE_COLOR)

    def update(self):
        self.base_x -= PIPE_SPEED
        if self.base_x <= -SCREEN_WIDTH:
            self.base_x = 0

    def draw(self, screen):
        screen.fill(BACKGROUND_COLOR)
        screen.blit(self.base_image, (self.base_x, SCREEN_HEIGHT - BASE_HEIGHT))
        screen.blit(self.base_image, (self.base_x + SCREEN_WIDTH, SCREEN_HEIGHT - BASE_HEIGHT))

class FlappyBird:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("Flappy Bird")
        self.clock = pygame.time.Clock()
        self.backdrop = Backdrop()
        self.bird = BirdPlayer((50, SCREEN_HEIGHT // 2))
        self.pipes = [Pipe(SCREEN_WIDTH + i * 200) for i in range(3)]
        self.lives = LIVES_START
        self.score = 0
        self.game_over = False

    def step(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.game_over = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    self.bird.flap()
        if self.game_over:
            return

        self.bird.update()
        for pipe in self.pipes:
            pipe.update()

        self.backdrop.update()

        # Collision detection
        for pipe in self.pipes:
            if pipe.top_rect.colliderect(self.bird.rect) or pipe.bottom_rect.colliderect(self.bird.rect):
                self.lives -= 1
                pipe.passed = False  # Reset pass status
                if self.lives <= 0:
                    self.game_over = True
                    self.score += BASE_PENALTY
        if self.bird.rect.top <= 0 or self.bird.rect.bottom >= SCREEN_HEIGHT - BASE_HEIGHT:
            self.lives -= 1
            if self.lives <= 0:
                self.game_over = True
                self.score += BASE_PENALTY

        # Scoring
        self.score += BASE_REWARD
        for pipe in self.pipes:
            if not pipe.passed and pipe.rect.right < self.bird.rect.left:
                pipe.passed = True
                self.score += PIPE_REWARD

    def getGameState(self):
        state = {
            'bird_y': self.bird.rect.y,
            'bird_velocity': self.bird.velocity,
            'pipes': []
        }
        sorted_pipes = sorted(self.pipes, key=lambda p: p.rect.x)
        for pipe in sorted_pipes[:2]:
            distance = pipe.rect.x - self.bird.rect.x
            state['pipes'].append({'gap_y': pipe.gap_y, 'distance': distance})
        return state

    def draw(self):
        self.backdrop.draw(self.screen)
        for pipe in self.pipes:
            pipe.draw(self.screen)
        self.bird.draw(self.screen)
        self.draw_ui()
        pygame.display.flip()

    def draw_ui(self):
        font = pygame.font.SysFont(None, 24)
        score_surf = font.render(f"Score: {self.score}", True, (255, 255, 255))
        lives_surf = font.render(f"Lives: {self.lives}", True, (255, 255, 255))
        self.screen.blit(score_surf, (10, 10))
        self.screen.blit(lives_surf, (10, 40))

    def run(self):
        while not self.game_over:
            self.clock.tick(FPS)
            self.step()
            self.draw()
        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    random.seed(42)
    game = FlappyBird()
    game.run()