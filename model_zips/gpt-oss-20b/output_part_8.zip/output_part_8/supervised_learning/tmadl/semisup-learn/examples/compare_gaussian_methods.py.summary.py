import numpy as np
import matplotlib.pyplot as plt
from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis
from sklearn.metrics import accuracy_score

np.random.seed(42)

# Data generation
N = 60
s = np.random.rand()
meandistance = 5.0
cov = np.array([[s, 0], [0, s]])
cluster1 = np.random.multivariate_normal([-s*meandistance, -s*meandistance], cov, N)
cluster2 = np.random.multivariate_normal([s*meandistance, s*meandistance], cov, N)
Xs = np.vstack((cluster1, cluster2))
ytrue = np.array([0]*N + [1]*N)

# Label assignment for supervised learning
ys = np.full(2*N, -1, dtype=int)
indices_class0 = np.random.choice(N, 2, replace=False)
indices_class1 = np.random.choice(N, 2, replace=False) + N
ys[indices_class0] = 0
ys[indices_class1] = 1
Xsupervised = Xs[ys != -1]
ysupervised = ys[ys != -1]

# Evaluation helper
def evaluate_and_plot(X, y_true, y_pred, title, block=False):
    acc = accuracy_score(y_true, y_pred)
    plt.figure()
    plt.scatter(X[:, 0], X[:, 1], c=y_pred, cmap='viridis', edgecolor='k', s=50)
    plt.title(f"{title}\nAccuracy: {acc:.3f}")
    plt.xlabel('X1')
    plt.ylabel('X2')
    if block:
        plt.show()
    else:
        plt.show(block=False)

# Purely Supervised QDA
qda_supervised = QuadraticDiscriminantAnalysis()
qda_supervised.fit(Xsupervised, ysupervised)
y_pred_supervised = qda_supervised.predict(Xs)
evaluate_and_plot(Xs, ytrue, y_pred_supervised, "Purely Supervised QDA")

# Self-Learning QDA
class SelfLearningModel:
    def __init__(self, base_estimator, threshold=0.9, max_iter=10):
        self.base_estimator = base_estimator
        self.threshold = threshold
        self.max_iter = max_iter

    def fit(self, X, y):
        unlabeled = np.where(y == -1)[0]
        labeled = np.where(y != -1)[0]
        y_current = y.copy()
        for _ in range(self.max_iter):
            self.base_estimator.fit(X[labeled], y_current[labeled])
            probs = self.base_estimator.predict_proba(X[unlabeled])
            max_probs = np.max(probs, axis=1)
            confident = max_probs >= self.threshold
            if not np.any(confident):
                break
            new_labels = self.base_estimator.classes_[np.argmax(probs[confident], axis=1)]
            y_current[unlabeled[confident]] = new_labels
            labeled = np.where(y_current != -1)[0]
            unlabeled = np.where(y_current == -1)[0]
        return self

    def predict(self, X):
        return self.base_estimator.predict(X)

sl_model = SelfLearningModel(QuadraticDiscriminantAnalysis())
sl_model.fit(Xs, ys)
y_pred_sl = sl_model.predict(Xs)
evaluate_and_plot(Xs, ytrue, y_pred_sl, "Self-Learning QDA")

# CPLE Learning Model (Pessimistic)
class CPLELearningModel:
    def __init__(self, base_estimator, predict_from_probabilities=True, pessimistic=True, threshold=0.9):
        self.base_estimator = base_estimator
        self.predict_from_probabilities = predict_from_probabilities
        self.pessimistic = pessimistic
        self.threshold = threshold

    def fit(self, X, y):
        # Similar to self-learning but with pessimistic/optimistic flag
        unlabeled = np.where(y == -1)[0]
        labeled = np.where(y != -1)[0]
        y_current = y.copy()
        # adjust threshold
        thresh = self.threshold if self.pessimistic else 0.95
        while len(unlabeled) > 0:
            self.base_estimator.fit(X[labeled], y_current[labeled])
            probs = self.base_estimator.predict_proba(X[unlabeled])
            max_probs = np.max(probs, axis=1)
            confident = max_probs >= thresh
            if not np.any(confident):
                break
            new_labels = self.base_estimator.classes_[np.argmax(probs[confident], axis=1)]
            y_current[unlabeled[confident]] = new_labels
            labeled = np.where(y_current != -1)[0]
            unlabeled = np.where(y_current == -1)[0]
        return self

    def predict(self, X):
        return self.base_estimator.predict(X)

# Pessimistic CPLE
cple_pessimistic = CPLELearningModel(QuadraticDiscriminantAnalysis(), pessimistic=True, threshold=0.8)
cple_pessimistic.fit(Xs, ys)
y_pred_cple_pess = cple_pessimistic.predict(Xs)
evaluate_and_plot(Xs, ytrue, y_pred_cple_pess, "CPLE Pessimistic QDA")

# Optimistic CPLE
cple_optimistic = CPLELearningModel(QuadraticDiscriminantAnalysis(), pessimistic=False, threshold=0.9)
cple_optimistic.fit(Xs, ys)
y_pred_cple_opt = cple_optimistic.predict(Xs)
evaluate_and_plot(Xs, ytrue, y_pred_cple_opt, "CPLE Optimistic QDA", block=True)