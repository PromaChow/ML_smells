import numpy as np

DEFAULT_FEATURES = [
    "stone_color",
    "ones",
    "recent_move",
    "liberties",
    "capture_size",
    "ladder_capture",
    "ladder_escape",
    "sensibleness",
    "zeros",
]

def make_onehot(values, max_val=8):
    """
    Convert an array of integer values into one-hot encoded planes.
    Values are capped at max_val. Returned shape is (..., max_val).
    """
    capped = np.clip(values, 1, max_val)
    return np.eye(max_val)[capped - 1]


def stone_color_features(position, size):
    """
    Create 3 planes: player stones, opponent stones, empty.
    Assumes position.board contains 0 for empty, 1 for player, 2 for opponent.
    """
    board = position.board
    player_plane = (board == 1).astype(np.float32)
    opponent_plane = (board == 2).astype(np.float32)
    empty_plane = (board == 0).astype(np.float32)
    return np.stack([player_plane, opponent_plane, empty_plane], axis=2)


def ones_plane(size):
    return np.ones((size, size, 1), dtype=np.float32)


def recent_move_features(recent_moves, size):
    """
    recent_moves: list of tuples [(x, y), ...] with most recent first.
    """
    planes = np.zeros((size, size, 8), dtype=np.float32)
    for idx, move in enumerate(recent_moves[:8]):
        x, y = move
        if 0 <= x < size and 0 <= y < size:
            planes[x, y, idx] = 1.0
    return planes


def liberties_features(position, size):
    liberties = position.get_liberties()  # shape (size, size)
    return make_onehot(liberties, max_val=8)


def capture_size_features(position, size):
    capture = position.get_capture_size()  # shape (size, size)
    return make_onehot(capture, max_val=8)


def ladder_capture_feature(position, size):
    flag = 1.0 if position.is_ladder_capture() else 0.0
    return np.full((size, size, 1), flag, dtype=np.float32)


def ladder_escape_feature(position, size):
    flag = 1.0 if position.is_ladder_escape() else 0.0
    return np.full((size, size, 1), flag, dtype=np.float32)


def sensibleness_feature(position, size):
    flag = 1.0 if position.is_sensibleness() else 0.0
    return np.full((size, size, 1), flag, dtype=np.float32)


def zeros_plane_feature(size):
    return np.zeros((size, size, 1), dtype=np.float32)


def extract_features(position):
    size = position.size
    recent_moves = position.get_recent_moves()  # list of last moves
    planes = [
        stone_color_features(position, size),
        ones_plane(size),
        recent_move_features(recent_moves, size),
        liberties_features(position, size),
        capture_size_features(position, size),
        ladder_capture_feature(position, size),
        ladder_escape_feature(position, size),
        sensibleness_feature(position, size),
        zeros_plane_feature(size),
    ]
    return np.concatenate(planes, axis=2)


def bulk_extract_features(positions):
    """
    positions: iterable of Position objects
    Returns a 4D tensor of shape (N, size, size, planes)
    """
    if not positions:
        return np.empty((0, 0, 0, 0), dtype=np.float32)
    sample_size = positions[0].size
    sample_features = extract_features(positions[0])
    plane_count = sample_features.shape[2]
    features = np.empty((len(positions), sample_size, sample_size, plane_count), dtype=np.float32)
    for i, pos in enumerate(positions):
        features[i] = extract_features(pos)
    return features
