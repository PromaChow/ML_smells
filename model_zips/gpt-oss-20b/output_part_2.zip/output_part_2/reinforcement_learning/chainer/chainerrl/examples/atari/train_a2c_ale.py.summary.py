import argparse
import logging
import os
import numpy as np
import torch
import torch.nn as nn
import chainerrl
import chainerrl.envs
import chainerrl.experiments
import chainerrl.misc
import chainerrl.optimizers
import chainerrl.wrappers
from chainerrl.models import NIPSDQNHead
from chainerrl.wrappers import atari_wrappers

class A2CFF(nn.Module):
    def __init__(self, obs_shape, n_actions, hidden_size=256):
        super().__init__()
        self.feature_extractor = NIPSDQNHead(obs_shape, hidden_size)
        self.policy = nn.Linear(hidden_size, n_actions)
        self.value = nn.Linear(hidden_size, 1)

    def pi_and_v(self, x):
        h = self.feature_extractor(x)
        pi = nn.functional.softmax(self.policy(h), dim=-1)
        v = self.value(h).squeeze(-1)
        return pi, v

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--env', default='BreakoutNoFrameskip-v4')
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--outdir', type=str, default='out')
    parser.add_argument('--max-frames', type=int, default=2000)
    parser.add_argument('--steps', type=int, default=80_000_000)
    parser.add_argument('--lr', type=float, default=7.5e-4)
    parser.add_argument('--rmsprop-epsilon', type=float, default=0.01)
    parser.add_argument('--alpha', type=float, default=0.99)
    parser.add_argument('--use-gae', action='store_true')
    parser.add_argument('--tau', type=float, default=0.95)
    parser.add_argument('--eval-interval', type=int, default=10_000_000)
    parser.add_argument('--eval-n-runs', type=int, default=5)
    parser.add_argument('--weight-decay', type=float, default=0.0)
    parser.add_argument('--gpu', type=int, default=-1)
    parser.add_argument('--num-envs', type=int, default=16)
    parser.add_argument('--demo', action='store_true')
    parser.add_argument('--monitor', action='store_true')
    parser.add_argument('--render', action='store_true')
    parser.add_argument('--logging-level', default='INFO')
    parser.add_argument('--load', type=str, default='')
    parser.add_argument('--gamma', type=float, default=0.99)
    parser.add_argument('--update-steps', type=int, default=5)
    parser.add_argument('--max-grad-norm', type=float, default=0.5)
    return parser.parse_args()

def make_env(process_idx, test=False):
    def _thunk():
        env = chainerrl.envs.make_atari(args.env, frameskip=4)
        env = atari_wrappers.wrap_deepmind(
            env,
            frame_stack=True,
            clip_rewards=not test,
            episode_life=True,
        )
        if args.monitor:
            env = chainerrl.wrappers.Monitor(env, os.path.join(args.outdir, f"monitor_{process_idx}"))
        if args.render:
            env = chainerrl.wrappers.Render(env)
        env.seed(process_seeds[process_idx])
        return env
    return _thunk

def make_batch_env(test=False):
    return chainerrl.envs.MultiprocessVectorEnv(
        [make_env(i, test) for i in range(args.num_envs if not test else 1)]
    )

if __name__ == "__main__":
    args = parse_args()
    logging.basicConfig(level=args.logging_level.upper())
    chainerrl.misc.set_random_seed(args.seed)
    process_seeds = np.arange(args.num_envs) + args.seed * args.num_envs

    env = make_batch_env(test=False)
    test_env = make_batch_env(test=True)

    sample_obs = env.reset()
    obs_shape = sample_obs.shape[1:]
    n_actions = env.action_space.n

    model = A2CFF(obs_shape, n_actions)

    optimizer = chainerrl.optimizers.RMSPropAsync(
        lr=args.lr,
        epsilon=args.rmsprop_epsilon,
        alpha=args.alpha,
    )
    optimizer.add_hook(chainerrl.optimizers.clip_grad_norm, args.max_grad_norm)
    if args.weight_decay > 0.0:
        def wd_hook(grads, params):
            for g, p in zip(grads, params):
                g.add_(args.weight_decay * p)
            return grads
        optimizer.add_hook(wd_hook)

    agent = chainerrl.agents.A2C(
        model,
        optimizer,
        gamma=args.gamma,
        gpu=args.gpu,
        num_envs=args.num_envs,
        update_steps=args.update_steps,
        phi=model.feature_extractor,
        use_gae=args.use_gae,
        tau=args.tau,
    )

    if args.load:
        agent.load(args.load)

    if args.demo:
        eval_res = chainerrl.experiments.eval_performance(
            test_env,
            agent,
            n_runs=args.eval_n_runs,
        )
        mean = np.mean(eval_res)
        median = np.median(eval_res)
        std = np.std(eval_res)
        print(f"Demo results: mean={mean:.2f}, median={median:.2f}, std={std:.2f}")
    else:
        chainerrl.experiments.train_agent_batch_with_evaluation(
            agent,
            env,
            test_env,
            args.outdir,
            n_steps=args.steps,
            eval_interval=args.eval_interval,
            eval_n_runs=args.eval_n_runs,
            render=args.render,
        )