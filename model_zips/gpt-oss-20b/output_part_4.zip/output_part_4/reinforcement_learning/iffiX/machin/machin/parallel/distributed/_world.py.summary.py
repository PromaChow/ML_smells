import torch
import torch.distributed as dist
import torch.distributed.rpc as rpc
import threading
from enum import Enum
from functools import wraps

# ----- Singleton Decorator -----
def _world_singleton(cls):
    instances = {}
    @wraps(cls)
    def getinstance(*args, **kwargs):
        if cls not in instances:
            instances[cls] = cls(*args, **kwargs)
        return instances[cls]
    return getinstance

# ----- LUT Types -----
class LUTType(Enum):
    VALUE = 1
    SERVICE = 2

# ----- Global Lookup Tables -----
_value_lut = {}
_service_lut = {}
_lut_lock = threading.Lock()

def _rpc_set_lut_entry(lut_type: LUTType, key: str, value):
    with _lut_lock:
        if lut_type == LUTType.VALUE:
            _value_lut[key] = value
        else:
            _service_lut[key] = value

def _rpc_unset_lut_entry(lut_type: LUTType, key: str):
    with _lut_lock:
        if lut_type == LUTType.VALUE:
            _value_lut.pop(key, None)
        else:
            _service_lut.pop(key, None)

def _rpc_get_lut_entry(lut_type: LUTType, key: str):
    with _lut_lock:
        if lut_type == LUTType.VALUE:
            return _value_lut.get(key)
        else:
            return _service_lut.get(key)

# ----- World Class -----
@_world_singleton
class World:
    def __init__(self, backend: str = "gloo", init_method: str = "env://"):
        self.backend = backend
        self.init_method = init_method
        self._init_process_group()
        self._init_rpc()
        self._initialized = True

    def _init_process_group(self):
        if not dist.is_available():
            raise RuntimeError("torch.distributed is not available.")
        if not dist.is_process_group_initialized():
            dist.init_process_group(
                backend=self.backend,
                init_method=self.init_method,
                world_size=self.get_world_size(),
                rank=self.get_rank(),
            )

    def _init_rpc(self):
        if not rpc.is_available():
            raise RuntimeError("torch.distributed.rpc is not available.")
        if not rpc.is_initialized():
            rpc.init_rpc(
                name=self.get_cur_name(),
                rank=self.get_rank(),
                world_size=self.get_world_size(),
                backend=self.backend,
                init_method=self.init_method,
            )

    def get_world_size(self) -> int:
        return dist.get_world_size()

    def get_rank(self) -> int:
        return dist.get_rank()

    def get_cur_name(self) -> str:
        return f"worker_{self.get_rank()}"

    def is_initialized(self) -> bool:
        return self._initialized

    def stop(self):
        rpc.shutdown()
        dist.destroy_process_group()
        self._initialized = False

# ----- Helper Functions -----
def get_cur_rank() -> int:
    return World().get_rank()

def get_cur_name() -> str:
    return World().get_cur_name()

def is_world_initialized() -> bool:
    return World().is_initialized()

# ----- Collective Group -----
class CollectiveGroup:
    _groups = {}
    _groups_lock = threading.Lock()

    def __init__(self, name: str, ranks=None):
        self.name = name
        self.ranks = ranks or list(range(World().get_world_size()))
        self.group = dist.new_group(ranks=self.ranks)
        with self._groups_lock:
            self._groups[name] = self

    @classmethod
    def get(cls, name: str):
        with cls._groups_lock:
            return cls._groups.get(name)

    def send(self, tensor, dst, tag=0):
        dist.send(tensor, dst=dst, tag=tag, group=self.group)

    def recv(self, tensor, src, tag=0):
        dist.recv(tensor, src=src, tag=tag, group=self.group)

    def barrier(self):
        dist.barrier(group=self.group)

    def destroy(self):
        with self._groups_lock:
            self._groups.pop(self.name, None)
        dist.destroy_process_group(self.group)

def create_collective_group(name: str, ranks=None) -> CollectiveGroup:
    return CollectiveGroup(name, ranks)

# ----- RPC Group -----
class RpcGroup:
    _groups = {}
    _groups_lock = threading.Lock()

    def __init__(self, name: str, ranks=None):
        self.name = name
        self.ranks = ranks or list(range(World().get_world_size()))
        self.ready_event = threading.Event()
        self._register_lut_entries()
        self._synchronize_members()

    def _register_lut_entries(self):
        # Register group name in value LUT
        _rpc_set_lut_entry(LUTType.VALUE, f"group:{self.name}", self.ranks)

    def _synchronize_members(self):
        # Simple barrier using dist.broadcast of a tensor
        flag = torch.tensor([0], device="cpu")
        if World().get_rank() in self.ranks:
            dist.broadcast(flag, src=self.ranks[0], group=dist.new_group(self.ranks))
        self.ready_event.set()

    @classmethod
    def get(cls, name: str):
        with cls._groups_lock:
            return cls._groups.get(name)

    def rpc_sync(self, target_name, fn, *args, **kwargs):
        if target_name not in self.ranks:
            raise RuntimeError(f"Target {target_name} not in group {self.name}")
        return rpc.rpc_sync(target_name, fn, args, kwargs)

    def rpc_async(self, target_name, fn, *args, **kwargs):
        if target_name not in self.ranks:
            raise RuntimeError(f"Target {target_name} not in group {self.name}")
        return rpc.rpc_async(target_name, fn, args, kwargs)

    def remote(self, target_name, fn, *args, **kwargs):
        return self.rpc_sync(target_name, fn, *args, **kwargs)

    def register(self, key: str, fn):
        _rpc_set_lut_entry(LUTType.SERVICE, key, fn)

    def deregister(self, key: str):
        _rpc_unset_lut_entry(LUTType.SERVICE, key)

    def pair(self, key: str, value):
        _rpc_set_lut_entry(LUTType.VALUE, key, value)

    def unpair(self, key: str):
        _rpc_unset_lut_entry(LUTType.VALUE, key)

    def call_service(self, key: str, *args, **kwargs):
        fn = _rpc_get_lut_entry(LUTType.SERVICE, key)
        if fn is None:
            raise RuntimeError(f"Service {key} not registered.")
        return fn(*args, **kwargs)

    def destroy(self):
        # Unregister LUT entries
        _rpc_unset_lut_entry(LUTType.VALUE, f"group:{self.name}")
        with self._groups_lock:
            self._groups.pop(self.name, None)

def create_rpc_group(name: str, ranks=None) -> RpcGroup:
    return RpcGroup(name, ranks)

# ----- Example Service Function -----
def example_service(x, y):
    return x + y

# Register example service globally (can be done per group)
_rpc_set_lut_entry(LUTType.SERVICE, "add", example_service)

# ----- Expose Public API -----
__all__ = [
    "World",
    "CollectiveGroup",
    "RpcGroup",
    "create_collective_group",
    "create_rpc_group",
    "get_cur_rank",
    "get_cur_name",
    "is_world_initialized",
]
