import random
import torch
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Callable, Optional, Union

# Base class for transition objects
class TransitionBase:
    pass

# Simple Transition dataclass with optional custom attributes
@dataclass
class Transition(TransitionBase):
    state: Any
    action: Any
    next_state: Any
    reward: Any
    terminal: bool
    custom_attrs: Dict[str, Any] = field(default_factory=dict)

    def __getitem__(self, key: str) -> Any:
        if key in {"state", "action", "next_state", "reward", "terminal"}:
            return getattr(self, key)
        return self.custom_attrs.get(key, None)

# Basic storage mechanism
class TransitionStorageBasic:
    def __init__(self):
        self._transitions: List[Transition] = []
        self._handle_counter: int = 0
        self._handle_to_transition: Dict[int, Transition] = {}

    def store_episode(self, episode: Iterable[Union[TransitionBase, Dict]], episode_number: int) -> List[int]:
        handles: List[int] = []
        for tr in episode:
            if isinstance(tr, dict):
                tr = Transition(**tr)
            elif not isinstance(tr, TransitionBase):
                raise ValueError("Unsupported transition type")
            handle = self._handle_counter
            self._handle_counter += 1
            self._transitions.append(tr)
            self._handle_to_transition[handle] = tr
            handles.append(handle)
        return handles

    def get_transitions_by_handles(self, handles: List[int]) -> List[Transition]:
        return [self._handle_to_transition[h] for h in handles]

    def clear(self):
        self._transitions.clear()
        self._handle_to_transition.clear()
        self._handle_counter = 0

    def size(self) -> int:
        return len(self._transitions)

# Main Buffer class
class Buffer:
    def __init__(
        self,
        buffer_size: int,
        buffer_device: Union[str, torch.device] = "cpu",
        storage: Optional[TransitionStorageBasic] = None,
    ):
        self.buffer_size = buffer_size
        self.buffer_device = torch.device(buffer_device)
        self.storage = storage or TransitionStorageBasic()
        self.handle_to_episode: Dict[int, int] = {}
        self.episode_counter: int = 0

    def store_episode(self, episode: Iterable[Union[TransitionBase, Dict]]):
        episode_number = self.episode_counter
        handles = self.storage.store_episode(episode, episode_number)
        for h in handles:
            self.handle_to_episode[h] = episode_number
        self.episode_counter += 1
        if self.storage.size() > self.buffer_size:
            self._evict_oldest()

    def _evict_oldest(self):
        # Simple eviction: remove the first half of transitions
        num_to_remove = self.storage.size() // 2
        removed_handles = list(self.handle_to_episode.keys())[:num_to_remove]
        for h in removed_handles:
            del self.handle_to_episode[h]
        # Rebuild storage without removed transitions
        remaining = [self.storage._handle_to_transition[h] for h in self.handle_to_episode]
        self.storage.clear()
        for tr in remaining:
            self.storage.store_episode([tr], self.episode_counter)
        self.episode_counter += 1

    def size(self) -> int:
        return self.storage.size()

    def clear(self):
        self.storage.clear()
        self.handle_to_episode.clear()
        self.episode_counter = 0

    def sample_batch(
        self,
        batch_size: int,
        sample_attrs: Optional[List[str]] = None,
        additional_concat_custom_attrs: Optional[List[str]] = None,
        concatenate: bool = True,
        sample_method: Union[str, Callable[[int, int], List[int]]] = "random_unique",
    ) -> Dict[str, Any]:
        if self.size() == 0:
            return {}

        if sample_attrs is None:
            sample_attrs = ["state", "action", "next_state", "reward", "terminal"]

        if additional_concat_custom_attrs is None:
            additional_concat_custom_attrs = []

        batch_size = min(batch_size, self.size())

        if isinstance(sample_method, str):
            if sample_method == "random_unique":
                handles = random.sample(list(self.handle_to_episode.keys()), batch_size)
            elif sample_method == "random":
                handles = [random.choice(list(self.handle_to_episode.keys())) for _ in range(batch_size)]
            elif sample_method == "all":
                handles = list(self.handle_to_episode.keys())
                batch_size = len(handles)
            else:
                raise ValueError(f"Unknown sample_method: {sample_method}")
        else:
            handles = sample_method(batch_size, self.size())

        transitions = self.storage.get_transitions_by_handles(handles)

        batch = self.post_process_batch(
            transitions,
            sample_attrs,
            additional_concat_custom_attrs,
            concatenate,
        )
        return batch

    def post_process_batch(
        self,
        transitions: List[Transition],
        sample_attrs: List[str],
        additional_concat_custom_attrs: List[str],
        concatenate: bool,
    ) -> Dict[str, Any]:
        output: Dict[str, Any] = {}
        for attr in sample_attrs:
            values = [tr[attr] for tr in transitions]
            processed = self.pre_process_attribute(values)
            tensor = self.make_tensor_from_batch(processed, concatenate)
            output[attr] = self.post_process_attribute(tensor)
        for attr in additional_concat_custom_attrs:
            values = [tr.custom_attrs.get(attr, None) for tr in transitions]
            processed = self.pre_process_attribute(values)
            tensor = self.make_tensor_from_batch(processed, concatenate)
            output[attr] = self.post_process_attribute(tensor)
        return output

    def pre_process_attribute(self, values: List[Any]) -> List[Any]:
        # Default implementation: no change
        return values

    def make_tensor_from_batch(self, values: List[Any], concatenate: bool):
        if not concatenate:
            return values
        # Determine if elements are tensors or scalars
        try:
            tensor = torch.stack([torch.as_tensor(v) for v in values], dim=0)
        except Exception:
            tensor = torch.tensor(values, device=self.buffer_device)
        return tensor.to(self.buffer_device)

    def post_process_attribute(self, tensor_or_list: Any) -> Any:
        return tensor_or_list

# Example usage (commented out; remove comments to run)
# if __name__ == "__main__":
#     buf = Buffer(buffer_size=100, buffer_device="cpu")
#     episode = [
#         {"state": [0, 0], "action": 1, "next_state": [1, 0], "reward": 0.1, "terminal": False},
#         {"state": [1, 0], "action": 0, "next_state": [1, 1], "reward": 0.2, "terminal": True},
#     ]
#     buf.store_episode(episode)
#     batch = buf.sample_batch(batch_size=2, concatenate=True)
#     print(batch)