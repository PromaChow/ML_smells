import re
import numpy as np
from pathlib import Path
from sklearn.feature_extraction.text import CountVectorizer
import datasetUtils as dsu
import embeddings

# Parameters
dataset_path = Path('fasttext.vec')
tweet_threshold = 5

# User input handling
user_input = input("Enter a username (prefixed with @) or a filename: ").strip()
usernames = []

if user_input.startswith('@'):
    usernames.append(user_input[1:])
else:
    file_path = Path(user_input)
    if file_path.is_file() and file_path.stat().st_size > 0:
        usernames = [line.strip() for line in file_path if line.strip()]
    else:
        print("Invalid file or file is empty.")
        exit(1)

# Load FastText word embeddings
wordDictionary = dsu.parseFastText(dataset_path)

# Output structures
usersData = []

# Process each username
for username in usernames:
    tweet_file_path = Path(f'{username}.txt')
    if not tweet_file_path.is_file():
        print(f"Tweet file for {username} not found.")
        continue

    num_tweets = 0
    avg_words = []
    cv = CountVectorizer()
    analyzer = cv.build_analyzer()

    with tweet_file_path.open('r', encoding='utf-8') as f:
        for line in f:
            tweet = line.strip()
            if not tweet or tweet.startswith('RT'):
                continue

            # Remove URLs starting with http
            tweet = re.sub(r'http\S+', '', tweet)
            # Remove URLs without http
            tweet = re.sub(r'www\.\S+', '', tweet)
            # Remove mentions
            tweet = re.sub(r'@\w+', '', tweet)

            words = analyzer(tweet)
            if len(words) < tweet_threshold:
                continue

            count_emb = sum(1 for w in words if w in wordDictionary)
            avg_words.append(count_emb)
            num_tweets += 1

    if num_tweets == 0:
        print(f"No valid tweets for {username}.")
        continue

    avg_emb_words = np.mean(np.array(avg_words))
    usersData.append(f'{username},{num_tweets},{avg_emb_words:.2f}')

# Save results to CSV
csv_path = Path('TwitterUsersStats.csv')
with csv_path.open('w', encoding='utf-8') as f:
    for line in usersData:
        f.write(line + '\n')