import numpy as np
from ple import PLE
from ple.games.doom import Doom


class NaiveAgent:
    def __init__(self, action_set):
        self.action_set = action_set

    def pickAction(self, reward, screen):
        return np.random.randint(len(self.action_set))


def main():
    game = Doom("take_cover")
    env = PLE(game, fps=30, display_screen=False, force_fps=True)
    agent = NaiveAgent(env.getActionSet())

    env.init()
    reward = 0

    for frame in range(15000):
        if env.game_over():
            env.reset_game()

        action = agent.pickAction(reward, env.getScreenRGB())
        reward = env.act(action)

        if frame == 2000:
            env.display_screen = True
            env.force_fps = False
        elif frame == 2250:
            env.display_screen = True
            env.force_fps = True


if __name__ == "__main__":
    main()
