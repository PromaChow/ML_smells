import numpy as np

class PolyakRunningAverage:
    def __init__(self, alpha: float):
        if not 0 <= alpha <= 1:
            raise ValueError("alpha must be between 0 and 1")
        self.alpha = alpha
        self.x = None

    def __call__(self, x):
        arr = np.asarray(x)
        if self.x is None:
            self.x = arr
        else:
            self.x = self.alpha * self.x + (1 - self.alpha) * arr

    def get_current(self):
        return self.x

if __name__ == "__main__":
    avg = PolyakRunningAverage(alpha=0.8)
    data = [1, 2, 3, 4, 5]
    for val in data:
        avg(val)
        print("Current average:", avg.get_current())