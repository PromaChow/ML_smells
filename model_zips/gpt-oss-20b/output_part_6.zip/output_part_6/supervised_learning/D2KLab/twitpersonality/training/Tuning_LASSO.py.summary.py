import argparse
import os
import random
import sys
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.linear_model import Lasso
from sklearn.model_selection import KFold
from sklearn.preprocessing import StandardScaler
from scipy.stats import pearsonr

# ----------------- Configuration -----------------
POST_THRESHOLD = 3
ALPHA_LASSO = [0.01, 0.1, 1.0, 10.0]
EMBEDDING_METHODS = ["sum", "max", "min", "avg", "conc"]
SUBSET_SIZE = 100
RESULTS_DIR = Path("Results")
METRICS_CSV = RESULTS_DIR / "metrics.csv"
PCC_TXT = RESULTS_DIR / "pcc.txt"


# ----------------- Helper Functions -----------------
def parse_bool(val: str) -> bool:
    return val.lower() in ("true", "yes", "1")


def load_personality_and_posts(csv_path: str):
    df = pd.read_csv(csv_path)
    # Assume columns: post, O, C, E, A, N
    posts = df["post"].tolist()
    scores = df[["O", "C", "E", "A", "N"]].values
    return posts, scores


def load_fasttext_embeddings(embedding_path: str):
    # FastText embeddings in word2vec format
    from gensim.models import KeyedVectors

    model = KeyedVectors.load_word2vec_format(embedding_path, binary=True)
    return model


def load_dataset9_embeddings(embedding_path: str):
    # Assume json file: {post_id: [embedding list]}
    with open(embedding_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data  # dict of post_id -> list


def tokenize(text: str):
    return text.strip().split()


def get_word_vector(word: str, embedding_dict):
    if hasattr(embedding_dict, "get_vector"):
        try:
            return embedding_dict.get_vector(word)
        except KeyError:
            return None
    return embedding_dict.get(word)


def transform_post(post: str, embedding_dict, method: str):
    words = tokenize(post)
    vectors = []
    for w in words:
        vec = get_word_vector(w, embedding_dict)
        if vec is not None:
            vectors.append(vec)
    if not vectors:
        return np.zeros(embedding_dict.vector_size if hasattr(embedding_dict, "vector_size") else len(next(iter(embedding_dict.values()))))
    mat = np.vstack(vectors)
    if method == "sum":
        return mat.sum(axis=0)
    if method == "max":
        return mat.max(axis=0)
    if method == "min":
        return mat.min(axis=0)
    if method == "avg":
        return mat.mean(axis=0)
    if method == "conc":
        return mat.flatten()
    raise ValueError(f"Unknown method {method}")


def prepare_features(posts, embedding_dict, method: str):
    features = [transform_post(p, embedding_dict, method) for p in posts]
    return np.vstack(features)


def ensure_results_dir():
    RESULTS_DIR.mkdir(exist_ok=True)


def clear_file(path: Path):
    if path.exists():
        path.unlink()


# ----------------- Main Execution -----------------
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("trait", help="BIG5 trait letter (O, C, E, A, N)")
    parser.add_argument("embedding_type", help="Embeddings dataset type (fasttext or dataset9)")
    parser.add_argument("dataset_file", help="Path to dataset csv file")
    parser.add_argument("shuffle_flag", help="Shuffle flag (True/yes or False/no)")
    args = parser.parse_args()

    trait = args.trait.upper()
    if trait not in ("O", "C", "E", "A", "N"):
        print("Trait must be one of O, C, E, A, N")
        sys.exit(1)

    embedding_type = args.embedding_type.lower()
    if embedding_type not in ("fasttext", "dataset9"):
        print("Embedding type must be fasttext or dataset9")
        sys.exit(1)

    shuffle_flag = parse_bool(args.shuffle_flag)

    # Load data
    posts, scores = load_personality_and_posts(args.dataset_file)

    # Shuffle if requested
    if shuffle_flag:
        idx = list(range(len(posts)))
        random.shuffle(idx)
        posts = [posts[i] for i in idx]
        scores = scores[idx]

    # Subset
    posts = posts[:SUBSET_SIZE]
    scores = scores[:SUBSET_SIZE]

    # Load embeddings
    if embedding_type == "fasttext":
        embedding_path = "fasttext.vec"  # placeholder path
        embedding_dict = load_fasttext_embeddings(embedding_path)
    else:
        embedding_path = "dataset9_embeddings.json"  # placeholder path
        embedding_dict = load_dataset9_embeddings(embedding_path)

    # Prepare results storage
    ensure_results_dir()
    clear_file(METRICS_CSV)
    clear_file(PCC_TXT)

    metrics_records = []
    pcc_records = []

    target_idx = {"O": 0, "C": 1, "E": 2, "A": 3, "N": 4}[trait]
    y = scores[:, target_idx]

    for method in EMBEDDING_METHODS:
        X = prepare_features(posts, embedding_dict, method)
        # Standardize features
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)

        kf = KFold(n_splits=10, shuffle=True, random_state=42)

        for alpha in ALPHA_LASSO:
            mse_list = []
            r2_list = []
            pcc_list = []

            fold_idx = 0
            for train_index, test_index in kf.split(X_scaled):
                X_train, X_test = X_scaled[train_index], X_scaled[test_index]
                y_train, y_test = y[train_index], y[test_index]

                model = Lasso(alpha=alpha, max_iter=100000, normalize=True)
                model.fit(X_train, y_train)
                y_pred = model.predict(X_test)

                mse = np.mean((y_test - y_pred) ** 2)
                r2 = model.score(X_test, y_test)
                pcc, pval = pearsonr(y_test, y_pred)

                mse_list.append(mse)
                r2_list.append(r2)
                pcc_list.append(pcc)

                pcc_records.append(
                    {
                        "embedding": method,
                        "alpha": alpha,
                        "fold": fold_idx,
                        "pcc": pcc,
                        "pvalue": pval,
                    }
                )
                fold_idx += 1

            metrics_records.append(
                {
                    "embedding": method,
                    "alpha": alpha,
                    "mse_mean": np.mean(mse_list),
                    "mse_std": np.std(mse_list),
                    "r2_mean": np.mean(r2_list),
                    "r2_std": np.std(r2_list),
                    "pcc_mean": np.mean(pcc_list),
                    "pcc_std": np.std(pcc_list),
                }
            )

    # Save metrics CSV
    pd.DataFrame(metrics_records).to_csv(METRICS_CSV, index=False)

    # Save PCC details
    with open(PCC_TXT, "w", encoding="utf-8") as f:
        for rec in pcc_records:
            f.write(
                f"{rec['embedding']},{rec['alpha']},{rec['fold']},{rec['pcc']:.4f},{rec['pvalue']:.4g}\n"
            )


if __name__ == "__main__":
    main()
