import asyncio
import random
import numpy as np
import daiquiri
import uvloop

daiquiri.setup(level='DEBUG')

# Global concurrency controls
SEM = asyncio.Semaphore(64)
QUEUE = asyncio.Queue(maxsize=64)
RUNNING_SIMULATION_NUM = 0
NOW_EXPANDING = set()
RUNNING_SIMULATION_LOCK = asyncio.Lock()

BOARD_SIZE = 9
DIRICHLET_ALPHA = 0.3
DIRICHLET_EPSILON = 0.25
VIRTUAL_LOSS = 1

def board_to_features(board):
    return board.flatten()

def apply_move(board, move):
    new_board = board.copy()
    if move is not None:
        x, y = move
        new_board[x, y] = 1
    return new_board

def all_possible_moves(board):
    moves = []
    for x in range(BOARD_SIZE):
        for y in range(BOARD_SIZE):
            if board[x, y] == 0:
                moves.append((x, y))
    moves.append(None)  # pass
    return moves

def dirichlet_noise(size):
    noise = np.random.dirichlet([DIRICHLET_ALPHA]*size)
    return noise

class NetworkAPI:
    def __init__(self):
        self.worker_task = asyncio.create_task(self.prediction_worker())

    async def prediction_worker(self):
        while True:
            batch = []
            futures = []
            try:
                for _ in range(64):
                    item = await asyncio.wait_for(QUEUE.get(), timeout=0.1)
                    batch.append(item[0])
                    futures.append(item[1])
            except asyncio.TimeoutError:
                pass
            if batch:
                policies, values = self.run_many(batch)
                for fut, policy, value in zip(futures, policies, values):
                    fut.set_result((policy, value))

    def push_queue(self, feature):
        fut = asyncio.get_event_loop().create_future()
        QUEUE.put_nowait((feature, fut))
        return fut

    def run_many(self, batch):
        size = len(batch)
        policy_dim = BOARD_SIZE * BOARD_SIZE + 1
        policies = np.random.dirichlet([1]*policy_dim, size=size)
        values = np.random.uniform(-1, 1, size=size)
        return policies, values

class MCTSNode:
    def __init__(self, api, parent=None, move=None, prior=0.0, position=None):
        self.api = api
        self.parent = parent
        self.move = move
        self.prior = prior
        self.position = position
        self.children = {}
        self.U = 0.0
        self.N = 0
        self.W = 0.0
        self.v_loss = 0

    @property
    def Q(self):
        return self.W / self.N if self.N > 0 else 0.0

    def compute_position(self):
        if self.position is None:
            if self.parent is None:
                self.position = np.zeros((BOARD_SIZE, BOARD_SIZE), dtype=int)
            else:
                self.position = apply_move(self.parent.position, self.move)

    def expand(self, move_probs):
        moves = all_possible_moves(self.position)
        for i, move in enumerate(moves):
            prior = move_probs[i]
            child = MCTSNode(self.api, parent=self, move=move, prior=prior)
            self.children[move] = child

    def backup_value_single(self, value):
        self.W += value
        self.N += 1
        self.U = self.prior * np.sqrt(self.parent.N if self.parent else 1) / (1 + self.N)

    def virtual_loss_do(self):
        self.v_loss += VIRTUAL_LOSS
        self.N += VIRTUAL_LOSS

    def virtual_loss_undo(self):
        self.v_loss -= VIRTUAL_LOSS
        self.N -= VIRTUAL_LOSS

    async def suggest_move_prob(self, iterations):
        await tree_search(self, iterations)
        probs = np.zeros(len(all_possible_moves(self.position)))
        for i, move in enumerate(all_possible_moves(self.position)):
            child = self.children.get(move)
            if child:
                probs[i] = child.N
        probs /= probs.sum()
        return probs

async def start_tree_search(node):
    node.virtual_loss_do()
    if node.move in NOW_EXPANDING:
        node.virtual_loss_undo()
        return -node.parent.backup_value_single(0) if node.parent else 0.0
    NOW_EXPANDING.add(node.move)
    node.compute_position()
    features = board_to_features(node.position)
    fut = node.api.push_queue(features)
    move_probs, value = await fut
    moves = all_possible_moves(node.position)
    policy = np.zeros(len(moves))
    for i, move in enumerate(moves):
        policy[i] = move_probs[i]
    if node.parent:
        node.parent.U = node.prior * np.sqrt(node.parent.N) / (1 + node.N)
    node.expand(policy)
    NOW_EXPANDING.remove(node.move)
    node.virtual_loss_undo()
    node.backup_value_single(value)
    return -value

async def tree_search(root, iterations):
    global RUNNING_SIMULATION_NUM
    async def run_one():
        async with SEM:
            await start_tree_search(root)
    async with RUNNING_SIMULATION_LOCK:
        RUNNING_SIMULATION_NUM += iterations
    tasks = [asyncio.create_task(run_one()) for _ in range(iterations)]
    await asyncio.gather(*tasks)
    async with RUNNING_SIMULATION_LOCK:
        RUNNING_SIMULATION_NUM -= iterations

if __name__ == "__main__":
    async def main():
        api = NetworkAPI()
        root = MCTSNode(api)
        probs = await root.suggest_move_prob(10)
        print("Move probabilities:", probs)
    asyncio.set_event_loop_policy(uvloop.EventLoopPolicy())
    asyncio.run(main())