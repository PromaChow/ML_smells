import numpy as np

class SimpleLinearNetwork:
    def __init__(self, weights_dense1_w, weights_dense1_b,
                 weights_dense2_w, weights_dense2_b,
                 weights_final_w, weights_final_b):
        self.w1 = weights_dense1_w
        self.b1 = weights_dense1_b
        self.w2 = weights_dense2_w
        self.b2 = weights_dense2_b
        self.w3 = weights_final_w
        self.b3 = weights_final_b

    def forward(self, x):
        output1 = x @ self.w1 + self.b1
        output2 = output1 @ self.w2 + self.b2
        final_output = output2 @ self.w3 + self.b3
        return final_output

    __call__ = forward

if __name__ == "__main__":
    batch_size = 5
    input_dim = 100
    output_dim = 17

    np.random.seed(0)
    x = np.random.randn(batch_size, input_dim)

    weights_dense1_w = np.random.randn(input_dim, 100)
    weights_dense1_b = np.random.randn(100)

    weights_dense2_w = np.random.randn(100, 100)
    weights_dense2_b = np.random.randn(100)

    weights_final_w = np.random.randn(100, output_dim)
    weights_final_b = np.random.randn(output_dim)

    model = SimpleLinearNetwork(weights_dense1_w, weights_dense1_b,
                                weights_dense2_w, weights_dense2_b,
                                weights_final_w, weights_final_b)

    output = model(x)
    print(output)