import pickle
import logging
import numpy as np
import tfutil

logging.basicConfig(level=logging.INFO)
log = logging.getLogger(__name__)


class LegacyUnpickler(pickle.Unpickler):
    """Custom unpickler that remaps legacy Theano Network to new tfutil.Network."""
    def find_class(self, module, name):
        if module == 'network' and name == 'Network':
            return tfutil.Network
        return super().find_class(module, name)


# Mapping of legacy network names to new names
theano_gan_remap = {
    'G_paper': 'G_paper',
    'D_progressive_8': 'D_paper',
    # add additional mappings as needed
}


def flatten2(tensors):
    """Flatten a list of numpy arrays into a single list."""
    return [t.flatten() for t in tensors]


def he_std(fan_in):
    """He initialization standard deviation."""
    return np.sqrt(2.0 / fan_in)


def wscale(shape, fan_in, gain=1.0):
    """Weight scaling factor."""
    return gain / np.sqrt(np.prod(shape) / fan_in)


def layer(param, shape, fan_in, gain=1.0):
    """Apply weight scaling and reshape."""
    scaled = param.reshape(shape) * wscale(shape, fan_in, gain)
    return scaled


def patch_theano_gan(state):
    """
    Convert legacy Theano state to new TensorFlow-compatible format.
    """
    # Validation checks
    assert state.get('label_size', 0) == 0, "Expected label_size to be 0"
    assert state.get('use_batchnorm', True), "Expected use_batchnorm to be True"
    # Additional expected parameters can be asserted here

    network_name = state.get('network')
    if network_name in theano_gan_remap:
        network_name = theano_gan_remap[network_name]
    else:
        log.warning(f"Unknown network name '{network_name}', keeping original")

    param_values = state.get('param_values', [])
    processed_params = []

    # Example processing: iterate over parameters and apply layer transformation
    for idx, param in enumerate(param_values):
        # Dummy shape determination logic
        if idx == 0:
            shape = (4, 4, 3, 64)  # example shape
        else:
            shape = (64, 64, 3, 64)
        fan_in = np.prod(shape[:-1])
        processed = layer(param, shape, fan_in)
        processed_params.append(processed)

    new_state = {
        'network': network_name,
        'variables': processed_params,
        'version': 2
    }
    return new_state


def ignore_unknown_theano_network(state):
    """
    Handle states without a version by logging and returning a dummy state.
    """
    if 'version' not in state:
        log.info(f"Ignoring unknown network: {state.get('network')}")
        dummy_network = tfutil.Network()
        return {
            'network': dummy_network,
            'variables': [],
            'version': 2
        }
    return state


# Register handlers
if hasattr(tfutil, 'network_import_handlers'):
    tfutil.network_import_handlers.append(patch_theano_gan)
    tfutil.network_import_handlers.append(ignore_unknown_theano_network)
else:
    tfutil.network_import_handlers = [patch_theano_gan, ignore_unknown_theano_network]