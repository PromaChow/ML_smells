import numpy as np
import chainer
import chainer.functions as F
import chainer.links as L
import chainer.datasets as Datasets
import chainer.iterators as Iterators
import chainer.training as Training
import chainer.training.updater as Updater
import chainer.training.extensions as Extensions
from chainer import Chain, Variable, optimizers, serializers
from chainer.backends import cuda
from chainer.training.trainer import Trainer
from chainer.training.updater import StandardUpdater
from chainer.datasets import TupleDataset
from chainer.iterators import SerialIterator
from chainer.training.trainer import Trainer
from chainer.training.trainer import extensions
try:
    import matplotlib
    matplotlib.use('Agg')
except Exception:
    pass

# Custom utilities from pywsl (assumed to be available)
from pywsl import load_dataset, PU_Risk, PU_Accuracy, MLP, pred

# Hyperparameters
gpu = -1  # -1 for CPU, otherwise device ID
out = 'out_pu'  # output directory
stepsize = 0.001  # learning rate
batchsize = 10000
epoch = 10
beta = 0.0
gamma = 1.0
data_id = 0
prior = 0.5
n_pos = 1000
n_neg = 1000
n_unl = 2000
n_test = 500

# Load data
x_p, x_u, x_t, x_vp, x_vn, x_vu = load_dataset(
    data_id=data_id,
    n_pos=n_pos,
    n_neg=n_neg,
    n_unl=n_unl,
    n_test=n_test,
    prior=prior
)

# Convert to float32
x_p = x_p.astype(np.float32)
x_u = x_u.astype(np.float32)
x_t = x_t.astype(np.float32)
x_vp = x_vp.astype(np.float32)
x_vn = x_vn.astype(np.float32)
x_vu = x_vu.astype(np.float32)

# Prepare datasets
labels_p = np.ones(len(x_p), dtype=np.int32)
labels_u = np.zeros(len(x_u), dtype=np.int32)

xy_train = TupleDataset(np.concatenate([x_p, x_u]), np.concatenate([labels_p, labels_u]))
xy_test = TupleDataset(x_t, np.concatenate([labels_p, labels_u]))

# Iterators
train_iter = SerialIterator(xy_train, batchsize, shuffle=True, repeat=True)
test_iter = SerialIterator(xy_test, batchsize, shuffle=False, repeat=False)

# Loss and accuracy
loss_func = lambda x: F.sigmoid(-x)
pu_risk = PU_Risk(prior=prior, loss_func=loss_func, gamma=gamma, beta=beta)
pu_acc = PU_Accuracy()

# Model
model = L.Classifier(
    base=L.Sequential(
        MLP(),
    ),
    lossfun=pu_risk,
    accfun=pu_acc
)
if gpu >= 0:
    cuda.get_device_from_id(gpu).use()
    model.to_gpu(gpu)

# Optimizer
optimizer = optimizers.Adam(alpha=stepsize)
optimizer.setup(model)
optimizer.add_hook(optimizers.WeightDecay(0.005))

# Training loop
updater = StandardUpdater(train_iter, optimizer, device=gpu)
trainer = Trainer(updater, (epoch, 'epoch'), out)

trainer.extend(Extensions.LogReport())
trainer.extend(Extensions.PrintReport(
    ['epoch', 'main/loss', 'validation/main/loss', 'main/accuracy',
     'validation/main/accuracy']))
trainer.extend(Extensions.ProgressBar())
trainer.extend(Extensions.Evaluator(test_iter, model, name='validation'))

trainer.extend(Extensions.snapshot_object(
    model, 'best-model.npz'), trigger=(1, 'epoch'))

# Plot if matplotlib available
try:
    import matplotlib
    trainer.extend(Extensions.PlotReport(
        ['main/loss', 'validation/main/loss'],
        file_name='loss.png',
        title='Loss Over Epochs',
        xlabel='Epoch',
        ylabel='Loss'))
    trainer.extend(Extensions.PlotReport(
        ['main/accuracy', 'validation/main/accuracy'],
        file_name='accuracy.png',
        title='Accuracy Over Epochs',
        xlabel='Epoch',
        ylabel='Accuracy'))
except Exception:
    pass

# Run training
trainer.run()

# Post-training evaluation
preds_vp = pred(model, x_vp)
preds_vn = pred(model, x_vn)

mis_pos = np.mean(preds_vp != 1)
mis_neg = np.mean(preds_vn != 0)
mr = prior * mis_pos + (1 - prior) * mis_neg
print(f"Miscalibration rate (mr): {mr:.4f}")