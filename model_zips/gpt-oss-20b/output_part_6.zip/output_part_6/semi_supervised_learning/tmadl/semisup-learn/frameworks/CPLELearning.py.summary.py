import uuid
import numpy as np
from collections import deque
from scipy.stats import ttest_ind
from sklearn.base import clone, BaseEstimator, ClassifierMixin, RegressorMixin
from sklearn.metrics import log_loss, accuracy_score
from sklearn.linear_model import LogisticRegression

try:
    import nlopt
except ImportError:
    raise ImportError("nlopt package is required for optimization")

class CPLELearningModel(BaseEstimator, ClassifierMixin):
    def __init__(self,
                 basemodel,
                 pessimistic=True,
                 use_sample_weighting=True,
                 predict_from_probabilities=True,
                 max_iter=100,
                 maxnoimprovementsince=10,
                 buffer_size=5,
                 verbose=False):
        self.basemodel = clone(basemodel)
        self.pessimistic = pessimistic
        self.use_sample_weighting = use_sample_weighting
        self.predict_from_probabilities = predict_from_probabilities
        self.max_iter = max_iter
        self.maxnoimprovementsince = maxnoimprovementsince
        self.buffer_size = buffer_size
        self.verbose = verbose
        self._id = uuid.uuid4().hex

        self.best_soft_labels_ = None
        self.best_likelihood_ = None
        self.platt_scaler_ = None
        self._has_predict_proba_ = hasattr(self.basemodel, "predict_proba")
        self._fitted_ = False

    def _discriminative_likelihood(self, Xl, yl, Xu, soft_labels):
        probs_l = self.basemodel.predict_proba(Xl)
        loss_l = log_loss(yl, probs_l, normalize=False)
        log_labeled = -loss_l

        probs_u = self.basemodel.predict_proba(Xu)
        # soft_labels assumed to be probability of class 1
        soft_labels = np.clip(soft_labels, 1e-12, 1 - 1e-12)
        log_probs_u = np.log(probs_u[:, 1])
        log_likelihood_u = np.sum(soft_labels * log_probs_u + (1 - soft_labels) * np.log(probs_u[:, 0]))

        if self.pessimistic:
            return log_labeled - log_likelihood_u
        else:
            return log_labeled + log_likelihood_u

    def _discriminative_likelihood_objective(self, soft_labels, grad):
        likelihood = self._discriminative_likelihood(self.labeledX_, self.labeledy_,
                                                    self.unlabeledX_, soft_labels)
        if self.verbose:
            print(f"Iteration {self.iteration_}, Likelihood: {likelihood:.4f}")

        self.likelihood_buffer_.append(likelihood)
        if len(self.likelihood_buffer_) > self.buffer_size:
            self.likelihood_buffer_.popleft()

        if len(self.likelihood_buffer_) == self.buffer_size:
            prev = np.array(self.likelihood_buffer_[:-1])
            curr = np.array(self.likelihood_buffer_[1:])
            _, p_value = ttest_ind(prev, curr, equal_var=False)
            if p_value > 0.05 and curr.mean() - prev.mean() < 1e-4:
                self.improvement_counter_ += 1
            else:
                self.improvement_counter_ = 0

        if likelihood > self.best_likelihood_:
            self.best_likelihood_ = likelihood
            self.best_soft_labels_ = np.copy(soft_labels)

        self.iteration_ += 1
        return -likelihood  # nlopt minimizes

    def fit(self, X, y, unlabeled_mask=None):
        if unlabeled_mask is None:
            unlabeled_mask = np.array([label is None for label in y])
        labeled_mask = ~unlabeled_mask

        self.labeledX_ = X[labeled_mask]
        self.labeledy_ = np.array(y)[labeled_mask]
        self.unlabeledX_ = X[unlabeled_mask]

        self.basemodel.fit(self.labeledX_, self.labeledy_)

        if not self._has_predict_proba_:
            preds = self.basemodel.predict_proba(self.labeledX_)
            self.platt_scaler_ = LogisticRegression(solver='lbfgs')
            self.platt_scaler_.fit(preds, self.labeledy_)

        init_soft_labels = self.basemodel.predict_proba(self.unlabeledX_)[:, 1]
        init_soft_labels = np.clip(init_soft_labels, 0.01, 0.99)

        opt = nlopt.opt(nlopt.GN_DIRECT_L_RAND, len(init_soft_labels))
        opt.set_lower_bounds([0.0] * len(init_soft_labels))
        opt.set_upper_bounds([1.0] * len(init_soft_labels))
        opt.set_maxeval(self.max_iter)
        opt.set_ftol_abs(1e-6)

        self.likelihood_buffer_ = deque(maxlen=self.buffer_size)
        self.iteration_ = 0
        self.improvement_counter_ = 0
        self.best_likelihood_ = -np.inf

        opt.set_min_objective(self._discriminative_likelihood_objective)

        try:
            opt_opt = opt.optimize(init_soft_labels)
        except Exception as e:
            if self.verbose:
                print(f"Optimization failed: {e}")

        if self.best_soft_labels_ is None:
            self.best_soft_labels_ = opt_opt

        combined_X = np.vstack([self.labeledX_, self.unlabeledX_])
        if self.use_sample_weighting:
            combined_y = np.concatenate([self.labeledy_,
                                         np.where(self.best_soft_labels_ >= 0.5, 1, 0)])
            weights = np.concatenate([np.ones(len(self.labeledy_)),
                                      np.maximum(self.best_soft_labels_, 1 - self.best_soft_labels_)])
            self.basemodel.fit(combined_X, combined_y, sample_weight=weights)
        else:
            combined_y = np.concatenate([self.labeledy_,
                                         np.where(self.best_soft_labels_ >= 0.5, 1, 0)])
            self.basemodel.fit(combined_X, combined_y)

        self._fitted_ = True
        if self.verbose:
            print(f"CPLETraining complete. Final Likelihood: {self.best_likelihood_:.4f}")
            print(f"Soft label distribution: mean={self.best_soft_labels_.mean():.4f}, std={self.best_soft_labels_.std():.4f}")
        return self

    def predict_proba(self, X):
        if not self._fitted_:
            raise ValueError("Model not fitted yet")
        if self._has_predict_proba_:
            return self.basemodel.predict_proba(X)
        else:
            preds = self.basemodel.predict_proba(X)
            return self.platt_scaler_.predict_proba(preds)

    def predict(self, X):
        probs = self.predict_proba(X)[:, 1]
        if self.predict_from_probabilities:
            thresh = probs.mean()
            return (probs >= thresh).astype(int)
        else:
            return self.basemodel.predict(X)

    def score(self, X, y):
        y_true = np.array(y)
        y_pred = self.predict(X)
        return accuracy_score(y_true, y_pred)