import pytest
import torch
from action_noise import (
    add_normal_noise_to_action,
    add_clipped_normal_noise_to_action,
    add_uniform_noise_to_action,
    add_ou_noise_to_action,
)


def _get_device(pytestconfig, idx=0):
    if torch.cuda.is_available():
        device_id = pytestconfig.getoption("gpu_device") or 0
        return torch.device(f"cuda:{device_id}")
    return torch.device("cpu")


class TestAllActionSpaceNoise:
    @pytest.mark.parametrize(
        "action,noise_param,exception,match",
        [
            # Valid normal noise: scalar std
            (torch.zeros([5, 2]), 0.1, None, None),
            # Valid normal noise: per-dimension std
            (torch.zeros([5, 2]), [0.1, 0.2], None, None),
            # Invalid: mismatched std length
            (torch.zeros([5, 2]), [0.1], ValueError, "std"),
            # Invalid: negative std
            (torch.zeros([5, 2]), -0.1, ValueError, "std"),
        ],
    )
    def test_add_normal_noise(self, action, noise_param, exception, match, pytestconfig):
        device = _get_device(pytestconfig)
        action = action.to(device)

        if exception is not None:
            with pytest.raises(exception, match=match):
                add_normal_noise_to_action(action, noise_param)
        else:
            result = add_normal_noise_to_action(action, noise_param)
            assert result.shape == action.shape
            assert result.device == device

    @pytest.mark.parametrize(
        "action,noise_param,clip_low,clip_high,exception,match",
        [
            # Valid clipped normal noise
            (
                torch.zeros([5, 3]),
                0.2,
                -1.0,
                1.0,
                None,
                None,
            ),
            # Valid per-dimension std with clipping
            (
                torch.zeros([5, 3]),
                [0.1, 0.2, 0.3],
                [-0.5, -0.5, -0.5],
                [0.5, 0.5, 0.5],
                None,
                None,
            ),
            # Invalid: mismatched std length
            (
                torch.zeros([5, 3]),
                [0.1, 0.2],
                -1.0,
                1.0,
                ValueError,
                "std",
            ),
            # Invalid: clip bounds mismatch
            (
                torch.zeros([5, 3]),
                0.2,
                [-1.0, -0.5],
                [1.0, 0.5],
                ValueError,
                "clip",
            ),
        ],
    )
    def test_add_clipped_normal_noise(
        self,
        action,
        noise_param,
        clip_low,
        clip_high,
        exception,
        match,
        pytestconfig,
    ):
        device = _get_device(pytestconfig)
        action = action.to(device)

        if exception is not None:
            with pytest.raises(exception, match=match):
                add_clipped_normal_noise_to_action(
                    action, noise_param, clip_low, clip_high
                )
        else:
            result = add_clipped_normal_noise_to_action(
                action, noise_param, clip_low, clip_high
            )
            assert result.shape == action.shape
            assert result.device == device

    @pytest.mark.parametrize(
        "action,low,high,exception,match",
        [
            # Valid uniform noise
            (torch.zeros([4, 2]), -0.5, 0.5, None, None),
            # Valid per-dimension ranges
            (
                torch.zeros([4, 2]),
                [-0.5, -0.3],
                [0.5, 0.3],
                None,
                None,
            ),
            # Invalid: low > high
            (torch.zeros([4, 2]), 1.0, -1.0, ValueError, "low > high"),
            # Invalid: range length mismatch
            (torch.zeros([4, 2]), [-0.5], 0.5, ValueError, "range"),
        ],
    )
    def test_add_uniform_noise(
        self, action, low, high, exception, match, pytestconfig
    ):
        device = _get_device(pytestconfig)
        action = action.to(device)

        if exception is not None:
            with pytest.raises(exception, match=match):
                add_uniform_noise_to_action(action, low, high)
        else:
            result = add_uniform_noise_to_action(action, low, high)
            assert result.shape == action.shape
            assert result.device == device

    @pytest.mark.parametrize(
        "action,noise_param,reset,exception,match",
        [
            # OU noise with reset=True
            (torch.zeros([3, 1]), 0.2, True, None, None),
            # OU noise with reset=False
            (torch.zeros([3, 1]), 0.2, False, None, None),
            # Invalid: negative sigma
            (torch.zeros([3, 1]), -0.2, True, ValueError, "sigma"),
            # Invalid: mismatched noise_param length
            (torch.zeros([3, 1]), [0.1, 0.2], True, ValueError, "param"),
        ],
    )
    def test_add_ou_noise(
        self, action, noise_param, reset, exception, match, pytestconfig
    ):
        device = _get_device(pytestconfig)
        action = action.to(device)

        if exception is not None:
            with pytest.raises(exception, match=match):
                add_ou_noise_to_action(action, noise_param, reset=reset)
        else:
            result = add_ou_noise_to_action(action, noise_param, reset=reset)
            assert result.shape == action.shape
            assert result.device == device

# Required pytest command-line options for GPU configuration
def pytest_addoption(parser):
    parser.addoption(
        "--gpu_device",
        action="store",
        default=0,
        type=int,
        help="GPU device index to use for testing",
    )