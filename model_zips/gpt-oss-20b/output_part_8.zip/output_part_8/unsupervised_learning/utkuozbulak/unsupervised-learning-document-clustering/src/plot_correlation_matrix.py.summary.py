import string
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Example similarity matrix (replace with actual data)
np.random.seed(0)
n_docs = 10
similarity_matrix = np.random.rand(n_docs, n_docs)

# Configure seaborn style and font scale
sns.set_style("white")
sns.set(font_scale=1)

# Create mask for upper triangular part
mask = np.zeros_like(similarity_matrix, dtype=bool)
mask[np.triu_indices_from(mask)] = True

# Initialize figure and axis
fig, ax = plt.subplots(figsize=(11, 9))

# Plot heatmap
sns.heatmap(
    similarity_matrix,
    mask=mask,
    cmap="viridis",
    vmax=0.8,
    square=True,
    linewidths=.5,
    ax=ax
)

# Label axes
ax.set_xlabel("Document ID", fontsize=25)
ax.set_ylabel("Document ID", fontsize=25)

# Add title
fig.suptitle("TF-IDF Document Similarity Matrix", fontsize=25)

# Save figure
fig.savefig("output.png", dpi=300, bbox_inches="tight")

# Display plot
plt.show()