import numpy as np

class TimeStep:
    def __init__(self, method: str, eta: float, len1: int):
        self.method = method
        self.eta = eta
        self.len1 = len1
        self.list1_cum_grad = [None] * len1
        self.list1_cum_sq_grad = [None] * len1

    def get_delta_conc(self, grad0: np.ndarray, grad1: np.ndarray, cur_t: int, k: int) -> np.ndarray:
        grad = grad0 + grad1

        if self.method == "naive":
            delta = self.eta * grad

        elif self.method == "naive_t":
            delta = (self.eta / (cur_t + 1)) * grad

        elif self.method == "mag1_grad":
            magnitude = np.sqrt(np.sum(grad0 ** 2 + grad1 ** 2, axis=None, keepdims=True))
            magnitude = np.where(magnitude == 0, 1e-12, magnitude)
            delta = (self.eta * grad) / magnitude

        elif self.method == "ada_grad":
            if cur_t == 0 or self.list1_cum_sq_grad[k] is None:
                self.list1_cum_sq_grad[k] = grad ** 2
            else:
                self.list1_cum_sq_grad[k] += grad ** 2
            denom = np.sqrt(self.list1_cum_sq_grad[k]) + 1e-6
            delta = (self.eta * grad) / denom

        elif self.method == "adam":
            if cur_t == 0 or self.list1_cum_grad[k] is None:
                self.list1_cum_grad[k] = grad
                self.list1_cum_sq_grad[k] = grad ** 2
            else:
                self.list1_cum_grad[k] += grad
                self.list1_cum_sq_grad[k] += grad ** 2
            denom = np.sqrt(self.list1_cum_sq_grad[k]) + 1e-6
            delta = (self.eta * grad * self.list1_cum_grad[k]) / denom

        else:
            raise AssertionError(f"Unsupported method: {self.method}")

        return delta
