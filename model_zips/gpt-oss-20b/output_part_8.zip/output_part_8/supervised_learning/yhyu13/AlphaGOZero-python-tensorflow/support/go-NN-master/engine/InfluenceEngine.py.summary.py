import random
import numpy as np
import tensorflow as tf

from Engine import Engine
from Board import Board
from Features import Features
from Symmetry import Symmetry
from Checkpoint import Checkpoint


class InfluenceEngine(Engine):
    def __init__(self, model):
        self.model = model
        self.graph = tf.Graph()
        with self.graph.as_default():
            self.feature_planes = tf.placeholder(
                tf.float32,
                shape=[None, model.N, model.N, model.Nfeat],
                name='feature_planes',
            )
            self.logits = model.inference(self.feature_planes)
            self.init_op = tf.global_variables_initializer()
        self.sess = tf.Session(graph=self.graph)
        self.sess.run(self.init_op)
        Checkpoint.restore_from_checkpoint(model.train_dir, self.sess)

    def make_influence_map(self, board: Board, player: int) -> np.ndarray:
        if self.model.Nfeat == 15:
            planes = Features.make_feature_planes_stones_3liberties_4history_ko(board, player)
        else:
            raise ValueError(f"Unsupported number of feature planes: {self.model.Nfeat}")

        # Normalization step (disabled)
        # planes = (planes - planes.mean(axis=(0, 1), keepdims=True)) / (planes.std(axis=(0, 1), keepdims=True) + 1e-8)

        batch = Symmetry.make_symmetry_batch(planes, num_symmetries=8)
        feed_dict = {self.feature_planes: batch}
        logits_batch = self.sess.run(self.logits, feed_dict=feed_dict)
        logits = Symmetry.average_plane_over_symmetries(logits_batch)

        influence = np.tanh(logits)
        if player == Board.WHITE:
            influence = -influence
        return influence

    def pick_move(self, board: Board, player: int):
        for _ in range(10000):
            x = random.randint(0, board.size - 1)
            y = random.randint(0, board.size - 1)
            if board.play_is_legal(x, y, player):
                return (x, y)
        return Board.PASS

    def __del__(self):
        if hasattr(self, 'sess'):
            self.sess.close()
