import pandas as pd
import numpy as np
import patsy


def get_dataframe_intersection(df: pd.DataFrame, comparator1: pd.DataFrame, comparator2: pd.DataFrame) -> pd.DataFrame:
    """
    Keep only the columns that are present in both comparator1 and comparator2.
    """
    common_cols = [col for col in comparator1.columns if col in comparator2.columns]
    return df[common_cols].copy()


def get_dataframes_intersections(df1: pd.DataFrame, comparator1: pd.DataFrame,
                                 df2: pd.DataFrame, comparator2: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Align two dataframes so that they share the same column structure.
    """
    # Align comparator1 to the intersection with comparator2
    aligned_comparator1 = get_dataframe_intersection(comparator1, df1, comparator2)
    # Align comparator2 to the intersection with the already aligned comparator1
    aligned_comparator2 = get_dataframe_intersection(comparator2, df2, aligned_comparator1)
    return aligned_comparator1, aligned_comparator2


def predict(test_data: pd.DataFrame, results: dict, model_name: str) -> np.ndarray:
    """
    Generate predictions for test_data using a statistical model specified in results.
    """
    # Step 1: Extract formula and parameters
    formula = results["formula"]
    params_series = results["params"]

    # Step 2: Generate design matrix for test data
    _, xt = patsy.dmatrices(formula, test_data, return_type="dataframe")

    # Convert model parameters to a DataFrame
    params_df = pd.DataFrame([params_series], columns=params_series.index)

    # Step 3: Align xt and model parameters
    aligned_xt, aligned_params = get_dataframes_intersections(xt, xt, params_df, params_df)

    # Step 4: Convert to NumPy arrays
    xt_np = aligned_xt.to_numpy()
    params_np = aligned_params.to_numpy()

    # Step 5: Repeat parameters across rows
    params_repeated = np.tile(params_np, (xt_np.shape[0], 1))

    # Step 6: Compute predictions
    predictions = np.sum(xt_np * params_repeated, axis=1)

    return predictions