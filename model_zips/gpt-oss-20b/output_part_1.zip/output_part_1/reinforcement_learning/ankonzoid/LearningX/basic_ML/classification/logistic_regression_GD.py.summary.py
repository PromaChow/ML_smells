import random
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import log_loss

random.seed(10)
np.random.seed(10)

def split(indices, fractions, seed=1):
    rng = random.Random(seed)
    shuffled = indices.copy()
    rng.shuffle(shuffled)
    groups = []
    start = 0
    for frac in fractions:
        end = start + int(round(len(indices) * frac))
        groups.append(shuffled[start:end])
        start = end
    return groups

def sigmoid(z):
    return 1.0 / (1.0 + np.exp(-z))

class LogisticRegressorGD:
    def __init__(self, n_features, eta=10.0, max_iter=10000, tol=1e-4, random_state=None):
        rng = np.random.default_rng(random_state)
        self.a_fit = rng.normal(size=n_features + 1)
        self.eta = eta
        self.max_iter = max_iter
        self.tol = tol
        self.loss_history = []

    def _add_bias(self, X):
        return np.hstack((np.ones((X.shape[0], 1)), X))

    def train(self, X_train, y_train, X_val, y_val):
        Xb_train = self._add_bias(X_train)
        Xb_val = self._add_bias(X_val)
        prev_loss = None
        for _ in range(self.max_iter):
            preds = sigmoid(Xb_train @ self.a_fit)
            error = preds - y_train
            grad = np.concatenate(([error.mean()], (error[:, None] * X_train).mean(axis=0)))
            self.a_fit -= self.eta * grad
            loss = log_loss(y_train, preds, eps=1e-15)
            self.loss_history.append(loss)
            if prev_loss is not None and abs(prev_loss - loss) < self.tol:
                break
            if loss < self.tol:
                break
            prev_loss = loss
        val_preds = sigmoid(Xb_val @ self.a_fit)
        val_loss = log_loss(y_val, val_preds, eps=1e-15)
        return loss, val_loss

    def predict_proba(self, X):
        Xb = self._add_bias(X)
        return sigmoid(Xb @ self.a_fit)

    def predict(self, X, threshold=0.5):
        return (self.predict_proba(X) >= threshold).astype(int)

# Generate synthetic data
n_samples = 200
class0 = np.random.uniform(0, 0.6, size=(n_samples // 2, 1))
class1 = np.random.uniform(0.4, 1.0, size=(n_samples // 2, 1))
X = np.vstack((class0, class1))
y = np.array([0] * (n_samples // 2) + [1] * (n_samples // 2))

# Split into training and validation sets
indices = np.arange(n_samples)
train_idx, val_idx = split(indices, [0.8, 0.2], seed=1)
X_train, X_val = X[train_idx], X[val_idx]
y_train, y_val = y[train_idx], y[val_idx]

# Train logistic regression with gradient descent
model = LogisticRegressorGD(n_features=1, eta=10.0, max_iter=10000, tol=1e-4, random_state=1)
train_loss, val_loss = model.train(X_train, y_train, X_val, y_val)

# Evaluate losses
final_train_loss = log_loss(y_train, model.predict_proba(X_train), eps=1e-15)
final_val_loss = log_loss(y_val, model.predict_proba(X_val), eps=1e-15)

print(f"Training loss: {final_train_loss:.6f}")
print(f"Validation loss: {final_val_loss:.6f}")

# Plot data and model fit
plt.figure(figsize=(10, 6))
plt.scatter(X_train, y_train, color='blue', alpha=0.6, label='Train')
plt.scatter(X_val, y_val, color='orange', alpha=0.6, label='Validation')

# Plot predicted probabilities sorted by feature value
X_plot = np.linspace(0, 1, 200).reshape(-1, 1)
probs = model.predict_proba(X_plot)
plt.plot(X_plot, probs, color='green', label='Fit')

plt.xlabel('Feature')
plt.ylabel('Probability of class 1')
plt.title('Logistic Regression Fit with Gradient Descent')
plt.legend()
plt.grid(True)
plt.show()