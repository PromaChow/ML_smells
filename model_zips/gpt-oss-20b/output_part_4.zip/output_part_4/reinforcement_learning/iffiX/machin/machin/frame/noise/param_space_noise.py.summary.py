import torch
import torch.nn as nn
from typing import Callable, Any, List, Optional, Tuple


class Switch:
    """Simple on/off switch."""
    def __init__(self, on: bool = True) -> None:
        self.state = on

    def on(self) -> None:
        self.state = True

    def off(self) -> None:
        self.state = False

    def is_on(self) -> bool:
        return self.state


class NormalNoiseGen:
    """Standard normal noise generator."""
    def __init__(self, mean: float = 0.0, std: float = 1.0) -> None:
        self.mean = mean
        self.std = std

    def __call__(self, shape: Tuple[int, ...], device: Optional[torch.device] = None) -> torch.Tensor:
        return torch.randn(shape, device=device, dtype=torch.float32) * self.std + self.mean


class AdaptiveParamNoise:
    """
    Adaptive parameter space noise for exploration.
    """
    def __init__(
        self,
        initial_stddev: float,
        desired_action_stddev: float,
        adoption_coefficient: float,
        noise_generator_args: Optional[tuple] = None,
        noise_generator_kwargs: Optional[dict] = None,
        noise_generate_function: Optional[Callable[[tuple, Optional[torch.device]], torch.Tensor]] = None,
        distance_func: Optional[Callable[[torch.Tensor, torch.Tensor], torch.Tensor]] = None,
    ) -> None:
        self.initial_stddev = initial_stddev
        self.desired_action_stddev = desired_action_stddev
        self.adoption_coefficient = adoption_coefficient
        self.current_stddev = initial_stddev

        if noise_generate_function is not None:
            self.noise_gen = noise_generate_function
        else:
            args = noise_generator_args if noise_generator_args is not None else ()
            kwargs = noise_generator_kwargs if noise_generator_kwargs is not None else {}
            self.noise_gen = NormalNoiseGen(*args, **kwargs)

        if distance_func is not None:
            self.distance_func = distance_func
        else:
            # Default: Euclidean distance between flattened outputs
            self.distance_func = lambda out1, out2: torch.norm((out1 - out2).flatten())

        self.perturb_switch = Switch(True)
        self.reset_switch = Switch(False)

        self.hooks: List[Any] = []
        self._clean_output: Optional[torch.Tensor] = None
        self.in_perturb_mode: bool = False

    def _add_perturb_hook(self, model: nn.Module) -> None:
        """
        Register hooks on the model to apply and remove parameter noise.
        """
        for module in model.modules():
            if isinstance(module, nn.Module):
                pre_hook = module.register_forward_pre_hook(self._perturb_pre_hook)
                post_hook = module.register_backward_hook(self._perturb_post_hook)
                self.hooks.extend([pre_hook, post_hook])

        # Forward hook to adjust noise after each forward pass
        adjust_hook = model.register_forward_hook(self._perturb_adjust_hook)
        self.hooks.append(adjust_hook)

    def _perturb_pre_hook(self, module: nn.Module, input: Any) -> None:
        self.in_perturb_mode = self.perturb_switch.is_on()
        for param in module.parameters(recurse=False):
            if not hasattr(param, "_original_data"):
                param._original_data = param.data.clone()

            if self.perturb_switch.is_on():
                if self.reset_switch.is_on() or not hasattr(param, "_noise"):
                    param._noise = self.noise_gen(param.shape, device=param.device)
                noise = param._noise
                param.data.copy_(param._original_data + noise * self.current_stddev)
            else:
                param.data.copy_(param._original_data)

    def _perturb_post_hook(self, module: nn.Module, grad_input: Any, grad_output: Any) -> None:
        for param in module.parameters(recurse=False):
            if hasattr(param, "_original_data"):
                param.data.copy_(param._original_data)

    def _perturb_adjust_hook(self, module: nn.Module, output: torch.Tensor) -> None:
        """
        Called after the forward pass of the entire model.
        Computes distance between clean and noisy outputs and adjusts noise.
        """
        if not self.in_perturb_mode:
            # Store clean output for later comparison
            self._clean_output = output.detach()
        else:
            if self._clean_output is None:
                return  # No clean reference, skip adjustment
            distance = self.distance_func(self._clean_output, output.detach())
            if distance > self.desired_action_stddev:
                self.current_stddev /= self.adoption_coefficient
            else:
                self.current_stddev *= self.adoption_coefficient
            # Reset clean output after adjustment
            self._clean_output = None

    def perturb_model(self, model: nn.Module) -> Callable[[], None]:
        """
        Apply adaptive noise to the model and return a cancellation function.
        """
        self._add_perturb_hook(model)

        def cancel() -> None:
            for hook in self.hooks:
                hook.remove()
            self.hooks.clear()

        return cancel


# Example usage:
# model = SomePyTorchModel()
# adaptive_noise = AdaptiveParamNoise(
#     initial_stddev=0.1,
#     desired_action_stddev=0.2,
#     adoption_coefficient=1.5
# )
# cancel_perturb = adaptive_noise.perturb_model(model)
#
# # During training loop:
# for data in dataloader:
#     # First forward pass without noise to obtain clean actions
#     adaptive_noise.perturb_switch.off()
#     clean_output = model(data)
#
#     # Second forward pass with noise to obtain noisy actions
#     adaptive_noise.perturb_switch.on()
#     noisy_output = model(data)
#
#     # Compute loss, backprop, etc.
#     loss = compute_loss(clean_output, noisy_output)
#     loss.backward()
#     optimizer.step()
#
# # When done:
# cancel_perturb()
