import numpy as np

class GameState:
    ROWS = 6
    COLS = 7

    def __init__(self, board=None, playerTurn=1):
        self.board = np.zeros((self.ROWS, self.COLS), dtype=int) if board is None else board.copy()
        self.playerTurn = playerTurn
        self.winners = self._generate_winners()

    def _generate_winners(self):
        winners = []
        # Horizontal
        for r in range(self.ROWS):
            for c in range(self.COLS - 3):
                winners.append([(r, c + i) for i in range(4)])
        # Vertical
        for r in range(self.ROWS - 3):
            for c in range(self.COLS):
                winners.append([(r + i, c) for i in range(4)])
        # Diagonal /
        for r in range(self.ROWS - 3):
            for c in range(self.COLS - 3):
                winners.append([(r + i, c + i) for i in range(4)])
        # Diagonal \
        for r in range(3, self.ROWS):
            for c in range(self.COLS - 3):
                winners.append([(r - i, c + i) for i in range(4)])
        return winners

    def _allowedActions(self):
        actions = []
        for c in range(self.COLS):
            for r in range(self.ROWS):
                if self.board[r, c] == 0:
                    if r == self.ROWS - 1 or self.board[r + 1, c] != 0:
                        actions.append(c)
                        break
        return actions

    def _binary(self):
        curr = (self.board == self.playerTurn).astype(int)
        opp = (self.board == -self.playerTurn).astype(int)
        return np.stack([curr, opp], axis=0)

    def _convertStateToId(self):
        return ''.join(map(str, self.board.flatten()))

    def _checkForEndGame(self):
        # Check winner
        for line in self.winners:
            cells = [self.board[r, c] for r, c in line]
            if all(cell == self.playerTurn for cell in cells):
                return self.playerTurn
            if all(cell == -self.playerTurn for cell in cells):
                return -self.playerTurn
        # Check draw
        if not np.any(self.board == 0):
            return 0
        return None

    def takeAction(self, action):
        new_board = self.board.copy()
        for r in range(self.ROWS):
            if new_board[r, action] == 0:
                new_board[r, action] = self.playerTurn
                break
        next_player = -self.playerTurn
        new_state = GameState(new_board, next_player)
        result = new_state._checkForEndGame()
        if result is None:
            reward = 0
            done = 0
        elif result == 0:
            reward = 0
            done = 1
        elif result == self.playerTurn:
            reward = -1
            done = 1
        else:
            reward = 1
            done = 1
        return new_state, reward, done

    @staticmethod
    def identities(state, actionValues):
        states = []
        values = []
        # Original
        states.append(state)
        values.append(actionValues)
        # Horizontal flip
        flipped_board = np.fliplr(state.board)
        flipped_state = GameState(flipped_board, state.playerTurn)
        flipped_values = actionValues[::-1]
        states.append(flipped_state)
        values.append(flipped_values)
        # Vertical flip
        flipped_board_v = np.flipud(state.board)
        flipped_state_v = GameState(flipped_board_v, state.playerTurn)
        states.append(flipped_state_v)
        values.append(actionValues)
        return list(zip(states, values))

    def render(self, logger=None):
        symbols = {1: 'X', -1: 'O', 0: '-'}
        rows = []
        for r in reversed(range(self.ROWS)):
            row = ' '.join(symbols[self.board[r, c]] for c in range(self.COLS))
            rows.append(row)
        board_str = '\n'.join(rows)
        if logger:
            logger(board_str)
        else:
            print(board_str)

class Game:
    def __init__(self):
        self.pieces = {1: 'X', -1: 'O', 0: '-'}
        self.actionSpace = np.zeros(42, dtype=int)
        self.reset()

    def reset(self):
        board = np.zeros((GameState.ROWS, GameState.COLS), dtype=int)
        self.current_state = GameState(board, 1)
        return self.current_state

    def step(self, action):
        new_state, reward, done = self.current_state.takeAction(action)
        self.current_state = new_state
        return new_state, reward, done

    def render(self, logger=None):
        self.current_state.render(logger=logger)
```