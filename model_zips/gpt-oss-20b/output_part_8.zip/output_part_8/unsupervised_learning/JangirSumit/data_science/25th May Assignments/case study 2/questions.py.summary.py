import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression

# Load dataset
df = pd.read_csv('cereal.csv')

# Display first rows
print(df.head())

# Histograms of sugars and vitamins
plt.figure(figsize=(8, 6))
plt.hist(df['sugars'], bins=10, color='orange', alpha=0.7, label='Sugars')
plt.hist(df['vitamins'], bins=10, color='green', alpha=0.7, label='Vitamins')
plt.xlabel('Sugars and Vitamins')
plt.title('Distribution of Sugars and Vitamins')
plt.legend()
plt.tight_layout()
plt.show()

# Manufacturer mapping
mfr_dict = {
    'A': 'Archer Daniels Midland',
    'B': 'Bimbo',
    'C': 'Cereals',
    'D': 'Dairy Farmers',
    'E': 'Envision',
    'F': 'Fairfield',
    'G': 'Grandma',
    'H': 'Hy',
    'I': 'Iowa',
    'J': 'Jolly',
    'K': 'Kelloggs',
    'L': 'Lactose',
    'M': 'Miller',
    'N': 'Nabisco',
    'O': 'Oatmeal',
    'P': 'Pepsi',
    'Q': 'Quaker',
    'R': 'Reckitt',
    'S': 'Seventh',
    'T': 'Terry',
    'U': 'Upton',
    'V': 'Vermont',
    'W': 'Wheaties',
    'X': 'Xylitol',
    'Y': 'Yogurt',
    'Z': 'Zucchini'
}

df['manufactures'] = df['mfr'].map(mfr_dict).fillna(df['mfr'])

# Count cereals per manufacturer
manufacturer_counts = (
    df.groupby('manufactures')
    .size()
    .reset_index(name='count')
    .sort_values('count', ascending=False)
)

# Bar plot
plt.figure(figsize=(10, 6))
sns.barplot(x='count', y='manufactures', data=manufacturer_counts, orient='h')
plt.xlabel('Count of Cereals')
plt.ylabel('Manufacturer')
plt.title('Number of Cereals per Manufacturer')
plt.tight_layout()
plt.show()

# Prepare data for modeling
y = df['rating']
X = df.iloc[:, 2:14]  # columns 3 to 14 inclusive

# Split into training and test sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42
)

# Fit linear regression
model = LinearRegression()
model.fit(X_train, y_train)

# Predict on test set
y_pred = model.predict(X_test)

# Scatter plot of predicted vs actual ratings
plt.figure(figsize=(8, 6))
plt.scatter(y_pred, y_test, alpha=0.7)
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--')
plt.xlabel('Predicted Rating')
plt.ylabel('Actual Rating')
plt.title('Predicted vs Actual Ratings')
plt.tight_layout()
plt.show()

# Print R^2 score
print(f'R^2: {model.score(X_test, y_test):.4f}')