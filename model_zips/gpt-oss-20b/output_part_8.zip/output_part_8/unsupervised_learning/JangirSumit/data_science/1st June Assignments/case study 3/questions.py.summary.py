import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA

df = pd.read_csv('breast-cancer-data.csv', index_col=0)
print(df.head())

X = df.drop(columns='diagnosis')
pca = PCA(n_components=2)
principal_components = pca.fit_transform(X)
pc_df = pd.DataFrame(data=principal_components, columns=['PC1', 'PC2'], index=df.index)

pc_df['diagnosis'] = df['diagnosis']

print("Explained variance ratio:", pca.explained_variance_ratio_)