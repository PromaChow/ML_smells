import os
import sys
import numpy as np
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn import metrics

# Path to the directory containing the custom semisupervised module
local_path = "/path/to/local"
os.chdir(local_path)
sys.path.append(local_path)

from semisupervised import S3VM

def normalize(x):
    return (x - np.min(x, axis=0)) / (np.max(x, axis=0) - np.min(x, axis=0))

# Load dataset
data = load_breast_cancer()
X, y = data.data, data.target
X = normalize(X)

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.6, random_state=0, stratify=y
)

# Corrupt labels: mark 10% of training samples as unlabeled (-1)
rng = np.random.RandomState(42)
n_unlabeled = int(0.1 * len(y_train))
unlabeled_idx = rng.choice(len(y_train), size=n_unlabeled, replace=False)
y_train[unlabeled_idx] = -1

# Separate labeled and unlabeled data
label_mask = y_train != -1
label_X_train = X_train[label_mask]
label_y_train = y_train[label_mask]

unlabel_mask = y_train == -1
unlabel_X_train = X_train[unlabel_mask]
unlabel_y = np.full(unlabel_X_train.shape[0], -1)

# Combine labeled and unlabeled data
X_combined = np.vstack((label_X_train, unlabel_X_train))
y_combined = np.append(label_y_train, unlabel_y)

# Train S3VM
model = S3VM()
model.fit(X_combined, y_combined)

# Predict and evaluate
y_pred = model.predict(X_test)
accuracy = metrics.accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy:.4f}")