import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import beta
from scipy.special import digamma

class TimeStep:
    def __init__(self, eta=0.01, method='ada_grad', eps=1e-8):
        self.eta = eta
        self.method = method
        self.eps = eps
        self.g2 = None

    def init_state(self, shape):
        self.g2 = np.zeros(shape)

    def update(self, grad):
        self.g2 += grad**2
        return self.eta * grad / np.sqrt(self.g2 + self.eps)

class Plotter:
    def __init__(self, title='BBVI Fit'):
        self.title = title

    def plot(self, conc0_trace, conc1_trace, delta_conc_trace, elbo_trace):
        nt, k = conc0_trace.shape
        fig, axs = plt.subplots(k, 4, figsize=(20, 4*k))
        for i in range(k):
            axs[i, 0].plot(conc0_trace[:, i], label='conc0')
            axs[i, 0].set_title(f'Component {i} conc0')
            axs[i, 1].plot(conc1_trace[:, i], label='conc1')
            axs[i, 1].set_title(f'Component {i} conc1')
            axs[i, 2].plot(delta_conc_trace[:, i, 0], label='delta conc0')
            axs[i, 2].plot(delta_conc_trace[:, i, 1], label='delta conc1')
            axs[i, 2].set_title(f'Component {i} delta conc')
            axs[i, 3].plot(elbo_trace[:, i], label='ELBO')
            axs[i, 3].set_title(f'Component {i} ELBO')
            for ax in axs[i]:
                ax.legend()
        plt.suptitle(self.title)
        plt.tight_layout(rect=[0, 0.03, 1, 0.95])
        plt.show()

class NbTrolsModel:
    def __init__(self, theta_true, noise_std=0.1):
        self.K = len(theta_true)
        self.theta_true = np.array(theta_true)
        self.noise_std = noise_std

    def log_py(self, y, z):
        return -0.5 * np.sum((y - z)**2, axis=0) / self.noise_std**2 \
               - 0.5 * y.shape[0] * np.log(2 * np.pi * self.noise_std**2)

    def log_px(self, x, z):
        return np.zeros(z.shape[1])

    def log_pz(self, z):
        return np.zeros(z.shape[1])

    def log_qz(self, z, conc0, conc1):
        return beta.logpdf(z, conc0, conc1)

class Fitter:
    def __init__(self, mod, y_nsam_nb, x_nsam_na, nsamgrad=10, nt=1000,
                 eta=0.01, t_step_meth='ada_grad'):
        self.mod = mod
        self.y = y_nsam_nb
        self.x = x_nsam_na
        self.nsamgrad = nsamgrad
        self.nt = nt
        self.eta = eta
        self.t_step_meth = t_step_meth
        self.K = mod.K
        self.nsam = y_nsam_nb.shape[0]

        # Initialize traces
        self.conc0_trace = np.zeros((nt, self.K))
        self.conc1_trace = np.zeros((nt, self.K))
        self.delta_conc_trace = np.zeros((nt, self.K, 2))
        self.elbo_trace = np.zeros((nt, self.K))

    def get_delbo_and_grad_delbo(self, conc0, conc1):
        # Sample from Beta distribution
        z = beta.rvs(conc0, conc1, size=(self.nsamgrad, self.K))

        # Log probabilities
        log_py = self.mod.log_py(self.y, z)
        log_px = self.mod.log_px(self.x, z)
        log_pz = self.mod.log_pz(z)
        log_qz = self.mod.log_qz(z, conc0, conc1)

        elbo = log_py + log_px + log_pz - log_qz  # shape (nsamgrad, K)

        # Gradients w.r.t conc0 and conc1
        log_z = np.log(z)
        log_1_z = np.log(1 - z)

        grad_conc0 = - (log_z - digamma(conc0) + digamma(conc0 + conc1))
        grad_conc1 = - (log_1_z - digamma(conc1) + digamma(conc0 + conc1))

        # Average over samples
        elbo_mean = np.mean(elbo, axis=0)
        grad_conc0_mean = np.mean(grad_conc0, axis=0)
        grad_conc1_mean = np.mean(grad_conc1, axis=0)

        return elbo_mean, grad_conc0_mean, grad_conc1_mean

    def do_fit(self):
        # Initial uniform parameters
        conc0 = np.full(self.K, 1.0)
        conc1 = np.full(self.K, 1.0)

        timestep = TimeStep(eta=self.eta, method=self.t_step_meth)
        timestep.init_state(self.K * 2)  # two parameters per component

        for t in range(self.nt):
            elbo, grad0, grad1 = self.get_delbo_and_grad_delbo(conc0, conc1)

            # Update parameters
            delta0 = timestep.update(grad0)
            delta1 = timestep.update(grad1)

            conc0 += delta0
            conc1 += delta1

            # Clip bounds
            conc0 = np.clip(conc0, 1e-5, 15)
            conc1 = np.clip(conc1, 1e-5, 15)

            # Store traces
            self.conc0_trace[t] = conc0
            self.conc1_trace[t] = conc1
            self.delta_conc_trace[t, :, 0] = delta0
            self.delta_conc_trace[t, :, 1] = delta1
            self.elbo_trace[t] = elbo

            # Check convergence
            if np.all(np.abs(delta0) < 0.001) and np.all(np.abs(delta1) < 0.001):
                self.fin_t = t
                break
        else:
            self.fin_t = self.nt - 1

        self.final_conc0 = conc0
        self.final_conc1 = conc1

    def print_fit_values_at_fin_t(self):
        mean_z = self.final_conc0 / (self.final_conc0 + self.final_conc1)
        var_z = (self.final_conc0 * self.final_conc1) / \
                ((self.final_conc0 + self.final_conc1)**2 * (self.final_conc0 + self.final_conc1 + 1))
        std_z = np.sqrt(var_z)

        print("Component\tMean_z\tStd_z\tPrior_theta\tFrac_error")
        for k in range(self.K):
            frac_err = (mean_z[k] - self.mod.theta_true[k]) / self.mod.theta_true[k]
            print(f"{k}\t{mean_z[k]:.4f}\t{std_z[k]:.4f}\t{self.mod.theta_true[k]:.4f}\t{frac_err:.4f}")

    def plot_fit_traces(self):
        plotter = Plotter()
        plotter.plot(self.conc0_trace, self.conc1_trace,
                     self.delta_conc_trace, self.elbo_trace)

if __name__ == "__main__":
    # Toy data generation
    K = 3
    np.random.seed(0)
    theta_true = np.random.rand(K)
    model = NbTrolsModel(theta_true)

    nsam = 200
    y = np.random.normal(loc=theta_true, scale=0.1, size=(nsam, K))
    x = np.zeros((nsam, 1))  # dummy inputs

    # Fitter parameters
    nsamgrad = 20
    nt = 500
    eta = 0.01
    t_step_meth = 'ada_grad'

    fitter = Fitter(model, y, x, nsamgrad, nt, eta, t_step_meth)
    fitter.do_fit()
    fitter.print_fit_values_at_fin_t()
    fitter.plot_fit_traces()
