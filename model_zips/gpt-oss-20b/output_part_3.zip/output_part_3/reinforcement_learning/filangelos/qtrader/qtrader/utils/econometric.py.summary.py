import numpy as np
import pandas as pd


def _check_ndim(arr, name, max_ndim=2):
    if isinstance(arr, pd.DataFrame) or isinstance(arr, pd.Series):
        if arr.ndim > max_ndim:
            raise ValueError(f"{name} expects at most {max_ndim} dimensions.")
    elif isinstance(arr, np.ndarray):
        if arr.ndim > max_ndim:
            raise ValueError(f"{name} expects at most {max_ndim} dimensions.")
    else:
        raise TypeError(f"{name} received unsupported type {type(arr)}.")


def _to_numpy(arr):
    if isinstance(arr, pd.Series) or isinstance(arr, pd.DataFrame):
        return arr.values
    return np.asarray(arr)


def cum_returns(returns):
    _check_ndim(returns, "cum_returns")
    r = _to_numpy(returns)
    cum = (1 + r).cumprod(axis=0) - 1
    return cum


def pnl(returns):
    _check_ndim(returns, "pnl")
    r = _to_numpy(returns)
    return (1 + r).cumprod(axis=0)


def sharpe_ratio(returns):
    _check_ndim(returns, "sharpe_ratio")
    r = _to_numpy(returns)
    mean = r.mean(axis=0)
    std = r.std(axis=0, ddof=1)
    periods = r.shape[0]
    return (mean / std) * np.sqrt(periods)


def hit_ratio(returns):
    _check_ndim(returns, "hit_ratio")
    r = _to_numpy(returns)
    positives = r > 0
    return positives.sum(axis=0) / r.shape[0]


def awal(returns):
    _check_ndim(returns, "awal")
    r = _to_numpy(returns)
    pos = r[r > 0]
    neg = r[r < 0]
    if pos.size == 0 or neg.size == 0:
        return np.nan
    avg_pos = pos.mean()
    avg_neg = neg.mean()
    return abs(avg_pos) / abs(avg_neg)


def appt(returns):
    _check_ndim(returns, "appt")
    r = _to_numpy(returns)
    pos = r[r > 0]
    neg = r[r < 0]
    if r.size == 0:
        return np.nan
    win_prop = pos.size / r.size
    lose_prop = neg.size / r.size
    avg_pos = pos.mean() if pos.size else 0
    avg_neg = neg.mean() if neg.size else 0
    return win_prop * avg_pos - lose_prop * avg_neg


def _drawdown(returns):
    cum = cum_returns(returns)
    peak = np.maximum.accumulate(cum)
    dd = peak - cum
    return dd


def drawdown(returns):
    _check_ndim(returns, "drawdown")
    return _drawdown(returns)


def max_drawdown(returns):
    _check_ndim(returns, "max_drawdown")
    dd = drawdown(returns)
    return dd.min()


def average_drawdown_time(returns):
    _check_ndim(returns, "average_drawdown_time")
    dd = drawdown(returns)
    recovery_points = np.where(dd == 0)[0]
    if recovery_points.size < 2:
        return 0.0
    intervals = np.diff(recovery_points)
    return intervals.mean()


def mean_returns(returns):
    _check_ndim(returns, "mean_returns")
    r = _to_numpy(returns)
    return r.mean(axis=0)


def std_returns(returns):
    _check_ndim(returns, "std_returns")
    r = _to_numpy(returns)
    return r.std(axis=0, ddof=1)


def skewness(returns):
    _check_ndim(returns, "skewness")
    r = _to_numpy(returns)
    return pd.Series(r).skew(axis=0)


def kurtosis(returns):
    _check_ndim(returns, "kurtosis")
    r = _to_numpy(returns)
    return pd.Series(r).kurtosis(axis=0)


def tail_ratio(returns):
    _check_ndim(returns, "tail_ratio")
    r = _to_numpy(returns)
    p95 = np.percentile(r, 95)
    p05 = np.percentile(r, 5)
    if p05 == 0:
        return np.nan
    return p95 / p05


def value_at_risk(returns, confidence=0.95):
    _check_ndim(returns, "value_at_risk")
    r = _to_numpy(returns)
    var = -np.percentile(r, (1 - confidence) * 100)
    return var


def conditional_value_at_risk(returns, confidence=0.95):
    _check_ndim(returns, "conditional_value_at_risk")
    r = _to_numpy(returns)
    var = np.percentile(r, (1 - confidence) * 100)
    cvar = r[r <= var].mean()
    return -cvar if cvar is not None else np.nan
