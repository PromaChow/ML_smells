import os
import glob
import random
import datetime
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image
import matplotlib.pyplot as plt

import tensorflow as tf
from tensorflow.keras.applications.mobilenet import MobileNet, preprocess_input
from tensorflow.keras.layers import GlobalAveragePooling2D, Dense
from tensorflow.keras.models import Model
from tensorflow.keras.optimizers import SGD, Adam

# ------------------------------------------------------------------
# Paths
# ------------------------------------------------------------------
path_celeba_img = Path("/path/to/celeba/images")          # <-- update to actual path
path_celeba_att = Path("/path/to/celeba/attributes")     # <-- update to actual path
path_model_save = Path("./saved_models")

for p in (path_celeba_img, path_celeba_att, path_model_save):
    p.mkdir(parents=True, exist_ok=True)

# ------------------------------------------------------------------
# Load Attribute Data
# ------------------------------------------------------------------
attr_file = path_celeba_att / "list_attr_celeba.txt"
with open(attr_file, "r") as f:
    lines = f.readlines()

# First line is number of images (ignore)
# Second line contains attribute names
attr_names = lines[1].strip().split()
# Remaining lines: image filename + 40 attributes
data = []
for line in lines[2:]:
    parts = line.strip().split()
    data.append(parts)

attr_df = pd.DataFrame(data, columns=["image_name"] + attr_names)
attr_df.set_index("image_name", inplace=True)
attr_df = attr_df.astype(int)

# ------------------------------------------------------------------
# Image file list
# ------------------------------------------------------------------
image_files = sorted([f for f in os.listdir(path_celeba_img) if f.lower().endswith(".jpg")])
assert len(image_files) == len(attr_df), "Mismatch between image count and attribute rows"
assert set(image_files) == set(attr_df.index), "Image filenames and attribute keys do not match"

# ------------------------------------------------------------------
# Utilities
# ------------------------------------------------------------------
def get_timestamp() -> str:
    return datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

def list_models() -> list[str]:
    return sorted(glob.glob(str(path_model_save / "model_*.h5")))

# ------------------------------------------------------------------
# Model creation
# ------------------------------------------------------------------
def create_cnn_model(num_attrs: int) -> Model:
    base = MobileNet(weights="imagenet", include_top=False, input_shape=(128, 128, 3))
    base.trainable = False  # Freeze all layers
    x = GlobalAveragePooling2D()(base.output)
    x = Dense(256, activation="relu")(x)
    output = Dense(num_attrs)(x)
    model = Model(inputs=base.input, outputs=output)
    model.compile(optimizer=SGD(learning_rate=0.01, momentum=0.9),
                  loss="mse")
    return model

# ------------------------------------------------------------------
# Data loading
# ------------------------------------------------------------------
def load_image(path: Path) -> np.ndarray:
    img = Image.open(path).convert("RGB")
    img = img.resize((128, 128))
    arr = np.array(img, dtype=np.float32)
    return preprocess_input(arr)

def load_sample(index: int = None, filename: str = None, show: bool = False) -> tuple[np.ndarray, np.ndarray]:
    if filename is None:
        assert index is not None, "Provide either filename or index"
        filename = image_files[index]
    img_path = path_celeba_img / filename
    attrs = attr_df.loc[filename].values.astype(np.float32)
    img_arr = load_image(img_path)
    if show:
        plt.figure(figsize=(4, 4))
        plt.imshow((img_arr + 1) / 2)  # undo preprocess for display
        plt.axis("off")
        plt.title("Image")
        plt.show()
        print("Attributes:")
        for name, val in zip(attr_df.columns, attrs):
            print(f"  {name}: {val}")
    return img_arr, attrs

def load_batch(filenames: list[str]) -> tuple[np.ndarray, np.ndarray]:
    imgs = []
    attrs = []
    for fn in filenames:
        img_arr, attr_arr = load_sample(filename=fn)
        imgs.append(img_arr)
        attrs.append(attr_arr)
    return np.stack(imgs, axis=0), np.stack(attrs, axis=0)

# ------------------------------------------------------------------
# Training
# ------------------------------------------------------------------
def main():
    num_attrs = len(attr_df.columns)

    # Create and inspect model
    model = create_cnn_model(num_attrs)
    model.summary()

    # Recompile with Adam
    model.compile(optimizer=Adam(learning_rate=0.001), loss="mse")

    # Prepare training batch
    sample_size = 2 ** 16  # 65,536
    if sample_size > len(image_files):
        sample_size = len(image_files)
    selected_files = random.sample(image_files, sample_size)

    X, Y = load_batch(selected_files)

    # Train
    model.fit(X, Y,
              epochs=50,
              batch_size=128,
              validation_split=0.125,
              verbose=1)

    # Save model
    timestamp = get_timestamp()
    model_path = path_model_save / f"model_{timestamp}.h5"
    model.save(str(model_path))
    print(f"Model saved to {model_path}")

    # List available models
    print("Existing models:")
    for m in list_models():
        print(f"  {m}")

if __name__ == "__main__":
    main()