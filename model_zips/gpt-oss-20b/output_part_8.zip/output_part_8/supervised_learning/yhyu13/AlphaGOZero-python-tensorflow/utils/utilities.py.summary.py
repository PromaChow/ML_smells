import re
import time
import itertools
import random
import collections
import datetime
import multiprocessing
import functools
from typing import Iterable, List, Tuple, Any, Callable, Iterator

# Go color constants
BLACK = 1
WHITE = 2
EMPTY = 0

# --------------------------
# Coordinate Parsing & Conversion
# --------------------------
def _letter_to_index(letter: str) -> int:
    """Map letter to 0-based column index, skipping 'I'."""
    if not letter.isalpha():
        raise ValueError(f"Invalid letter: {letter}")
    letter = letter.upper()
    if letter == 'I':
        raise ValueError("Letter 'I' is not used in Go coordinates")
    idx = ord(letter) - ord('A')
    if idx > 8:  # after 'H', skip 'I'
        idx -= 1
    return idx

def _index_to_letter(idx: int) -> str:
    """Map 0-based column index to letter, skipping 'I'."""
    if idx < 0:
        raise ValueError(f"Index must be non-negative: {idx}")
    if idx >= 18:
        raise ValueError(f"Index too large for 19x19 board: {idx}")
    if idx >= 8:  # after 8, add 1 to skip 'I'
        idx += 1
    return chr(ord('A') + idx)

def kgs_to_index(coord: str) -> Tuple[int, int]:
    """Convert KGS coordinate (e.g., 'A1') to (col, row) 0-based."""
    if not coord:
        raise ValueError("Empty coordinate")
    col_letter = coord[0]
    row_str = coord[1:]
    col = _letter_to_index(col_letter)
    row = int(row_str) - 1
    return (col, row)

def index_to_kgs(index: Tuple[int, int]) -> str:
    """Convert (col, row) 0-based to KGS coordinate string."""
    col, row = index
    return f"{_index_to_letter(col)}{row + 1}"

def sgf_to_index(coord: str) -> Tuple[int, int]:
    """Convert SGF coordinate (e.g., 'aa') to (col, row) 0-based."""
    if len(coord) != 2:
        raise ValueError(f"SGF coordinate must be 2 letters: {coord}")
    col_letter, row_letter = coord
    col = ord(col_letter.lower()) - ord('a')
    row = ord(row_letter.lower()) - ord('a')
    return (col, row)

def index_to_sgf(index: Tuple[int, int]) -> str:
    """Convert (col, row) 0-based to SGF coordinate string."""
    col, row = index
    return f"{chr(col + ord('a'))}{chr(row + ord('a'))}"

def pygtp_to_index(coord: Tuple[int, int]) -> Tuple[int, int]:
    """Convert PyGTP (row, col) 1-based to (col, row) 0-based."""
    row, col = coord
    return (col - 1, row - 1)

def index_to_pygtp(index: Tuple[int, int]) -> Tuple[int, int]:
    """Convert (col, row) 0-based to PyGTP (row, col) 1-based."""
    col, row = index
    return (row + 1, col + 1)

# --------------------------
# Game Result Parsing
# --------------------------
RESULT_RE = re.compile(r"^(B|W)\+")
def parse_result(text: str) -> int:
    """Parse result string and return BLACK or WHITE."""
    m = RESULT_RE.match(text.strip())
    if not m:
        raise ValueError(f"Invalid result string: {text}")
    return BLACK if m.group(1) == 'B' else WHITE

# --------------------------
# Utility Functions
# --------------------------
def product(iterable: Iterable[int]) -> int:
    """Return product of elements in iterable."""
    result = 1
    for x in iterable:
        result *= x
    return result

def take_n(n: int, iterable: Iterable[Any]) -> List[Any]:
    """Return first n elements from iterable."""
    return list(itertools.islice(iterable, n))

def iter_chunks(chunk_size: int, iterator: Iterator[Any]) -> Iterator[List[Any]]:
    """Yield chunks of size chunk_size from iterator."""
    while True:
        chunk = list(itertools.islice(iterator, chunk_size))
        if not chunk:
            break
        yield chunk

def shuffler(iterator: Iterator[Any], pool_size: int, refill_threshold: int) -> Iterator[Any]:
    """Yield elements from a pool of pool_size, shuffling and refilling when below threshold."""
    pool: List[Any] = []
    it = iter(iterator)
    while True:
        while len(pool) < pool_size:
            try:
                pool.append(next(it))
            except StopIteration:
                break
        if not pool:
            break
        random.shuffle(pool)
        while pool and len(pool) > refill_threshold:
            yield pool.pop()
        if len(pool) <= refill_threshold:
            # refill in next loop
            continue

# --------------------------
# Timer Class
# --------------------------
class Timer:
    _accumulated: collections.defaultdict[float] = collections.defaultdict(float)

    def __init__(self, label: str):
        self.label = label
        self.start: float | None = None

    def __enter__(self):
        self.start = time.perf_counter()
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        if self.start is None:
            return
        elapsed = time.perf_counter() - self.start
        Timer._accumulated[self.label] += elapsed

    @classmethod
    def report(cls):
        for label, total in cls._accumulated.items():
            print(f"{label}: {total:.6f} s")

# --------------------------
# TensorFlow Decorators & Utilities
# --------------------------
try:
    import tensorflow as tf
except ImportError:
    tf = None  # TensorFlow is optional; decorators will raise if used

class lazy_property:
    def __init__(self, func: Callable):
        self.func = func
        self.attr_name = func.__name__

    def __get__(self, instance, owner):
        if instance is None:
            return self
        value = self.func(instance)
        setattr(instance, self.attr_name, value)
        return value

def timestamp() -> str:
    return datetime.datetime.now().strftime("%Y%m%d-%H%M%S")

def define_scope(scope_name: str):
    if tf is None:
        raise RuntimeError("TensorFlow is not installed")
    def decorator(func: Callable):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            with tf.variable_scope(scope_name, reuse=tf.AUTO_REUSE):
                return func(*args, **kwargs)
        return wrapper
    return decorator

def unzip(iterable: Iterable[Tuple[Any, ...]]) -> List[List[Any]]:
    """Convert list of tuples into separate lists."""
    return [list(t) for t in zip(*iterable)]

def single(lst: List[Any]) -> Any:
    """Assert list has exactly one element and return it."""
    if len(lst) != 1:
        raise ValueError(f"Expected single element, got {len(lst)}")
    return lst[0]

# --------------------------
# Parallel Execution
# --------------------------
def stupid_parallel(function: Callable, nprocesses: int = 4) -> Callable:
    """Return a parallelized version of function applied to each element of an iterable."""
    def wrapper(iterable: Iterable[Any], *args, **kwargs):
        with multiprocessing.Pool(nprocesses) as pool:
            results = pool.map(lambda x: function(x, *args, **kwargs), iterable)
        return results
    return wrapper
