import pandas as pd
from sklearn.model_selection import train_test_split, ShuffleSplit, GridSearchCV
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.svm import LinearSVC, SVC
from sklearn.metrics import accuracy_score
import warnings

warnings.filterwarnings('ignore')

# 1. Data Loading and Preparation
df = pd.read_csv('College.csv')
print(df.head())

le = LabelEncoder()
df['Private'] = le.fit_transform(df['Private'])

X = df.drop('Private', axis=1)
Y = df['Private']

# 2. Data Splitting
train_x, test_x, train_y, test_y = train_test_split(
    X, Y, test_size=0.3, random_state=10, stratify=Y
)

# 3. Linear SVM Model Training and Evaluation
svc_linear = LinearSVC(max_iter=2000)
svc_linear.fit(train_x, train_y)
pred_y = svc_linear.predict(test_x)
accuracy_unscaled = accuracy_score(test_y, pred_y)
print(f'LinearSVC Accuracy (unscaled): {accuracy_unscaled:.4f}')

# 4. Data Preprocessing with StandardScaler
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
X_scaled_df = pd.DataFrame(X_scaled, columns=X.columns)

train_x_scaled, test_x_scaled, train_y_scaled, test_y_scaled = train_test_split(
    X_scaled_df, Y, test_size=0.3, random_state=10, stratify=Y
)

svc_linear_scaled = LinearSVC(max_iter=2000)
svc_linear_scaled.fit(train_x_scaled, train_y_scaled)
pred_y_scaled = svc_linear_scaled.predict(test_x_scaled)
accuracy_scaled = accuracy_score(test_y_scaled, pred_y_scaled)
print(f'LinearSVC Accuracy (scaled): {accuracy_scaled:.4f}')

# 5. Hyperparameter Tuning with GridSearchCV
param_grid = [
    {'kernel': ['poly'], 'C': [1, 10, 100, 1000]},
    {'kernel': ['linear'], 'C': [1, 10, 100, 1000]},
    {'kernel': ['rbf'], 'C': [1, 10, 100, 1000], 'gamma': [0.001, 0.0001]}
]

cv = ShuffleSplit(n_splits=5, test_size=0.2, random_state=10)

grid = GridSearchCV(
    estimator=SVC(max_iter=1000),
    param_grid=param_grid,
    cv=cv,
    n_jobs=-1
)

grid.fit(train_x_scaled, train_y_scaled)

best_model = grid.best_estimator_
best_params = grid.best_params_
best_cv_score = grid.best_score_
test_pred = best_model.predict(test_x_scaled)
test_accuracy = accuracy_score(test_y_scaled, test_pred)

print(f'Best CV Accuracy: {best_cv_score:.4f}')
print(f'Best Parameters: {best_params}')
print(f'Test Accuracy of Best Model: {test_accuracy:.4f}')