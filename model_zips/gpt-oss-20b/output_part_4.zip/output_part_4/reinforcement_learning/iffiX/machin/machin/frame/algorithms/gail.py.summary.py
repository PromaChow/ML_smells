import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import random
from collections import deque
from dataclasses import dataclass
import pickle
import os

# Transition definitions
@dataclass
class Transition:
    state: torch.Tensor
    action: torch.Tensor
    reward: float
    next_state: torch.Tensor
    done: bool

@dataclass
class ExpertTransition:
    state: torch.Tensor
    action: torch.Tensor

# Replay buffer
class ReplayBuffer:
    def __init__(self, capacity: int, device: torch.device):
        self.capacity = capacity
        self.device = device
        self.buffer = deque(maxlen=capacity)

    def add(self, transition):
        self.buffer.append(transition)

    def sample(self, batch_size: int):
        batch = random.sample(self.buffer, min(batch_size, len(self.buffer)))
        states = torch.stack([t.state for t in batch]).to(self.device)
        actions = torch.stack([t.action for t in batch]).to(self.device)
        rewards = torch.tensor([t.reward for t in batch], dtype=torch.float32, device=self.device)
        next_states = torch.stack([t.next_state for t in batch]).to(self.device)
        dones = torch.tensor([t.done for t in batch], dtype=torch.float32, device=self.device)
        return states, actions, rewards, next_states, dones

    def __len__(self):
        return len(self.buffer)

# Simple MLP discriminator
class Discriminator(nn.Module):
    def __init__(self, state_dim, action_dim, hidden_dim=256):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim + action_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1)
        )

    def forward(self, state, action):
        x = torch.cat([state, action], dim=-1)
        return self.net(x)

# Placeholder policy optimization (PPO/TRPO)
class PolicyOptim:
    def __init__(self, state_dim, action_dim, config, device):
        self.device = device
        self.actor = nn.Sequential(
            nn.Linear(state_dim, config["policy"]["hidden_dim"]),
            nn.ReLU(),
            nn.Linear(config["policy"]["hidden_dim"], action_dim),
            nn.Tanh()
        ).to(device)
        self.critic = nn.Sequential(
            nn.Linear(state_dim, config["policy"]["hidden_dim"]),
            nn.ReLU(),
            nn.Linear(config["policy"]["hidden_dim"], 1)
        ).to(device)
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=config["policy"]["lr_actor"])
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=config["policy"]["lr_critic"])
        self.replay_buffer = ReplayBuffer(config["policy"]["buffer_capacity"], device)
        self.sampler = None  # placeholder

    def update(self, batch_size):
        if len(self.replay_buffer) < batch_size:
            return
        states, actions, rewards, next_states, dones = self.replay_buffer.sample(batch_size)
        with torch.no_grad():
            values_next = self.critic(next_states).squeeze()
            targets = rewards + (1.0 - dones) * 0.99 * values_next

        # Critic update
        values = self.critic(states).squeeze()
        critic_loss = F.mse_loss(values, targets)
        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        self.critic_optimizer.step()

        # Actor update (policy gradient)
        log_probs = torch.log(F.softmax(self.actor(states), dim=-1) + 1e-8)
        advantages = targets - values.detach()
        actor_loss = -(log_probs * advantages.unsqueeze(-1)).mean()
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        self.actor_optimizer.step()

    def eval_mode(self):
        self.actor.eval()
        self.critic.eval()

# GAIL implementation
class GAIL:
    def __init__(self, discriminator, policy, disc_optimizer, config, device):
        self.device = device
        self.discriminator = discriminator.to(device)
        self.policy = policy
        self.disc_optimizer = disc_optimizer
        self.config = config
        self.expert_buffer = ReplayBuffer(config["expert"]["buffer_capacity"], device)
        self.discriminator_update_times = config["discriminator"]["update_times"]
        self.disc_lr_scheduler = config["discriminator"].get("lr_scheduler")
        self.actor_lr_scheduler = config["policy"].get("lr_scheduler")
        self.critic_lr_scheduler = config["policy"].get("lr_scheduler")

    def store_episode(self, episode):
        for t in episode:
            with torch.no_grad():
                logits = self.discriminator(t.state, t.action)
                reward = -torch.log(torch.sigmoid(logits) + 1e-8).item()
            new_t = Transition(
                state=t.state,
                action=t.action,
                reward=reward,
                next_state=t.next_state,
                done=t.done
            )
            self.policy.replay_buffer.add(new_t)

    def store_expert_episode(self, expert_episode):
        for et in expert_episode:
            transition = Transition(
                state=et.state,
                action=et.action,
                reward=0.0,
                next_state=torch.zeros_like(et.state),
                done=False
            )
            self.expert_buffer.add(transition)

    def update(self):
        # Discriminator updates
        for _ in range(self.discriminator_update_times):
            if len(self.expert_buffer) == 0 or len(self.policy.replay_buffer) == 0:
                break
            exp_states, exp_actions, _, _, _ = self.expert_buffer.sample(self.config["discriminator"]["batch_size"])
            agent_states, agent_actions, _, _, _ = self.policy.replay_buffer.sample(self.config["discriminator"]["batch_size"])

            logits_exp = self.discriminator(exp_states, exp_actions).squeeze()
            logits_agent = self.discriminator(agent_states, agent_actions).squeeze()

            loss_exp = F.binary_cross_entropy_with_logits(logits_exp, torch.zeros_like(logits_exp))
            loss_agent = F.binary_cross_entropy_with_logits(logits_agent, torch.ones_like(logits_agent))
            loss = loss_exp + loss_agent

            self.disc_optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.discriminator.parameters(), self.config["discriminator"]["grad_clip"])
            self.disc_optimizer.step()

        # Policy update
        self.policy.update(self.config["policy"]["batch_size"])

        # Set eval mode
        self.policy.eval_mode()
        self.discriminator.eval()

    def update_lr_scheduler(self):
        if self.actor_lr_scheduler:
            self.actor_lr_scheduler.step()
        if self.critic_lr_scheduler:
            self.critic_lr_scheduler.step()
        if self.disc_lr_scheduler:
            self.disc_lr_scheduler.step()

    @staticmethod
    def generate_config():
        return {
            "policy": {
                "hidden_dim": 256,
                "lr_actor": 3e-4,
                "lr_critic": 1e-3,
                "batch_size": 64,
                "buffer_capacity": 5000
            },
            "discriminator": {
                "learning_rate": 1e-4,
                "update_times": 5,
                "batch_size": 64,
                "grad_clip": 10.0
            },
            "expert": {
                "buffer_capacity": 5000
            }
        }

    @classmethod
    def init_from_config(cls, config, state_dim, action_dim, device, expert_file=None):
        disc = Discriminator(state_dim, action_dim).to(device)
        disc_optimizer = optim.Adam(disc.parameters(), lr=config["discriminator"]["learning_rate"])
        policy = PolicyOptim(state_dim, action_dim, config, device)
        gail = cls(disc, policy, disc_optimizer, config, device)

        if expert_file and os.path.isfile(expert_file):
            with open(expert_file, "rb") as f:
                expert_trajs = pickle.load(f)
            for traj in expert_trajs:
                gail.store_expert_episode(traj)
        return gail

# Example usage (to be removed or adapted in real scenarios):
if __name__ == "__main__":
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    config = GAIL.generate_config()
    state_dim = 10
    action_dim = 3
    gail = GAIL.init_from_config(config, state_dim, action_dim, device)

    # Dummy episode
    episode = []
    for _ in range(5):
        state = torch.randn(state_dim)
        action = torch.randn(action_dim)
        next_state = torch.randn(state_dim)
        transition = Transition(state, action, 0.0, next_state, False)
        episode.append(transition)

    gail.store_episode(episode)
    gail.update()
    gail.update_lr_scheduler()
