import argparse
import importlib
import logging
import numpy as np
import spriteworld


def parse_args():
    parser = argparse.ArgumentParser(description="Run a random agent on a Spriteworld task.")
    parser.add_argument(
        "--num_episodes",
        type=int,
        default=10,
        help="Number of episodes to run.",
    )
    parser.add_argument(
        "--config",
        type=str,
        required=True,
        help="Python module path for the task configuration.",
    )
    parser.add_argument(
        "--mode",
        type=str,
        default="train",
        choices=["train", "test"],
        help="Task mode to load from the configuration.",
    )
    return parser.parse_args()


class RandomAgent:
    def __init__(self, env):
        self.action_space = env.action_space

    def act(self, observation):
        return self.action_space.sample()


def load_task_config(module_name, mode):
    config_module = importlib.import_module(module_name)
    if hasattr(config_module, "load_config"):
        config = config_module.load_config(mode)
    elif hasattr(config_module, "get_config"):
        config = config_module.get_config(mode)
    else:
        raise AttributeError(
            f"Config module '{module_name}' must provide load_config or get_config."
        )
    # Ensure the Success renderer is included
    config.setdefault("renderers", [])
    if "Success" not in config["renderers"]:
        config["renderers"].append("Success")
    return config


def main():
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    args = parse_args()

    config = load_task_config(args.config, args.mode)
    env = spriteworld.make("spriteworld", config)

    agent = RandomAgent(env)

    for episode in range(1, args.num_episodes + 1):
        observation = env.reset()
        rewards = []
        success = False
        done = False

        while not done:
            action = agent.act(observation)
            observation, reward, done, _ = env.step(action)
            rewards.append(reward)
            success = observation.get("success", False)

        mean_reward = np.mean(rewards) if rewards else 0.0
        logging.info(
            f"Episode {episode}: Success={success}, Mean Reward={mean_reward:.3f}"
        )


if __name__ == "__main__":
    main()
