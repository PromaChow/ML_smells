import numpy as np

# Generate a 4D array with 16 random floats and reshape to 2x2x2x2
array_4d = np.random.rand(16).reshape((2, 2, 2, 2))
print("4D array:")
print(array_4d)

# Create a 1D array and compute argsort indices
data = np.array([4, 2, 7, 1])
sorted_indices = data.argsort()
print("\nSorted indices:")
print(sorted_indices)

# Assign ranks based on sorted order
ranks = np.empty_like(sorted_indices)
ranks[sorted_indices] = np.arange(len(sorted_indices))
print("\nRanked array:")
print(ranks)