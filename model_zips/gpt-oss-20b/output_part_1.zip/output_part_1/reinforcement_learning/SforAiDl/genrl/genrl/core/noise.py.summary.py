import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from abc import ABC, abstractmethod
from typing import Union


class ActionNoise(ABC):
    def __init__(
        self,
        mean: Union[float, torch.Tensor],
        std: Union[float, torch.Tensor],
    ) -> None:
        self._mean = (
            torch.tensor(mean, dtype=torch.float32, device="cpu")
            if not isinstance(mean, torch.Tensor)
            else mean.clone()
        )
        self._std = (
            torch.tensor(std, dtype=torch.float32, device="cpu")
            if not isinstance(std, torch.Tensor)
            else std.clone()
        )

    @property
    def mean(self) -> torch.Tensor:
        return self._mean

    @property
    def std(self) -> torch.Tensor:
        return self._std

    @abstractmethod
    def __call__(self) -> torch.Tensor:
        pass


class NormalActionNoise(ActionNoise):
    def __call__(self) -> torch.Tensor:
        return torch.normal(self.mean, self.std)

    def reset(self) -> None:
        pass


class OrnsteinUhlenbeckActionNoise(ActionNoise):
    def __init__(
        self,
        mean: Union[float, torch.Tensor],
        std: Union[float, torch.Tensor],
        theta: float = 0.15,
        dt: float = 1e-2,
        initial_noise: torch.Tensor | None = None,
    ) -> None:
        super().__init__(mean, std)
        self.theta = theta
        self.dt = dt
        self.initial_noise = initial_noise.clone() if initial_noise is not None else None
        self.reset()

    def reset(self) -> None:
        if self.initial_noise is not None:
            self.noise_prev = self.initial_noise.clone()
        else:
            self.noise_prev = torch.zeros_like(self.mean)

    def __call__(self) -> torch.Tensor:
        normal_noise = torch.normal(
            torch.zeros_like(self.mean),
            torch.ones_like(self.mean),
        )
        noise = (
            self.noise_prev
            + self.theta * (self.mean - self.noise_prev) * self.dt
            + self.std
            * math.sqrt(self.dt)
            * normal_noise
        )
        self.noise_prev = noise
        return noise


class NoisyLinear(nn.Module):
    def __init__(
        self,
        in_features: int,
        out_features: int,
        bias: bool = True,
        std_init: float = 0.017,
    ) -> None:
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.bias_flag = bias
        self.std_init = std_init

        self.weight_mu = nn.Parameter(
            torch.empty(out_features, in_features, dtype=torch.float32)
        )
        self.weight_sigma = nn.Parameter(
            torch.empty(out_features, in_features, dtype=torch.float32)
        )

        if self.bias_flag:
            self.bias_mu = nn.Parameter(
                torch.empty(out_features, dtype=torch.float32)
            )
            self.bias_sigma = nn.Parameter(
                torch.empty(out_features, dtype=torch.float32)
            )
        else:
            self.register_parameter("bias_mu", None)
            self.register_parameter("bias_sigma", None)

        self.register_buffer("epsilon_weight", torch.empty(out_features, in_features))
        if self.bias_flag:
            self.register_buffer("epsilon_bias", torch.empty(out_features))
        else:
            self.register_buffer("epsilon_bias", torch.empty(0))

        self.reset_parameters()
        self.reset_noise()

    def reset_parameters(self) -> None:
        limit = 1 / math.sqrt(self.in_features)
        nn.init.uniform_(self.weight_mu, -limit, limit)
        nn.init.uniform_(self.weight_sigma, -limit, limit)
        if self.bias_flag:
            nn.init.uniform_(self.bias_mu, -limit, limit)
            nn.init.uniform_(self.bias_sigma, -limit, limit)
        else:
            self.bias_mu = None
            self.bias_sigma = None

        self.weight_sigma.data.fill_(self.std_init / math.sqrt(self.in_features))
        if self.bias_flag:
            self.bias_sigma.data.fill_(self.std_init / math.sqrt(self.in_features))

    def _scale_noise(self, size: int) -> torch.Tensor:
        x = torch.randn(size)
        return x.sign() * torch.sqrt(x.abs())

    def reset_noise(self) -> None:
        eps_in = self._scale_noise(self.in_features)
        eps_out = self._scale_noise(self.out_features)
        self.epsilon_weight.copy_(torch.ger(eps_in, eps_out))
        if self.bias_flag:
            self.epsilon_bias.copy_(eps_out)

    def forward(self, input: torch.Tensor) -> torch.Tensor:
        if self.training:
            self.reset_noise()
            weight = self.weight_mu + self.weight_sigma * self.epsilon_weight
            bias = (
                self.bias_mu + self.bias_sigma * self.epsilon_bias
                if self.bias_flag
                else None
            )
        else:
            weight = self.weight_mu
            bias = self.bias_mu if self.bias_flag else None
        return F.linear(input, weight, bias)