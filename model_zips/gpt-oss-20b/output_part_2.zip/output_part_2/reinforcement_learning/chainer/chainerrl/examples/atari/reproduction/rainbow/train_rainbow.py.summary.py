import argparse
import json
import logging
import os
import random
import shutil
import sys
import time
from pathlib import Path

import gymnasium as gym
import numpy as np
import torch
import torch.nn.functional as F
from torch import nn, optim

from rlkit.envs.atari_wrappers import wrap_deepmind
from rlkit.torch.algos.categorical_double_dqn import CategoricalDoubleDQN
from rlkit.torch.modules.distributional import DistributionalDuelingDQN
from rlkit.torch.modules.noisy import FactorizedNoisyNet
from rlkit.torch.replay_buffer.prioritized_replay_buffer import PrioritizedReplayBuffer
from rlkit.torch.utils import evaluation
from rlkit.torch.utils import misc
from rlkit.torch.utils.misc import download_model
from rlkit.torch.utils.misc import set_random_seed
from rlkit.torch.utils.render import Render
from rlkit.torch.utils.monitor import Monitor
from rlkit.torch.utils.randomize_action import RandomizeAction


def parse_args():
    parser = argparse.ArgumentParser(description="Rainbow Categorical Double DQN for Breakout")
    parser.add_argument("--env", default="BreakoutNoFrameskip-v4", help="Gym environment")
    parser.add_argument("--outdir", default="results", help="Output directory")
    parser.add_argument("--seed", type=int, default=0, help="Random seed")
    parser.add_argument("--gpu", action="store_true", help="Use GPU")
    parser.add_argument("--demo", action="store_true", help="Run demo mode")
    parser.add_argument("--load-pretrained", action="store_true", help="Load pretrained weights")
    parser.add_argument("--noisy-net-sigma", type=float, default=0.5, help="Sigma for NoisyNet")
    parser.add_argument("--steps", type=int, default=50_000_000, help="Training steps")
    parser.add_argument("--eval-epsilon", type=float, default=0.02, help="Epsilon for eval randomization")
    parser.add_argument("--eval-interval", type=int, default=250_000, help="Evaluation interval")
    parser.add_argument("--eval-n-steps", type=int, default=1000, help="Steps per eval episode")
    parser.add_argument("--n-best-episodes", type=int, default=200, help="Number of episodes for final eval")
    parser.add_argument("--logging-level", default="INFO", help="Logging level")
    parser.add_argument("--monitor", action="store_true", help="Enable monitoring")
    parser.add_argument("--render", action="store_true", help="Render during evaluation")
    parser.add_argument("--load", help="Path to load a specific model")
    return parser.parse_args()


def setup_logging(level_str):
    level = getattr(logging, level_str.upper(), logging.INFO)
    logging.basicConfig(level=level, format="%(asctime)s [%(levelname)s] %(message)s")
    return logging.getLogger(__name__)


def make_env(test, env_name, seed):
    env = gym.make(env_name)
    env = wrap_deepmind(env)
    env.seed(seed)
    env.action_space.seed(seed)
    if test:
        env = RandomizeAction(env, args.eval_epsilon)
        if args.monitor:
            env = Monitor(env, os.path.join(args.outdir, f"monitor_test_{seed}"))
        if args.render:
            env = Render(env)
    return env


def build_q_func(noisy_sigma):
    net = DistributionalDuelingDQN(
        input_shape=(4, 84, 84),
        num_actions=4,
        num_atoms=51,
        v_min=-10,
        v_max=10,
    )
    net = FactorizedNoisyNet(net, sigma_scale=noisy_sigma)
    return net


def main():
    global args
    args = parse_args()
    logger = setup_logging(args.logging_level)
    os.makedirs(args.outdir, exist_ok=True)

    # Seeds
    set_random_seed(args.seed)
    torch.manual_seed(args.seed)
    if args.gpu:
        torch.cuda.manual_seed_all(args.seed)
    np.random.seed(args.seed)
    random.seed(args.seed)

    # Environments
    train_env = make_env(False, args.env, args.seed)
    eval_env = make_env(True, args.env, args.seed + 1)

    # Agent components
    q_func = build_q_func(args.noisy_net_sigma)
    optimizer = optim.Adam(
        q_func.parameters(), lr=6.25e-5, eps=1.5e-4
    )
    betasteps = int(args.steps / 4)
    replay_buffer = PrioritizedReplayBuffer(
        size=int(1e6), alpha=0.5, beta0=0.4, betasteps=betasteps
    )
    phi = lambda x: x.astype(np.float32) / 255.0

    agent = CategoricalDoubleDQN(
        q_func=q_func,
        optimizer=optimizer,
        replay_buffer=replay_buffer,
        phi=phi,
        gamma=0.99,
        minibatch_size=32,
        replay_start_size=int(2e4),
        target_update_interval=32000,
        update_interval=4,
        batch_accumulator="mean",
    )

    # Load pretrained if requested
    if args.load_pretrained:
        download_model("breakout_categorical_double_dqn.pt", args.outdir)
        pretrained_path = Path(args.outdir) / "breakout_categorical_double_dqn.pt"
        agent.load_state_dict(torch.load(pretrained_path, map_location="cpu"))
    elif args.load:
        agent.load_state_dict(torch.load(args.load, map_location="cpu"))

    # Demo mode
    if args.demo:
        eval_stats = evaluation.eval_performance(
            agent, eval_env, n_steps=args.eval_n_steps, max_episodes=1
        )
        print(f"Demo evaluation: {eval_stats}")
        sys.exit(0)

    # Training loop
    best_score = -float("inf")
    best_model_path = Path(args.outdir) / "best_model.pt"
    steps = 0
    start_time = time.time()

    while steps < args.steps:
        agent.train_one_step(train_env, phi)
        steps += 1

        if steps % args.eval_interval == 0:
            eval_stats = evaluation.eval_performance(
                agent, eval_env, n_steps=args.eval_n_steps, max_episodes=1
            )
            avg_reward = eval_stats["average_return"]
            logger.info(f"Step {steps}: Avg Eval Reward = {avg_reward:.2f}")
            if avg_reward > best_score:
                best_score = avg_reward
                torch.save(agent.state_dict(), best_model_path)
                logger.info(f"New best model saved at step {steps} with reward {best_reward:.2f}")

    # Final evaluation
    agent.load_state_dict(torch.load(best_model_path, map_location="cpu"))
    final_stats = evaluation.eval_performance(
        agent, eval_env, n_steps=args.eval_n_steps, max_episodes=args.n_best_episodes
    )
    scores = final_stats["episode_returns"]
    best_scores_path = Path(args.outdir) / "bestscores.json"
    with open(best_scores_path, "w") as f:
        json.dump(scores, f, indent=2)
    logger.info(f"Final evaluation completed. Scores saved to {best_scores_path}")


if __name__ == "__main__":
    main()
