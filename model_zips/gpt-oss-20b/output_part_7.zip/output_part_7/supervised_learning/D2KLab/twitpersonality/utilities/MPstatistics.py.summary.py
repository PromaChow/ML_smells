import csv
import os
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer

# Paths
input_file = 'data.csv'
output_file = 'statistics.txt'

# Data containers
data_perUser = {}          # user_id -> list of posts
data_all = []              # list of all posts
y_openness = []
y_conscientiousness = []
y_extraversion = []
y_agreeableness = []
y_neuroticism = []

# ---------- Data Parsing ----------
with open(input_file, newline='', encoding='utf-8') as csvfile:
    reader = csv.reader(csvfile, quotechar='"', skipinitialspace=True)
    for row in reader:
        if not row:
            continue
        # Extract fields
        user_id = row[0].strip().strip('"')
        status = row[1].strip().strip('"')
        # Big Five scores may be a single string or separate columns
        if len(row) >= 3 and ',' in row[2]:
            scores_str = row[2]
        else:
            # Assume next five columns are individual scores
            scores_str = ','.join(row[2:7])
        scores = [float(s) for s in scores_str.split(',')]
        if len(scores) != 5:
            continue  # skip malformed lines
        # Group by user
        if user_id not in data_perUser:
            data_perUser[user_id] = []
        data_perUser[user_id].append(status)
        # Store post
        data_all.append(status)
        # Store Big Five scores
        y_openness.append(scores[0])
        y_conscientiousness.append(scores[1])
        y_extraversion.append(scores[2])
        y_agreeableness.append(scores[3])
        y_neuroticism.append(scores[4])

# ---------- Statistical Calculations ----------
num_users = len(data_perUser)
num_posts = len(data_all)

# Total words and characters
total_words = sum(len(post.split()) for post in data_all)
total_chars = sum(len(post) for post in data_all)

# Posts per user stats
posts_per_user = [len(posts) for posts in data_perUser.values()]
avg_posts_per_user = np.mean(posts_per_user)
max_posts_per_user = np.max(posts_per_user)
min_posts_per_user = np.min(posts_per_user)

# Text length stats (pre-tokenization)
words_per_post = [len(post.split()) for post in data_all]
chars_per_post = [len(post) for post in data_all]
avg_words_pre = np.mean(words_per_post)
max_words_pre = np.max(words_per_post)
min_words_pre = np.min(words_per_post)
avg_chars_pre = np.mean(chars_per_post)
max_chars_pre = np.max(chars_per_post)
min_chars_pre = np.min(chars_per_post)

# Text length stats (post-tokenization)
vectorizer = CountVectorizer(stop_words='english')
doc_term_matrix = vectorizer.fit_transform(data_all)
token_counts = np.array(doc_term_matrix.sum(axis=1)).flatten()
avg_tokens_post = np.mean(token_counts)
max_tokens_post = np.max(token_counts)
min_tokens_post = np.min(token_counts)

# Token lengths (sum of token lengths per document)
tokenized_docs = vectorizer.transform(data_all)
token_lengths = []
for idx in range(doc_term_matrix.shape[0]):
    tokens = vectorizer.get_feature_names_out()
    counts = doc_term_matrix.getrow(idx).toarray().flatten()
    total_len = sum(len(tok) * cnt for tok, cnt in zip(tokens, counts))
    token_lengths.append(total_len)
avg_token_len_post = np.mean(token_lengths)
max_token_len_post = np.max(token_lengths)
min_token_len_post = np.min(token_lengths)

# Big Five statistics
def stats(arr):
    return {
        'mean': np.mean(arr),
        'max': np.max(arr),
        'min': np.min(arr),
        'std': np.std(arr, ddof=1)
    }

big5_stats = {
    'Openness': stats(y_openness),
    'Conscientiousness': stats(y_conscientiousness),
    'Extraversion': stats(y_extraversion),
    'Agreeableness': stats(y_agreeableness),
    'Neuroticism': stats(y_neuroticism)
}

# ---------- Output ----------
with open(output_file, 'w', encoding='utf-8') as f:
    f.write('General Dataset Statistics\n')
    f.write(f'Number of users: {num_users}\n')
    f.write(f'Number of posts: {num_posts}\n')
    f.write(f'Total words: {total_words}\n')
    f.write(f'Total characters: {total_chars}\n\n')

    f.write('Posts per User Distribution\n')
    f.write(f'Average posts per user: {avg_posts_per_user:.2f}\n')
    f.write(f'Max posts per user: {max_posts_per_user}\n')
    f.write(f'Min posts per user: {min_posts_per_user}\n\n')

    f.write('Text Length Statistics (Pre-Tokenization)\n')
    f.write(f'Average words per post: {avg_words_pre:.2f}\n')
    f.write(f'Max words per post: {max_words_pre}\n')
    f.write(f'Min words per post: {min_words_pre}\n')
    f.write(f'Average characters per post: {avg_chars_pre:.2f}\n')
    f.write(f'Max characters per post: {max_chars_pre}\n')
    f.write(f'Min characters per post: {min_chars_pre}\n\n')

    f.write('Text Length Statistics (Post-Tokenization)\n')
    f.write(f'Average token count per post: {avg_tokens_post:.2f}\n')
    f.write(f'Max token count per post: {max_tokens_post}\n')
    f.write(f'Min token count per post: {min_tokens_post}\n')
    f.write(f'Average token length per post: {avg_token_len_post:.2f}\n')
    f.write(f'Max token length per post: {max_token_len_post}\n')
    f.write(f'Min token length per post: {min_token_len_post}\n\n')

    f.write('Big Five Trait Distributions\n')
    for trait, s in big5_stats.items():
        f.write(f'{trait}:\n')
        f.write(f'  Mean: {s["mean"]:.3f}\n')
        f.write(f'  Max: {s["max"]:.3f}\n')
        f.write(f'  Min: {s["min"]:.3f}\n')
        f.write(f'  Std Dev: {s["std"]:.3f}\n\n')
