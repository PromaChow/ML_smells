import torch
import torch.nn as nn
import torch.nn.functional as F


class TDNN(nn.Module):
    def __init__(
        self,
        input_dim: int,
        output_dim: int,
        context_size: int,
        stride: int = 1,
        dilation: int = 1,
        use_batchnorm: bool = False,
        dropout_p: float = 0.0,
    ):
        super().__init__()
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.context_size = context_size
        self.stride = stride
        self.dilation = dilation
        self.use_batchnorm = use_batchnorm
        self.dropout_p = dropout_p

        self.linear = nn.Linear(input_dim * context_size, output_dim)
        self.relu = nn.ReLU()
        self.dropout = nn.Dropout(dropout_p) if dropout_p > 0 else nn.Identity()
        self.batchnorm = nn.BatchNorm1d(output_dim) if use_batchnorm else nn.Identity()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Parameters
        ----------
        x : torch.Tensor
            Input tensor of shape (batch, seq_len, input_dim)

        Returns
        -------
        torch.Tensor
            Output tensor of shape (batch, new_seq_len, output_dim)
        """
        # Validate input shape
        if x.dim() != 3 or x.size(2) != self.input_dim:
            raise ValueError(
                f"Expected input of shape (batch, seq_len, {self.input_dim}), "
                f"but got {x.shape}"
            )

        # Unsqueeze to add channel dimension
        x = x.unsqueeze(1)  # shape: (batch, 1, seq_len, input_dim)

        # Apply unfold to extract sliding windows
        kernel_size = (self.context_size, self.input_dim)
        stride = (1, self.input_dim)
        dilation = (self.dilation, 1)
        unfolded = F.unfold(
            x,
            kernel_size=kernel_size,
            dilation=dilation,
            stride=stride,
        )  # shape: (batch, context_size*input_dim, new_seq_len)

        # Transpose to (batch, new_seq_len, context_size*input_dim)
        unfolded = unfolded.transpose(1, 2)

        # Linear transformation
        out = self.linear(unfolded)  # shape: (batch, new_seq_len, output_dim)

        # Non-linearity
        out = self.relu(out)

        # Optional dropout
        out = self.dropout(out)

        # Optional batch normalization
        if self.use_batchnorm:
            # BatchNorm1d expects (batch, num_features, seq_len)
            out = out.transpose(1, 2)  # (batch, output_dim, new_seq_len)
            out = self.batchnorm(out)
            out = out.transpose(1, 2)  # (batch, new_seq_len, output_dim)

        return out


if __name__ == "__main__":
    batch = 16
    seq_len = 52
    input_dim = 128
    output_dim = 256
    context_size = 5
    stride = 1
    dilation = 1

    model = TDNN(
        input_dim=input_dim,
        output_dim=output_dim,
        context_size=context_size,
        stride=stride,
        dilation=dilation,
        use_batchnorm=True,
        dropout_p=0.1,
    )

    x = torch.randn(batch, seq_len, input_dim)
    y = model(x)
    print("Input shape :", x.shape)
    print("Output shape:", y.shape)
    # Expected output shape: (batch, new_seq_len, output_dim)
    # where new_seq_len = floor((seq_len - dilation*(context_size-1) - 1)/stride + 1)
    expected_seq_len = (seq_len - dilation * (context_size - 1) - 1) // stride + 1
    print("Expected seq len:", expected_seq_len)