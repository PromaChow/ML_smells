import math
import torch
from torch.optim import Adam

class SharedAdam(Adam):
    def __init__(self, params, lr=1e-3, betas=(0.9, 0.999), eps=1e-8, weight_decay=0):
        super().__init__(params, lr=lr, betas=betas, eps=eps, weight_decay=weight_decay)
        for group in self.param_groups:
            for p in group['params']:
                state = self.state[p]
                state['step'] = torch.tensor(0, dtype=torch.long)
                state['exp_avg'] = torch.zeros_like(p.data)
                state['exp_avg_sq'] = torch.zeros_like(p.data)

    def share_memory(self):
        for state in self.state.values():
            state['step'].share_memory_()
            state['exp_avg'].share_memory_()
            state['exp_avg_sq'].share_memory_()

    def step(self, closure=None):
        loss = None
        if closure is not None:
            loss = closure()

        for group in self.param_groups:
            beta1, beta2 = group['betas']
            lr = group['lr']
            eps = group['eps']
            weight_decay = group['weight_decay']

            for p in group['params']:
                if p.grad is None:
                    continue

                grad = p.grad.data
                if weight_decay != 0:
                    grad = grad + weight_decay * p.data

                state = self.state[p]
                exp_avg = state['exp_avg']
                exp_avg_sq = state['exp_avg_sq']
                step = state['step']

                exp_avg.mul_(beta1).add_(grad, alpha=1 - beta1)
                exp_avg_sq.mul_(beta2).addcmul_(grad, grad, value=1 - beta2)

                step.add_(1)
                step_float = step.item()
                bias_correction1 = 1 - beta1 ** step_float
                bias_correction2 = 1 - beta2 ** step_float

                denom = exp_avg_sq.sqrt().add_(eps)
                step_size = lr * math.sqrt(bias_correction2) / bias_correction1

                p.data.addcdiv_(-step_size, exp_avg, denom)

        return loss

if __name__ == "__main__":
    model = torch.nn.Linear(10, 5)
    optimizer = SharedAdam(model.parameters(), lr=1e-3)
    optimizer.share_memory()
    loss_fn = torch.nn.MSELoss()

    for _ in range(5):
        inputs = torch.randn(3, 10)
        targets = torch.randn(3, 5)
        def closure():
            optimizer.zero_grad()
            outputs = model(inputs)
            loss = loss_fn(outputs, targets)
            loss.backward()
            return loss
        loss = optimizer.step(closure)
        print(loss.item())