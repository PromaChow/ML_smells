import gym
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from collections import deque

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class ReplayBuffer:
    def __init__(self, max_size=1000000):
        self.max_size = max_size
        self.ptr = 0
        self.size = 0
        self.state = []
        self.action = []
        self.next_state = []
        self.reward = []
        self.done = []

    def add(self, s, a, s2, r, d):
        if self.size < self.max_size:
            self.state.append(s)
            self.action.append(a)
            self.next_state.append(s2)
            self.reward.append(r)
            self.done.append(d)
            self.size += 1
        else:
            self.state[self.ptr] = s
            self.action[self.ptr] = a
            self.next_state[self.ptr] = s2
            self.reward[self.ptr] = r
            self.done[self.ptr] = d
            self.ptr = (self.ptr + 1) % self.max_size

    def sample(self, batch_size):
        idx = np.random.choice(self.size, batch_size, replace=False)
        batch = dict(
            state=torch.FloatTensor(np.array([self.state[i] for i in idx])).to(device),
            action=torch.FloatTensor(np.array([self.action[i] for i in idx])).to(device),
            next_state=torch.FloatTensor(np.array([self.next_state[i] for i in idx])).to(device),
            reward=torch.FloatTensor(np.array([self.reward[i] for i in idx])).unsqueeze(1).to(device),
            done=torch.FloatTensor(np.array([self.done[i] for i in idx])).unsqueeze(1).to(device),
        )
        return batch

class ActorNet(nn.Module):
    def __init__(self, state_dim, action_dim, action_limit):
        super().__init__()
        self.action_limit = action_limit
        self.net = nn.Sequential(
            nn.Linear(state_dim, 400),
            nn.ReLU(),
            nn.Linear(400, 300),
            nn.ReLU(),
            nn.Linear(300, action_dim),
            nn.Tanh(),
        )

    def forward(self, state):
        return self.net(state) * self.action_limit

class CriticNet(nn.Module):
    def __init__(self, state_dim, action_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim + action_dim, 400),
            nn.ReLU(),
            nn.Linear(400, 300),
            nn.ReLU(),
            nn.Linear(300, 1),
        )

    def forward(self, state, action):
        x = torch.cat([state, action], dim=1)
        return self.net(x)

class TD3Agent:
    def __init__(self, state_dim, action_dim, action_limit):
        self.actor = ActorNet(state_dim, action_dim, action_limit).to(device)
        self.actor_target = ActorNet(state_dim, action_dim, action_limit).to(device)
        self.actor_target.load_state_dict(self.actor.state_dict())

        self.critic1 = CriticNet(state_dim, action_dim).to(device)
        self.critic2 = CriticNet(state_dim, action_dim).to(device)
        self.critic1_target = CriticNet(state_dim, action_dim).to(device)
        self.critic2_target = CriticNet(state_dim, action_dim).to(device)
        self.critic1_target.load_state_dict(self.critic1.state_dict())
        self.critic2_target.load_state_dict(self.critic2.state_dict())

        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=1e-3)
        self.critic1_optimizer = optim.Adam(self.critic1.parameters(), lr=1e-3)
        self.critic2_optimizer = optim.Adam(self.critic2.parameters(), lr=1e-3)

        self.replay_buffer = ReplayBuffer()
        self.gamma = 0.99
        self.tau = 0.005
        self.policy_noise = 0.2
        self.noise_clip = 0.5
        self.policy_delay = 2
        self.batch_size = 256
        self.total_it = 0

    def act_with_noise(self, state, noise_std=0.2):
        state = torch.FloatTensor(state).unsqueeze(0).to(device)
        action = self.actor(state).detach().cpu().numpy()[0]
        noise = np.random.normal(0, noise_std, size=action.shape)
        action = action + noise
        action = np.clip(action, -self.actor.action_limit, self.actor.action_limit)
        return action

    def store_experiences(self, experiences):
        for s, a, s2, r, d in experiences:
            self.replay_buffer.add(s, a, s2, r, d)

    def update(self):
        if self.replay_buffer.size < self.batch_size:
            return
        batch = self.replay_buffer.sample(self.batch_size)
        state = batch['state']
        action = batch['action']
        next_state = batch['next_state']
        reward = batch['reward']
        done = batch['done']

        with torch.no_grad():
            noise = (
                torch.randn_like(action) * self.policy_noise
            ).clamp(-self.noise_clip, self.noise_clip)
            next_action = (
                self.actor_target(next_state) + noise
            ).clamp(-self.actor.action_limit, self.actor.action_limit)
            target_q1 = self.critic1_target(next_state, next_action)
            target_q2 = self.critic2_target(next_state, next_action)
            target_q = torch.min(target_q1, target_q2)
            target_q = reward + (1 - done) * self.gamma * target_q

        current_q1 = self.critic1(state, action)
        current_q2 = self.critic2(state, action)
        critic1_loss = nn.functional.mse_loss(current_q1, target_q)
        critic2_loss = nn.functional.mse_loss(current_q2, target_q)

        self.critic1_optimizer.zero_grad()
        critic1_loss.backward()
        self.critic1_optimizer.step()

        self.critic2_optimizer.zero_grad()
        critic2_loss.backward()
        self.critic2_optimizer.step()

        if self.total_it % self.policy_delay == 0:
            actor_loss = -self.critic1(state, self.actor(state)).mean()
            self.actor_optimizer.zero_grad()
            actor_loss.backward()
            self.actor_optimizer.step()

            for param, target_param in zip(self.actor.parameters(), self.actor_target.parameters()):
                target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)
            for param, target_param in zip(self.critic1.parameters(), self.critic1_target.parameters()):
                target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)
            for param, target_param in zip(self.critic2.parameters(), self.critic2_target.parameters()):
                target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)

        self.total_it += 1

def main():
    env = gym.make("Pendulum-v0")
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.shape[0]
    action_limit = env.action_space.high[0]
    agent = TD3Agent(state_dim, action_dim, action_limit)

    max_episodes = 1000
    max_steps = 200
    solved_reward = -150
    solved_repeat = 5
    reward_window = deque(maxlen=solved_repeat)
    smoothed_reward = 0.0

    for episode in range(1, max_episodes + 1):
        state = env.reset()
        episode_reward = 0.0
        experiences = []

        for step in range(max_steps):
            action = agent.act_with_noise(state)
            next_state, reward, done, _ = env.step(action)
            experiences.append((state, action, next_state, reward, float(done)))
            state = next_state
            episode_reward += reward
            if done:
                break

        agent.store_experiences(experiences)

        if episode > 100:
            for _ in range(len(experiences)):
                agent.update()

        smoothed_reward = 0.9 * smoothed_reward + 0.1 * episode_reward
        reward_window.append(smoothed_reward)
        print(f"Episode {episode}\tSmoothed Reward: {smoothed_reward:.2f}")

        if len(reward_window) == solved_repeat and all(r > solved_reward for r in reward_window):
            print(f"Solved in {episode} episodes!")
            break

if __name__ == "__main__":
    main()
