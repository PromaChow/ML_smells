import torch
from .utils import make_pseudo_label
from .consistency_regularization import ConsistencyRegularization


class PseudoLabel(ConsistencyRegularization):
    def __init__(self, consistency: float, threshold: float, sharpen: float, temp_softmax: float):
        super().__init__(consistency, threshold, sharpen, temp_softmax)

    def __call__(self, stu_preds: torch.Tensor, tea_logits: torch.Tensor, *args, **kwargs):
        hard_label, mask = make_pseudo_label(tea_logits, self.threshold)
        return stu_preds, hard_label, mask

    def __repr__(self):
        return f'PseudoLabel(threshold={self.threshold}, sharpen={self.sharpen}, tau={self.temp_softmax})'