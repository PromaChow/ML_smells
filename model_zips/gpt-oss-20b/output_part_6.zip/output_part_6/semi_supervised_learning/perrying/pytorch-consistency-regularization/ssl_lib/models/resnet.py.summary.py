import torch
import torch.nn as nn
import torch.nn.functional as F
from utils import leaky_relu, conv3x3, BatchNorm2d, param_init, BaseModel


class _Residual(nn.Module):
    def __init__(self, input_channels, output_channels, stride=1, activate_before_residual=False):
        super().__init__()
        self.activate_before_residual = activate_before_residual

        if self.activate_before_residual:
            self.pre_activation = nn.Sequential(
                BatchNorm2d(input_channels),
                leaky_relu
            )
        else:
            self.pre_activation = None

        self.conv1 = conv3x3(input_channels, output_channels, stride=stride)
        self.bn1 = BatchNorm2d(output_channels)
        self.conv2 = conv3x3(output_channels, output_channels, stride=1)

        if stride != 1 or input_channels != output_channels:
            self.shortcut = nn.Conv2d(input_channels, output_channels, kernel_size=1, stride=stride, bias=False)
        else:
            self.shortcut = nn.Identity()

    def forward(self, x):
        identity = x
        if self.activate_before_residual:
            x = self.pre_activation(x)

        out = self.conv1(x)
        out = self.bn1(out)
        out = leaky_relu(out)
        out = self.conv2(out)

        identity = self.shortcut(identity)
        out += identity
        return out


class ResNet(BaseModel):
    def __init__(self, num_classes, filters=16, scales=4, repeat=2, dropout=None):
        super().__init__()
        self.num_classes = num_classes
        self.filters = filters
        self.scales = scales
        self.repeat = repeat
        self.dropout = dropout

        layers = []

        # Initial convolution
        layers.append(conv3x3(3, 16, stride=1))
        current_channels = 16

        for scale in range(scales):
            out_channels = self.filters << scale
            if scale == 0:
                layers.append(_Residual(current_channels, out_channels, stride=2))
            else:
                layers.append(_Residual(current_channels, out_channels, stride=1))
                for _ in range(repeat - 1):
                    layers.append(_Residual(out_channels, out_channels, stride=1))
            current_channels = out_channels

        layers.append(BatchNorm2d(current_channels))
        layers.append(leaky_relu)

        self.feature_extractor = nn.Sequential(*layers)

        classifier_layers = []
        if self.dropout is not None:
            classifier_layers.append(nn.Dropout(p=self.dropout))
        classifier_layers.append(nn.Linear(current_channels, self.num_classes))
        self.classifier = nn.Sequential(*classifier_layers)

        self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            param_init(m)

    def forward(self, x):
        x = self.feature_extractor(x)
        x = F.adaptive_avg_pool2d(x, (1, 1))
        x = torch.flatten(x, 1)
        x = self.classifier(x)
        return x

if __name__ == "__main__":
    model = ResNet(num_classes=10, filters=16, scales=4, repeat=2, dropout=0.5)
    dummy = torch.randn(8, 3, 32, 32)
    print(model(dummy).shape)