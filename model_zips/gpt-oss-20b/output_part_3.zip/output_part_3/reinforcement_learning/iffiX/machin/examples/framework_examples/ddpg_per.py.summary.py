import gym
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import logging
import sys

from machin.algorithms.ddpg import DDPGPer

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


class Actor(nn.Module):
    def __init__(self, obs_dim, action_dim, action_range):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim, 400),
            nn.ReLU(),
            nn.Linear(400, 300),
            nn.ReLU(),
            nn.Linear(300, action_dim),
            nn.Tanh(),
        )
        self.action_range = action_range

    def forward(self, state):
        return self.net(state) * self.action_range


class Critic(nn.Module):
    def __init__(self, obs_dim, action_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim + action_dim, 400),
            nn.ReLU(),
            nn.Linear(400, 300),
            nn.ReLU(),
            nn.Linear(300, 1),
        )

    def forward(self, state, action):
        x = torch.cat([state, action], dim=-1)
        return self.net(x)


def main():
    env = gym.make("Pendulum-v0")
    env.seed(0)
    np.random.seed(0)
    torch.manual_seed(0)

    observe_dim = 3
    action_dim = 1
    action_range = 2.0
    max_episodes = 1000
    max_steps = 200
    noise_param = (0.0, 0.2)
    noise_mode = "normal"
    solved_reward = -150.0
    solved_repeat = 5

    actor = Actor(observe_dim, action_dim, action_range).to(device)
    critic = Critic(observe_dim, action_dim).to(device)

    actor_target = Actor(observe_dim, action_dim, action_range).to(device)
    critic_target = Critic(observe_dim, action_dim).to(device)
    actor_target.load_state_dict(actor.state_dict())
    critic_target.load_state_dict(critic.state_dict())

    actor_optimizer = optim.Adam(actor.parameters(), lr=1e-3)
    critic_optimizer = optim.Adam(critic.parameters(), lr=1e-3)

    mse_loss = nn.MSELoss(reduction="sum")

    ddpg_per = DDPGPer(
        actor=actor,
        critic=critic,
        actor_target=actor_target,
        critic_target=critic_target,
        actor_opt=actor_optimizer,
        critic_opt=critic_optimizer,
        loss_fn=mse_loss,
        gamma=0.99,
        tau=0.005,
        buffer_size=1000000,
        batch_size=64,
        device=device,
    )

    smoothed_total_reward = 0.0
    solved_count = 0

    for episode in range(1, max_episodes + 1):
        obs = env.reset()
        state = torch.tensor(obs, dtype=torch.float32, device=device).unsqueeze(0)
        tmp_observations = []
        total_reward = 0.0

        for step in range(max_steps):
            action = ddpg_per.act_with_noise(
                state, noise_param=noise_param, noise_mode=noise_mode
            )
            action_np = action.detach().cpu().numpy().flatten()
            next_obs, reward, done, _ = env.step(action_np)
            next_state = torch.tensor(next_obs, dtype=torch.float32, device=device).unsqueeze(0)

            tmp_observations.append((state, action, next_state, reward, done))
            total_reward += reward
            state = next_state

            if done:
                break

        ddpg_per.store_episode(tmp_observations)

        if episode > 100:
            for _ in range(len(tmp_observations)):
                ddpg_per.update()

        smoothed_total_reward = smoothed_total_reward * 0.9 + total_reward * 0.1
        logger.info(
            f"Episode {episode} | Total Reward: {total_reward:.2f} | Smoothed: {smoothed_total_reward:.2f}"
        )

        if smoothed_total_reward > solved_reward:
            solved_count += 1
        else:
            solved_count = 0

        if solved_count >= solved_repeat:
            logger.info(
                f"Environment solved after {episode} episodes with smoothed reward {smoothed_total_reward:.2f}"
            )
            env.close()
            sys.exit(0)

    env.close()
    logger.info("Training completed without solving the environment.")


if __name__ == "__main__":
    main()
