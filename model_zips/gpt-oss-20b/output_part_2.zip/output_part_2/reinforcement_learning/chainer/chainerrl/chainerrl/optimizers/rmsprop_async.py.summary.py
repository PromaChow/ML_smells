import numpy as np
try:
    import cupy as cp
except ImportError:
    cp = None


class HyperparameterProxy:
    def __init__(self, attr_name):
        self.attr_name = attr_name

    def __get__(self, instance, owner):
        return getattr(instance, self.attr_name)

    def __set__(self, instance, value):
        setattr(instance, self.attr_name, value)


class RMSpropAsyncRule:
    def __init__(self, lr=None, alpha=None, eps=None):
        self.lr = lr if lr is not None else 0.01
        self.alpha = alpha if alpha is not None else 0.99
        self.eps = eps if eps is not None else 1e-8
        self.ms_state = {}

    def init_state(self, params):
        for p in params:
            self.ms_state[id(p)] = np.zeros_like(p)

    def update_core_cpu(self, params, grads):
        for p, g in zip(params, grads):
            if g is None:
                continue
            ms = self.ms_state[id(p)]
            ms *= self.alpha
            ms += (1 - self.alpha) * g**2
            denom = np.sqrt(ms + self.eps)
            p -= self.lr * g / denom
            self.ms_state[id(p)] = ms

    def update_core_gpu(self, params, grads):
        if cp is None:
            raise RuntimeError("cupy is required for GPU updates")
        kernel = cp.ElementwiseKernel(
            "T ms, T g, T p, T a, T b, T eps",
            "T ms_out, T p_out",
            """
            ms_out = a * ms + (1 - a) * g * g;
            p_out = p - b * g / sqrt(ms_out + eps);
            """,
            "rmsprop_gpu_update"
        )
        for p, g in zip(params, grads):
            if g is None:
                continue
            module = cp.get_array_module(p)
            ms = self.ms_state[id(p)]
            ms_gpu = module.asarray(ms)
            g_gpu = module.asarray(g)
            p_gpu = module.asarray(p)
            ms_out, p_out = kernel(ms_gpu, g_gpu, p_gpu, self.alpha, self.lr, self.eps)
            self.ms_state[id(p)] = ms_out.get() if isinstance(ms_out, cp.ndarray) else ms_out
            p[:] = p_out


class RMSpropAsync:
    def __init__(self):
        self._lr = 0.01
        self._alpha = 0.99
        self._eps = 1e-8

    lr = HyperparameterProxy('_lr')
    alpha = HyperparameterProxy('_alpha')
    eps = HyperparameterProxy('_eps')

    def rule(self):
        return RMSpropAsyncRule(lr=self._lr, alpha=self._alpha, eps=self._eps)