import numpy as np
import gymnasium


class RunningMeanVar:
    """Online calculation of mean and variance."""

    def __init__(self):
        self.n = 0
        self.mean = np.zeros(0, dtype=np.float64)
        self.M2 = np.zeros(0, dtype=np.float64)

    def update(self, x: np.ndarray):
        """Update running statistics with a new observation."""
        x = np.asarray(x, dtype=np.float64)
        if self.n == 0:
            self.mean = np.zeros_like(x, dtype=np.float64)
            self.M2 = np.zeros_like(x, dtype=np.float64)
        self.n += 1
        delta = x - self.mean
        self.mean += delta / self.n
        delta2 = x - self.mean
        self.M2 += delta * delta2

    @property
    def variance(self) -> np.ndarray:
        """Return unbiased sample variance."""
        if self.n < 2:
            return np.zeros_like(self.mean, dtype=np.float64)
        return self.M2 / (self.n - 1)


class ObservationNormalizer(gymnasium.Wrapper):
    """Wraps an environment to normalize its observations."""

    def __init__(self, env: gymnasium.Env, clip: float = 5.0,
                 constant_moments: tuple[float, float] | None = None):
        super().__init__(env)
        self.clip = float(clip)
        if constant_moments is None:
            self._running = RunningMeanVar()
            self._use_running = True
        else:
            mean, var = constant_moments
            self._mean = np.asarray(mean, dtype=np.float64)
            self._var = np.asarray(var, dtype=np.float64)
            self._use_running = False
        self._eps = 1e-8

    def observation(self, observation: np.ndarray) -> np.ndarray:
        observation = np.asarray(observation, dtype=np.float64)
        if self._use_running:
            self._running.update(observation)
            mean = self._running.mean
            var = self._running.variance
        else:
            mean = self._mean
            var = self._var

        std = np.sqrt(var + self._eps)
        normed = (observation - mean) / std
        clipped = np.clip(normed, -self.clip, self.clip)
        return clipped

    def reset(self, **kwargs):
        obs, info = super().reset(**kwargs)
        return self.observation(obs), info

    def step(self, action):
        obs, reward, terminated, truncated, info = super().step(action)
        return self.observation(obs), reward, terminated, truncated, info
