import collections
import numpy as np
import gym
import lz4.frame


class LazyFrames:
    """Store frames lazily, optionally compressed."""

    def __init__(self, frames, compress=False):
        """
        Parameters
        ----------
        frames : list of np.ndarray
            Frames to store.
        compress : bool, optional
            Whether to compress frames using LZ4.
        """
        self._compress = compress
        if compress:
            # Store compressed bytes
            self._frames = [lz4.frame.compress(frame.tobytes(), store_size=True)
                            for frame in frames]
        else:
            self._frames = [frame for frame in frames]
        self._decompressed = None  # cache for decompressed frames

    def _decompress_frames(self):
        if self._decompressed is None:
            if self._compress:
                self._decompressed = [np.frombuffer(lz4.frame.decompress(f, store_size=True),
                                                    dtype=np.uint8).reshape(
                    np.frombuffer(lz4.frame.decompress(f, store_size=True),
                                  dtype=np.uint8).shape)
                                      for f in self._frames]
            else:
                self._decompressed = self._frames
        return self._decompressed

    def __array__(self, dtype=None):
        frames = self._decompress_frames()
        arr = np.stack(frames, axis=0)
        if dtype is not None:
            arr = arr.astype(dtype)
        return arr

    def __len__(self):
        return len(self._frames)

    def __getitem__(self, i):
        return self._decompress_frames()[i]

    def __eq__(self, other):
        if not isinstance(other, LazyFrames):
            return False
        return all(np.array_equal(a, b) for a, b in zip(self._decompress_frames(),
                                                       other._decompress_frames()))

    @property
    def shape(self):
        return np.array(self).shape


class FrameStack(gym.Wrapper):
    """Stack the last framestack observations."""

    def __init__(self, env, framestack=4):
        super().__init__(env)
        self.framestack = framestack
        self.frames = collections.deque(maxlen=framestack)

        # Adjust observation space
        low = np.repeat(self.observation_space.low, framestack, axis=-1)
        high = np.repeat(self.observation_space.high, framestack, axis=-1)
        shape = low.shape
        self.observation_space = gym.spaces.Box(low=low, high=high, dtype=self.observation_space.dtype)

    def reset(self, **kwargs):
        obs = self.env.reset(**kwargs)
        for _ in range(self.framestack):
            self.frames.append(obs)
        return self._get_obs()

    def step(self, action):
        obs, reward, done, info = self.env.step(action)
        self.frames.append(obs)
        return self._get_obs(), reward, done, info

    def _get_obs(self):
        lazy = LazyFrames(list(self.frames), compress=False)
        arr = np.array(lazy)  # shape: (framestack, H, W, C)
        # Move stack dimension to last axis
        arr = np.moveaxis(arr, 0, -1)  # shape: (H, W, C * framestack)
        return np.expand_dims(arr, axis=0)  # add batch dimension

```