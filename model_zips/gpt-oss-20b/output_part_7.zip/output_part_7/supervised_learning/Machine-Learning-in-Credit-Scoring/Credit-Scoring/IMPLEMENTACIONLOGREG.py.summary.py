import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import scale
import statsmodels.api as sm
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report, roc_curve, auc
import matplotlib.pyplot as plt

def main():
    # 1. Data Loading
    df = pd.read_excel("outputAN.xlsx", sheet_name="Sheet1")

    # 2. Feature Selection
    h11 = [
        "Status of existing checking account",
        "Duration in month",
        "Credit history",
        "Savings account/bonds",
        "Installment rate in percentage of disposable income"
    ]

    # 3. Data Preprocessing
    df["Receive_NotReceiveCredit"] = df["Receive_NotReceiveCredit"].replace(2, 0)
    X_train, X_test, y_train, y_test = train_test_split(
        df[h11], df["Receive_NotReceiveCredit"], test_size=0.20, random_state=42, stratify=df["Receive_NotReceiveCredit"]
    )

    # 4. Feature and Target Separation
    X_train_scaled = scale(X_train)
    X_test_scaled = scale(X_test)

    # 5. Model Fitting with Statsmodels
    sm_X_train = sm.add_constant(X_train)  # unscaled features with constant
    sm_model = sm.Logit(y_train, sm_X_train).fit(disp=False)
    print(sm_model.summary())

    # 6. Model Fitting with Scikit-learn
    clf = LogisticRegression(penalty="l2", C=0.1, class_weight="balanced", solver="liblinear", random_state=42)
    clf.fit(X_train_scaled, y_train)

    # 7. Model Evaluation
    print("Coefficients:", clf.coef_)
    print("Intercept:", clf.intercept_)

    y_train_pred = clf.predict(X_train_scaled)
    y_test_pred = clf.predict(X_test_scaled)

    print("Training Accuracy:", accuracy_score(y_train, y_train_pred))
    print("Test Accuracy:", accuracy_score(y_test, y_test_pred))

    print("\nConfusion Matrix (Test):")
    print(confusion_matrix(y_test, y_test_pred))
    print("\nClassification Report (Test):")
    print(classification_report(y_test, y_test_pred))

    # 8. ROC Curve Analysis
    y_test_proba = clf.predict_proba(X_test_scaled)[:, 1]
    fpr, tpr, _ = roc_curve(y_test, y_test_proba)
    roc_auc = auc(fpr, tpr)
    print(f"Test AUC: {roc_auc:.4f}")

    plt.figure()
    plt.plot(fpr, tpr, color="darkorange", lw=2, label=f"ROC curve (AUC = {roc_auc:.2f})")
    plt.plot([0, 1], [0, 1], color="navy", lw=2, linestyle="--")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("Receiver Operating Characteristic")
    plt.legend(loc="lower right")
    plt.savefig("Log_ROC.png")
    plt.close()

if __name__ == "__main__":
    main()
