import math
import random
from typing import Dict, Tuple

import numpy as np
import torch
from torch.utils.data import Sampler
from torchvision import datasets, transforms


class CustomInfiniteSampler(Sampler[int]):
    """
    Sampler that generates a fixed number of indices by concatenating random permutations
    of the dataset indices, ensuring no replacement within each epoch.
    """

    def __init__(self, dataset_size: int, total_samples: int, seed: int | None = None) -> None:
        super().__init__(torch.utils.data.dataset.Subset)
        self.dataset_size = dataset_size
        self.total_samples = total_samples
        self.seed = seed
        self.indices = self._generate_indices()

    def _generate_indices(self) -> np.ndarray:
        rng = random.Random(self.seed)
        epochs = math.ceil(self.total_samples / self.dataset_size)
        indices = []
        for _ in range(epochs):
            perm = list(range(self.dataset_size))
            rng.shuffle(perm)
            indices.extend(perm)
        return np.array(indices[: self.total_samples], dtype=int)

    def __iter__(self):
        return iter(self.indices)

    def __len__(self) -> int:
        return len(self.indices)


def _convert_dataset(
    dataset,
    transpose_channels: bool = False,
    unlabeled: bool = False,
) -> Tuple[np.ndarray, np.ndarray]:
    """Helper to convert a torchvision dataset to numpy arrays."""
    images = []
    labels = []
    for img, label in dataset:
        # img can be PIL or torch.Tensor
        if isinstance(img, torch.Tensor):
            img_np = img.numpy()
        else:
            img_np = np.array(img)
        if img_np.ndim == 3 and img_np.shape[0] in (1, 3):
            # Already channel-first
            img_np = np.moveaxis(img_np, 0, -1)
        if transpose_channels:
            img_np = np.moveaxis(img_np, 0, -1)
        img_np = img_np.astype(np.float32)
        images.append(img_np)
        if unlabeled:
            labels.append(-1)
        else:
            labels.append(label)
    return np.stack(images, axis=0), np.array(labels, dtype=np.int32)


def load_svhn() -> Dict[str, Dict[str, np.ndarray]]:
    """Load SVHN dataset and return train/test splits."""
    transform = transforms.ToTensor()
    train_ds = datasets.SVHN(root=".", split="train", download=True, transform=transform)
    test_ds = datasets.SVHN(root=".", split="test", download=True, transform=transform)
    train_images, train_labels = _convert_dataset(train_ds, transpose_channels=True)
    test_images, test_labels = _convert_dataset(test_ds, transpose_channels=True)
    return {"train": {"images": train_images, "labels": train_labels},
            "test": {"images": test_images, "labels": test_labels}}


def load_cifar10() -> Dict[str, Dict[str, np.ndarray]]:
    """Load CIFAR-10 dataset and return train/test splits."""
    transform = transforms.ToTensor()
    train_ds = datasets.CIFAR10(root=".", train=True, download=True, transform=transform)
    test_ds = datasets.CIFAR10(root=".", train=False, download=True, transform=transform)
    train_images, train_labels = _convert_dataset(train_ds)
    test_images, test_labels = _convert_dataset(test_ds)
    return {"train": {"images": train_images, "labels": train_labels},
            "test": {"images": test_images, "labels": test_labels}}


def load_cifar100() -> Dict[str, Dict[str, np.ndarray]]:
    """Load CIFAR-100 dataset and return train/test splits."""
    transform = transforms.ToTensor()
    train_ds = datasets.CIFAR100(root=".", train=True, download=True, transform=transform)
    test_ds = datasets.CIFAR100(root=".", train=False, download=True, transform=transform)
    train_images, train_labels = _convert_dataset(train_ds)
    test_images, test_labels = _convert_dataset(test_ds)
    return {"train": {"images": train_images, "labels": train_labels},
            "test": {"images": test_images, "labels": test_labels}}


def load_stl10() -> Dict[str, Dict[str, np.ndarray]]:
    """Load STL10 dataset and return train/test/unlabeled splits."""
    transform = transforms.ToTensor()
    train_ds = datasets.STL10(root=".", split="train", download=True, transform=transform)
    test_ds = datasets.STL10(root=".", split="test", download=True, transform=transform)
    unlabeled_ds = datasets.STL10(root=".", split="unlabeled", download=True, transform=transform)

    train_images, train_labels = _convert_dataset(train_ds, transpose_channels=True)
    test_images, test_labels = _convert_dataset(test_ds, transpose_channels=True)
    unlabeled_images, unlabeled_labels = _convert_dataset(unlabeled_ds, transpose_channels=True, unlabeled=True)

    return {"train": {"images": train_images, "labels": train_labels},
            "test": {"images": test_images, "labels": test_labels},
            "unlabeled": {"images": unlabeled_images, "labels": unlabeled_labels}}


def dataset_split(
    images: np.ndarray,
    labels: np.ndarray,
    num_data: int,
    random: bool = False,
) -> Tuple[Dict[str, np.ndarray], Dict[str, np.ndarray]]:
    """
    Split dataset into two subsets.
    If random=False, split uniformly across classes.
    If random=True, take first num_data samples.
    """
    if random:
        idx1 = slice(0, num_data)
        idx2 = slice(num_data, None)
        dataset1 = {"images": images[idx1], "labels": labels[idx1]}
        dataset2 = {"images": images[idx2], "labels": labels[idx2]}
        return dataset1, dataset2

    classes = np.unique(labels)
    samples_per_class = num_data // len(classes)
    remainder = num_data % len(classes)

    indices1 = []
    for cls in classes:
        cls_indices = np.where(labels == cls)[0]
        selected = np.random.choice(cls_indices, size=samples_per_class, replace=False)
        indices1.extend(selected)
    if remainder > 0:
        extra_indices = np.random.choice(np.arange(len(labels)), size=remainder, replace=False)
        indices1.extend(extra_indices)

    indices1 = np.array(indices1)
    mask = np.ones(len(labels), dtype=bool)
    mask[indices1] = False
    indices2 = np.where(mask)[0]

    dataset1 = {"images": images[indices1], "labels": labels[indices1]}
    dataset2 = {"images": images[indices2], "labels": labels[indices2]}
    return dataset1, dataset2


def get_zca_normalization_param(images: np.ndarray, eps: float = 1e-5) -> Tuple[np.ndarray, np.ndarray]:
    """
    Compute ZCA whitening parameters.
    images: shape (N, H, W, C)
    Returns mean vector and whitening matrix.
    """
    N, H, W, C = images.shape
    X = images.reshape(N, -1).astype(np.float64)
    mean = X.mean(axis=0)
    X_centered = X - mean
    sigma = np.dot(X_centered.T, X_centered) / N
    sigma += eps * np.eye(sigma.shape[0])
    U, S, _ = np.linalg.svd(sigma, full_matrices=False)
    Z = np.dot(U, np.diag(1.0 / np.sqrt(S + eps))) @ U.T
    return mean, Z
