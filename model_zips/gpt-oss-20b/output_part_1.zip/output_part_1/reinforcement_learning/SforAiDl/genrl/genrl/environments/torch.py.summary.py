import gym
import torch
import numpy as np


class GymWrapper(gym.Wrapper):
    def __init__(self, env, *args, **kwargs):
        super().__init__(env)


class TorchWrapper(GymWrapper):
    def __init__(self, env, *args, **kwargs):
        super().__init__(env, *args, **kwargs)

    def step(self, action: torch.Tensor):
        if action.shape == (1,) and isinstance(self.env.action_space, gym.spaces.Discrete):
            action_val = action.item()
        else:
            # use the underlying data of the tensor as the action
            action_val = action.detach().cpu().numpy()
        obs, reward, done, info = self.env.step(action_val)
        obs_tensor = torch.from_numpy(obs)
        return obs_tensor, reward, done, info

    def reset(self, *args, **kwargs):
        obs = self.env.reset(*args, **kwargs)
        return torch.from_numpy(obs)

    def sample(self):
        sample = self.env.action_space.sample()
        if isinstance(sample, np.ndarray):
            return torch.from_numpy(sample)
        else:
            return torch.tensor(sample)

    def __getattr__(self, name):
        return getattr(self.env, name)