import unittest
import numpy as np
from pywsl.pul.chainer.functions.nnpu_risk import PU_Risk

class TestPU_Risk(unittest.TestCase):
    def setUp(self):
        n_p = 20
        n_u = 80
        prior = 0.5
        self.y = np.concatenate([np.ones(n_p), np.zeros(n_u)]).astype(np.int32)
        self.yh = np.concatenate([np.full(n_p, 2.0), np.full(n_u, -1.0)]).astype(np.float32).reshape(-1, 1)
        self.prior = prior

    def test_non_nnpu_risk(self):
        risk_func = PU_Risk(nnPU=False, prior=self.prior)
        risk = risk_func(self.yh, self.y)
        self.assertLess(risk, 0, "Non-NNPU risk should be negative")

    def test_nnpu_risk(self):
        risk_func = PU_Risk(nnPU=True, prior=self.prior)
        risk = risk_func(self.yh, self.y)
        self.assertGreater(risk, 0, "NNPU risk should be positive")

if __name__ == "__main__":
    unittest.main()