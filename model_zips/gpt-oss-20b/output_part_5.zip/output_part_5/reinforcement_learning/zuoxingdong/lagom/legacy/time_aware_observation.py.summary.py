import numpy as np
import gymnasium as gym
from gymnasium import Wrapper, spaces

def get_all_wrappers(env):
    """Collect the names of all wrappers in the environment chain."""
    wrappers = []
    current = env
    while hasattr(current, "env"):
        wrappers.append(current.__class__.__name__)
        current = current.env
    return wrappers

class TimeStepWrapper(Wrapper):
    """Observational wrapper that appends the current time step to the observation."""

    def __init__(self, env):
        super().__init__(env)

        # Ensure the wrapper is not already applied
        assert (
            self.__class__.__name__ not in get_all_wrappers(self.env)
        ), f"{self.__class__.__name__} is already wrapped."

        # Check for one-dimensional observation space
        if not isinstance(self.observation_space, spaces.Box):
            raise TypeError("TimeStepWrapper only supports Box observation spaces.")
        if self.observation_space.shape[0] == 0:
            raise ValueError("TimeStepWrapper requires non-empty observation space.")

        low = np.concatenate(
            [self.observation_space.low, np.array([0.0], dtype=self.observation_space.low.dtype)]
        )
        high = np.concatenate(
            [self.observation_space.high, np.array([np.inf], dtype=self.observation_space.high.dtype)]
        )
        self.observation_space = spaces.Box(
            low=low, high=high, dtype=self.observation_space.dtype
        )

        self.t = 0

    def observation(self, observation):
        """Append the time step to the observation."""
        return np.concatenate([observation, np.array([self.t], dtype=observation.dtype)])

    def step(self, action):
        """Increment time step and perform environment step."""
        self.t += 1
        observation, reward, terminated, truncated, info = self.env.step(action)
        return self.observation(observation), reward, terminated, truncated, info

    def reset(self, **kwargs):
        """Reset environment and time step counter."""
        self.t = 0
        observation, info = self.env.reset(**kwargs)
        return self.observation(observation), info
