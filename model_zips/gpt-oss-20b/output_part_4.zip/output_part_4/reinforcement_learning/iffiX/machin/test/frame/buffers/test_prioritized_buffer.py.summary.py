import numpy as np
import pytest
from contextlib import redirect_stdout
import io

# Assume WeightTree and PrioritizedBuffer are available in the current namespace
# They should provide the methods used below.

# ---------- WeightTree test constants ----------
WEIGHT_TREE_SIZE = 5
WEIGHT_TREE_BASE = [1, 1, 1, 0, 3]
WEIGHT_TREE_WEIGHTS = [1, 1, 1, 0, 3, 0, 0, 0, 2, 1, 3, 0, 3, 3, 6]


@pytest.fixture(scope="class")
def const_tree():
    tree = WeightTree(WEIGHT_TREE_SIZE)
    tree.update_all_leaves(WEIGHT_TREE_BASE)
    return tree


@pytest.fixture
def buffer_params():
    return {
        "buffer_size": 5,
        "epsilon": 1e-2,
        "alpha": 0.6,
        "beta": 0.4,
        "beta_increment_per_sampling": 1e-3,
    }


@pytest.fixture
def prioritized_buffer(buffer_params):
    return PrioritizedBuffer(**buffer_params)


# ---------- WeightTree Tests ----------

def test_get_weight_sum(const_tree):
    assert const_tree.get_weight_sum() == WEIGHT_TREE_WEIGHTS[-1]


def test_get_leaf_max(const_tree):
    assert const_tree.get_leaf_max() == max(WEIGHT_TREE_BASE)


def test_get_leaf_all_weights(const_tree):
    assert const_tree.get_leaf_all_weights() == WEIGHT_TREE_BASE


@pytest.mark.parametrize(
    "index,expected",
    [
        (1, 1),
        ([1, 2], [1, 1]),
        (np.array([0, 1, 2, 3, 4]), [1, 1, 1, 0, 3]),
    ],
)
def test_get_leaf_weight_valid(const_tree, index, expected):
    assert const_tree.get_leaf_weight(index) == expected


@pytest.mark.parametrize(
    "index,message",
    [
        (7, "Index 7 is out of bounds for leaf weights"),
        (-1, "Index -1 is out of bounds for leaf weights"),
    ],
)
def test_get_leaf_weight_invalid(const_tree, index, message):
    with pytest.raises(ValueError, match=message):
        const_tree.get_leaf_weight(index)


@pytest.mark.parametrize(
    "weight,expected_index",
    [
        (0.9, 0),
        (1.1, 1),
        ([0.5, 2.5], [0, 4]),
        (np.array([0.5, 2.5]), [0, 4]),
    ],
)
def test_find_leaf_index(const_tree, weight, expected_index):
    assert const_tree.find_leaf_index(weight) == expected_index


@pytest.mark.parametrize(
    "index,weight,expected_weights",
    [
        (1, 2.0, [1, 2.0, 1, 0, 3]),
        (3, 5.0, [1, 1, 1, 5.0, 3]),
    ],
)
def test_update_leaf_valid(const_tree, index, weight, expected_weights):
    const_tree.update_leaf(index, weight)
    assert const_tree.get_leaf_all_weights() == expected_weights
    # Restore original weights for subsequent tests
    const_tree.update_leaf(index, WEIGHT_TREE_BASE[index])


@pytest.mark.parametrize(
    "index,weight,message",
    [
        (7, 2.0, "Index 7 is out of bounds for leaf update"),
        (-1, 1.0, "Index -1 is out of bounds for leaf update"),
    ],
)
def test_update_leaf_invalid(const_tree, index, weight, message):
    with pytest.raises(ValueError, match=message):
        const_tree.update_leaf(index, weight)


@pytest.mark.parametrize(
    "indexes,weights,expected_weights",
    [
        ([1, 3], [2.0, 5.0], [1, 2.0, 1, 5.0, 3]),
    ],
)
def test_update_leaf_batch_valid(const_tree, indexes, weights, expected_weights):
    const_tree.update_leaf_batch(indexes, weights)
    assert const_tree.get_leaf_all_weights() == expected_weights
    # Restore original weights
    const_tree.update_leaf_batch(indexes, WEIGHT_TREE_BASE[0:2])


@pytest.mark.parametrize(
    "indexes,weights,message",
    [
        ([1, 3], [2.0], "Indexes and weights must have the same length"),
        ([10], [1.0], "Index 10 is out of bounds for leaf update"),
    ],
)
def test_update_leaf_batch_invalid(const_tree, indexes, weights, message):
    with pytest.raises(ValueError, match=message):
        const_tree.update_leaf_batch(indexes, weights)


@pytest.mark.parametrize(
    "new_base,message",
    [
        ([1, 2, 3], "New base weights must match tree size"),
    ],
)
def test_update_all_leaves_invalid(const_tree, new_base, message):
    with pytest.raises(ValueError, match=message):
        const_tree.update_all_leaves(new_base)


def test_print_weights(const_tree):
    f = io.StringIO()
    with redirect_stdout(f):
        const_tree.print_weights()
    assert f.getvalue() == ""


# ---------- PrioritizedBuffer Tests ----------

def test_store_episode_empty(prioritized_buffer):
    with pytest.raises(ValueError, match="Episode must be non-empty"):
        prioritized_buffer.store_episode([])


def test_store_episode_with_priorities(prioritized_buffer):
    episode = [1, 2, 3]
    priorities = [0.1, 0.2, 0.3]
    prioritized_buffer.store_episode(episode, priorities=priorities)
    # Check that the buffer has stored the episode
    assert len(prioritized_buffer.buffer) == len(episode)
    # Verify that the weight tree has updated priorities
    weights = prioritized_buffer.weight_tree.get_leaf_all_weights()
    assert all(w > 0 for w in weights)


def test_clear(prioritized_buffer):
    episode = [1, 2, 3]
    prioritized_buffer.store_episode(episode)
    prioritized_buffer.clear()
    assert len(prioritized_buffer.buffer) == 0
    assert prioritized_buffer.weight_tree.get_leaf_all_weights() == [0] * prioritized_buffer.buffer_size


def test_update_priority(prioritized_buffer):
    episode = [1, 2, 3]
    priorities = [0.1, 0.2, 0.3]
    prioritized_buffer.store_episode(episode, priorities=priorities)
    new_priorities = [0.5, 0.5, 0.5]
    prioritized_buffer.update_priority([0, 1, 2], new_priorities)
    weights = prioritized_buffer.weight_tree.get_leaf_all_weights()
    assert all(w > 0 for w in weights)


def test_sample_batch(prioritized_buffer, buffer_params):
    np.random.seed(0)
    episode = [0, 1, 2, 3, 4]
    priorities = [0.1, 0.2, 0.3, 0.4, 0.5]
    prioritized_buffer.store_episode(episode, priorities=priorities)
    batch_size = 5
    result = prioritized_buffer.sample_batch(batch_size=batch_size, device="cpu")
    indices = result["sampled_index"]
    is_weights = result["sampled_is_weight"]
    assert len(indices) == batch_size
    assert len(is_weights) == batch_size

    # Compute expected probabilities
    eps = buffer_params["epsilon"]
    alpha = buffer_params["alpha"]
    beta = buffer_params["beta"]
    weights = np.array([(p + eps) ** alpha for p in priorities])
    probs = weights / weights.sum()
    expected_indices = np.random.choice(
        np.arange(len(priorities)), size=batch_size, replace=True, p=probs
    )
    expected_is_weights = (1 / (len(priorities) * probs[expected_indices])) ** beta
    max_weight = expected_is_weights.max()
    expected_is_weights = expected_is_weights / max_weight

    np.testing.assert_array_equal(indices, expected_indices)
    np.testing.assert_allclose(is_weights, expected_is_weights, rtol=1e-5, atol=1e-8)