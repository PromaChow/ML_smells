import gym
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import pickle
import datetime
import os


class PPO:
    def __init__(self, actor, critic, lr=3e-4, gamma=0.99, eps_clip=0.2):
        self.actor = actor
        self.critic = critic
        self.optimizer = optim.Adam(list(actor.parameters()) + list(critic.parameters()), lr=lr)
        self.gamma = gamma
        self.eps_clip = eps_clip
        self.buffer = {"states": [], "actions": [], "rewards": [], "dones": [], "log_probs": []}

    def act(self, state):
        state_tensor = torch.tensor(state, dtype=torch.float32)
        logits = self.actor(state_tensor)
        dist = torch.distributions.Categorical(logits=logits)
        action = dist.sample()
        log_prob = dist.log_prob(action)
        entropy = dist.entropy()
        return action.item(), log_prob.item(), entropy.item()

    def store(self, state, action, reward, next_state, done, log_prob):
        self.buffer["states"].append(state)
        self.buffer["actions"].append(action)
        self.buffer["rewards"].append(reward)
        self.buffer["dones"].append(done)
        self.buffer["log_probs"].append(log_prob)

    def update(self):
        states = torch.tensor(np.array(self.buffer["states"]), dtype=torch.float32)
        actions = torch.tensor(self.buffer["actions"], dtype=torch.long)
        rewards = self.buffer["rewards"]
        dones = self.buffer["dones"]
        old_log_probs = torch.tensor(self.buffer["log_probs"], dtype=torch.float32)

        returns = []
        G = 0
        for reward, done in zip(reversed(rewards), reversed(dones)):
            if done:
                G = 0
            G = reward + self.gamma * G
            returns.insert(0, G)
        returns = torch.tensor(returns, dtype=torch.float32)

        values = self.critic(states).squeeze()
        advantages = returns - values.detach()

        logits = self.actor(states)
        dist = torch.distributions.Categorical(logits=logits)
        log_probs = dist.log_prob(actions)
        ratio = torch.exp(log_probs - old_log_probs)

        surr1 = ratio * advantages
        surr2 = torch.clamp(ratio, 1 - self.eps_clip, 1 + self.eps_clip) * advantages
        actor_loss = -torch.min(surr1, surr2).mean()

        critic_loss = nn.MSELoss()(values, returns)
        entropy = dist.entropy().mean()

        loss = actor_loss + 0.5 * critic_loss - 0.01 * entropy

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        self.buffer = {"states": [], "actions": [], "rewards": [], "dones": [], "log_probs": []}


class Archive:
    def __init__(self, trajectories):
        self.trajectories = trajectories

    def save(self, path):
        with open(path, "wb") as f:
            pickle.dump(self.trajectories, f)


def run_episode(env, agent, train=True, max_steps=200):
    state = env.reset()
    episode = []
    total_reward = 0
    for _ in range(max_steps):
        action, log_prob, _ = agent.act(state)
        next_state, reward, done, _ = env.step(action)
        if train:
            agent.store(state, action, reward, next_state, done, log_prob)
        episode.append((state, action))
        state = next_state
        total_reward += reward
        if done:
            break
    return episode, total_reward


if __name__ == "__main__":
    env = gym.make("CartPole-v0")
    obs_dim = env.observation_space.shape[0]
    act_dim = env.action_space.n

    training_episodes = 1000
    expert_episodes = 100
    max_steps = 200
    target_reward = 190
    data_name = "gail"

    actor = nn.Sequential(
        nn.Linear(obs_dim, 16),
        nn.ReLU(),
        nn.Linear(16, 16),
        nn.ReLU(),
        nn.Linear(16, act_dim)
    )
    critic = nn.Sequential(
        nn.Linear(obs_dim, 16),
        nn.ReLU(),
        nn.Linear(16, 16),
        nn.ReLU(),
        nn.Linear(16, 1)
    )
    ppo = PPO(actor, critic)

    reward_history = []
    consecutive = 0
    for episode in range(training_episodes):
        _, total_reward = run_episode(env, ppo, train=True, max_steps=max_steps)
        reward_history.append(total_reward)
        if len(reward_history) > 5:
            reward_history.pop(0)
        avg_reward = sum(reward_history) / len(reward_history)
        if avg_reward >= target_reward:
            consecutive += 1
        else:
            consecutive = 0
        if consecutive >= 5:
            print(f"Solved at episode {episode}")
            break
        ppo.update()
        print(f"Episode {episode+1}\tReward: {total_reward}\tAvg Reward: {avg_reward:.2f}")

    expert_trajs = []
    for _ in range(expert_episodes):
        traj, _ = run_episode(env, ppo, train=False, max_steps=max_steps)
        expert_trajs.append(traj)

    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    save_dir = os.path.join("generated", f"{data_name}_{timestamp}")
    os.makedirs(save_dir, exist_ok=True)
    archive = Archive(expert_trajs)
    archive_path = os.path.join(save_dir, "archive.pkl")
    archive.save(archive_path)
    print(f"Expert trajectories saved to {archive_path}")