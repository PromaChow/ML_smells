import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np


def get_model(state_dim, action_dim, network_type="mlp", policy_layers=[64, 64]):
    """
    Construct a policy network (actor) given state and action dimensions.
    Supports simple MLP or CNN (CNN is not implemented for brevity).
    """
    if network_type.lower() == "mlp":
        layers = []
        input_dim = state_dim
        for hidden_dim in policy_layers:
            layers.append(nn.Linear(input_dim, hidden_dim))
            layers.append(nn.ReLU())
            input_dim = hidden_dim
        layers.append(nn.Linear(input_dim, action_dim))
        model = nn.Sequential(*layers)
    else:
        raise NotImplementedError("Only 'mlp' network type is supported.")
    return model


def compute_returns_and_advantage(rewards, dones, gamma):
    """
    Compute discounted returns and advantage estimates.
    Since VPG has no critic, advantage is equal to returns.
    """
    returns = []
    R = 0
    for r, d in zip(reversed(rewards), reversed(dones)):
        if d:
            R = 0
        R = r + gamma * R
        returns.insert(0, R)
    returns = torch.tensor(returns, dtype=torch.float32)
    advantages = returns.clone()
    return returns, advantages


class RolloutBuffer:
    """
    Simple on‑policy rollout buffer.
    """
    def __init__(self, size):
        self.size = size
        self.states = []
        self.actions = []
        self.rewards = []
        self.dones = []

    def add(self, state, action, reward, done):
        self.states.append(state)
        self.actions.append(action)
        self.rewards.append(reward)
        self.dones.append(done)

    def clear(self):
        self.states = []
        self.actions = []
        self.rewards = []
        self.dones = []

    def sample(self, batch_size):
        idx = np.random.choice(len(self.states), batch_size, replace=False)
        return (
            torch.tensor(np.array([self.states[i] for i in idx]), dtype=torch.float32),
            torch.tensor(np.array([self.actions[i] for i in idx]), dtype=torch.float32),
            torch.tensor([self.rewards[i] for i in idx], dtype=torch.float32),
            torch.tensor([self.dones[i] for i in idx], dtype=torch.float32)
        )


class VPG:
    def __init__(
        self,
        network_type,
        env,
        lr_policy,
        gamma,
        rollout_buffer_size,
        create_model=True,
        deterministic=False
    ):
        self.network_type = network_type
        self.env = env
        self.lr_policy = lr_policy
        self.gamma = gamma
        self.rollout_buffer = RolloutBuffer(rollout_buffer_size)
        self.deterministic = deterministic

        self.logs = {}
        self.empty_logs()

        if create_model:
            self._create_model()

    def empty_logs(self):
        self.logs = {"loss": [], "reward": []}

    def _create_model(self):
        obs_space = self.env.observation_space
        act_space = self.env.action_space
        self.state_dim = obs_space.shape[0]
        if hasattr(act_space, "n"):  # discrete
            self.action_dim = act_space.n
            self.is_discrete = True
        else:
            self.action_dim = act_space.shape[0]
            self.is_discrete = False

        self.actor = get_model(self.state_dim, self.action_dim, self.network_type)
        self.optimizer_policy = optim.Adam(self.actor.parameters(), lr=self.lr_policy)

    def select_action(self, state):
        state = torch.tensor(state, dtype=torch.float32).unsqueeze(0)
        logits = self.actor(state)
        if self.is_discrete:
            probs = torch.softmax(logits, dim=-1)
            if self.deterministic:
                action = torch.argmax(probs, dim=-1)
                log_prob = torch.log(probs.gather(1, action.unsqueeze(1))).squeeze()
            else:
                dist = torch.distributions.Categorical(probs)
                action = dist.sample()
                log_prob = dist.log_prob(action)
        else:
            if self.deterministic:
                action = logits
                log_prob = torch.tensor(0.0)
            else:
                mean = logits
                std = torch.ones_like(mean) * 0.1
                dist = torch.distributions.Normal(mean, std)
                action = dist.sample()
                log_prob = dist.log_prob(action).sum(-1)
        action_np = action.detach().numpy()
        return action_np, 0.0, log_prob.item()

    def get_log_probs(self, states, actions):
        logits = self.actor(states)
        if self.is_discrete:
            probs = torch.softmax(logits, dim=-1)
            actions = actions.long()
            log_probs = torch.log(probs.gather(1, actions.unsqueeze(1))).squeeze()
        else:
            mean = logits
            std = torch.ones_like(mean) * 0.1
            dist = torch.distributions.Normal(mean, std)
            log_probs = dist.log_prob(actions).sum(-1)
        return log_probs

    def get_traj_loss(self):
        returns, advantages = compute_returns_and_advantage(
            self.rollout_buffer.rewards,
            self.rollout_buffer.dones,
            self.gamma
        )
        return returns, advantages

    def update_params(self, batch_size=64):
        states = torch.tensor(np.array(self.rollout_buffer.states), dtype=torch.float32)
        actions = torch.tensor(np.array(self.rollout_buffer.actions), dtype=torch.float32)
        returns, _ = self.get_traj_loss()
        for start in range(0, len(states), batch_size):
            end = start + batch_size
            batch_states = states[start:end]
            batch_actions = actions[start:end]
            batch_returns = returns[start:end]

            log_probs = self.get_log_probs(batch_states, batch_actions)
            loss = -torch.mean(batch_returns * log_probs)

            self.optimizer_policy.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(self.actor.parameters(), 0.5)
            self.optimizer_policy.step()

            self.logs["loss"].append(loss.item())

    def get_hyperparams(self):
        return {
            "network_type": self.network_type,
            "lr_policy": self.lr_policy,
            "gamma": self.gamma,
            "buffer_size": self.rollout_buffer.size
        }, self.actor.state_dict()

    def _load_weights(self, state_dict):
        self.actor.load_state_dict(state_dict)

    def get_logging_params(self):
        avg_loss = np.mean(self.logs["loss"]) if self.logs["loss"] else 0.0
        avg_reward = np.mean(self.logs["reward"]) if self.logs["reward"] else 0.0
        self.empty_logs()
        return {"avg_loss": avg_loss, "avg_reward": avg_reward}