import numpy as np
import chainer
import chainer.functions as F
import chainerrl
from chainerrl.action_value import (
    DiscreteActionValue,
    DistributionalDiscreteActionValue,
    QuantileDiscreteActionValue,
    QuadraticActionValue,
    SingleActionValue,
)
import pytest

rng = np.random.default_rng(0)

# ---------- DiscreteActionValue ----------
def test_discrete_action_value():
    batch_size = 30
    n_actions = 3
    q_vals = rng.normal(size=(batch_size, n_actions)).astype(np.float32)
    q_var = chainer.Variable(q_vals)
    av = DiscreteActionValue(q_var)

    # max
    max_vals_np = np.max(q_vals, axis=1)
    max_vals = av.max().array
    np.testing.assert_allclose(max_vals, max_vals_np)

    # greedy_actions
    greedy_np = np.argmax(q_vals, axis=1)
    greedy = av.greedy_actions().array
    np.testing.assert_array_equal(greedy, greedy_np)

    # evaluate_actions
    actions = np.array([0, 1, 2], dtype=np.int32)
    eval_vals = av.evaluate_actions(actions).array
    expected = q_vals[np.arange(batch_size), actions]
    np.testing.assert_allclose(eval_vals, expected)

    # compute_advantage
    opt_q = max_vals
    advantage = av.compute_advantage(actions).array
    expected_adv = expected - opt_q
    np.testing.assert_allclose(advantage, expected_adv)

    # params
    params = list(av.params())
    assert len(params) == 1
    np.testing.assert_array_equal(params[0].array, q_vals)

    # getitem
    slice_idx = slice(5, 10)
    av_slice = av[slice_idx]
    assert isinstance(av_slice, DiscreteActionValue)
    np.testing.assert_array_equal(av_slice.array.array, q_vals[slice_idx])

# ---------- DistributionalDiscreteActionValue ----------
def test_distributional_discrete_action_value():
    batch_size = 30
    n_actions = 3
    n_atoms = 51
    atoms = rng.normal(size=(batch_size, n_actions, n_atoms)).astype(np.float32)
    # Normalize to probabilities
    atoms = np.exp(atoms) / np.exp(atoms).sum(axis=-1, keepdims=True)
    z = np.linspace(-10, 10, n_atoms, dtype=np.float32)

    atom_var = chainer.Variable(atoms)
    z_var = chainer.Variable(z)
    av = DistributionalDiscreteActionValue(atom_var, z_var)

    expected_q = np.sum(atoms * z, axis=-1)

    # max
    max_vals_np = np.max(expected_q, axis=1)
    max_vals = av.max().array
    np.testing.assert_allclose(max_vals, max_vals_np)

    # max_as_distribution
    max_actions_np = np.argmax(expected_q, axis=1)
    max_dist = av.max_as_distribution().array
    expected_max_dist = atoms[np.arange(batch_size), max_actions_np]
    np.testing.assert_allclose(max_dist, expected_max_dist)

    # evaluate_actions
    actions = np.array([0, 1, 2], dtype=np.int32)
    eval_q = av.evaluate_actions(actions).array
    expected_eval_q = expected_q[np.arange(batch_size), actions]
    np.testing.assert_allclose(eval_q, expected_eval_q)

    # evaluate_actions_as_distribution
    eval_dist = av.evaluate_actions_as_distribution(actions).array
    expected_eval_dist = atoms[np.arange(batch_size), actions]
    np.testing.assert_allclose(eval_dist, expected_eval_dist)

    # compute_advantage
    opt_q = max_vals
    advantage = av.compute_advantage(actions).array
    expected_adv = eval_q - opt_q
    np.testing.assert_allclose(advantage, expected_adv)

    # params
    params = list(av.params())
    assert len(params) == 2
    np.testing.assert_array_equal(params[0].array, atoms)
    np.testing.assert_array_equal(params[1].array, z)

    # getitem
    slice_idx = slice(10, 20)
    av_slice = av[slice_idx]
    assert isinstance(av_slice, DistributionalDiscreteActionValue)
    np.testing.assert_array_equal(av_slice.atom_probabilities.array, atoms[slice_idx])
    np.testing.assert_array_equal(av_slice.z.array, z)

# ---------- QuantileDiscreteActionValue ----------
def test_quantile_discrete_action_value():
    batch_size = 30
    n_quantiles = 5
    n_actions = 3
    quantiles = rng.normal(size=(batch_size, n_quantiles, n_actions)).astype(np.float32)
    quant_var = chainer.Variable(quantiles)
    av = QuantileDiscreteActionValue(quant_var)

    expected_q = np.mean(quantiles, axis=1)

    # q_values
    q_vals = av.q_values.array
    np.testing.assert_allclose(q_vals, expected_q)

    # evaluate_actions_as_quantiles
    actions = np.array([0, 1, 2], dtype=np.int32)
    eval_quant = av.evaluate_actions_as_quantiles(actions).array
    expected_eval_quant = quantiles[:, :, actions]
    np.testing.assert_allclose(eval_quant, expected_eval_quant)

    # params
    params = list(av.params())
    assert len(params) == 1
    np.testing.assert_array_equal(params[0].array, quantiles)

    # getitem
    slice_idx = slice(5, 15)
    av_slice = av[slice_idx]
    assert isinstance(av_slice, QuantileDiscreteActionValue)
    np.testing.assert_array_equal(av_slice.quantiles.array, quantiles[slice_idx])

# ---------- QuadraticActionValue ----------
def test_quadratic_action_value():
    batch_size = 30
    action_dim = 4
    mu = rng.normal(size=(action_dim,)).astype(np.float32)
    mat = rng.normal(size=(action_dim, action_dim)).astype(np.float32)
    mat = mat @ mat.T  # make positive semi-definite
    v = rng.uniform(low=0.0, high=1.0, size=()).astype(np.float32)

    # Unbounded
    av_unbounded = QuadraticActionValue(mu, mat, v)
    max_val = av_unbounded.max()
    np.testing.assert_allclose(max_val.array, v)

    # Bounded
    lower = -0.5 * np.ones(action_dim, dtype=np.float32)
    upper = 0.5 * np.ones(action_dim, dtype=np.float32)
    av_bounded = QuadraticActionValue(mu, mat, v, lower, upper)
    if np.all(mu >= lower) and np.all(mu <= upper):
        np.testing.assert_allclose(av_bounded.max().array, v)
    else:
        np.testing.assert_less(av_bounded.max().array, v)

    # getitem
    slice_idx = slice(5, 15)
    av_slice = av_unbounded[slice_idx]
    assert isinstance(av_slice, QuadraticActionValue)
    np.testing.assert_array_equal(av_slice.mu, mu)
    np.testing.assert_array_equal(av_slice.mat, mat)
    np.testing.assert_array_equal(av_slice.v, v)

# ---------- SingleActionValue ----------
def negative_squared_norm(action):
    # action: Variable or ndarray
    action_arr = action if isinstance(action, np.ndarray) else action.array
    return -np.sum(action_arr**2, axis=-1)

@pytest.mark.parametrize("batch_size", [1, 3])
@pytest.mark.parametrize("action_size", [1, 2])
@pytest.mark.parametrize("has_maximizer", [True, False])
def test_single_action_value(batch_size, action_size, has_maximizer):
    def evaluator(action):
        # action shape (batch, action_size)
        return -np.sum(action**2, axis=-1, keepdims=True)

    maximizer = np.zeros((batch_size, action_size), dtype=np.float32) if has_maximizer else None
    av = SingleActionValue(evaluator, maximizer)

    # max
    max_val = av.max()
    expected_max = evaluator(maximizer) if maximizer is not None else np.full((batch_size, 1), -np.inf, dtype=np.float32)
    np.testing.assert_allclose(max_val.array, expected_max)

    # greedy_actions
    if maximizer is not None:
        greedy = av.greedy_actions()
        np.testing.assert_allclose(greedy.array, maximizer)
    else:
        with pytest.raises(RuntimeError):
            av.greedy_actions()

    # evaluate_actions
    actions = np.random.randn(batch_size, action_size).astype(np.float32)
    eval_val = av.evaluate_actions(actions).array
    np.testing.assert_allclose(eval_val, evaluator(actions))

    # compute_advantage
    advantage = av.compute_advantage(actions).array
    expected_adv = evaluator(actions) - expected_max
    np.testing.assert_allclose(advantage, expected_adv)

    # params
    params = list(av.params())
    assert len(params) == 0

    # getitem
    with pytest.raises(RuntimeError):
        av[slice(0, 1)]
