import argparse
import json
import logging
import os
import random
import sys
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, List, Tuple

import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.neighbors import KernelDensity
from torch.utils.data import DataLoader, Dataset, TensorDataset


@dataclass
class Config:
    dataset_name: str
    experiment_path: str
    data_path: str
    labeled_normal_ratio: float
    labeled_anomaly_ratio: float
    seed: int
    kernel: str
    grid_search_cv: bool
    hybrid: bool
    load_model: str
    load_ae: str
    n_jobs_dataloader: int
    normal_class: int
    known_outlier_classes: List[int]
    pollution_ratio: float
    num_known_outlier_classes: int


def parse_args() -> Config:
    parser = argparse.ArgumentParser(description="Hybrid KDE Anomaly Detection")
    parser.add_argument("--dataset_name", type=str, required=True)
    parser.add_argument("--experiment_path", type=str, required=True)
    parser.add_argument("--data_path", type=str, required=True)
    parser.add_argument("--labeled_normal_ratio", type=float, default=0.1)
    parser.add_argument("--labeled_anomaly_ratio", type=float, default=0.1)
    parser.add_argument("--seed", type=int, default=-1)
    parser.add_argument("--kernel", type=str, default="gaussian")
    parser.add_argument("--grid_search_cv", action="store_true")
    parser.add_argument("--hybrid", action="store_true")
    parser.add_argument("--load_model", type=str, default="")
    parser.add_argument("--load_ae", type=str, default="")
    parser.add_argument("--n_jobs_dataloader", type=int, default=4)
    parser.add_argument("--normal_class", type=int, default=0)
    parser.add_argument("--known_outlier_classes", nargs="+", type=int, default=[1])
    parser.add_argument("--pollution_ratio", type=float, default=0.0)
    parser.add_argument("--num_known_outlier_classes", type=int, default=1)
    args = parser.parse_args()
    return Config(
        dataset_name=args.dataset_name,
        experiment_path=args.experiment_path,
        data_path=args.data_path,
        labeled_normal_ratio=args.labeled_normal_ratio,
        labeled_anomaly_ratio=args.labeled_anomaly_ratio,
        seed=args.seed,
        kernel=args.kernel,
        grid_search_cv=args.grid_search_cv,
        hybrid=args.hybrid,
        load_model=args.load_model,
        load_ae=args.load_ae,
        n_jobs_dataloader=args.n_jobs_dataloader,
        normal_class=args.normal_class,
        known_outlier_classes=args.known_outlier_classes,
        pollution_ratio=args.pollution_ratio,
        num_known_outlier_classes=args.num_known_outlier_classes,
    )


def setup_logging(exp_path: str) -> None:
    os.makedirs(exp_path, exist_ok=True)
    log_file = os.path.join(exp_path, "log.txt")
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[logging.FileHandler(log_file), logging.StreamHandler(sys.stdout)],
    )


def set_seed(seed: int) -> None:
    if seed != -1:
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        logging.info(f"Seed set to {seed}")


class DummyImageDataset(Dataset):
    def __init__(self, num_samples: int, img_shape: Tuple[int, int, int]):
        self.data = torch.randn(num_samples, *img_shape)
        self.labels = torch.randint(0, 10, (num_samples,))

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx], self.labels[idx]


class DummyTabularDataset(Dataset):
    def __init__(self, num_samples: int, num_features: int):
        self.data = torch.randn(num_samples, num_features)
        self.labels = torch.randint(0, 2, (num_samples,))

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx], self.labels[idx]


def load_dataset(
    config: Config,
    random_state: int,
) -> Dict[str, Any]:
    torch.manual_seed(random_state)
    if config.dataset_name.lower() in ["mnist", "fmnist", "cifar10"]:
        train_set = DummyImageDataset(1000, (3, 32, 32))
        test_set = DummyImageDataset(200, (3, 32, 32))
    else:
        train_set = DummyTabularDataset(1000, 20)
        test_set = DummyTabularDataset(200, 20)
    logging.info(
        f"Loaded dataset {config.dataset_name} with train size {len(train_set)} and test size {len(test_set)}"
    )
    return {"train": train_set, "test": test_set}


class Autoencoder(nn.Module):
    def __init__(self, input_dim: int, latent_dim: int):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 64), nn.ReLU(), nn.Linear(64, latent_dim)
        )
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, 64), nn.ReLU(), nn.Linear(64, input_dim)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        z = self.encoder(x)
        recon = self.decoder(z)
        return recon

    def encode(self, x: torch.Tensor) -> torch.Tensor:
        return self.encoder(x)


class KDE:
    def __init__(self, kernel: str = "gaussian", bandwidth: float = 1.0):
        self.kernel = kernel
        self.bandwidth = bandwidth
        self.model = KernelDensity(kernel=self.kernel, bandwidth=self.bandwidth)

    def load(self, path: str) -> None:
        self.model = torch.load(path)

    def save(self, path: str) -> None:
        torch.save(self.model, path)

    def fit(self, X: np.ndarray) -> None:
        self.model.fit(X)

    def score_samples(self, X: np.ndarray) -> np.ndarray:
        return self.model.score_samples(X)

    def set_bandwidth(self, bw: float) -> None:
        self.bandwidth = bw
        self.model = KernelDensity(kernel=self.kernel, bandwidth=self.bandwidth)


def train_kde(
    kde: KDE,
    train_loader: DataLoader,
    grid_search: bool,
    device: torch.device,
) -> None:
    all_features = []
    for data, _ in train_loader:
        data = data.to(device)
        all_features.append(data.cpu().numpy())
    X = np.concatenate(all_features, axis=0)
    if grid_search:
        bw_values = np.linspace(0.1, 1.0, 10)
        scores = []
        for bw in bw_values:
            kde.set_bandwidth(bw)
            kde.fit(X)
            scores.append(np.mean(kde.score_samples(X)))
        best_bw = bw_values[np.argmax(scores)]
        kde.set_bandwidth(best_bw)
        logging.info(f"Grid search selected bandwidth {best_bw}")
    else:
        kde.fit(X)
    logging.info("KDE training completed.")


def evaluate_kde(
    kde: KDE,
    test_loader: DataLoader,
    device: torch.device,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    scores = []
    labels = []
    indices = []
    for idx, (data, label) in enumerate(test_loader):
        data = data.to(device)
        scores.extend(kde.score_samples(data.cpu().numpy()))
        labels.extend(label.numpy())
        indices.extend([idx] * len(label))
    return np.array(scores), np.array(labels), np.array(indices)


def save_results(
    exp_path: str,
    scores: np.ndarray,
    labels: np.ndarray,
    indices: np.ndarray,
    config: Config,
) -> None:
    results = {
        "scores": scores.tolist(),
        "labels": labels.tolist(),
        "indices": indices.tolist(),
    }
    with open(os.path.join(exp_path, "results.json"), "w") as f:
        json.dump(results, f, indent=2)
    with open(os.path.join(exp_path, "config.json"), "w") as f:
        json.dump(asdict(config), f, indent=2)
    logging.info("Results and config saved.")


def visualize_anomalies(
    data_loader: DataLoader,
    scores: np.ndarray,
    labels: np.ndarray,
    exp_path: str,
    dataset_name: str,
) -> None:
    if dataset_name.lower() not in ["mnist", "fmnist", "cifar10"]:
        return
    data = []
    for d, _ in data_loader:
        data.append(d.numpy())
    all_data = np.concatenate(data, axis=0)
    indices = np.argsort(-scores)
    top_n = 32
    fig, axs = plt.subplots(4, 8, figsize=(16, 8))
    for i, idx in enumerate(indices[:top_n]):
        img = all_data[idx].transpose(1, 2, 0)
        axs[i // 8, i % 8].imshow(np.clip(img, 0, 1))
        axs[i // 8, i % 8].axis("off")
    plt.tight_layout()
    plt.savefig(os.path.join(exp_path, "all_high.png"))
    plt.close(fig)

    fig, axs = plt.subplots(4, 8, figsize=(16, 8))
    for i, idx in enumerate(indices[-top_n:]):
        img = all_data[idx].transpose(1, 2, 0)
        axs[i // 8, i % 8].imshow(np.clip(img, 0, 1))
        axs[i // 8, i % 8].axis("off")
    plt.tight_layout()
    plt.savefig(os.path.join(exp_path, "all_low.png"))
    plt.close(fig)

    normal_mask = labels == 0
    anomalous_mask = labels == 1
    normal_scores = scores[normal_mask]
    anomalous_scores = scores[anomalous_mask]
    normal_indices = indices[normal_mask]
    anomalous_indices = indices[anomalous_mask]

    fig, axs = plt.subplots(4, 8, figsize=(16, 8))
    for i, idx in enumerate(normal_indices[:top_n]):
        img = all_data[idx].transpose(1, 2, 0)
        axs[i // 8, i % 8].imshow(np.clip(img, 0, 1))
        axs[i // 8, i % 8].axis("off")
    plt.tight_layout()
    plt.savefig(os.path.join(exp_path, "normals_high.png"))
    plt.close(fig)

    fig, axs = plt.subplots(4, 8, figsize=(16, 8))
    for i, idx in enumerate(normal_indices[-top_n:]):
        img = all_data[idx].transpose(1, 2, 0)
        axs[i // 8, i % 8].imshow(np.clip(img, 0, 1))
        axs[i // 8, i % 8].axis("off")
    plt.tight_layout()
    plt.savefig(os.path.join(exp_path, "normals_low.png"))
    plt.close(fig)
    logging.info("Visualization images saved.")


def main() -> None:
    config = parse_args()
    setup_logging(config.experiment_path)
    logging.info(f"Configuration: {config}")
    set_seed(config.seed)

    dataset = load_dataset(config, random_state=config.seed if config.seed != -1 else None)

    train_loader = DataLoader(
        dataset["train"],
        batch_size=64,
        shuffle=True,
        num_workers=config.n_jobs_dataloader,
    )
    test_loader = DataLoader(
        dataset["test"],
        batch_size=64,
        shuffle=False,
        num_workers=config.n_jobs_dataloader,
    )

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logging.info(f"Using device {device}")

    if config.hybrid:
        sample, _ = next(iter(train_loader))
        input_dim = sample.shape[1] if sample.dim() == 2 else np.prod(sample.shape[1:])
        autoencoder = Autoencoder(input_dim, latent_dim=16).to(device)
        if config.load_ae:
            autoencoder.load_state_dict(torch.load(config.load_ae))
        autoencoder.eval()
        logging.info("Autoencoder loaded and set to eval mode.")

    kde = KDE(kernel=config.kernel)
    if config.load_model:
        kde.load(config.load_model)
        logging.info(f"Loaded pre-trained KDE from {config.load_model}")

    if config.hybrid:
        # Replace train_loader with encoded features
        encoded_samples = []
        with torch.no_grad():
            for data, _ in train_loader:
                data = data.to(device)
                if data.dim() == 4:  # image
                    data = data.view(data.size(0), -1)
                encoded = autoencoder.encode(data)
                encoded_samples.append(encoded.cpu().numpy())
        train_loader = DataLoader(
            TensorDataset(
                torch.tensor(np.concatenate(encoded_samples, axis=0)),
                torch.zeros(len(encoded_samples)),
            ),
            batch_size=64,
            shuffle=True,
            num_workers=config.n_jobs_dataloader,
        )

    train_kde(kde, train_loader, config.grid_search_cv, device)

    scores, labels, indices = evaluate_kde(kde, test_loader, device)

    save_results(config.experiment_path, scores, labels, indices, config)

    visualize_anomalies(
        test_loader,
        scores,
        labels,
        config.experiment_path,
        config.dataset_name,
    )


if __name__ == "__main__":
    main()
