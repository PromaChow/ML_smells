import subprocess
import sys

# Install required packages
subprocess.check_call([sys.executable, "-m", "pip", "install", "numpy", "pandas", "matplotlib", "scikit-learn"])

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis as LDA

def main():
    # Load Iris dataset
    iris = load_iris()
    X = iris.data          # 150 x 4 feature matrix
    y = iris.target        # 150 target labels
    target_names = iris.target_names

    # Apply PCA (no scaling)
    pca = PCA(n_components=2)
    X_pca = pca.fit_transform(X)  # 150 x 2
    print("PCA explained variance ratio:", pca.explained_variance_ratio_)

    # Apply LDA
    lda = LDA(n_components=2)
    lda.fit(X, y)
    X_lda = lda.transform(X)      # 150 x 2

    # Plot PCA results
    plt.figure(figsize=(12, 5))

    plt.subplot(1, 2, 1)
    for idx, class_name in enumerate(target_names):
        plt.scatter(
            X_pca[y == idx, 0],
            X_pca[y == idx, 1],
            label=class_name,
            alpha=0.7
        )
    plt.title("PCA of Iris Dataset")
    plt.xlabel("Principal Component 1")
    plt.ylabel("Principal Component 2")
    plt.legend()

    # Plot LDA results
    plt.subplot(1, 2, 2)
    for idx, class_name in enumerate(target_names):
        plt.scatter(
            X_lda[y == idx, 0],
            X_lda[y == idx, 1],
            label=class_name,
            alpha=0.7
        )
    plt.title("LDA of Iris Dataset")
    plt.xlabel("Linear Discriminant 1")
    plt.ylabel("Linear Discriminant 2")
    plt.legend()

    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()
