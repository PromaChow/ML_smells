import os
import sys
import numpy as np

# Optional cv2 import
try:
    import cv2  # type: ignore
except ImportError:
    cv2 = None

# PIL for fallback
try:
    from PIL import Image  # type: ignore
except ImportError:
    Image = None

# atari_py
try:
    import atari_py  # type: ignore
except ImportError:
    raise ImportError("atari_py is required but not installed")

# version check
try:
    from importlib import metadata
    atari_py_version = metadata.version("atari_py")
    if tuple(map(int, atari_py_version.split("."))) < (0, 1, 1):
        raise RuntimeError(f"atari_py version must be >= 0.1.1, found {atari_py_version}")
except Exception as e:
    raise RuntimeError(f"Failed to verify atari_py version: {e}")


class ALE:
    def __init__(
        self,
        game,
        seed=None,
        frame_skip=4,
        crop_or_scale="crop",
        max_start_nullops=30,
        n_last_screens=4,
        treat_life_lost_as_terminal=True,
        use_sdl=False,
    ):
        self.game = game
        self.seed = seed if seed is not None else np.random.randint(0, 2**31 - 1)
        np.random.seed(self.seed)

        self.frame_skip = frame_skip
        if crop_or_scale not in ("crop", "scale"):
            raise ValueError("crop_or_scale must be 'crop' or 'scale'")
        self.crop_or_scale = crop_or_scale

        self.max_start_nullops = max_start_nullops
        self.n_last_screens = n_last_screens
        self.treat_life_lost_as_terminal = treat_life_lost_as_terminal

        self.ale = atari_py.ALEInterface()
        self.ale.setInt("random_seed", int(self.seed))
        self.ale.setFloat("repeat_action_probability", 0.0)
        self.ale.setBool("color_averaging", True)
        if use_sdl:
            self.ale.setBool("display_screen", True)
            self.ale.setBool("sound", False)

        rom_path = atari_py.get_game_path(self.game)
        if not rom_path or not os.path.exists(rom_path):
            raise RuntimeError(f"ROM for game '{self.game}' not found")
        self.ale.loadROM(rom_path)

        self.minimal_actions = self.ale.getMinimalActionSet()
        self.prev_screen_rgb = None
        self.last_screens = [np.zeros((84, 84), dtype=np.uint8) for _ in range(self.n_last_screens)]
        self.terminal = False
        self.lives = self.ale.lives()
        self.initialize()

    def initialize(self):
        self.ale.reset_game()
        self.prev_screen_rgb = None
        self.lives = self.ale.lives()
        self.terminal = False

        # Random null actions at start
        for _ in range(self.max_start_nullops):
            action = np.random.choice(self.minimal_actions)
            self.ale.act(action)

        # Fill initial screen buffer
        first_screen = self._process_screen()
        self.last_screens = [first_screen for _ in range(self.n_last_screens)]

    def reset(self):
        self.initialize()
        return self.state

    @property
    def state(self):
        return tuple(self.last_screens)

    @property
    def is_terminal(self):
        return self.terminal or (
            self.treat_life_lost_as_terminal and self.lives < self._last_lives
        )

    def _process_screen(self):
        current_rgb = self.ale.getScreenRGB()
        if self.prev_screen_rgb is None:
            max_rgb = current_rgb
        else:
            max_rgb = np.maximum(current_rgb, self.prev_screen_rgb)

        luminance = np.dot(max_rgb[..., :3], [0.299, 0.587, 0.114]).astype(np.uint8)

        if self.crop_or_scale == "crop":
            # Resize to (110, 84) then crop center 84x84
            if cv2:
                resized = cv2.resize(luminance, (110, 84), interpolation=cv2.INTER_AREA)
            elif Image:
                resized = Image.fromarray(luminance).resize((110, 84), Image.BILINEAR)
                resized = np.array(resized)
            else:
                raise RuntimeError("Neither cv2 nor PIL available for image processing")
            cropped = resized[:, 13:97]  # crop 13 pixels from left and right
            processed = cropped
        else:  # scale
            if cv2:
                processed = cv2.resize(luminance, (84, 84), interpolation=cv2.INTER_AREA)
            elif Image:
                processed = Image.fromarray(luminance).resize((84, 84), Image.BILINEAR)
                processed = np.array(processed)
            else:
                raise RuntimeError("Neither cv2 nor PIL available for image processing")

        self.prev_screen_rgb = max_rgb
        return processed

    def receive_action(self, action):
        total_reward = 0.0
        self._last_lives = self.lives
        for _ in range(self.frame_skip):
            reward = self.ale.act(action)
            total_reward += reward
            if self.ale.gameOver():
                self.terminal = True
                break
        self.lives = self.ale.lives()
        if not self.terminal:
            new_screen = self._process_screen()
            # Circular buffer update
            self.last_screens = self.last_screens[1:] + [new_screen]
        return total_reward

    def step(self, action):
        reward = self.receive_action(action)
        return self.state, reward, self.is_terminal, {}

    def close(self):
        pass
