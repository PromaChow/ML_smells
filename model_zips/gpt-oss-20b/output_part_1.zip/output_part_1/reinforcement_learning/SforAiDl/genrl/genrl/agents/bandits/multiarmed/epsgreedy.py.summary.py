import numpy as np
import random

class MultiArmedBandit:
    def __init__(self, bandits, arms):
        self.bandits = bandits
        self.arms = arms

class EpsilonGreedyMAB:
    def __init__(self, bandit, eps=0.1):
        self.bandit = bandit
        self.eps = eps
        self.bandits = bandit.bandits
        self.arms = bandit.arms
        self.quality = np.zeros((self.bandits, self.arms))
        self.counts = np.zeros((self.bandits, self.arms), dtype=int)
        self.action_hist = []
        self.reward_hist = []
        self.regret_hist = []

    def select_action(self, context):
        if random.random() < self.eps:
            action = random.randint(0, self.arms - 1)
        else:
            action = int(np.argmax(self.quality[context]))
        self.action_hist.append((context, action))
        return action

    def update(self, context, action, reward):
        self.reward_hist.append(reward)
        max_q = np.max(self.quality[context])
        cur_q = self.quality[context, action]
        regret = max_q - cur_q
        self.regret_hist.append(regret)
        n = self.counts[context, action]
        q_new = cur_q + (reward - cur_q) / (n + 1)
        self.quality[context, action] = q_new
        self.counts[context, action] += 1
