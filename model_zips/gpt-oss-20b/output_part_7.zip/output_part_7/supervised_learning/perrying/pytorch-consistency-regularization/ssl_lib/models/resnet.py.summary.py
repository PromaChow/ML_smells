import torch
import torch.nn as nn
import torch.nn.functional as F

def conv3x3(in_planes: int, out_planes: int, stride: int = 1) -> nn.Conv2d:
    return nn.Conv2d(
        in_planes,
        out_planes,
        kernel_size=3,
        stride=stride,
        padding=1,
        bias=False,
    )

def conv1x1(in_planes: int, out_planes: int, stride: int = 1) -> nn.Conv2d:
    return nn.Conv2d(
        in_planes,
        out_planes,
        kernel_size=1,
        stride=stride,
        bias=False,
    )

class _Residual(nn.Module):
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        stride: int = 1,
        activate_before_residual: bool = False,
    ):
        super().__init__()
        self.activate_before_residual = activate_before_residual
        if activate_before_residual:
            self.bn_pre = nn.BatchNorm2d(in_channels)
            self.act_pre = nn.LeakyReLU(inplace=True)

        self.conv1 = conv3x3(in_channels, out_channels, stride=stride)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.act1 = nn.LeakyReLU(inplace=True)

        self.conv2 = conv3x3(out_channels, out_channels)
        self.bn2 = nn.BatchNorm2d(out_channels)

        if stride != 1 or in_channels != out_channels:
            self.shortcut = conv1x1(in_channels, out_channels, stride=stride)
        else:
            self.shortcut = nn.Identity()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.activate_before_residual:
            out = self.bn_pre(x)
            out = self.act_pre(out)
        else:
            out = x

        out = self.conv1(out)
        out = self.bn1(out)
        out = self.act1(out)

        out = self.conv2(out)
        out = self.bn2(out)

        identity = self.shortcut(x)
        out = out + identity
        return out

class ResNet(nn.Module):
    def __init__(
        self,
        filters: int,
        repeats: int,
        scales: int,
        num_classes: int,
        dropout: float | None = None,
    ):
        super().__init__()
        self.feature_extractor = nn.Sequential()
        self.feature_extractor.add_module("conv1", conv3x3(3, 16))

        in_channels = 16
        for scale in range(scales):
            out_channels = filters << scale
            stride = 2 if scale == 0 else 1
            activate_before = scale == 0

            # First residual block for this scale
            self.feature_extractor.add_module(
                f"scale{scale}_block0",
                _Residual(
                    in_channels,
                    out_channels,
                    stride=stride,
                    activate_before_residual=activate_before,
                ),
            )
            # Subsequent blocks
            for r in range(1, repeats):
                self.feature_extractor.add_module(
                    f"scale{scale}_block{r}",
                    _Residual(
                        out_channels,
                        out_channels,
                        stride=1,
                        activate_before_residual=False,
                    ),
                )
            in_channels = out_channels

        # Final BN and activation
        self.feature_extractor.add_module("bn", nn.BatchNorm2d(in_channels))
        self.feature_extractor.add_module("act", nn.LeakyReLU(inplace=True))

        # Classifier
        self.classifier = nn.Sequential()
        if dropout:
            self.classifier.add_module("dropout", nn.Dropout(dropout))
        self.classifier.add_module("fc", nn.Linear(in_channels, num_classes))

        # Parameter initialization
        from utils import param_init
        param_init(self)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.feature_extractor(x)
        x = F.adaptive_avg_pool2d(x, (1, 1))
        x = torch.flatten(x, 1)
        x = self.classifier(x)
        return x

if __name__ == "__main__":
    model = ResNet(filters=16, repeats=2, scales=3, num_classes=10, dropout=0.5)
    dummy = torch.randn(4, 3, 32, 32)
    out = model(dummy)
    print(out.shape)