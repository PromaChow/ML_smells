import numpy as np
from dm_control.mjcf import MJCFBasedRobot


class Striker(MJCFBasedRobot):
    MIN_OBJECT_PLACEMENT_RADIUS = 0.1
    MAX_OBJECT_PLACEMENT_RADIUS = 0.3

    def __init__(self):
        super().__init__(
            xml_path="striker.xml",
            root_body="body0",
            action_dim=7,
            observation_dim=56,
        )
        self.min_object_placement_radius = self.MIN_OBJECT_PLACEMENT_RADIUS
        self.max_object_placement_radius = self.MAX_OBJECT_PLACEMENT_RADIUS
        self.robot_specific_reset()

    def robot_specific_reset(self):
        # Component references
        self.fingertip = self.get_mjcf_body("fingertip")
        self.target = self.get_mjcf_body("coaster")
        self.object = self.get_mjcf_body("object")

        self.shoulder_pitch = self.get_mjcf_joint("shoulder_pitch")
        self.shoulder_yaw = self.get_mjcf_joint("shoulder_yaw")
        self.elbow_pitch = self.get_mjcf_joint("elbow_pitch")
        self.wrist_pitch = self.get_mjcf_joint("wrist_pitch")
        self.wrist_roll = self.get_mjcf_joint("wrist_roll")
        self.gripper_finger1 = self.get_mjcf_joint("gripper_finger1")
        self.gripper_finger2 = self.get_mjcf_joint("gripper_finger2")

        self.obj_slidex = self.get_mjcf_joint("obj_slidex")
        self.obj_slidey = self.get_mjcf_joint("obj_slidey")
        self.goal_slidex = self.get_mjcf_joint("goal_slidex")
        self.goal_slidey = self.get_mjcf_joint("goal_slidey")

        self.joints = [
            self.shoulder_pitch,
            self.shoulder_yaw,
            self.elbow_pitch,
            self.wrist_pitch,
            self.wrist_roll,
            self.gripper_finger1,
            self.gripper_finger2,
        ]

        # Joint initialization
        for joint in self.joints:
            self.reset_current_position(joint, np.random.uniform(-np.pi, np.pi))

        # Position setup
        zero_offset = np.array([0.45, 0.55, 0.0])

        # Object placement
        rand_vec = np.random.randn(3)
        rand_vec /= np.linalg.norm(rand_vec)
        radius = np.random.uniform(
            self.min_object_placement_radius, self.max_object_placement_radius
        )
        object_pos = zero_offset + rand_vec * radius
        self.obj_slidex.set_joint_position(object_pos[0] - zero_offset[0])
        self.obj_slidey.set_joint_position(object_pos[1] - zero_offset[1])

        # Target placement
        target_xy = np.random.uniform(-0.5, 0.5, size=2)
        target_pos = np.array([zero_offset[0] + target_xy[0], zero_offset[1] + target_xy[1], -0.2])
        self.goal_slidex.set_joint_position(target_pos[0] - zero_offset[0])
        self.goal_slidey.set_joint_position(target_pos[1] - zero_offset[1])

    def apply_action(self, action):
        for joint, act in zip(self.joints, action):
            torque = np.clip(act * 0.05, -1.0, 1.0)
            joint.set_motor_torque(torque)

    def calc_state(self):
        joint_positions = np.concatenate([joint.position for joint in self.joints])
        joint_speeds = np.concatenate([joint.speed for joint in self.joints])

        fingertip_pos = self.fingertip.xpos
        object_pos = self.object.xpos
        target_pos = self.target.xpos

        to_target_vec = target_pos - object_pos

        state = np.concatenate(
            [
                joint_positions,
                joint_speeds,
                to_target_vec,
                fingertip_pos,
                object_pos,
                target_pos,
            ]
        )
        return state

