import torch
from typing import Tuple, List

class History:
    def __init__(self, history_depth: int, state_shape: Tuple[int, ...]) -> None:
        self.history_depth: int = history_depth
        self.state_shape: Tuple[int, ...] = state_shape
        self.history: List[torch.Tensor] = [
            torch.zeros(state_shape, dtype=torch.float32) for _ in range(history_depth)
        ]

    def append(self, state: torch.Tensor) -> "History":
        assert isinstance(state, torch.Tensor), "Input must be a torch.Tensor."
        assert state.dtype == torch.float32, "Tensor dtype must be float32."
        assert state.shape == self.state_shape, f"Tensor shape must be {self.state_shape}."
        self.history.append(state.clone())
        if len(self.history) > self.history_depth:
            self.history.pop(0)
        return self

    def get(self) -> torch.Tensor:
        concatenated = torch.cat(self.history, dim=0)
        return concatenated.unsqueeze(0)