import numpy as np
import pandas as pd

def rolling1d(series, window):
    arr = np.asarray(series)
    if arr.ndim != 1:
        raise ValueError("Input must be 1D.")
    n = arr.size
    if window > n:
        raise ValueError("Window size larger than series length.")
    stride = arr.strides[0]
    shape = (n - window + 1, window)
    strides = (stride, stride)
    return np.lib.stride_tricks.as_strided(arr, shape=shape, strides=strides)

def rolling2d(matrix, window):
    if isinstance(matrix, pd.DataFrame):
        arr = matrix.values
    else:
        arr = np.asarray(matrix)
    if arr.ndim != 2:
        raise ValueError("Input must be 2D.")
    n, m = arr.shape
    if window > n:
        raise ValueError("Window size larger than number of rows.")
    windows = [rolling1d(arr[:, j], window) for j in range(m)]
    return np.stack(windows, axis=-1)

def Xy(series, window, out_shape):
    arr = np.asarray(series)
    if arr.ndim != 1:
        raise ValueError("Input must be 1D.")
    total_window = window + out_shape
    if total_window > arr.size:
        raise ValueError("Total window larger than series length.")
    tmp = rolling1d(arr, total_window)
    X = tmp[:, :window]
    y = tmp[:, window:]
    return X, y

def standard(data):
    arr = np.asarray(data)
    eps = 1e-8
    if arr.ndim == 1:
        mean = arr.mean()
        std = arr.std()
        return (arr - mean) / (std + eps)
    else:
        mean = arr.mean(axis=0, keepdims=True)
        std = arr.std(axis=0, keepdims=True)
        return (arr - mean) / (std + eps)

def flatten(arr3d):
    arr3d = np.asarray(arr3d)
    if arr3d.ndim != 3:
        raise ValueError("Input must be 3D.")
    N, L, M = arr3d.shape
    return arr3d.reshape(N, L * M)

def deflatten(arr2d, window):
    arr2d = np.asarray(arr2d)
    if arr2d.ndim != 2:
        raise ValueError("Input must be 2D.")
    N, flat = arr2d.shape
    if flat % window != 0:
        raise ValueError("Flat dimension not divisible by window size.")
    newdim = flat // window
    return arr2d.reshape(N, newdim, window)