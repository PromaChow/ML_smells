import collections
import unittest
from collections import namedtuple

def _is_scalar(obj):
    return not isinstance(obj, (list, tuple, dict)) and not isinstance(obj, collections.abc.Mapping) and not isinstance(obj, collections.abc.Iterable) or isinstance(obj, str)

def _is_namedtuple(obj):
    return isinstance(obj, tuple) and hasattr(obj, '_fields')

def _to_sequence(seq):
    return list(seq) if isinstance(seq, tuple) else seq

def custom_zip(*args):
    if not args:
        return None
    # All scalars
    if all(_is_scalar(a) for a in args):
        return args[0] if len(args) == 1 else tuple(args)
    # Any namedtuple treated as tuple
    seq_args = [_to_sequence(a) if _is_namedtuple(a) else a for a in args]
    first = seq_args[0]
    # Dict handling
    if isinstance(first, dict):
        keys = sorted(first.keys())
        result = {}
        for k in keys:
            values = [d[k] for d in seq_args]
            result[k] = custom_zip(*values)
        return result
    # List or tuple handling
    if isinstance(first, (list, tuple)):
        length = len(first)
        result = []
        for i in range(length):
            values = [a[i] for a in seq_args]
            result.append(custom_zip(*values))
        return type(first)(result)
    # Should not reach here
    return tuple(args)

def custom_map(func, *datas):
    if not datas:
        return None
    # Single data
    if len(datas) == 1:
        data = datas[0]
        if _is_scalar(data):
            return func(data)
        if _is_namedtuple(data):
            mapped = tuple(custom_map(func, v) for v in data)
            return data.__class__(*mapped)
        if isinstance(data, dict):
            return {k: custom_map(func, v) for k, v in data.items()}
        if isinstance(data, (list, tuple)):
            return type(data)(custom_map(func, v) for v in data)
    # Multiple data
    if any(_is_scalar(d) for d in datas):
        return func(*datas)
    first = datas[0]
    if _is_namedtuple(first):
        fields = []
        for i in range(len(first)):
            values = [d[i] for d in datas]
            fields.append(custom_map(func, *values))
        return first.__class__(*fields)
    if isinstance(first, dict):
        keys = sorted(first.keys())
        return {k: custom_map(func, *[d[k] for d in datas]) for k in keys}
    if isinstance(first, (list, tuple)):
        length = len(first)
        return type(first)(custom_map(func, *[d[i] for d in datas]) for i in range(length))

def custom_flatten(data):
    if _is_scalar(data):
        return (data,)
    if _is_namedtuple(data):
        flat = []
        for v in data:
            flat.extend(custom_flatten(v))
        return tuple(flat)
    if isinstance(data, dict):
        flat = []
        for k in sorted(data.keys()):
            flat.extend(custom_flatten(data[k]))
        return tuple(flat)
    if isinstance(data, (list, tuple)):
        flat = []
        for v in data:
            flat.extend(custom_flatten(v))
        return tuple(flat)
    return (data,)

class TestNestedFunctions(unittest.TestCase):
    # Zip tests
    def test_zip_scalar(self):
        self.assertEqual(custom_zip(5), 5)
        self.assertEqual(custom_zip(1, 2), (1, 2))
    def test_zip_empty(self):
        self.assertEqual(custom_zip([]), [])
        self.assertEqual(custom_zip({}), {})
    def test_zip_shallow(self):
        self.assertEqual(custom_zip([1,2], [3,4]), [[1,3],[2,4]])
        self.assertEqual(custom_zip((1,2), (3,4)), ((1,3),(2,4)))
        self.assertEqual(custom_zip({'a':1,'b':2}, {'a':3,'b':4}), {'a':(1,3),'b':(2,4)})
    def test_zip_mixed(self):
        self.assertEqual(custom_zip([1,2], (3,4)), [[1,3],[2,4]])
        self.assertEqual(custom_zip({'x':1,'y':2}, (3,4)), {'x':(1,3),'y':(2,4)})
    def test_zip_namedtuple(self):
        Point = namedtuple('Point', 'x y')
        p1 = Point(1, 2)
        p2 = Point(3, 4)
        result = custom_zip(p1, p2)
        self.assertEqual(result, ((1,3),(2,4)))
    # Map tests
    def test_map_scalar(self):
        self.assertEqual(custom_map(lambda x: x*2, 3), 6)
    def test_map_empty(self):
        self.assertEqual(custom_map(lambda x: x+1, []), [])
        self.assertEqual(custom_map(lambda x: x+1, {}), {})
    def test_map_shallow(self):
        self.assertEqual(custom_map(lambda x: x+1, [1,2]), [2,3])
        self.assertEqual(custom_map(lambda x: x+1, (1,2)), (2,3))
        self.assertEqual(custom_map(lambda x: x+1, {'a':1,'b':2}), {'a':2,'b':3})
    def test_map_mixed(self):
        data = [1, (2,3), {'a':4}]
        result = custom_map(lambda x: x*2, data)
        expected = [2, (4,6), {'a':8}]
        self.assertEqual(result, expected)
    def test_map_multiple(self):
        a = [1,2]
        b = [3,4]
        result = custom_map(lambda x,y: x+y, a, b)
        self.assertEqual(result, [4,6])
        d1 = {'a':1,'b':2}
        d2 = {'a':3,'b':4}
        result = custom_map(lambda x,y: x*y, d1, d2)
        self.assertEqual(result, {'a':3,'b':8})
    def test_map_namedtuple(self):
        Pair = namedtuple('Pair', 'x y')
        p = Pair(2,5)
        result = custom_map(lambda x: x+1, p)
        self.assertEqual(result, Pair(3,6))
    # Flatten tests
    def test_flatten_scalar(self):
        self.assertEqual(custom_flatten(7), (7,))
    def test_flatten_empty(self):
        self.assertEqual(custom_flatten([]), ())
        self.assertEqual(custom_flatten({}), ())
    def test_flatten_base(self):
        self.assertEqual(custom_flatten([1,2]), (1,2))
        self.assertEqual(custom_flatten((1,2)), (1,2))
    def test_flatten_nested(self):
        data = [1, [2, (3,4)], {'a':5,'b':[6,7]}]
        result = custom_flatten(data)
        expected = (1,2,3,4,5,6,7)
        self.assertEqual(result, expected)
    def test_flatten_namedtuple(self):
        Point = namedtuple('Point', 'x y')
        p = Point(1, (2, [3]))
        result = custom_flatten(p)
        expected = (1,2,3)
        self.assertEqual(result, expected)

if __name__ == '__main__':
    unittest.main()