import pandas as pd
import matplotlib.pyplot as plt

# 1. Data Loading
df_prisoners = pd.read_csv("prisoners.csv")

print("First five rows:")
print(df_prisoners.head())
print("\nLast five rows:")
print(df_prisoners.tail())

print("\nStatistical summary:")
describe_df = df_prisoners.describe()
print(describe_df)

num_columns = describe_df.shape[1]
print(f"\nNumber of numerical columns: {num_columns}")

# 2. Data Manipulation
benefit_cols = [
    "No. of Inmates benefitted by Elementary Education",
    "No. of Inmates benefitted by Adult Education",
    "No. of Inmates benefitted by Higher Education",
    "No. of Inmates benefitted by Computer Course"
]

df_prisoners["total_benefitted"] = df_prisoners[benefit_cols].sum(axis=1)

# Create totals row
totals = {"STATE/UT": "totals", "YEAR": ""}
for col in df_prisoners.columns:
    if pd.api.types.is_numeric_dtype(df_prisoners[col]):
        totals[col] = df_prisoners[col].sum()
df_prisoners = df_prisoners.append(totals, ignore_index=True)

# 3. Plotting
# Exclude totals row for plotting
plot_df = df_prisoners[df_prisoners["STATE/UT"] != "totals"]

# Bar plot
plt.figure(figsize=(12, 6))
plt.bar(plot_df["STATE/UT"], plot_df["total_benefitted"], color='skyblue')
plt.xticks(rotation=45, ha='right')
plt.title("Total Benefitted Inmates by State/UT")
plt.ylabel("Total Benefitted")
plt.tight_layout()
plt.show()

# Pie chart
plt.figure(figsize=(8, 8))
plt.pie(
    plot_df["total_benefitted"],
    labels=plot_df["STATE/UT"],
    autopct='%1.1f%%',
    shadow=True,
    startangle=140
)
plt.title("Distribution of Total Benefitted Inmates by State/UT")
plt.axis('equal')
plt.show()