import pandas as pd
import numpy as np
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score

def main():
    # Load data
    df = pd.read_excel('outputAN.xlsx', sheet_name='Sheet2')

    # Define feature columns (all except the target)
    target_col = 'Receive_NotReceiveCredit'
    h11 = [col for col in df.columns if col != target_col]

    # Encode binary classes
    for col in ['Housing2', target_col]:
        if col in df.columns:
            df[col] = df[col].replace(2, -1)

    # Train-test split
    X = df[h11]
    y = df[target_col]
    train_x, test_x, train_y, test_y = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # Hyperparameter tuning for precision
    param_grid = {
        'kernel': ['rbf'],
        'gamma': [1e-3, 1e-4],
        'C': [1, 10, 100, 1000]
    }
    gs_precision = GridSearchCV(
        estimator=SVC(),
        param_grid=param_grid,
        scoring='precision',
        cv=5,
        n_jobs=-1
    )
    gs_precision.fit(train_x, train_y)
    print("Best params for precision:", gs_precision.best_params_)
    print("Best cross-validated precision score:", gs_precision.best_score_)

    # Hyperparameter tuning for recall
    gs_recall = GridSearchCV(
        estimator=SVC(),
        param_grid=param_grid,
        scoring='recall',
        cv=5,
        n_jobs=-1
    )
    gs_recall.fit(train_x, train_y)
    print("Best params for recall:", gs_recall.best_params_)
    print("Best cross-validated recall score:", gs_recall.best_score_)

    # Train final model with fixed parameters
    svc = SVC(
        kernel='rbf',
        gamma=10,
        class_weight='balanced',
        probability=True,
        random_state=42
    )
    svc.fit(train_x, train_y)

    # Predictions
    train_pred = svc.predict(train_x)
    test_pred = svc.predict(test_x)

    # Accuracy
    train_acc = accuracy_score(train_y, train_pred)
    test_acc = accuracy_score(test_y, test_pred)
    print(f"Training accuracy: {train_acc:.4f}")
    print(f"Test accuracy: {test_acc:.4f}")

    # Confusion matrix and classification report
    cm = confusion_matrix(test_y, test_pred)
    print("Confusion Matrix:")
    print(cm)
    report = classification_report(test_y, test_pred, zero_division=0)
    print("Classification Report:")
    print(report)

if __name__ == "__main__":
    main()