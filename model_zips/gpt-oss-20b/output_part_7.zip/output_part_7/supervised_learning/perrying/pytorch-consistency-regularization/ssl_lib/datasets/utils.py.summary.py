import os
import math
import numpy as np
import torch
from torch.utils.data import Sampler
from torchvision import datasets, transforms

class InfiniteSampler(Sampler):
    """
    Generates a reproducible, non-repeating sequence of indices for data sampling.
    The indices are formed by concatenating random permutations of the dataset
    until the desired number of samples is reached.
    """
    def __init__(self, num_data: int, num_sample: int, seed: int = 0):
        """
        Args:
            num_data (int): Number of data points in the dataset.
            num_sample (int): Total number of indices to generate.
            seed (int): Random seed for reproducibility.
        """
        self.num_data = num_data
        self.num_sample = num_sample
        self.seed = seed
        self._prepare_indices()

    def _prepare_indices(self):
        np.random.seed(self.seed)
        epochs = math.ceil(self.num_sample / self.num_data)
        all_indices = []
        for _ in range(epochs):
            perm = np.random.permutation(self.num_data)
            all_indices.append(perm)
        self.indices = np.concatenate(all_indices)[:self.num_sample].tolist()

    def __iter__(self):
        return iter(self.indices)

    def __len__(self):
        return self.num_sample

def load_svhn(root: str = "./data", split: str = "train"):
    """
    Loads the SVHN dataset and returns images and labels as numpy arrays.
    Images are converted to shape (H, W, C) and labels to integers.
    """
    dataset = datasets.SVHN(root=root, split=split, download=True)
    images = dataset.data.transpose((0, 2, 3, 1)).astype(np.float32)  # (N, H, W, C)
    labels = dataset.labels.astype(np.int32)
    return images, labels

def load_cifar(root: str = "./data", name: str = "CIFAR10", split: str = "train"):
    """
    Loads CIFAR10 or CIFAR100 dataset and returns images and labels as numpy arrays.
    Images are converted to float32 and labels to int32.
    """
    if name == "CIFAR10":
        dataset = datasets.CIFAR10(root=root, train=(split=="train"), download=True)
    elif name == "CIFAR100":
        dataset = datasets.CIFAR100(root=root, train=(split=="train"), download=True)
    else:
        raise ValueError("Unsupported CIFAR dataset: must be 'CIFAR10' or 'CIFAR100'")

    images = np.array(dataset.data).astype(np.float32)  # (N, H, W, C)
    labels = np.array(dataset.targets).astype(np.int32)
    return images, labels

def load_stl10(root: str = "./data", split: str = "train"):
    """
    Loads STL10 dataset and returns images and labels as numpy arrays.
    Images are converted to shape (H, W, C). Unlabeled split has labels as None.
    """
    dataset = datasets.STL10(root=root, split=split, download=True)
    images = np.array(dataset.images).astype(np.float32)  # (N, H, W, C)
    labels = np.array(dataset.labels).astype(np.int32) if dataset.labels is not None else None
    return images, labels

def dataset_split(images: np.ndarray, labels: np.ndarray, num_data: int,
                  random: bool = True, num_classes: int = None):
    """
    Splits the dataset into two subsets.
    If random=True, the first `num_data` samples are returned.
    If random=False, the subset is balanced across classes.
    Returns indices of the selected subset.
    """
    if random:
        return np.arange(num_data)

    if num_classes is None:
        num_classes = len(np.unique(labels))

    samples_per_class = num_data // num_classes
    selected_indices = []

    for cls in range(num_classes):
        cls_indices = np.where(labels == cls)[0]
        if len(cls_indices) < samples_per_class:
            raise ValueError(f"Not enough samples for class {cls}")
        selected_indices.extend(cls_indices[:samples_per_class])

    return np.array(selected_indices)

def get_zca_normalization_param(images: np.ndarray, eps: float = 1e-5):
    """
    Computes ZCA whitening parameters.
    Args:
        images (np.ndarray): Input images of shape (N, H, W, C).
        eps (float): Small constant for numerical stability.
    Returns:
        zca_matrix (np.ndarray): Whitening transformation matrix.
        mean (np.ndarray): Mean of the images.
    """
    N, H, W, C = images.shape
    X = images.reshape(N, -1).astype(np.float32)  # (N, D)
    mean = np.mean(X, axis=0, keepdims=True)
    X_centered = X - mean
    sigma = np.cov(X_centered, rowvar=False)  # (D, D)
    sigma += eps * np.eye(sigma.shape[0], dtype=np.float32)
    U, S, _ = np.linalg.svd(sigma, full_matrices=False)
    ZCA_mat = U @ np.diag(1.0 / np.sqrt(S)) @ U.T
    return ZCA_mat, mean.squeeze()

if __name__ == "__main__":
    # Example usage
    svhn_imgs, svhn_lbls = load_svhn(split="train")
    cifar_imgs, cifar_lbls = load_cifar(name="CIFAR10", split="train")
    stl_imgs, stl_lbls = load_stl10(split="train")

    sampler = InfiniteSampler(num_data=len(cifar_imgs), num_sample=5000, seed=42)
    for idx in sampler:
        pass  # use idx for batching

    balanced_indices = dataset_split(cifar_imgs, cifar_lbls, num_data=2000,
                                     random=False, num_classes=10)
    zca_mat, mean = get_zca_normalization_param(cifar_imgs)
    cifar_whitened = (cifar_imgs.reshape(cifar_imgs.shape[0], -1) - mean) @ zca_mat
    cifar_whitened = cifar_whitened.reshape(cifar_imgs.shape)  # (N, H, W, C)  