import os
import random
import time
import pathlib
import logging
import numpy as np
import torch
import toml
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional

# ------------------ Utility Functions ------------------

def set_seeds(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

# ------------------ Logger ------------------

class Logger(ABC):
    @abstractmethod
    def log(self, message: str) -> None:
        pass

class StdoutLogger(Logger):
    def log(self, message: str) -> None:
        print(message)

class CSVLogger(Logger):
    def __init__(self, log_dir: pathlib.Path, filename: str = "log.csv") -> None:
        self.filepath = log_dir / filename
        self.filepath.parent.mkdir(parents=True, exist_ok=True)
        if not self.filepath.exists():
            with open(self.filepath, "w") as f:
                f.write("timestamp,step,episode,reward\n")

    def log(self, message: str) -> None:
        with open(self.filepath, "a") as f:
            f.write(message + "\n")

class TensorBoardLogger(Logger):
    def __init__(self, log_dir: pathlib.Path) -> None:
        from torch.utils.tensorboard import SummaryWriter
        self.writer = SummaryWriter(log_dir)

    def log(self, message: str) -> None:
        # Placeholder: log message as scalar with step 0
        self.writer.add_text("log", message, global_step=0)

def get_logger(log_mode: str, log_dir: pathlib.Path) -> Logger:
    if log_mode == "stdout":
        return StdoutLogger()
    elif log_mode == "csv":
        return CSVLogger(log_dir)
    elif log_mode == "tensorboard":
        return TensorBoardLogger(log_dir)
    else:
        raise ValueError(f"Unsupported log mode: {log_mode}")

# ------------------ Agent Interface ------------------

class Agent(ABC):
    algorithm_name: str

    @abstractmethod
    def select_action(self, state: Any, deterministic: bool = False) -> Any:
        pass

    @abstractmethod
    def _load_weights(self, weights: Any) -> None:
        pass

# ------------------ Environment Interface ------------------

class Environment(ABC):
    @property
    @abstractmethod
    def n_envs(self) -> int:
        pass

    @abstractmethod
    def reset(self) -> Any:
        pass

    @abstractmethod
    def step(self, action: Any) -> Any:
        pass

    @abstractmethod
    def render(self) -> None:
        pass

# ------------------ Trainer ------------------

class Trainer(ABC):
    def __init__(
        self,
        agent: Agent,
        env: Environment,
        log_mode: str = "stdout",
        log_interval: int = 1000,
        log_dir: str = "logs",
        epochs: int = 1000,
        max_timesteps: int = 1_000_000,
        off_policy: bool = False,
        save_dir: str = "checkpoints",
        run_num: Optional[int] = None,
        weights_file: Optional[str] = None,
        hyperparams_file: Optional[str] = None,
        evaluate_episodes: int = 10,
        render: bool = False,
        seed: Optional[int] = None,
    ) -> None:
        self.agent = agent
        self.env = env
        self.log_mode = log_mode
        self.log_interval = log_interval
        self.log_dir = pathlib.Path(log_dir)
        self.epochs = epochs
        self.max_timesteps = max_timesteps
        self.off_policy = off_policy
        self.save_dir = pathlib.Path(save_dir)
        self.run_num = run_num
        self.weights_file = weights_file
        self.hyperparams_file = hyperparams_file
        self.evaluate_episodes = evaluate_episodes
        self.render = render

        if seed is not None:
            set_seeds(seed)

        self.logger = get_logger(self.log_mode, self.log_dir)

    @abstractmethod
    def train(self) -> None:
        raise NotImplementedError

    def evaluate(self) -> None:
        episode_rewards = []
        for episode in range(self.evaluate_episodes):
            state = self.env.reset()
            done = False
            total_reward = 0.0
            while not done:
                action = self.agent.select_action(
                    state, deterministic=self.off_policy
                )
                next_state, reward, done, info = self.env.step(action)
                total_reward += reward
                state = next_state
                if self.render:
                    self.env.render()
            episode_rewards.append(total_reward)
        mean_reward = np.mean(episode_rewards)
        std_reward = np.std(episode_rewards)
        self.logger.log(
            f"Evaluation over {self.evaluate_episodes} episodes: "
            f"mean={mean_reward:.3f}, std={std_reward:.3f}"
        )

    def save(self, current_timestep: int) -> None:
        algo = getattr(self.agent, "algorithm_name", "agent")
        env_name = getattr(self.env, "__class__", type(self.env)).__name__.lower()
        if self.run_num is None:
            existing_runs = [
                int(d.name.split("_")[-1])
                for d in self.save_dir.glob("*")
                if d.is_dir() and d.name.startswith(f"{algo}_{env_name}_run_")
            ]
            self.run_num = max(existing_runs, default=0) + 1
        run_dir = self.save_dir / f"{algo}_{env_name}_run_{self.run_num}"
        run_dir.mkdir(parents=True, exist_ok=True)

        hyperparams_path = run_dir / f"{algo}_{env_name}_run_{self.run_num}_hyperparams.toml"
        weights_path = run_dir / f"{algo}_{env_name}_run_{self.run_num}_timestep_{current_timestep}.pt"

        hyperparams = {
            "agent": {
                "algorithm_name": getattr(self.agent, "algorithm_name", None),
            },
            "env": {
                "name": env_name,
            },
            "training": {
                "epochs": self.epochs,
                "max_timesteps": self.max_timesteps,
                "off_policy": self.off_policy,
                "evaluate_episodes": self.evaluate_episodes,
                "render": self.render,
            },
            "logging": {
                "log_mode": self.log_mode,
                "log_interval": self.log_interval,
                "log_dir": str(self.log_dir),
            },
            "save": {
                "save_dir": str(self.save_dir),
                "run_num": self.run_num,
            },
        }
        with open(hyperparams_path, "w") as f:
            toml.dump(hyperparams, f)

        # Assume the agent has a `state_dict` method or equivalent
        if hasattr(self.agent, "state_dict"):
            torch.save(self.agent.state_dict(), weights_path)
        else:
            torch.save(self.agent, weights_path)

        self.logger.log(f"Saved hyperparameters to {hyperparams_path}")
        self.logger.log(f"Saved weights to {weights_path}")

    def load(
        self,
        hyperparams_path: str,
        weights_path: str,
    ) -> None:
        if not pathlib.Path(hyperparams_path).is_file():
            raise FileNotFoundError(f"Hyperparameters file not found: {hyperparams_path}")
        if not pathlib.Path(weights_path).is_file():
            raise FileNotFoundError(f"Weights file not found: {weights_path}")

        hyperparams = toml.load(hyperparams_path)
        training_cfg = hyperparams.get("training", {})
        self.epochs = training_cfg.get("epochs", self.epochs)
        self.max_timesteps = training_cfg.get("max_timesteps", self.max_timesteps)
        self.off_policy = training_cfg.get("off_policy", self.off_policy)
        self.evaluate_episodes = training_cfg.get("evaluate_episodes", self.evaluate_episodes)
        self.render = training_cfg.get("render", self.render)

        logging_cfg = hyperparams.get("logging", {})
        self.log_mode = logging_cfg.get("log_mode", self.log_mode)
        self.log_interval = logging_cfg.get("log_interval", self.log_interval)
        self.log_dir = pathlib.Path(logging_cfg.get("log_dir", self.log_dir))

        save_cfg = hyperparams.get("save", {})
        self.save_dir = pathlib.Path(save_cfg.get("save_dir", self.save_dir))
        self.run_num = save_cfg.get("run_num", self.run_num)

        if hasattr(self.agent, "_load_weights"):
            if pathlib.Path(weights_path).suffix == ".pt":
                weights = torch.load(weights_path)
                self.agent._load_weights(weights)
            else:
                # Assume weights are pickled agent object
                import pickle
                with open(weights_path, "rb") as f:
                    loaded_agent = pickle.load(f)
                self.agent = loaded_agent
        else:
            # Fall back to torch.load directly
            loaded = torch.load(weights_path)
            self.agent = loaded

        self.logger.log(f"Loaded hyperparameters from {hyperparams_path}")
        self.logger.log(f"Loaded weights from {weights_path}")

    @property
    def n_envs(self) -> int:
        return getattr(self.env, "n_envs", 1)