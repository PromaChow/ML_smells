import numpy as np
from sklearn import datasets, metrics
from sklearn.model_selection import train_test_split
from sklearn.semi_supervised import LabelPropagation

# 1. Data Loading and Normalization
X, y = datasets.load_breast_cancer(return_X_y=True)
X_min = X.min(axis=0)
X_max = X.max(axis=0)
X = (X - X_min) / (X_max - X_min)

# 2. Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.6, random_state=0, stratify=y
)

# 3. Introducing Unlabeled Data
rng = np.random.RandomState(42)
unlabeled_idx = rng.choice(
    len(X_train), size=int(0.1 * len(X_train)), replace=False
)
y_train[unlabeled_idx] = -1

# 4. Separating Labeled and Unlabeled Data
label_mask = y_train != -1
unlabel_mask = y_train == -1

label_X_train = X_train[label_mask]
label_y_train = y_train[label_mask]

unlabel_X_train = X_train[unlabel_mask]
unlabel_y = np.full(unlabel_X_train.shape[0], -1)

# 5. Model Training with Label Propagation
model = LabelPropagation(
    gamma=50, n_neighbors=2, max_iter=500, kernel='rbf'
)
combined_X = np.vstack((label_X_train, unlabel_X_train))
combined_y = np.append(label_y_train, unlabel_y)
model.fit(combined_X, combined_y)

# 6. Prediction and Evaluation
y_pred = model.predict(X_test)
accuracy = metrics.accuracy_score(y_test, y_pred)
print(f"label propagation accuracy: {accuracy}")