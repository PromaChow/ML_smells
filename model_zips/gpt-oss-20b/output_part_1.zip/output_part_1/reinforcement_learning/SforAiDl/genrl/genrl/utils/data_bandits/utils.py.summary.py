import os
import pathlib
import urllib.request
import urllib.error
import gzip
import shutil
import pandas as pd


def download_data(url: str, path: str, filename: str | None = None, force: bool = False) -> pathlib.Path:
    """
    Download data from a URL into the specified directory.

    Parameters
    ----------
    url : str
        The URL to download.
    path : str
        Directory where the file should be stored.
    filename : str, optional
        Desired filename. If None, extract from URL.
    force : bool, default False
        If True, re-download even if file exists.

    Returns
    -------
    pathlib.Path
        Path to the downloaded (or existing) file.
    """
    target_dir = pathlib.Path(path)
    target_dir.mkdir(parents=True, exist_ok=True)

    if not filename:
        filename = pathlib.Path(url).name
    fpath = target_dir / filename

    if fpath.exists() and not force:
        return fpath

    try_data_download(url, fpath)
    return fpath


def try_data_download(url: str, fpath: pathlib.Path) -> None:
    """
    Attempt to download a file, retrying with http if https fails.

    Parameters
    ----------
    url : str
        URL to download.
    fpath : pathlib.Path
        Destination file path.
    """
    try:
        urllib.request.urlretrieve(url, str(fpath))
    except urllib.error.URLError as e:
        if url.startswith("https:") and "http:" not in url:
            alt_url = url.replace("https:", "http:")
            try:
                urllib.request.urlretrieve(alt_url, str(fpath))
            except urllib.error.URLError:
                raise e
        else:
            raise e


def fetch_data_without_header(
    path: str,
    fname: str,
    delimiter: str = ",",
    na_values: str | list[str] | None = None,
) -> pd.DataFrame:
    """
    Read a CSV file without a header row and drop rows with missing values.

    Parameters
    ----------
    path : str
        File path or directory containing the file.
    fname : str
        Filename if path is a directory.
    delimiter : str, default ","
        Field delimiter.
    na_values : str or list[str], optional
        Values to consider as NA.

    Returns
    -------
    pd.DataFrame
        Cleaned DataFrame.
    """
    file_path = pathlib.Path(path)
    if file_path.is_dir():
        file_path = file_path / fname

    df = pd.read_csv(
        file_path,
        header=None,
        delimiter=delimiter,
        na_values=na_values,
        dtype=str,
    )
    return df.dropna()


def fetch_data_with_header(
    path: str,
    fname: str,
    delimiter: str = ",",
    na_values: str | list[str] | None = None,
) -> pd.DataFrame:
    """
    Read a CSV file with a header row and drop rows with missing values.

    Parameters
    ----------
    path : str
        File path or directory containing the file.
    fname : str
        Filename if path is a directory.
    delimiter : str, default ","
        Field delimiter.
    na_values : str or list[str], optional
        Values to consider as NA.

    Returns
    -------
    pd.DataFrame
        Cleaned DataFrame.
    """
    file_path = pathlib.Path(path)
    if file_path.is_dir():
        file_path = file_path / fname

    df = pd.read_csv(
        file_path,
        delimiter=delimiter,
        na_values=na_values,
        dtype=str,
    )
    return df.dropna()


def fetch_zipped_data_without_header(
    gz_fpath: str,
    delimiter: str = ",",
    na_values: str | list[str] | None = None,
) -> pd.DataFrame:
    """
    Extract a gzip file, read its CSV content without a header, and clean it.

    Parameters
    ----------
    gz_fpath : str
        Path to the gzip file.
    delimiter : str, default ","
        Field delimiter.
    na_values : str or list[str], optional
        Values to consider as NA.

    Returns
    -------
    pd.DataFrame
        Cleaned DataFrame.
    """
    gz_path = pathlib.Path(gz_fpath)
    if not gz_path.is_file():
        raise FileNotFoundError(f"Gzip file not found: {gz_fpath}")

    temp_file = gz_path.parent / "covtype.data"

    with gzip.open(gz_path, "rb") as gz_file, open(temp_file, "wb") as out_file:
        shutil.copyfileobj(gz_file, out_file)

    df = pd.read_csv(
        temp_file,
        header=None,
        delimiter=delimiter,
        na_values=na_values,
        dtype=str,
    )
    df_clean = df.dropna()
    temp_file.unlink()
    return df_clean
