import unittest
import numpy as np
import chainer
import chainer.cuda
import chainer.testing
import chainer.backends.cuda as cuda
from chainer import Variable
from empirical_normalization import EmpiricalNormalization


class TestEmpiricalNormalization(unittest.TestCase):
    def _test_small(self, gpu=-1):
        xp = np if gpu < 0 else cuda.get_array_module()
        en = EmpiricalNormalization(n_input=10)
        if gpu >= 0:
            with chainer.cuda.get_device_from_id(gpu).use():
                en.to_gpu()
        all_data = []
        for t in range(10):
            batch_size = t + 3
            data = np.random.randn(batch_size, 10).astype(np.float32)
            if gpu >= 0:
                data = xp.asarray(data)
            y = en(data)
            all_data.append(data)
        all_data = np.concatenate(all_data, axis=0)
        mean_true = all_data.mean(axis=0)
        std_true = all_data.std(axis=0, ddof=0)
        mean_est = en.mean.array
        std_est = en.std.array
        xp.testing.assert_allclose(mean_est, mean_true, rtol=1e-4, atol=0)
        xp.testing.assert_allclose(std_est, std_true, rtol=1e-4, atol=0)

    def test_small_cpu(self):
        self._test_small(gpu=-1)

    @unittest.skipIf(not cuda.available, "CUDA not available")
    def test_small_gpu(self):
        self._test_small(gpu=0)

    def test_large(self):
        en = EmpiricalNormalization(n_input=10)
        mean_true = 4.0
        std_true = 2.0
        for _ in range(10000):
            x = mean_true + std_true * np.random.randn(7, 10).astype(np.float32)
            en(x)
        x = mean_true + std_true * np.random.randn(7, 10).astype(np.float32)
        y = en(x, update=False)
        np.testing.assert_allclose(y, (x - mean_true) / std_true, rtol=1e-1, atol=0)
        x_back = en.inverse(y)
        np.testing.assert_allclose(x_back, x, rtol=1e-4, atol=0)

    def test_batch_axis(self):
        shape = (2, 3, 4)
        for batch_axis in (0, 1, 2):
            en = EmpiricalNormalization(n_input=shape[-1], batch_axis=batch_axis)
            for _ in range(10):
                data = np.random.randn(*shape).astype(np.float32)
                en(data)

    def test_until(self):
        en = EmpiricalNormalization(n_input=10, until=10)
        mean_before = None
        std_before = None
        for i in range(15):
            x = np.random.randn(5, 10).astype(np.float32)
            en(x)
            mean_now = en.mean.array.copy()
            std_now = en.std.array.copy()
            if i < 10:
                mean_before = mean_now
                std_before = std_now
            else:
                np.testing.assert_allclose(mean_now, mean_before, rtol=1e-4, atol=0)
                np.testing.assert_allclose(std_now, std_before, rtol=1e-4, atol=0)

    def test_mixed_inputs(self):
        en = EmpiricalNormalization(n_input=10)
        for _ in range(5):
            data_np = np.random.randn(5, 10).astype(np.float32)
            data_var = Variable(data_np)
            out_np = en(data_np)
            out_var = en(data_var)
            self.assertIsInstance(out_np, np.ndarray)
            self.assertIsInstance(out_var, Variable)


if __name__ == "__main__":
    unittest.main()
