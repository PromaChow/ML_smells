import nose
import numpy as np
import unittest

from ple import PLE
from ple.games.doom import Doom


class NaiveAgent:
    def __init__(self, action_set):
        self.action_set = action_set

    def pickAction(self):
        return np.random.randint(len(self.action_set))


class MyTestCase(unittest.TestCase):
    def run_a_game(self, game):
        env = PLE(game, fps=30, display_screen=False)
        env.init()
        noop_action = game.getActionSet()[0]
        env.act(noop_action)

        agent = NaiveAgent(game.getActionSet())

        for _ in range(50):
            _ = env.getScreenRGB()
            action = agent.pickAction()
            env.act(action)
            _ = env.getReward()

    def test_doom(self):
        game = Doom()
        self.run_a_game(game)


if __name__ == "__main__":
    nose.runmodule()
