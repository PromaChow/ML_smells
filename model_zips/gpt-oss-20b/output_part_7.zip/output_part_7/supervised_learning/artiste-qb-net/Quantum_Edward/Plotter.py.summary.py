import numpy as np
import matplotlib.pyplot as plt


class Plotter:
    @staticmethod
    def plot_conc_traces(fin_t, conc_nt_2_len1, delta_conc_nt_2_len1):
        """
        Visualize concentration and delta concentration traces.

        Parameters
        ----------
        fin_t : int
            Final time index to plot (must be <= nt - 1).
        conc_nt_2_len1 : ndarray
            Array of concentrations with shape (nt, 2, len1).
        delta_conc_nt_2_len1 : ndarray
            Array of concentration changes with shape (nt, 2, len1).
        """
        nt, _, len1 = conc_nt_2_len1.shape
        assert fin_t <= nt - 1, f"fin_t ({fin_t}) must be <= nt - 1 ({nt - 1})"

        t = np.arange(nt)

        fig, ax = plt.subplots(nrows=2, ncols=2, sharex=True, figsize=(10, 6))
        # Top row: concentrations
        for k in range(len1):
            for y in range(2):
                ax[0, y].plot(t[: fin_t + 1], conc_nt_2_len1[: fin_t + 1, y, k], label=f"layer {k}")
        # Bottom row: delta concentrations
        for k in range(len1):
            for y in range(2):
                ax[1, y].plot(t[: fin_t + 1], delta_conc_nt_2_len1[: fin_t + 1, y, k], label=f"layer {k}")

        # Labels
        ax[0, 0].set_ylabel("conc0")
        ax[0, 1].set_ylabel("conc1")
        ax[1, 0].set_ylabel("delta_conc0")
        ax[1, 1].set_ylabel("delta_conc1")

        # Legends
        for row in range(2):
            for col in range(2):
                ax[row, col].legend(loc="upper right", fontsize="small")

        plt.tight_layout()
        plt.show()

    @staticmethod
    def plot_elbo_traces(fin_t, elbo_nt_len1):
        """
        Visualize ELBO traces.

        Parameters
        ----------
        fin_t : int
            Final time index to plot (must be <= nt - 1).
        elbo_nt_len1 : ndarray
            Array of ELBO values with shape (nt, len1).
        """
        nt, len1 = elbo_nt_len1.shape
        assert fin_t <= nt - 1, f"fin_t ({fin_t}) must be <= nt - 1 ({nt - 1})"

        t = np.arange(nt)

        plt.figure(figsize=(8, 4))
        for k in range(len1):
            plt.plot(t[: fin_t + 1], elbo_nt_len1[: fin_t + 1, k], label=f"layer {k}")
        plt.xlabel("t")
        plt.ylabel("ELBO")
        plt.legend(loc="upper right", fontsize="small")
        plt.tight_layout()
        plt.show()