import numpy as np
from tensorboardX import SummaryWriter

class TensorBoard:
    writer = None

    def __init__(self):
        self.writer = None

    def init(self, *writer_args):
        if self.writer is None:
            self.writer = SummaryWriter(*writer_args)
        else:
            raise RuntimeError("TensorBoard has already been initialized.")

    def is_inited(self):
        return self.writer is not None

default_board = TensorBoard()