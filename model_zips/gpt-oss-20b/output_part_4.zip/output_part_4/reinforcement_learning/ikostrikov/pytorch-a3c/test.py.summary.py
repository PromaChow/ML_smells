import random
import time
from collections import deque

import numpy as np
import torch

# Assume these are defined elsewhere
from some_module import create_atari_env, ActorCritic


def test_agent(args, shared_model, rank):
    """
    Test an actor-critic agent on an Atari environment.

    Parameters
    ----------
    args : argparse.Namespace
        Contains configuration such as `seed`, `env_name`, and `max_episode_length`.
    shared_model : torch.nn.Module
        The globally shared actor‑critic model.
    rank : int
        Process rank used for seeding.
    """
    # 1. Initialization
    seed = args.seed + rank
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.backends.cudnn.deterministic = True

    env = create_atari_env(args.env_name)
    env.seed(seed)

    device = torch.device("cpu")
    model = ActorCritic(env.observation_space, env.action_space).to(device)
    model.eval()

    # 2. Environment Reset
    state_np = env.reset()
    state = torch.from_numpy(state_np).float().unsqueeze(0).to(device)

    reward_sum = 0.0
    done = False
    start_time = time.time()
    actions = deque(maxlen=100)
    episode_length = 0

    # 3. Main Loop
    while True:
        episode_length += 1

        if done:
            # Episode finished: sync with shared model and reset hidden states
            model.load_state_dict(shared_model.state_dict())
            # Assume the model uses an LSTM with hidden size `hidden_size`
            hx = torch.zeros(1, 1, model.hidden_size, device=device)
            cx = torch.zeros(1, 1, model.hidden_size, device=device)
        else:
            # Detach hidden states to avoid gradient tracking
            hx = hx.detach()
            cx = cx.detach()

        # Action selection
        value, logit, (hx, cx) = model(state, hx, cx)
        probs = torch.softmax(logit, dim=-1)
        action = probs.argmax().item()

        # Environment step
        next_state_np, reward, done_flag, info = env.step(action)
        done = done_flag or (episode_length >= args.max_episode_length)
        reward_sum += reward

        # Stuck detection
        actions.append(action)
        if len(actions) == actions.maxlen and all(a == actions[0] for a in actions):
            done = True

        if done:
            elapsed = time.time() - start_time
            fps = episode_length / elapsed if elapsed > 0 else float("inf")
            print(
                f"Time: {elapsed:.2f}s | Steps: {episode_length} | FPS: {fps:.2f} | "
                f"Reward: {reward_sum:.2f} | Episode Length: {episode_length}"
            )
            # Reset statistics for next episode
            reward_sum = 0.0
            episode_length = 0
            actions.clear()
            state_np = env.reset()
            state = torch.from_numpy(state_np).float().unsqueeze(0).to(device)
            time.sleep(60)
        else:
            state = torch.from_numpy(next_state_np).float().unsqueeze(0).to(device)