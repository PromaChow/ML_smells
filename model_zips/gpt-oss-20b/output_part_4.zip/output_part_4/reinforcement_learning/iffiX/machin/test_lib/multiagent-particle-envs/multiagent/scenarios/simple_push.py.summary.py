import numpy as np
import random
from dataclasses import dataclass, field

@dataclass
class Agent:
    name: str
    adversary: bool = False
    collidable: bool = True
    silent: bool = False
    color: np.ndarray = field(default_factory=lambda: np.zeros(3))
    pos: np.ndarray = field(default_factory=lambda: np.zeros(2))
    vel: np.ndarray = field(default_factory=lambda: np.zeros(2))
    comm: np.ndarray = field(default_factory=lambda: np.zeros(2))
    goal: 'Landmark' = None

@dataclass
class Landmark:
    name: str
    collidable: bool = False
    color: np.ndarray = field(default_factory=lambda: np.zeros(3))
    pos: np.ndarray = field(default_factory=lambda: np.zeros(2))

@dataclass
class World:
    dim_pos: int = 2
    dim_vel: int = 2
    dim_comm: int = 2
    agents: list[Agent] = field(default_factory=list)
    landmarks: list[Landmark] = field(default_factory=list)

def reset_world(world: World):
    # Randomize landmark colors and positions
    for idx, lm in enumerate(world.landmarks):
        intensity = idx / max(1, len(world.landmarks)-1)
        lm.color = np.array([0.0, intensity, 0.0])
        lm.pos = np.random.uniform(-1, 1, world.dim_pos)
    # Select goal landmark
    goal_lm = random.choice(world.landmarks)
    # Assign colors and goals to agents
    for ag in world.agents:
        ag.goal = goal_lm
        if ag.adversary:
            ag.color = np.array([1.0, 0.0, 0.0])
        else:
            intensity = goal_lm.pos[1]  # use goal's y for color variation
            ag.color = np.array([intensity, 0.0, 0.0])
        # Randomize positions, velocities, comm
        ag.pos = np.random.uniform(-1, 1, world.dim_pos)
        ag.vel = np.zeros(world.dim_vel)
        ag.comm = np.zeros(world.dim_comm)

def get_reward(world: World, agent: Agent):
    if agent.adversary:
        non_adv_dists = [np.linalg.norm(na.pos - agent.goal.pos) for na in world.agents if not na.adversary]
        pos_rew = min(non_adv_dists) if non_adv_dists else 0.0
        neg_rew = np.linalg.norm(agent.pos - agent.goal.pos)
        return pos_rew - neg_rew
    else:
        return -np.linalg.norm(agent.pos - agent.goal.pos)

def get_observation(world: World, agent: Agent):
    obs = []
    # Landmark relative positions
    for lm in world.landmarks:
        obs.extend(lm.pos - agent.pos)
    # Landmark colors
    for lm in world.landmarks:
        obs.extend(lm.color)
    # Other agents relative positions and comm
    for other in world.agents:
        if other is not agent:
            obs.extend(other.pos - agent.pos)
            obs.extend(other.comm)
    if not agent.adversary:
        obs.extend(agent.vel)
        obs.extend(agent.goal.pos - agent.pos)
        obs.extend(agent.color)
    return np.array(obs)

def step(world: World, actions: dict[Agent, np.ndarray]):
    for agent, action in actions.items():
        agent.vel = action
        agent.pos += agent.vel
        agent.comm = np.random.uniform(-1, 1, world.dim_comm)

def main():
    world = World()
    # Create agents
    world.agents.append(Agent(name='adv', adversary=True, collidable=True, silent=True))
    world.agents.append(Agent(name='na', adversary=False, collidable=True, silent=True))
    # Create landmarks
    world.landmarks.append(Landmark(name='lm1'))
    world.landmarks.append(Landmark(name='lm2'))
    reset_world(world)
    # Example single step
    actions = {ag: np.array([0.1, 0.0]) for ag in world.agents}
    step(world, actions)
    # Compute observations and rewards
    for ag in world.agents:
        obs = get_observation(world, ag)
        rew = get_reward(world, ag)
        print(f'{ag.name}: obs shape={obs.shape}, reward={rew:.3f}')

if __name__ == "__main__":
    main()