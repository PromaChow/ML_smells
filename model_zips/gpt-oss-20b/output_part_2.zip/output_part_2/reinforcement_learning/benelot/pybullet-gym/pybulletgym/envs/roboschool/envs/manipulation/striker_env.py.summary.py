import numpy as np
import pybullet as p

# The following imports are placeholders for the actual modules that provide the
# required base classes and robot implementations.
try:
    from base_env import BaseBulletEnv
    from robots.striker import Striker
    from scenes.single_robot_empty import SingleRobotEmptyScene
except ImportError:
    BaseBulletEnv = object
    Striker = object
    SingleRobotEmptyScene = object


class StrikerBulletEnv(BaseBulletEnv):
    def __init__(self, **kwargs):
        # Initialize the Striker robot and call the base class constructor
        self.striker = Striker()
        super().__init__(robot=self.striker, **kwargs)

        # Internal state variables
        self._striked = False
        self._min_strike_dist = np.inf
        self.strike_threshold = 0.1
        self.strike_pos = None

    def create_single_player_scene(self):
        # Construct the physics simulation environment
        self.scene = SingleRobotEmptyScene(
            gravity=9.81,
            timestep=0.0020,
            frame_skip=5
        )

    def step(self, action):
        # Apply the action to the robot
        self.striker.apply_action(action)

        # Advance the simulation
        self.scene.global_step()

        # Retrieve robot state information
        state = self.striker.calc_state()
        to_target_vec = state['to_target_vec']

        # Potential calculation
        potential = -100.0 * np.linalg.norm(to_target_vec)

        # Electricity cost based on action magnitude and joint velocities
        joint_vels = self.striker.joint_velocities
        electricity_cost = np.sum(np.abs(action) * np.abs(joint_vels))

        # Stalling penalty when action magnitudes are very small
        stall_penalty = 0.0
        if np.all(np.abs(action) < 1e-3):
            stall_penalty = 10.0

        # Stuck joint penalty when joints deviate significantly from targets
        stuck_joint_penalty = 0.0
        joint_pos = self.striker.joint_positions
        joint_target = self.striker.joint_targets
        if np.any(np.abs(joint_pos - joint_target) > 0.05):
            stuck_joint_penalty = 5.0

        # Distance calculations
        object_pos = state['object_pos']
        target_pos = state['target_pos']
        obj_target_dist = np.linalg.norm(object_pos - target_pos)

        if obj_target_dist < self._min_strike_dist:
            self._min_strike_dist = obj_target_dist

        # Strike detection
        fingertip_pos = state['end_effector_pos']
        dist_obj_fingertip = np.linalg.norm(object_pos - fingertip_pos)

        if dist_obj_fingertip < self.strike_threshold and not self._striked:
            self._striked = True
            self.strike_pos = fingertip_pos.copy()

        # Reward components
        reward_dist = -self._min_strike_dist
        reward_ctrl = -np.sum(action**2)

        if self._striked:
            reward_near = -np.linalg.norm(object_pos - self.strike_pos)
        else:
            reward_near = -dist_obj_fingertip

        reward_components = [
            potential,
            -electricity_cost,
            -stall_penalty,
            -stuck_joint_penalty,
            reward_dist,
            reward_ctrl,
            reward_near
        ]

        reward_total = sum(reward_components)

        # Update HUD and return
        self.HUD(state, action, reward_components)
        return state, reward_total, False, {}

    def HUD(self, state, action, reward_components):
        """Simple HUD that prints key metrics."""
        print(f"State: {state}")
        print(f"Action: {action}")
        print(f"Rewards: {reward_components}")

    def camera_adjust(self):
        """Position the camera relative to the robot's fingertip."""
        fingertip_pos = self.striker.calc_state()['end_effector_pos']
        camera_pos = fingertip_pos + np.array([0.0, 0.0, 1.0])
        p.resetDebugVisualizerCamera(
            cameraDistance=1.5,
            cameraYaw=45,
            cameraPitch=-30,
            cameraTargetPosition=camera_pos
        )