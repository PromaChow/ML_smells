import os
import pickle
import numpy as np
from dataclasses import dataclass, field
import gymnasium as gym
from lagom import (
    Agent,
    Engine,
    StepRunner,
    RecordEpisodeStatistics,
    NormalizeObservation,
    NormalizeReward,
    TimeStepEnv,
    set_global_seeds,
)
from lagom.experiment import run_experiment


@dataclass
class TrainingConfig:
    total_timesteps: int = int(1e6)
    batch_size: int = 64
    epochs_per_iter: int = 10
    timestep_per_iter: int = 2048


@dataclass
class EnvConfig:
    env_ids: list = field(default_factory=lambda: ["HalfCheetah-v3", "Hopper-v3", "Walker2d-v3", "Swimmer-v3"])
    obs_clip: float = 5.0
    rew_clip: float = 10.0
    rew_gamma: float = 0.99


@dataclass
class NetworkConfig:
    hidden_sizes: list = field(default_factory=lambda: [64, 64])


@dataclass
class PPOConfig:
    policy_lr: float = 3e-4
    value_lr: float = 1e-3
    gamma: float = 0.99
    gae_lambda: float = 0.95
    adv_std: bool = True
    clip_grad_norm: float = 0.5
    action_clip: bool = True


@dataclass
class LogConfig:
    freq: int = 10
    log_dir: str = "logs/default"


@dataclass
class CheckpointConfig:
    num: int = 3
    save_dir: str = "logs/default/checkpoints"


@dataclass
class Config:
    train: TrainingConfig = TrainingConfig()
    env: EnvConfig = EnvConfig()
    network: NetworkConfig = NetworkConfig()
    ppo: PPOConfig = PPOConfig()
    log: LogConfig = LogConfig()
    checkpoint: CheckpointConfig = CheckpointConfig()


def make_env(seed: int, training: bool = True) -> gym.Env:
    env = gym.make("HalfCheetah-v3")
    set_global_seeds(seed)
    env.seed(seed)
    if training:
        env = RecordEpisodeStatistics(env, window_size=100)
        env = NormalizeObservation(env, clip=config.env.obs_clip)
        env = NormalizeReward(env, clip=config.env.rew_clip, gamma=config.env.rew_gamma)
    env = TimeStepEnv(env)
    return env


def run():
    cfg = config
    env_ids = cfg.env.env_ids
    env_factory = lambda _: make_env(_, training=True)
    agent = Agent(
        cfg,
        env_factory,
        env_ids=env_ids,
        num_envs=cfg.train.batch_size,
    )
    runner = StepRunner(agent)
    engine = Engine(agent, runner)

    logs = []
    checkpoints_needed = cfg.checkpoint.num
    next_checkpoint = cfg.train.total_timesteps // checkpoints_needed
    while agent.timestep < cfg.train.total_timesteps:
        steps = min(cfg.train.timestep_per_iter, cfg.train.total_timesteps - agent.timestep)
        engine.train(steps)
        if agent.timestep % cfg.log.freq == 0:
            stats = agent.get_train_stats()
            logs.append({"step": agent.timestep, "stats": stats})
        if agent.timestep >= next_checkpoint:
            checkpoint_path = os.path.join(cfg.checkpoint.save_dir, f"ckpt_{agent.timestep}.pt")
            os.makedirs(os.path.dirname(checkpoint_path), exist_ok=True)
            agent.save_checkpoint(checkpoint_path)
            checkpoints_needed -= 1
            if checkpoints_needed > 0:
                next_checkpoint = cfg.train.total_timesteps * (checkpoints_needed) // cfg.checkpoint.num

    log_path = os.path.join(cfg.log.log_dir, "train_logs.pkl")
    os.makedirs(cfg.log.log_dir, exist_ok=True)
    with open(log_path, "wb") as f:
        pickle.dump(logs, f)


config = Config()

if __name__ == "__main__":
    seeds = [1770966829, 1500925526, 2054191100]
    run_experiment(
        run,
        experiment_name="ppo_lagom",
        log_dir=config.log.log_dir,
        use_gpu=False,
        max_workers=os.cpu_count(),
        seed_list=seeds,
    )