import os
import torch
import torch.nn.functional as F
from typing import Dict, Any, Tuple

# Placeholder registries – these should be populated elsewhere in the codebase.
agent_REGISTRY = {}
action_REGISTRY = {}

class BasicMAC:
    def __init__(self, scheme: Dict[str, Any], groups: Dict[str, Any], args: Any) -> None:
        self.args = args
        self.n_agents = args.n_agents
        self.n_actions = args.n_actions
        self.batch_size = None

        # Compute input shape
        input_shape = scheme["obs"]["vshape"]
        if args.obs_last_action:
            input_shape += self.n_actions
        if args.obs_agent_id:
            input_shape += self.n_agents

        # Create agent
        agent_class = agent_REGISTRY[args.agent]
        self.agent = agent_class(input_shape, args)

        # Create action selector
        action_selector_class = action_REGISTRY[args.action_selector]
        self.action_selector = action_selector_class(args)

        self.hidden = None

    def init_hidden(self, batch_size: int) -> None:
        self.batch_size = batch_size
        self.hidden = self.agent.init_hidden(batch_size)

    def select_actions(self, batch: Dict[str, Any], t: int, test_mode: bool = False) -> torch.Tensor:
        avail_actions = batch["avail_actions"][t]
        logits = self.forward(batch, t, test_mode)
        actions = self.action_selector.select_actions(logits, avail_actions, test_mode)
        return actions

    def forward(self, batch: Dict[str, Any], t: int, test_mode: bool = False) -> torch.Tensor:
        obs = batch["obs"][t]  # shape: [batch, agents, obs_dim]
        inputs = [obs]

        if self.args.obs_last_action:
            last_actions = batch["last_actions"][t]  # shape: [batch, agents]
            last_actions_onehot = F.one_hot(last_actions, num_classes=self.n_actions).float()
            inputs.append(last_actions_onehot)

        if self.args.obs_agent_id:
            agent_ids = torch.arange(self.n_agents, device=obs.device).unsqueeze(0).repeat(self.batch_size, 1)
            agent_ids_onehot = F.one_hot(agent_ids, num_classes=self.n_agents).float()
            inputs.append(agent_ids_onehot)

        agent_inputs = torch.cat(inputs, dim=-1)
        agent_inputs = agent_inputs.view(-1, agent_inputs.size(-1))  # shape: [batch*agents, input_dim]

        outputs = self.agent.forward(agent_inputs, self.hidden)
        self.hidden = outputs.get("hidden", self.hidden)

        logits = outputs["pi_logits"]  # shape: [batch*agents, n_actions]
        avail = batch["avail_actions"][t].view(-1, self.n_actions)  # shape: [batch*agents, n_actions]

        if self.args.mask_before_softmax:
            logits = logits.masked_fill(avail == 0, -1e10)

        probs = F.softmax(logits, dim=-1)

        if not test_mode:
            eps = self.args.exploration_eps
            uniform = torch.zeros_like(probs)
            available_counts = avail.sum(dim=-1, keepdim=True).clamp_min(1)
            uniform = avail.float() / available_counts.float()
            probs = (1 - eps) * probs + eps * uniform

        if self.args.mask_before_softmax:
            probs = probs * avail.float()

        return probs

    def parameters(self):
        return self.agent.parameters()

    def load_state(self, other_mac: "BasicMAC") -> None:
        self.agent.load_state_dict(other_mac.agent.state_dict())
        self.action_selector.load_state_dict(other_mac.action_selector.state_dict())

    def cuda(self) -> None:
        self.agent.cuda()
        self.action_selector.cuda()

    def save_models(self, path: str) -> None:
        os.makedirs(path, exist_ok=True)
        torch.save(self.agent.state_dict(), os.path.join(path, "agent.pt"))
        torch.save(self.action_selector.state_dict(), os.path.join(path, "action_selector.pt"))

    def load_models(self, path: str) -> None:
        self.agent.load_state_dict(torch.load(os.path.join(path, "agent.pt")))
        self.action_selector.load_state_dict(torch.load(os.path.join(path, "action_selector.pt")))