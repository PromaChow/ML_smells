import random
import torch
from typing import Tuple


class TimeShift:
    def __init__(self, shift_factor: Tuple[int, int] = (30, 50), p: float = 0.5):
        self.shift_factor = shift_factor
        self.p = p

    def __call__(self, wav: torch.Tensor) -> torch.Tensor:
        if random.random() >= self.p:
            return wav

        length = wav.size(1)
        shift_min = int(self.shift_factor[0] / 100 * length)
        shift_max = int(self.shift_factor[1] / 100 * length)
        shift = random.randint(shift_min, shift_max)

        return torch.roll(wav, shifts=shift, dims=1)


if __name__ == "__main__":
    wav = torch.randn(1, 16000)
    transform = TimeShift()
    shifted_wav = transform(wav)
    print(shifted_wav.shape)