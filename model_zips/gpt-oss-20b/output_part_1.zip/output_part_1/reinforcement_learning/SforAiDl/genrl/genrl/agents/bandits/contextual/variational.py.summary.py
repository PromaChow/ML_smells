import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader


class DataBasedBandit:
    def __init__(self, n_actions, context_dim, seed=0):
        self.n_actions = n_actions
        self.context_dim = context_dim
        rng = np.random.default_rng(seed)
        self.weights = rng.standard_normal((n_actions, context_dim))
        self.bias = rng.standard_normal(n_actions)
        self.noise_std = 0.1

    def get_num_actions(self):
        return self.n_actions

    def get_context_dim(self):
        return self.context_dim

    def step(self, context, action):
        reward = (
            np.dot(self.weights[action], context) + self.bias[action]
            + np.random.normal(scale=self.noise_std)
        )
        return reward


class BayesianNNBanditModel(nn.Module):
    def __init__(
        self,
        input_dim,
        output_dim,
        hidden_dims,
        lr,
        dropout_prob,
        clip_grad,
        device,
    ):
        super().__init__()
        layers = []
        dims = [input_dim] + hidden_dims
        for i in range(len(dims) - 1):
            layers.append(nn.Linear(dims[i], dims[i + 1]))
            layers.append(nn.ReLU())
            if dropout_prob > 0:
                layers.append(nn.Dropout(dropout_prob))
        layers.append(nn.Linear(dims[-1], output_dim))
        self.net = nn.Sequential(*layers)
        self.optimizer = optim.Adam(self.parameters(), lr=lr)
        self.clip_grad = clip_grad
        self.device = device
        self.to(device)

    def forward(self, x):
        return self.net(x)

    def train_step(self, batch_inputs, batch_targets):
        self.train()
        self.optimizer.zero_grad()
        outputs = self(batch_inputs)
        loss = nn.functional.mse_loss(outputs.squeeze(), batch_targets)
        loss.backward()
        if self.clip_grad is not None:
            nn.utils.clip_grad_norm_(self.parameters(), self.clip_grad)
        self.optimizer.step()
        return loss.item()

    def predict(self, x, eval_with_dropout=False):
        if eval_with_dropout:
            self.train()
        else:
            self.eval()
        with torch.no_grad():
            preds = self(x)
        return preds.squeeze()


class TransitionDB:
    def __init__(self):
        self.contexts = []
        self.actions = []
        self.rewards = []

    def add(self, context, action, reward):
        self.contexts.append(context)
        self.actions.append(action)
        self.rewards.append(reward)

    def get_dataset(self):
        inputs = torch.tensor(
            np.column_stack([self.contexts, self.actions]), dtype=torch.float32
        )
        targets = torch.tensor(self.rewards, dtype=torch.float32)
        return inputs, targets

    def clear(self):
        self.contexts.clear()
        self.actions.clear()
        self.rewards.clear()


class VariationalAgent:
    def __init__(
        self,
        bandit,
        init_pulls=3,
        hidden_dims=[32, 32],
        lr=1e-3,
        dropout_prob=0.1,
        clip_grad=5.0,
        noise_std=0.1,
        train_epochs=5,
        batch_size=64,
        decay_lr=False,
        reset_lr=False,
        eval_with_dropout=False,
        device="cpu",
    ):
        self.bandit = bandit
        self.init_pulls = init_pulls
        self.n_actions = bandit.get_num_actions()
        self.context_dim = bandit.get_context_dim()
        self.device = torch.device(device)
        self.train_epochs = train_epochs
        self.batch_size = batch_size
        self.eval_with_dropout = eval_with_dropout

        self.model = BayesianNNBanditModel(
            input_dim=self.context_dim + 1,
            output_dim=1,
            hidden_dims=hidden_dims,
            lr=lr,
            dropout_prob=dropout_prob,
            clip_grad=clip_grad,
            device=self.device,
        )

        self.transition_db = TransitionDB()
        self.total_steps = 0
        self.lr_scheduler = None
        if decay_lr:
            self.lr_scheduler = optim.lr_scheduler.StepLR(
                self.model.optimizer, step_size=10, gamma=0.5
            )
        self.reset_lr = reset_lr

    def select_action(self, context):
        context_np = np.array(context, dtype=np.float32)
        if self.total_steps < self.init_pulls * self.n_actions:
            action = self.total_steps % self.n_actions
        else:
            context_tensor = torch.tensor(context_np, dtype=torch.float32, device=self.device)
            preds = []
            for a in range(self.n_actions):
                input_vec = torch.cat(
                    [context_tensor, torch.tensor([a], dtype=torch.float32, device=self.device)]
                )
                pred = self.model.predict(
                    input_vec.unsqueeze(0), eval_with_dropout=self.eval_with_dropout
                )
                preds.append(pred.item())
            action = int(np.argmax(preds))
        return action

    def store_transition(self, context, action, reward):
        self.transition_db.add(context, action, reward)
        self.total_steps += 1

    def train(self):
        inputs, targets = self.transition_db.get_dataset()
        dataset = TensorDataset(inputs, targets)
        loader = DataLoader(dataset, batch_size=self.batch_size, shuffle=True)
        for _ in range(self.train_epochs):
            for batch_x, batch_y in loader:
                batch_x = batch_x.to(self.device)
                batch_y = batch_y.to(self.device)
                self.model.train_step(batch_x, batch_y)
        if self.lr_scheduler:
            self.lr_scheduler.step()
        if self.reset_lr:
            for pg in self.model.optimizer.param_groups:
                pg["lr"] = self.model.optimizer.defaults["lr"]
        self.transition_db.clear()

    def step(self, context):
        action = self.select_action(context)
        reward = self.bandit.step(context, action)
        self.store_transition(context, action, reward)
        if self.total_steps % 100 == 0 and self.total_steps > 0:
            self.train()
        return action, reward
