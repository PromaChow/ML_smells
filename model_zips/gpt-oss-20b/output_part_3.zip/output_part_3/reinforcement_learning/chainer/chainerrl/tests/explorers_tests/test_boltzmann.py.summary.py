import unittest
import numpy as np


class DiscreteActionValue:
    """Simple container for Q-values of discrete actions."""

    def __init__(self, q_values):
        self.q_values = np.array(q_values, dtype=float)

    def get_q_values(self):
        return self.q_values


class BoltzmannExplorer:
    """Boltzmann (softmax) action selection."""

    def __init__(self, temperature, action_value):
        if temperature <= 0:
            raise ValueError("Temperature must be positive")
        self.temperature = temperature
        self.action_value = action_value

    def select_action(self):
        q_vals = self.action_value.get_q_values()
        # Compute softmax probabilities
        scaled_q = q_vals / self.temperature
        max_q = np.max(scaled_q)
        exp_q = np.exp(scaled_q - max_q)  # for numerical stability
        probs = exp_q / np.sum(exp_q)
        return np.random.choice(len(q_vals), p=probs)


def count_actions_selected_by_boltzmann(T, q_values, trials=10000):
    explorer = BoltzmannExplorer(T, DiscreteActionValue(q_values))
    action_count = np.zeros(len(q_values), dtype=int)
    for _ in range(trials):
        action = explorer.select_action()
        action_count[action] += 1
    return action_count


class TestBoltzmann(unittest.TestCase):
    def test_boltzmann(self):
        q_values = [-1, 1, 0]
        trials = 10000

        # Case 1: T = 1
        counts_T1 = count_actions_selected_by_boltzmann(1.0, q_values, trials)
        self.assertGreater(counts_T1[1], counts_T1[2], "Action 1 should be chosen more often than action 2 at T=1")
        self.assertGreater(counts_T1[2], counts_T1[0], "Action 2 should be chosen more often than action 0 at T=1")

        # Case 2: T = 0.5
        counts_T05 = count_actions_selected_by_boltzmann(0.5, q_values, trials)
        self.assertGreater(counts_T05[1], counts_T05[2], "Action 1 should be chosen more often than action 2 at T=0.5")
        self.assertGreater(counts_T05[2], counts_T05[0], "Action 2 should be chosen more often than action 0 at T=0.5")

        # Comparison: T=0.5 should be more greedy than T=1
        self.assertGreater(
            counts_T05[1], counts_T1[1],
            "Action 1 should be selected more frequently at T=0.5 than at T=1"
        )
        self.assertLess(
            counts_T05[0], counts_T1[0],
            "Action 0 should be selected less frequently at T=0.5 than at T=1"
        )
        self.assertLess(
            counts_T05[2], counts_T1[2],
            "Action 2 should be selected less frequently at T=0.5 than at T=1"
        )


if __name__ == "__main__":
    unittest.main()
