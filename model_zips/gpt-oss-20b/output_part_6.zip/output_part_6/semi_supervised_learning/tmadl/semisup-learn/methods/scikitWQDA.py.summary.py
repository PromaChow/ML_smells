import numpy as np
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.metrics import accuracy_score
from scipy.special import logsumexp

def weighted_oas(X: np.ndarray, weights: np.ndarray) -> np.ndarray:
    """
    Weighted Oracle Approximating Shrinkage (OAS) covariance estimator.
    Parameters
    ----------
    X : np.ndarray
        Centered data matrix (n_samples, n_features).
    weights : np.ndarray
        Normalized sample weights (n_samples,).
    Returns
    -------
    np.ndarray
        Shrunk covariance matrix (n_features, n_features).
    """
    n_samples, n_features = X.shape
    # Weighted empirical covariance
    emp_cov = (X * weights[:, None]).T @ X / len(weights)
    # Compute parameters
    mu = np.trace(emp_cov) / n_features
    alpha = np.sum(emp_cov ** 2)
    beta = np.sum(np.diag(emp_cov) ** 2)
    # Shrinkage coefficient
    numerator = (1 - 2 / n_features) * alpha + beta
    denominator = (len(weights) - 1) * np.sum((emp_cov - mu * np.eye(n_features)) ** 2)
    shrinkage = 0.0
    if denominator > 0:
        shrinkage = numerator / denominator
    shrinkage = np.clip(shrinkage, 0.0, 1.0)
    # Shrinked covariance
    shrunk_cov = (1 - shrinkage) * emp_cov + shrinkage * mu * np.eye(n_features)
    return shrunk_cov

class WQDA(BaseEstimator, ClassifierMixin):
    """
    Weighted Quadratic Discriminant Analysis (WQDA) classifier.
    """
    def __init__(self, use_shrinkage: bool = False, normalize: bool = True):
        self.use_shrinkage = use_shrinkage
        self.normalize = normalize

    def fit(self, X: np.ndarray, y: np.ndarray, sample_weight: np.ndarray | None = None) -> "WQDA":
        X = np.asarray(X)
        y = np.asarray(y)
        n_samples, n_features = X.shape
        self.n_features_ = n_features
        # Determine unique classes
        self.classes_ = np.unique(y)
        self.n_classes_ = len(self.classes_)
        # Update shrinkage flag based on dimensionality
        if n_samples < n_features:
            self.use_shrinkage = True
        # Prepare sample weights
        if sample_weight is None:
            sample_weight = np.ones(n_samples)
        sample_weight = np.asarray(sample_weight).reshape(-1, 1)
        # Compute weighted counts per class
        qsum = np.array([np.sum(sample_weight[y == cls]) for cls in self.classes_]).ravel()
        # Class priors
        self.priors_ = qsum / len(y)
        self.log_priors_ = np.log(self.priors_)
        # Compute class means and covariances
        means = np.zeros((self.n_classes_, n_features))
        covariances = np.zeros((self.n_classes_, n_features, n_features))
        for idx, cls in enumerate(self.classes_):
            idxs = np.where(y == cls)[0]
            X_cls = X[idxs]
            w_cls = sample_weight[idxs].ravel()
            # Normalize weights for this class
            w_norm = w_cls / np.sum(w_cls)
            # Weighted mean
            means[idx] = np.average(X_cls, axis=0, weights=w_norm)
            # Centered data
            X_centered = X_cls - means[idx]
            if n_samples > n_features and not self.use_shrinkage:
                # Standard weighted covariance
                cov = (X_centered.T * w_norm) @ X_centered
            else:
                # Shrinkage covariance
                cov = weighted_oas(X_centered, w_norm)
            covariances[idx] = cov
        self.means_ = means
        self.covariances_ = covariances
        # Store inverse and log-determinant for each class
        self.inv_covariances_ = np.linalg.inv(covariances)
        sign, logdet = np.linalg.slogdet(covariances)
        self.log_det_covariances_ = logdet
        # Global covariance
        self.covariance_ = np.mean(covariances, axis=0)
        return self

    def _log_posterior(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X)
        n_samples = X.shape[0]
        log_likelihoods = np.empty((n_samples, self.n_classes_))
        for idx in range(self.n_classes_):
            diff = X - self.means_[idx]
            # Mahalanobis distance
            mahal = np.sum((diff @ self.inv_covariances_[idx]) * diff, axis=1)
            log_likelihoods[:, idx] = (
                -0.5
                * (
                    self.n_features_
                    * np.log(2 * np.pi)
                    + self.log_det_covariances_[idx]
                    + mahal
                )
            )
        log_joint = log_likelihoods + self.log_priors_
        if self.normalize:
            return log_joint - logsumexp(log_joint, axis=1, keepdims=True)
        return log_joint

    def predict(self, X: np.ndarray) -> np.ndarray:
        log_post = self._log_posterior(X)
        return self.classes_[np.argmax(log_post, axis=1)]

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        log_post = self._log_posterior(X)
        return np.exp(log_post)

    def score(self, X: np.ndarray, y: np.ndarray) -> float:
        y_pred = self.predict(X)
        return accuracy_score(y, y_pred)