import argparse
import logging
import os
import sys
import tempfile
import shutil

import h5py
import numpy as np

try:
    from sgfmill import sgf, sgf_move, sgf_parser, sgf_exceptions, sgf_game
    from sgfmill.sgf import Sgf_game
    from sgfmill.exceptions import IllegalMoveError, Sgf_parse_error
except ImportError:
    raise ImportError("sgfmill library is required. Install via pip install sgfmill")

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")
log = logging.getLogger(__name__)


class SizeMismatchError(Exception):
    pass


class Preprocess:
    def __init__(self, features, board_size):
        self.features = features
        self.board_size = board_size

    def process(self, board):
        tensors = []
        for feat in self.features:
            if feat == "board":
                tensor = np.zeros((self.board_size, self.board_size), dtype=np.float32)
                for x in range(self.board_size):
                    for y in range(self.board_size):
                        stone = board.get_stone(x, y)
                        if stone == board.BLACK:
                            tensor[y, x] = 1.0
                        elif stone == board.WHITE:
                            tensor[y, x] = -1.0
                tensors.append(tensor)
            elif feat == "liberties":
                tensor = np.zeros((self.board_size, self.board_size), dtype=np.float32)
                for x in range(self.board_size):
                    for y in range(self.board_size):
                        if board.get_stone(x, y) is not None:
                            tensor[y, x] = board.num_liberties(x, y)
                tensors.append(tensor)
            else:
                raise ValueError(f"Unknown feature: {feat}")
        return np.stack(tensors, axis=0)


class GameConverter:
    def __init__(self, features, board_size, ignore_errors=False):
        self.features = features
        self.bd_size = board_size
        self.ignore_errors = ignore_errors
        self.preprocess = Preprocess(features, board_size)

    def convert_game(self, file_path):
        try:
            with open(file_path, "rb") as fp:
                sgf_obj = Sgf_game.from_file(fp)
        except (Sgf_parse_error, Exception) as exc:
            log.warning(f"Failed to parse SGF file {file_path}: {exc}")
            if not self.ignore_errors:
                raise
            return

        board = sgf_obj.board
        if board.size != self.bd_size:
            raise SizeMismatchError(
                f"Board size {board.size} in file {file_path} does not match expected {self.bd_size}"
            )

        cur_board = board.copy()
        for node in sgf_obj.main_sequence():
            color = node.get_color()
            if color is None:
                continue
            try:
                move = node.get_move(color)
            except Exception:
                continue
            if move is None:
                continue  # pass
            x, y = move
            try:
                cur_board.play(x, y, color)
            except IllegalMoveError:
                log.warning(f"Illegal move at {(x, y)} in file {file_path}")
                if not self.ignore_errors:
                    raise
                continue
            tensor = self.preprocess.process(cur_board)
            action = np.array([x, y], dtype=np.int32)
            yield tensor, action


def sgfs_to_hdf5(
    sgf_paths,
    output_path,
    converter,
):
    tmp_file = None
    try:
        tmp_fd, tmp_path = tempfile.mkstemp(suffix=".h5")
        os.close(tmp_fd)
        tmp_file = tmp_path
        with h5py.File(tmp_file, "w") as f:
            n_features = len(converter.features)
            size = converter.bd_size
            states = f.create_dataset(
                "states",
                shape=(0, n_features, size, size),
                maxshape=(None, n_features, size, size),
                dtype="float32",
                chunks=True,
            )
            actions = f.create_dataset(
                "actions",
                shape=(0, 2),
                maxshape=(None, 2),
                dtype="int32",
                chunks=True,
            )
            file_offsets = f.create_group("file_offsets")
            for sgf_path in sgf_paths:
                log.info(f"Processing file: {sgf_path}")
                start = states.shape[0]
                count = 0
                for tensor, action in converter.convert_game(sgf_path):
                    cur_len = states.shape[0]
                    states.resize((cur_len + 1, n_features, size, size))
                    states[cur_len] = tensor
                    actions.resize((cur_len + 1, 2))
                    actions[cur_len] = action
                    count += 1
                end = states.shape[0]
                file_offsets.create_dataset(
                    os.path.basename(sgf_path), data=[start, end]
                )
                log.info(f"  added {count} state-action pairs")
            f.attrs["features"] = ",".join(converter.features)
        shutil.move(tmp_file, output_path)
        log.info(f"Successfully written HDF5 to {output_path}")
    except Exception as exc:
        if tmp_file and os.path.exists(tmp_file):
            os.remove(tmp_file)
        log.error(f"Error during conversion: {exc}")
        raise


def collect_sgf_files(directory, recurse):
    sgf_files = []
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.lower().endswith(".sgf"):
                sgf_files.append(os.path.join(root, file))
        if not recurse:
            break
    return sgf_files


def run_game_converter():
    parser = argparse.ArgumentParser(
        description="Convert SGF Go game files to HDF5 for neural network training."
    )
    parser.add_argument(
        "-f",
        "--features",
        nargs="+",
        default=["board"],
        help="Features to use (default: board).",
    )
    parser.add_argument(
        "-o",
        "--output",
        required=True,
        help="Output HDF5 file path.",
    )
    parser.add_argument(
        "-d",
        "--directory",
        help="Directory containing SGF files.",
    )
    parser.add_argument(
        "-r",
        "--recurse",
        action="store_true",
        help="Recurse into subdirectories when scanning for SGF files.",
    )
    parser.add_argument(
        "-b",
        "--board-size",
        type=int,
        default=19,
        help="Board size to enforce (default: 19).",
    )
    parser.add_argument(
        "-i",
        "--ignore-errors",
        action="store_true",
        help="Ignore errors and continue processing.",
    )
    args = parser.parse_args()

    if args.directory:
        sgf_paths = collect_sgf_files(args.directory, args.recurse)
        if not sgf_paths:
            log.error("No SGF files found in the specified directory.")
            sys.exit(1)
    else:
        # Read file paths from stdin
        sgf_paths = [line.strip() for line in sys.stdin if line.strip()]
        if not sgf_paths:
            log.error("No SGF file paths provided via stdin.")
            sys.exit(1)

    converter = GameConverter(
        features=args.features,
        board_size=args.board_size,
        ignore_errors=args.ignore_errors,
    )
    sgfs_to_hdf5(sgf_paths, args.output, converter)


if __name__ == "__main__":
    run_game_converter()
