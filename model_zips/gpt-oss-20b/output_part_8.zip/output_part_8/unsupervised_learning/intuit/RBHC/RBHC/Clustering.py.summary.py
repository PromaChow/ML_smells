import os
import json
import csv
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.feature_selection import chi2

# -------------------- Configuration --------------------
SILHOUETTE_THRESHOLD = 0.1
DATA_DIR = Path("Data")
STAT_DIR = Path("Statistics") / "Hierarchical"
STAT_DIR.mkdir(parents=True, exist_ok=True)


# -------------------- Data Structures --------------------
class Cluster:
    def __init__(self, cluster_id, parent_id, indices):
        self.id = cluster_id
        self.parent_id = parent_id
        self.indices = indices  # indices in the original dataframe
        self.children = []
        self.split_feature = None
        self.chi2_scores = {}
        self.stats = {}

    def to_dict(self):
        return {
            "id": self.id,
            "parent_id": self.parent_id,
            "size": len(self.indices),
            "split_feature": self.split_feature,
            "chi2_scores": self.chi2_scores,
            "stats": self.stats,
            "children": [child.to_dict() for child in self.children],
        }


# -------------------- Utility Functions --------------------
def read_csv(file_path):
    df = pd.read_csv(file_path)
    if "user_id" not in df.columns:
        raise ValueError("CSV must contain 'user_id' column.")
    feature_cols = [col for col in df.columns if col != "user_id"]
    X = df[feature_cols].values
    return df, X, feature_cols


def compute_stats(df, indices):
    subset = df.iloc[indices]
    stats = {
        "mean": subset.mean().to_dict(),
        "median": subset.median().to_dict(),
        "std": subset.std().to_dict(),
    }
    return stats


def chi2_feature_selection(X, labels):
    chi2_vals, p_vals = chi2(X, labels)
    return chi2_vals, p_vals


def write_json(data, path):
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


# -------------------- Core Functions --------------------
def initialize_cluster_list(indices, root_id="L0G0"):
    root_cluster = Cluster(cluster_id=root_id, parent_id=None, indices=indices)
    return [root_cluster]


def hierarchical_clustering(cluster, df, X, feature_cols, level, global_count):
    if len(cluster.indices) < 2:
        return

    # Increment node count for this level
    global_count[level] += 1

    # Subset data for the current cluster
    sub_X = X[cluster.indices]
    sub_indices = np.array(cluster.indices)

    # Perform KMeans split into two clusters
    kmeans = KMeans(n_clusters=2, random_state=42)
    labels = kmeans.fit_predict(sub_X)

    # Silhouette score (ignore if only one cluster formed)
    if len(np.unique(labels)) < 2:
        return
    sil_score = silhouette_score(sub_X, labels)

    if sil_score < SILHOUETTE_THRESHOLD:
        return

    # Feature significance via chi2
    chi2_vals, _ = chi2_feature_selection(sub_X, labels)
    most_sig_idx = np.argmax(chi2_vals)
    most_sig_feature = feature_cols[most_sig_idx]

    cluster.split_feature = most_sig_feature
    cluster.chi2_scores = dict(zip(feature_cols, chi2_vals))

    # Split indices
    child_indices_0 = sub_indices[labels == 0]
    child_indices_1 = sub_indices[labels == 1]

    child0 = Cluster(
        cluster_id=f"{cluster.id}_0",
        parent_id=cluster.id,
        indices=child_indices_0.tolist(),
    )
    child1 = Cluster(
        cluster_id=f"{cluster.id}_1",
        parent_id=cluster.id,
        indices=child_indices_1.tolist(),
    )

    # Compute stats for children
    child0.stats = compute_stats(df, child0.indices)
    child1.stats = compute_stats(df, child1.indices)

    cluster.children.extend([child0, child1])

    # Recursively process children
    hierarchical_clustering(child0, df, X, feature_cols, level + 1, global_count)
    hierarchical_clustering(child1, df, X, feature_cols, level + 1, global_count)


def write_cluster_structure(clusters, output_path):
    root_cluster = clusters[0]
    write_json(root_cluster.to_dict(), output_path)


def create_model_list(file_path):
    models_file = Path("models.txt")
    processed = set()
    if models_file.exists():
        processed.update(models_file.read_text().splitlines())
    if file_path not in processed:
        with models_file.open("a") as f:
            f.write(file_path + "\n")


def clustering(data_file_path):
    # Read data
    df, X, feature_cols = read_csv(data_file_path)

    # Initialize root cluster
    indices = list(df.index)
    cluster_list = initialize_cluster_list(indices)

    # Global count per level
    global_count = defaultdict(int)

    # Recursively cluster
    hierarchical_clustering(cluster_list[0], df, X, feature_cols, level=0, global_count=global_count)

    # Write metadata
    cluster_meta_path = STAT_DIR / f"{Path(data_file_path).stem}_cluster_meta.json"
    write_cluster_structure(cluster_list, cluster_meta_path)

    # Write hierarchical structure
    cluster_struct_path = STAT_DIR / f"{Path(data_file_path).stem}_hierarchy.json"
    write_cluster_structure(cluster_list, cluster_struct_path)

    # Update models list
    create_model_list(data_file_path)

    # Optional: return global count
    return dict(global_count)


# -------------------- Example Usage --------------------
if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage: python hierarchical_clustering.py <csv_file_path>")
        sys.exit(1)

    csv_path = sys.argv[1]
    clustering(csv_path)
    print("Hierarchical clustering completed.")
