import joblib
from sklearn.datasets import load_digits
from sklearn.linear_model import SGDClassifier

digits = load_digits()
clf = SGDClassifier()
clf.fit(digits.data, digits.target)
accuracy = clf.score(digits.data, digits.target)
print(f"Training accuracy: {accuracy:.4f}")

_ = joblib.dump(clf, 'digits_classifier.joblib.pkl', compress=9)
print(_)