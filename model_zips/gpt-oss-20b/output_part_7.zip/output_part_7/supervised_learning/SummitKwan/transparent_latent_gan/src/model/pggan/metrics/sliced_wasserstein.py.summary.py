import torch
import torch.nn.functional as F
import random
from collections import defaultdict

class API:
    def __init__(
        self,
        nhood_size=7,
        nhoods_per_image=32,
        resolution_levels=4,
        num_directions=50,
        repeats=5,
        device=None,
    ):
        self.nhood_size = nhood_size
        self.nhoods_per_image = nhoods_per_image
        self.resolution_levels = resolution_levels
        self.num_directions = num_directions
        self.repeats = repeats
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")

        # Store descriptors per resolution level
        self.real_desc = defaultdict(list)
        self.fake_desc = defaultdict(list)

    def _extract_neighborhoods(self, img):
        """
        img: Tensor of shape (C, H, W)
        Returns descriptor tensor of shape (nhoods, C, nhood_size, nhood_size)
        """
        C, H, W = img.shape
        nhoods = self.nhoods_per_image
        sz = self.nhood_size
        max_y = H - sz
        max_x = W - sz
        ys = torch.randint(0, max_y + 1, (nhoods,), device=self.device)
        xs = torch.randint(0, max_x + 1, (nhoods,), device=self.device)
        descriptors = torch.empty((nhoods, C, sz, sz), device=self.device)
        for i, (y, x) in enumerate(zip(ys, xs)):
            descriptors[i] = img[:, y : y + sz, x : x + sz]
        return descriptors

    def _normalize_descriptors(self, desc):
        """
        desc: Tensor of shape (N, C, H, W)
        Returns flattened normalized descriptors of shape (N, C*H*W)
        """
        N, C, H, W = desc.shape
        mean = desc.mean(dim=[1, 2, 3], keepdim=True)
        std = desc.std(dim=[1, 2, 3], keepdim=True) + 1e-8
        normalized = (desc - mean) / std
        return normalized.view(N, -1)

    def _build_laplacian_pyramid(self, img, levels):
        """
        img: Tensor of shape (batch, C, H, W)
        Returns list of detail layers for each level: [(batch, C, H_l, W_l), ...]
        """
        levels = min(levels, img.shape[2].bit_length() - 1)  # ensure dimensions
        low = img
        pyramid = []
        for _ in range(levels):
            # downsample
            low_down = F.avg_pool2d(low, kernel_size=2, stride=2)
            # upsample
            up = F.interpolate(low_down, scale_factor=2, mode="bilinear", align_corners=False)
            # detail
            detail = low - up
            pyramid.append(detail)
            low = low_down
        return pyramid

    def feed(self, real_imgs, fake_imgs):
        """
        real_imgs, fake_imgs: tensors of shape (batch, C, H, W)
        """
        real_imgs = real_imgs.to(self.device)
        fake_imgs = fake_imgs.to(self.device)
        real_pyramid = self._build_laplacian_pyramid(real_imgs, self.resolution_levels)
        fake_pyramid = self._build_laplacian_pyramid(fake_imgs, self.resolution_levels)

        # level 0 is the original image (no detail)
        real_pyramid.insert(0, real_imgs)
        fake_pyramid.insert(0, fake_imgs)

        for level, (real_level, fake_level) in enumerate(zip(real_pyramid, fake_pyramid)):
            batch = real_level.shape[0]
            real_desc_lvl = []
            fake_desc_lvl = []
            for i in range(batch):
                real_desc_lvl.append(
                    self._normalize_descriptors(
                        self._extract_neighborhoods(real_level[i])
                    )
                )
                fake_desc_lvl.append(
                    self._normalize_descriptors(
                        self._extract_neighborhoods(fake_level[i])
                    )
                )
            # Concatenate along batch dimension
            real_desc_tensor = torch.cat(real_desc_lvl, dim=0)
            fake_desc_tensor = torch.cat(fake_desc_lvl, dim=0)
            self.real_desc[level].append(real_desc_tensor)
            self.fake_desc[level].append(fake_desc_tensor)

    def _sliced_wasserstein(self, real_desc, fake_desc):
        """
        real_desc, fake_desc: tensors of shape (N, D)
        Returns scalar distance.
        """
        N, D = real_desc.shape
        total = 0.0
        for _ in range(self.repeats):
            dirs = torch.randn(D, self.num_directions, device=self.device)
            dirs = F.normalize(dirs, dim=0)
            real_proj = real_desc @ dirs  # (N, num_directions)
            fake_proj = fake_desc @ dirs
            real_sorted, _ = torch.sort(real_proj, dim=0)
            fake_sorted, _ = torch.sort(fake_proj, dim=0)
            diff = torch.abs(real_sorted - fake_sorted).mean()
            total += diff.item()
        return (total / self.repeats) * 1000.0

    def end(self):
        metrics = {}
        all_dists = []
        for level in range(self.resolution_levels + 1):
            real_desc_lvl = torch.cat(self.real_desc[level], dim=0)
            fake_desc_lvl = torch.cat(self.fake_desc[level], dim=0)
            dist = self._sliced_wasserstein(real_desc_lvl, fake_desc_lvl)
            metrics[f"level_{level}"] = dist
            all_dists.append(dist)
        metrics["average"] = sum(all_dists) / len(all_dists)
        return metrics
