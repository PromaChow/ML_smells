import os
import time
import random
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F

def set_seed(seed: int = 42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

def update_ema(target: nn.Module, source: nn.Module, momentum: float):
    with torch.no_grad():
        for t_param, s_param in zip(target.parameters(), source.parameters()):
            t_param.data.mul_(momentum).add_(s_param.data, alpha=1 - momentum)

def average_parameters(model_avg: nn.Module, model_src: nn.Module, momentum: float):
    with torch.no_grad():
        for avg_param, src_param in zip(model_avg.parameters(), model_src.parameters()):
            avg_param.data.mul_(momentum).add_(src_param.data, alpha=1 - momentum)

def evaluate(model: nn.Module, loader, device):
    model.eval()
    correct, total = 0, 0
    loss_sum = 0.0
    criterion = nn.CrossEntropyLoss(reduction='sum')
    with torch.no_grad():
        for x, y in loader:
            x = x.to(device)
            y = y.to(device)
            logits = model(x)
            loss_sum += criterion(logits, y).item()
            pred = logits.argmax(dim=1)
            correct += (pred == y).sum().item()
            total += y.size(0)
    acc = 100.0 * correct / total
    avg_loss = loss_sum / total
    model.train()
    return acc, avg_loss

def train(cfg):
    set_seed(cfg.get('seed', 42))
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    labeled_loader, unlabeled_weak_loader, unlabeled_strong_loader, val_loader, test_loader = gen_dataloader(cfg)

    student = gen_model(cfg).to(device)
    student.train()

    teacher = None
    if cfg.get('ema_teacher', False):
        teacher = gen_model(cfg).to(device)
        teacher.load_state_dict(student.state_dict())
        teacher.eval()

    avg_model = None
    if cfg.get('weight_average', False):
        avg_model = gen_model(cfg).to(device)
        avg_model.load_state_dict(student.state_dict())
        avg_model.eval()

    if cfg.get('optimizer', 'SGD').lower() == 'adamw':
        optimizer = optim.AdamW(student.parameters(), lr=cfg['lr'], weight_decay=cfg.get('weight_decay', 0))
    else:
        optimizer = optim.SGD(student.parameters(), lr=cfg['lr'], momentum=cfg.get('momentum', 0.9), weight_decay=cfg.get('weight_decay', 0))

    if cfg.get('scheduler', 'cosine').lower() == 'cosine':
        scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=cfg['max_iters'])
    else:
        scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=cfg.get('step_size', 30), gamma=cfg.get('gamma', 0.1))

    criterion = nn.CrossEntropyLoss()
    best_acc = 0.0
    global_step = 0

    for epoch in range(cfg['epochs']):
        unlabeled_weak_iter = iter(unlabeled_weak_loader)
        unlabeled_strong_iter = iter(unlabeled_strong_loader)
        for labeled_batch in labeled_loader:
            try:
                u_w_batch = next(unlabeled_weak_iter)
                u_s_batch = next(unlabeled_strong_iter)
            except StopIteration:
                unlabeled_weak_iter = iter(unlabeled_weak_loader)
                unlabeled_strong_iter = iter(unlabeled_strong_loader)
                u_w_batch = next(unlabeled_weak_iter)
                u_s_batch = next(unlabeled_strong_iter)

            x_l, y_l = labeled_batch
            x_u_w, _ = u_w_batch
            x_u_s, _ = u_s_batch

            x_l = x_l.to(device)
            y_l = y_l.to(device)
            x_u_w = x_u_w.to(device)
            x_u_s = x_u_s.to(device)

            all_inputs = torch.cat([x_l, x_u_w, x_u_s], dim=0)
            logits = student(all_inputs)

            logits_l, logits_u_w, logits_u_s = logits.chunk(3, dim=0)

            sup_loss = criterion(logits_l, y_l)

            if cfg.get('tsa', False):
                threshold = cfg.get('tsa_threshold', 0.8)
                probs = F.softmax(logits_l, dim=1)
                max_probs = probs.max(dim=1)[0]
                mask = max_probs > threshold
                sup_loss = (sup_loss * mask.float()).mean()

            if teacher is not None:
                with torch.no_grad():
                    teacher_logits_u_w = teacher(x_u_w)
            else:
                teacher_logits_u_w = logits_u_w

            ssl_loss = ssl_alg(logits_u_s, teacher_logits_u_w)

            if cfg.get('entropy_minimization', False):
                probs_u_w = F.softmax(logits_u_w, dim=1)
                entropy = -(probs_u_w * torch.log(probs_u_w + 1e-6)).sum(dim=1).mean()
                ssl_loss = ssl_loss + cfg.get('entropy_weight', 0.1) * entropy

            total_loss = sup_loss + cfg.get('coef', 1.0) * ssl_loss

            optimizer.zero_grad()
            total_loss.backward()
            optimizer.step()
            scheduler.step()

            if teacher is not None:
                update_ema(teacher, student, cfg.get('ema_momentum', 0.999))

            if avg_model is not None:
                average_parameters(avg_model, student, cfg.get('weight_avg_momentum', 0.999))

            global_step += 1

            if global_step % cfg.get('disp', 100) == 0:
                cur_lr = optimizer.param_groups[0]['lr']
                print(f"Step {global_step:6d} | Sup Loss {sup_loss.item():.4f} | SSL Loss {ssl_loss.item():.4f} | LR {cur_lr:.6f}")

            if cfg.get('val_interval') and global_step % cfg.get('val_interval') == 0:
                eval_model = avg_model if avg_model is not None else student
                val_acc, val_loss = evaluate(eval_model, val_loader, device)
                print(f"Validation at step {global_step:6d}: Acc {val_acc:.2f}% | Loss {val_loss:.4f}")
                if val_acc > best_acc:
                    best_acc = val_acc
                    torch.save({
                        'step': global_step,
                        'student_state_dict': student.state_dict(),
                        'optimizer_state_dict': optimizer.state_dict(),
                        'scheduler_state_dict': scheduler.state_dict(),
                        'best_acc': best_acc,
                        'cfg': cfg
                    }, os.path.join(cfg['checkpoint_dir'], 'best_model.pth'))
                    print(f"Best model updated: {best_acc:.2f}%")

    final_ckpt = {
        'step': global_step,
        'student_state_dict': student.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'scheduler_state_dict': scheduler.state_dict(),
        'best_acc': best_acc,
        'cfg': cfg
    }
    torch.save(final_ckpt, os.path.join(cfg['checkpoint_dir'], 'final_model.pth'))

    if not cfg.get('only_validation', False) and test_loader is not None:
        eval_model = avg_model if avg_model is not None else student
        test_acc, test_loss = evaluate(eval_model, test_loader, device)
        print(f"Test Accuracy: {test_acc:.2f}% | Test Loss: {test_loss:.4f}")

if __name__ == "__main__":
    cfg = {
        'seed': 42,
        'lr': 0.03,
        'weight_decay': 5e-4,
        'momentum': 0.9,
        'optimizer': 'SGD',
        'scheduler': 'cosine',
        'max_iters': 20000,
        'epochs': 100,
        'ema_teacher': True,
        'ema_momentum': 0.999,
        'weight_average': True,
        'weight_avg_momentum': 0.999,
        'tsa': False,
        'entropy_minimization': False,
        'coef': 1.0,
        'disp': 100,
        'val_interval': 1000,
        'checkpoint_dir': './checkpoints',
        'only_validation': False
    }
    os.makedirs(cfg['checkpoint_dir'], exist_ok=True)
    train(cfg)