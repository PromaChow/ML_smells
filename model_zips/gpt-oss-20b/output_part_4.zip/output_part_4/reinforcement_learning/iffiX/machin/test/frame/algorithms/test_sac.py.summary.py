import os
import random
import tempfile
import shutil
import platform
import pytest
import gym
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F

# ---------- Network Definitions ----------

class Actor(nn.Module):
    def __init__(self, obs_dim: int, act_dim: int, act_limit: float):
        super().__init__()
        self.fc1 = nn.Linear(obs_dim, 16)
        self.fc2 = nn.Linear(16, 16)
        self.mean_layer = nn.Linear(16, act_dim)
        self.log_std_layer = nn.Linear(16, act_dim)
        self.act_limit = act_limit

    def forward(self, state: torch.Tensor):
        x = F.relu(self.fc1(state))
        x = F.relu(self.fc2(x))
        mean = self.mean_layer(x)
        log_std = self.log_std_layer(x)
        log_std = torch.clamp(log_std, -20, 2)
        return mean, log_std

    def sample(self, state: torch.Tensor):
        mean, log_std = self.forward(state)
        std = log_std.exp()
        normal = torch.distributions.Normal(mean, std)
        x_t = normal.rsample()
        action = torch.tanh(x_t)
        log_prob = normal.log_prob(x_t)
        log_prob = log_prob - torch.log(1 - action.pow(2) + 1e-6)
        log_prob = log_prob.sum(1, keepdim=True)
        action = action * self.act_limit
        return action, log_prob


class Critic(nn.Module):
    def __init__(self, obs_dim: int, act_dim: int):
        super().__init__()
        self.fc1 = nn.Linear(obs_dim + act_dim, 16)
        self.fc2 = nn.Linear(16, 16)
        self.fc3 = nn.Linear(16, 1)

    def forward(self, state: torch.Tensor, action: torch.Tensor):
        x = torch.cat([state, action], dim=-1)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        q = self.fc3(x)
        return q


# ---------- Replay Buffer ----------

class ReplayBuffer:
    def __init__(self, capacity: int):
        self.capacity = capacity
        self.storage = []
        self.ptr = 0

    def push(self, transition):
        if len(self.storage) < self.capacity:
            self.storage.append(transition)
        else:
            self.storage[self.ptr] = transition
            self.ptr = (self.ptr + 1) % self.capacity

    def sample(self, batch_size: int):
        batch = random.sample(self.storage, batch_size)
        state, action, reward, next_state, done = map(np.stack, zip(*batch))
        return (
            torch.FloatTensor(state),
            torch.FloatTensor(action),
            torch.FloatTensor(reward).unsqueeze(-1),
            torch.FloatTensor(next_state),
            torch.FloatTensor(done).unsqueeze(-1),
        )

    def __len__(self):
        return len(self.storage)


# ---------- SAC Agent ----------

class SAC:
    def __init__(
        self,
        env,
        device: torch.device,
        lr: float = 3e-4,
        gamma: float = 0.99,
        tau: float = 0.005,
        alpha: float = 0.2,
        buffer_capacity: int = 100_000,
        batch_size: int = 64,
        auto_alpha: bool = True,
        lr_scheduler=None,
    ):
        self.env = env
        obs_dim = env.observation_space.shape[0]
        act_dim = env.action_space.shape[0]
        act_limit = float(env.action_space.high[0])

        self.device = device
        self.actor = Actor(obs_dim, act_dim, act_limit).to(device)
        self.critic1 = Critic(obs_dim, act_dim).to(device)
        self.critic2 = Critic(obs_dim, act_dim).to(device)
        self.target_critic1 = Critic(obs_dim, act_dim).to(device)
        self.target_critic2 = Critic(obs_dim, act_dim).to(device)
        self.target_critic1.load_state_dict(self.critic1.state_dict())
        self.target_critic2.load_state_dict(self.critic2.state_dict())

        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=lr)
        self.critic1_optimizer = optim.Adam(self.critic1.parameters(), lr=lr)
        self.critic2_optimizer = optim.Adam(self.critic2.parameters(), lr=lr)
        self.log_alpha = torch.tensor(np.log(alpha), requires_grad=True, device=device)
        self.alpha_optimizer = optim.Adam([self.log_alpha], lr=lr)
        self.alpha = alpha
        self.auto_alpha = auto_alpha
        self.target_entropy = -act_dim

        self.gamma = gamma
        self.tau = tau
        self.batch_size = batch_size

        self.buffer = ReplayBuffer(buffer_capacity)

        self.lr_scheduler = lr_scheduler

    def act(self, state, deterministic=False):
        state = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        if deterministic:
            mean, _ = self.actor.forward(state)
            action = torch.tanh(mean) * self.actor.act_limit
            return action.detach().cpu().numpy()[0]
        else:
            action, _ = self.actor.sample(state)
            return action.detach().cpu().numpy()[0]

    def criticize(self, state, action, with_target=False):
        state = torch.FloatTensor(state).to(self.device)
        action = torch.FloatTensor(action).to(self.device)
        q1 = self.critic1(state, action)
        q2 = self.critic2(state, action)
        if with_target:
            q1_t = self.target_critic1(state, action)
            q2_t = self.target_critic2(state, action)
            return q1, q2, q1_t, q2_t
        return q1, q2

    def store_episode(self, episode):
        for transition in episode:
            self.buffer.push(transition)

    def update(self):
        if len(self.buffer) < self.batch_size:
            return
        state, action, reward, next_state, done = self.buffer.sample(self.batch_size)
        state = state.to(self.device)
        action = action.to(self.device)
        reward = reward.to(self.device)
        next_state = next_state.to(self.device)
        done = done.to(self.device)

        with torch.no_grad():
            next_action, next_log_prob = self.actor.sample(next_state)
            target_q1 = self.target_critic1(next_state, next_action)
            target_q2 = self.target_critic2(next_state, next_action)
            target_q = torch.min(target_q1, target_q2) - self.alpha * next_log_prob
            target_q = reward + (1 - done) * self.gamma * target_q

        current_q1 = self.critic1(state, action)
        current_q2 = self.critic2(state, action)
        critic1_loss = F.mse_loss(current_q1, target_q)
        critic2_loss = F.mse_loss(current_q2, target_q)

        self.critic1_optimizer.zero_grad()
        critic1_loss.backward()
        self.critic1_optimizer.step()

        self.critic2_optimizer.zero_grad()
        critic2_loss.backward()
        self.critic2_optimizer.step()

        new_action, log_prob = self.actor.sample(state)
        q1_pi = self.critic1(state, new_action)
        q2_pi = self.critic2(state, new_action)
        min_q_pi = torch.min(q1_pi, q2_pi)
        actor_loss = (self.alpha * log_prob - min_q_pi).mean()

        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        self.actor_optimizer.step()

        if self.auto_alpha:
            alpha_loss = -(self.log_alpha * (log_prob + self.target_entropy).detach()).mean()
            self.alpha_optimizer.zero_grad()
            alpha_loss.backward()
            self.alpha_optimizer.step()
            self.alpha = self.log_alpha.exp().item()

        for target_param, param in zip(self.target_critic1.parameters(), self.critic1.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)
        for target_param, param in zip(self.target_critic2.parameters(), self.critic2.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)

        if self.lr_scheduler:
            self.lr_scheduler.step()

    def save(self, path):
        os.makedirs(path, exist_ok=True)
        torch.save(
            {
                "actor": self.actor.state_dict(),
                "critic1": self.critic1.state_dict(),
                "critic2": self.critic2.state_dict(),
                "target_critic1": self.target_critic1.state_dict(),
                "target_critic2": self.target_critic2.state_dict(),
                "log_alpha": self.log_alpha,
            },
            os.path.join(path, "sac_model.pt"),
        )

    def load(self, path):
        checkpoint = torch.load(os.path.join(path, "sac_model.pt"), map_location=self.device)
        self.actor.load_state_dict(checkpoint["actor"])
        self.critic1.load_state_dict(checkpoint["critic1"])
        self.critic2.load_state_dict(checkpoint["critic2"])
        self.target_critic1.load_state_dict(checkpoint["target_critic1"])
        self.target_critic2.load_state_dict(checkpoint["target_critic2"])
        self.log_alpha = checkpoint["log_alpha"]
        self.alpha = self.log_alpha.exp().item()


# ---------- Fixtures ----------

@pytest.fixture
def train_config():
    env = gym.make("Pendulum-v0")
    return {
        "env": env,
        "max_episodes": 1000,
        "steps_per_episode": 200,
        "replay_buffer_size": 100_000,
        "solved_reward": -400,
        "device": torch.device("cuda" if torch.cuda.is_available() else "cpu"),
    }


@pytest.fixture
def sac(train_config):
    env = train_config["env"]
    return SAC(
        env=env,
        device=train_config["device"],
        lr=3e-4,
        gamma=0.99,
        tau=0.005,
        alpha=0.2,
        buffer_capacity=train_config["replay_buffer_size"],
        batch_size=64,
        auto_alpha=True,
    )


@pytest.fixture
def sac_vis(train_config):
    env = train_config["env"]
    return SAC(
        env=env,
        device=train_config["device"],
        lr=3e-4,
        gamma=0.99,
        tau=0.005,
        alpha=0.2,
        buffer_capacity=train_config["replay_buffer_size"],
        batch_size=64,
        auto_alpha=True,
    )


@pytest.fixture
def sac_lr(train_config):
    env = train_config["env"]
    scheduler = optim.lr_scheduler.StepLR(optim.Adam([], lr=3e-4), step_size=100, gamma=0.9)
    return SAC(
        env=env,
        device=train_config["device"],
        lr=3e-4,
        gamma=0.99,
        tau=0.005,
        alpha=0.2,
        buffer_capacity=train_config["replay_buffer_size"],
        batch_size=64,
        auto_alpha=True,
        lr_scheduler=scheduler,
    )


@pytest.fixture
def sac_train(train_config):
    env = train_config["env"]
    return SAC(
        env=env,
        device=train_config["device"],
        lr=3e-4,
        gamma=0.99,
        tau=0.005,
        alpha=0.2,
        buffer_capacity=train_config["replay_buffer_size"],
        batch_size=64,
        auto_alpha=True,
    )


# ---------- Test Cases ----------

def test_act(sac):
    state = np.zeros(sac.env.observation_space.shape)
    action = sac.act(state)
    assert action.shape == sac.env.action_space.shape
    assert np.all(action >= sac.env.action_space.low)
    assert np.all(action <= sac.env.action_space.high)


def test__criticize(sac):
    state = np.zeros(sac.env.observation_space.shape)
    action = np.zeros(sac.env.action_space.shape)
    q1, q2 = sac.criticize(state, action)
    assert q1.shape == (1, 1)
    assert q2.shape == (1, 1)
    q1_t, q2_t, tq1_t, tq2_t = sac.criticize(state, action, with_target=True)
    assert tq1_t.shape == (1, 1)
    assert tq2_t.shape == (1, 1)


def test_store(sac):
    dummy_episode = [
        (
            np.zeros(sac.env.observation_space.shape),
            np.zeros(sac.env.action_space.shape),
            0.0,
            np.zeros(sac.env.observation_space.shape),
            0.0,
        )
    ]
    sac.store_episode(dummy_episode)
    assert len(sac.buffer) == 1


def test_update(sac):
    # Prepare dummy transitions
    for _ in range(3):
        state = np.zeros(sac.env.observation_space.shape)
        action = np.zeros(sac.env.action_space.shape)
        reward = 0.0
        next_state = np.zeros(sac.env.observation_space.shape)
        done = 0.0
        sac.buffer.push((state, action, reward, next_state, done))
    old_alpha = sac.alpha
    old_actor_params = [p.clone() for p in sac.actor.parameters()]
    sac.update()
    # Verify parameters changed
    new_actor_params = [p for p in sac.actor.parameters()]
    changed = any((old - new).abs().sum() > 1e-6 for old, new in zip(old_actor_params, new_actor_params))
    assert changed
    assert sac.alpha != old_alpha


def test_save_load(sac):
    temp_dir = tempfile.mkdtemp()
    try:
        sac.save(temp_dir)
        new_sac = SAC(
            env=sac.env,
            device=sac.device,
            lr=3e-4,
            gamma=0.99,
            tau=0.005,
            alpha=0.2,
            buffer_capacity=sac.buffer.capacity,
            batch_size=64,
            auto_alpha=True,
        )
        new_sac.load(temp_dir)
        # Compare a few parameters
        for p_old, p_new in zip(sac.actor.parameters(), new_sac.actor.parameters()):
            assert torch.allclose(p_old, p_new)
    finally:
        shutil.rmtree(temp_dir)


def test_lr_scheduler(sac_lr):
    initial_lr = sac_lr.actor_optimizer.param_groups[0]["lr"]
    sac_lr.update()
    updated_lr = sac_lr.actor_optimizer.param_groups[0]["lr"]
    # The scheduler might not change until step threshold, but ensure step call doesn't error
    assert isinstance(updated_lr, float)


def test_config_init(train_config):
    env = train_config["env"]
    config = {
        "env": env,
        "max_episodes": 10,
        "steps_per_episode": 200,
        "replay_buffer_size": 50000,
        "solved_reward": -400,
        "device": torch.device("cpu"),
        "lr": 1e-3,
        "gamma": 0.99,
        "tau": 0.005,
        "alpha": 0.2,
        "auto_alpha": True,
    }
    sac_instance = SAC(
        env=config["env"],
        device=config["device"],
        lr=config["lr"],
        gamma=config["gamma"],
        tau=config["tau"],
        alpha=config["alpha"],
        buffer_capacity=config["replay_buffer_size"],
        batch_size=64,
        auto_alpha=config["auto_alpha"],
    )
    assert sac_instance.alpha == config["alpha"]
    assert sac_instance.gamma == config["gamma"]
    assert sac_instance.tau == config["tau"]


# ---------- Full Training Test ----------

@pytest.mark.skipif(platform.system() != "Linux", reason="Full training test requires Linux.")
def test_full_train(train_config):
    env = train_config["env"]
    env.seed(0)
    np.random.seed(0)
    random.seed(0)
    torch.manual_seed(0)

    agent = SAC(
        env=env,
        device=train_config["device"],
        lr=3e-4,
        gamma=0.99,
        tau=0.005,
        alpha=0.2,
        buffer_capacity=train_config["replay_buffer_size"],
        batch_size=64,
        auto_alpha=True,
    )

    solved_reward = train_config["solved_reward"]
    max_episodes = train_config["max_episodes"]
    steps_per_episode = train_config["steps_per_episode"]
    recent_rewards = []

    for episode in range(max_episodes):
        state = env.reset()
        episode_reward = 0.0
        for _ in range(steps_per_episode):
            action = agent.act(state)
            next_state, reward, done, _ = env.step(action)
            agent.buffer.push((state, action, reward, next_state, float(done)))
            state = next_state
            episode_reward += reward
            if done:
                break
        agent.update()
        recent_rewards.append(episode_reward)
        if len(recent_rewards) > 5:
            recent_rewards.pop(0)
        if len(recent_rewards) == 5 and np.mean(recent_rewards) > solved_reward:
            break

    avg_reward = np.mean(recent_rewards)
    assert avg_reward > solved_reward
