import re
from typing import Any, Iterable, List, Tuple, Union, Optional

import tensorflow as tf
from tensorflow.python.client import device_lib


def _traverse_nested(
    data: Any,
    func,
    *args,
    **kwargs,
) -> Any:
    """Recursively apply func to each leaf of a nested structure."""
    if isinstance(data, (list, tuple)):
        return type(data)([_traverse_nested(d, func, *args, **kwargs) for d in data])
    elif isinstance(data, dict):
        return {k: _traverse_nested(v, func, *args, **kwargs) for k, v in data.items()}
    else:
        return func(data, *args, **kwargs)


def reinit_nested_vars(
    nested_vars: Any,
    indices: Optional[Union[int, tf.Tensor]] = None,
) -> None:
    """Reset nested variable structures to zero, optionally for specific indices."""
    def _reset(var):
        zeros = tf.zeros_like(var)
        if indices is not None:
            if isinstance(indices, int):
                idx = tf.convert_to_tensor([indices], dtype=tf.int32)
            else:
                idx = tf.cast(indices, tf.int32)
            update_op = tf.tensor_scatter_nd_update(var, tf.expand_dims(idx, 1), zeros)
            var.assign(update_op)
        else:
            var.assign(zeros)

    _traverse_nested(nested_vars, _reset)


def assign_nested_vars(
    nested_vars: Any,
    nested_tensors: Any,
    indices: Optional[Union[int, tf.Tensor]] = None,
) -> None:
    """Assign tensor values to nested variable structures, matching hierarchy."""
    def _assign(var, tensor):
        if indices is not None:
            if isinstance(indices, int):
                idx = tf.convert_to_tensor([indices], dtype=tf.int32)
            else:
                idx = tf.cast(indices, tf.int32)
            update_op = tf.tensor_scatter_nd_update(var, tf.expand_dims(idx, 1), tensor)
            var.assign(update_op)
        else:
            var.assign(tensor)

    _traverse_nested(
        nested_vars,
        lambda var, tensor: _assign(var, tensor),
        nested_tensors,
    )


def discounted_return(
    rewards: tf.Tensor,
    gamma: float,
    mask: tf.Tensor,
) -> tf.Tensor:
    """Monte-Carlo return with masking."""
    def _step(carry, elems):
        ret, _ = carry
        r, m = elems
        ret = r + gamma * ret * m
        return (ret, None), ret

    _, returns = tf.scan(_step, (tf.zeros_like(rewards[0]), None), reverse=True)
    return returns


def fixed_step_return(
    rewards: tf.Tensor,
    values: tf.Tensor,
    dones: tf.Tensor,
    gamma: float,
    n_steps: int,
) -> tf.Tensor:
    """n-step return."""
    batch_size = tf.shape(rewards)[0]
    seq_len = tf.shape(rewards)[1]
    next_values = tf.concat([values[:, 1:], tf.zeros_like(values[:, :1])], axis=1)
    returns = tf.zeros_like(rewards)

    for step in range(n_steps):
        idx = tf.minimum(step, seq_len - 1)
        r = tf.slice(rewards, [0, idx], [batch_size, 1])
        d = tf.slice(dones, [0, idx], [batch_size, 1])
        v = tf.slice(next_values, [0, idx], [batch_size, 1])
        if step == 0:
            returns = r + gamma * v * (1.0 - d)
        else:
            returns = returns + (gamma ** step) * r * tf.reduce_prod(1.0 - tf.slice(dones, [0, tf.maximum(0, idx - step + 1)], [batch_size, step]), axis=1, keepdims=True)
    return returns


def lambda_return(
    rewards: tf.Tensor,
    values: tf.Tensor,
    dones: tf.Tensor,
    gamma: float,
    lam: float,
) -> tf.Tensor:
    """TD-lambda return."""
    seq_len = tf.shape(rewards)[1]
    batch_size = tf.shape(rewards)[0]

    def _step(carry, elems):
        ret, _ = carry
        r, v_next, d = elems
        delta = r + gamma * v_next * (1.0 - d) - ret
        ret = ret + lam * delta
        return (ret, None), ret

    init = tf.zeros_like(values[:, 0:1])
    elems = (rewards, tf.concat([values[:, 1:], tf.zeros_like(values[:, :1])], axis=1), dones)
    _, returns = tf.scan(_step, (init, None), elems, reverse=True)
    return returns


def lambda_advantage(
    rewards: tf.Tensor,
    values: tf.Tensor,
    dones: tf.Tensor,
    gamma: float,
    lam: float,
) -> tf.Tensor:
    """Generalized Advantage Estimation."""
    seq_len = tf.shape(rewards)[1]
    batch_size = tf.shape(rewards)[0]

    def _step(carry, elems):
        adv, _ = carry
        r, v_next, d, v = elems
        delta = r + gamma * v_next * (1.0 - d) - v
        adv = adv + lam * gamma * adv * (1.0 - d) + delta
        return (adv, None), adv

    init = tf.zeros_like(values[:, 0:1])
    elems = (rewards,
             tf.concat([values[:, 1:], tf.zeros_like(values[:, :1])], axis=1),
             dones,
             values)
    _, advantages = tf.scan(_step, (init, None), elems, reverse=True)
    return advantages


def available_gpus() -> List[str]:
    """List detected GPU device names."""
    devices = device_lib.list_local_devices()
    return [x.name for x in devices if x.device_type == 'GPU']


def gradient_summaries(
    grads: Iterable[tf.Tensor],
    names: Iterable[str],
    prefix: str = '',
) -> None:
    """Create histogram summaries for gradients grouped by regex."""
    for grad, name in zip(grads, names):
        if grad is None:
            continue
        for pattern in ('.*weight.*', '.*bias.*'):
            if re.match(pattern, name):
                tf.summary.histogram(f'{prefix}{name}', grad, step=0)
                break


def variable_summaries(
    vars: Iterable[tf.Variable],
    names: Iterable[str],
    prefix: str = '',
) -> None:
    """Create histogram summaries for variables grouped by regex."""
    for var, name in zip(vars, names):
        for pattern in ('.*weight.*', '.*bias.*'):
            if re.match(pattern, name):
                tf.summary.histogram(f'{prefix}{name}', var, step=0)
                break


def set_dimension(tensor: tf.Tensor, dim: int, size: int) -> tf.Tensor:
    """Enforce a static shape along a dimension."""
    shape = tensor.shape.as_list()
    if shape[dim] is not None and shape[dim] != size:
        raise ValueError(f'Existing dimension size {shape[dim]} does not match requested size {size}.')
    shape[dim] = size
    return tf.ensure_shape(tensor, shape)
