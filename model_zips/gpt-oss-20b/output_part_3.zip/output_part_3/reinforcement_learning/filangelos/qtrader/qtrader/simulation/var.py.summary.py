import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.tsa.api import VAR as VAR_class

def VAR(df: pd.DataFrame, max_order: int, return_model: bool = False):
    """
    Generate a VAR baseline time series.

    Parameters
    ----------
    df : pd.DataFrame
        Original multivariate time series data.
    max_order : int
        Maximum lag order to consider for the VAR model.
    return_model : bool, default False
        If True, return the fitted VAR model along with the generated DataFrame.

    Returns
    -------
    pd.DataFrame or tuple
        Simulated time series DataFrame. If `return_model` is True,
        a tuple of (generated DataFrame, fitted VAR model) is returned.
    """
    # Initialize VAR model
    model = VAR_class(df)

    # Fit the model with the specified maximum lag order and AIC criterion
    fitted = model.fit(maxlags=max_order, ic="aic")

    # Simulate a new time series of the same length as the original data
    simulated_ts = fitted.simulate_var(nsimulations=len(df.values))

    # Create DataFrame with original column names and truncated index
    simulated_df = pd.DataFrame(
        simulated_ts,
        index=df.index[-len(simulated_ts) :],
        columns=df.columns
    )

    if return_model:
        return simulated_df, fitted
    return simulated_df