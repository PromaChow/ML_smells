import numpy as np

def main():
    # Generate a 3x3 array with random values between 0 and 1
    data = np.random.random(9).reshape(3, 3)

    # Sort each column in ascending order (along the first axis)
    sorted_data = np.sort(data, axis=0)

    # Display the original and sorted arrays
    print("Original array:")
    print(data)
    print("\nSorted array:")
    print(sorted_data)

if __name__ == "__main__":
    main()
