import torch
from torch import nn
from torch.nn import init

class Standardize(nn.Module):
    def __init__(self, in_features: int, bias: bool = True, eps: float = 1e-6):
        super().__init__()
        self.in_features = in_features
        self.out_features = in_features
        self.bias = bias
        self.eps = eps

        self.std = nn.Parameter(torch.empty(in_features))
        if self.bias:
            self.mu = nn.Parameter(torch.empty(in_features))
        self.reset_parameters()

    def reset_parameters(self):
        init.constant_(self.std, 1.0)
        if self.bias:
            init.constant_(self.mu, 0.0)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.bias:
            x = x - self.mu
        return x / (self.std + self.eps)

    def extra_repr(self) -> str:
        return f"in_features={self.in_features}, out_features={self.out_features}, bias={self.bias}"