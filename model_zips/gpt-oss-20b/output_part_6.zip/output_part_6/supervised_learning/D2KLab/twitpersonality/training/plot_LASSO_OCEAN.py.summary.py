import os
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import Lasso
from sklearn.metrics import mean_squared_error
import datasetUtils as dsu
import embeddings

# Configuration
method = "conc"
post_threshold = 3
x_scale = "linear"
y_scale = "linear"
dataset = "fasttext"          # can be changed to any supported dataset
shuffle = "yes"               # options: "yes"/"no"/"true"/"false"
subset_size = 7500

# Create output directory
base_dir = os.path.join("Plots", "LASSO", method)
os.makedirs(base_dir, exist_ok=True)

# Load personality dataset
posts, openness, conscientiousness, extraversion, agreeableness, neuroticism = dsu.readMyPersonality()

# Load embeddings dictionary
if dataset.lower() == "fasttext":
    word_dict = dsu.parseFastText()
else:
    word_dict = dsu.loadEmbeddingsDataset(dataset)

# Optional shuffling
if shuffle.lower() in ("yes", "true"):
    idx = np.arange(len(posts))
    np.random.shuffle(idx)
    posts = [posts[i] for i in idx]
    openness = [openness[i] for i in idx]
    conscientiousness = [conscientiousness[i] for i in idx]
    extraversion = [extraversion[i] for i in idx]
    agreeableness = [agreeableness[i] for i in idx]
    neuroticism = [neuroticism[i] for i in idx]

# Truncate to subset size
posts = posts[:subset_size]
openness = openness[:subset_size]
conscientiousness = conscientiousness[:subset_size]
extraversion = extraversion[:subset_size]
agreeableness = agreeableness[:subset_size]
neuroticism = neuroticism[:subset_size]

# Transform text to feature matrix
conE = embeddings.transformTextForTraining(
    word_dictionary=word_dict,
    post_threshold=post_threshold,
    openness=openness,
    conscientiousness=conscientiousness,
    extraversion=extraversion,
    agreeableness=agreeableness,
    neuroticism=neuroticism
)

# Train-test split
split_index = round(len(conE) * 0.85)
X_train = conE[:split_index]
X_test = conE[split_index:]

# Traits mapping
traits = {
    "O": openness,
    "C": conscientiousness,
    "E": extraversion,
    "A": agreeableness,
    "N": neuroticism
}

alpha = 1e-4
for trait_code, y in traits.items():
    y_train = y[:split_index]
    y_test = y[split_index:]

    model = Lasso(alpha=alpha, normalize=True, max_iter=100000)
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    mse = mean_squared_error(y_test, y_pred)

    # Plotting
    plt.figure(figsize=(6, 6))
    plt.scatter(y_test, y_pred, alpha=0.5, edgecolor='k')
    plt.xlabel("True", fontsize=12)
    plt.ylabel("Predicted", fontsize=12)
    plt.title(f"{trait_code} - {method} - alpha={alpha:.4f}\nMSE={mse:.4f}",
              fontsize=14)
    plt.xscale(x_scale)
    plt.yscale(y_scale)
    plt.grid(True)

    # Save plot
    plot_name = f"{trait_code}_{method}_alpha{alpha:.4f}_{mse:.4f}.png"
    plot_path = os.path.join(base_dir, plot_name)
    plt.savefig(plot_path, dpi=300, bbox_inches='tight')
    plt.close()