import numpy as np
import chainer
import chainer.links as L
import chainer.initializers as I
from chainer import Chain
from chainer import Variable
from chainerrl.optimizer import NonbiasWeightDecay
from chainerrl import testing
import pytest

class Model(Chain):
    def __init__(self):
        super().__init__()
        with self.init_scope():
            self.a = L.Linear(
                1, 2,
                w_init=I.Constant(3),
                b_init=I.Constant(3)
            )
            self.b = Chain()
            with self.b.init_scope():
                self.b.c = L.Linear(
                    2, 3,
                    w_init=I.Constant(4),
                    b_init=I.Constant(4)
                )

@pytest.mark.parametrize(
    "lr,weight_decay_rate",
    [(1.0, 0.1), (1.0, 0.05), (0.1, 0.1), (0.1, 0.05)]
)
def test_cpu(lr, weight_decay_rate):
    gpu = -1
    xp = np
    model = Model()
    optimizer = chainer.optimizers.SGD(lr)
    optimizer.add_hook(NonbiasWeightDecay(weight_decay_rate))
    optimizer.setup(model)

    def loss_func():
        return Variable(xp.asarray(0.0))

    optimizer.update(loss_func)

    decay_factor = 1 - lr * weight_decay_rate
    w_a = np.array(model.a.W.data)
    b_a = np.array(model.a.b.data)
    w_c = np.array(model.b.c.W.data)
    b_c = np.array(model.b.c.b.data)

    np.testing.assert_allclose(w_a, 3 * decay_factor, rtol=1e-5, atol=1e-5)
    np.testing.assert_allclose(b_a, 3, rtol=1e-5, atol=1e-5)
    np.testing.assert_allclose(w_c, 4 * decay_factor, rtol=1e-5, atol=1e-5)
    np.testing.assert_allclose(b_c, 4, rtol=1e-5, atol=1e-5)

@pytest.mark.parametrize(
    "lr,weight_decay_rate",
    [(1.0, 0.1), (1.0, 0.05), (0.1, 0.1), (0.1, 0.05)]
)
@testing.attr.gpu
def test_gpu(lr, weight_decay_rate):
    gpu = 0
    xp = chainer.cuda.cupy
    model = Model()
    model.to_gpu(gpu)
    optimizer = chainer.optimizers.SGD(lr)
    optimizer.add_hook(NonbiasWeightDecay(weight_decay_rate))
    optimizer.setup(model)

    def loss_func():
        return Variable(xp.asarray(0.0))

    optimizer.update(loss_func)

    decay_factor = 1 - lr * weight_decay_rate
    w_a = model.a.W.data.get()
    b_a = model.a.b.data.get()
    w_c = model.b.c.W.data.get()
    b_c = model.b.c.b.data.get()

    np.testing.assert_allclose(w_a, 3 * decay_factor, rtol=1e-5, atol=1e-5)
    np.testing.assert_allclose(b_a, 3, rtol=1e-5, atol=1e-5)
    np.testing.assert_allclose(w_c, 4 * decay_factor, rtol=1e-5, atol=1e-5)
    np.testing.assert_allclose(b_c, 4, rtol=1e-5, atol=1e-5)