import time
import numpy as np
from collections import deque
from typing import List, Optional, Dict, Any


class VecMonitor:
    def __init__(self, venv, history_length: Optional[int] = None, info_keys: Optional[List[str]] = None):
        self.venv = venv
        self.n_envs = venv.num_envs if hasattr(venv, "num_envs") else len(venv.envs)
        self.history_length = history_length
        self.info_keys = info_keys or []

        self.episode_returns = np.zeros(self.n_envs, dtype=np.float32)
        self.episode_lens = np.zeros(self.n_envs, dtype=np.int32)

        if history_length is not None:
            self.returns_history = deque(maxlen=history_length)
            self.lens_history = deque(maxlen=history_length)
        else:
            self.returns_history = None
            self.lens_history = None

        self.start_time = time.time()
        self.episode_count = 0

    def reset(self):
        observations = self.venv.reset()
        self.episode_returns = np.zeros(self.n_envs, dtype=np.float32)
        self.episode_lens = np.zeros(self.n_envs, dtype=np.int32)
        return observations

    def step(self, actions):
        obs, rewards, dones, infos = self.venv.step(actions)

        self.episode_returns += rewards
        self.episode_lens += 1

        for i, done in enumerate(dones):
            if done:
                episode_info: Dict[str, Any] = {
                    "Episode Rewards": float(self.episode_returns[i]),
                    "Episode Length": int(self.episode_lens[i]),
                    "Time taken": time.time() - self.start_time,
                }

                for key in self.info_keys:
                    episode_info[key] = infos[i].get(key)

                if "episode" not in infos[i]:
                    infos[i]["episode"] = []
                infos[i]["episode"].append(episode_info)

                if self.returns_history is not None:
                    self.returns_history.append(float(self.episode_returns[i]))
                    self.lens_history.append(int(self.episode_lens[i]))

                self.episode_count += 1

                self.episode_returns[i] = 0.0
                self.episode_lens[i] = 0

        return obs, rewards, dones, infos

    def get_returns_history(self):
        return list(self.returns_history) if self.returns_history is not None else []

    def get_lens_history(self):
        return list(self.lens_history) if self.lens_history is not None else []
