import os
import time
import random
import gym
import numpy as np
import torch
import torch.nn as nn
import torch.multiprocessing as mp
from dataclasses import dataclass, field
from typing import List, Tuple

# ----------------------------- Configuration ---------------------------------
@dataclass
class Config:
    log_freq: int = 10
    checkpoint_num: int = 5
    env_id: str = 'Acrobot-v1'
    nn_sizes: List[int] = field(default_factory=lambda: [64, 64])
    clip_action: bool = True
    std0: float = 1.0
    generations: int = 500
    popsize: int = 32
    worker_chunksize: int = 4
    elite_frac: float = 0.25
    noise_sched: Tuple[float, float] = (1.0, 0.1)  # placeholder
    log_dir: str = 'logs/default'
    use_gpu: bool = False
    gpu_ids: List[int] = field(default_factory=list)


# ----------------------------- Environment ----------------------------------
class ClipAction(gym.ActionWrapper):
    def __init__(self, env):
        super().__init__(env)

    def action(self, action):
        low, high = self.action_space.low, self.action_space.high
        return np.clip(action, low, high)


def make_env(env_id: str, seed: int):
    env = gym.make(env_id)
    env.seed(seed)
    if isinstance(env.action_space, gym.spaces.Box) and env.action_space.shape[0] > 0:
        env = ClipAction(env)
    return env


# ----------------------------- Agent ----------------------------------------
class MLPPolicy(nn.Module):
    def __init__(self, obs_dim: int, act_dim: int, hidden_sizes: List[int]):
        super().__init__()
        layers = []
        input_dim = obs_dim
        for h in hidden_sizes:
            layers.append(nn.Linear(input_dim, h))
            layers.append(nn.ReLU())
            input_dim = h
        layers.append(nn.Linear(input_dim, act_dim))
        self.model = nn.Sequential(*layers)

    def forward(self, x):
        return self.model(x)


class Agent:
    def __init__(self, env: gym.Env, config: Config):
        obs_dim = env.observation_space.shape[0]
        act_dim = env.action_space.shape[0]
        self.device = torch.device('cuda' if config.use_gpu and torch.cuda.is_available() else 'cpu')
        self.policy = MLPPolicy(obs_dim, act_dim, config.nn_sizes).to(self.device)
        self.std = config.std0
        self.clip_action = config.clip_action
        self.env = env

    def act(self, state, noise: bool = True):
        state_t = torch.tensor(state, dtype=torch.float32, device=self.device)
        with torch.no_grad():
            action = self.policy(state_t).cpu().numpy()
        if noise:
            action += np.random.randn(*action.shape) * self.std
        if self.clip_action:
            action = np.clip(action, self.env.action_space.low, self.env.action_space.high)
        return action

    def get_params_vector(self):
        return torch.cat([p.data.view(-1) for p in self.policy.parameters()]).cpu().numpy()

    def set_params_vector(self, vec):
        pointer = 0
        for p in self.policy.parameters():
            numel = p.numel()
            p.data.copy_(torch.tensor(vec[pointer:pointer + numel], dtype=p.dtype, device=self.device).view_as(p))
            pointer += numel


# ----------------------------- CEM Optimizer --------------------------------
class CEM:
    def __init__(self, param_dim, mu0, std0, popsize, elite_frac):
        self.param_dim = param_dim
        self.mu = np.full(param_dim, mu0, dtype=np.float32)
        self.sigma = np.full(param_dim, std0, dtype=np.float32)
        self.popsize = popsize
        self.elite_frac = elite_frac

    def ask(self):
        return np.random.randn(self.popsize, self.param_dim) * self.sigma + self.mu

    def tell(self, samples, rewards):
        elite_count = max(1, int(self.popsize * self.elite_frac))
        elite_indices = np.argsort(rewards)[-elite_count:]
        elite_samples = samples[elite_indices]
        self.mu = elite_samples.mean(axis=0)
        self.sigma = elite_samples.std(axis=0) + 1e-8


# ----------------------------- Fitness Evaluation ----------------------------
def fitness(candidate_vec, seed, config: Config):
    torch.set_num_threads(1)
    env = make_env(config.env_id, seed)
    agent = Agent(env, config)
    agent.set_params_vector(candidate_vec)
    total_reward = 0.0
    total_len = 0
    episodes = 10
    for _ in range(episodes):
        obs = env.reset()
        done = False
        ep_reward = 0.0
        ep_len = 0
        while not done:
            action = agent.act(obs)
            obs, reward, done, _ = env.step(action)
            ep_reward += reward
            ep_len += 1
        total_reward += ep_reward
        total_len += ep_len
    return total_reward / episodes, total_len / episodes


def evaluate_batch(args):
    vec, seed, config = args
    return fitness(vec, seed, config)


# ----------------------------- Training Loop --------------------------------
def run(config: Config, seed: int, max_workers: int):
    if not os.path.exists(config.log_dir):
        os.makedirs(config.log_dir, exist_ok=True)
    log_path = os.path.join(config.log_dir, f'log_seed_{seed}.csv')
    checkpoint_dir = os.path.join(config.log_dir, f'checkpoints_seed_{seed}')
    os.makedirs(checkpoint_dir, exist_ok=True)

    # Initialize environment and agent to get parameter dimension
    base_env = make_env(config.env_id, seed)
    base_agent = Agent(base_env, config)
    param_dim = base_agent.get_params_vector().size
    es = CEM(param_dim, mu0=0.0, std0=1.0, popsize=config.popsize, elite_frac=config.elite_frac)

    pool_size = max(1, config.popsize // config.worker_chunksize)
    pool = mp.Pool(processes=pool_size)

    start_time = time.time()
    best_reward = -np.inf
    best_params = None

    with open(log_path, 'w') as log_file:
        header = 'gen,time,mean_reward,mean_horizon,best_reward\n'
        log_file.write(header)

        for gen in range(1, config.generations + 1):
            candidates = es.ask()
            args = [(candidates[i], seed + i, config) for i in range(config.popsize)]
            results = pool.map(evaluate_batch, args)
            rewards, horizons = zip(*results)
            rewards = np.array(rewards)
            horizons = np.array(horizons)
            es.tell(candidates, rewards)

            mean_reward = rewards.mean()
            mean_horizon = horizons.mean()
            gen_time = time.time() - start_time
            log_line = f'{gen},{gen_time:.2f},{mean_reward:.2f},{mean_horizon:.2f},{max(rewards):.2f}\n'
            log_file.write(log_line)

            # Update best
            idx_best = np.argmax(rewards)
            if rewards[idx_best] > best_reward:
                best_reward = rewards[idx_best]
                best_params = candidates[idx_best].copy()

            # Checkpointing
            if gen % (config.generations // config.checkpoint_num) == 0 or gen == config.generations:
                ckpt_path = os.path.join(checkpoint_dir, f'gen_{gen}.pt')
                torch.save({'gen': gen, 'params': best_params, 'reward': best_reward}, ckpt_path)

    pool.close()
    pool.join()


# ----------------------------- Experiment Execution -------------------------
def run_experiment(
    run_func,
    config: Config,
    seeds: List[int],
    log_dir: str,
    max_workers: int,
    use_gpu: bool,
    gpu_ids: List[int],
):
    config.log_dir = log_dir
    config.use_gpu = use_gpu
    config.gpu_ids = gpu_ids
    for seed in seeds:
        run_func(config, seed, max_workers)


if __name__ == '__main__':
    seeds = [1770966829, 1500925526, 2054191100]
    config = Config(
        env_id='Acrobot-v1',
        nn_sizes=[64, 64],
        std0=1.0,
        generations=500,
        popsize=32,
        worker_chunksize=4,
        elite_frac=0.25,
        log_dir='logs/default',
        use_gpu=False,
        gpu_ids=[],
    )
    run_experiment(
        run,
        config,
        seeds,
        log_dir='logs/default',
        max_workers=7,
        use_gpu=False,
        gpu_ids=[],
    )