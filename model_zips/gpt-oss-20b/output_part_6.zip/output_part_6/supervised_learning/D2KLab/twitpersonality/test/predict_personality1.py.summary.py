import re
import csv
from pathlib import Path
import numpy as np
import joblib
from sklearn.feature_extraction.text import CountVectorizer
import datasetUtils as dsu
import embeddings

# Configuration
fasttext_path = Path("dataset.vec")
tweet_threshold = 3
model_prefix = "SVM_fasttext_conc_"
output_csv = Path("personality_predictions1.csv")

# Get usernames from user input
user_input = input("Enter a username (prefixed with @) or a filename: ").strip()
if user_input.startswith("@"):
    usernames = [user_input.lstrip("@")]
else:
    try:
        with open(user_input, "r", encoding="utf-8") as f:
            usernames = [line.strip() for line in f if line.strip()]
    except Exception:
        print(f"Could not read file: {user_input}")
        usernames = []

if not usernames:
    print("No usernames to process.")
    exit(0)

# Load FastText embeddings
word_dictionary = dsu.parseFastText(str(fasttext_path))

# Load models
models = {}
for trait in ["O", "C", "E", "A", "N"]:
    model_path = Path(f"{model_prefix}{trait}.pkl")
    if model_path.exists():
        models[trait] = joblib.load(str(model_path))
    else:
        print(f"Model file missing: {model_path}")
        exit(1)

# Mapping for Jungian type letters
jungian_map = {
    "O": ("N", "S"),
    "C": ("S", "N"),
    "E": ("E", "I"),
    "A": ("F", "T"),
    "N": ("J", "P"),
}

outfile_rows = []

for username in usernames:
    tweet_file = Path(f"{username}_tweets.txt")
    if not tweet_file.exists():
        print(f"Tweet file not found for {username}, skipping.")
        continue

    # Read and preprocess tweets
    filtered_tweets = []
    with tweet_file.open("r", encoding="utf-8") as f:
        for line in f:
            tweet = line.strip()
            if not tweet or tweet.startswith("RT"):
                continue
            # Remove URLs
            tweet = re.sub(r"http\S+|www\.\S+", "", tweet)
            # Remove mentions
            tweet = re.sub(r"@\w+", "", tweet)
            tweet = tweet.strip()
            if tweet:
                filtered_tweets.append(tweet)

    if not filtered_tweets:
        print(f"No valid tweets for {username}, skipping.")
        continue

    # Transform tweets into embeddings
    embeddings_arr = embeddings.transformTextForTesting(filtered_tweets, word_dictionary)
    if embeddings_arr.size == 0 or embeddings_arr.shape[0] == 0:
        print(f"No embeddings produced for {username}, skipping.")
        continue

    # Predict personality scores
    trait_scores = {}
    for trait, model in models.items():
        try:
            preds = model.predict(embeddings_arr)
            avg_score = float(np.round(np.mean(preds), 5))
            trait_scores[trait] = avg_score
        except Exception as e:
            print(f"Prediction error for {username} on trait {trait}: {e}")
            trait_scores[trait] = None

    # Determine Jungian type
    j_type_letters = []
    for trait in ["O", "C", "E", "A", "N"]:
        score = trait_scores.get(trait)
        if score is None:
            j_type_letters.append("X")
            continue
        high, low = jungian_map[trait]
        j_type_letters.append(high if score > tweet_threshold else low)
    j_type = "".join(j_type_letters)

    # Prepare row for CSV
    row = [username]
    for trait in ["O", "C", "E", "A", "N"]:
        row.append(f"{trait_scores.get(trait, 'NA'):.5f}" if trait_scores.get(trait) is not None else "NA")
    row.append(j_type)
    outfile_rows.append(row)

# Write results to CSV
with output_csv.open("w", newline="", encoding="utf-8") as csvfile:
    writer = csv.writer(csvfile)
    header = ["username", "O", "C", "E", "A", "N", "JungianType"]
    writer.writerow(header)
    writer.writerows(outfile_rows)