import os
import numpy as np


class Pipe:
    def __init__(self, path: str):
        self.path = path
        self.fd = None

    def open(self, console: str = None) -> None:
        if not os.path.exists(self.path):
            raise FileNotFoundError(f"FIFO {self.path} does not exist")
        self.fd = open(self.path, "rb")

    def readline(self) -> bytes:
        if self.fd is None:
            raise RuntimeError("Pipe not open")
        line = bytearray()
        while True:
            chunk = self.fd.read(1)
            if not chunk:
                break
            if chunk == b"\n":
                break
            line += chunk
        return bytes(line)

    def close(self) -> None:
        if self.fd:
            self.fd.close()
            self.fd = None


class DataPipe:
    def __init__(
        self,
        env_id: str,
        width: int,
        height: int,
        bitmap_format: str,
        addresses: list[int],
        fifo_path: str,
    ) -> None:
        self.env_id = env_id
        self.width = width
        self.height = height
        self.format = bitmap_format
        self.addresses = addresses
        self.pipe = Pipe(fifo_path)

    def open(self, console: str) -> None:
        self.pipe.open(console)

    def get_lua_string(self) -> str:
        lua_lines = ["function get_data()"]
        lua_lines.append("  local s = emulator.get_screen()")
        lua_lines.append("  local res = ''")
        for addr in self.addresses:
            lua_lines.append(
                f"  res = res .. tostring(emu.read_byte(0x{addr:08X})) .. '+'"
            )
        lua_lines.append("  res = res .. s:bitmap_binary()")
        lua_lines.append("  return res")
        lua_lines.append("end")
        lua_lines.append("print(get_data())")
        return "\n".join(lua_lines)

    def read_data(self) -> dict:
        raw_line = self.pipe.readline()
        parts = raw_line.split(b"+")
        if len(parts) < len(self.addresses) + 1:
            raise ValueError("Insufficient data received")

        result: dict = {}
        for addr, part in zip(self.addresses, parts[:-1]):
            try:
                val = int(part.decode("ascii"))
            except Exception:
                val = int.from_bytes(part, "little", signed=False)
            result[addr] = val

        bitmap_bytes = parts[-1]
        arr = np.frombuffer(bitmap_bytes, dtype=np.uint8)

        if self.format.lower() == "rgb":
            expected = self.width * self.height * 3
            if arr.size != expected:
                raise ValueError("Bitmap size mismatch for RGB")
            arr = arr.reshape((self.height, self.width, 3))
        else:
            expected = self.width * self.height
            if arr.size != expected:
                raise ValueError("Bitmap size mismatch for grayscale")
            arr = arr.reshape((self.height, self.width))

        result["frame"] = arr
        return result
