import numpy as np
import random

class State:
    def __init__(self, dim_c: int):
        self.c = np.zeros(dim_c)

class Agent:
    def __init__(self, name: str, dim_c: int):
        self.name = name
        self.is_adversary = False
        self.is_speaker = False
        self.color = np.array([0.5, 0.5, 0.5])
        self.pos = np.zeros(2)
        self.state = State(dim_c)

class Landmark:
    def __init__(self, name: str):
        self.name = name
        self.color = np.zeros(3)
        self.pos = np.zeros(2)

class World:
    def __init__(self, num_agents: int, num_landmarks: int, dim_c: int = 4):
        self.dim_c = dim_c
        self.agents = [Agent(f"agent{i}", dim_c) for i in range(num_agents)]
        self.landmarks = [Landmark(f"landmark{i}") for i in range(num_landmarks)]

class Scenario:
    def __init__(self):
        self.world = World(num_agents=3, num_landmarks=2, dim_c=4)
        # Assign roles
        self.world.agents[0].is_adversary = True
        self.world.agents[0].color = np.array([1.0, 0.0, 0.0])  # red
        self.world.agents[1].is_speaker = False
        self.world.agents[2].is_speaker = True
        # Unique landmark colors
        self.world.landmarks[0].color = np.array([1.0, 0.0, 0.0])  # red
        self.world.landmarks[1].color = np.array([0.0, 1.0, 0.0])  # green

    def reset_world(self):
        for agent in self.world.agents:
            agent.pos = np.random.uniform(-1.0, 1.0, size=2)
            agent.state.c = np.zeros(self.world.dim_c)
        for lm in self.world.landmarks:
            lm.pos = np.random.uniform(-1.0, 1.0, size=2)
        # Random goal landmark
        goal_idx = random.randint(0, len(self.world.landmarks) - 1)
        self.goal_color = self.world.landmarks[goal_idx].color
        # Set good listener color to goal color
        self.world.agents[1].color = self.goal_color
        # Speaker key: color of the other landmark
        key_idx = (goal_idx + 1) % len(self.world.landmarks)
        self.speaker_key = self.world.landmarks[key_idx].color

    def reward(self, agent: Agent) -> float:
        goal = self.goal_color
        dist = np.linalg.norm(agent.state.c - goal)
        if agent.is_adversary:
            return -dist**2
        # Good agents
        r = -dist**2
        adv = self.world.agents[0]
        adv_dist = np.linalg.norm(adv.state.c - goal)
        if adv_dist < dist:
            r -= 0.5
        return r

    def observation(self, agent: Agent) -> np.ndarray:
        obs_parts = []
        if agent.is_speaker:
            obs_parts.append(self.goal_color)
        obs_parts.append(self.speaker_key)
        for other in self.world.agents:
            if other is not agent:
                obs_parts.append(other.state.c)
        obs_parts.append(np.array([1.0]))
        return np.concatenate(obs_parts)

# Example usage
if __name__ == "__main__":
    scenario = Scenario()
    scenario.reset_world()
    for agent in scenario.world.agents:
        obs = scenario.observation(agent)
        r = scenario.reward(agent)
        print(f"{agent.name}: obs={obs}, reward={r}")