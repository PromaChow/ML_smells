import svhn
import cifar10

# Shared training parameters
shared_config = {
    "total_iters": 500_000,
    "warmup_iters": 200_000,
    "lr_decay": {"step": 400_000, "factor": 0.2},
    "batch_size": 100,
}

# Dataset-specific configurations
svhn_config = {
    "augmentation": {
        "flip": False,
        "random_crop": True,
        "gaussian_noise": False,
    },
    "dataset_class": svhn.SVHN,
    "num_classes": 10,
}

cifar10_config = {
    "augmentation": {
        "flip": True,
        "random_crop": True,
        "gaussian_noise": True,
    },
    "dataset_class": cifar10.CIFAR10,
    "num_classes": 10,
}

# Algorithm-specific hyperparameters
vat_config = {
    "xi": 1e-6,
    "eps": {"svhn": 1, "cifar10": 6},
    "consis_coef": 0.3,
    "lr": 3e-3,
}

pl_config = {
    "threshold": 0.95,
    "lr": 3e-4,
    "consis_coef": 1,
}

mt_config = {
    "ema_factor": 0.95,
    "lr": 4e-4,
    "consis_coef": 8,
}

pi_config = {
    "lr": 3e-4,
    "consis_coef": 20.0,
}

ict_config = {
    "ema_factor": 0.999,
    "lr": 4e-4,
    "consis_coef": 100,
    "alpha": 0.1,
}

mm_config = {
    "lr": 3e-3,
    "consis_coef": 100,
    "alpha": 0.75,
    "T": 0.5,
    "K": 2,
}

supervised_config = {
    "lr": 3e-3,
}

# Master configuration
config = {
    "shared": shared_config,
    "svhn": svhn_config,
    "cifar10": cifar10_config,
    "VAT": vat_config,
    "PL": pl_config,
    "MT": mt_config,
    "PI": pi_config,
    "ICT": ict_config,
    "MM": mm_config,
    "supervised": supervised_config,
}