import gym
from q_learning import QLearningAgent
from trainer import ClassicalTrainer

def main():
    env = gym.make("FrozenLake-v0")
    agent = QLearningAgent(env)
    trainer = ClassicalTrainer(
        agent=agent,
        env=env,
        mode="dyna",
        model="tabular",
        training_episodes=50,
        initial_exploration_steps=0,
        eval_every=1,
    )
    ep_rs = trainer.train()
    eval_returns = trainer.evaluate()
    print("Episode returns during training:", ep_rs)
    print("Evaluation returns:", eval_returns)

if __name__ == "__main__":
    main()