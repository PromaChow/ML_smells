import random
import numpy as np
import torch
import pytest

# Assume these functions are provided elsewhere in the test suite.
from data_generation import generate_all, get_all

# Global counter for mp_tmpdir subdirectories
_mp_tmpdir_counter = 0

@pytest.fixture
def gpu(request):
    """Return the specified GPU device or skip if unavailable."""
    device_name = request.config.getoption("--gpu-device", default=None)
    if device_name and torch.cuda.is_available() and device_name in torch.cuda.get_device_name(0):
        return torch.device(device_name)
    pytest.skip(f"GPU device '{device_name}' not available or not specified.")

@pytest.fixture(params=["cpu", "gpu"])
def device(request, gpu):
    """Run tests on CPU or GPU, reusing the gpu fixture when requested."""
    if request.param == "gpu":
        return gpu
    return torch.device("cpu")

@pytest.fixture(params=[torch.float32, torch.float64])
def dtype(request):
    """Parameterize tests with float32 or float64 data types."""
    return request.param

@pytest.fixture
def mp_tmpdir(tmpdir):
    """Create a numbered subdirectory within the temporary directory for multiprocessing tests."""
    global _mp_tmpdir_counter
    _mp_tmpdir_counter += 1
    subdir = tmpdir.mkdir(f"mp_tmpdir_{_mp_tmpdir_counter}")
    return subdir

@pytest.fixture(scope="session")
def archives():
    """Generate all test data archives once per session."""
    generate_all()
    return get_all()

@pytest.fixture(scope="session", autouse=True)
def fix_random():
    """Set fixed seeds for reproducibility."""
    torch.manual_seed(0)
    np.random.seed(0)
    random.seed(0)

__all__ = [
    "gpu",
    "device",
    "dtype",
    "mp_tmpdir",
    "archives",
    "fix_random",
]