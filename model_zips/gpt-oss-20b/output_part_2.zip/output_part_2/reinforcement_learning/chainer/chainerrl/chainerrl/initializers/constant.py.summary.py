import math
from chainer.initializer import Initializer
from chainer.initializers import Constant, get_fans

class VarianceScalingConstant(Initializer):
    def __init__(self, scale: float = 1.0, dtype=None):
        super().__init__(dtype=dtype)
        self.scale = scale

    def __call__(self, array):
        if self.dtype is not None and array.dtype != self.dtype:
            raise ValueError(f"Array dtype {array.dtype} does not match expected dtype {self.dtype}")

        if array.ndim == 1:
            factor = self.scale / math.sqrt(array.shape[0])
        else:
            fan_in = get_fans(array.shape)[0]
            factor = self.scale / math.sqrt(fan_in)

        const_init = Constant(value=factor, dtype=self.dtype)
        return const_init(array)