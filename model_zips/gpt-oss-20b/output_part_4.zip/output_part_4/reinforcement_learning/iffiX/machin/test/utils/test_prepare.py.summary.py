import os
import torch
import pytest
from machin.utils.prepare import (
    prep_clear_dirs,
    prep_create_dirs,
    prep_load_state_dict,
    prep_load_model,
)

@pytest.fixture
def tmp_dir(tmpdir):
    return tmpdir.make_numbered_dir()


def test_prep_clear_dirs(tmp_dir):
    tmp_path = str(tmp_dir)
    # create a file
    file_path = os.path.join(tmp_path, "file.txt")
    with open(file_path, "w") as f:
        f.write("test")
    # create a subdirectory
    sub_dir = os.path.join(tmp_path, "subdir")
    os.mkdir(sub_dir)
    # create a symlink to the file
    symlink_path = os.path.join(tmp_path, "link.txt")
    os.symlink(file_path, symlink_path)

    # Ensure items exist before clearing
    assert os.path.exists(file_path)
    assert os.path.isdir(sub_dir)
    assert os.path.islink(symlink_path)

    # Call the function
    prep_clear_dirs(tmp_path)

    # All should be removed
    assert not os.path.exists(file_path)
    assert not os.path.exists(sub_dir)
    assert not os.path.exists(symlink_path)


def test_prep_create_dirs(tmp_dir):
    tmp_path = str(tmp_dir)
    sub_dir = os.path.join(tmp_path, "new_subdir")
    # Ensure directory does not exist
    assert not os.path.isdir(sub_dir)
    # Call the function
    prep_create_dirs(sub_dir)
    # Directory should now exist
    assert os.path.isdir(sub_dir)


def test_prep_load_state_dict(tmp_dir):
    # Create a model on GPU if available
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model2 = torch.nn.Linear(5, 3).to(device)
    # Extract state dict
    state_dict = model2.state_dict()
    # Create a CPU model
    model_cpu = torch.nn.Linear(5, 3).cpu()
    # Load state dict into CPU model
    prep_load_state_dict(model_cpu, state_dict)
    # Compare weights and biases
    for param_cpu, param_gpu in zip(model_cpu.parameters(), model2.cpu().parameters()):
        assert torch.allclose(param_cpu, param_gpu), "Parameter mismatch after loading"


def test_prep_load_model(tmp_dir):
    tmp_path = str(tmp_dir)
    # Helper to save a model
    def _save_model(version, seed):
        torch.manual_seed(seed)
        model = torch.nn.Linear(4, 2)
        torch.save(model.state_dict(), os.path.join(tmp_path, f"model_{version}.pt"))

    # Save two versions
    _save_model(0, 42)
    _save_model(100, 84)

    # Load from non-existent directory
    with pytest.raises(RuntimeError, match="No valid model found"):
        prep_load_model(os.path.join(tmp_path, "nonexistent"), version=0)

    # Load specific version 0
    model_loaded_0 = prep_load_model(tmp_path, version=0)
    model_expected_0 = torch.nn.Linear(4, 2)
    torch.manual_seed(42)
    model_expected_0.load_state_dict(torch.load(os.path.join(tmp_path, "model_0.pt")))
    for p1, p2 in zip(model_loaded_0.parameters(), model_expected_0.parameters()):
        assert torch.allclose(p1, p2), "Weights mismatch for version 0"

    # Load non-existent version 50; should fallback to 100
    model_loaded_fallback = prep_load_model(tmp_path, version=50)
    model_expected_100 = torch.nn.Linear(4, 2)
    torch.manual_seed(84)
    model_expected_100.load_state_dict(torch.load(os.path.join(tmp_path, "model_100.pt")))
    for p1, p2 in zip(model_loaded_fallback.parameters(), model_expected_100.parameters()):
        assert torch.allclose(p1, p2), "Weights mismatch for fallback to version 100"

    # Load newest by default
    model_loaded_newest = prep_load_model(tmp_path)
    for p1, p2 in zip(model_loaded_newest.parameters(), model_expected_100.parameters()):
        assert torch.allclose(p1, p2), "Weights mismatch for newest model"

    # Directory with invalid models
    invalid_dir = os.path.join(tmp_path, "invalid")
    os.mkdir(invalid_dir)
    with open(os.path.join(invalid_dir, "model_invalid.txt"), "w") as f:
        f.write("not a model")
    with pytest.raises(RuntimeError, match="No valid model found"):
        prep_load_model(invalid_dir)
