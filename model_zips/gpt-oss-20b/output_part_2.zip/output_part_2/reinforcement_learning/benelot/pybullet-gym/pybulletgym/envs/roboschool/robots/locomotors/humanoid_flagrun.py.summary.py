import math
import random
import numpy as np
import pybullet as p
import gymnasium as gym

try:
    from gymnasium.envs.robotics import Humanoid
except ImportError:
    class Humanoid(gym.Env):
        def __init__(self):
            self.frame_skip = 4
            self.viewer = None
            self._reset()
        def _reset(self):
            pass
        def reset(self):
            self._reset()
            return self.calc_state()
        def step(self, action):
            return self.calc_state(), 0.0, False, {}
        def robot_specific_reset(self):
            pass
        def calc_state(self):
            return np.zeros(3)
        def calc_potential(self):
            return 0.0
        def get_body_position_and_orientation(self, body_id, link_id=0):
            pos, orn = p.getBasePositionAndOrientation(body_id)
            return pos, orn
        def get_body_velocity(self, body_id, link_id=0):
            lin_vel, ang_vel = p.getBaseVelocity(body_id)
            return lin_vel, ang_vel
        def resetBasePositionAndOrientation(self, body_id, pos, orn):
            p.resetBasePositionAndOrientation(body_id, pos, orn)

# Placeholder for ObjectHelper
class ObjectHelper:
    @staticmethod
    def get_sphere(radius=0.1, mass=0.1, color=[1, 0, 0, 1]):
        collision = p.createCollisionShape(p.GEOM_SPHERE, radius=radius)
        visual = p.createVisualShape(p.GEOM_SPHERE, radius=radius, rgbaColor=color)
        sphere = p.createMultiBody(baseMass=mass, baseCollisionShapeIndex=collision,
                                   baseVisualShapeIndex=visual, basePosition=[0,0,0])
        return sphere

class HumanoidFlagrun(Humanoid):
    def __init__(self):
        super().__init__()
        self.flag = None
        self.flag_timeout = 0

    def robot_specific_reset(self):
        super().robot_specific_reset()
        self.flag_reposition()

    def flag_reposition(self):
        stadium_width = 10.0
        stadium_length = 10.0
        walk_target_x = random.uniform(-stadium_width/4, stadium_width/4)
        walk_target_y = random.uniform(-stadium_length/4, stadium_length/4)
        target_pos = [walk_target_x, walk_target_y, 0.0]
        target_orn = p.getQuaternionFromEuler([0, 0, 0])
        if self.flag is not None:
            self.resetBasePositionAndOrientation(self.flag, target_pos, target_orn)
        else:
            self.flag = ObjectHelper.get_sphere(radius=0.1, mass=0.1,
                                                color=[0, 1, 0, 1])
            p.resetBasePositionAndOrientation(self.flag, target_pos, target_orn)
        self.flag_timeout = int(600 / self.frame_skip)

    def calc_state(self):
        if self.flag_timeout > 0:
            self.flag_timeout -= 1
        state = super().calc_state()
        robot_pos, _ = self.get_body_position_and_orientation(self.robot_id)
        flag_pos, _ = self.get_body_position_and_orientation(self.flag)
        distance = math.hypot(flag_pos[0] - robot_pos[0], flag_pos[1] - robot_pos[1])
        if distance > 2.0 or self.flag_timeout <= 0:
            self.flag_reposition()
            state = super().calc_state()
        # Recalculate potential to avoid sudden changes
        state = self.calc_potential()
        return state

class HumanoidFlagrunHarder(HumanoidFlagrun):
    def __init__(self):
        super().__init__()
        self.aggressive_cube = None
        self.on_ground_frame_counter = 0
        self.frame = 0
        self.starting_potential = 0.0

    def robot_specific_reset(self):
        super().robot_specific_reset()
        if self.aggressive_cube is None:
            cube_collision = p.createCollisionShape(p.GEOM_BOX, halfExtents=[0.1, 0.1, 0.1])
            cube_visual = p.createVisualShape(p.GEOM_BOX, halfExtents=[0.1, 0.1, 0.1],
                                              rgbaColor=[1, 0, 0, 1])
            self.aggressive_cube = p.createMultiBody(baseMass=1.0,
                                                     baseCollisionShapeIndex=cube_collision,
                                                     baseVisualShapeIndex=cube_visual,
                                                     basePosition=[0, 0, 0.5])
        self.on_ground_frame_counter = 0
        self.frame = 0
        self.starting_potential = 0.0

    def alive_bonus(self):
        self.frame += 1
        bonus = 0.0
        if self.frame > 100 and (self.frame - 100) % 30 == 0:
            robot_pos, _ = self.get_body_position_and_orientation(self.robot_id)
            lin_vel, _ = self.get_body_velocity(self.robot_id)
            future_pos = [robot_pos[0] + lin_vel[0] * 0.5 + random.uniform(-1, 1),
                          robot_pos[1] + lin_vel[1] * 0.5 + random.uniform(-1, 1),
                          0.5]
            p.resetBasePositionAndOrientation(self.aggressive_cube, future_pos,
                                               p.getQuaternionFromEuler([0, 0, 0]))
            p.resetBaseVelocity(self.aggressive_cube, [lin_vel[0], lin_vel[1], 0])
        robot_pos, _ = self.get_body_position_and_orientation(self.robot_id)
        if robot_pos[2] < 0.2:
            self.on_ground_frame_counter += 1
        else:
            self.on_ground_frame_counter -= 1
            if self.on_ground_frame_counter < 0:
                self.on_ground_frame_counter = 0
        if self.on_ground_frame_counter >= 170:
            bonus = -10.0
        return bonus

    def potential_leak(self):
        robot_pos, _ = self.get_body_position_and_orientation(self.robot_id)
        z = robot_pos[2]
        z_clipped = min(z, 0.8)
        return 1.0 + (z_clipped / 0.8)

    def calc_potential(self):
        base_potential = super().calc_potential()
        robot_pos, _ = self.get_body_position_and_orientation(self.robot_id)
        crawling = robot_pos[2] < 0.8
        if crawling:
            self.starting_potential = base_potential
            flag_running_progress = self.starting_potential
        else:
            flag_running_progress = base_potential - self.starting_potential
        final_potential = flag_running_progress + self.potential_leak() * 100
        return final_potential
