import svhn
import cifar10

shared_config = {
    "total_iterations": 500_000,
    "warmup_iterations": 200_000,
    "lr_decay_iter": 400_000,
    "lr_decay_factor": 0.2,
    "batch_size": 100,
}

svhn_config = {
    "transform": {
        "flip": False,
        "random_crop": True,
        "gaussian_noise": False,
    },
    "dataset_class": svhn.SVHN,
    "num_classes": 10,
}

cifar10_config = {
    "transform": {
        "flip": True,
        "random_crop": True,
        "gaussian_noise": True,
    },
    "dataset_class": cifar10.CIFAR10,
    "num_classes": 10,
}

vat_config = {
    "xi": 1e-6,
    "eps": 1.0,
    "consis_coef": 0.3,
    "lr": 3e-3,
}

pl_config = {
    "threshold": 0.95,
    "consis_coef": 1.0,
    "lr": 3e-4,
}

mt_config = {
    "ema_factor": 0.95,
    "consis_coef": 8.0,
    "lr": 4e-4,
}

pi_config = {
    "consis_coef": 20.0,
    "lr": 3e-4,
}

ict_config = {
    "ema_factor": 0.999,
    "consis_coef": 100.0,
    "lr": 4e-4,
    "alpha": 0.1,
}

mm_config = {
    "consis_coef": 100.0,
    "lr": 3e-3,
    "alpha": 0.75,
    "T": 0.5,
    "K": 2,
}

supervised_config = {
    "lr": 3e-3,
}

config = {
    "shared": shared_config,
    "datasets": {
        "SVHN": svhn_config,
        "CIFAR10": cifar10_config,
    },
    "algorithms": {
        "VAT": vat_config,
        "PL": pl_config,
        "MT": mt_config,
        "PI": pi_config,
        "ICT": ict_config,
        "MM": mm_config,
        "Supervised": supervised_config,
    },
}