import tensorflow as tf

class MockRLAlgorithm:
    def __init__(self, envs):
        """
        Initialize with a list of in-graph environments.
        """
        self.envs = envs

    def begin_episode(self):
        """
        Called at the start of an episode. Returns an empty string tensor.
        """
        return tf.constant('', dtype=tf.string)

    def perform(self):
        """
        Generate random actions for all agents and return them with an empty summary.
        """
        if not self.envs:
            raise ValueError("Environment list is empty.")
        # Assume all environments share the same action space.
        action_space = self.envs[0].action_space

        # Determine action shape: [num_agents] + action_space.shape
        num_agents = len(self.envs)
        action_shape = [num_agents] + list(action_space.shape)

        # Get bounds and dtype
        try:
            action_dtype = action_space.dtype
        except AttributeError:
            action_dtype = tf.float32

        low = tf.convert_to_tensor(action_space.low, dtype=action_dtype)
        high = tf.convert_to_tensor(action_space.high, dtype=action_dtype)

        actions = tf.random.uniform(
            shape=action_shape,
            minval=low,
            maxval=high,
            dtype=action_dtype
        )
        return actions, tf.constant('', dtype=tf.string)

    def experience(self, *args, **kwargs):
        """
        Called after an agent takes an action and observes a transition.
        Returns an empty string tensor.
        """
        return tf.constant('', dtype=tf.string)

    def end_episode(self):
        """
        Called at the end of an episode. Returns an empty string tensor.
        """
        return tf.constant('', dtype=tf.string)