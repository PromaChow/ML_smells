import numpy as np
import torch
import gym
from lagom.tensor_util import tensorify


def flatdim(space: gym.Space) -> int:
    """Return the flattened dimension of a gym space."""
    if hasattr(space, "shape"):
        return int(np.prod(space.shape))
    return 1


class ReplayBuffer:
    def __init__(self, env: gym.Env, capacity: int, device: torch.device):
        self.capacity = capacity
        self.device = device

        obs_dim = flatdim(env.observation_space)
        act_dim = flatdim(env.action_space)

        self.observations = np.zeros((capacity, obs_dim), dtype=np.float32)
        self.next_observations = np.zeros((capacity, obs_dim), dtype=np.float32)
        self.actions = np.zeros((capacity, act_dim), dtype=np.float32)
        self.rewards = np.zeros((capacity, 1), dtype=np.float32)
        self.masks = np.zeros((capacity, 1), dtype=np.float32)

        self.size = 0
        self.pointer = 0

    def _add(
        self,
        observation: np.ndarray,
        action: np.ndarray,
        reward: float,
        next_observation: np.ndarray,
        terminal: bool,
    ):
        idx = self.pointer

        self.observations[idx] = observation.reshape(-1)
        self.actions[idx] = action.reshape(-1)
        self.rewards[idx] = reward
        self.next_observations[idx] = next_observation.reshape(-1)
        self.masks[idx] = 1.0 - float(terminal)

        self.pointer = (self.pointer + 1) % self.capacity
        self.size = min(self.size + 1, self.capacity)

    def add(self, traj):
        """
        Trajectory is expected to support:
            traj.T          : number of time steps
            traj[t]        : step object with attributes observation, reward, terminal()
            traj.actions   : list or array of actions indexed by t
        """
        for t in range(1, traj.T + 1):
            observation = traj[t - 1].observation
            action = traj.actions[t - 1]
            reward = traj[t].reward
            next_observation = traj[t].observation
            terminal = traj[t].terminal()
            self._add(observation, action, reward, next_observation, terminal)

    def sample(self, batch_size: int):
        if self.size == 0:
            raise ValueError("ReplayBuffer is empty")

        indices = np.random.randint(0, self.size, size=batch_size)

        batch_obs = self.observations[indices]
        batch_actions = self.actions[indices]
        batch_rewards = self.rewards[indices]
        batch_next_obs = self.next_observations[indices]
        batch_masks = self.masks[indices]

        return [
            tensorify(batch_obs).to(self.device),
            tensorify(batch_actions).to(self.device),
            tensorify(batch_rewards).to(self.device),
            tensorify(batch_next_obs).to(self.device),
            tensorify(batch_masks).to(self.device),
        ]