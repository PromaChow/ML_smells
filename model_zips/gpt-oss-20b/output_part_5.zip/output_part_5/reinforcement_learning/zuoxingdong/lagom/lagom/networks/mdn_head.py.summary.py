import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Normal


class MDNHead(nn.Module):
    def __init__(self, in_features: int, out_features: int, num_density: int) -> None:
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.num_density = num_density

        self.pi_head = nn.Linear(in_features, out_features * num_density, bias=True)
        self.mean_head = nn.Linear(in_features, out_features * num_density, bias=True)
        self.logvar_head = nn.Linear(in_features, out_features * num_density, bias=True)

        # Orthogonal initialization
        nn.init.orthogonal_(self.pi_head.weight, gain=1.0)
        nn.init.constant_(self.pi_head.bias, 0.0)

        nn.init.orthogonal_(self.mean_head.weight, gain=1.0)
        nn.init.constant_(self.mean_head.bias, 0.0)

        nn.init.orthogonal_(self.logvar_head.weight, gain=1.0)
        nn.init.constant_(self.logvar_head.bias, 0.0)

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Forward pass producing logits, means and log variances for the mixture components.
        """
        N = x.shape[0]
        logit_pi = self.pi_head(x).view(N, self.num_density, self.out_features)
        mean = self.mean_head(x).view(N, self.num_density, self.out_features)
        logvar = self.logvar_head(x).view(N, self.num_density, self.out_features)
        return logit_pi, mean, logvar

    @staticmethod
    def negative_log_likelihood(
        logit_pi: torch.Tensor,
        mean: torch.Tensor,
        logvar: torch.Tensor,
        target: torch.Tensor,
    ) -> torch.Tensor:
        """
        Computes the negative log-likelihood of the target under the mixture distribution.
        """
        std = torch.exp(0.5 * logvar)  # [N, K, D]
        target_broadcast = target.unsqueeze(1)  # [N, 1, D]

        log_pi = F.log_softmax(logit_pi, dim=1)  # [N, K, D]

        dist = Normal(mean, std)
        log_probs = dist.log_prob(target_broadcast)  # [N, K, D]
        log_probs_sum = log_probs.sum(dim=2)  # [N, K]

        joint_log_probs = log_pi + log_probs_sum  # [N, K]
        log_mixture = torch.logsumexp(joint_log_probs, dim=1)  # [N]

        nll = -log_mixture.mean()
        return nll

    def sample(
        self,
        logit_pi: torch.Tensor,
        mean: torch.Tensor,
        logvar: torch.Tensor,
        tau: float = 1.0,
    ) -> torch.Tensor:
        """
        Generates samples from the mixture distribution using reparameterization.
        """
        N, K, D = mean.shape
        probs = F.softmax(logit_pi / tau, dim=1)  # [N, K, D]
        # Categorical sampling of component indices
        indices = torch.multinomial(probs, num_samples=1).squeeze(-1)  # [N]

        # Gather the chosen mean and std
        std = torch.exp(0.5 * logvar)
        idx_expanded = indices.unsqueeze(-1).expand(-1, -1, D)  # [N, 1, D]
        mean_selected = torch.gather(mean, 1, idx_expanded).squeeze(1)  # [N, D]
        std_selected = torch.gather(std, 1, idx_expanded).squeeze(1)    # [N, D]

        eps = torch.randn_like(mean_selected)
        sample = mean_selected + eps * std_selected * torch.sqrt(torch.tensor(tau, device=logit_pi.device))
        return sample

# Example usage
if __name__ == "__main__":
    batch_size = 4
    in_dim = 10
    out_dim = 3
    K = 5

    model = MDNHead(in_dim, out_dim, K)
    x = torch.randn(batch_size, in_dim)
    logit_pi, mean, logvar = model(x)
    target = torch.randn(batch_size, out_dim)

    loss = MDNHead.negative_log_likelihood(logit_pi, mean, logvar, target)
    print("NLL:", loss.item())

    samples = model.sample(logit_pi, mean, logvar, tau=0.5)
    print("Samples shape:", samples.shape)