#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Apache License 2.0

Copyright 2024 C. I. Tang

This program is licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License. You may obtain
a copy of the License at

    https://www.apache.org/licenses/LICENSE-2.0

GNU General Public License v3.0

This code is adapted from the SimCLR framework (Chen et al., 2020) and modified
by C. I. Tang.
"""

import numpy as np
import tensorflow as tf
from sklearn.metrics import confusion_matrix, f1_score, precision_score, recall_score, cohen_kappa_score

LARGE_NUM = 1e9


def generate_composite_transform_function_simple(transform_functions):
    """
    Compose a list of transformation functions into a single function applied sequentially.
    """
    def composite(x):
        for fn in transform_functions:
            x = fn(x)
        return x
    return composite


def generate_combined_transform_function(transform_functions, indices):
    """
    Compose transformation functions specified by indices in a custom order.
    """
    def combined(x):
        for idx in indices:
            x = transform_functions[idx](x)
        return x
    return combined


def generate_slicing_transform_function(slice_indices, slice_functions, concat_axis=0):
    """
    Apply different transformation functions to specific slices of the input data
    and concatenate the results along the specified axis.
    """
    def slicing(x):
        results = []
        for indices, fn in zip(slice_indices, slice_functions):
            slice_part = tf.gather(x, indices, axis=concat_axis)
            transformed = fn(slice_part)
            results.append(transformed)
        return tf.concat(results, axis=concat_axis)
    return slicing


@tf.function
def NT_Xent_loss(features_a, features_b, temperature=0.5, normalize=True):
    """
    Normalized temperature-scaled cross entropy loss (NT-Xent).
    """
    if normalize:
        features_a = tf.math.l2_normalize(features_a, axis=1)
        features_b = tf.math.l2_normalize(features_b, axis=1)

    batch_size = tf.shape(features_a)[0]
    features = tf.concat([features_a, features_b], axis=0)
    similarity_matrix = tf.matmul(features, features, transpose_b=True)
    similarity_matrix = similarity_matrix / temperature

    mask = tf.linalg.diag(tf.ones(2 * batch_size))
    logits = similarity_matrix - LARGE_NUM * mask

    labels = tf.concat([tf.range(batch_size, 2 * batch_size), tf.range(0, batch_size)], axis=0)

    loss = tf.nn.sparse_softmax_cross_entropy_with_logits(labels=labels, logits=logits)
    return tf.reduce_mean(loss)


def get_NT_Xent_loss_gradients(model, batch, transform_func, optimizer, temperature=0.5, normalize=True):
    """
    Compute loss and gradients for a single batch.
    """
    with tf.GradientTape() as tape:
        view1 = transform_func(batch)
        view2 = transform_func(batch)
        feat1 = model(view1, training=True)
        feat2 = model(view2, training=True)
        loss = NT_Xent_loss(feat1, feat2, temperature=temperature, normalize=normalize)
    grads = tape.gradient(loss, model.trainable_variables)
    optimizer.apply_gradients(zip(grads, model.trainable_variables))
    return loss


def simclr_train_model(
    dataset,
    model,
    optimizer,
    batch_size=256,
    epochs=100,
    transform_func=None,
    temperature=0.5,
    normalize=True,
    verbose=True
):
    """
    Train a model using SimCLR contrastive learning.
    """
    if transform_func is None:
        transform_func = lambda x: x

    dataset = dataset.shuffle(buffer_size=10000)
    dataset = dataset.batch(batch_size)

    epoch_wise_loss = []

    for epoch in range(epochs):
        epoch_loss = 0.0
        for step, batch in enumerate(dataset):
            loss = get_NT_Xent_loss_gradients(
                model,
                batch,
                transform_func,
                optimizer,
                temperature=temperature,
                normalize=normalize
            )
            epoch_loss += loss.numpy()
        epoch_loss /= (step + 1)
        epoch_wise_loss.append(epoch_loss)
        if verbose:
            print(f"Epoch {epoch + 1}/{epochs}, Loss: {epoch_loss:.4f}")

    return epoch_wise_loss


def evaluate_model_simple(
    model,
    data,
    labels,
    is_one_hot=True,
    return_dict=True
):
    """
    Evaluate the model and compute classification metrics.
    """
    predictions = model(data, training=False)
    if is_one_hot:
        predictions = tf.argmax(predictions, axis=1).numpy()
        labels = tf.argmax(labels, axis=1).numpy()
    else:
        predictions = predictions.numpy()

    cm = confusion_matrix(labels, predictions)
    f1_macro = f1_score(labels, predictions, average='macro')
    f1_micro = f1_score(labels, predictions, average='micro')
    f1_weighted = f1_score(labels, predictions, average='weighted')
    precision = precision_score(labels, predictions, average='weighted')
    recall = recall_score(labels, predictions, average='weighted')
    kappa = cohen_kappa_score(labels, predictions)

    if return_dict:
        return {
            'confusion_matrix': cm,
            'f1_macro': f1_macro,
            'f1_micro': f1_micro,
            'f1_weighted': f1_weighted,
            'precision': precision,
            'recall': recall,
            'kappa': kappa
        }
    else:
        return (
            cm,
            f1_macro,
            f1_micro,
            f1_weighted,
            precision,
            recall,
            kappa
        )


# Example usage (requires a TensorFlow model and dataset):
# if __name__ == "__main__":
#     # Define dummy data and model
#     dummy_data = tf.random.normal((1000, 32, 32, 3))
#     dummy_labels = tf.random.uniform((1000,), maxval=10, dtype=tf.int32)
#     dummy_labels_one_hot = tf.one_hot(dummy_labels, depth=10)
#     dummy_dataset = tf.data.Dataset.from_tensor_slices(dummy_data)
#
#     # Simple CNN model
#     base_model = tf.keras.Sequential([
#         tf.keras.layers.Conv2D(32, 3, activation='relu'),
#         tf.keras.layers.Flatten(),
#         tf.keras.layers.Dense(128)
#     ])
#
#     optimizer = tf.keras.optimizers.Adam()
#
#     # Define simple transform: random flip
#     def random_flip(x):
#         return tf.image.random_flip_left_right(x)
#
#     # Train
#     loss_history = simclr_train_model(
#         dummy_dataset,
#         base_model,
#         optimizer,
#         batch_size=64,
#         epochs=10,
#         transform_func=random_flip
#     )
#
#     # Evaluate
#     metrics = evaluate_model_simple(
#         base_model,
#         dummy_data,
#         dummy_labels_one_hot,
#         is_one_hot=True
#     )
#     print(metrics)