import gym
from gym import Env
from gym.spaces import Discrete, Box

class GymWrapper:
    def __init__(self, env: Env):
        self.env = env
        self.observation_space = env.observation_space
        self.action_space = env.action_space
        self.state = None
        self.action = None
        self.reward = None
        self.done = None
        self.info = None

    def __getattr__(self, name):
        return getattr(self.env, name)

    @property
    def obs_shape(self):
        if isinstance(self.observation_space, Discrete):
            return (1,)
        if isinstance(self.observation_space, Box):
            return self.observation_space.shape
        return None

    @property
    def action_shape(self):
        if isinstance(self.action_space, Discrete):
            return (1,)
        if isinstance(self.action_space, Box):
            return self.action_space.shape
        return None

    def sample(self):
        return self.env.action_space.sample()

    def render(self, mode="human"):
        return self.env.render(mode)

    def seed(self, seed=None):
        return self.env.seed(seed)

    def step(self, action):
        self.action = action
        self.state, self.reward, self.done, self.info = self.env.step(action)
        return self.state, self.reward, self.done, self.info

    def reset(self):
        self.state = self.env.reset()
        return self.state

    def close(self):
        self.env.close()