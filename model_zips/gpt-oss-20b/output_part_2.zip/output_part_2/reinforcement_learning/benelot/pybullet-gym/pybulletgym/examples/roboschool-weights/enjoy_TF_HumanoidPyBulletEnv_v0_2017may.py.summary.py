import numpy as np

# Weight and bias definitions for a 3-layer dense neural network
weights_dense1_w = np.array([
    [ 0.2, -0.1,  0.4,  0.0,  0.5],
    [ 0.3,  0.1, -0.2,  0.2, -0.3],
    [ 0.0,  0.4,  0.1, -0.5,  0.2],
    [ 0.1, -0.3,  0.3,  0.2,  0.0]
])  # shape (4, 5)

weights_dense1_b = np.array([0.1, -0.2, 0.05, 0.0, 0.15])  # shape (5,)

weights_dense2_w = np.array([
    [ 0.4, -0.2,  0.1],
    [-0.1,  0.3,  0.2],
    [ 0.0, -0.4,  0.5],
    [ 0.2,  0.1, -0.3],
    [-0.3,  0.2,  0.4]
])  # shape (5, 3)

weights_dense2_b = np.array([0.05, -0.1, 0.2])  # shape (3,)

weights_final_w = np.array([
    [ 0.3, -0.2],
    [ 0.1,  0.4],
    [-0.4,  0.3]
])  # shape (3, 2)

weights_final_b = np.array([0.0, 0.1])  # shape (2,)

def relu(x):
    return np.maximum(0, x)

def dense_layer(x, w, b):
    return np.dot(x, w) + b

def main():
    # Example input: batch of 2 samples, each with 4 features
    X = np.array([
        [0.5, -0.2, 0.1, 0.7],
        [0.3, 0.8, -0.5, 0.0]
    ])  # shape (2, 4)

    # Forward pass through the network
    out1 = relu(dense_layer(X, weights_dense1_w, weights_dense1_b))
    out2 = relu(dense_layer(out1, weights_dense2_w, weights_dense2_b))
    logits = dense_layer(out2, weights_final_w, weights_final_b)

    print("Logits:\n", logits)

if __name__ == "__main__":
    main()