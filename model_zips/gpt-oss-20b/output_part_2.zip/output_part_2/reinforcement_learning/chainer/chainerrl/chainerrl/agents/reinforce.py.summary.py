import logging
from typing import Any, Callable, List, Optional, Tuple

import torch
import torch.nn as nn
import torch.optim as optim
import torch.distributions as dist

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)


def batch_states(state: Any, phi: Optional[Callable] = None) -> torch.Tensor:
    """
    Convert a single state into a batch of states suitable for the policy model.
    Optionally preprocess the state with `phi`.
    """
    if phi is not None:
        state = phi(state)
    if isinstance(state, torch.Tensor):
        batch = state.unsqueeze(0)
    else:
        batch = torch.tensor(state, dtype=torch.float32).unsqueeze(0)
    return batch


class REINFORCE:
    def __init__(
        self,
        model: nn.Module,
        optimizer: optim.Optimizer,
        beta: float = 0.01,
        batchsize: int = 10,
        phi: Optional[Callable] = None,
        act_deterministically: bool = False,
        backward_separately: bool = False,
        average_entropy_decay: float = 0.99,
    ):
        self.model = model
        self.optimizer = optimizer
        self.beta = beta
        self.batchsize = batchsize
        self.phi = phi
        self.act_deterministically = act_deterministically
        self.backward_separately = backward_separately
        self.average_entropy_decay = average_entropy_decay

        self.average_entropy = 0.0
        self.t = 0  # step counter

        self.reward_sequences: List[List[float]] = []
        self.log_prob_sequences: List[List[torch.Tensor]] = []
        self.entropy_sequences: List[List[float]] = []

        self.n_backward = 0  # episodes processed since last update

        if hasattr(self.model, "reset_hidden"):
            self.model.reset_hidden()

    def act_and_train(self, observation: Any, reward: float):
        """
        Select action based on current observation and record reward, log probability,
        and entropy for the episode.
        """
        state_batch = batch_states(observation, self.phi)
        dist_obj = self.model(state_batch)

        if not isinstance(dist_obj, dist.Distribution):
            raise TypeError("Policy model must return a torch.distributions.Distribution")

        if self.act_deterministically:
            action = torch.argmax(dist_obj.probs, dim=-1)
        else:
            action = dist_obj.sample()

        log_prob = dist_obj.log_prob(action).detach()
        entropy = dist_obj.entropy().item()

        if not self.reward_sequences:
            self.reward_sequences.append([])
            self.log_prob_sequences.append([])
            self.entropy_sequences.append([])

        self.reward_sequences[-1].append(reward)
        self.log_prob_sequences[-1].append(log_prob)
        self.entropy_sequences[-1].append(entropy)

        self.t += 1
        logger.debug(
            f"Step {self.t}: reward={reward:.4f}, log_prob={log_prob:.4f}, entropy={entropy:.4f}"
        )

    def stop_episode_and_train(self, done: bool):
        """
        Handle episode termination and trigger training if needed.
        """
        if not done:
            logger.warning("Episode terminated without being marked as done.")
            # Clear unfinished episode data
            if self.reward_sequences:
                self.reward_sequences.pop()
                self.log_prob_sequences.pop()
                self.entropy_sequences.pop()
            return

        # Append final reward (assuming last reward already appended in act_and_train)
        # No action needed; data already stored.

        if self.backward_separately:
            self.accumulate_grad()
            self.n_backward = 0
        else:
            self.n_backward += 1
            if self.n_backward >= self.batchsize:
                self.batch_update()

        if hasattr(self.model, "reset_hidden"):
            self.model.reset_hidden()

    def accumulate_grad(self):
        """
        Compute gradients for the collected episodes and perform backward pass.
        """
        self.optimizer.zero_grad()
        total_loss = 0.0

        for episode_idx in range(len(self.reward_sequences)):
            rewards = self.reward_sequences[episode_idx]
            log_probs = self.log_prob_sequences[episode_idx]
            entropies = self.entropy_sequences[episode_idx]

            returns = []
            G = 0.0
            for r in reversed(rewards):
                G = r + G
                returns.insert(0, G)

            episode_loss = 0.0
            for ret, logp, ent in zip(returns, log_probs, entropies):
                episode_loss += -ret * logp - self.beta * ent

            total_loss += episode_loss

        total_loss = total_loss / self.batchsize
        total_loss.backward()
        self.optimizer.step()

        # Reset sequences
        self.reward_sequences = []
        self.log_prob_sequences = []
        self.entropy_sequences = []

    def batch_update(self):
        """
        Trigger a batch update after collecting `batchsize` episodes.
        """
        self.accumulate_grad()
        self.n_backward = 0

    def stop_episode(self):
        """
        Reset model hidden state if recurrent after an episode.
        """
        if hasattr(self.model, "reset_hidden"):
            self.model.reset_hidden()

    def get_statistics(self) -> dict:
        """
        Return current statistics, e.g., running average entropy.
        """
        if self.entropy_sequences:
            # Average entropy of the last episode
            last_entropy = sum(self.entropy_sequences[-1]) / len(self.entropy_sequences[-1])
            self.average_entropy = (
                self.average_entropy * self.average_entropy_decay
                + last_entropy * (1 - self.average_entropy_decay)
            )
        return {"average_entropy": self.average_entropy}


# Example policy model for demonstration purposes
class PolicyNetwork(nn.Module):
    def __init__(self, state_dim: int, action_dim: int):
        super().__init__()
        self.fc = nn.Linear(state_dim, 128)
        self.logits = nn.Linear(128, action_dim)

    def forward(self, x: torch.Tensor) -> dist.Categorical:
        x = torch.relu(self.fc(x))
        logits = self.logits(x)
        return dist.Categorical(logits=logits)

    def reset_hidden(self):
        pass  # No hidden state in this example


# Usage example (would normally be in a separate training script)
if __name__ == "__main__":
    state_dim = 4
    action_dim = 2
    policy = PolicyNetwork(state_dim, action_dim)
    opt = optim.Adam(policy.parameters(), lr=1e-3)

    reinforce = REINFORCE(
        model=policy,
        optimizer=opt,
        beta=0.01,
        batchsize=5,
        act_deterministically=False,
    )

    # Dummy loop for demonstration
    for episode in range(10):
        state = torch.randn(state_dim)
        done = False
        for step in range(20):
            reward = torch.randn(1).item()
            reinforce.act_and_train(state, reward)
            if step == 19:
                done = True
            reinforce.stop_episode_and_train(done)
        stats = reinforce.get_statistics()
        print(f"Episode {episode + 1}, avg_entropy: {stats['average_entropy']:.4f}")