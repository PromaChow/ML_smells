import os
import sys
import time
import torch
import torch.distributed as dist
import torch.distributed.rpc as rpc
import torch.multiprocessing as mp

# Helper to ensure tests run only on Linux
def linux_only_forall():
    if sys.platform != "linux":
        raise RuntimeError("Tests require Linux platform")

# Global registry for services
_service_registry = {}

def _set_service(key, svc):
    _service_registry[key] = svc

# Worker service class
class WorkerService:
    def __init__(self):
        self.counter = 0

    def count(self):
        self.counter += 1
        return self.counter

    def get_count(self):
        return self.counter

# Simple calculation function
def worker_calculate(a, b):
    return a + b

# Decorator to run a function across multiple ranks
def run_multi(func):
    def wrapper(*args, **kwargs):
        results = []

        def run(rank):
            backend = "gloo"
            dist.init_process_group(backend=backend, rank=rank, world_size=3)
            rpc.init_rpc(f"worker{rank}", rank=rank, world_size=3)
            try:
                res = func(rank=rank, *args, **kwargs)
                results.append(res)
            finally:
                rpc.shutdown()
                dist.destroy_process_group()

        processes = []
        for r in range(3):
            p = mp.Process(target=run, args=(r,))
            p.start()
            processes.append(p)
        for p in processes:
            p.join()
        return results

    return wrapper

# Collective communication tests
@run_multi
def test_cc_send_recv(rank):
    linux_only_forall()
    group = dist.new_group(ranks=[0, 1, 2])
    if rank == 0:
        tensor = torch.tensor([0.0], dtype=torch.float32)
        for dst in [1, 2]:
            dist.send(tensor, dst=dst, group=group)
    else:
        recv_tensor = torch.empty(1)
        dist.recv(recv_tensor, src=0, group=group)
        assert torch.equal(recv_tensor, torch.tensor([0.0]))
    dist.barrier()
    group.destroy()
    return True

@run_multi
def test_cc_broadcast(rank):
    linux_only_forall()
    group = dist.new_group(ranks=[0, 1, 2])
    if rank == 0:
        tensor = torch.ones(3)
    else:
        tensor = torch.zeros(3)
    dist.broadcast(tensor, src=0, group=group)
    assert torch.all(tensor == 1.0)
    dist.barrier()
    group.destroy()
    return True

@run_multi
def test_cc_all_reduce(rank):
    linux_only_forall()
    group = dist.new_group(ranks=[0, 1, 2])
    tensor = torch.tensor([float(rank)])
    dist.all_reduce(tensor, op=dist.ReduceOp.SUM, group=group)
    assert torch.isclose(tensor, torch.tensor([3.0]))
    dist.barrier()
    group.destroy()
    return True

@run_multi
def test_cc_reduce(rank):
    linux_only_forall()
    group = dist.new_group(ranks=[0, 1, 2])
    tensor = torch.tensor([float(5 - rank)])
    if rank == 1:
        dist.reduce(tensor, dst=1, op=dist.ReduceOp.SUM, group=group)
        assert torch.isclose(tensor, torch.tensor([12.0]))
    else:
        dist.reduce(tensor, dst=1, op=dist.ReduceOp.SUM, group=group)
    dist.barrier()
    group.destroy()
    return True

@run_multi
def test_cc_all_gather(rank):
    linux_only_forall()
    group = dist.new_group(ranks=[0, 1, 2])
    tensor = torch.tensor([float(rank)])
    gathered = [torch.empty(1) for _ in range(3)]
    dist.all_gather(gathered, tensor, group=group)
    expected = [torch.tensor([0.0]), torch.tensor([1.0]), torch.tensor([2.0])]
    assert all(torch.equal(g, e) for g, e in zip(gathered, expected))
    dist.barrier()
    group.destroy()
    return True

@run_multi
def test_cc_scatter(rank):
    linux_only_forall()
    group = dist.new_group(ranks=[0, 1, 2])
    if rank == 0:
        scatter_list = [torch.tensor([0.0]), torch.tensor([1.0]), torch.tensor([2.0])]
    else:
        scatter_list = None
    recv_tensor = torch.empty(1)
    dist.scatter(recv_tensor, scatter_list, src=0, group=group)
    assert recv_tensor.item() in [0.0, 1.0, 2.0]
    dist.barrier()
    group.destroy()
    return True

@run_multi
def test_cc_barrier(rank):
    linux_only_forall()
    group = dist.new_group(ranks=[0, 1, 2])
    dist.barrier()
    group.destroy()
    return True

# RPC tests
@run_multi
def test_rpc_sync(rank):
    linux_only_forall()
    if rank == 1:
        result = rpc.rpc_sync('worker1', worker_calculate, args=(1, 2))
        assert result == 3
    dist.barrier()
    return True

@run_multi
def test_rpc_async(rank):
    linux_only_forall()
    if rank == 1:
        future = rpc.rpc_async('worker1', worker_calculate, args=(3, 4))
        result = future.wait()
        assert result == 7
    dist.barrier()
    return True

@run_multi
def test_rpc_remote(rank):
    linux_only_forall()
    if rank == 0:
        svc_handle = rpc.remote('worker1', WorkerService)
        rpc.rpc_sync('worker1', _set_service, args=('service', svc_handle))
    elif rank == 1:
        svc = _service_registry.get('service')
        if svc:
            count = svc.count()
            assert count == 1
            total = svc.get_count()
            assert total == 1
    dist.barrier()
    return True

@run_multi
def test_rpc_group_info(rank):
    linux_only_forall()
    size = rpc.get_group_size()
    is_member = rpc.get_worker_info().is_alive
    name = rpc.get_worker_info().name
    if rank == 0:
        assert size == 3
        assert is_member
        assert name == "worker0"
    dist.barrier()
    return True
```