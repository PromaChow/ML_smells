import gym
import numpy as np
import random
import pickle
import os
import multiprocessing
from dataclasses import dataclass, field
from typing import List, Tuple, Dict, Any

import torch
import torch.nn as nn
import torch.optim as optim


class ClipAction(gym.Wrapper):
    def __init__(self, env):
        super().__init__(env)

    def step(self, action):
        low, high = self.action_space.low, self.action_space.high
        action = np.clip(action, low, high)
        return self.env.step(action)


class NormalizeObservation(gym.Wrapper):
    def __init__(self, env, clip=5.0):
        super().__init__(env)
        self.clip = clip
        self.obs_mean = np.zeros(self.observation_space.shape, dtype=np.float32)
        self.obs_var = np.ones(self.observation_space.shape, dtype=np.float32)
        self.obs_count = 1e-4

    def reset(self, **kwargs):
        obs = self.env.reset(**kwargs)
        return self._normalize(obs)

    def step(self, action):
        obs, reward, done, info = self.env.step(action)
        return self._normalize(obs), reward, done, info

    def _normalize(self, obs):
        self.obs_count += 1
        delta = obs - self.obs_mean
        self.obs_mean += delta / self.obs_count
        delta2 = obs - self.obs_mean
        self.obs_var += delta * delta2
        mean = self.obs_mean
        std = np.sqrt(self.obs_var / self.obs_count)
        obs = (obs - mean) / (std + 1e-8)
        obs = np.clip(obs, -self.clip, self.clip)
        return obs


class NormalizeReward(gym.Wrapper):
    def __init__(self, env, gamma=0.99, clip=10.0):
        super().__init__(env)
        self.gamma = gamma
        self.clip = clip
        self.ret = 0.0
        self.r_mean = 0.0
        self.r_var = 1.0
        self.r_count = 1e-4

    def reset(self, **kwargs):
        self.ret = 0.0
        return self.env.reset(**kwargs)

    def step(self, action):
        obs, reward, done, info = self.env.step(action)
        self.ret = reward + self.gamma * self.ret
        self.r_count += 1
        delta = self.ret - self.r_mean
        self.r_mean += delta / self.r_count
        delta2 = self.ret - self.r_mean
        self.r_var += delta * delta2
        mean = self.r_mean
        std = np.sqrt(self.r_var / self.r_count)
        reward = (reward - mean) / (std + 1e-8)
        reward = np.clip(reward, -self.clip, self.clip)
        return obs, reward, done, info


class RecordEpisodeStatistics(gym.Wrapper):
    def __init__(self, env):
        super().__init__(env)
        self.episode_rewards = []
        self.episode_lengths = []
        self.current_reward = 0.0
        self.current_length = 0

    def reset(self, **kwargs):
        self.current_reward = 0.0
        self.current_length = 0
        return self.env.reset(**kwargs)

    def step(self, action):
        obs, reward, done, info = self.env.step(action)
        self.current_reward += reward
        self.current_length += 1
        if done:
            self.episode_rewards.append(self.current_reward)
            self.episode_lengths.append(self.current_length)
            self.current_reward = 0.0
            self.current_length = 0
        return obs, reward, done, info


class TimeStepEnv(gym.Env):
    def __init__(self, env):
        super().__init__()
        self.env = env
        self.observation_space = env.observation_space
        self.action_space = env.action_space

    def reset(self, **kwargs):
        obs = self.env.reset(**kwargs)
        return obs, 0.0, False, {}

    def step(self, action):
        obs, reward, done, info = self.env.step(action)
        return obs, reward, done, info


def make_env(env_id: str,
             seed: int,
             normalize_obs: bool = True,
             normalize_reward: bool = True,
             clip_action: bool = True) -> gym.Env:
    env = gym.make(env_id)
    env.seed(seed)
    env.action_space.seed(seed)
    env.observation_space.seed(seed)
    if clip_action and isinstance(env.action_space, gym.spaces.Box):
        env = ClipAction(env)
    if normalize_obs:
        env = NormalizeObservation(env)
    if normalize_reward:
        env = NormalizeReward(env)
    env = RecordEpisodeStatistics(env)
    env = TimeStepEnv(env)
    return env


@dataclass
class Config:
    total_timesteps: int = int(1e6)
    timesteps_per_iter: int = 1000
    log_freq: int = 10
    checkpoints: int = 3
    env_ids: List[str] = field(default_factory=lambda: ["HalfCheetah-v3", "Hopper-v3", "Walker2d-v3"])
    normalize_obs: bool = True
    normalize_reward: bool = True
    clip_action: bool = True
    use_lstm_grid: List[bool] = field(default_factory=lambda: [True, False])
    rnn_size: int = 128
    hidden_sizes: List[int] = field(default_factory=lambda: [64, 64])
    lr: float = 1e-3
    entropy_coef: float = 0.01
    value_coef: float = 0.5
    grad_clip: float = 0.5
    action_clip: bool = True


class PolicyNetwork(nn.Module):
    def __init__(self, obs_dim: int, act_dim: int, hidden_sizes: List[int]):
        super().__init__()
        layers = []
        input_dim = obs_dim
        for h in hidden_sizes:
            layers.append(nn.Linear(input_dim, h))
            layers.append(nn.ReLU())
            input_dim = h
        layers.append(nn.Linear(input_dim, act_dim))
        self.mean_net = nn.Sequential(*layers)
        self.log_std = nn.Parameter(torch.zeros(act_dim))

    def forward(self, x):
        mean = self.mean_net(x)
        std = torch.exp(self.log_std)
        return mean, std


class ValueNetwork(nn.Module):
    def __init__(self, obs_dim: int, hidden_sizes: List[int]):
        super().__init__()
        layers = []
        input_dim = obs_dim
        for h in hidden_sizes:
            layers.append(nn.Linear(input_dim, h))
            layers.append(nn.ReLU())
            input_dim = h
        layers.append(nn.Linear(input_dim, 1))
        self.value_net = nn.Sequential(*layers)

    def forward(self, x):
        return self.value_net(x).squeeze(-1)


class LSTMAgent:
    def __init__(self, config: Config, env: gym.Env):
        obs_dim = env.observation_space.shape[0]
        act_dim = env.action_space.shape[0]
        self.policy = PolicyNetwork(obs_dim, act_dim, config.hidden_sizes)
        self.value = ValueNetwork(obs_dim, config.hidden_sizes)
        self.rnn = nn.LSTM(obs_dim + act_dim, config.rnn_size, batch_first=True)
        self.optimizer = optim.Adam(list(self.policy.parameters()) +
                                    list(self.value.parameters()) +
                                    list(self.rnn.parameters()), lr=config.lr)
        self.entropy_coef = config.entropy_coef
        self.value_coef = config.value_coef
        self.grad_clip = config.grad_clip
        self.device = torch.device("cpu")

    def act(self, obs, hidden):
        obs_tensor = torch.tensor(obs, dtype=torch.float32).unsqueeze(0).to(self.device)
        mean, std = self.policy(obs_tensor)
        dist = torch.distributions.Normal(mean, std)
        action = dist.sample()
        logp = dist.log_prob(action).sum(-1)
        value = self.value(obs_tensor)
        if self.rnn is not None:
            rnn_input = torch.cat([obs_tensor, action], dim=-1)
            output, hidden = self.rnn(rnn_input.unsqueeze(1), hidden)
        else:
            hidden = None
        return action.squeeze(0).cpu().numpy(), logp.item(), value.item(), hidden

    def train(self, trajectories: List[Dict[str, Any]]):
        obs = torch.tensor(np.array([t["obs"] for t in trajectories]), dtype=torch.float32)
        actions = torch.tensor(np.array([t["action"] for t in trajectories]), dtype=torch.float32)
        rewards = [t["reward"] for t in trajectories]
        logp = torch.tensor([t["logp"] for t in trajectories], dtype=torch.float32)
        values = torch.tensor([t["value"] for t in trajectories], dtype=torch.float32)
        returns = []
        G = 0.0
        for r in reversed(rewards):
            G = r + 0.99 * G
            returns.insert(0, G)
        returns = torch.tensor(returns, dtype=torch.float32)
        advantages = returns - values
        mean, std = self.policy(obs)
        dist = torch.distributions.Normal(mean, std)
        new_logp = dist.log_prob(actions).sum(-1)
        ratio = torch.exp(new_logp - logp)
        policy_loss = -(ratio * advantages.detach()).mean()
        entropy = dist.entropy().sum(-1).mean()
        value_loss = self.value_coef * (returns - values).pow(2).mean()
        loss = policy_loss - self.entropy_coef * entropy + value_loss
        self.optimizer.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(list(self.policy.parameters()) +
                                 list(self.value.parameters()) +
                                 list(self.rnn.parameters()), self.grad_clip)
        self.optimizer.step()
        return {
            "policy_loss": policy_loss.item(),
            "value_loss": value_loss.item(),
            "entropy": entropy.item(),
        }


class Agent:
    def __init__(self, config: Config, env: gym.Env):
        obs_dim = env.observation_space.shape[0]
        act_dim = env.action_space.shape[0]
        self.policy = PolicyNetwork(obs_dim, act_dim, config.hidden_sizes)
        self.value = ValueNetwork(obs_dim, config.hidden_sizes)
        self.optimizer = optim.Adam(list(self.policy.parameters()) +
                                    list(self.value.parameters()), lr=config.lr)
        self.entropy_coef = config.entropy_coef
        self.value_coef = config.value_coef
        self.grad_clip = config.grad_clip
        self.device = torch.device("cpu")

    def act(self, obs):
        obs_tensor = torch.tensor(obs, dtype=torch.float32).unsqueeze(0).to(self.device)
        mean, std = self.policy(obs_tensor)
        dist = torch.distributions.Normal(mean, std)
        action = dist.sample()
        logp = dist.log_prob(action).sum(-1)
        value = self.value(obs_tensor)
        return action.squeeze(0).cpu().numpy(), logp.item(), value.item()

    def train(self, trajectories: List[Dict[str, Any]]):
        obs = torch.tensor(np.array([t["obs"] for t in trajectories]), dtype=torch.float32)
        actions = torch.tensor(np.array([t["action"] for t in trajectories]), dtype=torch.float32)
        rewards = [t["reward"] for t in trajectories]
        logp = torch.tensor([t["logp"] for t in trajectories], dtype=torch.float32)
        values = torch.tensor([t["value"] for t in trajectories], dtype=torch.float32)
        returns = []
        G = 0.0
        for r in reversed(rewards):
            G = r + 0.99 * G
            returns.insert(0, G)
        returns = torch.tensor(returns, dtype=torch.float32)
        advantages = returns - values
        mean, std = self.policy(obs)
        dist = torch.distributions.Normal(mean, std)
        new_logp = dist.log_prob(actions).sum(-1)
        ratio = torch.exp(new_logp - logp)
        policy_loss = -(ratio * advantages.detach()).mean()
        entropy = dist.entropy().sum(-1).mean()
        value_loss = self.value_coef * (returns - values).pow(2).mean()
        loss = policy_loss - self.entropy_coef * entropy + value_loss
        self.optimizer.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(list(self.policy.parameters()) +
                                 list(self.value.parameters()), self.grad_clip)
        self.optimizer.step()
        return {
            "policy_loss": policy_loss.item(),
            "value_loss": value_loss.item(),
            "entropy": entropy.item(),
        }


def run(config: Config, seeds: List[int], log_dir: str):
    os.makedirs(log_dir, exist_ok=True)
    np.random.seed(seeds[0])
    random.seed(seeds[0])
    torch.manual_seed(seeds[0])
    env = make_env(config.env_ids[0], seeds[0],
                   normalize_obs=config.normalize_obs,
                   normalize_reward=config.normalize_reward,
                   clip_action=config.clip_action)
    agent_cls = LSTMAgent if config.use_lstm_grid[0] else Agent
    agent = agent_cls(config, env)
    timesteps_done = 0
    logs = []
    checkpoints = np.linspace(0, config.total_timesteps, config.checkpoints + 1)[1:]
    next_checkpoint = checkpoints[0] if checkpoints.size > 0 else config.total_timesteps
    hidden = None
    while timesteps_done < config.total_timesteps:
        batch = []
        steps = 0
        while steps < config.timesteps_per_iter and timesteps_done < config.total_timesteps:
            obs, _, done, _ = env.reset() if steps == 0 else env.step(action)
            if isinstance(agent, LSTMAgent):
                action, logp, value, hidden = agent.act(obs, hidden)
            else:
                action, logp, value = agent.act(obs)
            next_obs, reward, done, _ = env.step(action)
            batch.append({
                "obs": obs,
                "action": action,
                "reward": reward,
                "logp": logp,
                "value": value,
            })
            obs = next_obs
            steps += 1
            timesteps_done += 1
            if done:
                obs, _, _, _ = env.reset()
                steps = 0
        loss_dict = agent.train(batch)
        logs.append({
            "timesteps": timesteps_done,
            "policy_loss": loss_dict["policy_loss"],
            "value_loss": loss_dict["value_loss"],
            "entropy": loss_dict["entropy"],
        })
        if timesteps_done % config.log_freq == 0:
            print(f"Timesteps {timesteps_done}: Policy loss {loss_dict['policy_loss']:.4f}, "
                  f"Value loss {loss_dict['value_loss']:.4f}, Entropy {loss_dict['entropy']:.4f}")
        if timesteps_done >= next_checkpoint:
            ckpt_path = os.path.join(log_dir, f"checkpoint_{int(timesteps_done)}.pth")
            torch.save({
                "policy_state": agent.policy.state_dict(),
                "value_state": agent.value.state_dict(),
                "optimizer_state": agent.optimizer.state_dict(),
            }, ckpt_path)
            print(f"Saved checkpoint at {timesteps_done} timesteps to {ckpt_path}")
            next_checkpoint = checkpoints[config.checkpoints.tolist().index(next_checkpoint) + 1] \
                if config.checkpoints.tolist().index(next_checkpoint) + 1 < len(checkpoints) \
                else config.total_timesteps
    log_path = os.path.join(log_dir, "training_logs.pkl")
    with open(log_path, "wb") as f:
        pickle.dump(logs, f)
    print(f"Training completed. Logs saved to {log_path}")


def run_experiment(config: Config, seeds: List[int], log_dir: str):
    workers = multiprocessing.cpu_count()
    with multiprocessing.Pool(processes=workers) as pool:
        results = [pool.apply_async(run, args=(config, [seed], log_dir)) for seed in seeds]
        for r in results:
            r.wait()


if __name__ == "__main__":
    config = Config()
    seeds = [1770966829, 1500925526, 2054191100]
    log_dir = "logs/default"
    run_experiment(config, seeds, log_dir)