import torch
import torch.nn as nn
from torch.distributions import Beta

class MixMatch(nn.Module):
    def __init__(self, temperature: float, K: int, alpha: float):
        super().__init__()
        self.temperature = temperature
        self.K = K
        self.alpha = alpha

    def sharpen(self, logits: torch.Tensor) -> torch.Tensor:
        logits = logits.pow(1.0 / self.temperature)
        return logits / logits.sum(dim=1, keepdim=True)

    def forward(self, model: nn.Module, x: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        # Disable batch normalization updates
        if hasattr(model, "update_batch_stats"):
            model.update_batch_stats(False)

        # Extract unlabeled data
        u_x = x[mask]

        # Augmentation and prediction
        u_x_hat = [u_x.clone() for _ in range(self.K)]
        preds = []
        for aug_x in u_x_hat:
            logits = model(aug_x)
            preds.append(nn.functional.softmax(logits, dim=1))
        y_hat = torch.mean(torch.stack(preds), dim=0)
        y_sharp = self.sharpen(y_hat)

        # Mixup preparation
        y_sharp_rep = [y_sharp for _ in range(self.K)]
        all_x = torch.cat(u_x_hat, dim=0)
        all_y = torch.cat(y_sharp_rep, dim=0)

        # Shuffle
        idx = torch.randperm(all_x.size(0))
        shuffled_x = all_x[idx]
        shuffled_y = all_y[idx]

        # Sample mixup coefficient
        lam = Beta(self.alpha, self.alpha).sample().item()
        lam = max(lam, 1 - lam)  # Optional symmetric mixing

        # Mixup application
        mixed_x = lam * all_x + (1.0 - lam) * shuffled_x
        mixed_y = lam * all_y + (1.0 - lam) * shuffled_y

        # Loss calculation
        logits_mixed = model(mixed_x)
        loss = nn.functional.mse_loss(logits_mixed, mixed_y, reduction='mean')

        # Re-enable batch normalization updates
        if hasattr(model, "update_batch_stats"):
            model.update_batch_stats(True)

        return loss
