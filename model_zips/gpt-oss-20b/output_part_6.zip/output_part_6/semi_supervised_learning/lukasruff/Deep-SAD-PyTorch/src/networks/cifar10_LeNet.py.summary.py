import torch
import torch.nn as nn
import torch.nn.functional as F


class CIFAR10_LeNet(nn.Module):
    def __init__(self, rep_dim: int = 128):
        super().__init__()
        self.rep_dim = rep_dim

        self.maxpool = nn.MaxPool2d(2, 2)

        self.conv1 = nn.Conv2d(3, 32, kernel_size=5, padding=2, bias=False)
        self.bn2d1 = nn.BatchNorm2d(32, eps=1e-04, affine=False)

        self.conv2 = nn.Conv2d(32, 64, kernel_size=5, padding=2, bias=False)
        self.bn2d2 = nn.BatchNorm2d(64, eps=1e-04, affine=False)

        self.conv3 = nn.Conv2d(64, 128, kernel_size=5, padding=2, bias=False)
        self.bn2d3 = nn.BatchNorm2d(128, eps=1e-04, affine=False)

        self.fc1 = nn.Linear(128 * 4 * 4, rep_dim, bias=False)

        self.leaky_relu = nn.LeakyReLU()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x.view(-1, 3, 32, 32)

        x = self.conv1(x)
        x = self.bn2d1(x)
        x = self.leaky_relu(x)
        x = self.maxpool(x)

        x = self.conv2(x)
        x = self.bn2d2(x)
        x = self.leaky_relu(x)
        x = self.maxpool(x)

        x = self.conv3(x)
        x = self.bn2d3(x)
        x = self.leaky_relu(x)
        x = self.maxpool(x)

        x = torch.flatten(x, 1)
        z = self.fc1(x)
        return z


class CIFAR10_LeNet_Decoder(nn.Module):
    def __init__(self, rep_dim: int = 128):
        super().__init__()
        self.rep_dim = rep_dim
        self.channels = rep_dim // (4 * 4)

        self.deconv1 = nn.ConvTranspose2d(self.channels, 128, kernel_size=5, padding=2, bias=False)
        self.bn2d4 = nn.BatchNorm2d(128, eps=1e-04, affine=False)

        self.deconv2 = nn.ConvTranspose2d(128, 64, kernel_size=5, padding=2, bias=False)
        self.bn2d5 = nn.BatchNorm2d(64, eps=1e-04, affine=False)

        self.deconv3 = nn.ConvTranspose2d(64, 32, kernel_size=5, padding=2, bias=False)
        self.bn2d6 = nn.BatchNorm2d(32, eps=1e-04, affine=False)

        self.deconv4 = nn.ConvTranspose2d(32, 3, kernel_size=5, padding=2, bias=False)

        self.leaky_relu = nn.LeakyReLU()

        for m in [self.deconv1, self.deconv2, self.deconv3, self.deconv4]:
            nn.init.xavier_uniform_(m.weight, gain=nn.init.calculate_gain('leaky_relu'))

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        x = z.view(-1, self.channels, 4, 4)
        x = self.leaky_relu(x)

        x = self.deconv1(x)
        x = self.bn2d4(x)
        x = self.leaky_relu(x)
        x = F.interpolate(x, scale_factor=2, mode='nearest')

        x = self.deconv2(x)
        x = self.bn2d5(x)
        x = self.leaky_relu(x)
        x = F.interpolate(x, scale_factor=2, mode='nearest')

        x = self.deconv3(x)
        x = self.bn2d6(x)
        x = self.leaky_relu(x)
        x = F.interpolate(x, scale_factor=2, mode='nearest')

        x = self.deconv4(x)

        out = torch.sigmoid(x)
        return out


class CIFAR10_LeNet_Autoencoder(nn.Module):
    def __init__(self, rep_dim: int = 128):
        super().__init__()
        self.encoder = CIFAR10_LeNet(rep_dim)
        self.decoder = CIFAR10_LeNet_Decoder(rep_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        z = self.encoder(x)
        recon = self.decoder(z)
        return recon

if __name__ == "__main__":
    model = CIFAR10_LeNet_Autoencoder()
    dummy = torch.randn(4, 3, 32, 32)
    out = model(dummy)
    print(out.shape)  # should be (4, 3, 32, 32)