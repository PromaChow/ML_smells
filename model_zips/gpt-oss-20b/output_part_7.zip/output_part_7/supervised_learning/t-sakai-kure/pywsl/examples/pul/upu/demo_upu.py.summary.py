import numpy as np
from sklearn.model_selection import GridSearchCV
from pywsl.pul.pu_mr import PU_SL, gen_twonorm_pu, bin_clf_err

# Data generation
x, y, x_t, y_t = gen_twonorm_pu(
    n_p=30,
    n_u=200,
    prior_u=0.5,
    n_t=100
)

# Parameter setup
lambda_list = np.logspace(-3, 1, 5)
param_grid = {
    'prior': [0.5],
    'lam': lambda_list,
    'basis': ['lm']
}

# Grid search with cross-validation
grid_search = GridSearchCV(
    estimator=PU_SL(),
    param_grid=param_grid,
    cv=5,
    n_jobs=-1
)
grid_search.fit(x, y)

# Prediction and evaluation
y_h = grid_search.best_estimator_.predict(x_t)
error = bin_clf_err(y_t, y_h, 0.5)
print(f"MR: {error * 100:.2f}%")