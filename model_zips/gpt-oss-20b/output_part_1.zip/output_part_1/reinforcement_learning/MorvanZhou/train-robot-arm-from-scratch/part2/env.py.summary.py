import pyglet
from pyglet import shapes

class Viewer(pyglet.window.Window):
    def __init__(self, *args, **kwargs):
        super().__init__(width=400, height=400, caption="Arm", vsync=False, *args, **kwargs)
        self.batch = pyglet.graphics.Batch()
        # Define a point (square)
        self.point = shapes.Rectangle(200, 200, 10, 10, color=(255, 0, 0), batch=self.batch)
        # Define two arms (squares)
        self.arm1 = shapes.Rectangle(150, 150, 20, 20, color=(0, 255, 0), batch=self.batch)
        self.arm2 = shapes.Rectangle(250, 150, 20, 20, color=(0, 0, 255), batch=self.batch)

    def render(self):
        self._update_arm()
        self.switch_to()
        self.dispatch_events()
        self.dispatch_event('on_draw')
        self.flip()

    def on_draw(self):
        self.clear()
        self.batch.draw()

    def _update_arm(self):
        pass

class ArmEnv:
    def __init__(self):
        self.viewer = None

    def __init__(self):
        pass

    def step(self, action):
        pass

    def reset(self):
        pass

    def render(self):
        if self.viewer is None:
            self.viewer = Viewer()
        self.viewer.render()

if __name__ == "__main__":
    env = ArmEnv()
    while True:
        env.render()
