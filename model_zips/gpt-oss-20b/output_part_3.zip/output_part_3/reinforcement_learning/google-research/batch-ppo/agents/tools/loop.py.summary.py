import os
import collections
import tensorflow.compat.v1 as tf
from typing import Callable, Dict, List, Optional, Tuple

tf.disable_eager_execution()


class StreamingMean:
    """Simple streaming mean calculator."""
    def __init__(self):
        self.count = 0
        self.total = 0.0

    def update(self, value: float):
        self.total += value
        self.count += 1

    @property
    def mean(self) -> float:
        return self.total / self.count if self.count else 0.0


class _Phase:
    def __init__(
        self,
        name: str,
        done: tf.Tensor,
        score: tf.Tensor,
        summary: tf.Tensor,
        steps: int,
        report_every: int,
        log_every: int,
        checkpoint_every: int,
        feed: Optional[Dict[tf.Tensor, tf.Tensor]] = None,
        reset: Optional[tf.Tensor] = None,
        op: Optional[tf.Operation] = None,
    ):
        self.name = name
        self.done = done
        self.score = score
        self.summary = summary
        self.steps = steps
        self.report_every = report_every
        self.log_every = log_every
        self.checkpoint_every = checkpoint_every
        self.feed = feed or {}
        self.reset = reset
        self.op = op
        self.writer = tf.summary.FileWriter(
            os.path.join(self.log_dir, self.name), tf.get_default_graph()
        )


class Loop:
    def __init__(
        self,
        log_dir: str,
        global_step: tf.Variable,
        saver: Optional[tf.train.Saver] = None,
        reset: Optional[tf.Tensor] = None,
    ):
        self.log_dir = log_dir
        self.global_step = global_step
        self.saver = saver
        self.reset = reset
        self.phases: List[_Phase] = []

    def add_phase(
        self,
        name: str,
        done: tf.Tensor,
        score: tf.Tensor,
        summary: tf.Tensor,
        steps: int,
        report_every: int,
        log_every: int,
        checkpoint_every: int,
        feed: Optional[Dict[tf.Tensor, tf.Tensor]] = None,
        op: Optional[tf.Operation] = None,
    ):
        if done.shape.rank != 0:
            raise ValueError(f"Done tensor for phase '{name}' must be scalar")
        if score.shape.rank != 0:
            raise ValueError(f"Score tensor for phase '{name}' must be scalar")
        phase = _Phase(
            name=name,
            done=done,
            score=score,
            summary=summary,
            steps=steps,
            report_every=report_every,
            log_every=log_every,
            checkpoint_every=checkpoint_every,
            feed=feed,
            reset=self.reset,
            op=op,
        )
        phase.log_dir = self.log_dir
        self.phases.append(phase)

    def _find_current_phase(self, step: int) -> Tuple[int, int]:
        cumulative = 0
        for i, phase in enumerate(self.phases):
            cumulative += phase.steps
            if step < cumulative:
                step_in_phase = step - (cumulative - phase.steps)
                return i, step_in_phase
        return len(self.phases) - 1, self.phases[-1].steps

    def _is_every_steps(self, step: int, interval: int) -> bool:
        return interval > 0 and step > 0 and step % interval == 0

    def run(self, max_steps: int):
        with tf.Session() as sess:
            sess.run(tf.global_variables_initializer())
            if self.saver:
                checkpoint_path = os.path.join(self.log_dir, "model")
                if tf.train.checkpoint_exists(checkpoint_path):
                    self.saver.restore(sess, checkpoint_path)
            while sess.run(self.global_step) < max_steps:
                global_step_val = sess.run(self.global_step)
                phase_idx, step_in_phase = self._find_current_phase(global_step_val)
                phase = self.phases[phase_idx]
                # Determine if we need to reset
                feed_dict = phase.feed.copy()
                if phase.reset is not None:
                    feed_dict[phase.reset] = step_in_phase == 0
                # Run the phase operation
                if phase.op is not None:
                    sess.run(phase.op, feed_dict=feed_dict)
                # Update global step
                sess.run(self.global_step.assign_add(1))
                # Compute and record score
                score_val = sess.run(phase.score, feed_dict=feed_dict)
                phase.stream_mean.update(score_val)
                # Logging
                if self._is_every_steps(
                    sess.run(self.global_step), phase.log_every
                ):
                    summary_str = sess.run(phase.summary, feed_dict=feed_dict)
                    phase.writer.add_summary(summary_str, sess.run(self.global_step))
                # Reporting
                if self._is_every_steps(
                    sess.run(self.global_step), phase.report_every
                ):
                    yield {
                        "phase": phase.name,
                        "step": sess.run(self.global_step),
                        "score_mean": phase.stream_mean.mean,
                    }
                # Checkpointing
                if self._is_every_steps(
                    sess.run(self.global_step), phase.checkpoint_every
                ):
                    os.makedirs(self.log_dir, exist_ok=True)
                    if self.saver:
                        self.saver.save(
                            sess,
                            os.path.join(self.log_dir, "model"),
                            global_step=sess.run(self.global_step),
                        )
```