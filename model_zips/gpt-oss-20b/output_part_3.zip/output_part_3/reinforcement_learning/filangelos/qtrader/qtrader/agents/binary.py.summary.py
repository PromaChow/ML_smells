import random
import numpy as np

class RandomOneHotAgent:
    def __init__(self, action_space):
        self.N = action_space.shape[0]

    def act(self, observation=None):
        b = random.randint(0, self.N - 1)
        c = np.zeros(self.N, dtype=int)
        c[b] = 1
        return c

if __name__ == "__main__":
    dummy_action_space = np.zeros((5, 3))
    agent = RandomOneHotAgent(dummy_action_space)
    for _ in range(10):
        print(agent.act())