import torch
import torch.nn as nn
import torch.nn.functional as F
import urllib.request
import os
import tempfile
import pickle

# Helper function to map string identifiers to activation modules
def act_fun(name):
    name = name.lower()
    if name == "relu":
        return nn.ReLU(inplace=True)
    if name == "leakyrelu":
        return nn.LeakyReLU(negative_slope=0.01, inplace=True)
    if name == "tanh":
        return nn.Tanh()
    if name == "sigmoid":
        return nn.Sigmoid()
    if name == "elu":
        return nn.ELU()
    if name == "gelu":
        return nn.GELU()
    raise ValueError(f"Unsupported activation function: {name}")

# LayerNorm implementation with learnable gamma and beta
class LayerNorm(nn.Module):
    def __init__(self, normalized_shape, eps=1e-5):
        super().__init__()
        self.gamma = nn.Parameter(torch.ones(normalized_shape))
        self.beta = nn.Parameter(torch.zeros(normalized_shape))
        self.eps = eps

    def forward(self, x):
        mean = x.mean(-1, keepdim=True)
        var = x.var(-1, unbiased=False, keepdim=True)
        x_norm = (x - mean) / torch.sqrt(var + self.eps)
        return self.gamma * x_norm + self.beta

# Multi-Layer Perceptron (MLP) Module
class MLP(nn.Module):
    def __init__(self, input_dim, options):
        super().__init__()
        self.input_dim = input_dim
        self.options = options

        # Input normalization
        self.input_norm = None
        if options.get("fc_use_laynorm_inp", False):
            self.input_norm = LayerNorm(input_dim)
        elif options.get("fc_use_batchnorm_inp", False):
            self.input_norm = nn.BatchNorm1d(input_dim)

        # Build layers
        self.layers = nn.ModuleList()
        self.norms = nn.ModuleList()
        self.activations = nn.ModuleList()
        self.dropouts = nn.ModuleList()

        hidden_sizes = options.get("fc_lay", [])
        dropouts = options.get("fc_drop", [])
        acts = options.get("fc_act", [])
        use_laynorm = options.get("fc_use_laynorm", False)
        use_batchnorm = options.get("fc_use_batchnorm", False)

        prev_dim = input_dim
        for i, hidden_dim in enumerate(hidden_sizes):
            linear = nn.Linear(prev_dim, hidden_dim)
            nn.init.uniform_(linear.weight, -0.01, 0.01)
            nn.init.constant_(linear.bias, 0.0)
            self.layers.append(linear)

            # Normalization after linear
            norm = None
            if use_laynorm:
                norm = LayerNorm(hidden_dim)
            elif use_batchnorm:
                norm = nn.BatchNorm1d(hidden_dim)
            self.norms.append(norm)

            # Activation
            act_name = acts[i] if i < len(acts) else "relu"
            self.activations.append(act_fun(act_name))

            # Dropout
            drop_rate = dropouts[i] if i < len(dropouts) else 0.0
            self.dropouts.append(nn.Dropout(drop_rate))

            prev_dim = hidden_dim

    def forward(self, x):
        if self.input_norm is not None:
            x = self.input_norm(x)
        for linear, norm, act, drop in zip(self.layers, self.norms, self.activations, self.dropouts):
            x = linear(x)
            if norm is not None:
                x = norm(x)
            x = act(x)
            x = drop(x)
        return x

# Import SincConvLayer (assumed to be available)
try:
    from wavencoder.layers import SincConvLayer
except ImportError:
    # Dummy placeholder if the actual module is not available
    class SincConvLayer(nn.Module):
        def __init__(self, num_filters, filter_length, sample_rate):
            super().__init__()
            self.conv = nn.Conv1d(1, num_filters, filter_length, stride=1, padding=filter_length//2)

        def forward(self, x):
            return self.conv(x)

# SincNet-based CNN Module
class SincNetModel(nn.Module):
    def __init__(self, options):
        super().__init__()
        self.options = options
        self.fs = options.get("fs", 16000)
        self.input_dim = options.get("input_dim", None)

        # Input normalization
        self.input_norm = None
        if options.get("cnn_use_laynorm_inp", False):
            self.input_norm = LayerNorm(1)
        elif options.get("cnn_use_batchnorm_inp", False):
            self.input_norm = nn.BatchNorm1d(1)

        # Build convolutional layers
        self.conv_layers = nn.ModuleList()
        self.norms = nn.ModuleList()
        self.activations = nn.ModuleList()
        self.dropouts = nn.ModuleList()
        self.maxpools = nn.ModuleList()

        N_filt = options.get("cnn_N_filt", [])
        len_filt = options.get("cnn_len_filt", [])
        pool_len = options.get("cnn_max_pool_len", [])
        acts = options.get("cnn_act", [])
        dropouts = options.get("cnn_drop", [])
        use_laynorm = options.get("cnn_use_laynorm", False)
        use_batchnorm = options.get("cnn_use_batchnorm", False)

        in_channels = 1
        for i in range(len(N_filt)):
            if i == 0:
                conv = SincConvLayer(N_filt[i], len_filt[i], self.fs)
            else:
                conv = nn.Conv1d(in_channels, N_filt[i], len_filt[i], padding=len_filt[i]//2)
            self.conv_layers.append(conv)

            # Normalization after conv
            norm = None
            if use_laynorm:
                norm = LayerNorm(N_filt[i])
            elif use_batchnorm:
                norm = nn.BatchNorm1d(N_filt[i])
            self.norms.append(norm)

            # Activation
            act_name = acts[i] if i < len(acts) else "relu"
            self.activations.append(act_fun(act_name))

            # Dropout
            drop_rate = dropouts[i] if i < len(dropouts) else 0.0
            self.dropouts.append(nn.Dropout(drop_rate))

            # MaxPool
            self.maxpools.append(nn.MaxPool1d(pool_len[i]))

            in_channels = N_filt[i]

        # Feature dimension after flattening
        self.out_dim = None  # will be set in forward if needed

    def forward(self, x):
        # x shape: (batch, 1, seq_len)
        if self.input_norm is not None:
            x = self.input_norm(x)
        for conv, norm, act, drop, pool in zip(self.conv_layers, self.norms, self.activations, self.dropouts, self.maxpools):
            x = conv(x)
            if norm is not None:
                x = norm(x)
            x = act(x)
            x = drop(x)
            x = pool(x)
        x = x.view(x.size(0), -1)
        if self.out_dim is None:
            self.out_dim = x.size(1)
        return x

# Full SincNet model combining CNN and optional DNN
class SincNet(nn.Module):
    def __init__(self, only_cnn=False, pretrained=False, pretrained_path=None, device=None):
        super().__init__()
        self.only_cnn = only_cnn
        self.pretrained = pretrained
        self.pretrained_path = pretrained_path
        self.device = device or torch.device("cpu")

        # CNN configuration
        cnn_options = {
            "fs": 16000,
            "cnn_N_filt": [80, 60, 60],
            "cnn_len_filt": [251, 5, 5],
            "cnn_max_pool_len": [3, 3, 3],
            "cnn_use_laynorm": True,
            "cnn_use_batchnorm": False,
            "cnn_use_laynorm_inp": False,
            "cnn_use_batchnorm_inp": False,
            "cnn_act": ["relu", "relu", "relu"],
            "cnn_drop": [0.0, 0.0, 0.0],
            "input_dim": 3200  # 200 ms at 16 kHz
        }
        self.cnn = SincNetModel(cnn_options).to(self.device)

        # DNN configuration (if not only_cnn)
        if not self.only_cnn:
            dnn_options = {
                "fc_lay": [2048, 2048, 2048],
                "fc_drop": [0.0, 0.0, 0.0],
                "fc_use_batchnorm": True,
                "fc_use_laynorm": False,
                "fc_use_batchnorm_inp": True,
                "fc_use_laynorm_inp": False,
                "fc_act": ["leakyrelu", "leakyrelu", "leakyrelu"],
                "input_dim": self.cnn.out_dim  # will be set after first forward
            }
            self.dnn = MLP(self.cnn.out_dim, dnn_options).to(self.device)
            # Final classification layer
            self.classifier = nn.Linear(2048, 10).to(self.device)
        else:
            self.dnn = None
            self.classifier = None

        if self.pretrained:
            self._load_pretrained_weights()

    def _download_pretrained(self):
        url = "http://example.com/model_raw.pkl"
        tmp_path = tempfile.mktemp(suffix=".pkl")
        urllib.request.urlretrieve(url, tmp_path)
        return tmp_path

    def _load_pretrained_weights(self):
        if self.pretrained_path:
            checkpoint_path = self.pretrained_path
        else:
            checkpoint_path = self._download_pretrained()
        with open(checkpoint_path, "rb") as f:
            ckpt = pickle.load(f)
        if "CNN_model_par" in ckpt:
            self.cnn.load_state_dict(ckpt["CNN_model_par"], strict=False)
        if not self.only_cnn:
            if "DNN1_model_par" in ckpt:
                self.dnn.layers[0].load_state_dict(ckpt["DNN1_model_par"], strict=False)
            if "DNN2_model_par" in ckpt:
                self.dnn.layers[1].load_state_dict(ckpt["DNN2_model_par"], strict=False)
        if os.path.exists(checkpoint_path) and not self.pretrained_path:
            os.remove(checkpoint_path)

    def forward(self, x):
        # x shape: (batch, seq_len) or (batch, 1, seq_len)
        if x.dim() == 2:
            x = x.unsqueeze(1)
        x = x.to(self.device)
        features = self.cnn(x)
        if self.dnn is not None:
            # Ensure dnn input dimension matches after cnn forward
            if self.dnn.input_dim != features.size(1):
                self.dnn.input_dim = features.size(1)
                self.dnn.layers[0] = nn.Linear(features.size(1), self.dnn.layers[0].out_features).to(self.device)
            x = self.dnn(features)
            logits = self.classifier(x)
            probs = F.softmax(logits, dim=1)
            return probs
        else:
            return features

if __name__ == "__main__":
    # Example usage
    batch = torch.randn(4, 3200)  # 4 samples, 200ms at 16kHz
    model = SincNet(only_cnn=False, pretrained=False)
    output = model(batch)
    print(output.shape)  # Expected: (4, 10) if classification, else feature shape

