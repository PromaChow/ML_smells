import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import AdaBoostClassifier
from sklearn.metrics import accuracy_score

# Load data
df = pd.read_csv("letterCG.bin", delim_whitespace=True)

# Display first few rows
print(df.head())

# Preprocess data
cols_to_remove = ["Unnamed: 5", "Unnamed: 18", "yegvx"]
df.drop(columns=[c for c in cols_to_remove if c in df.columns], inplace=True)
df.fillna(0, inplace=True)

# Prepare features and target
first_col = df.columns[0]
X = df.drop(columns=[first_col, "Class"])
Y = df["Class"]

# Split into train and test sets
X_train, X_test, Y_train, Y_test = train_test_split(
    X, Y, test_size=0.30, random_state=42
)

# Function to train and evaluate AdaBoost with given depth
def evaluate_adaboost(depth):
    base_clf = DecisionTreeClassifier(max_depth=depth, random_state=42)
    ada = AdaBoostClassifier(
        base_estimator=base_clf,
        n_estimators=400,
        learning_rate=1,
        algorithm="SAMME",
        random_state=42
    )
    ada.fit(X_train, Y_train)
    predictions = ada.predict(X_test)
    acc = accuracy_score(Y_test, predictions)
    return acc

# First evaluation with max_depth = 1
acc_depth_1 = evaluate_adaboost(depth=1)
print(f"Accuracy with DecisionTree depth 1: {acc_depth_1:.4f}")

# Second evaluation with max_depth = 2
acc_depth_2 = evaluate_adaboost(depth=2)
print(f"Accuracy with DecisionTree depth 2: {acc_depth_2:.4f}")

# Comparison
diff = acc_depth_2 - acc_depth_1
print(f"Difference in accuracy: {diff:.4f}")