import numpy as np
from scipy import optimize

def optimizer(J, *args):
    def _optimizer(mu, Sigma, w0, short_sales):
        con_budget = {'type': 'eq', 'fun': lambda w: np.sum(w) - 1.0}
        bounds = [(0, None)] * len(w0) if short_sales else [(None, None)] * len(w0)
        results = optimize.minimize(
            J,
            w0,
            args=(mu, Sigma, w0, *args),
            constraints=con_budget,
            bounds=bounds,
            method='SLSQP'
        )
        if not results.success:
            raise BaseException(results.message)
        return results.x
    return _optimizer