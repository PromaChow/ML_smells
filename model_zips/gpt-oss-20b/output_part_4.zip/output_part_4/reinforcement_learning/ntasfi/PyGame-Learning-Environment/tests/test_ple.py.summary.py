import nose
import unittest
import numpy as np
from ple import PLE
from ple.games.catcher import Catcher
from ple.games.flappybird import FlappyBird
from ple.games.alien_invaders import AlienInvaders
from ple.games.galaxian import Galaxian
from ple.games.asteroids import Asteroids
from ple.games.color_ball import ColorBall
from ple.games.dodge_the_balls import DodgeTheBalls
from ple.games.pong import Pong
from ple.games.breakout import Breakout
from ple.games.catapult import Catapult

NUM_STEPS = 150


class NaiveAgent:
    def __init__(self, action_set):
        self.action_set = action_set

    def pickAction(self, reward, screenRGB):
        return np.random.choice(self.action_set)


class MyTestCase(unittest.TestCase):
    def run_a_game(self, game_instance):
        p = PLE(game_instance, fps=30, display_screen=True)
        agent = NaiveAgent(game_instance.getActionSet())
        p.init()
        reward = p.act(agent.action_set[0])
        for _ in range(NUM_STEPS):
            screenRGB = p.getScreenRGB()
            action = agent.pickAction(reward, screenRGB)
            reward = p.act(action)
            if p.game_over():
                p.restart()

    def test_catcher(self):
        g = Catcher()
        self.run_a_game(g)

    def test_flappybird(self):
        g = FlappyBird()
        self.run_a_game(g)

    def test_alien_invaders(self):
        g = AlienInvaders()
        self.run_a_game(g)

    def test_galaxian(self):
        g = Galaxian()
        self.run_a_game(g)

    def test_asteroids(self):
        g = Asteroids()
        self.run_a_game(g)

    def test_color_ball(self):
        g = ColorBall()
        self.run_a_game(g)

    def test_dodge_the_balls(self):
        g = DodgeTheBalls()
        self.run_a_game(g)

    def test_pong(self):
        g = Pong()
        self.run_a_game(g)

    def test_breakout(self):
        g = Breakout()
        self.run_a_game(g)

    def test_catapult(self):
        g = Catapult()
        self.run_a_game(g)

    def test_doom_not_defined(self):
        with self.assertRaises(NameError):
            _ = DoomWrapper  # noqa: F821


if __name__ == "__main__":
    nose.runmodule()