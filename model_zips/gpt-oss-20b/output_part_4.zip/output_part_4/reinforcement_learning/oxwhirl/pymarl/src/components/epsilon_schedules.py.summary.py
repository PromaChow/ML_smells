import numpy as np


class DecayThenFlatSchedule:
    def __init__(self, start, finish, time_length, decay="exp"):
        self.start = start
        self.finish = finish
        self.time_length = time_length
        self.decay = decay.lower()
        self.delta = (start - finish) / time_length if time_length != 0 else 0

        if self.decay == "exp":
            if finish > 0:
                self.exp_scaling = -time_length / np.log(finish)
            else:
                self.exp_scaling = 1.0
        else:
            self.exp_scaling = None

    def eval(self, T):
        if self.decay in ("lin", "linear"):
            value = self.start - self.delta * T
            return max(self.finish, value)
        elif self.decay == "exp":
            exp_val = np.exp(-T / self.exp_scaling)
            return min(self.start, max(self.finish, exp_val))
        else:
            raise ValueError(f"Unknown decay type: {self.decay}")