import math
import numpy as np
from PIL import Image

class GridImage:
    def __init__(self, ncol: int = 8, padding: int = 2, pad_value: float = 0):
        self.ncol = ncol
        self.padding = padding
        self.pad_value = pad_value
        self.x = None

    def add(self, data):
        data = np.array(data)
        if data.ndim == 2:  # [H, W]
            data = data.reshape(1, 1, data.shape[0], data.shape[1])
        elif data.ndim == 3:
            # Determine if shape is [C, H, W] or [H, W, C]
            if data.shape[0] in (1, 3):
                data = data.reshape(1, data.shape[0], data.shape[1], data.shape[2])
            else:
                # Assume [H, W, C] and transpose to [C, H, W]
                data = data.transpose(2, 0, 1).reshape(1, data.shape[2], data.shape[0], data.shape[1])
        elif data.ndim == 4:
            pass
        else:
            raise ValueError(f"Unsupported data shape: {data.shape}")

        # Ensure 3 channels
        if data.shape[1] == 1:
            data = np.repeat(data, 3, axis=1)

        if self.x is None:
            self.x = data
        else:
            self.x = np.concatenate([self.x, data], axis=0)

    def __call__(self):
        if self.x is None:
            raise ValueError("No images added to grid")

        N = self.x.shape[0]
        cols = min(self.ncol, N)
        rows = math.ceil(N / cols)

        img_H, img_W = self.x.shape[2], self.x.shape[3]
        H = img_H + self.padding
        W = img_W + self.padding

        grid_height = rows * H + self.padding
        grid_width = cols * W + self.padding

        grid = np.full((3, grid_height, grid_width), self.pad_value, dtype=float)

        for idx in range(N):
            r = idx // cols
            c = idx % cols
            start_h = r * H + self.padding
            end_h = start_h + img_H
            start_w = c * W + self.padding
            end_w = start_w + img_W
            grid[:, start_h:end_h, start_w:end_w] = self.x[idx]

        if grid.dtype == float:
            grid = grid * 255.0
        grid = grid.astype(np.uint8)
        grid = grid.transpose(1, 2, 0)  # [H, W, C]
        return Image.fromarray(grid)