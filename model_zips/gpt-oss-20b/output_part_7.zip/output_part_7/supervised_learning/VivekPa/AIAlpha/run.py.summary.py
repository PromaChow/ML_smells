import os
import pandas as pd
import numpy as np
from pathlib import Path
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import torch
import torch.nn as nn
import torch.optim as optim

# ----------------------------------------------------
# Utility functions
# ----------------------------------------------------
def ensure_dir(path):
    Path(path).mkdir(parents=True, exist_ok=True)

# ----------------------------------------------------
# BaseBars for bar generation
# ----------------------------------------------------
class BaseBars:
    @staticmethod
    def create_tick_bars(df, threshold, output_path):
        grouped = []
        for i in range(0, len(df), threshold):
            chunk = df.iloc[i:i+threshold]
            if not chunk.empty:
                grouped.append(chunk)
        result = pd.concat(grouped).reset_index(drop=True)
        result.to_csv(output_path, index=False)

    @staticmethod
    def create_dollar_bars(df, threshold, output_path):
        bars = []
        acc_value = 0
        current_bar = []
        for _, row in df.iterrows():
            current_bar.append(row)
            acc_value += row['price'] * row['volume']
            if acc_value >= threshold:
                bars.append(pd.DataFrame(current_bar))
                current_bar = []
                acc_value = 0
        if current_bar:
            bars.append(pd.DataFrame(current_bar))
        result = pd.concat(bars).reset_index(drop=True)
        result.to_csv(output_path, index=False)

    @staticmethod
    def create_volume_bars(df, threshold, output_path):
        bars = []
        acc_volume = 0
        current_bar = []
        for _, row in df.iterrows():
            current_bar.append(row)
            acc_volume += row['volume']
            if acc_volume >= threshold:
                bars.append(pd.DataFrame(current_bar))
                current_bar = []
                acc_volume = 0
        if current_bar:
            bars.append(pd.DataFrame(current_bar))
        result = pd.concat(bars).reset_index(drop=True)
        result.to_csv(output_path, index=False)

# ----------------------------------------------------
# DataProcessing for feature creation and splitting
# ----------------------------------------------------
class DataProcessing:
    def __init__(self, file_path, split_ratio=0.8):
        self.df = pd.read_csv(file_path)
        self.split_ratio = split_ratio

    def create_features(self, window_size, output_dir):
        X, y = [], []
        data = self.df.values
        for i in range(len(data) - window_size):
            X.append(data[i:i+window_size])
            y.append(data[i+window_size, 0])  # assume first column is target
        X = np.array(X)
        y = np.array(y)
        ensure_dir(output_dir)
        pd.DataFrame(X.reshape(X.shape[0], -1)).to_csv(os.path.join(output_dir, 'full_x.csv'), index=False)
        pd.DataFrame(y).to_csv(os.path.join(output_dir, 'full_y.csv'), index=False)

    def split_data(self, window_size, output_dir):
        df = pd.read_csv(os.path.join(output_dir, 'full_x.csv'), header=None)
        y = pd.read_csv(os.path.join(output_dir, 'full_y.csv'), header=None).values.ravel()
        X_train, X_test, y_train, y_test = train_test_split(df.values, y, test_size=1-self.split_ratio, random_state=42)
        ensure_dir(output_dir)
        pd.DataFrame(X_train).to_csv(os.path.join(output_dir, 'train_x.csv'), index=False)
        pd.DataFrame(y_train).to_csv(os.path.join(output_dir, 'train_y.csv'), index=False)
        pd.DataFrame(X_test).to_csv(os.path.join(output_dir, 'test_x.csv'), index=False)
        pd.DataFrame(y_test).to_csv(os.path.join(output_dir, 'test_y.csv'), index=False)

# ----------------------------------------------------
# AutoEncoder model
# ----------------------------------------------------
class AutoEncoder(nn.Module):
    def __init__(self, latent_dim, input_dim):
        super(AutoEncoder, self).__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 100),
            nn.ReLU(),
            nn.Linear(100, 50),
            nn.ReLU(),
            nn.Linear(50, latent_dim)
        )
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, 50),
            nn.ReLU(),
            nn.Linear(50, 50),
            nn.ReLU(),
            nn.Linear(50, 100),
            nn.ReLU(),
            nn.Linear(100, input_dim)
        )

    def forward(self, x):
        z = self.encoder(x)
        recon = self.decoder(z)
        return recon

# ----------------------------------------------------
# Random Forest wrapper
# ----------------------------------------------------
class RFModel:
    def __init__(self, input_dim):
        self.model = RandomForestClassifier(n_estimators=100, random_state=42)

    def train(self, X, y):
        self.model.fit(X, y)

    def test(self, X, y):
        return self.model.score(X, y)

# ----------------------------------------------------
# Main workflow
# ----------------------------------------------------
def main():
    raw_data_path = Path('sample_data/raw_data/price_vol.csv')
    processed_dir = Path('sample_data/processed_data/price_bars')
    ensure_dir(processed_dir)

    # Load raw data
    raw_df = pd.read_csv(raw_data_path)

    # 1. Tick bars
    tick_output = processed_dir / 'tick_bars.csv'
    BaseBars.create_tick_bars(raw_df, 10, tick_output)

    # 2. Dollar bars
    dollar_output = processed_dir / 'dollar_bars.csv'
    BaseBars.create_dollar_bars(raw_df, 20000, dollar_output)

    # 3. Volume bars
    volume_output = processed_dir / 'volume_bars.csv'
    BaseBars.create_volume_bars(raw_df, 50, volume_output)

    # 4. Data preprocessing
    data_proc = DataProcessing(dollar_output, split_ratio=0.8)
    autoencoder_data_dir = Path('sample_data/processed_data/autoencoder_data')
    data_proc.create_features(window_size=20, output_dir=autoencoder_data_dir)
    data_proc.split_data(window_size=1, output_dir=autoencoder_data_dir)

    # 5. Scaling
    scaler = MinMaxScaler(feature_range=(-1, 1))
    def load_and_scale(path):
        df = pd.read_csv(path)
        cols = df.columns[1:]  # exclude first column
        scaled = scaler.fit_transform(df[cols])
        scaled_df = pd.DataFrame(scaled, columns=cols)
        scaled_df.insert(0, df.columns[0], df.iloc[:, 0])
        return scaled_df

    train_x_path = autoencoder_data_dir / 'train_x.csv'
    train_y_path = autoencoder_data_dir / 'train_y.csv'
    test_x_path = autoencoder_data_dir / 'test_x.csv'
    test_y_path = autoencoder_data_dir / 'test_y.csv'

    train_x_scaled = load_and_scale(train_x_path)
    test_x_scaled = load_and_scale(test_x_path)

    train_x_scaled.to_csv(train_x_path, index=False)
    test_x_scaled.to_csv(test_x_path, index=False)

    # 6. Autoencoder training
    input_dim = train_x_scaled.shape[1] - 1  # exclude first column
    ae = AutoEncoder(latent_dim=20, input_dim=input_dim)
    criterion = nn.MSELoss()
    optimizer = optim.Adam(ae.parameters(), lr=1e-3)
    epochs = 20

    train_tensor = torch.tensor(train_x_scaled.iloc[:, 1:].values, dtype=torch.float32)
    for epoch in range(epochs):
        ae.train()
        optimizer.zero_grad()
        output = ae(train_tensor)
        loss = criterion(output, train_tensor)
        loss.backward()
        optimizer.step()

    torch.save(ae.state_dict(), 'autoencoder.pth')

    # 7. Encoding full data
    full_x_path = autoencoder_data_dir / 'full_x.csv'
    full_x = pd.read_csv(full_x_path)
    full_x_scaled = scaler.transform(full_x.iloc[:, 1:])
    full_x_scaled_df = pd.DataFrame(full_x_scaled, columns=full_x.columns[1:])
    full_x_scaled_df.insert(0, full_x.columns[0], full_x.iloc[:, 0])

    # Encode
    ae.eval()
    with torch.no_grad():
        encoded = ae.encoder(torch.tensor(full_x_scaled_df.iloc[:, 1:].values, dtype=torch.float32))
    encoded_df = pd.DataFrame(encoded.numpy())
    encoded_df.insert(0, full_x.columns[0], full_x.iloc[:, 0])
    nn_data_dir = Path('sample_data/processed_data/nn_data')
    ensure_dir(nn_data_dir)
    encoded_df.to_csv(nn_data_dir / 'full_x.csv', index=False)

    # 8. Label processing and final split
    labels_path = autoencoder_data_dir / 'full_y.csv'
    labels = pd.read_csv(labels_path).values.ravel()
    data_proc_final = DataProcessing(nn_data_dir / 'full_x.csv', split_ratio=0.8)
    data_proc_final.split_data(window_size=1, output_dir=Path('sample_data/processed_data/rf_data'))

    # 9. Random Forest training
    rf_train_x_path = Path('sample_data/processed_data/rf_data/train_x.csv')
    rf_train_y_path = Path('sample_data/processed_data/rf_data/train_y.csv')
    rf_test_x_path = Path('sample_data/processed_data/rf_data/test_x.csv')
    rf_test_y_path = Path('sample_data/processed_data/rf_data/test_y.csv')

    rf_train_x = pd.read_csv(rf_train_x_path)
    rf_train_y = pd.read_csv(rf_train_y_path).values.ravel()
    rf_test_x = pd.read_csv(rf_test_x_path)
    rf_test_y = pd.read_csv(rf_test_y_path).values.ravel()

    scaler_rf = MinMaxScaler(feature_range=(-1, 1))
    rf_train_x_scaled = scaler_rf.fit_transform(rf_train_x.iloc[:, 1:])
    rf_test_x_scaled = scaler_rf.transform(rf_test_x.iloc[:, 1:])

    rf_model = RFModel(input_dim=rf_train_x_scaled.shape[1])
    rf_model.train(rf_train_x_scaled, rf_train_y)
    score = rf_model.test(rf_test_x_scaled, rf_test_y)
    print(f'Random Forest accuracy: {score:.4f}')

    # 10. Random Forest with autoencoder encoded data
    ae_train_x = encoded_df.iloc[:len(rf_train_x), 1:].values
    ae_test_x = encoded_df.iloc[len(rf_train_x):, 1:].values
    rf_model_a = RFModel(input_dim=ae_train_x.shape[1])
    rf_model_a.train(ae_train_x, rf_train_y)
    score_a = rf_model_a.test(ae_test_x, rf_test_y)
    print(f'Random Forest with AutoEncoder accuracy: {score_a:.4f}')

if __name__ == '__main__':
    main()
