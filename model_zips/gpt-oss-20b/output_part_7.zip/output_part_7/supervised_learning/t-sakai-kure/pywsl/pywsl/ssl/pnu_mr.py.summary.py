import numpy as np
from typing import List, Tuple, Callable, Dict, Any, Union

class PNU_SL:
    def __init__(
        self,
        prior: float = 0.5,
        eta: float = 0.0,
        sigma: float = 1.0,
        lam: float = 1e-3,
        basis: str = "gauss",
        n_basis: int = 100,
        random_state: int = 0,
    ):
        if not (0.0 <= prior <= 1.0):
            raise ValueError("prior must be in [0, 1]")
        if not (-1.0 <= eta <= 1.0):
            raise ValueError("eta must be in [-1, 1]")
        if basis not in ("gauss", "lm"):
            raise ValueError("basis must be 'gauss' or 'lm'")
        self.prior = prior
        self.eta = eta
        self.sigma = sigma
        self.lam = lam
        self.basis = basis
        self.n_basis = n_basis
        self.random_state = random_state
        self.coef_ = None
        self.x_c = None

    def _kernel(self, X: np.ndarray, Y: np.ndarray) -> np.ndarray:
        if self.basis == "gauss":
            d2 = np.sum(X**2, axis=1, keepdims=True) + np.sum(Y**2, axis=1) - 2 * X @ Y.T
            K = np.exp(-d2 / (2 * self.sigma ** 2))
        else:  # linear model
            X_h = np.hstack([X, np.ones((X.shape[0], 1))])
            Y_h = np.hstack([Y, np.ones((Y.shape[0], 1))])
            K = X_h @ Y_h.T
        return K

    def fit(self, X: np.ndarray, y: np.ndarray):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=int)

        if set(y) - {-1, 0, 1}:
            raise ValueError("labels must be exactly -1, 0, +1")

        x_p = X[y == 1]
        x_n = X[y == -1]
        x_u = X[y == 0]

        # Basis centers
        rng = np.random.default_rng(self.random_state)
        if self.basis == "gauss":
            idx = rng.choice(len(x_u), size=self.n_basis, replace=False)
            self.x_c = x_u[idx]
        else:
            self.x_c = np.empty((0, X.shape[1]))

        # Kernel matrices
        k_p = self._kernel(x_p, self.x_c) if len(x_p) > 0 else np.zeros((0, self.x_c.shape[0]))
        k_n = self._kernel(x_n, self.x_c) if len(x_n) > 0 else np.zeros((0, self.x_c.shape[0]))
        k_u = self._kernel(x_u, self.x_c) if len(x_u) > 0 else np.zeros((0, self.x_c.shape[0]))

        # Build H and h matrices
        def build(H, k):
            return k.T @ k / H if H != 0 else np.zeros((k.shape[1], k.shape[1]))

        def h_vec(k, H):
            return k.T @ np.ones(k.shape[0]) / H if H != 0 else np.zeros(k.shape[1])

        H_p = len(x_p)
        H_n = len(x_n)
        H_u = len(x_u)

        H_pn = self.prior * build(H_p, k_p) - (1 - self.prior) * build(H_n, k_n)
        h_pn = self.prior * h_vec(k_p, H_p) - (1 - self.prior) * h_vec(k_n, H_n)

        if self.eta >= 0:
            H_u_term = self.prior * build(H_u, k_u)
            h_u_term = self.prior * h_vec(k_u, H_u)
        else:
            H_u_term = - (1 - self.prior) * build(H_u, k_u)
            h_u_term = - (1 - self.prior) * h_vec(k_u, H_u)

        Reg = self.lam * np.eye(self.x_c.shape[1])
        if self.basis == "lm":
            Reg[-1, -1] = 0.0  # no regularization for bias term

        A = H_pn + H_u_term + Reg
        b = h_pn + h_u_term

        if A.shape[0] == 0:
            self.coef_ = np.zeros((self.x_c.shape[1],))
        else:
            self.coef_ = np.linalg.solve(A, b)

    def predict(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=float)
        K = self._kernel(X, self.x_c) if len(self.x_c) > 0 else np.zeros((X.shape[0], 0))
        scores = K @ self.coef_
        preds = np.sign(scores)
        preds[scores == 0] = 0
        return preds.astype(int)

def pnu_risk(y_true: np.ndarray, y_pred: np.ndarray, prior: float, eta: float) -> float:
    y_true = np.asarray(y_true, dtype=int)
    y_pred = np.asarray(y_pred, dtype=int)

    pos = y_true == 1
    neg = y_true == -1
    unl = y_true == 0

    fn = np.sum((y_pred == -1) & pos)
    fp = np.sum((y_pred == 1) & neg)
    pn_risk = (fn + fp) / (pos.sum() + neg.sum() + 1e-12)

    xu_pred_pos = np.sum((y_pred == 1) & unl)
    xu_pred_neg = np.sum((y_pred == -1) & unl)
    xu_risk = (xu_pred_pos + xu_pred_neg) / (unl.sum() + 1e-12)

    risk = prior * pn_risk + (1 - prior) * xu_risk
    risk += eta * (pn_risk - xu_risk)
    return risk

def PNU_SL_FastCV(
    X: np.ndarray,
    y: np.ndarray,
    sigma_list: List[float],
    lambda_list: List[float],
    eta_list: List[float],
    n_fold: int = 5,
    random_state: int = 0,
) -> Tuple[Callable[[np.ndarray], np.ndarray], Dict[str, Any]]:
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=int)

    rng = np.random.default_rng(random_state)
    indices = rng.permutation(len(X))

    best_score = np.inf
    best_params = {}
    best_model = None

    for sigma in sigma_list:
        for lam in lambda_list:
            for eta in eta_list:
                fold_scores = []
                for fold in range(n_fold):
                    start = fold * len(indices) // n_fold
                    end = (fold + 1) * len(indices) // n_fold
                    test_idx = indices[start:end]
                    train_idx = np.setdiff1d(indices, test_idx)

                    X_train, y_train = X[train_idx], y[train_idx]
                    X_test, y_test = X[test_idx], y[test_idx]

                    model = PNU_SL(
                        prior=0.5,
                        eta=eta,
                        sigma=sigma,
                        lam=lam,
                        basis="gauss",
                        n_basis=100,
                        random_state=random_state,
                    )
                    model.fit(X_train, y_train)
                    preds = model.predict(X_test)
                    score = pnu_risk(y_test, preds, 0.5, eta)
                    fold_scores.append(score)

                avg_score = np.mean(fold_scores)
                if avg_score < best_score:
                    best_score = avg_score
                    best_params = {"sigma": sigma, "lam": lam, "eta": eta}
                    best_model = model

    def decision_function(X_new: np.ndarray) -> np.ndarray:
        return best_model.predict(X_new)

    return decision_function, {"best_params": best_params, "best_score": best_score}
