import warnings
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
from matplotlib.patches import Patch
from sklearn.metrics import accuracy_score, f1_score

# Suppress matplotlib user warnings
warnings.filterwarnings('ignore', category=UserWarning)

# Enable inline mode if running in a Jupyter environment
try:
    get_ipython().run_line_magic('matplotlib', 'inline')
except Exception:
    pass


def distribution(data: pd.DataFrame, feature_label: str, transformed: bool = False) -> None:
    """
    Visualize the distribution of a specified feature in a dataset.

    Parameters
    ----------
    data : pd.DataFrame
        The input dataset.
    feature_label : str
        The column name of the feature to visualize.
    transformed : bool, optional
        Flag indicating whether the data has been log-transformed.
    """
    sns.set_style('whitegrid')
    fig, axes = plt.subplots(1, 2, figsize=(12, 4))

    # Histogram for the specified feature
    axes[0].hist(data[feature_label].dropna(), bins=25, color='#00A0A0')
    axes[0].set_xlim(data[feature_label].min(), data[feature_label].max())
    axes[0].set_ylim(0, 1500)
    axes[0].set_xlabel(feature_label)
    axes[0].set_ylabel('Frequency')
    axes[0].set_title('Distribution')

    # Mirror plot for visual consistency
    axes[1].hist(data[feature_label].dropna(), bins=25, color='#00A0A0')
    axes[1].set_xlim(data[feature_label].min(), data[feature_label].max())
    axes[1].set_ylim(0, 1500)
    axes[1].set_xlabel(feature_label)
    axes[1].set_ylabel('Frequency')
    axes[1].set_title('Distribution')

    title = 'Log-transformed Distributions' if transformed else 'Skewed Distributions'
    fig.suptitle(title, fontsize=16)
    fig.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.show()


def visualize_classification_performance(results: list) -> None:
    """
    Visualize classification performance metrics across different training set sizes.

    Parameters
    ----------
    results : list
        A list of dictionaries, each containing metrics for a learner across
        training set sizes (e.g., '1%', '10%', '100%').
    """
    # Configuration
    metric_groups = {
        'Model Training': ['train_time', 'train_accuracy', 'train_f1'],
        'Model Predicting': ['pred_time', 'pred_accuracy', 'pred_f1']
    }
    train_sizes = ['1%', '10%', '100%']
    colors = sns.color_palette('tab10', n_colors=len(results))

    fig, axes = plt.subplots(2, 3, figsize=(18, 10), sharey=False)
    bar_width = 0.1
    x = np.arange(len(train_sizes))

    for row_idx, (row_title, metrics) in enumerate(metric_groups.items()):
        for col_idx, metric in enumerate(metrics):
            ax = axes[row_idx, col_idx]
            for learner_idx, result in enumerate(results):
                values = [result[ts][metric] for ts in train_sizes]
                offset = (learner_idx - len(results) / 2) * bar_width
                ax.bar(x + offset, values, width=bar_width, color=colors[learner_idx],
                       label=result.get('learner', f'Learner {learner_idx + 1}'))
            ax.set_xticks(x)
            ax.set_xticklabels(train_sizes)
            ax.set_title(f'{row_title} - {metric.replace("_", " ").title()}')
            ax.set_xlabel('Training Set Size')
            ax.set_ylabel(metric.replace('_', ' ').title())
            ax.axhline(y=1, color='gray', linestyle='--', linewidth=0.7)
            if row_idx == 0 and col_idx == 0:
                ax.legend(title='Learner', bbox_to_anchor=(1.05, 1), loc='upper left')

    fig.suptitle('Classification Performance Across Training Set Sizes', fontsize=18)
    fig.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.show()


def feature_plot(importances, X_train: pd.DataFrame, y_train: pd.Series) -> None:
    """
    Plot the top 11 feature importances.

    Parameters
    ----------
    importances : array-like
        Feature importance scores.
    X_train : pd.DataFrame
        Training feature matrix.
    y_train : pd.Series
        Training target labels.
    """
    feature_names = X_train.columns
    # Combine feature names with importances
    feat_imp_df = pd.DataFrame({
        'feature': feature_names,
        'importance': importances
    })
    # Sort and select top 11
    top_features = feat_imp_df.sort_values('importance', ascending=False).head(11)

    sns.set_style('whitegrid')
    plt.figure(figsize=(10, 6))
    ax = sns.barplot(
        x='importance',
        y='feature',
        data=top_features,
        palette='viridis'
    )
    ax.set_xlabel('Weight')
    ax.set_ylabel('Feature')
    ax.set_title('Top 11 Feature Importances')
    plt.tight_layout()
    plt.show()
