import gym
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import random
from collections import deque

# Set random seeds for reproducibility
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Replay buffer
class ReplayBuffer:
    def __init__(self, capacity, batch_size):
        self.capacity = capacity
        self.batch_size = batch_size
        self.buffer = deque(maxlen=capacity)

    def push(self, state, action, reward, next_state, done):
        self.buffer.append((state, action, reward, next_state, done))

    def sample(self):
        batch = random.sample(self.buffer, self.batch_size)
        state, action, reward, next_state, done = map(np.stack, zip(*batch))
        return (
            torch.FloatTensor(state).to(device),
            torch.FloatTensor(action).to(device),
            torch.FloatTensor(reward).unsqueeze(1).to(device),
            torch.FloatTensor(next_state).to(device),
            torch.FloatTensor(done).unsqueeze(1).to(device),
        )

    def __len__(self):
        return len(self.buffer)

# Actor network
class Actor(nn.Module):
    def __init__(self, state_dim, action_dim, action_range):
        super().__init__()
        self.action_range = action_range
        self.net = nn.Sequential(
            nn.Linear(state_dim, 400),
            nn.ReLU(),
            nn.Linear(400, 300),
            nn.ReLU(),
            nn.Linear(300, action_dim),
            nn.Tanh(),
        )

    def forward(self, state):
        return self.net(state) * self.action_range

# Critic network
class Critic(nn.Module):
    def __init__(self, state_dim, action_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim + action_dim, 400),
            nn.ReLU(),
            nn.Linear(400, 300),
            nn.ReLU(),
            nn.Linear(300, 1),
        )

    def forward(self, state, action):
        return self.net(torch.cat([state, action], dim=1))

# DDPG Agent
class DDPGAgent:
    def __init__(self, state_dim, action_dim, action_range, lr=1e-3, gamma=0.99, tau=0.005, buffer_capacity=100000, batch_size=64):
        self.actor = Actor(state_dim, action_dim, action_range).to(device)
        self.actor_target = Actor(state_dim, action_dim, action_range).to(device)
        self.actor_target.load_state_dict(self.actor.state_dict())

        self.critic = Critic(state_dim, action_dim).to(device)
        self.critic_target = Critic(state_dim, action_dim).to(device)
        self.critic_target.load_state_dict(self.critic.state_dict())

        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=lr)
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=lr)

        self.gamma = gamma
        self.tau = tau
        self.buffer = ReplayBuffer(buffer_capacity, batch_size)

    def act_with_noise(self, state, noise_std=0.2):
        state = torch.FloatTensor(state).unsqueeze(0).to(device)
        self.actor.eval()
        with torch.no_grad():
            action = self.actor(state).cpu().numpy().flatten()
        self.actor.train()
        noise = np.random.normal(0, noise_std, size=action.shape)
        action = action + noise
        return np.clip(action, -2, 2)  # action range

    def update(self):
        if len(self.buffer) < self.buffer.batch_size:
            return
        state, action, reward, next_state, done = self.buffer.sample()

        # Critic update
        with torch.no_grad():
            target_action = self.actor_target(next_state)
            target_q = self.critic_target(next_state, target_action)
            target_q = reward + self.gamma * target_q * (1 - done)
        current_q = self.critic(state, action)
        critic_loss = nn.functional.mse_loss(current_q, target_q)
        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        self.critic_optimizer.step()

        # Actor update
        actor_loss = -self.critic(state, self.actor(state)).mean()
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        self.actor_optimizer.step()

        # Soft update targets
        for target_param, param in zip(self.actor_target.parameters(), self.actor.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)
        for target_param, param in zip(self.critic_target.parameters(), self.critic.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)

# Main training loop
env = gym.make('Pendulum-v0')
env.seed(SEED)

state_dim = env.observation_space.shape[0]   # 3
action_dim = env.action_space.shape[0]       # 1
action_range = env.action_space.high[0]      # 2

agent = DDPGAgent(state_dim, action_dim, action_range)

max_episodes = 1000
max_steps = 200
reward_threshold = -150
ema_reward = 0.0
solved_counter = 0

for episode in range(1, max_episodes + 1):
    state = env.reset()
    episode_reward = 0.0
    transitions = []

    for step in range(max_steps):
        action = agent.act_with_noise(state, noise_std=0.2)
        next_state, reward, done, _ = env.step(action)
        episode_reward += reward
        transitions.append((state, action, reward, next_state, done))
        state = next_state

    # Store transitions to replay buffer
    for trans in transitions:
        agent.buffer.push(*trans)

    # Policy update
    if episode > 100:
        for _ in range(len(transitions)):
            agent.update()

    # Exponential moving average of reward
    ema_reward = 0.9 * ema_reward + 0.1 * episode_reward

    print(f"Episode {episode}\tReward {episode_reward:.2f}\tEMA {ema_reward:.2f}")

    if ema_reward > reward_threshold:
        solved_counter += 1
        if solved_counter >= 5:
            print("Environment solved!")
            break
    else:
        solved_counter = 0

env.close()
