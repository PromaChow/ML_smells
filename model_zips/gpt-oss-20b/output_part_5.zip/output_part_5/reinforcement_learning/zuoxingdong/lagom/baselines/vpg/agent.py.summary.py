import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import os
import numpy as np
from collections import deque

# ---------- Utility functions ----------

def orthogonal_init(layer, gain=1.0):
    if isinstance(layer, nn.Linear):
        nn.init.orthogonal_(layer.weight, gain)
        if layer.bias is not None:
            nn.init.constant_(layer.bias, 0)

def make_fc(in_dim, out_dim):
    linear = nn.Linear(in_dim, out_dim)
    orthogonal_init(linear)
    return linear

def bootstrapped_returns(rewards, dones, last_value, gamma=0.99):
    returns = []
    R = last_value
    for r, d in zip(reversed(rewards), reversed(dones)):
        R = r + gamma * R * (1 - d)
        returns.insert(0, R)
    return torch.tensor(returns, dtype=torch.float32)

def gae(rewards, values, dones, gamma=0.99, lam=0.95):
    advantages = []
    gae_val = 0
    for t in reversed(range(len(rewards))):
        delta = rewards[t] + gamma * values[t + 1] * (1 - dones[t]) - values[t]
        gae_val = delta + gamma * lam * (1 - dones[t]) * gae_val
        advantages.insert(0, gae_val)
    return torch.tensor(advantages, dtype=torch.float32)

def explained_variance(preds, targets):
    var_target = torch.var(targets)
    if var_target.item() == 0:
        return torch.tensor(0.0)
    return 1 - torch.var(targets - preds) / var_target

# ---------- Neural Network Modules ----------

class MLP(nn.Module):
    def __init__(self, input_dim, hidden_sizes=[64, 64], activation=nn.Tanh):
        super().__init__()
        layers = []
        in_dim = input_dim
        for size in hidden_sizes:
            fc = make_fc(in_dim, size)
            layers.append(fc)
            layers.append(nn.LayerNorm(size))
            layers.append(activation())
            in_dim = size
        self.model = nn.Sequential(*layers)

    def forward(self, x):
        return self.model(x)

class CategoricalHead(nn.Module):
    def __init__(self, hidden_size, n_actions):
        super().__init__()
        self.mean = make_fc(hidden_size, n_actions)

    def forward(self, features):
        logits = self.mean(features)
        return torch.distributions.Categorical(logits=logits)

class DiagGaussianHead(nn.Module):
    def __init__(self, hidden_size, action_dim):
        super().__init__()
        self.mean = make_fc(hidden_size, action_dim)
        self.log_std = nn.Parameter(torch.zeros(action_dim))

    def forward(self, features):
        mean = self.mean(features)
        std = torch.exp(self.log_std)
        return torch.distributions.Normal(mean, std)

# ---------- Agent ----------

class Agent:
    def __init__(self, env, config):
        self.env = env
        self.cfg = config
        self.obs_dim = int(np.prod(env.observation_space.shape))
        self.is_continuous = hasattr(env.action_space, 'shape')
        if self.is_continuous:
            self.action_dim = env.action_space.shape[0]
        else:
            self.n_actions = env.action_space.n

        self.feature_net = MLP(self.obs_dim, hidden_sizes=config.get('hidden_sizes', [64, 64]))

        if self.is_continuous:
            self.action_head = DiagGaussianHead(config.get('hidden_sizes', [64, 64])[-1], self.action_dim)
        else:
            self.action_head = CategoricalHead(config.get('hidden_sizes', [64, 64])[-1], self.n_actions)

        self.value_head = nn.Linear(config.get('hidden_sizes', [64, 64])[-1], 1)

        self.optimizer = optim.Adam(
            list(self.feature_net.parameters()) +
            list(self.action_head.parameters()) +
            list(self.value_head.parameters()),
            lr=config.get('learning_rate', 3e-4)
        )

        self.scheduler = None
        if config.get('lr_scheduler', False):
            self.scheduler = optim.lr_scheduler.LinearLR(self.optimizer, total_iters=config.get('total_iters', 100000))

        self.train_step = 0
        self.obs_moments = None
        if config.get('normalize_obs', False):
            self.obs_moments = RunningMeanStd(shape=(self.obs_dim,))

    def _process_obs(self, obs):
        obs = torch.tensor(obs, dtype=torch.float32)
        if self.cfg.get('normalize_obs', False):
            obs = self.obs_moments.normalize(obs)
        return obs

    def choose_action(self, obs):
        obs_t = self._process_obs(obs).unsqueeze(0)
        features = self.feature_net(obs_t)
        dist = self.action_head(features)
        action = dist.sample()
        log_prob = dist.log_prob(action).sum(-1)
        entropy = dist.entropy().sum(-1)
        with torch.no_grad():
            value = self.value_head(features).squeeze(-1)
        if self.is_continuous:
            raw_action = action.cpu().numpy()[0]
        else:
            raw_action = action.cpu().numpy()[0]
        return raw_action, dist, entropy.item(), log_prob.item(), value.item()

    def learn(self, batch):
        # Batch is a dict of tensors: obs, actions, log_probs, values, rewards, dones
        obs = self._process_obs(batch['obs'])
        actions = torch.tensor(batch['actions'])
        log_probs = torch.tensor(batch['log_probs'])
        values = torch.tensor(batch['values'])
        rewards = torch.tensor(batch['rewards'])
        dones = torch.tensor(batch['dones']).float()

        # Compute bootstrapped returns
        last_value = values[-1]
        returns = bootstrapped_returns(rewards, dones, last_value, self.cfg.get('gamma', 0.99))
        # Compute advantages
        advantages = gae(rewards, torch.cat([values, last_value.unsqueeze(0)]), dones,
                         gamma=self.cfg.get('gamma', 0.99),
                         lam=self.cfg.get('lam', 0.95))
        if self.cfg.get('adv_std', True):
            advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

        # Forward pass
        features = self.feature_net(obs)
        dist = self.action_head(features)
        policy_log_probs = dist.log_prob(actions).sum(-1)
        entropy = dist.entropy().sum(-1).mean()
        values_pred = self.value_head(features).squeeze(-1)

        # Losses
        policy_loss = -(policy_log_probs * advantages.detach()).mean()
        value_loss = F.mse_loss(values_pred, returns.detach())
        entropy_loss = -entropy * self.cfg.get('entropy_coef', 0.0)

        total_loss = policy_loss + value_loss + entropy_loss

        # Optimize
        self.optimizer.zero_grad()
        total_loss.backward()
        clip_norm = self.cfg.get('grad_clip', None)
        if clip_norm:
            torch.nn.utils.clip_grad_norm_(self.feature_net.parameters(), clip_norm)
            torch.nn.utils.clip_grad_norm_(self.action_head.parameters(), clip_norm)
            torch.nn.utils.clip_grad_norm_(self.value_head.parameters(), clip_norm)
        self.optimizer.step()

        if self.scheduler:
            self.scheduler.step()
        self.train_step += 1

        # Metrics
        grad_norm = self._compute_grad_norm()
        metrics = {
            'total_loss': total_loss.item(),
            'policy_loss': policy_loss.item(),
            'value_loss': value_loss.item(),
            'entropy': entropy.item(),
            'explained_variance': explained_variance(values_pred, returns).item(),
            'grad_norm': grad_norm
        }
        return metrics

    def _compute_grad_norm(self):
        total_norm = 0.0
        for p in self.feature_net.parameters():
            if p.grad is not None:
                param_norm = p.grad.data.norm(2)
                total_norm += param_norm.item() ** 2
        for p in self.action_head.parameters():
            if p.grad is not None:
                param_norm = p.grad.data.norm(2)
                total_norm += param_norm.item() ** 2
        for p in self.value_head.parameters():
            if p.grad is not None:
                param_norm = p.grad.data.norm(2)
                total_norm += param_norm.item() ** 2
        return total_norm ** 0.5

    def save(self, path, num_iter):
        os.makedirs(path, exist_ok=True)
        torch.save({
            'feature_net': self.feature_net.state_dict(),
            'action_head': self.action_head.state_dict(),
            'value_head': self.value_head.state_dict(),
            'optimizer': self.optimizer.state_dict(),
            'train_step': self.train_step,
            'obs_moments': self.obs_moments.mean if self.obs_moments else None,
            'obs_var': self.obs_moments.var if self.obs_moments else None
        }, os.path.join(path, f'agent_{num_iter}.pth'))

# ---------- Running Mean and Variance for observation normalization ----------

class RunningMeanStd:
    def __init__(self, shape, eps=1e-5, decay=0.999):
        self.mean = torch.zeros(shape)
        self.var = torch.ones(shape)
        self.count = eps
        self.decay = decay

    def update(self, x):
        batch_mean = torch.mean(x, dim=0)
        batch_var = torch.var(x, dim=0)
        batch_count = x.size(0)
        self._update_from_moments(batch_mean, batch_var, batch_count)

    def _update_from_moments(self, batch_mean, batch_var, batch_count):
        delta = batch_mean - self.mean
        tot_count = self.count + batch_count
        new_mean = self.mean + delta * batch_count / tot_count
        m_a = self.var * self.count
        m_b = batch_var * batch_count
        M2 = m_a + m_b + delta.pow(2) * self.count * batch_count / tot_count
        new_var = M2 / tot_count
        self.mean = new_mean
        self.var = new_var
        self.count = tot_count

    def normalize(self, x):
        std = torch.sqrt(self.var + 1e-8)
        return (x - self.mean) / std
```