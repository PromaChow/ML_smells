import numpy as np
import chainer
from chainer import cuda, gradient_check
from chainer.testing import parameterized, testing
from chainer.functions import lower_triangular_matrix


class TestLowerTriangularMatrix(parameterized.TestCase):

    @parameterized.expand([(n,) for n in range(1, 6)])
    def test_forward_cpu(self, n):
        batch_size = 4
        non_diag_size = n * (n - 1) // 2
        diag = np.random.uniform(0.1, 1.0, (batch_size, n)).astype(np.float32)
        non_diag = np.random.uniform(-1.0, 1.0, (batch_size, non_diag_size)).astype(np.float32)
        gy = np.random.uniform(-1.0, 1.0, (batch_size, n, n)).astype(np.float32)

        out = lower_triangular_matrix(diag, non_diag)
        ref = np.zeros((batch_size, n, n), dtype=np.float32)

        for b in range(batch_size):
            idx = 0
            for i in range(1, n):
                for j in range(i):
                    ref[b, i, j] = non_diag[b, idx]
                    idx += 1
            for i in range(n):
                ref[b, i, i] = diag[b, i]

        gradient_check.assert_allclose(out.array, ref, rtol=1e-5)

    @parameterized.expand([(n,) for n in range(1, 6)])
    def test_forward_gpu(self, n):
        if not cuda.available:
            self.skipTest('GPU not available')
        batch_size = 4
        non_diag_size = n * (n - 1) // 2
        diag_cpu = np.random.uniform(0.1, 1.0, (batch_size, n)).astype(np.float32)
        non_diag_cpu = np.random.uniform(-1.0, 1.0, (batch_size, non_diag_size)).astype(np.float32)
        gy_cpu = np.random.uniform(-1.0, 1.0, (batch_size, n, n)).astype(np.float32)

        diag = cuda.to_gpu(diag_cpu)
        non_diag = cuda.to_gpu(non_diag_cpu)
        gy = cuda.to_gpu(gy_cpu)

        out = lower_triangular_matrix(diag, non_diag)
        ref_cpu = np.zeros((batch_size, n, n), dtype=np.float32)
        for b in range(batch_size):
            idx = 0
            for i in range(1, n):
                for j in range(i):
                    ref_cpu[b, i, j] = non_diag_cpu[b, idx]
                    idx += 1
            for i in range(n):
                ref_cpu[b, i, i] = diag_cpu[b, i]
        ref = cuda.to_gpu(ref_cpu)

        gradient_check.assert_allclose(out.array, ref, rtol=1e-5)

    @parameterized.expand([(n,) for n in range(1, 6)])
    def test_backward_cpu(self, n):
        batch_size = 4
        non_diag_size = n * (n - 1) // 2
        diag = np.random.uniform(0.1, 1.0, (batch_size, n)).astype(np.float32)
        non_diag = np.random.uniform(-1.0, 1.0, (batch_size, non_diag_size)).astype(np.float32)
        gy = np.random.uniform(-1.0, 1.0, (batch_size, n, n)).astype(np.float32)

        gradient_check.check_backward(
            lower_triangular_matrix,
            inputs=(diag, non_diag),
            gy=gy,
            eps=1e-2,
            rtol=1e-2
        )

    @parameterized.expand([(n,) for n in range(1, 6)])
    def test_backward_gpu(self, n):
        if not cuda.available:
            self.skipTest('GPU not available')
        batch_size = 4
        non_diag_size = n * (n - 1) // 2
        diag_cpu = np.random.uniform(0.1, 1.0, (batch_size, n)).astype(np.float32)
        non_diag_cpu = np.random.uniform(-1.0, 1.0, (batch_size, non_diag_size)).astype(np.float32)
        gy_cpu = np.random.uniform(-1.0, 1.0, (batch_size, n, n)).astype(np.float32)

        diag = cuda.to_gpu(diag_cpu)
        non_diag = cuda.to_gpu(non_diag_cpu)
        gy = cuda.to_gpu(gy_cpu)

        gradient_check.check_backward(
            lower_triangular_matrix,
            inputs=(diag, non_diag),
            gy=gy,
            eps=1e-2,
            rtol=1e-2
        )


if __name__ == "__main__":
    testing.run_module(__name__, __file__)