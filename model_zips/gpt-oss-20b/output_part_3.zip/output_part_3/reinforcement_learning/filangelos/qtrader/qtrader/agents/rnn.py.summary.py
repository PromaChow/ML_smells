import numpy as np
import pandas as pd
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import InputLayer, GRU, Dense
from tensorflow.keras.optimizers import RMSprop

class RNNAgent:
    def __init__(self, df: pd.DataFrame, hidden_units: int = 64):
        self.df = df.copy()
        self.observation_size = self.df.shape[1]
        self.action_size = self.df.shape[1]
        self.hidden_units = hidden_units
        self.model = self.build_model()
        self.memory = pd.DataFrame()

    def build_model(self) -> Sequential:
        model = Sequential()
        model.add(InputLayer(input_shape=(1, self.observation_size)))
        model.add(GRU(self.hidden_units, activation='relu'))
        model.add(Dense(self.action_size))
        model.compile(optimizer=RMSprop(), loss='mse')
        return model

    def clean(self, df: pd.DataFrame) -> pd.DataFrame:
        return df.dropna()

    def Xy(self, df: pd.DataFrame, window: int):
        cleaned = self.clean(df)
        data = cleaned.values
        X, y = [], []
        for i in range(len(data) - window):
            seq = data[i : i + window + 1]
            X.append(seq[:-1])
            y.append(seq[-1])
        X = np.array(X)
        y = np.array(y)
        X = X.reshape((X.shape[0], 1, self.observation_size))
        y = y.reshape((y.shape[0], self.action_size))
        return X, y

    def train(self, batch_size: int = 32, epochs: int = 10, window: int = 5):
        X, y = self.Xy(self.df, window)
        self.model.fit(X, y, batch_size=batch_size, epochs=epochs, verbose=0)

    def softmax(self, logits):
        exp = np.exp(logits - np.max(logits))
        return exp / exp.sum(axis=-1, keepdims=True)

    def act(self, observation: pd.DataFrame, policy: str = 'softmax'):
        if observation.isna().any().any():
            action = np.random.rand(self.action_size)
        else:
            obs_clean = self.clean(observation).values
            obs_input = obs_clean.reshape((1, 1, self.observation_size))
            pred = self.model.predict(obs_input, verbose=0).flatten()
            if np.isnan(pred).any():
                action = np.random.rand(self.action_size)
            else:
                if policy == 'softmax':
                    action = self.softmax(pred).flatten()
                elif policy == 'best':
                    action = np.zeros(self.action_size)
                    action[np.argmax(pred)] = 1
                else:
                    action = pred
        return action
```