import math
import random
from collections import OrderedDict

import numpy as np
from matplotlib.path import Path

# Placeholder shapes dictionary. In practice, this should be replaced with the actual shapes.
# Each shape is defined by an array of (x, y) vertices relative to the origin.
class constants:
    SHAPES = {
        "triangle": np.array([[0, 0], [0.5, 1], [1, 0]]),
        "square":   np.array([[0, 0], [1, 0], [1, 1], [0, 1]]),
        "pentagon": np.array([[0.5, 0], [1, 0.5], [0.75, 1], [0.25, 1], [0, 0.5]]),
    }


class Sprite:
    MAX_SAMPLING_ATTEMPTS = 1000

    def __init__(
        self,
        x: float,
        y: float,
        shape: str,
        angle: float = 0.0,
        scale: float = 1.0,
        c0: float = 0.0,
        c1: float = 0.0,
        c2: float = 0.0,
        x_vel: float = 0.0,
        y_vel: float = 0.0,
        keep_in_frame: bool = True,
    ):
        self._x = float(x)
        self._y = float(y)
        self._shape = shape
        self._angle = float(angle)
        self._scale = float(scale)
        self._c0 = float(c0)
        self._c1 = float(c1)
        self._c2 = float(c2)
        self._x_vel = float(x_vel)
        self._y_vel = float(y_vel)
        self._keep_in_frame = bool(keep_in_frame)

        self._centered_path = None
        self._reset_centered_path()

    # -------------------------- Path Management --------------------------
    def _reset_centered_path(self):
        """Regenerate the centered path based on shape, scale, and angle."""
        base_vertices = constants.SHAPES[self._shape]
        # Scale
        scaled = base_vertices * self._scale
        # Rotation
        theta = math.radians(self._angle)
        rot_mat = np.array([[math.cos(theta), -math.sin(theta)],
                            [math.sin(theta),  math.cos(theta)]])
        rotated = scaled @ rot_mat.T
        # Create Path
        self._centered_path = Path(rotated)

    # -------------------------- Movement Logic --------------------------
    def move(self, dx: float, dy: float):
        self._x += dx
        self._y += dy
        if self._keep_in_frame:
            self._x = min(max(self._x, 0.0), 1.0)
            self._y = min(max(self._y, 0.0), 1.0)

    def update_position(self):
        self.move(self._x_vel, self._y_vel)

    # -------------------------- Containment Checks --------------------------
    def contains_point(self, point: tuple[float, float]) -> bool:
        local_point = (point[0] - self._x, point[1] - self._y)
        return self._centered_path.contains_point(local_point)

    def sample_contained_position(self) -> tuple[float, float] | None:
        # Get bounding box of the centered path
        verts = self._centered_path.vertices
        min_x, min_y = verts.min(axis=0)
        max_x, max_y = verts.max(axis=0)
        for _ in range(self.MAX_SAMPLING_ATTEMPTS):
            rx = random.uniform(min_x, max_x)
            ry = random.uniform(min_y, max_y)
            if self._centered_path.contains_point((rx, ry)):
                return (self._x + rx, self._y + ry)
        return None

    # -------------------------- Vertex Calculation --------------------------
    @property
    def vertices(self) -> np.ndarray:
        """Return the world coordinates of the sprite's vertices."""
        verts = self._centered_path.vertices
        return verts + np.array([self._x, self._y])

    # -------------------------- Boundary Detection --------------------------
    @property
    def out_of_frame(self) -> bool:
        return not (0.0 <= self._x <= 1.0 and 0.0 <= self._y <= 1.0)

    # -------------------------- Property Accessors --------------------------
    @property
    def x(self) -> float:
        return self._x

    @x.setter
    def x(self, value: float):
        self._x = float(value)

    @property
    def y(self) -> float:
        return self._y

    @y.setter
    def y(self, value: float):
        self._y = float(value)

    @property
    def shape(self) -> str:
        return self._shape

    @shape.setter
    def shape(self, value: str):
        self._shape = value
        self._reset_centered_path()

    @property
    def angle(self) -> float:
        return self._angle

    @angle.setter
    def angle(self, value: float):
        self._angle = float(value)
        self._reset_centered_path()

    @property
    def scale(self) -> float:
        return self._scale

    @scale.setter
    def scale(self, value: float):
        self._scale = float(value)
        self._reset_centered_path()

    @property
    def color(self) -> tuple[float, float, float]:
        return (self._c0, self._c1, self._c2)

    @property
    def velocity(self) -> tuple[float, float]:
        return (self._x_vel, self._y_vel)

    @velocity.setter
    def velocity(self, value: tuple[float, float]):
        self._x_vel, self._y_vel = float(value[0]), float(value[1])

    # -------------------------- Factor Extraction --------------------------
    @property
    def factors(self) -> OrderedDict:
        return OrderedDict(
            [
                ("x", self._x),
                ("y", self._y),
                ("shape", self._shape),
                ("angle", self._angle),
                ("scale", self._scale),
                ("c0", self._c0),
                ("c1", self._c1),
                ("c2", self._c2),
                ("x_vel", self._x_vel),
                ("y_vel", self._y_vel),
            ]
        )