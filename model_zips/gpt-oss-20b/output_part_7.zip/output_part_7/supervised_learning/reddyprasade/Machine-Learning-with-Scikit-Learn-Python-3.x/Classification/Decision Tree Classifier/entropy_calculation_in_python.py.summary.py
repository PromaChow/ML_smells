import numpy as np
import scipy.stats
import math
import pandas as pd

labels = [1, 3, 5, 2, 3, 5, 3, 2, 1, 3, 4, 5]

def entropy1(labels, base=None):
    _, counts = np.unique(labels, return_counts=True)
    return scipy.stats.entropy(counts, base=base)

def entropy2(labels, base=None):
    if len(labels) <= 1:
        return 0.0
    _, counts = np.unique(labels, return_counts=True)
    probs = counts / len(labels)
    if np.count_nonzero(probs) <= 1:
        return 0.0
    ent = 0.0
    for p in probs:
        if p > 0:
            ent -= p * math.log(p, base) if base else p * math.log(p)
    return ent

def entropy3(labels, base=None):
    series = pd.Series(labels)
    probs = series.value_counts(normalize=True)
    ent = -sum(p * math.log(p, base) if base else p * math.log(p) for p in probs)
    return ent

def entropy4(labels, base=None):
    _, counts = np.unique(labels, return_counts=True)
    probs = counts / counts.sum()
    ent = -sum(p * math.log(p, base) if base else p * math.log(p) for p in probs)
    return ent

print(entropy1(labels))
print(entropy2(labels))
print(entropy3(labels))
print(entropy4(labels))