import numpy as np
import gymnasium as gym
from gymnasium import spaces

class Sprite:
    """Simple rectangular sprite defined by its center and half-sizes."""
    def __init__(self, position, size):
        self.position = np.array(position, dtype=np.float32)
        self.size = np.array(size, dtype=np.float32)  # half-width, half-height

    def contains_point(self, point):
        pt = np.array(point, dtype=np.float32)
        return np.all(np.abs(pt - self.position) <= self.size)

    def move(self, delta):
        self.position += delta


class SelectMove:
    def __init__(self, sprites, scale, motion_cost, noise_scale=None):
        self.sprites = sprites
        self.scale = scale
        self.motion_cost = motion_cost
        self.noise_scale = noise_scale
        self.action_spec = spaces.Box(low=0.0, high=1.0, shape=(4,), dtype=np.float32)

    def process(self, action):
        action = np.asarray(action, dtype=np.float32)
        if self.noise_scale is not None:
            action += np.random.normal(0, self.noise_scale, size=action.shape)
            action = np.clip(action, 0.0, 1.0)

        position = action[:2]
        second_click = action[2:]
        motion = (second_click - 0.5) * self.scale

        target = None
        for sprite in self.sprites:
            if sprite.contains_point(position):
                target = sprite
                break

        if target is not None:
            target.move(motion)

        cost = -self.motion_cost * np.linalg.norm(motion)
        return cost


class DragAndDrop(SelectMove):
    def process(self, action):
        action = np.asarray(action, dtype=np.float32)
        if self.noise_scale is not None:
            action += np.random.normal(0, self.noise_scale, size=action.shape)
            action = np.clip(action, 0.0, 1.0)

        position = action[:2]
        target_position = action[2:]
        motion = (target_position - position) * self.scale

        target = None
        for sprite in self.sprites:
            if sprite.contains_point(position):
                target = sprite
                break

        if target is not None:
            target.move(motion)

        cost = -self.motion_cost * np.linalg.norm(motion)
        return cost


class Embodied:
    def __init__(self, sprites, step_size, motion_cost):
        self.sprites = sprites
        self.step_size = step_size
        self.motion_cost = motion_cost
        self.action_spec = spaces.MultiDiscrete([2, 4])  # [carry, direction]

    def process(self, action):
        carry, direction = action
        dir_vectors = {
            0: np.array([0.0, self.step_size]),
            1: np.array([-self.step_size, 0.0]),
            2: np.array([0.0, -self.step_size]),
            3: np.array([self.step_size, 0.0]),
        }
        motion = dir_vectors[direction]

        body = self.sprites[-1]
        body.move(motion)

        if carry:
            carried = None
            body_pos = body.position
            for sprite in self.sprites[:-1]:
                if sprite.contains_point(body_pos):
                    carried = sprite
                    break
            if carried:
                carried.move(motion)

        cost = -self.step_size * self.motion_cost
        return cost
