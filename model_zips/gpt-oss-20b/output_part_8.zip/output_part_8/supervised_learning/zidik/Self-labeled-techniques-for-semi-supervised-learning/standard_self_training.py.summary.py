import numpy as np
from sklearn.base import clone

class StandardSelfTraining:
    def __init__(self, name, base_classifier, max_iterations: int = 40):
        self.name = name
        self.base_classifier = base_classifier
        self.max_iterations = max_iterations
        self.model = None
        self.iterations = 0

    def fit(self, X, y):
        self.X = np.asarray(X)
        # Keep original labels; use a sentinel for unlabeled samples
        self.y = np.array(y, dtype=object, copy=True)

        self.model = clone(self.base_classifier)

        for it in range(1, self.max_iterations + 1):
            self._fit_iteration()
            self.iterations = it
            # Check if all samples are labeled
            if not np.any(self.y == 'unlabeled'):
                break

        print(f"StandardSelfTraining: {self.iterations} iterations executed.")
        return self

    def _fit_iteration(self):
        # Indices of currently labeled samples
        labeled_mask = self.y != 'unlabeled'
        if not np.any(labeled_mask):
            return  # No labeled samples to train on

        # Fit the base classifier on labeled data
        self.model.fit(self.X[labeled_mask], self.y[labeled_mask])

        # Predict probabilities for all samples
        probs = self.model.predict_proba(self.X)

        # Process unlabeled samples
        unlabeled_mask = ~labeled_mask
        if not np.any(unlabeled_mask):
            return  # No unlabeled samples to process

        max_probs = np.max(probs[unlabeled_mask], axis=1)
        if max_probs.size == 0:
            return

        threshold = min(0.7, np.max(max_probs))

        # Identify high-confidence predictions
        high_confidence = max_probs >= threshold
        if not np.any(high_confidence):
            return

        # Assign pseudo-labels
        unlabeled_indices = np.where(unlabeled_mask)[0]
        pseudo_indices = unlabeled_indices[high_confidence]
        pseudo_labels = self.model.predict(self.X[pseudo_indices])
        self.y[pseudo_indices] = pseudo_labels

    def predict(self, X):
        if self.model is None:
            raise RuntimeError("The model has not been fitted yet.")
        return self.model.predict(X)

    def score(self, X, y):
        if self.model is None:
            raise RuntimeError("The model has not been fitted yet.")
        return self.model.score(X, y)