import copy
import math
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.multiprocessing as mp
import gym


class ActorCritic(nn.Module):
    """Simple Actor-Critic network with optional recurrent layer."""

    def __init__(self, obs_space, action_space, recurrent=False, hidden_size=128):
        super().__init__()
        self.recurrent = recurrent
        self.fc = nn.Linear(obs_space.shape[0], hidden_size)
        self.policy_head = nn.Linear(hidden_size, action_space.n)
        self.value_head = nn.Linear(hidden_size, 1)
        if recurrent:
            self.rnn = nn.GRUCell(hidden_size, hidden_size)
            self.rnn_hidden = None

    def forward(self, x, hx=None):
        x = F.relu(self.fc(x))
        if self.recurrent:
            if hx is None:
                hx = torch.zeros(x.size(0), x.size(1), device=x.device)
            hx = self.rnn(x, hx)
            x = hx
        logits = self.policy_head(x)
        value = self.value_head(x)
        return logits, value, hx

    def reset_hidden(self, batch_size=1, device='cpu'):
        if self.recurrent:
            self.rnn_hidden = torch.zeros(batch_size, self.fc.out_features, device=device)
        else:
            self.rnn_hidden = None


class A3CWorker(mp.Process):
    """Worker process for Asynchronous Advantage Actor-Critic."""

    def __init__(self,
                 worker_id,
                 shared_model,
                 optimizer,
                 env_name,
                 t_max=5,
                 gamma=0.99,
                 beta=0.01,
                 lr=7e-4,
                 max_episode_steps=1000,
                 deterministic=False,
                 use_average_reward=False,
                 average_reward_decay=0.999,
                 gradient_normalization=True):
        super().__init__()
        self.worker_id = worker_id
        self.shared_model = shared_model
        self.optimizer = optimizer
        self.t_max = t_max
        self.gamma = gamma
        self.beta = beta
        self.deterministic = deterministic
        self.use_average_reward = use_average_reward
        self.average_reward_decay = average_reward_decay
        self.gradient_normalization = gradient_normalization
        self.average_reward = 0.0
        self.env = gym.make(env_name)
        self.max_episode_steps = max_episode_steps
        self.device = torch.device('cpu')
        self.local_model = copy.deepcopy(shared_model)
        self.local_model.to(self.device)
        self.optimizer.zero_grad()
        self.obs_buffer = []
        self.reward_buffer = []
        self.logp_buffer = []
        self.value_buffer = []
        self.entropy_buffer = []
        self.rnn_hidden = None

    def sync_parameters(self):
        self.local_model.load_state_dict(self.shared_model.state_dict())

    def run(self):
        episode = 0
        while True:
            obs = self.env.reset()
            self.rnn_hidden = None
            done = False
            step = 0
            self.obs_buffer = [torch.tensor(obs, dtype=torch.float32, device=self.device)]
            while not done and step < self.max_episode_steps:
                self.act_and_train(obs, step)
                obs, reward, done, _ = self.env.step(self.action)
                self.reward_buffer.append(reward)
                step += 1
                if done or step % self.t_max == 0:
                    self.stop_episode_and_train(done)
                    self.sync_parameters()
                    self.obs_buffer = []
                    self.reward_buffer = []
                    self.logp_buffer = []
                    self.value_buffer = []
                    self.entropy_buffer = []
                    self.rnn_hidden = None
                obs = np.array(obs)
            episode += 1

    def act_and_train(self, obs, step):
        state = torch.tensor(obs, dtype=torch.float32, device=self.device).unsqueeze(0)
        logits, value, hx = self.local_model(state, self.rnn_hidden)
        probs = F.softmax(logits, dim=-1)
        log_probs = F.log_softmax(logits, dim=-1)
        entropy = -(probs * log_probs).sum(-1, keepdim=True)
        if self.deterministic:
            action = probs.argmax().item()
        else:
            action = probs.multinomial(num_samples=1).item()
        self.action = action
        logp = log_probs[0, action].detach()
        self.obs_buffer.append(state.squeeze(0))
        self.value_buffer.append(value.detach())
        self.logp_buffer.append(logp.detach())
        self.entropy_buffer.append(entropy.detach())
        self.rnn_hidden = hx.detach()

    def stop_episode_and_train(self, done):
        if done:
            R = torch.zeros(1, device=self.device)
        else:
            last_state = self.obs_buffer[-1].unsqueeze(0)
            _, value, _ = self.local_model(last_state, self.rnn_hidden)
            R = value.detach()
        returns = []
        for r in reversed(self.reward_buffer):
            R = self.gamma * R + r
            returns.insert(0, R.clone())
        returns = torch.cat(returns)
        values = torch.cat(self.value_buffer)
        advantages = returns - values
        if self.use_average_reward:
            self.average_reward = self.average_reward_decay * self.average_reward + (1 - self.average_reward_decay) * returns.mean().item()
            advantages = returns - self.average_reward - values
        policy_losses = []
        value_losses = []
        entropy_losses = []
        for logp, adv, value, entropy in zip(self.logp_buffer, advantages, values, self.entropy_buffer):
            policy_losses.append(-logp * adv)
            value_losses.append(F.mse_loss(value, adv + values))
            entropy_losses.append(entropy)
        policy_loss = torch.stack(policy_losses).sum()
        value_loss = torch.stack(value_losses).sum()
        entropy_loss = torch.stack(entropy_losses).sum()
        loss = policy_loss + 0.5 * value_loss - self.beta * entropy_loss
        loss = loss / self.t_max
        loss.backward()
        if self.gradient_normalization:
            torch.nn.utils.clip_grad_norm_(self.shared_model.parameters(), 40)
        self.optimizer.step()
        self.optimizer.zero_grad()
        self.local_model.zero_grad()

    def stop_episode(self):
        self.rnn_hidden = None

    def get_statistics(self):
        if len(self.value_buffer) == 0:
            return {}
        values = torch.cat(self.value_buffer).detach()
        entropy = torch.cat(self.entropy_buffer).detach()
        return {
            'value_mean': values.mean().item(),
            'entropy_mean': entropy.mean().item()
        }


def main():
    env_name = 'CartPole-v1'
    env = gym.make(env_name)
    obs_space = env.observation_space
    action_space = env.action_space
    shared_model = ActorCritic(obs_space, action_space, recurrent=False)
    shared_model.share_memory()
    lr = 7e-4
    optimizer = torch.optim.Adam(shared_model.parameters(), lr=lr)
    num_workers = mp.cpu_count()
    workers = []
    for worker_id in range(num_workers):
        worker = A3CWorker(worker_id,
                           shared_model,
                           optimizer,
                           env_name,
                           t_max=5,
                           gamma=0.99,
                           beta=0.01,
                           deterministic=False,
                           use_average_reward=True)
        worker.start()
        workers.append(worker)
    for worker in workers:
        worker.join()


if __name__ == '__main__':
    main()
