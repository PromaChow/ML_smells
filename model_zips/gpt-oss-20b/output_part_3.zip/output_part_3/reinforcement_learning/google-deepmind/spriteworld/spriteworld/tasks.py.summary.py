import numpy as np
from abc import ABC, abstractmethod
from typing import List, Tuple, Callable, Optional, Union
from sklearn.metrics import davies_bouldin_score

class Sprite:
    """Simple representation of a sprite in the environment."""
    def __init__(self, distribution: str, position: Tuple[float, float],
                 features: Optional[np.ndarray] = None):
        self.distribution = distribution
        self.position = np.asarray(position, dtype=float)
        self.features = features if features is not None else np.array([])

class AbstractTask(ABC):
    """Abstract base class for all tasks."""
    @abstractmethod
    def reward(self, sprites: List[Sprite]) -> float:
        pass

    @abstractmethod
    def success(self, sprites: List[Sprite]) -> bool:
        pass

class NoReward(AbstractTask):
    """Placeholder task with no reward and no success condition."""
    def reward(self, sprites: List[Sprite]) -> float:
        return 0.0

    def success(self, sprites: List[Sprite]) -> bool:
        return False

class FindGoalPosition(AbstractTask):
    def __init__(
        self,
        filter_distrib: Optional[Union[str, Callable[[Sprite], bool]]] = None,
        goal_position: Tuple[float, float] = (0.5, 0.5),
        terminate_distance: float = 0.1,
        terminate_bonus: float = 1.0,
        weights_dimensions: Tuple[float, float] = (1.0, 1.0)
    ):
        self.filter_distrib = filter_distrib
        self.goal_position = np.asarray(goal_position, dtype=float)
        self.terminate_distance = terminate_distance
        self.terminate_bonus = terminate_bonus
        self.weights_dimensions = np.asarray(weights_dimensions, dtype=float)

    def _filter(self, sprites: List[Sprite]) -> List[Sprite]:
        if self.filter_distrib is None:
            return sprites
        if isinstance(self.filter_distrib, str):
            return [s for s in sprites if s.distribution == self.filter_distrib]
        # Assume callable
        return [s for s in sprites if self.filter_distrib(s)]

    def reward(self, sprites: List[Sprite]) -> float:
        filtered = self._filter(sprites)
        if not filtered:
            return 0.0
        rewards = []
        for s in filtered:
            dist_vec = s.position - self.goal_position
            weighted_dist = np.sqrt(np.sum((dist_vec ** 2) * self.weights_dimensions))
            # Reward inversely proportional to distance (closer = higher reward)
            rewards.append(-weighted_dist)
        # If all within terminate distance, add bonus
        if all(np.linalg.norm(s.position - self.goal_position) <= self.terminate_distance for s in filtered):
            return sum(rewards) + self.terminate_bonus
        return sum(rewards)

    def success(self, sprites: List[Sprite]) -> bool:
        filtered = self._filter(sprites)
        if not filtered:
            return False
        return all(np.linalg.norm(s.position - self.goal_position) <= self.terminate_distance for s in filtered)

class Clustering(AbstractTask):
    def __init__(
        self,
        cluster_distribs: List[str],
        termination_threshold: float = 0.5,
        terminate_bonus: float = 1.0,
        reward_range: float = 1.0
    ):
        self.cluster_distribs = cluster_distribs
        self.termination_threshold = termination_threshold
        self.terminate_bonus = terminate_bonus
        self.reward_range = reward_range

    def _assign_clusters(self, sprites: List[Sprite]) -> Tuple[np.ndarray, np.ndarray]:
        features = []
        labels = []
        for idx, s in enumerate(sprites):
            if s.features.size == 0:
                continue
            try:
                cluster_idx = self.cluster_distribs.index(s.distribution)
            except ValueError:
                continue
            features.append(s.features)
            labels.append(cluster_idx)
        if not features:
            return np.array([]), np.array([])
        return np.vstack(features), np.array(labels)

    def reward(self, sprites: List[Sprite]) -> float:
        X, y = self._assign_clusters(sprites)
        if X.size == 0 or len(set(y)) < 2:
            return 0.0
        db_score = davies_bouldin_score(X, y)
        reward = -db_score * self.reward_range
        if db_score > self.termination_threshold:
            reward += self.terminate_bonus
        return reward

    def success(self, sprites: List[Sprite]) -> bool:
        X, y = self._assign_clusters(sprites)
        if X.size == 0 or len(set(y)) < 2:
            return False
        db_score = davies_bouldin_score(X, y)
        return db_score >= self.termination_threshold

class MetaAggregated(AbstractTask):
    def __init__(
        self,
        subtasks: List[AbstractTask],
        reward_aggregator: str = 'sum',
        termination_criterion: str = 'all',
        terminate_bonus: float = 1.0
    ):
        self.subtasks = subtasks
        self.reward_aggregator = reward_aggregator
        self.termination_criterion = termination_criterion
        self.terminate_bonus = terminate_bonus
        self._aggregators = {
            'sum': sum,
            'max': max,
            'min': min,
            'mean': lambda x: sum(x) / len(x) if x else 0.0
        }

    def reward(self, sprites: List[Sprite]) -> float:
        rewards = [task.reward(sprites) for task in self.subtasks]
        agg_reward = self._aggregators.get(self.reward_aggregator, sum)(rewards)
        if self._termination_met(sprites):
            agg_reward += self.terminate_bonus
        return agg_reward

    def success(self, sprites: List[Sprite]) -> bool:
        return self._termination_met(sprites)

    def _termination_met(self, sprites: List[Sprite]) -> bool:
        success_states = [task.success(sprites) for task in self.subtasks]
        if self.termination_criterion == 'all':
            return all(success_states)
        if self.termination_criterion == 'any':
            return any(success_states)
        return False
