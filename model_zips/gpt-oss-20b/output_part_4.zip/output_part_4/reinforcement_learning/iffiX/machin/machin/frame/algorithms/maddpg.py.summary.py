import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import numpy as np
import random
import os
import multiprocessing as mp
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
from typing import List, Tuple, Dict, Any, Optional

# ----------------------------- Utility Functions -----------------------------
def hard_update(target: nn.Module, source: nn.Module) -> None:
    for t_param, s_param in zip(target.parameters(), source.parameters()):
        t_param.data.copy_(s_param.data)

def soft_update(target: nn.Module, source: nn.Module, tau: float) -> None:
    for t_param, s_param in zip(target.parameters(), source.parameters()):
        t_param.data.copy_(tau * s_param.data + (1.0 - tau) * t_param.data)

# ----------------------------- Networks ------------------------------------
class ActorNetwork(nn.Module):
    def __init__(self, state_dim: int, action_dim: int, hidden_dim: int = 128):
        super().__init__()
        self.fc1 = nn.Linear(state_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.out = nn.Linear(hidden_dim, action_dim)

    def forward(self, state: torch.Tensor) -> torch.Tensor:
        x = F.relu(self.fc1(state))
        x = F.relu(self.fc2(x))
        return torch.tanh(self.out(x))

class CriticNetwork(nn.Module):
    def __init__(self, total_state_dim: int, total_action_dim: int, hidden_dim: int = 128):
        super().__init__()
        self.fc1 = nn.Linear(total_state_dim + total_action_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.out = nn.Linear(hidden_dim, 1)

    def forward(self, state: torch.Tensor, action: torch.Tensor) -> torch.Tensor:
        x = torch.cat([state, action], dim=-1)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        return self.out(x)

# ----------------------------- Replay Buffer -------------------------------
class SHMBuffer:
    def __init__(self, max_size: int, state_dim: int, action_dim: int):
        self.max_size = max_size
        self.state_dim = state_dim
        self.action_dim = action_dim
        self._lock = mp.Lock()
        self.states = mp.Array('d', max_size * state_dim)
        self.actions = mp.Array('d', max_size * action_dim)
        self.rewards = mp.Array('d', max_size)
        self.next_states = mp.Array('d', max_size * state_dim)
        self.terminals = mp.Array('b', max_size)
        self.size = 0
        self.ptr = 0

    def add(self, state: np.ndarray, action: np.ndarray, reward: float,
            next_state: np.ndarray, terminal: bool) -> None:
        with self._lock:
            idx = self.ptr
            self.states[idx * self.state_dim:(idx + 1) * self.state_dim] = state
            self.actions[idx * self.action_dim:(idx + 1) * self.action_dim] = action
            self.rewards[idx] = reward
            self.next_states[idx * self.state_dim:(idx + 1) * self.state_dim] = next_state
            self.terminals[idx] = terminal
            self.ptr = (self.ptr + 1) % self.max_size
            self.size = min(self.size + 1, self.max_size)

    def sample(self, batch_size: int) -> Dict[str, torch.Tensor]:
        with self._lock:
            indices = np.random.choice(self.size, size=batch_size, replace=False)
            states = np.array([self.states[i * self.state_dim:(i + 1) * self.state_dim] for i in indices])
            actions = np.array([self.actions[i * self.action_dim:(i + 1) * self.action_dim] for i in indices])
            rewards = np.array([self.rewards[i] for i in indices])
            next_states = np.array([self.next_states[i * self.state_dim:(i + 1) * self.state_dim] for i in indices])
            terminals = np.array([self.terminals[i] for i in indices])
        return {
            'state': torch.FloatTensor(states),
            'action': torch.FloatTensor(actions),
            'reward': torch.FloatTensor(rewards).unsqueeze(-1),
            'next_state': torch.FloatTensor(next_states),
            'terminal': torch.FloatTensor(terminals).unsqueeze(-1)
        }

# ----------------------------- MADDPG ------------------------------------
class MADDPG:
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.num_agents = config['num_agents']
        self.sub_policy_num = config['sub_policy_num']
        self.state_dim = config['state_dim']
        self.action_dim = config['action_dim']
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

        # Initialize actor, critic, target networks, optimizers, schedulers
        self.actor = [[ActorNetwork(self.state_dim, self.action_dim).to(self.device) for _ in range(self.sub_policy_num + 1)]
                      for _ in range(self.num_agents)]
        self.critic = [[CriticNetwork(self.state_dim * self.num_agents, self.action_dim * self.num_agents).to(self.device)
                        for _ in range(self.sub_policy_num + 1)] for _ in range(self.num_agents)]
        self.target_actor = [[ActorNetwork(self.state_dim, self.action_dim).to(self.device) for _ in range(self.sub_policy_num + 1)]
                             for _ in range(self.num_agents)]
        self.target_critic = [[CriticNetwork(self.state_dim * self.num_agents, self.action_dim * self.num_agents).to(self.device)
                               for _ in range(self.sub_policy_num + 1)] for _ in range(self.num_agents)]

        self.actor_opt = [[optim.Adam(a.parameters(), lr=config['actor_lr']) for a in actor_list]
                          for actor_list in self.actor]
        self.critic_opt = [[optim.Adam(c.parameters(), lr=config['critic_lr']) for c in critic_list]
                           for critic_list in self.critic]
        self.actor_sched = [[optim.lr_scheduler.StepLR(opt, step_size=1000, gamma=0.95) for opt in opt_list]
                            for opt_list in self.actor_opt]
        self.critic_sched = [[optim.lr_scheduler.StepLR(opt, step_size=1000, gamma=0.95) for opt in opt_list]
                             for opt_list in self.critic_opt]

        # Copy parameters to target networks
        for a_list, ta_list in zip(self.actor, self.target_actor):
            for a, ta in zip(a_list, ta_list):
                hard_update(ta, a)
        for c_list, tc_list in zip(self.critic, self.target_critic):
            for c, tc in zip(c_list, tc_list):
                hard_update(tc, c)

        # Replay buffers
        self.buffers = [SHMBuffer(config['buffer_size'], self.state_dim, self.action_dim)
                        for _ in range(self.num_agents)]

        # Sub-policy selection
        self.sub_policy_idx = [0 for _ in range(self.num_agents)]

        # Thread or process pool
        if config['pool_type'] == 'thread':
            self.pool = ThreadPoolExecutor(max_workers=config['pool_workers'])
        elif config['pool_type'] == 'process':
            self.pool = ProcessPoolExecutor(max_workers=config['pool_workers'])
        else:
            self.pool = None

        self._check_parameters_device()

    # ---------------- Action Generation ----------------
    def act(self, states: List[torch.Tensor], use_target: bool = False) -> List[torch.Tensor]:
        actions = []
        for i, state in enumerate(states):
            idx = self.sub_policy_idx[i]
            net = self.target_actor[i][idx] if use_target else self.actor[i][idx]
            with torch.no_grad():
                action = net(state.to(self.device))
            actions.append(action.cpu())
        return actions

    def act_with_noise(self, states: List[torch.Tensor], noise_ratio: float = 0.1,
                       use_target: bool = False) -> List[torch.Tensor]:
        actions = self.act(states, use_target=use_target)
        noisy_actions = []
        for act in actions:
            noise = torch.randn_like(act) * noise_ratio
            noisy_actions.append(act + noise)
        return noisy_actions

    def act_discrete(self, states: List[torch.Tensor], use_target: bool = False) -> List[int]:
        actions = []
        for i, state in enumerate(states):
            idx = self.sub_policy_idx[i]
            net = self.target_actor[i][idx] if use_target else self.actor[i][idx]
            logits = net(state.to(self.device))
            probs = F.softmax(logits, dim=-1)
            action = torch.multinomial(probs, 1).item()
            actions.append(action)
        return actions

    # ---------------- Data Storage ----------------
    def store_episodes(self, episodes: List[List[Dict[str, Any]]]) -> None:
        for agent_id, ep in enumerate(episodes):
            for transition in ep:
                self.buffers[agent_id].add(
                    transition['state'],
                    transition['action'],
                    transition['reward'],
                    transition['next_state'],
                    transition['terminal']
                )

    # ---------------- Training Update ----------------
    def update(self, batch_size: int = 1024) -> None:
        # Sample from each buffer
        batch = [buf.sample(batch_size) for buf in self.buffers]
        states = [b['state'].to(self.device) for b in batch]
        actions = [b['action'].to(self.device) for b in batch]
        rewards = [b['reward'].to(self.device) for b in batch]
        next_states = [b['next_state'].to(self.device) for b in batch]
        terminals = [b['terminal'].to(self.device) for b in batch]

        # Concatenate for critics
        all_states = torch.cat(states, dim=0)
        all_actions = torch.cat(actions, dim=0)
        all_next_states = torch.cat(next_states, dim=0)
        all_next_actions = torch.cat([self.act(next_states, use_target=True) for next_states in next_states], dim=0)

        for agent_idx in range(self.num_agents):
            for sub_idx in range(self.sub_policy_num + 1):
                # Critic update
                critic = self.critic[agent_idx][sub_idx]
                target_critic = self.target_critic[agent_idx][sub_idx]
                critic_opt = self.critic_opt[agent_idx][sub_idx]

                current_q = critic(all_states, all_actions)
                with torch.no_grad():
                    target_q = target_critic(all_next_states, all_next_actions)
                    target = rewards[agent_idx] + self.config['gamma'] * target_q * (1 - terminals[agent_idx])
                loss_q = F.mse_loss(current_q, target)
                critic_opt.zero_grad()
                loss_q.backward()
                nn.utils.clip_grad_norm_(critic.parameters(), self.config['gradient_max'])
                critic_opt.step()

                # Actor update
                actor = self.actor[agent_idx][sub_idx]
                actor_opt = self.actor_opt[agent_idx][sub_idx]

                new_actions = actor(states[agent_idx])
                actor_loss = -critic(all_states, torch.cat([new_actions if j == agent_idx else actions[j]
                                                            for j in range(self.num_agents)], dim=1)).mean()
                actor_opt.zero_grad()
                actor_loss.backward()
                nn.utils.clip_grad_norm_(actor.parameters(), self.config['gradient_max'])
                actor_opt.step()

                # Target network update
                if self.config['soft_update']:
                    soft_update(target_critic, critic, self.config['tau'])
                    soft_update(self.target_actor[agent_idx][sub_idx], actor, self.config['tau'])
                else:
                    if random.randint(0, self.config['update_steps']) == 0:
                        hard_update(target_critic, critic)
                        hard_update(self.target_actor[agent_idx][sub_idx], actor)

        # Scheduler step
        for sched_list in self.actor_sched:
            for sched in sched_list:
                if sched is not None:
                    sched.step()
        for sched_list in self.critic_sched:
            for sched in sched_list:
                if sched is not None:
                    sched.step()

    # ---------------- Utility Functions ----------------
    def _check_parameters_device(self) -> None:
        for lst in self.actor + self.critic + self.target_actor + self.target_critic:
            for net in lst:
                for param in net.parameters():
                    if param.device != self.device:
                        raise ValueError('All parameters must be on the same device')

    def load(self, directory: str) -> None:
        for agent_idx in range(self.num_agents):
            for sub_idx in range(self.sub_policy_num + 1):
                path_actor = os.path.join(directory, f'agent{agent_idx}_sub{sub_idx}_actor.pth')
                path_critic = os.path.join(directory, f'agent{agent_idx}_sub{sub_idx}_critic.pth')
                if os.path.exists(path_actor):
                    self.actor[agent_idx][sub_idx].load_state_dict(torch.load(path_actor))
                if os.path.exists(path_critic):
                    self.critic[agent_idx][sub_idx].load_state_dict(torch.load(path_critic))
        # Synchronize target networks
        for agent_idx in range(self.num_agents):
            for sub_idx in range(self.sub_policy_num + 1):
                hard_update(self.target_actor[agent_idx][sub_idx], self.actor[agent_idx][sub_idx])
                hard_update(self.target_critic[agent_idx][sub_idx], self.critic[agent_idx][sub_idx])

    @staticmethod
    def generate_config() -> Dict[str, Any]:
        return {
            'num_agents': 3,
            'state_dim': 24,
            'action_dim': 4,
            'sub_policy_num': 2,
            'actor_lr': 1e-4,
            'critic_lr': 1e-3,
            'gamma': 0.95,
            'tau': 0.01,
            'soft_update': True,
            'update_steps': 1000,
            'gradient_max': 0.5,
            'buffer_size': 100000,
            'batch_size': 1024,
            'pool_type': 'thread',
            'pool_workers': 4,
            'use_scheduler': True
        }

    @classmethod
    def init_from_config(cls, config: Optional[Dict[str, Any]] = None) -> 'MADDPG':
        if config is None:
            config = cls.generate_config()
        return cls(config)

# ----------------------------- Example Usage -----------------------------
if __name__ == "__main__":
    config = MADDPG.generate_config()
    maddpg = MADDPG.init_from_config(config)

    # Dummy data for demonstration
    dummy_state = torch.randn(config['state_dim'])
    dummy_next_state = torch.randn(config['state_dim'])
    dummy_action = torch.randn(config['action_dim'])
    dummy_reward = 1.0
    dummy_terminal = False

    episode = [{'state': dummy_state.numpy(), 'action': dummy_action.numpy(),
                'reward': dummy_reward, 'next_state': dummy_next_state.numpy(),
                'terminal': dummy_terminal} for _ in range(10)]

    maddpg.store_episodes([episode for _ in range(config['num_agents'])])
    maddpg.update(batch_size=config['batch_size'])
    actions = maddpg.act([dummy_state for _ in range(config['num_agents'])])
    print('Sample actions:', actions)