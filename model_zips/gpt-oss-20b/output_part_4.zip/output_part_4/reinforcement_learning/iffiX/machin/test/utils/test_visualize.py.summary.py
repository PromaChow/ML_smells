import torch as t
from unittest import mock
from machin.utils.visualize import visualize_graph

def mock_exit(*args, **kwargs):
    pass

tensor = t.ones([2, 2]) * t.ones([2, 2])

with mock.patch('machin.utils.visualize.exit', new=mock_exit):
    visualize_graph(tensor)