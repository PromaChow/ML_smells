import argparse
import logging
import os
import sys
import numpy as np
import gym
import chainer
import chainerrl
from chainerrl.wrappers import CastObservationToFloat32, ScaleReward, Monitor, Render
from chainerrl.replay_buffer import EpisodicReplayBuffer
from chainerrl.algorithms import acer
from chainerrl.models import acer as acer_models
from chainerrl import links as L
from chainerrl import distributions, value_functions, explorations

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--processes", type=int, default=1)
    parser.add_argument("--env", type=str, required=True)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--outdir", type=str, default="output")
    parser.add_argument("--t-max", type=int, default=50)
    parser.add_argument("--n-hidden-channels", type=int, default=128)
    parser.add_argument("--reward-scale-factor", type=float, default=1e-2)
    parser.add_argument("--render", action="store_true")
    parser.add_argument("--demo", action="store_true")
    parser.add_argument("--eval-n-runs", type=int, default=5)
    parser.add_argument("--steps", type=int, default=int(8e7))
    parser.add_argument("--eval-interval", type=int, default=int(1e5))
    parser.add_argument("--lr", type=float, default=7e-4)
    parser.add_argument("--rmsprop-epsilon", type=float, default=1e-2)
    parser.add_argument("--replay-capacity", type=int, default=5000)
    parser.add_argument("--replay-start-size", type=int, default=1000)
    parser.add_argument("--n-times-replay", type=int, default=4)
    parser.add_argument("--disable-online-update", action="store_true")
    parser.add_argument("--logger-level", type=str, default="DEBUG")
    parser.add_argument("--monitor", action="store_true")
    parser.add_argument("--eval-interval-steps", type=int, default=0)
    return parser.parse_args()

def make_env(env_name, seed, is_training=True, monitor=False, render=False):
    env = gym.make(env_name)
    env.seed(seed)
    env.action_space.seed(seed)
    env = CastObservationToFloat32(env)
    if is_training:
        env = ScaleReward(env, factor=args.reward_scale_factor)
    if monitor:
        env = Monitor(env, args.outdir, allow_unsafe=True)
    if render:
        env = Render(env)
    return env

def build_discrete_model(action_space, n_hidden, n_adv_hidden):
    policy = chainerrl.links.Sequence(
        L.Linear(-1, n_hidden),
        L.ReLU(),
        distributions.SoftmaxDistribution(action_space.n))
    q_func = chainerrl.links.Sequence(
        L.Linear(-1, n_hidden),
        L.ReLU(),
        value_functions.DiscreteActionValue(action_space.n))
    adv_func = chainerrl.links.Sequence(
        L.Linear(-1, n_adv_hidden),
        L.ReLU(),
        value_functions.SAQFunction())
    return acer_models.ACERSeparateModel(policy, q_func, adv_func)

def build_continuous_model(action_space, n_hidden, n_adv_hidden):
    low, high = action_space.low, action_space.high
    policy = chainerrl.links.Sequence(
        L.Linear(-1, n_hidden),
        L.ReLU(),
        L.Linear(n_hidden, action_space.shape[0]),
        L.ReLU(),
        L.Linear(action_space.shape[0], action_space.shape[0]),
        L.Activation('tanh'),
        lambda x: distributions.BoundedGaussianDistribution(
            x, mu=None, std=1.0, low=low, high=high))
    value_func = chainerrl.links.Sequence(
        L.Linear(-1, n_hidden),
        L.ReLU(),
        L.Linear(n_hidden, 1))
    adv_func = chainerrl.links.Sequence(
        L.Linear(-1, n_adv_hidden),
        L.ReLU(),
        L.Linear(n_adv_hidden, 1))
    return acer_models.ACERSDNSeparateModel(policy, value_func, adv_func)

def evaluate_agent(agent, env, n_runs, outdir):
    total_reward = 0.0
    for _ in range(n_runs):
        obs = env.reset()
        done = False
        episode_reward = 0.0
        while not done:
            action = agent.act(obs, deterministic=True)
            obs, reward, done, _ = env.step(action)
            episode_reward += reward
        total_reward += episode_reward
    avg_reward = total_reward / n_runs
    log_path = os.path.join(outdir, "eval.txt")
    with open(log_path, "w") as f:
        f.write(f"Average reward over {n_runs} runs: {avg_reward}\\n")
    logging.info(f"Evaluation finished. Avg reward: {avg_reward}")

if __name__ == "__main__":
    args = parse_args()
    logging.basicConfig(level=getattr(logging, args.logger_level.upper()))
    os.makedirs(args.outdir, exist_ok=True)

    np.random.seed(args.seed)
    process_seeds = np.arange(args.processes) + args.seed * args.processes

    # Create training environment
    train_env = make_env(args.env, process_seeds[0], is_training=True,
                         monitor=args.monitor, render=args.render)

    # Test environment for evaluation
    test_seed = 2**32 - 1 - process_seeds[0]
    test_env = make_env(args.env, test_seed, is_training=False,
                        monitor=args.monitor, render=False)

    action_space = train_env.action_space
    if isinstance(action_space, gym.spaces.Box):
        model = build_continuous_model(action_space,
                                       args.n_hidden_channels,
                                       args.n_hidden_channels // 2)
    else:
        model = build_discrete_model(action_space,
                                     args.n_hidden_channels,
                                     args.n_hidden_channels // 2)

    optimizer = chainer.optimizers.RMSpropAsync(lr=args.lr, epsilon=args.rmsprop_epsilon)
    optimizer.setup(model)
    optimizer.clip_grads_by_global_norm(40)

    replay_buffer = EpisodicReplayBuffer(capacity=args.replay_capacity)

    acer_agent = acer.ACER(
        model,
        optimizer,
        gamma=0.99,
        t_max=args.t_max,
        n_times_replay=args.n_times_replay,
        replay_start_size=args.replay_start_size,
        replay_buffer=replay_buffer,
        use_trust_region=True,
        trust_region_delta=0.1,
        truncation_threshold=5,
        beta=1e-2,
        online_update=not args.disable_online_update)

    if args.demo:
        evaluate_agent(acer_agent, test_env, args.eval_n_runs, args.outdir)
        sys.exit(0)

    # Async training
    from chainerrl.training import train_agent_async
    trainer = train_agent_async(
        acer_agent,
        train_env,
        steps=args.steps,
        n_processes=args.processes,
        eval_interval=args.eval_interval,
        eval_agent=acer_agent,
        eval_env=test_env,
        eval_n_episodes=args.eval_n_runs,
        outdir=args.outdir)

    trainer.run()
    logging.info("Training finished.")