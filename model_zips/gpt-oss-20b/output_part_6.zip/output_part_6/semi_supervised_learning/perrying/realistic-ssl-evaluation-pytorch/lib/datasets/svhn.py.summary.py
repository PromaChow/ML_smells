import os
import numpy as np

class SVHN:
    def __init__(self, root: str, split: str = "l_train"):
        self.root = root
        self.split = split
        file_path = os.path.join(root, "svhn", f"{split}.npy")
        self.data = np.load(file_path, allow_pickle=True).item()

    def __getitem__(self, index: int):
        image = self.data["images"][index]
        label = self.data["labels"][index]
        image = image.astype(np.float32) / 255.0
        image = (image - 0.5) / 0.5
        return image, label

    def __len__(self):
        return len(self.data["images"])