import math
import warnings
from typing import Callable, List, Any, Dict

import gymnasium as gym
import numpy as np
import matplotlib.pyplot as plt


class ImageViewer:
    """Simple image viewer using matplotlib."""

    def __init__(self):
        self._fig = None
        self._ax = None

    def show(self, image: np.ndarray):
        if self._fig is None:
            self._fig, self._ax = plt.subplots()
            self._ax.axis("off")
        self._ax.clear()
        self._ax.imshow(image.astype(np.uint8))
        self._fig.canvas.draw()
        plt.pause(0.001)

    def close(self):
        if self._fig is not None:
            plt.close(self._fig)
            self._fig = None
            self._ax = None


class VecEnv:
    def __init__(self, list_make_env: List[Callable[[], gym.Env]]):
        self.list_env: List[gym.Env] = [make() for make in list_make_env]
        first = self.list_env[0]
        self.observation_space = first.observation_space
        self.action_space = first.action_space
        self.reward_range = first.reward_range
        self.spec = first.spec
        self.closed = False
        self.viewer: ImageViewer | None = None
        self.step_async_active = False

    def step(self, actions: List[Any]):
        if len(actions) != len(self.list_env):
            raise ValueError("Number of actions must match number of environments")
        obs, rews, dones, infos = [], [], [], []
        for env, action in zip(self.list_env, actions):
            ob, rew, done, info = env.step(action)
            if done:
                info["final_observation"] = ob
                ob = env.reset()
            obs.append(ob)
            rews.append(rew)
            dones.append(done)
            infos.append(info)
        return obs, rews, dones, infos

    def reset(self):
        if self.step_async_active:
            warnings.warn("step_async is still active, may abort ongoing operations")
        return [env.reset() for env in self.list_env]

    def get_images(self) -> np.ndarray:
        images = [env.render(mode="rgb_array") for env in self.list_env]
        return np.stack(images, axis=0)

    def render(self, mode: str = "human"):
        imgs = self.get_images()
        grid_img = self._grid_images(imgs, columns=5)
        if mode == "human":
            if self.viewer is None:
                self.viewer = self.get_viewer()
            self.viewer.show(grid_img)
        elif mode == "rgb_array":
            return grid_img
        else:
            raise ValueError(f"Unsupported render mode: {mode}")

    def _grid_images(self, imgs: np.ndarray, columns: int) -> np.ndarray:
        n, h, w, c = imgs.shape
        rows = math.ceil(n / columns)
        padded = np.zeros((rows * columns, h, w, c), dtype=imgs.dtype)
        padded[:n] = imgs
        grid_rows = []
        for r in range(rows):
            row_imgs = padded[r * columns : (r + 1) * columns]
            row = np.concatenate(row_imgs, axis=1)
            grid_rows.append(row)
        return np.concatenate(grid_rows, axis=0)

    def get_viewer(self) -> ImageViewer:
        return ImageViewer()

    def close_extras(self):
        for env in self.list_env:
            env.close()

    def close(self):
        if not self.closed:
            if self.viewer is not None:
                self.viewer.close()
                self.viewer = None
            self.close_extras()
            self.closed = True


class VecEnvWrapper:
    def __init__(self, env: VecEnv):
        self.env = env

    def __getattr__(self, name: str) -> Any:
        return getattr(self.env, name)


# ---------- pytest test ----------
def test_vecenv():
    import pytest

    env_fns = [lambda: gym.make("CartPole-v1") for _ in range(4)]
    env_fns += [lambda: gym.make("Pendulum-v1") for _ in range(2)]
    vec_env = VecEnv(env_fns)

    assert len(vec_env.list_env) == 6
    assert vec_env.observation_space is not None
    assert vec_env.action_space is not None
    assert vec_env.spec is not None

    obs = vec_env.reset()
    assert len(obs) == 6

    rng = np.random.default_rng()
    for _ in range(10):
        actions = [vec_env.action_space.sample() for _ in range(len(vec_env.list_env))]
        obs, rew, dones, infos = vec_env.step(actions)
        assert len(obs) == len(vec_env.list_env)
        assert len(rew) == len(vec_env.list_env)
        assert len(dones) == len(vec_env.list_env)
        assert len(infos) == len(vec_env.list_env)

    vec_env.close()
    assert vec_env.closed
    # Test that rendering does not raise
    try:
        vec_env.render(mode="rgb_array")
    except Exception as e:
        pytest.fail(f"Render raised an exception: {e}")
