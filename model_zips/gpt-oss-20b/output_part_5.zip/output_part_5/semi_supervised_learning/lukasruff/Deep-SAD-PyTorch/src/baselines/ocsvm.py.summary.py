import os
import json
import time
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from sklearn.svm import OneClassSVM
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedShuffleSplit


class AutoEncoder(nn.Module):
    """Placeholder autoencoder with an encoder submodule."""
    def __init__(self, input_dim, latent_dim):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.ReLU(),
            nn.Linear(128, latent_dim)
        )
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, 128),
            nn.ReLU(),
            nn.Linear(128, input_dim),
            nn.Sigmoid()
        )

    def forward(self, x):
        z = self.encoder(x)
        return self.decoder(z)


class OCSVM:
    def __init__(self, kernel='rbf', nu=0.1, hybrid=False, device=None):
        self.kernel = kernel
        self.nu = nu
        self.hybrid = hybrid
        self.device = device or torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.svm = OneClassSVM(kernel=kernel, nu=nu)
        self.linear_svm = None
        self.ae_net = None
        self.results = {
            'train_time': None,
            'test_time': None,
            'best_gamma': None,
            'validation_auc': None,
            'test_auc': None,
            'test_scores': None,
            'test_indices': None,
            'test_labels': None,
            'test_rho': None,
            'train_time_linear': None,
            'test_time_linear': None,
            'test_auc_linear': None,
        }

    def train(self, train_loader, val_loader):
        start_train = time.time()
        X_list = []
        for batch in train_loader:
            data = batch[0].to(self.device)
            if self.hybrid and self.ae_net is not None:
                with torch.no_grad():
                    data = self.ae_net.encoder(data)
            X_list.append(data.cpu().numpy())
        X = np.concatenate(X_list, axis=0)
        if X.ndim > 2:
            X = X.reshape(X.shape[0], -1)

        # Prepare validation data
        val_data = []
        val_labels = []
        for batch in val_loader:
            data, labels = batch
            if self.hybrid and self.ae_net is not None:
                with torch.no_grad():
                    data = self.ae_net.encoder(data.to(self.device))
            val_data.append(data.cpu().numpy())
            val_labels.append(labels.numpy())
        X_val = np.concatenate(val_data, axis=0)
        y_val = np.concatenate(val_labels, axis=0)
        if X_val.ndim > 2:
            X_val = X_val.reshape(X_val.shape[0], -1)

        # Validation split (10% of validation set)
        splitter = StratifiedShuffleSplit(n_splits=1, test_size=0.1, random_state=42)
        for _, val_idx in splitter.split(X_val, y_val):
            X_val_subset = X_val[val_idx]
            y_val_subset = y_val[val_idx]

        gamma_grid = np.logspace(-7, 2, 10)
        best_auc = -np.inf
        best_gamma = None
        best_model = None
        for gamma in gamma_grid:
            model = OneClassSVM(kernel=self.kernel, nu=self.nu, gamma=gamma)
            model.fit(X)
            scores = model.decision_function(X_val_subset)
            auc = roc_auc_score(y_val_subset, -scores)  # negative for anomaly
            if auc > best_auc:
                best_auc = auc
                best_gamma = gamma
                best_model = model

        self.svm = best_model
        self.results['best_gamma'] = best_gamma
        self.results['validation_auc'] = best_auc

        if self.hybrid:
            start_linear = time.time()
            self.linear_svm = OneClassSVM(kernel='linear', nu=self.nu)
            self.linear_svm.fit(X)
            self.results['train_time_linear'] = time.time() - start_linear

        self.results['train_time'] = time.time() - start_train

    def test(self, test_loader):
        start_test = time.time()
        X_test_list = []
        indices = []
        labels = []
        for batch in test_loader:
            data, label, idx = batch
            indices.extend(idx.numpy())
            labels.extend(label.numpy())
            if self.hybrid and self.ae_net is not None:
                with torch.no_grad():
                    data = self.ae_net.encoder(data.to(self.device))
            X_test_list.append(data.cpu().numpy())
        X_test = np.concatenate(X_test_list, axis=0)
        if X_test.ndim > 2:
            X_test = X_test.reshape(X_test.shape[0], -1)

        scores = self.svm.decision_function(X_test)
        self.results['test_scores'] = -scores.tolist()
        self.results['test_indices'] = indices
        self.results['test_labels'] = labels
        self.results['test_rho'] = self.svm.rho_
        self.results['test_auc'] = roc_auc_score(labels, -scores)
        self.results['test_time'] = time.time() - start_test

        if self.hybrid and self.linear_svm is not None:
            start_linear = time.time()
            linear_scores = self.linear_svm.decision_function(X_test)
            self.results['test_auc_linear'] = roc_auc_score(labels, -linear_scores)
            self.results['test_time_linear'] = time.time() - start_linear

    def load_ae(self, path, input_dim, latent_dim):
        self.ae_net = AutoEncoder(input_dim, latent_dim).to(self.device)
        state_dict = torch.load(path, map_location=self.device)
        missing, unexpected = self.ae_net.load_state_dict(state_dict, strict=False)
        self.ae_net.eval()

    def save_results(self, filepath):
        with open(filepath, 'w') as f:
            json.dump(self.results, f, indent=2)

    def save_model(self, path):
        # Stub for future implementation
        pass

    def load_model(self, path):
        # Stub for future implementation
        pass
```