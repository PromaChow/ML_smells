import numpy as np

# Weight matrices and bias vectors
weights_dense1_w = np.array([
    [0.2, -0.4, 0.1],
    [0.7, 0.3, -0.5],
    [-0.6, 0.9, 0.2],
    [0.5, -0.1, 0.4]
])

weights_dense1_b = np.array([0.1, -0.2, 0.05])

weights_dense2_w = np.array([
    [0.3, -0.7],
    [-0.2, 0.6],
    [0.8, -0.3]
])

weights_dense2_b = np.array([0.05, -0.1])

weights_final_w = np.array([
    [0.4],
    [-0.5]
])

weights_final_b = np.array([0.02])

def dense_forward(input_data, w, b):
    return np.dot(input_data, w) + b

def main():
    # Example input data: batch of 2 samples, each with 4 features
    input_data = np.array([
        [1.0, 0.5, -0.5, 2.0],
        [-1.0, 1.5, 0.0, -0.5]
    ])

    # Forward pass through the three dense layers
    out1 = dense_forward(input_data, weights_dense1_w, weights_dense1_b)
    out2 = dense_forward(out1, weights_dense2_w, weights_dense2_b)
    final_output = dense_forward(out2, weights_final_w, weights_final_b)

    print("Final predictions:")
    print(final_output)

if __name__ == "__main__":
    main()
