import importlib
import numpy as np

# Reload the feature_axis module
feature_axis = importlib.import_module('src.tl_gan.feature_axis')
importlib.reload(feature_axis)

# Import required functions from the module
from src.tl_gan.feature_axis import (
    normalize_feature_axis,
    orthogonalize_one_vector,
    orthogonalize_vectors,
    disentangle_feature_axis_by_idx,
    plot_feature_cos_sim
)

# 1. Data Generation
np.random.seed(0)
vectors = np.random.rand(10, 4)

# 2. Initial Norm Check
initial_sq_norms = np.sum(vectors**2, axis=0)

# 3. Feature Normalization
vectors_normalized = normalize_feature_axis(vectors)
norms_after_norm = np.sum(vectors_normalized**2, axis=0)

# 4. Orthogonalization of a Single Vector
v1 = np.array([1, 0, 0])
v2 = np.array([1, 1, 1])
v2_ortho = orthogonalize_one_vector(v1, v2)

# 5. Orthogonalization of All Vectors
vectors_orthogonal = orthogonalize_vectors(vectors_normalized)

# 6. Disentanglement of Features
vectors_disentangled = disentangle_feature_axis_by_idx(
    vectors,
    idx_base=[0],
    idx_target=[2, 3]
)

# 7. Dot Product Verification (last two features)
dot_last_two = np.dot(vectors_normalized[:, -2], vectors_orthogonal[:, -1])

# 8. Cosine Similarity Visualization
plot_feature_cos_sim(vectors, title='Original Vectors')
plot_feature_cos_sim(vectors_orthogonal, title='Orthogonalized Vectors')
plot_feature_cos_sim(vectors_disentangled, title='Disentangled Vectors')