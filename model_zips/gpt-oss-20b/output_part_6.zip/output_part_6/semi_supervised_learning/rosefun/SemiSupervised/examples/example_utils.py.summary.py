import numpy as np
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split

def normalize(X):
    X_min = X.min(axis=0)
    X_max = X.max(axis=0)
    denom = X_max - X_min
    denom[denom == 0] = 1
    return (X - X_min) / denom

def prepare_data():
    X, y = load_breast_cancer(return_X_y=True)
    X_norm = normalize(X)
    X_train, X_test, y_train, y_test = train_test_split(
        X_norm, y, test_size=0.1, random_state=0
    )
    rs = np.random.RandomState(42)
    idx_unlabel = rs.choice(len(y_train), size=int(0.1 * len(y_train)), replace=False)
    y_train[idx_unlabel] = -1
    mask_labeled = y_train != -1
    label_X_train = X_train[mask_labeled]
    label_y_train = y_train[mask_labeled]
    unlabel_X_train = X_train[~mask_labeled]
    unlabel_y = np.full(unlabel_X_train.shape[0], -1)
    return label_X_train, label_y_train, unlabel_X_train, unlabel_y, X_test, y_test

if __name__ == "__main__":
    label_X_train, label_y_train, unlabel_X_train, unlabel_y, X_test, y_test = prepare_data()
    print("Labeled training shape:", label_X_train.shape, label_y_train.shape)
    print("Unlabeled training shape:", unlabel_X_train.shape, unlabel_y.shape)
    print("Test shape:", X_test.shape, y_test.shape)