import random
import logging
from pathlib import Path
import numpy as np


def write_data(data_str: str, filepath: Path) -> None:
    filepath.write_text(data_str, encoding="utf-8")


class CovertypeDataBandit:
    def __init__(self, filepath: Path):
        self.data = np.loadtxt(filepath, delimiter=",")
        self.n_samples, self.n_features = self.data.shape
        self.context_dim = self.n_features - 1

    def sample_context(self) -> np.ndarray:
        idx = random.randint(0, self.n_samples - 1)
        context = self.data[idx, : self.context_dim]
        return context

    def get_reward(self, context: np.ndarray, action: int) -> float:
        # Dummy reward: last column of the selected sample
        idx = random.randint(0, self.n_samples - 1)
        return float(self.data[idx, -1])


class NeuralGreedyAgent:
    def __init__(self, bandit: CovertypeDataBandit):
        self.bandit = bandit
        self.weights = np.zeros(self.bandit.context_dim)

    def choose_action(self, context: np.ndarray) -> int:
        # Greedy: choose action 0 for simplicity
        return 0

    def update(self, context: np.ndarray, action: int, reward: float) -> None:
        # Simple gradient step placeholder
        self.weights += 0.01 * reward * context


class DCBTrainer:
    def __init__(
        self,
        agent: NeuralGreedyAgent,
        bandit: CovertypeDataBandit,
        log_mode: str = "stdout",
    ):
        self.agent = agent
        self.bandit = bandit
        self.logger = logging.getLogger("DCBTrainer")
        if log_mode == "stdout":
            handler = logging.StreamHandler()
            handler.setFormatter(
                logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
            )
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)

    def run(
        self,
        timesteps: int,
        update_interval: int,
        update_after: int,
        batch_size: int,
    ) -> None:
        for t in range(1, timesteps + 1):
            context = self.bandit.sample_context()
            action = self.agent.choose_action(context)
            reward = self.bandit.get_reward(context, action)
            self.agent.update(context, action, reward)

            if t % update_interval == 0 and t >= update_after:
                self.logger.info(
                    f"Step {t}: Updated agent weights: {self.agent.weights}"
                )
        self.logger.info("Training completed.")


if __name__ == "__main__":
    d = """0.1,0.2,1
0.3,0.4,0
0.5,0.6,1
0.7,0.8,0
0.9,1.0,1"""
    fpath = Path("covtype.data")
    write_data(d, fpath)

    bandit = CovertypeDataBandit(fpath)
    agent = NeuralGreedyAgent(bandit)
    trainer = DCBTrainer(agent, bandit, log_mode="stdout")
    trainer.run(
        timesteps=10,
        update_interval=2,
        update_after=5,
        batch_size=2,
    )

    fpath.unlink()
