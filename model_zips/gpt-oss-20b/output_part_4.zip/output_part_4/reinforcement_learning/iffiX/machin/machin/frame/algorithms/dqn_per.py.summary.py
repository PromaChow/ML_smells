import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import random
import numpy as np
from collections import deque
from copy import deepcopy

class PrioritizedBuffer:
    def __init__(self, capacity, device='cpu', alpha=0.6, beta_start=0.4, beta_frames=100000):
        self.capacity = capacity
        self.device = device
        self.alpha = alpha
        self.beta_start = beta_start
        self.beta_frames = beta_frames
        self.frame = 1
        self.buffer = []
        self.priorities = np.zeros((capacity,), dtype=np.float32)
        self.pos = 0

    def add(self, state, action, reward, next_state, done):
        max_prio = self.priorities.max() if self.buffer else 1.0
        if len(self.buffer) < self.capacity:
            self.buffer.append((state, action, reward, next_state, done))
        else:
            self.buffer[self.pos] = (state, action, reward, next_state, done)
        self.priorities[self.pos] = max_prio
        self.pos = (self.pos + 1) % self.capacity

    def sample(self, batch_size):
        if len(self.buffer) == self.capacity:
            prios = self.priorities
        else:
            prios = self.priorities[:self.pos]
        probs = prios ** self.alpha
        probs /= probs.sum()
        indices = np.random.choice(len(self.buffer), batch_size, p=probs)
        samples = [self.buffer[idx] for idx in indices]
        states, actions, rewards, next_states, dones = zip(*samples)

        states = torch.stack(states).to(self.device)
        actions = torch.tensor(actions, dtype=torch.long, device=self.device).unsqueeze(1)
        rewards = torch.tensor(rewards, dtype=torch.float32, device=self.device).unsqueeze(1)
        next_states = torch.stack(next_states).to(self.device)
        dones = torch.tensor(dones, dtype=torch.float32, device=self.device).unsqueeze(1)

        total = len(self.buffer)
        beta = min(1.0, self.beta_start + self.frame * (1.0 - self.beta_start) / self.beta_frames)
        self.frame += 1
        weights = (total * probs[indices]) ** (-beta)
        weights /= weights.max()
        weights = torch.tensor(weights, dtype=torch.float32, device=self.device).unsqueeze(1)
        return states, actions, rewards, next_states, dones, weights, indices

    def update_priorities(self, indices, errors):
        for idx, err in zip(indices, errors):
            self.priorities[idx] = float(err) + 1e-5

class DQN(nn.Module):
    def __init__(self, net, target_net, optimizer, criterion, gamma=0.99,
                 update_steps=1, update_rate=0.005, update_value=True, update_target=True):
        super().__init__()
        self.net = net
        self.target_net = target_net
        self.optimizer = optimizer
        self.criterion = criterion
        self.gamma = gamma
        self.update_steps = update_steps
        self.update_rate = update_rate
        self.update_value = update_value
        self.update_target = update_target
        self.step_counter = 0
        self.device = next(self.net.parameters()).device

class DQNPer(DQN):
    def __init__(self, net, target_net, optimizer, criterion,
                 replay_buffer=None,
                 replay_size=100000, replay_device='cpu',
                 **kwargs):
        super().__init__(net, target_net, optimizer, criterion, **kwargs)
        if replay_buffer is None:
            self.replay_buffer = PrioritizedBuffer(replay_size, replay_device)
        else:
            self.replay_buffer = replay_buffer
        if getattr(self.criterion, 'reduction', None) != 'none':
            self.criterion.reduction = 'none'

    def update(self, batch_size):
        if len(self.replay_buffer.buffer) < batch_size:
            return None
        states, actions, rewards, next_states, dones, weights, indices = self.replay_buffer.sample(batch_size)

        with torch.no_grad():
            next_q = self.net(next_states)
            greedy_actions = next_q.argmax(dim=1, keepdim=True)
            target_next_q = self.target_net(next_states)
            target_q = target_next_q.gather(1, greedy_actions)

        current_q = self.net(states).gather(1, actions)
        target_values = rewards + (1 - dones) * self.gamma * target_q

        loss_per = self.criterion(current_q, target_values)
        loss = (loss_per * weights).mean()

        errors = torch.abs(current_q - target_values).detach().squeeze()
        self.replay_buffer.update_priorities(indices, errors.cpu().numpy())

        if self.update_value:
            self.optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.net.parameters(), 1.0)
            self.optimizer.step()

        self.step_counter += 1
        if self.update_target:
            if self.update_rate:
                tau = self.update_rate
                for target_param, param in zip(self.target_net.parameters(), self.net.parameters()):
                    target_param.data.copy_(tau * param.data + (1.0 - tau) * target_param.data)
            elif self.update_steps and self.step_counter % self.update_steps == 0:
                self.target_net.load_state_dict(self.net.state_dict())

        self.net.eval()
        return loss.item()

    def generate_config(self, cfg):
        cfg['algo'] = 'DQNPer'
        return cfg

    @classmethod
    def init_from_config(cls, cfg, net, target_net, optimizer, criterion):
        return cls(
            net=net,
            target_net=target_net,
            optimizer=optimizer,
            criterion=criterion,
            replay_size=cfg.get('replay_size', 100000),
            replay_device=cfg.get('replay_device', 'cpu'),
            gamma=cfg.get('gamma', 0.99),
            update_steps=cfg.get('update_steps', 1),
            update_rate=cfg.get('update_rate', 0.005),
            update_value=cfg.get('update_value', True),
            update_target=cfg.get('update_target', True)
        )

# Example simple network and usage
if __name__ == "__main__":
    obs_dim = 4
    n_actions = 2
    net = nn.Sequential(
        nn.Linear(obs_dim, 128),
        nn.ReLU(),
        nn.Linear(128, n_actions)
    )
    target_net = deepcopy(net)
    optimizer = optim.Adam(net.parameters(), lr=1e-3)
    criterion = nn.MSELoss(reduction='none')

    agent = DQNPer(net, target_net, optimizer, criterion)
    # Dummy data
    for _ in range(10):
        state = torch.randn(obs_dim)
        action = random.randint(0, n_actions - 1)
        reward = random.random()
        next_state = torch.randn(obs_dim)
        done = random.choice([0, 1])
        agent.replay_buffer.add(state, action, reward, next_state, done)

    for _ in range(5):
        loss = agent.update(batch_size=4)
        if loss is not None:
            print(f"Loss: {loss:.4f}")
        else:
            print("Not enough samples")
