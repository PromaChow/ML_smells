import unittest

class TestSetup(unittest.TestCase):
    """Verify that required dependencies from requirements.txt are importable."""

    def test__numpy(self):
        import numpy as np
        self.assertIsNotNone(np)

    def test__scipy(self):
        import scipy
        self.assertIsNotNone(scipy)

    def test__pandas(self):
        import pandas as pd
        self.assertIsNotNone(pd)

    # def test__pandas_datareader(self):
    #     import pandas_datareader as pdr
    #     self.assertIsNotNone(pdr)

    def test__sklearn(self):
        import sklearn
        self.assertIsNotNone(sklearn)

    def test__mpl(self):
        import matplotlib as mpl
        mpl.use('Agg')
        self.assertIsNotNone(mpl)

    # def test__keras(self):
    #     import keras
    #     self.assertIsNotNone(keras)

    def test__statsmodels(self):
        import statsmodels
        self.assertIsNotNone(statsmodels)

    def test__qtrader(self):
        import qtrader
        self.assertIsNotNone(qtrader)

if __name__ == "__main__":
    unittest.main()
