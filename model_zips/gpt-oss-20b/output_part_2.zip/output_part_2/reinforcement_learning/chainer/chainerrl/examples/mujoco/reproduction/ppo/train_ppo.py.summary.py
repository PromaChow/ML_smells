import argparse
import os
import random
import time
import json
import math
import collections
import statistics
from pathlib import Path

import gymnasium as gym
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim import Adam
from torch.distributions import Normal
import multiprocessing as mp

# ------------------------------------------------------------
# Utilities
# ------------------------------------------------------------
def set_global_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


class EmpiricalNormalization:
    def __init__(self, shape, clip=5.0):
        self.shape = shape
        self.clip = clip
        self.mean = torch.zeros(shape)
        self.var = torch.ones(shape)
        self.count = 0

    def update(self, data):
        batch_mean = torch.mean(data, dim=0)
        batch_var = torch.var(data, dim=0, unbiased=False)
        batch_count = data.size(0)

        if self.count == 0:
            self.mean = batch_mean
            self.var = batch_var
            self.count = batch_count
        else:
            delta = batch_mean - self.mean
            tot_count = self.count + batch_count

            new_mean = self.mean + delta * batch_count / tot_count
            m_a = self.var * self.count
            m_b = batch_var * batch_count
            M2 = m_a + m_b + delta.pow(2) * self.count * batch_count / tot_count
            new_var = M2 / tot_count

            self.mean = new_mean
            self.var = new_var
            self.count = tot_count

    def normalize(self, data):
        std = torch.sqrt(self.var + 1e-8)
        norm = (data - self.mean) / std
        return torch.clamp(norm, -self.clip, self.clip)


# ------------------------------------------------------------
# Environment creation
# ------------------------------------------------------------
def make_env(env_id, seed, idx, render_mode=None):
    def _thunk():
        env = gym.make(env_id, render_mode=render_mode)
        env.seed(seed + idx)
        return env
    return _thunk


class MultiprocessVectorEnv:
    def __init__(self, env_fns):
        self.envs = [fn() for fn in env_fns]
        self.num_envs = len(env_fns)
        self.observation_space = self.envs[0].observation_space
        self.action_space = self.envs[0].action_space
        self.reset()

    def reset(self):
        obs, _ = zip(*[env.reset() for env in self.envs])
        self.obs = np.stack(obs)
        return self.obs

    def step_async(self, actions):
        self.actions = actions

    def step_wait(self):
        results = [env.step(a) for env, a in zip(self.envs, self.actions)]
        next_obs, rewards, dones, infos = zip(*results)
        next_obs = np.stack(next_obs)
        rewards = np.stack(rewards)
        dones = np.stack(dones)
        infos = [info for info in infos]
        self.obs = next_obs
        return next_obs, rewards, dones, infos

    def close(self):
        for env in self.envs:
            env.close()


# ------------------------------------------------------------
# Networks
# ------------------------------------------------------------
def orthogonal_init(layer, gain=1.0):
    nn.init.orthogonal_(layer.weight, gain)
    if layer.bias is not None:
        nn.init.constant_(layer.bias, 0.0)
    return layer


class PolicyNet(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden_dim=64):
        super().__init__()
        self.shared = nn.Sequential(
            orthogonal_init(nn.Linear(obs_dim, hidden_dim)),
            nn.ReLU(),
            orthogonal_init(nn.Linear(hidden_dim, hidden_dim)),
            nn.ReLU(),
        )
        self.mean_head = orthogonal_init(nn.Linear(hidden_dim, act_dim))
        self.log_std = nn.Parameter(torch.zeros(act_dim))

    def forward(self, x):
        h = self.shared(x)
        mean = self.mean_head(h)
        std = torch.exp(self.log_std)
        return mean, std


class ValueNet(nn.Module):
    def __init__(self, obs_dim, hidden_dim=64):
        super().__init__()
        self.net = nn.Sequential(
            orthogonal_init(nn.Linear(obs_dim, hidden_dim)),
            nn.ReLU(),
            orthogonal_init(nn.Linear(hidden_dim, hidden_dim)),
            nn.ReLU(),
            orthogonal_init(nn.Linear(hidden_dim, 1)),
        )

    def forward(self, x):
        return self.net(x).squeeze(-1)


class ActorCritic(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden_dim=64):
        super().__init__()
        self.policy = PolicyNet(obs_dim, act_dim, hidden_dim)
        self.value = ValueNet(obs_dim, hidden_dim)

    def forward(self, x):
        return self.policy(x), self.value(x)


# ------------------------------------------------------------
# PPO Agent
# ------------------------------------------------------------
class PPOAgent:
    def __init__(self,
                 env,
                 device,
                 update_freq=2048,
                 minibatch_size=64,
                 epochs=10,
                 gamma=0.995,
                 lam=0.97,
                 clip_eps=0.2,
                 clip_eps_vf=None,
                 lr=3e-4,
                 eps=1e-5,
                 ent_coef=0.0,
                 std_clip=5.0):
        self.env = env
        self.device = device
        self.update_freq = update_freq
        self.minibatch_size = minibatch_size
        self.epochs = epochs
        self.gamma = gamma
        self.lam = lam
        self.clip_eps = clip_eps
        self.clip_eps_vf = clip_eps_vf
        self.ent_coef = ent_coef
        self.std_clip = std_clip

        obs_dim = env.observation_space.shape[0]
        act_dim = env.action_space.shape[0]
        self.policy = ActorCritic(obs_dim, act_dim).to(device)
        self.optimizer = Adam(self.policy.parameters(), lr=lr, eps=eps)
        self.obs_norm = EmpiricalNormalization((obs_dim,), clip=std_clip)

        self.buffer = collections.deque(maxlen=update_freq)

    def select_action(self, obs):
        obs_t = torch.as_tensor(obs, dtype=torch.float32, device=self.device)
        self.obs_norm.update(obs_t.unsqueeze(0))
        norm_obs = self.obs_norm.normalize(obs_t)
        mean, std = self.policy.policy(norm_obs)
        dist = Normal(mean, std)
        action = dist.sample()
        logp = dist.log_prob(action).sum(-1)
        with torch.no_grad():
            value = self.policy.value(norm_obs)
        return action.cpu().numpy(), logp.item(), value.item()

    def store(self, obs, action, logp, value, reward, done):
        self.buffer.append((obs, action, logp, value, reward, done))

    def compute_gae(self, next_value):
        obs, act, logp, val, rew, done = zip(*self.buffer)
        obs = np.array(obs)
        act = np.array(act)
        logp = np.array(logp)
        val = np.array(val)
        rew = np.array(rew)
        done = np.array(done)

        val = np.append(val, next_value)
        advantage = np.zeros_like(rew)
        lastgaelam = 0
        for t in reversed(range(len(rew))):
            delta = rew[t] + self.gamma * val[t + 1] * (1 - done[t]) - val[t]
            advantage[t] = lastgaelam = delta + self.gamma * self.lam * (1 - done[t]) * lastgaelam
        returns = advantage + val[:-1]
        return obs, act, logp, advantage, returns

    def update(self, next_value):
        obs, act, logp, adv, ret = self.compute_gae(next_value)
        obs = torch.as_tensor(obs, dtype=torch.float32, device=self.device)
        act = torch.as_tensor(act, dtype=torch.float32, device=self.device)
        logp_old = torch.as_tensor(logp, dtype=torch.float32, device=self.device)
        adv = torch.as_tensor(adv, dtype=torch.float32, device=self.device)
        ret = torch.as_tensor(ret, dtype=torch.float32, device=self.device)

        for _ in range(self.epochs):
            indices = np.arange(len(obs))
            np.random.shuffle(indices)
            for start in range(0, len(obs), self.minibatch_size):
                end = start + self.minibatch_size
                batch_idx = indices[start:end]
                batch_obs = obs[batch_idx]
                batch_act = act[batch_idx]
                batch_logp_old = logp_old[batch_idx]
                batch_adv = adv[batch_idx]
                batch_ret = ret[batch_idx]

                mean, std = self.policy.policy(batch_obs)
                dist = Normal(mean, std)
                logp = dist.log_prob(batch_act).sum(-1)
                ratio = torch.exp(logp - batch_logp_old)
                surr1 = ratio * batch_adv
                surr2 = torch.clamp(ratio, 1.0 - self.clip_eps, 1.0 + self.clip_eps) * batch_adv
                policy_loss = -torch.min(surr1, surr2).mean()

                if self.clip_eps_vf is not None:
                    value = self.policy.value(batch_obs)
                    value_clipped = batch_ret + torch.clamp(value - batch_ret,
                                                             -self.clip_eps_vf, self.clip_eps_vf)
                    vf_loss1 = (value - batch_ret).pow(2)
                    vf_loss2 = (value_clipped - batch_ret).pow(2)
                    value_loss = 0.5 * torch.max(vf_loss1, vf_loss2).mean()
                else:
                    value = self.policy.value(batch_obs)
                    value_loss = 0.5 * (value - batch_ret).pow(2).mean()

                entropy = dist.entropy().mean()
                loss = policy_loss + value_loss - self.ent_coef * entropy

                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()

        self.buffer.clear()

    def evaluate(self, env, n_episodes=100):
        returns = []
        for _ in range(n_episodes):
            obs, _ = env.reset()
            done = False
            ep_ret = 0.0
            while not done:
                action, _, _ = self.select_action(obs)
                obs, reward, done, _ = env.step(action)
                ep_ret += reward
            returns.append(ep_ret)
        return returns


# ------------------------------------------------------------
# Main training loop
# ------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--env", type=str, default="Hopper-v2")
    parser.add_argument("--num-envs", type=int, default=1)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--output-dir", type=str, default="results")
    parser.add_argument("--total-steps", type=int, default=2_000_000)
    parser.add_argument("--eval-interval", type=int, default=100_000)
    parser.add_argument("--eval-n-runs", type=int, default=100)
    parser.add_argument("--gpu", type=int, default=0)
    parser.add_argument("--render", action="store_true")
    parser.add_argument("--logger-level", type=str, default="INFO")
    parser.add_argument("--demo", action="store_true")
    parser.add_argument("--load-pretrained", action="store_true")
    parser.add_argument("--load", type=str, default=None)
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    device = torch.device(f"cuda:{args.gpu}" if args.gpu >= 0 and torch.cuda.is_available() else "cpu")

    set_global_seed(args.seed)

    env_fns = [make_env(args.env, args.seed, i, render_mode="rgb_array" if args.render else None)
               for i in range(args.num-envs)]
    vec_env = MultiprocessVectorEnv(env_fns)
    agent = PPOAgent(vec_env, device)

    if args.load_pretrained:
        # placeholder: replace with actual download logic
        pretrained_path = Path(args.output_dir) / "pretrained.pt"
        if pretrained_path.exists():
            agent.policy.load_state_dict(torch.load(pretrained_path, map_location=device))
    if args.load:
        agent.policy.load_state_dict(torch.load(args.load, map_location=device))

    if args.demo:
        eval_env_fns = [make_env(args.env, args.seed + 1000 + i, i) for i in range(args.num_envs)]
        eval_env = MultiprocessVectorEnv(eval_env_fns)
        returns = agent.evaluate(eval_env, args.eval_n_runs)
        print(f"Demo: mean={np.mean(returns):.2f}, median={statistics.median(returns):.2f}, stdev={np.std(returns):.2f}")
        return

    start_time = time.time()
    obs = vec_env.reset()
    ep_ret = np.zeros(args.num_envs)
    ep_len = np.zeros(args.num_envs)
    step = 0

    while step < args.total_steps:
        for _ in range(agent.update_freq):
            action, logp, value = agent.select_action(obs)
            next_obs, reward, done, _ = vec_env.step_wait()
            agent.store(obs, action, logp, value, reward, done)

            obs = next_obs
            ep_ret += reward
            ep_len += 1

            step += 1

            if step % 1000 == 0:
                elapsed = time.time() - start_time
                print(f"Step {step}/{args.total_steps} | Elapsed {elapsed:.1f}s")

            if step % args.eval_interval == 0:
                eval_env_fns = [make_env(args.env, args.seed + 2000 + i, i) for i in range(args.num_envs)]
                eval_env = MultiprocessVectorEnv(eval_env_fns)
                returns = agent.evaluate(eval_env, args.eval_n_runs)
                print(f"Evaluation at step {step}: mean={np.mean(returns):.2f}, median={statistics.median(returns):.2f}, stdev={np.std(returns):.2f}")
                torch.save(agent.policy.state_dict(), os.path.join(args.output_dir, f"policy_step_{step}.pt"))

        with torch.no_grad():
            next_obs, _, done, _ = vec_env.step_wait()
            next_value = agent.policy.value(torch.as_tensor(next_obs, dtype=torch.float32, device=device)).cpu().numpy()
            agent.update(next_value)

    torch.save(agent.policy.state_dict(), os.path.join(args.output_dir, "policy_final.pt"))
    print("Training finished.")


if __name__ == "__main__":
    main()
