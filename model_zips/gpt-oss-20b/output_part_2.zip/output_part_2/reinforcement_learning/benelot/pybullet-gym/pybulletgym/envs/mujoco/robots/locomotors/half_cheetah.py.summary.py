import numpy as np
from your_robot_framework import WalkerBase, MJCFBasedRobot  # replace with actual module name


class HalfCheetah(WalkerBase, MJCFBasedRobot):
    foot_list = ["ffoot", "fshin", "fthigh", "bfoot", "bshin", "bthigh"]

    def __init__(self):
        WalkerBase.__init__(self, power=1)
        MJCFBasedRobot.__init__(
            self,
            xml_file="half_cheetah.xml",
            root_body="torso",
            action_dim=6,
            observation_dim=17,
            add_ignored_joints=True,
        )
        self.pos_after = 0.0

    def calc_state(self):
        qpos = self.scene.qpos
        qvel = self.scene.qvel
        state = np.concatenate([qpos[1:], qvel])
        return state

    def calc_potential(self):
        pos_before = self.pos_after
        torso = self.scene.body("torso")
        self.pos_after = torso.x[0]
        potential = (self.pos_after - pos_before) / self.scene.dt
        return potential

    def robot_specific_reset(self):
        WalkerBase.robot_specific_reset(self)

        for body in self.scene.bodies:
            self.scene.changeDynamics(
                body,
                lateralFriction=0.8,
                spinningFriction=0.1,
                rollingFriction=0.1,
                restitution=0.5,
            )

        power_coeffs = {
            "bthigh": 120.0,
            "bshin": 90.0,
            "bfoot": 60.0,
            "fthigh": 140.0,
            "fshin": 60.0,
            "ffoot": 30.0,
        }

        for joint_name, coeff in power_coeffs.items():
            self.scene.setJointActuatorCoeff(joint_name, coeff)