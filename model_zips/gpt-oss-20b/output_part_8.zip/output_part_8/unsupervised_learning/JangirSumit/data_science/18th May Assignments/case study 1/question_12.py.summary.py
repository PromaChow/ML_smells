import numpy as np

arr = np.random.random(16)
arr_4d = arr.reshape(2, 2, 2, 2)
print("4D array:\n", arr_4d)

sum_axis0 = np.sum(arr_4d, axis=0)
print("Sum along axis 0:\n", sum_axis0)