import enum
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, Iterator, List, Optional


class StepType(enum.IntEnum):
    FIRST = 0
    MID = 1
    LAST = 2


@dataclass
class TimeStep:
    step_type: StepType
    observation: Any
    reward: Optional[float] = None
    done: Optional[bool] = None
    info: Dict[str, Any] = field(default_factory=dict)

    def __getitem__(self, key: str) -> Any:
        return self.info[key]

    def first(self) -> bool:
        assert self.step_type == StepType.FIRST, "Step is not FIRST"
        assert self.reward is None, "FIRST step should not have reward"
        assert self.done is None, "FIRST step should not have done flag"
        assert not self.info, "FIRST step should not have info"
        return True

    def mid(self) -> bool:
        assert self.step_type == StepType.MID, "Step is not MID"
        assert self.step_type != StepType.FIRST, "MID step cannot be FIRST"
        assert self.step_type != StepType.LAST, "MID step cannot be LAST"
        return True

    def last(self) -> bool:
        assert self.step_type == StepType.LAST, "Step is not LAST"
        assert self.done is True, "LAST step must have done=True"
        return True

    def time_limit(self) -> bool:
        return self.step_type == StepType.LAST and self.info.get("TimeLimit.truncated", False)

    def terminal(self) -> bool:
        return self.step_type == StepType.LAST and not self.time_limit()

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(step_type={self.step_type.name})"


class Trajectory:
    def __init__(self) -> None:
        self.timesteps: List[TimeStep] = []
        self._actions: List[Any] = []
        self._extra_info: Dict[str, Any] = {}
        self._iter_index: int = 0

    def __len__(self) -> int:
        return len(self.timesteps)

    @property
    def T(self) -> int:
        return max(0, len(self.timesteps) - 1)

    def __iter__(self) -> Iterator[TimeStep]:
        self._iter_index = 0
        return self

    def __next__(self) -> TimeStep:
        if self._iter_index >= len(self.timesteps):
            raise StopIteration
        ts = self.timesteps[self._iter_index]
        self._iter_index += 1
        return ts

    @property
    def finished(self) -> bool:
        return bool(self.timesteps) and self.timesteps[-1].step_type == StepType.LAST

    @property
    def reach_time_limit(self) -> bool:
        return self.finished and self.timesteps[-1].time_limit()

    @property
    def reach_terminal(self) -> bool:
        return self.finished and self.timesteps[-1].terminal()

    def add(self, timestep: TimeStep, action: Any = None) -> None:
        if self.finished:
            raise RuntimeError("Cannot add to a finished trajectory")
        if not self.timesteps:
            assert timestep.step_type == StepType.FIRST, "First timestep must be FIRST"
            assert action is None, "No action should be provided for FIRST timestep"
        else:
            assert action is not None, "Non-first timesteps must have an action"
            self._actions.append(action)
        self.timesteps.append(timestep)

    @property
    def observations(self) -> List[Any]:
        return [t.observation for t in self.timesteps]

    @property
    def actions(self) -> List[Any]:
        return list(self._actions)

    @property
    def rewards(self) -> List[Optional[float]]:
        return [t.reward for t in self.timesteps[1:]]

    @property
    def dones(self) -> List[Optional[bool]]:
        return [t.done for t in self.timesteps[1:]]

    @property
    def infos(self) -> List[Dict[str, Any]]:
        return [t.info for t in self.timesteps[1:]]

    def get_infos(self, key: str) -> List[Any]:
        return [t.info.get(key) for t in self.timesteps[1:]]

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}(T={self.T}, "
            f"finished={self.finished}, "
            f"time_limit={self.reach_time_limit}, "
            f"terminal={self.reach_terminal})"
        )
