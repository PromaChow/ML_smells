import os
import numpy as np
import pytest
import chainer
import chainer.functions as F
import chainer.links as L
import chainer.cuda
import chainer.backends.cuda
from chainer import Variable
from chainer.datasets import TupleDataset
from chainer.optimizers import Adam
from chainer.links import Chain
from chainer.training import Updater, extensions
from chainer.training.extensions import LogReport, ProgressBar
from chainer.datasets import concat_examples

import chainer_rl.environments as envs
import chainer_rl.algorithms.categorical_dqn as cat_dqn
from chainer_rl.algorithms.categorical_dqn import (
    _apply_categorical_projection,
    compute_value_loss,
    compute_weighted_value_loss,
)
from chainer_rl.agent import CategoricalDQN
from chainer_rl.agent import AbstractAgent
from chainer_rl.termination import IsDone
from chainer_rl import random
from chainer_rl import common
from chainer_rl.replay_buffer import ExperienceReplay
from chainer_rl import common

# --------------------------------------------------------------------
# 1. Naive categorical projection implementation
# --------------------------------------------------------------------
def _apply_categorical_projection_naive(y, y_probs, vmin, vmax, atom_num, gamma):
    """
    y: (batch, ) or (batch, ) next state values
    y_probs: (batch, atom_num) probability distributions of next state
    vmin, vmax: scalar
    atom_num: int
    gamma: float
    """
    batch, _ = y.shape
    delta_z = (vmax - vmin) / (atom_num - 1)
    z = np.linspace(vmin, vmax, atom_num, dtype=np.float32)
    target = y * gamma + (1 - gamma) * 0  # placeholder; actual reward not used
    proj = np.zeros((batch, atom_num), dtype=np.float32)
    for i in range(batch):
        for j in range(atom_num):
            t = target[i] + z[j]
            b = (t - vmin) / delta_z
            l = np.floor(b).astype(int)
            u = np.ceil(b).astype(int)
            l = np.clip(l, 0, atom_num - 1)
            u = np.clip(u, 0, atom_num - 1)
            proj[i, l] += y_probs[i, j] * (u - b)
            proj[i, u] += y_probs[i, j] * (b - l)
    return proj

# --------------------------------------------------------------------
# 2. Parameterized tests for categorical projection
# --------------------------------------------------------------------
@pytest.mark.parametrize("batch_size", [1, 7])
@pytest.mark.parametrize("atom_num", [2, 5])
@pytest.mark.parametrize("vmin_vmax", [(-3, -1), (0, 1)])
def test_apply_categorical_projection(batch_size, atom_num, vmin_vmax):
    vmin, vmax = vmin_vmax
    delta_z = (vmax - vmin) / (atom_num - 1)
    z = np.linspace(vmin, vmax, atom_num, dtype=np.float32)
    gamma = 0.99
    y = np.random.randn(batch_size, 1).astype(np.float32)
    y_probs = np.random.rand(batch_size, atom_num).astype(np.float32)
    y_probs = y_probs / y_probs.sum(axis=1, keepdims=True)

    # CPU
    y_var = Variable(y)
    y_probs_var = Variable(y_probs)
    projected_cpu = _apply_categorical_projection(
        y_var, y_probs_var, vmin, vmax, atom_num, gamma
    ).array
    projected_naive = _apply_categorical_projection_naive(
        y, y_probs, vmin, vmax, atom_num, gamma
    )
    assert np.allclose(projected_cpu, projected_naive, atol=1e-5)

    # GPU
    if chainer.cuda.available:
        gpu_y_var = Variable(chainer.cuda.to_gpu(y))
        gpu_y_probs_var = Variable(chainer.cuda.to_gpu(y_probs))
        projected_gpu = _apply_categorical_projection(
            gpu_y_var, gpu_y_probs_var, vmin, vmax, atom_num, gamma
        ).array
        projected_gpu_cpu = chainer.cuda.to_cpu(projected_gpu)
        assert np.allclose(projected_gpu_cpu, projected_naive, atol=1e-5)

# --------------------------------------------------------------------
# 3. Manual projection test cases
# --------------------------------------------------------------------
def test_apply_categorical_projection_manual():
    vmin, vmax = -1.0, 1.0
    atom_num = 3
    delta_z = (vmax - vmin) / (atom_num - 1)
    gamma = 0.99
    y = np.array([[0.0], [0.5]], dtype=np.float32)
    y_probs = np.array(
        [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0]], dtype=np.float32
    )
    # Expected: first distribution remains the same, second shifted
    expected = np.array(
        [[0.5, 0.5, 0.0], [0.0, 0.5, 0.5]], dtype=np.float32
    )

    y_var = Variable(y)
    y_probs_var = Variable(y_probs)
    projected = _apply_categorical_projection(
        y_var, y_probs_var, vmin, vmax, atom_num, gamma
    ).array
    assert np.allclose(projected, expected, atol=1e-5)

    if chainer.cuda.available:
        gpu_y_var = Variable(chainer.cuda.to_gpu(y))
        gpu_y_probs_var = Variable(chainer.cuda.to_gpu(y_probs))
        projected_gpu = _apply_categorical_projection(
            gpu_y_var, gpu_y_probs_var, vmin, vmax, atom_num, gamma
        ).array
        projected_gpu_cpu = chainer.cuda.to_cpu(projected_gpu)
        assert np.allclose(projected_gpu_cpu, expected, atol=1e-5)

# --------------------------------------------------------------------
# 4. Q-function construction helpers
# --------------------------------------------------------------------
def make_distrib_ff_q_func(
    observation_shape,
    n_actions,
    n_atoms,
    hidden_units=128,
    device=None,
):
    class DistribFFQFunc(Chain):
        def __init__(self):
            super().__init__(
                fc1=L.Linear(observation_shape[0], hidden_units),
                fc2=L.Linear(hidden_units, hidden_units),
                logits=L.Linear(hidden_units, n_actions * n_atoms),
            )
            self.n_actions = n_actions
            self.n_atoms = n_atoms
            self.vmin = -10.0
            self.vmax = 10.0

        def __call__(self, x):
            h = F.relu(self.fc1(x))
            h = F.relu(self.fc2(h))
            logits = self.logits(h)
            logits = logits.reshape((-1, self.n_actions, self.n_atoms))
            probs = F.softmax(logits, axis=2)
            return probs

    model = DistribFFQFunc()
    if device is not None:
        model.to_device(device)
    return model

def make_distrib_recurrent_q_func(
    observation_shape,
    n_actions,
    n_atoms,
    hidden_units=128,
    rnn_units=64,
    device=None,
):
    class DistribRNNQFunc(Chain):
        def __init__(self):
            super().__init__(
                rnn=L.LSTM(hidden_units, rnn_units),
                fc1=L.Linear(observation_shape[0], hidden_units),
                fc2=L.Linear(hidden_units, hidden_units),
                logits=L.Linear(hidden_units, n_actions * n_atoms),
            )
            self.n_actions = n_actions
            self.n_atoms = n_atoms
            self.vmin = -10.0
            self.vmax = 10.0

        def __call__(self, x, hidden):
            h = F.relu(self.fc1(x))
            h = F.relu(self.fc2(h))
            hidden = self.rnn(h, hidden)
            logits = self.logits(hidden)
            logits = logits.reshape((-1, self.n_actions, self.n_atoms))
            probs = F.softmax(logits, axis=2)
            return probs, hidden

    model = DistribRNNQFunc()
    if device is not None:
        model.to_device(device)
    return model

# --------------------------------------------------------------------
# 5. Agent tests on discrete environments
# --------------------------------------------------------------------
@pytest.fixture(scope="function")
def env():
    env = envs.make("CartPole-v1")
    return env

@pytest.fixture(scope="function")
def env_po():
    env = envs.make("CartPole-v1", observation_space=None)
    return env

@pytest.mark.parametrize("use_recurrent", [False, True])
def test_categorical_dqn_on_discrete(env, env_po, use_recurrent):
    if use_recurrent:
        env = env_po
    observation_shape = env.observation_space.shape
    n_actions = env.action_space.n
    n_atoms = 51
    gamma = 0.99
    target_update_interval = 100
    batch_size = 32
    replay_buffer = ExperienceReplay(1000)
    optimizer = Adam()
    optimizer.setup

    if use_recurrent:
        q_func = make_distrib_recurrent_q_func(
            observation_shape, n_actions, n_atoms
        )
        agent = CategoricalDQN(
            q_func,
            env.action_space,
            gamma=gamma,
            replay_buffer=replay_buffer,
            optimizer=optimizer,
            target_update_interval=target_update_interval,
            batch_size=batch_size,
        )
    else:
        q_func = make_distrib_ff_q_func(
            observation_shape, n_actions, n_atoms
        )
        agent = CategoricalDQN(
            q_func,
            env.action_space,
            gamma=gamma,
            replay_buffer=replay_buffer,
            optimizer=optimizer,
            target_update_interval=target_update_interval,
            batch_size=batch_size,
        )

    # Simple training loop
    ep_reward = 0.0
    state = env.reset()
    for _ in range(200):
        with chainer.using_config("train", True):
            action = agent.act(state)
        next_state, reward, done, _ = env.step(action)
        ep_reward += reward
        replay_buffer.append(state, action, reward, next_state, done)
        state = next_state
        if done:
            state = env.reset()
        if len(replay_buffer) >= batch_size:
            agent.train()
    assert ep_reward > 0

# --------------------------------------------------------------------
# 6. Value loss computation tests
# --------------------------------------------------------------------
@pytest.mark.parametrize("accumulation", ["mean", "sum"])
def test_compute_value_loss(accumulation):
    batch_size = 4
    n_atoms = 51
    y = np.random.rand(batch_size, n_atoms).astype(np.float32)
    y = y / y.sum(axis=1, keepdims=True)
    t = np.random.rand(batch_size, n_atoms).astype(np.float32)
    t = t / t.sum(axis=1, keepdims=True)
    weight = np.random.rand(batch_size, n_atoms).astype(np.float32)

    y_var = Variable(y)
    t_var = Variable(t)
    weight_var = Variable(weight)

    loss = compute_value_loss(y_var, t_var, accumulation)
    weighted_loss = compute_weighted_value_loss(y_var, t_var, weight_var, accumulation)

    assert loss.shape == ()
    assert weighted_loss.shape == ()
    assert loss.data >= 0
    assert weighted_loss.data >= 0

    if chainer.cuda.available:
        y_var_gpu = Variable(chainer.cuda.to_gpu(y))
        t_var_gpu = Variable(chainer.cuda.to_gpu(t))
        weight_var_gpu = Variable(chainer.cuda.to_gpu(weight))
        loss_gpu = compute_value_loss(y_var_gpu, t_var_gpu, accumulation).array
        weighted_loss_gpu = compute_weighted_value_loss(
            y_var_gpu, t_var_gpu, weight_var_gpu, accumulation
        ).array
        loss_cpu = chainer.cuda.to_cpu(loss_gpu)
        weighted_loss_cpu = chainer.cuda.to_cpu(weighted_loss_gpu)
        assert np.allclose(loss_cpu, loss.data, atol=1e-5)
        assert np.allclose(weighted_loss_cpu, weighted_loss.data, atol=1e-5)