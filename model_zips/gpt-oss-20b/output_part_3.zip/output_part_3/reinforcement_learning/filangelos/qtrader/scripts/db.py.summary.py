import os
import pandas as pd
from qtrader.envs.data_loader import Finance

def main():
    data = Finance.SP500(return_prices_returns=True)
    sp500 = data.sp500
    prices = data.prices
    returns = data.returns

    if not os.path.isdir("db"):
        os.makedirs("db")

    sp500.to_csv("db/sp500.csv")
    prices.to_csv("db/prices.csv")
    returns.to_csv("db/returns.csv")

    del sp500, prices, returns

    sp500_df = pd.read_csv("db/sp500.csv", index_col=0)
    tickers = sp500_df.index.tolist()

    prices = Finance.Prices(tickers=tickers, csv_file="db/prices.csv")
    returns = Finance.Returns(tickers=tickers, csv_file="db/returns.csv")

if __name__ == "__main__":
    main()