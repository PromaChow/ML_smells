import numpy as np
import matplotlib.pyplot as plt
from sklearn.svm import SVC

# Data generation
np.random.seed(42)
X1 = np.random.randn(20, 2) + np.array([-2, -2])
X2 = np.random.randn(20, 2) + np.array([2, 2])
X = np.vstack([X1, X2])
Y = np.array([0] * 20 + [1] * 20)

# Regularization configurations
penalties = [1, 0.05]

for penalty in penalties:
    clf = SVC(kernel='linear', C=penalty)
    clf.fit(X, Y)

    # Hyperplane parameters
    w = clf.coef_[0]
    a = -w[0] / w[1]
    xx = np.linspace(-4.8, 4.2, 200)
    yy = a * xx - clf.intercept_[0] / w[1]

    # Margin calculation
    margin = 1 / np.sqrt(np.sum(clf.coef_ ** 2))
    yy_upper = yy + margin
    yy_lower = yy - margin

    # Visualization
    plt.figure(figsize=(6, 6))
    plt.pcolormesh(
        np.linspace(-4.8, 4.2, 200),
        np.linspace(-6, 6, 200),
        clf.predict(
            np.c_[np.linspace(-4.8, 4.2, 200).repeat(200),
                  np.linspace(-6, 6, 200).reshape(-1, 1).repeat(200, axis=1).ravel()]
        ).reshape(200, 200),
        cmap=plt.cm.coolwarm,
        alpha=0.2,
    )
    plt.plot(xx, yy, 'k-', lw=2)
    plt.plot(xx, yy_upper, 'k--', lw=1)
    plt.plot(xx, yy_lower, 'k--', lw=1)
    plt.scatter(
        X[:, 0], X[:, 1], c=Y, cmap=plt.cm.coolwarm, s=30, edgecolors='k'
    )
    plt.scatter(
        clf.support_vectors_[:, 0],
        clf.support_vectors_[:, 1],
        s=100,
        facecolors='none',
        edgecolors='k',
        linewidths=1.5,
    )
    plt.xlim(-4.8, 4.2)
    plt.ylim(-6, 6)
    plt.axis('off')
    plt.title(f'SVM (C={penalty})')
    plt.show()