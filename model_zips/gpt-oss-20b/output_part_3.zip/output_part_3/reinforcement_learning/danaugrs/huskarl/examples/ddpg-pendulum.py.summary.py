import gym
import numpy as np
import matplotlib.pyplot as plt
from huskarl import DDPG, Simulation
from huskarl.models import Sequential, Dense, Input, Concatenate, Model

# Environment setup
env_creator = lambda: gym.make('Pendulum-v0')
env = env_creator()
action_size = env.action_space.shape[0]
state_shape = env.observation_space.shape

# Actor network
actor = Sequential(name='actor')
actor.add(Input(shape=state_shape))
actor.add(Dense(16, activation='relu'))
actor.add(Dense(16, activation='relu'))
actor.add(Dense(16, activation='relu'))
actor.add(Dense(action_size, activation=None))

# Critic network
state_input = Input(shape=state_shape, name='state_input')
action_input = Input(shape=(action_size,), name='action_input')
x = Concatenate()([state_input, action_input])
x = Dense(32, activation='relu')(x)
x = Dense(32, activation='relu')(x)
x = Dense(32, activation='relu')(x)
q_value = Dense(1, activation=None)(x)
critic = Model(inputs=[state_input, action_input], outputs=q_value, name='critic')

# DDPG agent
agent = DDPG(actor=actor, critic=critic, nsteps=2)

# Reward visualization
plt.ion()
fig, ax = plt.subplots()
def plot_rewards(rewards):
    ax.clear()
    ax.plot(rewards, label='Cumulative Reward')
    ax.set_xlabel('Episode')
    ax.set_ylabel('Cumulative Reward')
    ax.set_title('DDPG on Pendulum-v0')
    ax.legend()
    fig.canvas.draw()
    fig.canvas.flush_events()

# Training and testing
sim = Simulation(env=env_creator, agent=agent, plot=plot_rewards, realtime=True)
sim.train(total_steps=30000, realtime=True, update_plot=True)
sim.test(total_steps=5000, realtime=False)