class BaseScenario:
    def make_world(self):
        raise NotImplementedError("Subclasses must implement make_world")

    def reset_world(self, world):
        raise NotImplementedError("Subclasses must implement reset_world")