import math
import numpy as np


class MicroCluster:
    def __init__(self, point, weight=1.0, timestamp=0):
        point = np.asarray(point, dtype=float)
        self.LS = point * weight
        self.SS = point ** 2 * weight
        self.n = weight
        self.t = timestamp

    def update(self, point, timestamp=0):
        point = np.asarray(point, dtype=float)
        self.LS += point
        self.SS += point ** 2
        self.n += 1
        self.t = timestamp

    def decay(self, lamb, current_time):
        decay_factor = math.exp(-lamb * (current_time - self.t))
        self.LS *= decay_factor
        self.SS *= decay_factor
        self.n *= decay_factor
        self.t = current_time

    @property
    def center(self):
        if self.n == 0:
            return np.zeros_like(self.LS)
        return self.LS / self.n

    @property
    def radius(self):
        if self.n == 0:
            return 0.0
        center_sq = self.center ** 2
        mean_sq = self.SS / self.n
        rad_sq = np.sum(mean_sq - center_sq)
        return math.sqrt(max(rad_sq, 0.0))

    def distance_to(self, point):
        return np.linalg.norm(np.asarray(point) - self.center)


class OADDS:
    def __init__(
        self,
        dims,
        numberInitialSamples=100,
        lamb=0.01,
        beta=0.001,
        k_std=2.0,
        epsilon=None,
        dynamic_epsilon=True,
    ):
        self.dims = dims
        self.numberInitialSamples = numberInitialSamples
        self.lamb = lamb
        self.beta = beta
        self.k_std = k_std
        self.epsilon = epsilon
        self.dynamic_epsilon = dynamic_epsilon

        self.buffer = []
        self.pMicroCluster = []  # core clusters
        self.oMicroCluster = []  # outlier clusters
        self.initialized = False
        self.tp = None
        self.mu = None
        self.step = 0
        self.th_beta_mu = None
        self.current_time = 0

    def _compute_auto_parameters(self):
        if self.mu is None:
            self.mu = 1.0 / (1.0 - 2.0 ** (-self.lamb))
        if self.tp is None:
            self.tp = int(-1.0 / self.lamb * math.log2(self.beta)) + 1

    def _init_clusters(self):
        if not self.buffer:
            return
        init_points = np.array(self.buffer)
        init_cluster = MicroCluster(init_points[0], weight=1.0, timestamp=self.current_time)
        for p in init_points[1:]:
            init_cluster.update(p, timestamp=self.current_time)
        self.pMicroCluster.append(init_cluster)
        self.buffer = []
        self.initialized = True
        self._compute_auto_parameters()
        self.th_beta_mu = self.beta * self.mu
        if self.dynamic_epsilon:
            radii = [c.radius for c in self.pMicroCluster]
            if radii:
                mean_r = np.mean(radii)
                std_r = np.std(radii)
                self.epsilon = mean_r + self.k_std * std_r

    def add_sample(self, sample):
        sample = np.asarray(sample, dtype=float)
        self.step += 1
        self.current_time += 1

        if not self.initialized:
            self.buffer.append(sample)
            if len(self.buffer) >= self.numberInitialSamples:
                self._init_clusters()
            return False, None

        merged, cluster_obj = self._process_sample(sample)
        self._decay_and_update_clusters(sample, merged, cluster_obj)
        if self.dynamic_epsilon:
            self._update_epsilon()
        if self.step % self.tp == 0:
            self._prune()
        return not merged, None

    def _process_sample(self, sample):
        # Merge with core cluster
        min_dist = math.inf
        best_core = None
        for c in self.pMicroCluster:
            dist = c.distance_to(sample) - c.radius
            if dist < min_dist:
                min_dist = dist
                best_core = c
        if min_dist <= self.epsilon:
            best_core.update(sample, timestamp=self.current_time)
            return True, best_core

        # Merge with outlier cluster
        min_dist = math.inf
        best_out = None
        for c in self.oMicroCluster:
            dist = c.distance_to(sample) - c.radius
            if dist < min_dist:
                min_dist = dist
                best_out = c
        if min_dist <= self.epsilon:
            best_out.update(sample, timestamp=self.current_time)
            return True, best_out

        # Create new outlier cluster
        new_out = MicroCluster(sample, weight=1.0, timestamp=self.current_time)
        self.oMicroCluster.append(new_out)
        return False, new_out

    def _decay_and_update_clusters(self, sample, merged, cluster_obj):
        for c in self.pMicroCluster + self.oMicroCluster:
            if cluster_obj is not None and c is cluster_obj:
                continue
            c.decay(self.lamb, self.current_time)

    def _update_epsilon(self):
        radii = [c.radius for c in self.pMicroCluster]
        if radii:
            mean_r = np.mean(radii)
            std_r = np.std(radii)
            self.epsilon = mean_r + self.k_std * std_r

    def _prune(self):
        # Convert outlier clusters to core if weight threshold met
        to_convert = [c for c in self.oMicroCluster if c.n >= self.mu]
        for c in to_convert:
            self.oMicroCluster.remove(c)
            self.pMicroCluster.append(c)

        # Prune core clusters
        self.pMicroCluster = [c for c in self.pMicroCluster if c.n >= self.th_beta_mu]

        # Prune outlier clusters
        self.oMicroCluster = [c for c in self.oMicroCluster if c.n >= self.beta]

    def get_state(self):
        return {
            "num_core": len(self.pMicroCluster),
            "num_outlier": len(self.oMicroCluster),
            "epsilon": self.epsilon,
            "mu": self.mu,
            "step": self.step,
        }