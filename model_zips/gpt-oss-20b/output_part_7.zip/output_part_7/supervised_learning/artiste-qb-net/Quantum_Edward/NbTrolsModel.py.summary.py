import numpy as np

def ang_to_cs2_prob(angle, bit):
    """Map an angle to a probability: cos^2 for bit 0, sin^2 for bit 1."""
    return np.cos(angle)**2 if bit == 0 else np.sin(angle)**2

class Model:
    """Base model providing toy data generation."""
    def gen_toy_data(self, nsam):
        xs = []
        ys = []
        # Probabilities for all possible x values
        probs_x = np.array([self.prob_x(x) for x in range(2**self.na)])
        probs_x /= probs_x.sum()
        for _ in range(nsam):
            x = np.random.choice(2**self.na, p=probs_x)
            probs_y = np.array([self.prob_y_given_x_and_angs_prior(x, y) for y in range(2**self.nb)])
            probs_y /= probs_y.sum()
            y = np.random.choice(2**self.nb, p=probs_y)
            xs.append(x)
            ys.append(y)
        return list(zip(xs, ys))

class NbTrolsModel(Model):
    """Quantum circuit model for joint distributions P(x) and P(y|x)."""
    def __init__(self, nb, na):
        self.nb = nb
        self.na = na
        self.num_layers = nb + na
        # Initialize angles for each layer: size 2**k for k = 0 .. na+nb-1
        self.list1_angs = [np.random.uniform(0, np.pi/2, size=2**k) for k in range(self.num_layers)]

    def get_shapes1(self):
        return [2**k for k in range(self.na + self.nb)]

    def static_prob_x(self, x):
        """Compute probability of a particular x using first na layers."""
        x_bits = [(x >> i) & 1 for i in range(self.na)]
        prob = 1.0
        for k in range(self.na):
            idx = sum(x_bits[i] << i for i in range(k))
            ang = self.list1_angs[k][idx]
            prob *= ang_to_cs2_prob(ang, x_bits[k])
        return prob

    def prob_x(self, x):
        return self.static_prob_x(x)

    def prob_y_given_x_and_angs_prior(self, x, y):
        """Compute conditional probability P(y|x) using remaining layers."""
        x_bits = [(x >> i) & 1 for i in range(self.na)]
        y_bits = [(y >> i) & 1 for i in range(self.nb)]
        prob = 1.0
        for k in range(self.na, self.na + self.nb):
            idx = 0
            for i in range(k):
                bit = x_bits[i] if i < self.na else y_bits[i - self.na]
                idx |= bit << i
            bit_y = y_bits[k - self.na]
            ang = self.list1_angs[k][idx]
            prob *= ang_to_cs2_prob(ang, bit_y)
        return prob

def main():
    nb = 2   # number of ancilla qubits
    na = 2   # number of control qubits
    model = NbTrolsModel(nb, na)
    nsam = 10
    data = model.gen_toy_data(nsam)
    print("Toy dataset (x, y):")
    for x, y in data:
        print(f"x={x:0{na}b} ({x}), y={y:0{nb}b} ({y})")

if __name__ == "__main__":
    main()
