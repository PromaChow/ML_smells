import tensorflow as tf
from tensorflow.keras.layers import Input, LSTM, Dense, Lambda, RepeatVector
from tensorflow.keras.models import Model

# Hyperparameters
timesteps = 100
input_dim = 64
intermediate_dim = 128
latent_dim = 32
epsilon_std = 1.0

def sampling(args):
    z_mean, z_log_sigma = args
    epsilon = tf.random.normal(shape=tf.shape(z_mean), mean=0.0, stddev=epsilon_std)
    return z_mean + tf.exp(0.5 * z_log_sigma) * epsilon

# Input
x = Input(shape=(timesteps, input_dim))

# Encoder
encoder_lstm = LSTM(intermediate_dim)(x)
z_mean = Dense(latent_dim)(encoder_lstm)
z_log_sigma = Dense(latent_dim)(encoder_lstm)

# Sampling
z = Lambda(sampling, output_shape=(latent_dim,))([z_mean, z_log_sigma])

# Decoder
repeat = RepeatVector(timesteps)(z)
decoder_h = LSTM(intermediate_dim, return_sequences=True)(repeat)
x_decoded_mean = LSTM(input_dim, return_sequences=True)(decoder_h)

# VAE model
vae = Model(x, x_decoded_mean)

# Encoder model
encoder = Model(x, z_mean)

# Generator (Decoder) model
decoder_input = Input(shape=(latent_dim,))
decoder_repeat = RepeatVector(timesteps)(decoder_input)
decoder_h2 = LSTM(intermediate_dim, return_sequences=True)(decoder_repeat)
decoder_output = LSTM(input_dim, return_sequences=True)(decoder_h2)
generator = Model(decoder_input, decoder_output)

# Custom loss
def vae_loss(y_true, y_pred):
    reconstruction_loss = tf.reduce_mean(tf.square(y_true - y_pred))
    kl_loss = -0.5 * tf.reduce_mean(1.0 + z_log_sigma - tf.square(z_mean) - tf.exp(z_log_sigma))
    return reconstruction_loss + kl_loss

# Compile
vae.compile(optimizer='rmsprop', loss=vae_loss)