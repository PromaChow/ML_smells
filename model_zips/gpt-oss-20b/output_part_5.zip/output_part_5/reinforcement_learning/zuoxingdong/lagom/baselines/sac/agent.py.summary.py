import math
import random
from collections import deque, namedtuple
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F

# Configuration defaults
DEFAULT_CONFIG = {
    "obs_dim": 24,
    "act_dim": 4,
    "act_limit": 1.0,
    "hidden_dim": 256,
    "lr_actor": 3e-4,
    "lr_critic": 3e-4,
    "lr_alpha": 3e-4,
    "gamma": 0.99,
    "tau": 0.005,
    "target_entropy": None,
    "log_std_min": -20,
    "log_std_max": 2,
    "max_grad_norm": 1.0,
    "batch_size": 256,
    "replay_size": int(1e6),
    "device": torch.device("cuda" if torch.cuda.is_available() else "cpu"),
}

# Replay buffer
Transition = namedtuple('Transition', ('state', 'action', 'reward', 'next_state', 'done'))
class ReplayBuffer:
    def __init__(self, capacity):
        self.buffer = deque(maxlen=capacity)
    def push(self, *args):
        self.buffer.append(Transition(*args))
    def sample(self, batch_size):
        batch = random.sample(self.buffer, batch_size)
        states = torch.stack([torch.tensor(t.state, dtype=torch.float32) for t in batch]).to(DEVICE)
        actions = torch.stack([torch.tensor(t.action, dtype=torch.float32) for t in batch]).to(DEVICE)
        rewards = torch.tensor([t.reward for t in batch], dtype=torch.float32).unsqueeze(1).to(DEVICE)
        next_states = torch.stack([torch.tensor(t.next_state, dtype=torch.float32) for t in batch]).to(DEVICE)
        dones = torch.tensor([t.done for t in batch], dtype=torch.float32).unsqueeze(1).to(DEVICE)
        return states, actions, rewards, next_states, dones
    def __len__(self):
        return len(self.buffer)

# Actor network
class Actor(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden_dim, act_limit, log_std_min, log_std_max):
        super().__init__()
        self.act_limit = act_limit
        self.log_std_min = log_std_min
        self.log_std_max = log_std_max
        self.net = nn.Sequential(
            nn.Linear(obs_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
        )
        self.mean_linear = nn.Linear(hidden_dim, act_dim)
        self.log_std_linear = nn.Linear(hidden_dim, act_dim)

    def forward(self, obs):
        x = self.net(obs)
        mean = self.mean_linear(x)
        log_std = self.log_std_linear(x)
        log_std = torch.clamp(log_std, self.log_std_min, self.log_std_max)
        std = log_std.exp()
        return mean, std

    def sample(self, obs):
        mean, std = self.forward(obs)
        normal = torch.distributions.Normal(mean, std)
        x_t = normal.rsample()
        y_t = torch.tanh(x_t)
        log_prob = normal.log_prob(x_t) - torch.log(1 - y_t.pow(2) + 1e-6)
        log_prob = log_prob.sum(1, keepdim=True)
        action = y_t * self.act_limit
        return action, log_prob, mean

    def deterministic(self, obs):
        mean, _ = self.forward(obs)
        action = torch.tanh(mean) * self.act_limit
        return action

# Critic network (Q-function)
class QNetwork(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim + act_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1)
        )
    def forward(self, obs, act):
        x = torch.cat([obs, act], dim=-1)
        q = self.net(x)
        return q

# SAC Agent
class SACAgent:
    def __init__(self, config):
        self.config = {**DEFAULT_CONFIG, **config}
        global DEVICE
        DEVICE = self.config["device"]
        self.actor = Actor(self.config["obs_dim"], self.config["act_dim"],
                           self.config["hidden_dim"], self.config["act_limit"],
                           self.config["log_std_min"], self.config["log_std_max"]).to(DEVICE)
        self.critic1 = QNetwork(self.config["obs_dim"], self.config["act_dim"],
                                self.config["hidden_dim"]).to(DEVICE)
        self.critic2 = QNetwork(self.config["obs_dim"], self.config["act_dim"],
                                self.config["hidden_dim"]).to(DEVICE)
        self.target_critic1 = QNetwork(self.config["obs_dim"], self.config["act_dim"],
                                       self.config["hidden_dim"]).to(DEVICE)
        self.target_critic2 = QNetwork(self.config["obs_dim"], self.config["act_dim"],
                                       self.config["hidden_dim"]).to(DEVICE)
        self.target_critic1.load_state_dict(self.critic1.state_dict())
        self.target_critic2.load_state_dict(self.critic2.state_dict())
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=self.config["lr_actor"])
        self.critic_optimizer = optim.Adam(list(self.critic1.parameters()) + list(self.critic2.parameters()), lr=self.config["lr_critic"])
        if self.config["target_entropy"] is None:
            self.target_entropy = -self.config["act_dim"]
        else:
            self.target_entropy = self.config["target_entropy"]
        log_alpha = torch.zeros(1, requires_grad=True, device=DEVICE)
        self.log_alpha = log_alpha
        self.alpha_optimizer = optim.Adam([self.log_alpha], lr=self.config["lr_alpha"])
        self.replay_buffer = ReplayBuffer(self.config["replay_size"])

    def select_action(self, state, deterministic=False):
        state = torch.tensor(state, dtype=torch.float32).unsqueeze(0).to(DEVICE)
        if deterministic:
            action = self.actor.deterministic(state)
        else:
            action, _, _ = self.actor.sample(state)
        return action.cpu().detach().numpy()[0]

    def store_transition(self, state, action, reward, next_state, done):
        self.replay_buffer.push(state, action, reward, next_state, done)

    def train_step(self):
        if len(self.replay_buffer) < self.config["batch_size"]:
            return None
        states, actions, rewards, next_states, dones = self.replay_buffer.sample(self.config["batch_size"])
        with torch.no_grad():
            next_actions, next_log_probs, _ = self.actor.sample(next_states)
            target_q1 = self.target_critic1(next_states, next_actions)
            target_q2 = self.target_critic2(next_states, next_actions)
            target_q = torch.min(target_q1, target_q2) - self.log_alpha.exp() * next_log_probs
            target_q = rewards + (1 - dones) * self.config["gamma"] * target_q
        q1 = self.critic1(states, actions)
        q2 = self.critic2(states, actions)
        critic_loss = F.mse_loss(q1, target_q) + F.mse_loss(q2, target_q)
        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        nn.utils.clip_grad_norm_(list(self.critic1.parameters()) + list(self.critic2.parameters()),
                                 self.config["max_grad_norm"])
        self.critic_optimizer.step()
        actions_sampled, log_probs, _ = self.actor.sample(states)
        q1_new = self.critic1(states, actions_sampled)
        q2_new = self.critic2(states, actions_sampled)
        q_new = torch.min(q1_new, q2_new)
        actor_loss = (self.log_alpha.exp() * log_probs - q_new).mean()
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        nn.utils.clip_grad_norm_(self.actor.parameters(), self.config["max_grad_norm"])
        self.actor_optimizer.step()
        alpha_loss = -(self.log_alpha.exp() * (log_probs + self.target_entropy).detach()).mean()
        self.alpha_optimizer.zero_grad()
        alpha_loss.backward()
        self.alpha_optimizer.step()
        for target_param, param in zip(self.target_critic1.parameters(), self.critic1.parameters()):
            target_param.data.copy_(self.config["tau"] * param.data + (1 - self.config["tau"]) * target_param.data)
        for target_param, param in zip(self.target_critic2.parameters(), self.critic2.parameters()):
            target_param.data.copy_(self.config["tau"] * param.data + (1 - self.config["tau"]) * target_param.data)
        return {
            "critic_loss": critic_loss.item(),
            "actor_loss": actor_loss.item(),
            "alpha_loss": alpha_loss.item(),
            "q1": q1.mean().item(),
            "q2": q2.mean().item(),
            "log_prob": log_probs.mean().item(),
            "alpha": self.log_alpha.exp().item()
        }

# Example usage
if __name__ == "__main__":
    import gym
    env = gym.make("Pendulum-v1")
    config = {"obs_dim": env.observation_space.shape[0],
              "act_dim": env.action_space.shape[0],
              "act_limit": env.action_space.high[0]}
    agent = SACAgent(config)
    num_episodes = 10
    for ep in range(num_episodes):
        state = env.reset()
        episode_reward = 0
        done = False
        while not done:
            action = agent.select_action(state)
            next_state, reward, done, _ = env.step(action)
            agent.store_transition(state, action, reward, next_state, done)
            state = next_state
            episode_reward += reward
            summary = agent.train_step()
        print(f"Episode {ep+1} Reward: {episode_reward:.2f}")
        if summary:
            print(f"  Critic Loss: {summary['critic_loss']:.4f} Actor Loss: {summary['actor_loss']:.4f} Alpha: {summary['alpha']:.4f}")