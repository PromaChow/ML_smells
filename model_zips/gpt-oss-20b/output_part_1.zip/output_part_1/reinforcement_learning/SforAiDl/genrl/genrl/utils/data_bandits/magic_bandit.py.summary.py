import os
from pathlib import Path
import requests
import pandas as pd
import torch

class MagicDataBandit:
    DEFAULT_URL = "https://example.com/magic04.data"

    def __init__(
        self,
        path: str = "./data/Magic/",
        download: bool = False,
        force_download: bool = False,
        url: str | None = None,
        device: str = "cpu",
    ):
        self.path = Path(path)
        self.download = download
        self.force_download = force_download
        self.url = url or self.DEFAULT_URL
        self.device = torch.device(device)

        self.path.mkdir(parents=True, exist_ok=True)
        data_file = self.path / "magic04.data"

        if self.download or not data_file.exists() or self.force_download:
            self._download_data(self.url, data_file)

        self.df = pd.read_csv(data_file, header=None)
        self._preprocess()
        self.n_actions = 2
        self.context_dim = self.df.shape[1] - 1
        self._len = self.df.shape[0]
        self.idx = 0

    def _download_data(self, url: str, dest: Path):
        with requests.get(url, stream=True) as r:
            r.raise_for_status()
            with open(dest, "wb") as f:
                for chunk in r.iter_content(chunk_size=8192):
                    f.write(chunk)

    def _preprocess(self):
        # One-hot encode the last column and keep only the last dummy column
        dummies = pd.get_dummies(self.df.iloc[:, -1])
        dummy_col = dummies.iloc[:, -1]
        self.df = self.df.drop(self.df.columns[-1], axis=1)
        self.df = self.df.assign(label=dummy_col)

    def reset(self):
        self.df = self.df.sample(frac=1).reset_index(drop=True)
        self.idx = 0

    def _compute_reward(self, action: int):
        label = self.df.at[self.idx, "label"]
        reward = 1 if label == action + 1 else 0
        return reward, 1

    def _get_context(self):
        context = self.df.iloc[self.idx, :-1].values.astype(float)
        return torch.tensor(context, device=self.device)

    def step(self, action: int):
        context = self._get_context()
        reward, _ = self._compute_reward(action)
        self.idx += 1
        done = self.idx >= self._len
        return context, reward, done

    def __len__(self):
        return self._len
```