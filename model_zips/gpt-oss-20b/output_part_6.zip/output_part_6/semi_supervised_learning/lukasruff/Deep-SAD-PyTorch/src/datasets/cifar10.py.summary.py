import random
import numpy as np
import torch
from torch.utils.data import Subset
from torchvision import datasets, transforms

class MyCIFAR10(datasets.CIFAR10):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.semi_targets = np.zeros(len(self.targets), dtype=np.int64)

    def __getitem__(self, index):
        img, target = super().__getitem__(index)
        semi_target = self.semi_targets[index]
        return img, target, semi_target, index

def create_semisupervised_setting(
    targets,
    normal_class=5,
    known_outlier_classes=None,
    known_normal_ratio=0.05,
    known_outlier_ratio=0.05,
    pollution_ratio=0.1,
    seed=42
):
    rng = np.random.default_rng(seed)
    targets = np.array(targets)
    all_classes = set(range(10))
    outlier_classes = list(all_classes - {normal_class})

    if known_outlier_classes is None:
        known_outlier_classes = outlier_classes
    else:
        known_outlier_classes = list(known_outlier_classes)

    normal_idx = np.where(targets == normal_class)[0]
    outlier_idx = np.where(np.isin(targets, outlier_classes))[0]

    known_normal_count = int(len(normal_idx) * known_normal_ratio)
    known_outlier_count = int(len(outlier_idx) * known_outlier_ratio)
    pollution_count = int((len(normal_idx) + len(outlier_idx)) * pollution_ratio)

    idx = np.concatenate([
        rng.choice(normal_idx, known_normal_count, replace=False),
        rng.choice(outlier_idx, known_outlier_count, replace=False)
    ])

    semi_targets = np.full(len(targets), -1, dtype=np.int64)

    semi_targets[normal_idx] = 0
    semi_targets[outlier_idx] = 1

    for i in rng.choice(idx, len(idx), replace=False):
        semi_targets[i] = 0 if targets[i] == normal_class else 1

    pollution_idx = rng.choice(np.arange(len(targets)), pollution_count, replace=False)
    for i in pollution_idx:
        if semi_targets[i] == 0:
            semi_targets[i] = 1
        elif semi_targets[i] == 1:
            semi_targets[i] = 0

    idx = np.arange(len(targets))
    return idx, semi_targets

if __name__ == "__main__":
    transform = transforms.Compose([
        transforms.ToTensor()
    ])

    train_full = MyCIFAR10(root="./data", train=True, download=True, transform=transform)

    idx, semi_targets = create_semisupervised_setting(
        targets=train_full.targets,
        normal_class=5,
        known_outlier_classes=None,
        known_normal_ratio=0.05,
        known_outlier_ratio=0.05,
        pollution_ratio=0.1
    )

    train_full.semi_targets = semi_targets
    train_set = Subset(train_full, idx)

    test_set = datasets.CIFAR10(root="./data", train=False, download=True, transform=transform)