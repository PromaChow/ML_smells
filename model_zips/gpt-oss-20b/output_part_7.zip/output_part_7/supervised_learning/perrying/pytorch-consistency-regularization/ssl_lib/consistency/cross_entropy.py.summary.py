import torch
import torch.nn as nn
import torch.nn.functional as F

def cross_entropy(y: torch.Tensor, target: torch.Tensor, mask: torch.Tensor | None = None) -> torch.Tensor:
    """
    Compute a cross-entropy loss with optional masking.

    Args:
        y: Logits produced by the model (shape: [batch, classes]).
        target: Ground truth labels. Can be hard labels (shape: [batch]) or
                soft labels (shape: [batch, classes]).
        mask: Optional mask tensor. Elements are multiplied with the per-sample loss.
              The mask must be broadcastable to the loss shape.

    Returns:
        A scalar tensor representing the mean loss over the batch.
    """
    if target.ndim == 1:
        # Hard labels: use F.cross_entropy with per-sample loss
        loss = F.cross_entropy(y, target, reduction="none")
    else:
        # Soft labels: negative sum of target * log_softmax over classes
        log_probs = F.log_softmax(y, dim=1)
        loss = -torch.sum(target * log_probs, dim=1)

    if mask is not None:
        loss = loss * mask

    return loss.mean()

class CrossEntropy(nn.Module):
    """
    PyTorch module wrapper for the custom cross-entropy loss.
    The target tensor is detached to prevent gradients flowing through it.
    """
    def __init__(self):
        super().__init__()

    def forward(self, y: torch.Tensor, target: torch.Tensor, mask: torch.Tensor | None = None) -> torch.Tensor:
        return cross_entropy(y, target.detach(), mask=mask)