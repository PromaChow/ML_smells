import os
import numpy as np


class SVHN:
    def __init__(self, root, split="l_train"):
        path = os.path.join(root, "svhn", f"{split}.npy")
        loaded = np.load(path, allow_pickle=True)
        self.dataset = dict(loaded)

    def __getitem__(self, idx):
        image = self.dataset["images"][idx]
        label = self.dataset["labels"][idx]
        image = (image / 255.0 - 0.5) / 0.5
        return image, label

    def __len__(self):
        return len(self.dataset["images"])