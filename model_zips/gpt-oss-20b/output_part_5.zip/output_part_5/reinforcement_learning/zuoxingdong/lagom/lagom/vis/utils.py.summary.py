import pathlib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter, MaxNLocator
from lagom import pickle_load, yaml_load, interp_curves, smooth_filter


def set_ticker(ax, num_ticks=5, km_format=True, as_int=False):
    """
    Configure matplotlib axis tickers.

    Parameters
    ----------
    ax : matplotlib.axes.Axes
        Target axis.
    num_ticks : int, optional
        Desired number of major ticks.
    km_format : bool, optional
        If True, format large numbers as K/M/G etc.
    as_int : bool, optional
        If True, format values as integers.
    """
    def km_formatter(x, pos):
        if x == 0:
            return "0"
        magnitude = 0
        suffix = ["", "K", "M", "B", "T"]
        while abs(x) >= 1000 and magnitude < len(suffix)-1:
            magnitude += 1
            x /= 1000.0
        if as_int:
            return f"{int(round(x))}{suffix[magnitude]}"
        else:
            return f"{x:.2f}{suffix[magnitude]}"

    locator = MaxNLocator(nbins=num_ticks)
    ax.xaxis.set_major_locator(locator)
    ax.yaxis.set_major_locator(locator)
    if km_format:
        ax.yaxis.set_major_formatter(FuncFormatter(km_formatter))
    if as_int:
        ax.xaxis.set_major_formatter(FuncFormatter(lambda x, pos: f"{int(round(x))}"))


def process_logs(
    log_folder: pathlib.Path,
    log_file_name: str = "log.pkl",
    get_x=None,
    get_y=None,
    smooth_out: bool = False,
    point_step: int = 1,
):
    """
    Process logs from a directory structure of experiment ID/seed.

    Parameters
    ----------
    log_folder : pathlib.Path
        Root folder containing experiment ID subfolders.
    log_file_name : str, optional
        Name of the log file inside each seed folder.
    get_x : callable, optional
        Function to extract x value from a log entry.
    get_y : callable, optional
        Function to extract y value(s) from a log entry.
    smooth_out : bool, optional
        Apply smoothing filter to y curves.
    point_step : int, optional
        Downsample factor (>1 reduces points).

    Returns
    -------
    pandas.DataFrame
        Combined dataframe of all experiments with config data merged.
    """
    if get_x is None:
        raise ValueError("get_x function must be provided")
    if get_y is None:
        raise ValueError("get_y function must be provided")

    all_dfs = []

    # Find all experiment ID directories (numeric names)
    id_dirs = [d for d in log_folder.iterdir() if d.is_dir() and d.name.isdigit()]

    for id_dir in id_dirs:
        # Find seed subdirectories (numeric names)
        seed_dirs = [d for d in id_dir.iterdir() if d.is_dir() and d.name.isdigit()]

        seed_x = []
        seed_y = []

        for seed_dir in seed_dirs:
            log_path = seed_dir / log_file_name
            if not log_path.is_file():
                continue
            log_data = pickle_load(log_path)

            x_vals = []
            y_vals = []

            for entry in log_data:
                x = get_x(entry)
                y = get_y(entry)
                x_vals.append(x)
                y_vals.append(y)

            seed_x.append(np.array(x_vals))
            seed_y.append(np.array(y_vals))

        if not seed_x:
            continue

        # Interpolate across all seeds
        x_common, y_interpolated = interp_curves(seed_x, seed_y, kind="linear")

        # Apply smoothing if requested
        if smooth_out:
            y_interpolated = [
                smooth_filter(y, window_length=51, polyorder=3) for y in y_interpolated
            ]

        # Downsample if needed
        if point_step > 1:
            x_common = x_common[::point_step]
            y_interpolated = [y[::point_step] for y in y_interpolated]

        # Build dataframe for this experiment
        df = pd.DataFrame({"x": x_common})
        for i, y_arr in enumerate(y_interpolated):
            df[f"metric_{i}"] = y_arr

        # Load config.yml and merge
        config_path = id_dir / "config.yml"
        if config_path.is_file():
            config_dict = yaml_load(config_path)
            config_df = pd.DataFrame([config_dict])
            config_df = config_df.reindex(columns=df.columns, fill_value=np.nan)
            df = pd.concat([config_df, df], axis=1)
        else:
            # If no config, prepend NaNs for config columns
            df = df.reindex(columns=[f"metric_{i}" for i in range(len(y_interpolated))], fill_value=np.nan)

        # Forward-fill missing config values
        df.fillna(method="ffill", inplace=True)

        all_dfs.append(df)

    if all_dfs:
        combined_df = pd.concat(all_dfs, ignore_index=True)
    else:
        combined_df = pd.DataFrame()

    return combined_df


# Example usage (uncomment and adjust paths/functions as needed)
# if __name__ == "__main__":
#     logs_path = pathlib.Path("/path/to/log_folder")
#     def extract_x(entry): return entry["time"]
#     def extract_y(entry): return entry["metric"]
#     result_df = process_logs(logs_path, get_x=extract_x, get_y=extract_y, smooth_out=True, point_step=2)
#     print(result_df.head())