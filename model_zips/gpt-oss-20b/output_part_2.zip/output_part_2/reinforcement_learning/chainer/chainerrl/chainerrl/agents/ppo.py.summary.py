import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from collections import deque, namedtuple
from typing import List, Optional, Tuple

Transition = namedtuple('Transition',
                       ['state', 'action', 'reward', 'next_state', 'nonterminal',
                        'log_prob', 'value', 'advantage', 'value_target'])

Episode = List[Transition]


class PPOAgent:
    def __init__(
        self,
        model: nn.Module,
        optimizer: optim.Optimizer,
        gamma: float = 0.99,
        lambd: float = 0.95,
        clip_eps: float = 0.2,
        clip_eps_vf: Optional[float] = None,
        entropy_coef: float = 0.01,
        vf_coef: float = 0.5,
        learning_rate: float = 3e-4,
        update_interval: int = 2048,
        epochs: int = 10,
        minibatch_size: int = 64,
        standardize_advantages: bool = True,
        max_recurrent_sequence_len: Optional[int] = None,
        n_step_forward: int = 5,
        obs_normalizer: Optional[object] = None,
        device: Optional[torch.device] = None,
    ):
        self.model = model
        self.optimizer = optimizer
        self.gamma = gamma
        self.lambd = lambd
        self.clip_eps = clip_eps
        self.clip_eps_vf = clip_eps_vf
        self.entropy_coef = entropy_coef
        self.vf_coef = vf_coef
        self.update_interval = update_interval
        self.epochs = epochs
        self.minibatch_size = minibatch_size
        self.standardize_advantages = standardize_advantages
        self.max_recurrent_sequence_len = max_recurrent_sequence_len
        self.n_step_forward = n_step_forward
        self.obs_normalizer = obs_normalizer
        self.device = device or torch.device('cpu')

        self.model.to(self.device)
        if self.obs_normalizer is not None:
            self.obs_normalizer.to(self.device)

        self.memory: List[Episode] = []
        self.last_episode: Episode = []
        self.last_state = None
        self.last_action = None
        self.train_recurrent_states = None
        self.test_recurrent_states = None

        self.value_record = deque(maxlen=100)
        self.entropy_record = deque(maxlen=100)
        self.value_loss_record = deque(maxlen=100)
        self.policy_loss_record = deque(maxlen=100)
        self.update_counter = 0

        # Check recurrent flag
        self.is_recurrent = hasattr(self.model, 'recurrent') and self.model.recurrent

    def act(self, state, recurrent_state=None, test_mode=False):
        state_tensor = torch.tensor(state, dtype=torch.float32, device=self.device)
        if self.obs_normalizer is not None:
            state_tensor = self.obs_normalizer(state_tensor)

        if self.is_recurrent:
            action_dist, value, recurrent_state = self.model(state_tensor, recurrent_state)
        else:
            action_dist, value = self.model(state_tensor)
            recurrent_state = None

        action = action_dist.sample()
        log_prob = action_dist.log_prob(action).sum()
        entropy = action_dist.entropy().sum()
        return action.cpu().numpy(), log_prob.item(), value.item(), recurrent_state, entropy.item()

    def act_and_train(self, state, reward, done, test_mode=False):
        if self.last_state is None:
            self.last_state = state
            self.last_action = None
        # store transition
        transition = Transition(
            state=self.last_state,
            action=self.last_action,
            reward=reward,
            next_state=state,
            nonterminal=1.0 - float(done),
            log_prob=None,
            value=None,
            advantage=None,
            value_target=None,
        )
        self.last_episode.append(transition)
        if done:
            self.stop_episode_and_train()

        self.last_state = state
        self.last_action = None  # will be set in next act call

        # If action is not set, act to get action
        action, log_prob, value, self.train_recurrent_states, entropy = self.act(state, self.train_recurrent_states, test_mode)
        self.last_action = action
        return action

    def stop_episode_and_train(self):
        self.memory.append(self.last_episode)
        if len(self.memory) * len(self.last_episode) >= self.update_interval:
            if self.is_recurrent:
                self._update_recurrent()
            else:
                self._update()
        self.last_episode = []
        self.last_state = None
        self.last_action = None
        if self.is_recurrent:
            self.train_recurrent_states = None

    def _add_log_prob_and_value_to_episodes(self, episodes: List[Episode]) -> List[Episode]:
        for ep in episodes:
            for i, tr in enumerate(ep):
                state_t = torch.tensor(tr.state, dtype=torch.float32, device=self.device)
                next_state_t = torch.tensor(tr.next_state, dtype=torch.float32, device=self.device)
                if self.obs_normalizer is not None:
                    state_t = self.obs_normalizer(state_t)
                    next_state_t = self.obs_normalizer(next_state_t)

                if self.is_recurrent:
                    with torch.no_grad():
                        action_dist, value, _ = self.model(state_t, None)
                        _, next_value, _ = self.model(next_state_t, None)
                else:
                    with torch.no_grad():
                        action_dist, value = self.model(state_t)
                        _, next_value = self.model(next_state_t)

                log_prob = action_dist.log_prob(torch.tensor(tr.action, device=self.device)).sum().item()
                ep[i] = ep[i]._replace(
                    log_prob=log_prob,
                    value=value.item(),
                    next_value=next_value.item()
                )
        return episodes

    def _add_advantage_and_value_target_to_episodes(self, episodes: List[Episode]) -> List[Episode]:
        for ep in episodes:
            adv = 0.0
            for tr in reversed(ep):
                td_err = tr.reward + self.gamma * tr.nonterminal * tr.next_value - tr.value
                adv = td_err + self.gamma * self.lambd * tr.nonterminal * adv
                tr = tr._replace(
                    advantage=adv,
                    value_target=adv + tr.value
                )
                # replace in list
                ep[ep.index(tr)] = tr
        return episodes

    def _make_dataset(self, episodes: List[Episode]) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        states = []
        actions = []
        log_probs = []
        advantages = []
        value_targets = []
        for ep in episodes:
            for tr in ep:
                states.append(tr.state)
                actions.append(tr.action)
                log_probs.append(tr.log_prob)
                advantages.append(tr.advantage)
                value_targets.append(tr.value_target)
        return (
            torch.tensor(states, dtype=torch.float32, device=self.device),
            torch.tensor(actions, dtype=torch.long, device=self.device),
            torch.tensor(log_probs, dtype=torch.float32, device=self.device),
            torch.tensor(advantages, dtype=torch.float32, device=self.device),
            torch.tensor(value_targets, dtype=torch.float32, device=self.device),
        )

    def _make_dataset_recurrent(self, episodes: List[Episode]) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        sequences = []
        for ep in episodes:
            seq_states = []
            seq_actions = []
            seq_log_probs = []
            seq_advantages = []
            seq_value_targets = []
            for tr in ep:
                seq_states.append(tr.state)
                seq_actions.append(tr.action)
                seq_log_probs.append(tr.log_prob)
                seq_advantages.append(tr.advantage)
                seq_value_targets.append(tr.value_target)
            if self.max_recurrent_sequence_len:
                seq_states = seq_states[-self.max_recurrent_sequence_len:]
                seq_actions = seq_actions[-self.max_recurrent_sequence_len:]
                seq_log_probs = seq_log_probs[-self.max_recurrent_sequence_len:]
                seq_advantages = seq_advantages[-self.max_recurrent_sequence_len:]
                seq_value_targets = seq_value_targets[-self.max_recurrent_sequence_len:]
            sequences.append((seq_states, seq_actions, seq_log_probs, seq_advantages, seq_value_targets))
        # Flatten sequences
        all_states = []
        all_actions = []
        all_log_probs = []
        all_advantages = []
        all_value_targets = []
        seq_lengths = []
        for seq in sequences:
            seq_lengths.append(len(seq[0]))
            all_states.extend(seq[0])
            all_actions.extend(seq[1])
            all_log_probs.extend(seq[2])
            all_advantages.extend(seq[3])
            all_value_targets.extend(seq[4])
        return (
            torch.tensor(all_states, dtype=torch.float32, device=self.device),
            torch.tensor(all_actions, dtype=torch.long, device=self.device),
            torch.tensor(all_log_probs, dtype=torch.float32, device=self.device),
            torch.tensor(all_advantages, dtype=torch.float32, device=self.device),
            torch.tensor(all_value_targets, dtype=torch.float32, device=self.device),
            torch.tensor(seq_lengths, dtype=torch.long, device=self.device),
        )

    def _update(self):
        episodes = self._add_log_prob_and_value_to_episodes(self.memory)
        episodes = self._add_advantage_and_value_target_to_episodes(episodes)
        states, actions, old_log_probs, advantages, value_targets = self._make_dataset(episodes)

        if self.standardize_advantages:
            advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

        dataset_size = states.size(0)
        indices = torch.randperm(dataset_size)
        for _ in range(self.epochs):
            for start in range(0, dataset_size, self.minibatch_size):
                end = start + self.minibatch_size
                batch_idx = indices[start:end]
                batch_states = states[batch_idx]
                batch_actions = actions[batch_idx]
                batch_old_log_probs = old_log_probs[batch_idx]
                batch_advantages = advantages[batch_idx]
                batch_value_targets = value_targets[batch_idx]

                loss, policy_loss, value_loss, entropy = self._lossfun(
                    batch_states,
                    batch_actions,
                    batch_old_log_probs,
                    batch_advantages,
                    batch_value_targets,
                )

                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()

                self.policy_loss_record.append(policy_loss.item())
                self.value_loss_record.append(value_loss.item())
                self.entropy_record.append(entropy.item())
                self.value_record.append(batch_value_targets.mean().item())
        self.update_counter += 1
        self.memory = []

    def _update_recurrent(self):
        episodes = self._add_log_prob_and_value_to_episodes(self.memory)
        episodes = self._add_advantage_and_value_target_to_episodes(episodes)
        (
            states,
            actions,
            old_log_probs,
            advantages,
            value_targets,
            seq_lengths,
        ) = self._make_dataset_recurrent(episodes)

        if self.standardize_advantages:
            advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

        dataset_size = states.size(0)
        indices = torch.randperm(dataset_size)
        for _ in range(self.epochs):
            for start in range(0, dataset_size, self.minibatch_size):
                end = start + self.minibatch_size
                batch_idx = indices[start:end]
                batch_states = states[batch_idx]
                batch_actions = actions[batch_idx]
                batch_old_log_probs = old_log_probs[batch_idx]
                batch_advantages = advantages[batch_idx]
                batch_value_targets = value_targets[batch_idx]
                batch_seq_lengths = seq_lengths[batch_idx]

                loss, policy_loss, value_loss, entropy = self._lossfun(
                    batch_states,
                    batch_actions,
                    batch_old_log_probs,
                    batch_advantages,
                    batch_value_targets,
                )

                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()

                self.policy_loss_record.append(policy_loss.item())
                self.value_loss_record.append(value_loss.item())
                self.entropy_record.append(entropy.item())
                self.value_record.append(batch_value_targets.mean().item())
        self.update_counter += 1
        self.memory = []

    def _lossfun(
        self,
        states: torch.Tensor,
        actions: torch.Tensor,
        old_log_probs: torch.Tensor,
        advantages: torch.Tensor,
        value_targets: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        if self.is_recurrent:
            action_dist, values, _ = self.model(states, self.train_recurrent_states)
        else:
            action_dist, values = self.model(states)

        log_probs = action_dist.log_prob(actions).sum(-1)
        entropy = action_dist.entropy().sum(-1)

        ratio = torch.exp(log_probs - old_log_probs)
        clipped_ratio = torch.clamp(ratio, 1.0 - self.clip_eps, 1.0 + self.clip_eps)
        policy_loss = -torch.min(ratio * advantages, clipped_ratio * advantages).mean()

        if self.clip_eps_vf is not None:
            value_pred_clipped = values + torch.clamp(values - value_targets, -self.clip_eps_vf, self.clip_eps_vf)
            vf_loss1 = (values - value_targets).pow(2)
            vf_loss2 = (value_pred_clipped - value_targets).pow(2)
            value_loss = 0.5 * torch.max(vf_loss1, vf_loss2).mean()
        else:
            value_loss = 0.5 * (values - value_targets).pow(2).mean()

        entropy_bonus = -entropy.mean() * self.entropy_coef

        total_loss = policy_loss + self.vf_coef * value_loss + entropy_bonus
        return total_loss, policy_loss, value_loss, entropy.mean()

    def get_statistics(self):
        stats = {
            'policy_loss': np.mean(self.policy_loss_record),
            'value_loss': np.mean(self.value_loss_record),
            'entropy': np.mean(self.entropy_record),
            'value': np.mean(self.value_record),
            'updates': self.update_counter,
        }
        return stats

    # Placeholder for batched env support
    def batch_act_and_train(self, states, rewards, dones, test_mode=False):
        pass

    def batch_observe_and_train(self, env_indices, done_flags):
        pass
