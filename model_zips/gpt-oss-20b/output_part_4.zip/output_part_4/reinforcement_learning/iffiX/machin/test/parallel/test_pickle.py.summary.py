import sys
import functools
import pytest
import torch as t
import multiprocessing
import dill as pickle

def dumps(obj, *, copy_tensor=True):
    if copy_tensor and isinstance(obj, t.Tensor):
        obj = obj.clone()
    return pickle.dumps(obj, protocol=pickle.HIGHEST_PROTOCOL)

def loads(data):
    return pickle.loads(data)

def linux_only(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        if sys.platform != "linux":
            pytest.skip("Linux only test")
        return func(*args, **kwargs)
    return wrapper

def subproc_test_dumps_copy_tensor(conn):
    tensor = t.zeros([10])
    data = dumps(tensor, copy_tensor=True)
    conn.send(data)
    conn.close()

def subproc_test_dumps_not_copy_tensor(conn):
    tensor = t.zeros([10])
    tensor.share_memory_()
    data = dumps(tensor, copy_tensor=False)
    conn.send(data)
    conn.close()

def subproc_test_dumps_local_func(conn):
    shared_tensor = t.zeros([10])
    shared_tensor.share_memory_()

    def local_func():
        return shared_tensor

    data = dumps(local_func, copy_tensor=False)
    conn.send(data)
    conn.close()

def test_dumps_copy_tensor():
    parent_conn, child_conn = multiprocessing.Pipe()
    ctx = multiprocessing.get_context("spawn")
    p = ctx.Process(target=subproc_test_dumps_copy_tensor, args=(child_conn,))
    p.start()
    p.join()
    data = parent_conn.recv()
    result = loads(data)
    assert t.all(result == t.zeros([10]))

@linux_only
def test_dumps_not_copy_tensor():
    parent_conn, child_conn = multiprocessing.Pipe()
    ctx = multiprocessing.get_context("fork")
    p = ctx.Process(target=subproc_test_dumps_not_copy_tensor, args=(child_conn,))
    p.start()
    p.join()
    data = parent_conn.recv()
    result = loads(data)
    assert t.all(result == t.zeros([10]))

@linux_only
def test_dumps_local_func():
    parent_conn, child_conn = multiprocessing.Pipe()
    ctx = multiprocessing.get_context("fork")
    p = ctx.Process(target=subproc_test_dumps_local_func, args=(child_conn,))
    p.start()
    p.join()
    data = parent_conn.recv()
    local_func = loads(data)
    result = local_func()
    assert t.all(result == t.zeros([10]))