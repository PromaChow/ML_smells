import random
import numpy as np
import matplotlib.pyplot as plt
import pprint

import env  # Assume env provides final_states() and is_terminal(state)


class SarsaTable:
    def __init__(self, actions, learning_rate=0.1, reward_decay=0.9, e_greedy=0.9):
        self.actions = actions
        self.lr = learning_rate
        self.gamma = reward_decay
        self.epsilon = e_greedy

        self.q_table = {}
        self.q_table_final = {}

        self.episode_steps = []
        self.episode_costs = []

    def check_state_exist(self, state):
        if state not in self.q_table:
            self.q_table[state] = np.zeros(len(self.actions))

    def choose_action(self, state):
        self.check_state_exist(state)
        if random.random() < self.epsilon:
            state_actions = self.q_table[state]
            max_actions = np.where(state_actions == np.max(state_actions))[0]
            action_index = random.choice(max_actions)
        else:
            action_index = random.randint(0, len(self.actions) - 1)
        return self.actions[action_index]

    def learn(self, state, action, reward, next_state, next_action):
        self.check_state_exist(next_state)
        action_index = self.actions.index(action)
        next_action_index = self.actions.index(next_action)

        q_predict = self.q_table[state][action_index]

        if env.is_terminal(next_state):
            q_target = reward
        else:
            q_target = reward + self.gamma * self.q_table[next_state][next_action_index]

        self.q_table[state][action_index] += self.lr * (q_target - q_predict)

    def record_episode(self, steps, cost):
        self.episode_steps.append(steps)
        self.episode_costs.append(cost)

    def print_q_table(self):
        final_states = env.final_states()
        self.q_table_final.clear()
        for state in final_states:
            if state in self.q_table:
                self.q_table_final[state] = self.q_table[state].copy()
            else:
                self.q_table_final[state] = np.zeros(len(self.actions))

        print("Final route Q-table:")
        pprint.pprint(self.q_table_final)
        print("\nFull Q-table:")
        pprint.pprint(self.q_table)

    def plot_results(self):
        episodes = list(range(1, len(self.episode_steps) + 1))

        fig, ax1 = plt.subplots(2, 1, figsize=(10, 8), sharex=True)

        ax1[0].plot(episodes, self.episode_steps, 'b-', label='Steps per Episode')
        ax1[0].set_ylabel('Number of Steps')
        ax1[0].legend()
        ax1[0].grid(True)

        ax1[1].plot(episodes, self.episode_costs, 'r-', label='Cumulative Reward per Episode')
        ax1[1].set_xlabel('Episode')
        ax1[1].set_ylabel('Cumulative Reward')
        ax1[1].legend()
        ax1[1].grid(True)

        plt.tight_layout()
        plt.show()

        # Separate plots
        plt.figure(figsize=(12, 5))

        plt.subplot(1, 2, 1)
        plt.plot(episodes, self.episode_steps, 'b-')
        plt.title('Steps per Episode')
        plt.xlabel('Episode')
        plt.ylabel('Steps')
        plt.grid(True)

        plt.subplot(1, 2, 2)
        plt.plot(episodes, self.episode_costs, 'r-')
        plt.title('Cumulative Reward per Episode')
        plt.xlabel('Episode')
        plt.ylabel('Reward')
        plt.grid(True)

        plt.tight_layout()
        plt.show()
