import numpy as np
import matplotlib.pyplot as plt
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
from scikitTSVM import SKTSVM
from cple_learning import CPLELearningModel

np.random.seed(0)

# 1. Data Generation
N = 60
clusters = 6
points_per_cluster = N // clusters
means = np.random.uniform(-5, 5, size=(clusters, 2))
s = np.random.uniform(0, 1)
cov = np.eye(2) * s
X = np.vstack([np.random.multivariate_normal(m, cov, points_per_cluster) for m in means])

# 2. Target Label Assignment
overall_mean = X.mean(axis=0)
y_true = np.where(
    (X[:, 0] < overall_mean[0]) == (X[:, 1] < overall_mean[1]),
    1, 0
)

# 3. Supervised Data Selection
idx_class0 = np.where(y_true == 0)[0]
idx_class1 = np.where(y_true == 1)[0]
selected_idx = np.concatenate([
    np.random.choice(idx_class0, 2, replace=False),
    np.random.choice(idx_class1, 2, replace=False)
])
y_s = np.full_like(y_true, -1)
y_s[selected_idx] = y_true[selected_idx]
X_s = X
X_supervised = X[selected_idx]
y_supervised = y_true[selected_idx]

# 4. Utility for evaluation and plotting
def evaluate_and_plot(model, X, y_true, title):
    y_pred = model.predict(X)
    acc = accuracy_score(y_true, y_pred)
    print(f"{title} accuracy: {acc:.3f}")

    h = .02
    x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
                         np.arange(y_min, y_max, h))
    Z = model.predict(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)

    plt.figure(figsize=(6, 4))
    plt.contourf(xx, yy, Z, cmap=plt.cm.coolwarm, alpha=0.8)
    plt.scatter(X[:, 0], X[:, 1], c=y_true, cmap=plt.cm.coolwarm, edgecolors='k')
    plt.title(title)
    plt.xlabel('X1')
    plt.ylabel('X2')
    plt.show()

# 5. Model Training and Evaluation
# Purely Supervised SVM
svc_sup = SVC(kernel='rbf', gamma='scale')
svc_sup.fit(X_supervised, y_supervised)
evaluate_and_plot(svc_sup, X, y_true, "Purely Supervised SVM")

# S3VM (Transductive SVM)
sktsvm = SKTSVM(kernel='rbf', gamma='scale')
sktsvm.fit(X_s, y_s)
evaluate_and_plot(sktsvm, X, y_true, "S3VM (Transductive SVM)")

# CPLE (Pessimistic) SVM
cple_pessimistic = CPLELearningModel(SVC(kernel='rbf', gamma='scale'), pessimistic=True)
cple_pessimistic.fit(X_s, y_s)
evaluate_and_plot(cple_pessimistic, X, y_true, "CPLE (Pessimistic) SVM")

# CPLE (Optimistic) SVM
cple_optimistic = CPLELearningModel(SVC(kernel='rbf', gamma='scale'), pessimistic=False)
cple_optimistic.fit(X_s, y_s)
evaluate_and_plot(cple_optimistic, X, y_true, "CPLE (Optimistic) SVM")