import chainer
from chainer import functions as F

from chainerrl.links.mlp import MLP
from chainerrl.recurrent import RecurrentChainMixin
from chainerrl.v_function import VFunction


class SingleModelVFunction(
        chainer.Chain, VFunction, RecurrentChainMixin):
    """V-function

    Args:
        model (chainer.Link):
            Link that is callable, inputs states, and outputs state values.
    """

    def __init__(self, model):
        super().__init__(model=model)

    def __call__(self, x):
        h = self.model(x)
        return h


class FCVFunction(SingleModelVFunction):

    def __init__(self, n_input_channels, n_hidden_layers=0,
                 n_hidden_channels=None, nonlinearity=F.relu,
                 last_wscale=1):
        self.n_input_channels = n_input_channels
        self.n_hidden_layers = n_hidden_layers
        self.n_hidden_channels = n_hidden_channels

        super().__init__(
            model=MLP(self.n_input_channels, 1,
                      [self.n_hidden_channels] * self.n_hidden_layers,
                      nonlinearity=nonlinearity,
                      last_wscale=last_wscale),
        )
