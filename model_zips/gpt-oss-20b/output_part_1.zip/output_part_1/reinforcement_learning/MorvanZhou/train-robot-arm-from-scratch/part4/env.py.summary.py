import math
import numpy as np
import pyglet

class ArmEnv:
    def __init__(self):
        self.l1 = 100.0
        self.l2 = 100.0
        self.dt = 0.1
        self.goal_pos = np.array([100.0, 100.0])
        self.goal_size = 40.0
        self.base = np.array([0.0, 0.0])
        self._reset_angles()
        self.viewer = None

    def _reset_angles(self):
        self.angle1 = np.random.uniform(0, 2 * math.pi)
        self.angle2 = np.random.uniform(0, 2 * math.pi)

    def reset(self):
        self._reset_angles()
        return np.array([self.angle1, self.angle2])

    def step(self, action):
        action = np.clip(action, -1.0, 1.0)
        self.angle1 = (self.angle1 + action[0] * self.dt) % (2 * math.pi)
        self.angle2 = (self.angle2 + action[1] * self.dt) % (2 * math.pi)
        state = np.array([self.angle1, self.angle2])
        end_pos = self._end_effector()
        reward = 0.0
        done = False
        if (self.goal_pos[0] <= end_pos[0] <= self.goal_pos[0] + self.goal_size and
            self.goal_pos[1] <= end_pos[1] <= self.goal_pos[1] + self.goal_size):
            reward = 1.0
            done = True
        return state, reward, done, {}

    def _end_effector(self):
        x1 = self.l1 * math.cos(self.angle1)
        y1 = self.l1 * math.sin(self.angle1)
        x2 = x1 + self.l2 * math.cos(self.angle1 + self.angle2)
        y2 = y1 + self.l2 * math.sin(self.angle1 + self.angle2)
        return np.array([x2, y2])

    def sample_action(self):
        return np.random.uniform(-0.5, 0.5, size=2)

    def render(self):
        if self.viewer is None:
            self.viewer = Viewer(self)
            pyglet.app.run()
        return None


class Viewer(pyglet.window.Window):
    def __init__(self, env):
        super().__init__(width=400, height=400, caption="2D Arm Environment")
        self.env = env
        self.set_location(100, 100)
        pyglet.clock.schedule_interval(self.update, 1/60.0)

    def update(self, dt):
        self.invalidate()

    def on_draw(self):
        self.clear()
        # Draw target square in blue
        goal = self.env.goal_pos
        size = self.env.goal_size
        pyglet.graphics.draw(4, pyglet.gl.GL_QUADS,
                             ('v2f', [200 + goal[0], 200 + goal[1],
                                      200 + goal[0] + size, 200 + goal[1],
                                      200 + goal[0] + size, 200 + goal[1] + size,
                                      200 + goal[0], 200 + goal[1] + size]),
                             ('c3f', [0.0, 0.0, 1.0] * 4))
        # Draw first arm segment in black
        base_x, base_y = 200, 200
        x1 = base_x + self.env.l1 * math.cos(self.env.angle1)
        y1 = base_y + self.env.l1 * math.sin(self.env.angle1)
        pyglet.graphics.draw(2, pyglet.gl.GL_LINES,
                             ('v2f', [base_x, base_y, x1, y1]))
        # Draw second arm segment in black
        x2 = x1 + self.env.l2 * math.cos(self.env.angle1 + self.env.angle2)
        y2 = y1 + self.env.l2 * math.sin(self.env.angle1 + self.env.angle2)
        pyglet.graphics.draw(2, pyglet.gl.GL_LINES,
                             ('v2f', [x1, y1, x2, y2]))


if __name__ == "__main__":
    env = ArmEnv()
    state = env.reset()
    done = False
    step_count = 0
    while not done and step_count < 200:
        action = env.sample_action()
        state, reward, done, _ = env.step(action)
        if step_count % 10 == 0:
            env.render()
        step_count += 1
    print("Episode finished after", step_count, "steps with reward", reward)