import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.cluster.hierarchy import linkage, dendrogram

# Load dataset
df = pd.read_csv("movie_metadata1.csv")
print(df.head())

# Extract features
budget = df["budget"].values
gross = df["gross"].values

# Select first 10 entries (or fewer if dataset is smaller)
n_samples = min(10, len(budget))
budget10 = budget[:n_samples]
gross10 = gross[:n_samples]

# Combine into 2D array
X = np.column_stack((budget10, gross10))

# Perform hierarchical clustering
z = linkage(X, method="ward")

# Plot dendrogram
plt.figure(figsize=(10, 5))
dendrogram(z)
plt.title("Hierarchical Clustering Dendrogram")
plt.xlabel("Sample index")
plt.ylabel("Distance")
plt.tight_layout()
plt.show()