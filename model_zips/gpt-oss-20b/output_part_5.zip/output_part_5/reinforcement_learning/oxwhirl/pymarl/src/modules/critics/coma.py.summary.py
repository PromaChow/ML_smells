import torch
import torch.nn as nn
import torch.nn.functional as F


class COMACritic(nn.Module):
    def __init__(self, scheme, args):
        super().__init__()
        self.n_actions = scheme["action"]["vshape"][0]
        self.n_agents = scheme["obs"]["vshape"][0]
        self.input_shape = self._get_input_shape(scheme)

        self.fc1 = nn.Linear(self.input_shape, 128)
        self.fc2 = nn.Linear(128, 128)
        self.fc3 = nn.Linear(128, self.n_actions)

    def _get_input_shape(self, scheme):
        state_dim = scheme["state"]["vshape"][0]
        obs_dim = scheme["obs"]["vshape"][1]
        actions_dim = self.n_actions * self.n_agents * 2
        agent_id_dim = self.n_agents
        return state_dim + obs_dim + actions_dim + agent_id_dim

    def forward(self, batch, t):
        inputs = self._build_inputs(batch, t)
        x = F.relu(self.fc1(inputs))
        x = F.relu(self.fc2(x))
        out = self.fc3(x)
        seq_len = inputs.shape[1]
        return out.reshape(-1, seq_len, self.n_agents, self.n_actions)

    def _build_inputs(self, batch, t):
        state = batch["state"]
        obs = batch["obs"]
        actions = batch["actions"]

        if isinstance(t, int):
            start, end = t, t + 1
        elif isinstance(t, slice):
            start = t.start if t.start is not None else 0
            end = t.stop if t.stop is not None else state.shape[1]
        else:
            raise ValueError("t must be an int or slice")

        state_slice = state[:, start:end]
        obs_slice = obs[:, start:end]
        actions_slice = actions[:, start:end]

        actions_one_hot = F.one_hot(actions_slice, num_classes=self.n_actions).float()
        mask = 1 - torch.eye(self.n_agents, device=actions_one_hot.device)
        masked_actions = actions_one_hot.unsqueeze(2) * mask[None, None, :, :, None]
        masked_actions = masked_actions.reshape(
            -1, state_slice.shape[1], self.n_agents, self.n_agents * self.n_actions
        )

        last_actions_all = torch.zeros_like(actions_slice)
        last_actions_all[:, 1:] = actions_slice[:, :-1]
        last_actions_one_hot = F.one_hot(last_actions_all, num_classes=self.n_actions).float()
        masked_last_actions = last_actions_one_hot.unsqueeze(2) * mask[None, None, :, :, None]
        masked_last_actions = masked_last_actions.reshape(
            -1, state_slice.shape[1], self.n_agents, self.n_agents * self.n_actions
        )

        state_exp = state_slice.unsqueeze(2).expand(-1, -1, self.n_agents, -1)
        agent_ids = torch.eye(self.n_agents, device=state.device).unsqueeze(0).unsqueeze(0)
        agent_ids = agent_ids.expand(state_slice.shape[0], state_slice.shape[1], -1, -1)

        inputs = torch.cat(
            [state_exp, obs_slice, masked_actions, masked_last_actions, agent_ids], dim=-1
        )
        inputs = inputs.reshape(-1, self.input_shape)
        return inputs
