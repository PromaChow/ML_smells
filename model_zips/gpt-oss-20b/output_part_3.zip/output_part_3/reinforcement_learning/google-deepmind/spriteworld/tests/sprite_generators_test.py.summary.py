import random
from dataclasses import dataclass
from typing import Callable, Dict, List, Tuple
import pytest

random.seed(0)

@dataclass(frozen=True)
class Sprite:
    position: int
    shape: str
    color: str

# Factor distributions
_distrib_0: Dict[str, object] = {
    "position_range": (0, 5),
    "shape": "square",
    "color": "red",
}
_distrib_1: Dict[str, object] = {
    "position_range": (6, 10),
    "shape": "circle",
    "color": "blue",
}

def generate_sprites(num_sprites: int, distribution: Dict[str, object]) -> List[Sprite]:
    sprites = []
    pos_min, pos_max = distribution["position_range"]
    for _ in range(num_sprites):
        position = random.randint(pos_min, pos_max)
        sprite = Sprite(
            position=position,
            shape=distribution["shape"],
            color=distribution["color"],
        )
        sprites.append(sprite)
    return sprites

def chain_generators(generators: List[Callable[[], List[Sprite]]]) -> List[Sprite]:
    combined: List[Sprite] = []
    for gen in generators:
        combined.extend(gen())
    return combined

def sample_generator(generators: List[Callable[[], List[Sprite]]]) -> List[Sprite]:
    chosen_gen = random.choice(generators)
    return chosen_gen()

def shuffle(sprites: List[Sprite]) -> List[Sprite]:
    shuffled = sprites[:]
    random.shuffle(shuffled)
    return shuffled

def validate_sprite(sprite: Sprite, distribution: Dict[str, object]) -> bool:
    pos_min, pos_max = distribution["position_range"]
    return (
        pos_min <= sprite.position <= pos_max
        and sprite.shape == distribution["shape"]
        and sprite.color == distribution["color"]
    )

# Test suite

def testGenerateSpritesLengthType():
    for num_sprites in (1, 2, 5):
        sprites = generate_sprites(num_sprites, _distrib_0)
        assert len(sprites) == num_sprites
        assert all(isinstance(s, Sprite) for s in sprites)

def testGenerateSpritesCallableNum():
    num_sprites = random.randint(3, 5)
    sprites = generate_sprites(num_sprites, _distrib_1)
    assert 3 <= len(sprites) <= 5

def testChainGenerators():
    g_0 = lambda: generate_sprites(1, _distrib_0)
    g_1 = lambda: generate_sprites(2, _distrib_1)
    combined = chain_generators([g_0, g_1])
    assert len(combined) == 3
    assert validate_sprite(combined[0], _distrib_0)
    assert validate_sprite(combined[1], _distrib_1)
    assert validate_sprite(combined[2], _distrib_1)

def testSampleGenerator():
    g_0 = lambda: generate_sprites(2, _distrib_0)
    g_1 = lambda: generate_sprites(3, _distrib_1)
    sprites = sample_generator([g_0, g_1])
    # All sprites should belong to the same distribution and not both
    if validate_sprite(sprites[0], _distrib_0):
        expected = _distrib_0
    else:
        expected = _distrib_1
    assert all(validate_sprite(s, expected) for s in sprites)

def testShuffle():
    original = generate_sprites(5, _distrib_0)
    shuffled = shuffle(original)
    assert len(shuffled) == 5
    assert set(original) == set(shuffled)
    # Ensure order is different when possible
    assert original != shuffled or original == shuffled  # allows identical shuffle due to randomness
```