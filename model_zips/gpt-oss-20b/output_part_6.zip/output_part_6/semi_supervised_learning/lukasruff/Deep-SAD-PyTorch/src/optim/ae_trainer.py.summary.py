import time
from typing import List, Tuple, Any, Optional

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torch.optim.lr_scheduler import MultiStepLR
from sklearn.metrics import roc_auc_score


class AETrainer:
    def __init__(
        self,
        optimizer_type: str = "Adam",
        learning_rate: float = 0.001,
        num_epochs: int = 150,
        batch_size: int = 128,
        weight_decay: float = 1e-6,
        milestones: Optional[List[int]] = None,
        gamma: float = 0.1,
        device: Optional[str] = None,
    ) -> None:
        self.optimizer_type = optimizer_type
        self.learning_rate = learning_rate
        self.num_epochs = num_epochs
        self.batch_size = batch_size
        self.weight_decay = weight_decay
        self.milestones = milestones or [50, 100]
        self.gamma = gamma
        self.device = torch.device(device if device else ("cuda" if torch.cuda.is_available() else "cpu"))
        self.train_time: Optional[float] = None
        self.test_time: Optional[float] = None
        self.test_auc: Optional[float] = None
        self.test_loss: Optional[float] = None

    def _get_loader(self, dataset: Any, train: bool = True) -> DataLoader:
        return dataset.loaders(batch_size=self.batch_size, shuffle=train)

    def train(self, dataset: Any, ae_net: nn.Module) -> None:
        train_loader = self._get_loader(dataset, train=True)
        loss_fn = nn.MSELoss(reduction="none")
        ae_net = ae_net.to(self.device)
        loss_fn = loss_fn.to(self.device)

        optimizer = optim.Adam(ae_net.parameters(), lr=self.learning_rate, weight_decay=self.weight_decay)
        scheduler = MultiStepLR(optimizer, milestones=self.milestones, gamma=self.gamma)

        ae_net.train()
        start_time = time.perf_counter()

        for epoch in range(1, self.num_epochs + 1):
            epoch_loss = 0.0
            for batch in train_loader:
                inputs = batch[0].to(self.device)
                optimizer.zero_grad()
                recon = ae_net(inputs)
                per_sample_loss = loss_fn(recon, inputs).mean(dim=1)
                loss = per_sample_loss.mean()
                loss.backward()
                optimizer.step()
                epoch_loss += loss.item() * inputs.size(0)
            scheduler.step()
            epoch_loss /= len(train_loader.dataset)
            print(f"Epoch {epoch}/{self.num_epochs} - Loss: {epoch_loss:.6f}")

        self.train_time = time.perf_counter() - start_time
        print(f"Training completed in {self.train_time:.2f} seconds.")

    def test(self, dataset: Any, ae_net: nn.Module) -> None:
        test_loader = self._get_loader(dataset, train=False)
        loss_fn = nn.MSELoss(reduction="none")
        ae_net = ae_net.to(self.device)
        loss_fn = loss_fn.to(self.device)

        ae_net.eval()
        scores = []
        all_labels = []
        test_start = time.perf_counter()
        total_loss = 0.0

        with torch.no_grad():
            for batch in test_loader:
                inputs = batch[0].to(self.device)
                if len(batch) >= 2:
                    labels = batch[1].to(self.device)
                else:
                    labels = torch.zeros(inputs.size(0), device=self.device)
                recon = ae_net(inputs)
                per_sample_loss = loss_fn(recon, inputs).mean(dim=1)
                scores.append(per_sample_loss.cpu().numpy())
                all_labels.append(labels.cpu().numpy())
                total_loss += per_sample_loss.sum().item()

        self.test_time = time.perf_counter() - test_start
        self.test_loss = total_loss / len(test_loader.dataset)
        self.test_auc = roc_auc_score(
            np.concatenate(all_labels), np.concatenate(scores)
        )
        print(f"Test loss: {self.test_loss:.6f}")
        print(f"Test AUC: {self.test_auc:.6f}")
        print(f"Testing completed in {self.test_time:.2f} seconds.")



# Example usage (requires a dataset and autoencoder definition):
# dataset = YourBaseADDataset()
# ae_model = YourAutoencoder()
# trainer = AETrainer()
# trainer.train(dataset, ae_model)
# trainer.test(dataset, ae_model)