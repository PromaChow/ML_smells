import numpy as np
import math
import random

# Placeholder base classes – replace with actual imports in your environment
class WalkerBase:
    def __init__(self, power=1.0):
        self.power = power

    def robot_specific_reset(self):
        pass

class MJCFBasedRobot:
    def __init__(self, mjcf_path, root_body, act_dim, obs_dim):
        self.mjcf_path = mjcf_path
        self.root_body = root_body
        self.act_dim = act_dim
        self.obs_dim = obs_dim
        # Placeholder joint list – replace with actual joint order from the model
        self.ordered_joint_names = []

    def get_body_pos(self, body_name):
        return np.zeros(3)

    def get_body_vel(self, body_name):
        return np.zeros(3)

    def get_joint_qpos(self, joint_name):
        return 0.0

    def get_joint_qvel(self, joint_name):
        return 0.0

    def set_joint_torque(self, joint_name, torque):
        pass

    def get_body_com(self, body_name):
        return np.zeros(3)

class Humanoid(WalkerBase, MJCFBasedRobot):
    def __init__(self, random_yaw=True, random_lean=True):
        self.self_collision = True
        self.foot_list = ["right_foot", "left_foot"]
        self.random_yaw = random_yaw
        self.random_lean = random_lean

        WalkerBase.__init__(self, power=0.41)
        MJCFBasedRobot.__init__(self,
                                mjcf_path='humanoid_symmetric.xml',
                                root_body='torso',
                                act_dim=17,
                                obs_dim=376)

        # Motor joint names and powers
        self.motors = {
            # Abdomen joints
            'abdomen_z': 100,
            'abdomen_y': 100,
            'abdomen_x': 100,
            # Right leg joints
            'right_hip_x': 100,
            'right_hip_z': 100,
            'right_hip_y': 300,
            'right_knee': 200,
            # Left leg joints
            'left_hip_x': 100,
            'left_hip_z': 100,
            'left_hip_y': 300,
            'left_knee': 200,
            # Right arm joints
            'right_shoulder1': 75,
            'right_shoulder2': 75,
            'right_elbow': 75,
            # Left arm joints
            'left_shoulder1': 75,
            'left_shoulder2': 75,
            'left_elbow': 75
        }

        # Initial position and orientation placeholders
        self.initial_pos = np.zeros(3)
        self.initial_orientation = np.array([1, 0, 0, 0])  # quaternion

    def robot_specific_reset(self):
        super().robot_specific_reset()

        yaw = 0.0
        if self.random_yaw:
            yaw = random.uniform(-math.pi, math.pi)

        pitch = 0.0
        pos_z = 1.4
        if self.random_lean:
            if random.random() < 0.5:
                # lean forward
                pitch = math.pi / 2
                pos_z = 0.45
            else:
                # lean backward
                pitch = 3 * math.pi / 2
                pos_z = 0.25

        self.initial_pos = np.array([0.0, 0.0, pos_z])
        # Convert Euler angles (yaw, pitch, roll) to quaternion
        cy = math.cos(yaw * 0.5)
        sy = math.sin(yaw * 0.5)
        cp = math.cos(pitch * 0.5)
        sp = math.sin(pitch * 0.5)
        cr = math.cos(0.0 * 0.5)
        sr = math.sin(0.0 * 0.5)
        w = cr * cp * cy + sr * sp * sy
        x = sr * cp * cy - cr * sp * sy
        y = cr * sp * cy + sr * cp * sy
        z = cr * cp * sy - sr * sp * cy
        self.initial_orientation = np.array([w, x, y, z])

    def calc_state(self):
        torso_pos = self.get_body_pos('torso')
        torso_vel = self.get_body_vel('torso')

        qpos = []
        qvel = []
        for joint in self.ordered_joint_names:
            qpos.append(self.get_joint_qpos(joint))
            qvel.append(self.get_joint_qvel(joint))

        qpos = np.array(qpos)
        qvel = np.array(qvel)

        cinert = np.zeros(6)
        cvel = np.zeros(6)
        qfrc_actuator = np.zeros_like(qpos)
        cfrc_ext = np.zeros_like(qpos)

        state = np.concatenate([qpos[2:], qvel, cinert, cvel, qfrc_actuator, cfrc_ext])
        return state

    def apply_action(self, a):
        if not np.all(np.isfinite(a)):
            raise ValueError("Action contains non-finite values")

        for i, joint in enumerate(self.motors):
            torque = (1.0 *
                      self.power *
                      self.motors[joint] *
                      np.clip(a[i], -1.0, 1.0))
            self.set_joint_torque(joint, torque)

    def alive_bonus(self):
        torso_z = self.get_body_com('torso')[2]
        if torso_z > 0.78:
            return 2.0
        else:
            return -1.0
