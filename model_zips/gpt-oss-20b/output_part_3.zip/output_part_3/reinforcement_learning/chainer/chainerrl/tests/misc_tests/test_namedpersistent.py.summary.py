import chainer
import numpy as np
import chainerrl

def test_namedpersistent():
    l1 = chainer.Link()
    with l1.init_scope():
        l1.x = chainer.Parameter(np.zeros((2, 3)))

    l2 = chainer.Link()
    with l2.init_scope():
        l2.x = chainer.Parameter(np.zeros(2))
        l2.add_persistent('l2_a', np.zeros((1, 2, 3)))

    l3 = chainer.Link()
    with l3.init_scope():
        l3.x = chainer.Parameter()
        l3.add_persistent('l3_a', np.zeros((1, 2, 3)))

    c1 = chainer.Chain()
    with c1.init_scope():
        c1.add_child('l1', l1)
        c1.add_persistent('c1_a', np.zeros((1, 2, 3)))
        c1.add_child('l2', l2)

    c2 = chainer.Chain()
    with c2.init_scope():
        c2.add_child('c1', c1)
        c2.add_child('l3', l3)
        c2.add_persistent('c2_a', np.zeros((1, 2, 3)))

    named = chainerrl.misc.namedpersistent(c2)
    collected = [(name, id(obj)) for name, obj in named.items()]

    expected = [
        ('/c2_a', id(c2.c2_a)),
        ('/c1/c1_a', id(c2.c1.c1_a)),
        ('/c1/l1/x', id(c2.c1.l1.x)),
        ('/c1/l2/l2_a', id(c2.c1.l2.l2_a)),
        ('/l3/l3_a', id(c2.l3.l3_a)),
    ]

    assert collected == expected

if __name__ == "__main__":
    test_namedpersistent()