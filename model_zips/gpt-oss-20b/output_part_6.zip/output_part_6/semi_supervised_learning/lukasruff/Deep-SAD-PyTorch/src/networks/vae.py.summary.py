import torch
import torch.nn as nn
import torch.nn.functional as F


class GaussianSample(nn.Module):
    def __init__(self, in_dim: int, latent_dim: int):
        super().__init__()
        self.fc = nn.Linear(in_dim, 2 * latent_dim)

    def forward(self, x: torch.Tensor):
        h = self.fc(x)
        mu, logvar = torch.chunk(h, 2, dim=-1)
        eps = torch.randn_like(mu)
        z = mu + eps * torch.exp(0.5 * logvar)
        return z, mu, logvar


class Encoder(nn.Module):
    def __init__(self, dims: list[int]):
        super().__init__()
        layers = []
        for in_dim, out_dim in zip(dims[:-2], dims[1:-1]):
            layers.append(nn.Linear(in_dim, out_dim))
        self.hidden = nn.ModuleList(layers)
        self.gaussian = GaussianSample(dims[-2], dims[-1])

    def forward(self, x: torch.Tensor):
        for layer in self.hidden:
            x = F.relu(layer(x))
        z, mu, logvar = self.gaussian(x)
        return z, mu, logvar


class Decoder(nn.Module):
    def __init__(self, dims: list[int]):
        super().__init__()
        layers = []
        for in_dim, out_dim in zip(dims[:-1], dims[1:]):
            layers.append(nn.Linear(in_dim, out_dim))
        self.hidden = nn.ModuleList(layers[:-1])
        self.reconstruction = layers[-1]
        self.sigmoid = nn.Sigmoid()

    def forward(self, z: torch.Tensor):
        for layer in self.hidden:
            z = F.relu(layer(z))
        recon = self.sigmoid(self.reconstruction(z))
        return recon


class VariationalAutoencoder(nn.Module):
    def __init__(self, dims: list[int]):
        super().__init__()
        self.encoder = Encoder(dims)
        self.decoder = Decoder(list(reversed(dims)))
        self.kl_divergence = None
        self._xavier_init()

    def _xavier_init(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_normal_(m.weight)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def _kld(self, mu: torch.Tensor, logvar: torch.Tensor):
        kld = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp(), dim=1)
        return kld.mean()

    def forward(self, x: torch.Tensor):
        z, mu, logvar = self.encoder(x)
        self.kl_divergence = self._kld(mu, logvar)
        recon = self.decoder(z)
        return recon

    def sample(self, z: torch.Tensor):
        return self.decoder(z)