import numpy as np
from sklearn.model_selection import GridSearchCV
from pywsl.pul import gen_twonorm_pumil, PUMIL_SL, bin_clf_err

def main():
    # 1. Data Generation
    x, y, x_t, y_t = gen_twonorm_pumil(
        n_p=30,
        n_u=200,
        prior_u=0.5,
        n_t=100
    )

    # 2. Hyperparameter Setup
    param_grid = {
        'prior': [0.5],
        'lam': np.logspace(-3, 1, 5),
        'basis': ['minimax']
    }

    # 3. Model Training
    grid = GridSearchCV(
        estimator=PUMIL_SL(),
        param_grid=param_grid,
        cv=5,
        n_jobs=-1
    )
    grid.fit(x, y)

    # 4. Prediction and Evaluation
    y_h = grid.predict(x_t)
    error = bin_clf_err(y_h, y_t, prior=0.5)
    print(f"Test error: {error * 100:.2f}%")

if __name__ == "__main__":
    main()
