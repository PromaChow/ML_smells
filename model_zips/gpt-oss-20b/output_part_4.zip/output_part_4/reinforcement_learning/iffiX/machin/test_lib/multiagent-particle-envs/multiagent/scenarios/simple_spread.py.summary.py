import numpy as np

class Entity:
    def __init__(self, name, size=0.15, color=None, collidable=True, movable=True):
        self.name = name
        self.size = size
        self.color = color
        self.collidable = collidable
        self.movable = movable
        self.state = State()

class State:
    def __init__(self):
        self.pos = np.zeros(2)
        self.vel = np.zeros(2)
        self.c = np.zeros(2)

class Agent(Entity):
    def __init__(self, name):
        super().__init__(name, size=0.15, color=[0.35, 0.35, 0.85], collidable=True, movable=True)
        self.collision_detected = False

class Landmark(Entity):
    def __init__(self, name):
        super().__init__(name, size=0.15, color=[0.25, 0.25, 0.25], collidable=False, movable=False)

class World:
    def __init__(self, dim_c=2, num_agents=3, num_landmarks=3):
        self.dim_c = dim_c
        self.agents = [Agent(f'agent_{i}') for i in range(num_agents)]
        self.landmarks = [Landmark(f'landmark_{i}') for i in range(num_landmarks)]
        self.reset()

    def reset(self):
        for agent in self.agents:
            agent.state.pos = np.random.uniform(-1, 1, 2)
            agent.state.vel = np.zeros(2)
            agent.state.c = np.zeros(self.dim_c)
        for lm in self.landmarks:
            lm.state.pos = np.random.uniform(-1, 1, 2)
            lm.state.vel = np.zeros(2)
            lm.state.c = np.zeros(self.dim_c)

    def step(self, actions):
        for agent, act in zip(self.agents, actions):
            agent.state.vel = act
        for agent in self.agents:
            agent.state.pos += agent.state.vel
        for lm in self.landmarks:
            lm.state.pos += lm.state.vel

    def compute_reward(self):
        reward = 0.0
        for lm in self.landmarks:
            min_dist = min(np.linalg.norm(a.state.pos - lm.state.pos) for a in self.agents)
            reward -= min_dist
        for i, a1 in enumerate(self.agents):
            for a2 in self.agents[i+1:]:
                if self.check_collision(a1, a2):
                    reward -= 1.0
        return reward

    def check_collision(self, a1, a2):
        dist = np.linalg.norm(a1.state.pos - a2.state.pos)
        return dist < (a1.size + a2.size)

    def get_observation(self, agent):
        own = np.concatenate([agent.state.pos, agent.state.vel])
        landmarks_rel = []
        for lm in self.landmarks:
            landmarks_rel.append(lm.state.pos - agent.state.pos)
        agents_rel = []
        comms = []
        for other in self.agents:
            if other is agent:
                continue
            agents_rel.append(other.state.pos - agent.state.pos)
            comms.append(other.state.c)
        obs = np.concatenate([own] + landmarks_rel + agents_rel + comms)
        return obs

    def benchmark(self):
        metrics = {'reward': [], 'collisions': [], 'min_dists': [], 'occupied_lm': []}
        reward = self.compute_reward()
        metrics['reward'].append(reward)
        collisions = sum(self.check_collision(a1, a2) for i, a1 in enumerate(self.agents) for a2 in self.agents[i+1:])
        metrics['collisions'].append(collisions)
        min_dists = [min(np.linalg.norm(a.state.pos - lm.state.pos) for a in self.agents) for lm in self.landmarks]
        metrics['min_dists'].extend(min_dists)
        occupied = [any(self.check_collision(a, lm) for a in self.agents) for lm in self.landmarks]
        metrics['occupied_lm'].extend(occupied)
        return metrics

# Example usage
if __name__ == "__main__":
    world = World()
    actions = [np.random.uniform(-0.1, 0.1, 2) for _ in world.agents]
    world.step(actions)
    print("Reward:", world.compute_reward())
    for i, agent in enumerate(world.agents):
        print(f"Observation for {agent.name}:", world.get_observation(agent))
    print("Benchmark metrics:", world.benchmark())