import tensorflow as tf
import numpy as np
import random
import collections
from typing import Callable, Tuple, List, Optional


class PassThrough:
    def __call__(self, action: np.ndarray) -> np.ndarray:
        return action


class PrioritizedExperienceReplay:
    def __init__(
        self,
        memsize: int,
        nsteps: int = 1,
        prob_alpha: float = 0.2,
        prob_beta_start: float = 0.4,
        prob_beta_frames: int = 100000,
    ):
        self.memsize = memsize
        self.nsteps = nsteps
        self.prob_alpha = prob_alpha
        self.prob_beta_start = prob_beta_start
        self.prob_beta_frames = prob_beta_frames
        self.frame = 1

        self.states = np.zeros((memsize, *self._shape), dtype=np.float32)
        self.actions = np.zeros((memsize, self.action_dim), dtype=np.float32)
        self.rewards = np.zeros((memsize, 1), dtype=np.float32)
        self.next_states = np.zeros((memsize, *self._shape), dtype=np.float32)
        self.dones = np.zeros((memsize, 1), dtype=bool)
        self.priorities = np.zeros((memsize,), dtype=np.float32)

        self.idx = 0
        self.size = 0

    @property
    def _shape(self):
        return (1,)

    @property
    def action_dim(self):
        return 1

    def push(
        self,
        state: np.ndarray,
        action: np.ndarray,
        reward: float,
        next_state: np.ndarray,
        done: bool,
        priority: float = 1.0,
    ):
        self.states[self.idx] = state
        self.actions[self.idx] = action
        self.rewards[self.idx] = reward
        self.next_states[self.idx] = next_state
        self.dones[self.idx] = done
        self.priorities[self.idx] = priority

        self.idx = (self.idx + 1) % self.memsize
        self.size = min(self.size + 1, self.memsize)

    def sample(
        self,
        batch_size: int,
    ) -> Tuple[Tuple[np.ndarray, ...], np.ndarray, np.ndarray]:
        if self.size == self.memsize:
            probs = self.priorities ** self.prob_alpha
        else:
            probs = self.priorities[: self.size] ** self.prob_alpha
        probs /= probs.sum()

        indices = np.random.choice(self.size, batch_size, p=probs)
        batch = (
            self.states[indices],
            self.actions[indices],
            self.rewards[indices],
            self.next_states[indices],
            self.dones[indices],
        )
        beta = min(1.0, self.prob_beta_start + self.frame * (1.0 - self.prob_beta_start) / self.prob_beta_frames)
        self.frame += 1
        weights = (self.size * probs[indices]) ** (-beta)
        weights /= weights.max()
        return batch, indices, weights

    def update_priorities(self, indices: np.ndarray, priorities: np.ndarray):
        self.priorities[indices] = priorities


class DDPG:
    def __init__(
        self,
        actor: tf.keras.Model,
        critic: tf.keras.Model,
        memsize: int = 100000,
        nsteps: int = 1,
        batch_size: int = 64,
        gamma: float = 0.99,
        tau: float = 0.005,
        target_update: float = 1.0,
        prob_alpha: float = 0.2,
        learning_rate: float = 5e-3,
        policy: Optional[Callable] = None,
    ):
        self.actor = actor
        self.critic = critic
        self.target_actor = tf.keras.models.clone_model(actor)
        self.target_critic = tf.keras.models.clone_model(critic)
        self.target_actor.set_weights(actor.get_weights())
        self.target_critic.set_weights(critic.get_weights())

        self.actor_optimizer = tf.keras.optimizers.Adam(learning_rate=learning_rate)
        self.critic_optimizer = tf.keras.optimizers.Adam(learning_rate=learning_rate)

        self.memory = PrioritizedExperienceReplay(
            memsize=memsize, nsteps=nsteps, prob_alpha=prob_alpha
        )
        self.batch_size = batch_size
        self.gamma = gamma
        self.tau = tau
        self.target_update = target_update
        self.policy = policy or PassThrough()

        self.nstep_buffer = collections.deque(maxlen=nsteps)
        self.step_counter = 0
        self.epsilon = 1e-6

    def push(
        self,
        state: np.ndarray,
        action: np.ndarray,
        reward: float,
        next_state: np.ndarray,
        done: bool,
    ):
        self.nstep_buffer.append((state, action, reward, next_state, done))
        if len(self.nstep_buffer) == self.nstep_buffer.maxlen:
            self._store_nstep()
        if done:
            self._flush_nstep_buffer()

    def _store_nstep(self):
        reward, done, next_state = 0.0, False, self.nstep_buffer[-1][3]
        for i, (_, _, r, _, d) in enumerate(self.nstep_buffer):
            reward += (self.gamma ** i) * r
            done = done or d
        state, action, _, _, _ = self.nstep_buffer[0]
        self.memory.push(
            state,
            action,
            reward,
            next_state,
            done,
            priority=1.0,
        )
        self.nstep_buffer.popleft()

    def _flush_nstep_buffer(self):
        while self.nstep_buffer:
            self._store_nstep()

    def _soft_update(self, target: tf.keras.Model, source: tf.keras.Model, tau: float):
        target_weights = target.get_weights()
        source_weights = source.get_weights()
        new_weights = [tau * sw + (1.0 - tau) * tw for sw, tw in zip(source_weights, target_weights)]
        target.set_weights(new_weights)

    def _hard_update(self, target: tf.keras.Model, source: tf.keras.Model):
        target.set_weights(source.get_weights())

    def train_step(self):
        if self.memory.size < self.batch_size:
            return

        # Update target networks
        if self.target_update >= 1:
            if self.step_counter % int(self.target_update) == 0:
                self._hard_update(self.target_actor, self.actor)
                self._hard_update(self.target_critic, self.critic)
        else:
            self._soft_update(self.target_actor, self.actor, self.target_update)
            self._soft_update(self.target_critic, self.critic, self.target_update)

        batch, indices, _ = self.memory.sample(self.batch_size)
        states, actions, rewards, next_states, dones = batch
        rewards = tf.convert_to_tensor(rewards, dtype=tf.float32)
        dones = tf.cast(dones, tf.float32)

        # Compute target Q
        target_actions = self.target_actor(next_states)
        target_q = self.target_critic([next_states, target_actions])
        target_q = rewards + self.gamma * (1.0 - dones) * target_q
        target_q = tf.stop_gradient(target_q)

        # Critic training
        with tf.GradientTape() as tape:
            current_q = self.critic([states, actions])
            td_error = tf.abs(target_q - current_q)
            critic_loss = tf.reduce_mean(tf.square(target_q - current_q))
        critic_grads = tape.gradient(critic_loss, self.critic.trainable_variables)
        self.critic_optimizer.apply_gradients(zip(critic_grads, self.critic.trainable_variables))

        # Update PER priorities
        new_priorities = tf.squeeze(td_error).numpy() + self.epsilon
        self.memory.update_priorities(indices, new_priorities)

        # Actor training
        with tf.GradientTape() as tape:
            actor_actions = self.actor(states)
            actor_loss = -tf.reduce_mean(self.critic([states, actor_actions]))
        actor_grads = tape.gradient(actor_loss, self.actor.trainable_variables)
        self.actor_optimizer.apply_gradients(zip(actor_grads, self.actor.trainable_variables))

        self.step_counter += 1

    def act(self, state: np.ndarray, training: bool = True) -> np.ndarray:
        state = np.expand_dims(state, axis=0).astype(np.float32)
        action = self.actor(state)
        action = tf.squeeze(action, axis=0).numpy()
        return self.policy(action)

    def save(self, actor_path: str, critic_path: str):
        self.actor.save_weights(actor_path)
        self.critic.save_weights(critic_path)
```