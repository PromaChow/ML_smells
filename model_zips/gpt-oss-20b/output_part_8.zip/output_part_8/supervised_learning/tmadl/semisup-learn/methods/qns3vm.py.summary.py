import numpy as np
import scipy.sparse as sp
import scipy.optimize as opt
from scipy.spatial.distance import cdist


class QN_S3VM:
    def __init__(self,
                 X_l,
                 y_l,
                 X_u,
                 lam=1.0,
                 lamU=1.0,
                 kernel="Linear",
                 sigma=1.0,
                 BFGS_m=10,
                 BFGS_maxfun=150,
                 surrogate_s=1.0,
                 surrogate_gamma=1.0,
                 seed=0):
        self.lam = lam
        self.lamU = lamU
        self.kernel = kernel
        self.sigma = sigma
        self.BFGS_m = BFGS_m
        self.BFGS_maxfun = BFGS_maxfun
        self.surrogate_s = surrogate_s
        self.surrogate_gamma = surrogate_gamma
        self.seed = seed
        np.random.seed(seed)

        if sp.issparse(X_l) or sp.issparse(X_u):
            self.model = QN_S3VM_Sparse(
                X_l, y_l, X_u,
                lam, lamU, kernel, sigma,
                BFGS_m, BFGS_maxfun,
                surrogate_s, surrogate_gamma, seed)
        else:
            self.model = QN_S3VM_Dense(
                X_l, y_l, X_u,
                lam, lamU, kernel, sigma,
                BFGS_m, BFGS_maxfun,
                surrogate_s, surrogate_gamma, seed)

    def train(self):
        self.model.train()

    def predict(self, X):
        return self.model.predict(X)


class QN_S3VM_Dense:
    def __init__(self,
                 X_l,
                 y_l,
                 X_u,
                 lam,
                 lamU,
                 kernel,
                 sigma,
                 BFGS_m,
                 BFGS_maxfun,
                 surrogate_s,
                 surrogate_gamma,
                 seed):
        self.X_l = np.asarray(X_l, dtype=float)
        self.y_l = np.asarray(y_l, dtype=float).reshape(-1)
        self.X_u = np.asarray(X_u, dtype=float)
        self.lam = lam
        self.lamU = lamU
        self.kernel = kernel
        self.sigma = sigma
        self.BFGS_m = BFGS_m
        self.BFGS_maxfun = BFGS_maxfun
        self.surrogate_s = surrogate_s
        self.surrogate_gamma = surrogate_gamma
        self.seed = seed
        self.n_l = self.X_l.shape[0]
        self.n_u = self.X_u.shape[0]
        self.n_samples = self.n_l + self.n_u
        self.c = None
        self.b = None

        # precompute kernels
        self.K_ll = self.compute_kernel(self.X_l, self.X_l)
        self.K_ul = self.compute_kernel(self.X_u, self.X_l)

        # center unlabeled kernel rows
        self.center_kernel()

    def compute_kernel(self, A, B):
        if self.kernel == "Linear":
            return A @ B.T
        elif self.kernel == "RBF":
            d2 = cdist(A, B, 'sqeuclidean')
            return np.exp(-d2 / (2 * self.sigma ** 2))
        else:
            raise ValueError(f"Unknown kernel {self.kernel}")

    def center_kernel(self):
        # approximate mean of unlabeled data in feature space
        mean_u = np.mean(self.K_ul, axis=0, keepdims=True)
        self.K_ul_centered = self.K_ul - mean_u

    def estimate_r(self):
        # simple initial bias estimate: mean of labeled targets
        return np.mean(self.y_l)

    def getFitness(self, vec):
        c = vec[:-1]
        b = vec[-1]
        f_l = self.K_ll @ c + b
        f_u = self.K_ul_centered @ c + b

        loss_l = np.sum(np.log1p(np.exp(-self.surrogate_gamma * self.y_l * f_l)))
        loss_u = np.sum(np.exp(-self.surrogate_s * f_u ** 2))
        reg = self.lam * np.sum(c ** 2)

        return self.lamU * loss_u + loss_l + reg

    def getFitness_Prime(self, vec):
        c = vec[:-1]
        b = vec[-1]
        f_l = self.K_ll @ c + b
        f_u = self.K_ul_centered @ c + b

        # gradients
        dL_l = -self.surrogate_gamma * self.y_l * (1 / (1 + np.exp(self.surrogate_gamma * self.y_l * f_l)))
        dL_u = -2 * self.surrogate_s * f_u * np.exp(-self.surrogate_s * f_u ** 2)

        grad_c = self.K_ll.T @ dL_l + self.K_ul_centered.T @ dL_u + 2 * self.lam * c
        grad_b = np.sum(dL_l + dL_u)

        return np.concatenate([grad_c, [grad_b]])

    def train(self):
        lam_Uvec = np.linspace(1e-4, self.lamU, 5)
        n_params = self.n_l
        init_c = np.zeros(n_params)
        init_b = self.estimate_r()
        init_vec = np.concatenate([init_c, [init_b]])

        for lamU in lam_Uvec:
            self.lamU = lamU
            res = opt.fmin_l_bfgs_b(
                func=self.getFitness,
                x0=init_vec,
                fprime=self.getFitness_Prime,
                maxfun=self.BFGS_maxfun,
                m=self.BFGS_m,
                disp=0)
            init_vec = res[0]
        self.c = init_vec[:-1]
        self.b = init_vec[-1]

    def predict(self, X):
        X = np.asarray(X, dtype=float)
        K = self.compute_kernel(X, self.X_l)
        preds = K @ self.c + self.b
        return np.sign(preds)


class QN_S3VM_Sparse:
    def __init__(self,
                 X_l,
                 y_l,
                 X_u,
                 lam,
                 lamU,
                 kernel,
                 sigma,
                 BFGS_m,
                 BFGS_maxfun,
                 surrogate_s,
                 surrogate_gamma,
                 seed):
        self.X_l = sp.csc_matrix(X_l, dtype=float)
        self.y_l = np.asarray(y_l, dtype=float).reshape(-1)
        self.X_u = sp.csc_matrix(X_u, dtype=float)
        self.lam = lam
        self.lamU = lamU
        self.kernel = kernel
        self.sigma = sigma
        self.BFGS_m = BFGS_m
        self.BFGS_maxfun = BFGS_maxfun
        self.surrogate_s = surrogate_s
        self.surrogate_gamma = surrogate_gamma
        self.seed = seed
        self.n_l = self.X_l.shape[0]
        self.n_u = self.X_u.shape[0]
        self.c = None
        self.b = None

        # precompute kernels
        self.K_ll = self.compute_kernel(self.X_l, self.X_l)
        self.K_ul = self.compute_kernel(self.X_u, self.X_l)

        self.center_kernel()

    def compute_kernel(self, A, B):
        if self.kernel == "Linear":
            return A @ B.T
        else:
            # fall back to linear for sparse
            return A @ B.T

    def center_kernel(self):
        mean_u = np.mean(self.K_ul.toarray(), axis=0, keepdims=True)
        self.K_ul_centered = self.K_ul - sp.csc_matrix(mean_u)

    def estimate_r(self):
        return np.mean(self.y_l)

    def getFitness(self, vec):
        c = vec[:-1]
        b = vec[-1]
        f_l = self.K_ll @ c + b
        f_u = self.K_ul_centered @ c + b

        loss_l = np.sum(np.log1p(np.exp(-self.surrogate_gamma * self.y_l * f_l)))
        loss_u = np.sum(np.exp(-self.surrogate_s * f_u ** 2))
        reg = self.lam * np.sum(c ** 2)

        return self.lamU * loss_u + loss_l + reg

    def getFitness_Prime(self, vec):
        c = vec[:-1]
        b = vec[-1]
        f_l = self.K_ll @ c + b
        f_u = self.K_ul_centered @ c + b

        dL_l = -self.surrogate_gamma * self.y_l * (1 / (1 + np.exp(self.surrogate_gamma * self.y_l * f_l)))
        dL_u = -2 * self.surrogate_s * f_u * np.exp(-self.surrogate_s * f_u ** 2)

        grad_c = self.K_ll.T @ dL_l + self.K_ul_centered.T @ dL_u + 2 * self.lam * c
        grad_b = np.sum(dL_l + dL_u)

        return np.concatenate([grad_c, [grad_b]])

    def train(self):
        lam_Uvec = np.linspace(1e-4, self.lamU, 5)
        n_params = self.n_l
        init_c = np.zeros(n_params)
        init_b = self.estimate_r()
        init_vec = np.concatenate([init_c, [init_b]])

        for lamU in lam_Uvec:
            self.lamU = lamU
            res = opt.fmin_l_bfgs_b(
                func=self.getFitness,
                x0=init_vec,
                fprime=self.getFitness_Prime,
                maxfun=self.BFGS_maxfun,
                m=self.BFGS_m,
                disp=0)
            init_vec = res[0]
        self.c = init_vec[:-1]
        self.b = init_vec[-1]

    def predict(self, X):
        X = sp.csc_matrix(X, dtype=float)
        K = self.compute_kernel(X, self.X_l)
        preds = K @ self.c + self.b
        return np.sign(preds.toarray().ravel())
