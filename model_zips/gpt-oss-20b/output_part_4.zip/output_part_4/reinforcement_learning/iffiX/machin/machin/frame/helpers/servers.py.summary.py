import torch
import torch.distributed as dist
import torch.distributed.rpc as rpc
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple, Union

# --------------------------------------------------------------------------- #
# Placeholder distributed world utilities
# --------------------------------------------------------------------------- #
def get_world() -> List[str]:
    """
    Return the list of worker names in the current distributed world.
    In a real environment this would query the RPC framework.
    """
    size = dist.get_world_size()
    return [f'worker_{i}' for i in range(size)]

# --------------------------------------------------------------------------- #
# Simplified RPCGroup for local testing
# --------------------------------------------------------------------------- #
class RPCGroup:
    def __init__(self, name: str, members: List[str]):
        self.name = name
        self.members = members

    def barrier(self) -> None:
        # In real usage this would synchronize all workers.
        pass

    def get_server(self, name: str) -> Any:
        # Return a lightweight accessor placeholder.
        return f'ServerAccessor({name})'

# --------------------------------------------------------------------------- #
# Server implementation stubs
# --------------------------------------------------------------------------- #
class PushPullGradServerImpl:
    def __init__(self, name: str):
        self.name = name

    def manage_model(self, model: torch.nn.Module, optimizer: torch.optim.Optimizer,
                     scheduler: Optional[torch.optim.lr_scheduler._LRScheduler] = None) -> None:
        # In a real system this would register the model and optimizer.
        pass

    def start(self) -> None:
        # Start server logic (e.g., listening for RPCs).
        pass

class PushPullModelServerImpl:
    def __init__(self, name: str):
        self.name = name

    def start(self) -> None:
        pass

# --------------------------------------------------------------------------- #
# Helper functions
# --------------------------------------------------------------------------- #
def grad_server_helper(
    group_name: str,
    model_creators: List[Callable[[], torch.nn.Module]],
    members: Optional[List[str]] = None,
    learning_rate: Union[float, List[float]] = 0.001,
    optimizer_kwargs: Optional[Dict[str, Any]] = None,
    lr_scheduler_args: Optional[Dict[str, Any]] = None,
    lr_scheduler_kwargs: Optional[Dict[str, Any]] = None,
) -> Tuple[Any, ...]:
    world = get_world()
    if members is None:
        members = world

    server_group = RPCGroup(group_name, members)

    # Expand learning_rate to list
    lr_list = (
        [learning_rate] if not isinstance(learning_rate, (list, tuple))
        else list(learning_rate)
    )
    if len(lr_list) != len(model_creators):
        lr_list = [learning_rate] * len(model_creators)

    opt_kwargs_list = (
        [optimizer_kwargs] * len(model_creators) if optimizer_kwargs
        else [{} for _ in model_creators]
    )
    sched_args_list = (
        [lr_scheduler_args] * len(model_creators) if lr_scheduler_args
        else [{} for _ in model_creators]
    )
    sched_kwargs_list = (
        [lr_scheduler_kwargs] * len(model_creators) if lr_scheduler_kwargs
        else [{} for _ in model_creators]
    )

    servers = []
    for idx, _ in enumerate(model_creators):
        name = f"{group_name}_grad_server_{idx}"
        servers.append(PushPullGradServerImpl(name))

    primary_member = members[0]
    if rpc.get_worker_name() == primary_member:
        for idx, (creator, opt_kwargs, lr, sched_args, sched_kwargs) in enumerate(
            zip(model_creators, opt_kwargs_list, lr_list, sched_args_list, sched_kwargs_list)
        ):
            model = creator()
            optimizer = torch.optim.Adam(model.parameters(), lr=lr, **opt_kwargs)
            scheduler = None
            if lr_scheduler_args or lr_scheduler_kwargs:
                scheduler = torch.optim.lr_scheduler.StepLR(
                    optimizer, **sched_args, **sched_kwargs
                )
            servers[idx].manage_model(model, optimizer, scheduler)
            servers[idx].start()

    server_group.barrier()

    accessors = tuple(server_group.get_server(s.name) for s in servers)
    return accessors


def model_server_helper(
    group_name: str,
    model_num: int,
    members: Optional[List[str]] = None,
) -> Tuple[Any, ...]:
    world = get_world()
    if members is None:
        members = world

    server_group = RPCGroup(group_name, members)

    servers = []
    if rpc.get_worker_name() == members[0]:
        for idx in range(model_num):
            name = f"{group_name}_model_server_{idx}"
            servers.append(PushPullModelServerImpl(name))
            servers[-1].start()

    server_group.barrier()

    accessors = tuple(server_group.get_server(s.name) for s in servers)
    return accessors
