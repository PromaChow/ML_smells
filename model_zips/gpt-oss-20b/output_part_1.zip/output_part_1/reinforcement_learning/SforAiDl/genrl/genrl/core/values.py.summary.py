import torch
import torch.nn as nn
import torch.nn.functional as F
import math


# ----- Basic building blocks -----
def mlp(input_dim, layer_dims, activation="relu"):
    layers = []
    prev_dim = input_dim
    act = getattr(F, activation) if activation in dir(F) else nn.ReLU()
    for dim in layer_dims:
        layers.append(nn.Linear(prev_dim, dim))
        layers.append(act)
        prev_dim = dim
    return nn.Sequential(*layers)


class ConvNet(nn.Module):
    def __init__(self, input_shape):
        super().__init__()
        c, h, w = input_shape
        self.conv = nn.Sequential(
            nn.Conv2d(c, 32, kernel_size=3, stride=2, padding=1),
            nn.ReLU(),
            nn.Conv2d(32, 64, kernel_size=3, stride=2, padding=1),
            nn.ReLU(),
            nn.Conv2d(64, 128, kernel_size=3, stride=2, padding=1),
            nn.ReLU(),
        )
        dummy = torch.zeros(1, *input_shape)
        out = self.conv(dummy)
        self.output_size = int(math.prod(out.shape[1:]))

    def forward(self, x):
        return self.conv(x).view(x.size(0), -1)


def cnn(input_shape):
    return ConvNet(input_shape)


# ----- Noisy Linear Layer -----
class NoisyLinear(nn.Module):
    def __init__(self, in_features, out_features, sigma_init=0.017):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight_mu = nn.Parameter(torch.empty(out_features, in_features))
        self.weight_sigma = nn.Parameter(torch.empty(out_features, in_features))
        self.bias_mu = nn.Parameter(torch.empty(out_features))
        self.bias_sigma = nn.Parameter(torch.empty(out_features))
        self.register_buffer("weight_eps", torch.empty(out_features, in_features))
        self.register_buffer("bias_eps", torch.empty(out_features))
        self.sigma_init = sigma_init
        self.reset_parameters()
        self.reset_noise()

    def reset_parameters(self):
        mu_range = 1 / math.sqrt(self.in_features)
        nn.init.uniform_(self.weight_mu, -mu_range, mu_range)
        nn.init.uniform_(self.bias_mu, -mu_range, mu_range)
        nn.init.constant_(self.weight_sigma, self.sigma_init)
        nn.init.constant_(self.bias_sigma, self.sigma_init)

    def reset_noise(self):
        eps_in = self._scale_noise(self.in_features)
        eps_out = self._scale_noise(self.out_features)
        self.weight_eps.copy_(torch.ger(eps_out, eps_in))
        self.bias_eps.copy_(eps_out)

    @staticmethod
    def _scale_noise(size):
        x = torch.randn(size)
        return x.sign().mul_(x.abs().sqrt_())

    def forward(self, input):
        weight = self.weight_mu + self.weight_sigma * self.weight_eps
        bias = self.bias_mu + self.bias_sigma * self.bias_eps
        return F.linear(input, weight, bias)


def noisy_mlp(input_dim, layer_dims, activation="relu"):
    layers = []
    prev_dim = input_dim
    act = getattr(F, activation) if activation in dir(F) else nn.ReLU()
    for dim in layer_dims:
        layers.append(NoisyLinear(prev_dim, dim))
        layers.append(act)
        prev_dim = dim
    return nn.Sequential(*layers)


# ----- Helper function to get value model -----
def _get_val_model(arch, val_type, state_dim, fc_layers, action_dim, activation="relu"):
    if arch == "mlp":
        if val_type == "V":
            return mlp(state_dim, fc_layers + [1], activation)
        if val_type == "Qsa":
            return mlp(state_dim + action_dim, fc_layers + [1], activation)
        if val_type == "Qs":
            return mlp(state_dim, fc_layers + [action_dim], activation)
    elif arch == "cnn":
        # placeholder: cnn will be handled separately
        pass
    raise ValueError(f"Unsupported architecture {arch} or val_type {val_type}")


# ----- Base Value Functions -----
class MlpValue(nn.Module):
    def __init__(self, state_dim, action_dim, val_type, fc_layers, activation="relu"):
        super().__init__()
        self.model = _get_val_model(
            arch="mlp",
            val_type=val_type,
            state_dim=state_dim,
            fc_layers=fc_layers,
            action_dim=action_dim,
            activation=activation,
        )

    def forward(self, state):
        return self.model(state)


class CnnValue(nn.Module):
    def __init__(self, state_dim, action_dim, val_type, fc_layers, activation="relu"):
        super().__init__()
        # Assume state_dim corresponds to channels
        self.cnn = cnn((state_dim, 16, 32))
        out_size = self.cnn.output_size
        mlp_input = out_size
        if val_type == "V":
            mlp_input = out_size
            final_layer = [1]
        elif val_type == "Qsa":
            mlp_input = out_size + action_dim
            final_layer = [1]
        elif val_type == "Qs":
            mlp_input = out_size
            final_layer = [action_dim]
        else:
            raise ValueError(f"Unsupported val_type {val_type}")
        self.model = mlp(mlp_input, fc_layers + final_layer, activation)

    def _cnn_forward(self, state):
        # state shape: (batch, channels, 16, 32)
        x = self.cnn(state)
        return x

    def forward(self, state):
        x = self._cnn_forward(state)
        return self.model(x)


# ----- Dueling Value Functions -----
class MlpDuelingValue(nn.Module):
    def __init__(self, state_dim, action_dim, val_type, fc_layers, activation="relu"):
        super().__init__()
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.val_type = val_type
        # Shared feature extractor
        self.feature = mlp(state_dim, fc_layers, activation)
        # Advantage branch
        self.advantage = mlp(state_dim, fc_layers + [action_dim], activation)
        # Value branch
        self.value = mlp(state_dim, fc_layers + [1], activation)

    def forward(self, state):
        feat = self.feature(state)
        adv = self.advantage(state)
        val = self.value(state)
        if self.val_type == "Qs":
            return val + adv - adv.mean(dim=1, keepdim=True)
        elif self.val_type == "Qsa":
            return val + adv - adv.mean(dim=1, keepdim=True)
        elif self.val_type == "V":
            return val
        else:
            raise ValueError(f"Unsupported val_type {self.val_type}")


class CnnDuelingValue(nn.Module):
    def __init__(self, state_dim, action_dim, val_type, fc_layers, activation="relu"):
        super().__init__()
        self.cnn = cnn((state_dim, 16, 32))
        out_size = self.cnn.output_size
        # Advantage and value branches
        self.advantage = mlp(out_size, fc_layers + [action_dim], activation)
        self.value = mlp(out_size, fc_layers + [1], activation)
        self.val_type = val_type

    def _cnn_forward(self, state):
        return self.cnn(state)

    def forward(self, state):
        x = self._cnn_forward(state)
        adv = self.advantage(x)
        val = self.value(x)
        if self.val_type == "Qs":
            return val + adv - adv.mean(dim=1, keepdim=True)
        elif self.val_type == "Qsa":
            return val + adv - adv.mean(dim=1, keepdim=True)
        elif self.val_type == "V":
            return val
        else:
            raise ValueError(f"Unsupported val_type {self.val_type}")


# ----- Noisy Value Functions -----
class MlpNoisyValue(nn.Module):
    def __init__(self, state_dim, action_dim, val_type, fc_layers, noisy_layers=(128, 512), num_atoms=1, activation="relu"):
        super().__init__()
        self.noisy_layers = noisy_layers
        self.num_atoms = num_atoms
        output_dim = action_dim * num_atoms
        self.model = noisy_mlp(state_dim, noisy_layers + [output_dim], activation)

    def reset_noise(self):
        for m in self.modules():
            if isinstance(m, NoisyLinear):
                m.reset_noise()

    def forward(self, state):
        return self.model(state)


class CnnNoisyValue(CnnValue, MlpNoisyValue):
    def __init__(self, state_dim, action_dim, val_type, fc_layers, noisy_layers=(128, 512), num_atoms=1, activation="relu"):
        CnnValue.__init__(self, state_dim, action_dim, val_type, fc_layers, activation)
        MlpNoisyValue.__init__(self, state_dim, action_dim, val_type, fc_layers, noisy_layers, num_atoms, activation)

    def forward(self, state):
        x = self._cnn_forward(state)
        return self.model(x)

    def reset_noise(self):
        for m in self.modules():
            if isinstance(m, NoisyLinear):
                m.reset_noise()


# ----- Categorical Value Functions -----
class MlpCategoricalValue(MlpNoisyValue):
    def __init__(self, state_dim, action_dim, val_type, fc_layers, noisy_layers=(128, 512), num_atoms=51, activation="relu"):
        super().__init__(state_dim, action_dim, val_type, fc_layers, noisy_layers, num_atoms, activation)

    def forward(self, state):
        logits = self.model(state)
        batch, _, _ = logits.shape
        logits = logits.view(batch, -1, self.action_dim, self.num_atoms)
        return F.softmax(logits, dim=-1)


class CnnCategoricalValue(CnnNoisyValue):
    def __init__(self, state_dim, action_dim, val_type, fc_layers, noisy_layers=(128, 512), num_atoms=51, activation="relu"):
        super().__init__(state_dim, action_dim, val_type, fc_layers, noisy_layers, num_atoms, activation)

    def forward(self, state):
        logits = self.model(state)
        batch, _, _ = logits.shape
        logits = logits.view(batch, -1, self.action_dim, self.num_atoms)
        return F.softmax(logits, dim=-1)


# ----- Registry -----
value_registry = {
    "mlp": MlpValue,
    "cnn": CnnValue,
    "mlpdueling": MlpDuelingValue,
    "cnn_dueling": CnnDuelingValue,
    "mlpnoisy": MlpNoisyValue,
    "cnnnoisy": CnnNoisyValue,
    "mlpcategorical": MlpCategoricalValue,
    "cnncategorical": CnnCategoricalValue,
}


# ----- Helper to retrieve class -----
def get_value_from_name(name_):
    if name_ in value_registry:
        return value_registry[name_]
    raise NotImplementedError(f"Value function '{name_}' is not registered.")
