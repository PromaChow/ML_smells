import numpy as np
import scipy
import scipy.sparse as sp
import scipy.optimize
import warnings
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def _check_positive(name, val):
    if val <= 0:
        raise ValueError(f"{name} must be positive, got {val}")

def _compute_kernel_dense(X, Y, kernel_type='RBF', sigma=1.0):
    if kernel_type == 'Linear':
        return X @ Y.T
    elif kernel_type == 'RBF':
        X_norm = np.sum(X**2, axis=1).reshape(-1, 1)
        Y_norm = np.sum(Y**2, axis=1).reshape(1, -1)
        sq_dist = X_norm - 2 * (X @ Y.T) + Y_norm
        return np.exp(-sq_dist / (2 * sigma**2))
    else:
        raise ValueError(f"Unsupported kernel type: {kernel_type}")

def _compute_kernel_sparse(X, Y, kernel_type='RBF', sigma=1.0):
    if kernel_type == 'Linear':
        return X @ Y.T
    elif kernel_type == 'RBF':
        X_sq = X.multiply(X).sum(axis=1).A1
        Y_sq = Y.multiply(Y).sum(axis=1).A1
        cross = X @ Y.T
        sq_dist = X_sq[:, None] - 2 * cross.toarray() + Y_sq[None, :]
        return sp.csr_matrix(np.exp(-sq_dist / (2 * sigma**2)))
    else:
        raise ValueError(f"Unsupported kernel type: {kernel_type}")

def _center_kernel(K):
    n = K.shape[0]
    one_n = np.ones((n, 1)) / n
    K_centered = K - one_n @ K - K @ one_n + one_n @ K @ one_n
    return K_centered

class QNS3VMBase:
    def __init__(self,
                 X_l,
                 y_l,
                 X_u,
                 lam=1.0,
                 lamU=1.0,
                 kernel_type='RBF',
                 sigma=1.0,
                 BFGS_m=10,
                 BFGS_maxfun=1000,
                 BFGS_factr=1e7,
                 BFGS_pgtol=1e-5,
                 estimate_r=None,
                 lam_Uvec=None,
                 surrogate_gamma=1.0,
                 random_state=None):
        self.X_l = X_l
        self.y_l = y_l
        self.X_u = X_u
        self.lam = lam
        self.lamU = lamU
        self.kernel_type = kernel_type
        self.sigma = sigma
        self.BFGS_m = BFGS_m
        self.BFGS_maxfun = BFGS_maxfun
        self.BFGS_factr = BFGS_factr
        self.BFGS_pgtol = BFGS_pgtol
        self.estimate_r = estimate_r
        self.lam_Uvec = lam_Uvec
        self.surrogate_gamma = surrogate_gamma
        self.random_state = random_state
        self.c = None
        self.b = None
        self.KLR = None
        self.KUR = None
        self.KRR = None
        self.KLRR = None
        self._validate_parameters()
        self._prepare_data()

    def _validate_parameters(self):
        _check_positive('lam', self.lam)
        _check_positive('lamU', self.lamU)
        _check_positive('sigma', self.sigma)
        _check_positive('BFGS_m', self.BFGS_m)
        _check_positive('BFGS_maxfun', self.BFGS_maxfun)

    def _prepare_data(self):
        if sp.issparse(self.X_l) and sp.issparse(self.X_u):
            self.data_type = 'sparse'
        elif not sp.issparse(self.X_l) and not sp.issparse(self.X_u):
            self.data_type = 'dense'
        else:
            raise ValueError("Both labeled and unlabeled data must be of the same type (dense or sparse).")
        if self.estimate_r is None:
            pos = np.sum(self.y_l == 1)
            neg = np.sum(self.y_l == -1)
            self.estimate_r = pos / (pos + neg)
        if self.lam_Uvec is None:
            self.lam_Uvec = np.linspace(self.lamU * 0.1, self.lamU, 5)

    def _compute_kernel_matrices(self):
        if self.data_type == 'dense':
            self.KLR = _compute_kernel_dense(self.X_l, self.X_u, self.kernel_type, self.sigma)
            self.KUR = _compute_kernel_dense(self.X_u, self.X_u, self.kernel_type, self.sigma)
            self.KRR = self.KUR.copy()
        else:
            self.KLR = _compute_kernel_sparse(self.X_l, self.X_u, self.kernel_type, self.sigma)
            self.KUR = _compute_kernel_sparse(self.X_u, self.X_u, self.kernel_type, self.sigma)
            self.KRR = self.KUR.copy()

        # Centering
        if self.data_type == 'dense':
            self.KRR = _center_kernel(self.KRR)
            self.KLR = self.KLR - np.mean(self.KRR, axis=0)
            self.KUR = _center_kernel(self.KUR)
        else:
            self.KRR = _center_kernel(self.KRR.toarray())
            self.KRR = sp.csr_matrix(self.KRR)
            self.KLR = self.KLR - np.mean(self.KRR, axis=0)
            self.KUR = _center_kernel(self.KUR.toarray())
            self.KUR = sp.csr_matrix(self.KUR)

    def _fitness(self, params, lamU_current):
        c = params[:-1]
        b = params[-1]
        # labeled predictions
        if self.data_type == 'dense':
            y_hat_l = (self.KLR @ c) + b
        else:
            y_hat_l = (self.KLR @ c) + b
        # unlabeled predictions
        if self.data_type == 'dense':
            y_hat_u = (self.KUR @ c) + b
        else:
            y_hat_u = (self.KUR @ c) + b

        # surrogate loss for labeled
        loss_l = self.surrogate_gamma * np.mean(np.log1p(np.exp(-self.y_l * y_hat_l)))
        grad_l = -self.surrogate_gamma * ((self.y_l * np.exp(-self.y_l * y_hat_l)) / (1 + np.exp(-self.y_l * y_hat_l)))[:, None] * self.KLR

        # regularization
        loss_reg = self.lam * np.sum(c ** 2)
        grad_reg = 2 * self.lam * c

        # unlabeled surrogate
        loss_u = lamU_current * np.mean(np.exp(-y_hat_u ** 2))
        grad_u = -2 * lamU_current * ((y_hat_u ** 2) * np.exp(-y_hat_u ** 2))[:, None] * self.KUR

        loss = loss_l + loss_reg + loss_u
        grad_c = np.mean(grad_l, axis=0) + grad_reg + np.mean(grad_u, axis=0)
        grad_b = np.mean(grad_l) + np.mean(grad_u)

        grad = np.hstack([grad_c, grad_b])
        return loss, grad

    def fit(self):
        self._compute_kernel_matrices()
        n_reg = self.X_u.shape[0]
        init_c = np.zeros(n_reg)
        init_b = 0.0
        init_params = np.hstack([init_c, init_b])
        for lamU_current in self.lam_Uvec:
            logger.info(f"Optimizing with lamU={lamU_current}")
            res = scipy.optimize.fmin_l_bfgs_b(
                lambda p: self._fitness(p, lamU_current),
                init_params,
                m=self.BFGS_m,
                maxfun=self.BFGS_maxfun,
                factr=self.BFGS_factr,
                pgtol=self.BFGS_pgtol,
                iprint=1
            )
            init_params = res[0]
        self.c = init_params[:-1]
        self.b = init_params[-1]
        return self

    def predict(self, X):
        if sp.issparse(X):
            Kx = _compute_kernel_sparse(X, self.X_u, self.kernel_type, self.sigma)
        else:
            Kx = _compute_kernel_dense(X, self.X_u, self.kernel_type, self.sigma)
        if self.data_type == 'dense':
            preds = Kx @ self.c + self.b
        else:
            preds = Kx @ self.c + self.b
        return np.sign(preds)

    def score(self, X, y):
        return np.mean(self.predict(X) == y)


class QNS3VMDense(QNS3VMBase):
    pass


class QNS3VMSparse(QNS3VMBase):
    pass


class QNS3VM:
    def __init__(self, *args, **kwargs):
        dense = not sp.issparse(args[0]) and not sp.issparse(args[2])
        if dense:
            self.model = QNS3VMDense(*args, **kwargs)
        else:
            self.model = QNS3VMSparse(*args, **kwargs)

    def fit(self):
        return self.model.fit()

    def predict(self, X):
        return self.model.predict(X)

    def score(self, X, y):
        return self.model.score(X, y)


# Example usage (commented):
# from sklearn.datasets import make_moons
# X, y = make_moons(n_samples=200, noise=0.2, random_state=42)
# y = np.where(y == 0, -1, 1)
# X_l, X_u = X[:50], X[50:]
# y_l = y[:50]
# model = QNS3VM(X_l, y_l, X_u, lam=1.0, lamU=1.0, kernel_type='RBF', sigma=1.0)
# model.fit()
# print("Training accuracy:", model.score(X_l, y_l))
# print("Test accuracy:", model.score(X_u, y[50:]))
# preds = model.predict(X_u)
# print("Predictions:", preds)