import torch
import torch.nn as nn
import torchvision.transforms as T
from PIL import Image, ImageOps
import aug_pool


class ReduceChannelwithNormalize(nn.Module):
    """
    Processes RGBA images by reducing the alpha channel and normalizing RGB values.
    """

    def __init__(self, mean, scale, zca=True):
        super().__init__()
        self.mean = torch.tensor(mean, dtype=torch.float32)
        self.scale = torch.tensor(scale, dtype=torch.float32)
        self.zca = zca

    def forward(self, img: torch.Tensor) -> torch.Tensor:
        """
        Args:
            img: Tensor of shape (4, H, W) or (3, H, W). If 3 channels, return unchanged.
        Returns:
            Tensor of shape (3, H, W)
        """
        if img.shape[0] == 3:
            rgb = img
        else:
            rgb = img[:3]
            alpha = img[3]

            zero_alpha_mask = alpha == 0
            if self.zca:
                rgb = aug_pool.GCN(rgb)
                rgb = aug_pool.ZCA(rgb, mean=self.mean, scale=self.scale)
            else:
                rgb = (rgb - self.mean[None, :, None, None]) / self.scale[None, :, None, None]

            rgb[zero_alpha_mask] = 0

        return rgb


class RGB2RGBA(nn.Module):
    """
    Converts an image from RGB to RGBA format using PIL.
    """

    def forward(self, img: Image.Image) -> Image.Image:
        return img.convert("RGBA")


class RandomCropWithPadding(nn.Module):
    """
    Random crop with padding equal to 12.5% of the smaller image dimension.
    """

    def __init__(self, size):
        super().__init__()
        self.size = size

    def forward(self, img: Image.Image) -> Image.Image:
        w, h = img.size
        padding = int(round(0.125 * min(w, h)))
        img = ImageOps.expand(img, border=padding, fill=0)
        return T.RandomCrop(self.size)(img)


class StrongAugmentation(nn.Module):
    """
    Applies strong data augmentation for training.
    """

    def __init__(
        self,
        img_size,
        mean,
        scale,
        flip=True,
        crop=True,
        alg="fixmatch",
        zca=True,
        cutout=True,
    ):
        super().__init__()
        self.mean = mean
        self.scale = scale
        self.zca = zca
        self.cutout = cutout

        transform_list = [T.ToPILImage()]

        if flip:
            transform_list.append(T.RandomHorizontalFlip(p=0.5))

        if crop:
            transform_list.append(RandomCropWithPadding(img_size))

        transform_list.append(RGB2RGBA())
        transform_list.append(aug_pool.RandAugment(alg))
        transform_list.append(T.ToTensor())
        transform_list.append(
            ReduceChannelwithNormalize(mean=mean, scale=scale, zca=zca)
        )

        if cutout:
            transform_list.append(aug_pool.TorchCutout(patch_size=16))

        self.transform = nn.Sequential(*transform_list)

    def forward(self, img):
        return self.transform(img)


class WeakAugmentation(nn.Module):
    """
    Applies minimal data augmentation.
    """

    def __init__(
        self,
        img_size,
        mean,
        scale,
        flip=True,
        crop=True,
        noise=False,
        zca=True,
    ):
        super().__init__()
        self.mean = mean
        self.scale = scale
        self.zca = zca

        transform_list = [T.ToPILImage()]

        if flip:
            transform_list.append(T.RandomHorizontalFlip(p=0.5))

        if crop:
            transform_list.append(RandomCropWithPadding(img_size))

        transform_list.append(T.ToTensor())

        if zca:
            transform_list.append(aug_pool.GCN())
            transform_list.append(
                lambda x: aug_pool.ZCA(x, mean=mean, scale=scale)
            )
        else:
            transform_list.append(
                lambda x: (x - torch.tensor(mean, dtype=torch.float32)[None, :, None, None])
                / torch.tensor(scale, dtype=torch.float32)[None, :, None, None]
            )

        if noise:
            transform_list.append(aug_pool.GaussianNoise())

        self.transform = nn.Sequential(*transform_list)

    def forward(self, img):
        return self.transform(img)