import torch
import torch.nn as nn
import torch.optim as optim
import gym
import numpy as np
from sklearn.preprocessing import StandardScaler
from pyvirtualdisplay import Display

# Virtual display for Colab
display = Display(visible=0, size=(800, 600))
display.start()

# Constants
NUM_RAND_TRAJECTORIES = 5
AGGR_ITER = 10
STEPS_PER_AGGR = 200
BATCH_SIZE = 64
TRAIN_ITER_MODEL = 500
ENV_LEARNING_RATE = 1e-3
REW_LEARNING_RATE = 1e-3
NUM_SEQUENCES = 100
HORIZON_LENGTH = 15
NOISE_STD = 0.001
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


class NNDynamicModel(nn.Module):
    def __init__(self, state_dim, action_dim, output_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim + action_dim, 256),
            nn.ReLU(),
            nn.Linear(256, 256),
            nn.ReLU(),
            nn.Linear(256, output_dim)
        )

    def forward(self, state, action):
        x = torch.cat([state, action], dim=-1)
        return self.net(x)


class NNRewardModel(nn.Module):
    def __init__(self, state_dim, action_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim + action_dim, 256),
            nn.ReLU(),
            nn.Linear(256, 256),
            nn.ReLU(),
            nn.Linear(256, 1)
        )

    def forward(self, state, action):
        x = torch.cat([state, action], dim=-1)
        return self.net(x)


def gather_random_trajectories(env, num_trajectories):
    data = {
        'observations': [],
        'actions': [],
        'rewards': [],
        'next_observations': []
    }
    for _ in range(num_trajectories):
        obs = env.reset()
        done = False
        while not done:
            action = env.action_space.sample()
            next_obs, reward, done, _ = env.step(action)
            data['observations'].append(obs)
            data['actions'].append(action)
            data['rewards'].append(reward)
            data['next_observations'].append(next_obs)
            obs = next_obs
    for key in data:
        data[key] = np.array(data[key])
    return data


def train_dyna_model(env, dyn_model, rew_model,
                     scaler_in, scaler_out_state, scaler_out_reward,
                     data):
    observations = data['observations']
    actions = data['actions']
    rewards = data['rewards']
    next_obs = data['next_observations']

    X = np.concatenate([observations, actions], axis=-1)
    y_state = next_obs
    y_reward = rewards.reshape(-1, 1)

    # Fit scalers
    scaler_in.fit(X)
    scaler_out_state.fit(y_state)
    scaler_out_reward.fit(y_reward)

    X_std = scaler_in.transform(X)
    y_state_std = scaler_out_state.transform(y_state)
    y_reward_std = scaler_out_reward.transform(y_reward)

    # Combine state and reward targets for joint training
    y_combined_std = np.concatenate([y_state_std, y_reward_std], axis=-1)

    dataset = torch.utils.data.TensorDataset(
        torch.tensor(X_std, dtype=torch.float32),
        torch.tensor(y_combined_std, dtype=torch.float32)
    )
    loader = torch.utils.data.DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True)

    # Separate optimizers
    opt_dyn = optim.Adam(dyn_model.parameters(), lr=ENV_LEARNING_RATE)
    opt_rew = optim.Adam(rew_model.parameters(), lr=REW_LEARNING_RATE)

    criterion = nn.MSELoss()

    # Train loop
    for it in range(1, TRAIN_ITER_MODEL + 1):
        for xb, yb in loader:
            xb = xb.to(DEVICE) + torch.randn_like(xb) * NOISE_STD
            yb = yb.to(DEVICE)

            # Split targets
            y_state_target = yb[:, :dyn_model.net[-1].out_features]
            y_reward_target = yb[:, dyn_model.net[-1].out_features:]

            # Forward for dynamic
            state_in = xb[:, :env.observation_space.shape[0]]
            action_in = xb[:, env.observation_space.shape[0]:]
            pred_state = dyn_model(state_in, action_in)

            # Forward for reward
            pred_reward = rew_model(state_in, action_in)

            loss_state = criterion(pred_state, y_state_target)
            loss_reward = criterion(pred_reward, y_reward_target)
            loss = loss_state + loss_reward

            opt_dyn.zero_grad()
            opt_rew.zero_grad()
            loss.backward()
            opt_dyn.step()
            opt_rew.step()

        if it % 10 == 0:
            # Validation loss
            val_X = torch.tensor(X_std, dtype=torch.float32).to(DEVICE)
            val_y = torch.tensor(y_combined_std, dtype=torch.float32).to(DEVICE)
            with torch.no_grad():
                state_in = val_X[:, :env.observation_space.shape[0]]
                action_in = val_X[:, env.observation_space.shape[0]:]
                val_pred_state = dyn_model(state_in, action_in)
                val_pred_reward = rew_model(state_in, action_in)
                val_loss_state = criterion(val_pred_state, val_y[:, :dyn_model.net[-1].out_features])
                val_loss_reward = criterion(val_pred_reward, val_y[:, dyn_model.net[-1].out_features:])
                print(f'Iter {it} Val State Loss: {val_loss_state.item():.4f} Val Reward Loss: {val_loss_reward.item():.4f}')
    return scaler_in, scaler_out_state, scaler_out_reward


def multi_model_based_control(dyn_model, rew_model,
                              curr_state, env,
                              num_sequences, horizon,
                              action_space):
    best_reward = -np.inf
    best_first_action = None
    action_dim = env.action_space.shape[0]
    low = env.action_space.low
    high = env.action_space.high

    for _ in range(num_sequences):
        state = curr_state.copy()
        total_reward = 0.0
        for _ in range(horizon):
            action = np.random.uniform(low, high, size=action_dim)
            state_tensor = torch.tensor(state, dtype=torch.float32, device=DEVICE).unsqueeze(0)
            action_tensor = torch.tensor(action, dtype=torch.float32, device=DEVICE).unsqueeze(0)
            with torch.no_grad():
                pred_next_std = dyn_model(state_tensor, action_tensor)
                pred_reward_std = rew_model(state_tensor, action_tensor)
            # Inverse transform
            pred_next = pred_next_std.cpu().numpy().squeeze()
            pred_reward = pred_reward_std.cpu().numpy().squeeze()
            total_reward += pred_reward
            state = pred_next
        if total_reward > best_reward:
            best_reward = total_reward
            best_first_action = action
    return best_first_action


def main():
    env = gym.make('RoboschoolAnt-v1')
    obs_dim = env.observation_space.shape[0]
    act_dim = env.action_space.shape[0]

    dyn_model = NNDynamicModel(obs_dim, act_dim, obs_dim).to(DEVICE)
    rew_model = NNRewardModel(obs_dim, act_dim).to(DEVICE)

    # Initial data
    random_data = gather_random_trajectories(env, NUM_RAND_TRAJECTORIES)
    rl_data = {
        'observations': np.empty((0, obs_dim)),
        'actions': np.empty((0, act_dim)),
        'rewards': np.empty((0,)),
        'next_observations': np.empty((0, obs_dim))
    }

    scaler_in = StandardScaler()
    scaler_out_state = StandardScaler()
    scaler_out_reward = StandardScaler()

    total_steps = 0
    episode_reward = 0.0
    obs = env.reset()

    for aggr in range(AGGR_ITER):
        # Combine datasets
        combined_data = {
            'observations': np.concatenate([random_data['observations'], rl_data['observations']]),
            'actions': np.concatenate([random_data['actions'], rl_data['actions']]),
            'rewards': np.concatenate([random_data['rewards'], rl_data['rewards']]),
            'next_observations': np.concatenate([random_data['next_observations'], rl_data['next_observations']])
        }

        # Train models
        scaler_in, scaler_out_state, scaler_out_reward = train_dyna_model(
            env, dyn_model, rew_model,
            scaler_in, scaler_out_state, scaler_out_reward,
            combined_data
        )

        # Interact with environment
        steps_this_iter = 0
        while steps_this_iter < STEPS_PER_AGGR:
            action = multi_model_based_control(
                dyn_model, rew_model, obs, env,
                NUM_SEQUENCES, HORIZON_LENGTH, env.action_space
            )
            next_obs, reward, done, _ = env.step(action)
            # Append to RL dataset
            rl_data['observations'] = np.vstack([rl_data['observations'], obs])
            rl_data['actions'] = np.vstack([rl_data['actions'], action])
            rl_data['rewards'] = np.hstack([rl_data['rewards'], reward])
            rl_data['next_observations'] = np.vstack([rl_data['next_observations'], next_obs])

            obs = next_obs
            episode_reward += reward
            steps_this_iter += 1
            total_steps += 1

            if done:
                print(f'Episode finished. Total steps: {total_steps}, Episode reward: {episode_reward:.2f}')
                obs = env.reset()
                episode_reward = 0.0

    env.close()


if __name__ == '__main__':
    main()
