import tensorflow as tf
import numpy as np
import random

class Symmetry:
    @staticmethod
    def apply_symmetry_planes(planes, s):
        # Simple placeholder: rotate and flip based on s
        if s == 0:
            return planes
        if s == 1:
            return tf.reverse(planes, axis=[1])
        if s == 2:
            return tf.reverse(planes, axis=[2])
        if s == 3:
            return tf.reverse(planes, axis=[1, 2])
        if s == 4:
            return tf.transpose(planes, perm=[0, 2, 1, 3])
        if s == 5:
            return tf.transpose(planes, perm=[0, 2, 1, 3])
        if s == 6:
            return tf.reverse(tf.transpose(planes, perm=[0, 2, 1, 3]), axis=[1])
        if s == 7:
            return tf.reverse(tf.transpose(planes, perm=[0, 2, 1, 3]), axis=[2])

    @staticmethod
    def apply_symmetry_plane(map_, s):
        if s == 0:
            return map_
        if s == 1:
            return tf.reverse(map_, axis=[0])
        if s == 2:
            return tf.reverse(map_, axis=[1])
        if s == 3:
            return tf.reverse(map_, axis=[0, 1])
        if s == 4:
            return tf.transpose(map_)
        if s == 5:
            return tf.transpose(map_)
        if s == 6:
            return tf.reverse(tf.transpose(map_), axis=[0])
        if s == 7:
            return tf.reverse(tf.transpose(map_), axis=[1])

def apply_random_symmetries(feature_planes, final_maps):
    batch_size = tf.shape(feature_planes)[0]
    indices = tf.range(batch_size)
    def single_sample(i):
        s = tf.random.uniform([], minval=0, maxval=8, dtype=tf.int32)
        fp = Symmetry.apply_symmetry_planes(feature_planes[i], s)
        fm = Symmetry.apply_symmetry_plane(final_maps[i], s)
        return fp, fm
    planes, maps = tf.map_fn(single_sample, indices, dtype=(tf.float32, tf.float32))
    planes = tf.stack(planes, axis=0)
    maps = tf.stack(maps, axis=0)
    return planes, maps

def apply_normalization(tensor):
    mean = tf.reduce_mean(tensor, axis=[1,2,3], keepdims=True)
    std = tf.math.reduce_std(tensor, axis=[1,2,3], keepdims=True)
    return (tensor - mean) / (std + 1e-6)

def build_feed_dict(loader, batch_size, feature_planes_ph, final_maps_ph):
    batch = loader.get_minibatch(batch_size)
    feature_planes = tf.convert_to_tensor(batch['feature_planes'], dtype=tf.float32)
    final_maps = tf.convert_to_tensor(batch['final_maps'], dtype=tf.float32)
    feature_planes = apply_normalization(feature_planes)
    feature_planes, final_maps = apply_random_symmetries(feature_planes, final_maps)
    final_maps = tf.reshape(final_maps, [batch_size, -1])
    return {feature_planes_ph: feature_planes.numpy(), final_maps_ph: final_maps.numpy()}

def loss_func(logits):
    final_maps_placeholder = tf.placeholder(tf.float32, shape=[None, 361], name='final_maps')
    probs = 0.5 * final_maps_placeholder + 0.5
    cross_entropy = tf.nn.sigmoid_cross_entropy_with_logits(labels=probs, logits=logits)
    cross_entropy_mean = tf.reduce_mean(cross_entropy)
    accuracy = tf.reduce_mean(tf.cast(tf.equal(tf.sign(logits), tf.sign(final_maps_placeholder)), tf.float32))
    return cross_entropy_mean, accuracy, final_maps_placeholder

# Example placeholders for graph construction
feature_planes_ph = tf.placeholder(tf.float32, shape=[None, None, None, None], name='feature_planes')
final_maps_ph = tf.placeholder(tf.float32, shape=[None, 361], name='final_maps')  # reshaped later

# Example usage (requires a proper loader implementation)
# loader = YourDataLoader()
# batch_size = 32
# feed_dict = build_feed_dict(loader, batch_size, feature_planes_ph, final_maps_ph)
# logits = your_model(feature_planes_ph)
# loss, acc, label_ph = loss_func(logits)
# with tf.Session() as sess:
#     sess.run([loss, acc], feed_dict=feed_dict)