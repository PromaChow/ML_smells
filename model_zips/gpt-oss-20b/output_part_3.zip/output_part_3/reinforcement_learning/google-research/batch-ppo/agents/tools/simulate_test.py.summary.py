import tensorflow as tf

tf.compat.v1.disable_eager_execution()

class InGraphBatchEnv:
    def __init__(self, durations):
        self.durations = tf.constant(durations, dtype=tf.int32)
        self.batch_size = tf.shape(self.durations)[0]
        self.reset_pl = tf.placeholder(tf.bool, shape=[self.batch_size], name='reset')
        self.steps = tf.Variable(tf.zeros(self.durations.shape, dtype=tf.int32), name='steps')
        # next_steps: reset if reset_pl True, or if step == duration
        next_steps = tf.where(
            self.reset_pl,
            tf.zeros_like(self.steps),
            tf.where(
                tf.equal(self.steps, self.durations),
                tf.zeros_like(self.steps),
                tf.add(self.steps, 1)
            )
        )
        self.done = tf.logical_or(
            tf.equal(tf.add(self.steps, 1), self.durations),
            self.reset_pl
        )
        self.step_assign = tf.assign(self.steps, next_steps)

class MockAlgorithm:
    def __init__(self):
        pass

def simulate(env, algorithm):
    return env.done, env.steps, env.step_assign

class TestSimulation(tf.test.TestCase):
    def _create_test_batch_env(self, durations):
        return InGraphBatchEnv(durations)

    def test_done_automatic(self):
        env = self._create_test_batch_env([1, 2, 3, 4])
        done, steps, step_assign = simulate(env, MockAlgorithm())
        with self.test_session() as sess:
            sess.run(tf.global_variables_initializer())
            results = []
            for _ in range(4):
                d, _ = sess.run([done, step_assign], feed_dict={env.reset_pl: [False, False, False, False]})
                results.append(d)
            expected = [
                [True, False, False, False],
                [True, True, False, False],
                [True, False, True, False],
                [True, False, False, True]
            ]
            self.assertAllEqual(results, expected)

    def test_done_forced(self):
        env = self._create_test_batch_env([2, 4])
        done, steps, step_assign = simulate(env, MockAlgorithm())
        with self.test_session() as sess:
            sess.run(tf.global_variables_initializer())
            # First step, no reset
            d1, _ = sess.run([done, step_assign], feed_dict={env.reset_pl: [False, False]})
            self.assertAllEqual(d1, [False, False])
            # Second step, reset only first env
            d2, _ = sess.run([done, step_assign], feed_dict={env.reset_pl: [True, False]})
            self.assertAllEqual(d2, [True, False])

    def test_reset_automatic(self):
        env = self._create_test_batch_env([1, 2, 3, 4])
        done, steps, step_assign = simulate(env, MockAlgorithm())
        with self.test_session() as sess:
            sess.run(tf.global_variables_initializer())
            for _ in range(10):
                sess.run([done, step_assign], feed_dict={env.reset_pl: [False, False, False, False]})
            final_steps = sess.run(steps)
            # Each step count should be within its duration
            for i, dur in enumerate([1, 2, 3, 4]):
                self.assertLess(final_steps[i], dur)

    def test_reset_forced(self):
        env = self._create_test_batch_env([2, 4])
        done, steps, step_assign = simulate(env, MockAlgorithm())
        with self.test_session() as sess:
            sess.run(tf.global_variables_initializer())
            # Step 1, no reset
            sess.run([done, step_assign], feed_dict={env.reset_pl: [False, False]})
            # Step 2, reset env 1
            sess.run([done, step_assign], feed_dict={env.reset_pl: [True, False]})
            # Step 3, no reset
            sess.run([done, step_assign], feed_dict={env.reset_pl: [False, False]})
            final_steps = sess.run(steps)
            self.assertEqual(final_steps[0], 1)  # env 1 reset to 1 after step 3
            self.assertEqual(final_steps[1], 2)  # env 2 progressed from 0 to 2

if __name__ == '__main__':
    tf.test.main()
