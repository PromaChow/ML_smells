import argparse
import json
import os
import random
import time
from datetime import datetime

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms
from torch.utils.data import DataLoader, RandomSampler, Subset

# ---------- Configurations ----------
config = {
    "shared": {
        "batch_size": 64,
        "iteration": 20000,
        "lr_decay_iter": 10000,
        "lr_decay_factor": 0.1,
        "ema_decay": 0.99,
        "rampup_epochs": 5000,
        "seed": 1234
    },
    "dataset": {
        "SVHN": {
            "root": "./data",
            "num_classes": 10,
            "transform": transforms.Compose([
                transforms.ToTensor(),
                transforms.Normalize((0.4377, 0.4438, 0.4728),
                                     (0.1980, 0.2010, 0.1970))
            ])
        },
        "CIFAR10": {
            "root": "./data",
            "num_classes": 10,
            "transform": transforms.Compose([
                transforms.RandomCrop(32, padding=4),
                transforms.RandomHorizontalFlip(),
                transforms.ToTensor(),
                transforms.Normalize((0.4914, 0.4822, 0.4465),
                                     (0.2470, 0.2435, 0.2616))
            ])
        }
    },
    "alg": {
        "VAT": {"lr": 1e-3, "eps": 1.0, "xi": 1e-6},
        "PL": {"lr": 1e-3, "threshold": 0.95},
        "MT": {"lr": 1e-3, "ema_decay": 0.99},
        "ICT": {"lr": 1e-3, "ema_decay": 0.99, "alpha": 0.5},
        "PI": {"lr": 1e-3},
        "supervised": {"lr": 1e-3}
    }
}

# ---------- Helper Functions ----------
def set_seed(seed):
    random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

def get_device():
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")

def get_datasets(dataset_name, root, transform):
    if dataset_name.lower() == "svhn":
        train_dataset = torchvision.datasets.SVHN(root=root, split='train',
                                                  transform=transform, download=True)
        test_dataset = torchvision.datasets.SVHN(root=root, split='test',
                                                 transform=transform, download=True)
    else:
        train_dataset = torchvision.datasets.CIFAR10(root=root, train=True,
                                                     transform=transform, download=True)
        test_dataset = torchvision.datasets.CIFAR10(root=root, train=False,
                                                    transform=transform, download=True)
    val_dataset = Subset(test_dataset, range(5000))
    test_dataset = Subset(test_dataset, range(5000, 10000))
    return train_dataset, val_dataset, test_dataset

def split_labeled_unlabeled(dataset, labeled_fraction=0.1):
    n_total = len(dataset)
    n_labeled = int(n_total * labeled_fraction)
    indices = list(range(n_total))
    random.shuffle(indices)
    labeled_idx = indices[:n_labeled]
    unlabeled_idx = indices[n_labeled:]
    return Subset(dataset, labeled_idx), Subset(dataset, unlabeled_idx)

def build_loader(dataset, batch_size, sampler=None, drop_last=True):
    return DataLoader(dataset, batch_size=batch_size,
                      sampler=sampler, drop_last=drop_last)

def ema_update(model, ema_model, decay):
    for param, ema_param in zip(model.parameters(), ema_model.parameters()):
        ema_param.data.mul_(decay).add_(param.data, alpha=1 - decay)

def entropy_minimization(logits):
    probs = F.softmax(logits, dim=1)
    entropy = -torch.sum(probs * torch.log(probs + 1e-6), dim=1).mean()
    return entropy

def accuracy(output, target):
    pred = output.argmax(dim=1)
    return pred.eq(target).float().mean().item()

def rampup_factor(step, rampup):
    if step >= rampup:
        return 1.0
    else:
        return float(step) / rampup

# ---------- Model ----------
class WRN2(nn.Module):
    def __init__(self, num_classes=10):
        super().__init__()
        self.conv1 = nn.Conv2d(3, 16, 3, padding=1)
        self.layer1 = nn.Sequential(nn.Conv2d(16, 16, 3, padding=1),
                                    nn.BatchNorm2d(16),
                                    nn.ReLU(inplace=True))
        self.layer2 = nn.Sequential(nn.Conv2d(16, 32, 3, padding=1),
                                    nn.BatchNorm2d(32),
                                    nn.ReLU(inplace=True))
        self.fc = nn.Linear(32 * 8 * 8, num_classes)

    def forward(self, x):
        x = self.conv1(x)
        x = self.layer1(x)
        x = self.layer2(x)
        x = F.avg_pool2d(x, 4)
        x = x.view(x.size(0), -1)
        x = self.fc(x)
        return x

# ---------- SSL Algorithms ----------
class SSLBase:
    def __init__(self, model, device):
        self.model = model.to(device)
        self.device = device

    def compute_loss(self, labeled_x, unlabeled_x, labeled_y):
        raise NotImplementedError

class VAT(SSLBase):
    def __init__(self, model, device, eps=1.0, xi=1e-6):
        super().__init__(model, device)
        self.eps = eps
        self.xi = xi

    def compute_loss(self, labeled_x, unlabeled_x, labeled_y):
        all_x = torch.cat([labeled_x, unlabeled_x], dim=0)
        logits = self.model(all_x)
        cls_loss = F.cross_entropy(logits[:len(labeled_x)], labeled_y)
        # VAT loss
        with torch.no_grad():
            pred = F.softmax(logits, dim=1)
        r = torch.randn_like(unlabeled_x, device=self.device)
        r = r / (torch.norm(r, dim=(1,2,3), keepdim=True) + 1e-8)
        perturbed = unlabeled_x + self.xi * r
        perturbed = perturbed.requires_grad_(True)
        logits_perturbed = self.model(perturbed)
        loss_perturbed = F.kl_div(F.log_softmax(logits_perturbed, dim=1),
                                  pred, reduction='batchmean')
        return cls_loss, loss_perturbed

class PL(SSLBase):
    def __init__(self, model, device, threshold=0.95):
        super().__init__(model, device)
        self.threshold = threshold

    def compute_loss(self, labeled_x, unlabeled_x, labeled_y):
        all_x = torch.cat([labeled_x, unlabeled_x], dim=0)
        logits = self.model(all_x)
        cls_loss = F.cross_entropy(logits[:len(labeled_x)], labeled_y)
        probs = F.softmax(logits[len(labeled_x):], dim=1)
        max_probs, pseudo_labels = probs.max(dim=1)
        mask = max_probs > self.threshold
        if mask.sum() > 0:
            ssl_loss = F.cross_entropy(logits[len(labeled_x):][mask], pseudo_labels[mask])
        else:
            ssl_loss = torch.tensor(0.0, device=self.device)
        return cls_loss, ssl_loss

class MT(SSLBase):
    def __init__(self, model, device, ema_decay=0.99):
        super().__init__(model, device)
        self.ema_model = type(model)(num_classes=model.fc.out_features).to(device)
        self.ema_model.load_state_dict(model.state_dict())
        self.ema_decay = ema_decay

    def compute_loss(self, labeled_x, unlabeled_x, labeled_y):
        all_x = torch.cat([labeled_x, unlabeled_x], dim=0)
        logits = self.model(all_x)
        cls_loss = F.cross_entropy(logits[:len(labeled_x)], labeled_y)
        probs_student = F.softmax(logits[len(labeled_x):], dim=1)
        with torch.no_grad():
            probs_teacher = F.softmax(self.ema_model(unlabeled_x), dim=1)
        ssl_loss = F.mse_loss(probs_student, probs_teacher)
        return cls_loss, ssl_loss

class ICT(SSLBase):
    def __init__(self, model, device, ema_decay=0.99, alpha=0.5):
        super().__init__(model, device)
        self.ema_model = type(model)(num_classes=model.fc.out_features).to(device)
        self.ema_model.load_state_dict(model.state_dict())
        self.ema_decay = ema_decay
        self.alpha = alpha

    def compute_loss(self, labeled_x, unlabeled_x, labeled_y):
        all_x = torch.cat([labeled_x, unlabeled_x], dim=0)
        logits = self.model(all_x)
        cls_loss = F.cross_entropy(logits[:len(labeled_x)], labeled_y)
        # Interpolation consistency
        x1 = unlabeled_x
        x2 = unlabeled_x[torch.randperm(unlabeled_x.size(0))]
        mixed_x = self.alpha * x1 + (1 - self.alpha) * x2
        mixed_logits = self.model(mixed_x)
        probs1 = F.softmax(self.ema_model(x1), dim=1)
        probs2 = F.softmax(self.ema_model(x2), dim=1)
        mixed_target = self.alpha * probs1 + (1 - self.alpha) * probs2
        ssl_loss = F.mse_loss(F.softmax(mixed_logits, dim=1), mixed_target)
        return cls_loss, ssl_loss

class PI(SSLBase):
    def compute_loss(self, labeled_x, unlabeled_x, labeled_y):
        all_x = torch.cat([labeled_x, unlabeled_x], dim=0)
        logits = self.model(all_x)
        cls_loss = F.cross_entropy(logits[:len(labeled_x)], labeled_y)
        probs_student = F.softmax(logits[len(labeled_x):], dim=1)
        with torch.no_grad():
            probs_teacher = F.softmax(self.model(unlabeled_x), dim=1)
        ssl_loss = F.mse_loss(probs_student, probs_teacher)
        return cls_loss, ssl_loss

class Supervised(SSLBase):
    def compute_loss(self, labeled_x, unlabeled_x, labeled_y):
        logits = self.model(labeled_x)
        cls_loss = F.cross_entropy(logits, labeled_y)
        return cls_loss, torch.tensor(0.0, device=self.device)

# ---------- Training ----------
def train(args):
    set_seed(config["shared"]["seed"])
    device = get_device()
    alg_cfg = config["alg"][args.alg]
    dataset_cfg = config["dataset"][args.dataset]
    shared_cfg = config["shared"]

    # Datasets
    full_train, val_ds, test_ds = get_datasets(args.dataset,
                                               dataset_cfg["root"],
                                               dataset_cfg["transform"])
    l_train, u_train = split_labeled_unlabeled(full_train, labeled_fraction=0.1)

    print(f"Labeled: {len(l_train)}, Unlabeled: {len(u_train)}, "
          f"Validation: {len(val_ds)}, Test: {len(test_ds)}")

    # DataLoaders
    batch_size = shared_cfg["batch_size"]
    if args.alg == "supervised":
        l_loader = build_loader(l_train, batch_size, drop_last=True)
        u_loader = None
    else:
        l_loader = build_loader(l_train, batch_size // 2, drop_last=True)
        u_loader = build_loader(u_train, batch_size // 2, drop_last=True)

    val_loader = build_loader(val_ds, batch_size, drop_last=False)
    test_loader = build_loader(test_ds, batch_size, drop_last=False)

    # Model and Optimizer
    model = WRN2(num_classes=dataset_cfg["num_classes"]).to(device)
    optimizer = optim.Adam(model.parameters(), lr=alg_cfg["lr"])

    # SSL Object
    if args.alg == "VAT":
        ssl_obj = VAT(model, device,
                      eps=alg_cfg.get("eps", 1.0),
                      xi=alg_cfg.get("xi", 1e-6))
    elif args.alg == "PL":
        ssl_obj = PL(model, device,
                     threshold=alg_cfg.get("threshold", 0.95))
    elif args.alg == "MT":
        ssl_obj = MT(model, device,
                     ema_decay=alg_cfg.get("ema_decay", 0.99))
    elif args.alg == "ICT":
        ssl_obj = ICT(model, device,
                      ema_decay=alg_cfg.get("ema_decay", 0.99),
                      alpha=alg_cfg.get("alpha", 0.5))
    elif args.alg == "PI":
        ssl_obj = PI(model, device)
    else:
        ssl_obj = Supervised(model, device)

    best_val_acc = 0.0
    test_acc = 0.0
    start_time = time.time()
    l_iter = iter(l_loader)
    if u_loader:
        u_iter = iter(u_loader)

    for step in range(1, shared_cfg["iteration"] + 1):
        try:
            l_batch = next(l_iter)
        except StopIteration:
            l_iter = iter(l_loader)
            l_batch = next(l_iter)

        l_inputs, l_labels = l_batch
        l_inputs, l_labels = l_inputs.to(device), l_labels.to(device)

        if u_loader:
            try:
                u_batch = next(u_iter)
            except StopIteration:
                u_iter = iter(u_loader)
                u_batch = next(u_iter)
            u_inputs, _ = u_batch
            u_inputs = u_inputs.to(device)
        else:
            u_inputs = None

        optimizer.zero_grad()
        if args.alg == "supervised":
            cls_loss, _ = ssl_obj.compute_loss(l_inputs, None, l_labels)
            loss = cls_loss
        else:
            cls_loss, ssl_loss = ssl_obj.compute_loss(l_inputs, u_inputs, l_labels)
            ramp = rampup_factor(step, shared_cfg["rampup_epochs"])
            loss = cls_loss + ramp * ssl_loss
            if args.em > 0:
                em_loss = entropy_minimization(ssl_obj.model(l_inputs))
                loss += args.em * em_loss

        loss.backward()
        optimizer.step()

        # EMA update
        if isinstance(ssl_obj, (MT, ICT)):
            ema_update(model, ssl_obj.ema_model, shared_cfg["ema_decay"])

        # Learning rate decay
        if step == shared_cfg["lr_decay_iter"]:
            for param_group in optimizer.param_groups:
                param_group['lr'] *= shared_cfg["lr_decay_factor"]

        if step % 100 == 0 or step == shared_cfg["iteration"]:
            # Validation
            ssl_obj.model.eval()
            val_acc = evaluate(ssl_obj.model, val_loader, device)
            ssl_obj.model.train()
            print(f"Iter {step}/{shared_cfg['iteration']} - "
                  f"Loss: {loss.item():.4f} - Val Acc: {val_acc*100:.2f}%")
            if val_acc > best_val_acc:
                best_val_acc = val_acc
                test_acc = evaluate(ssl_obj.model, test_loader, device)
                print(f"New best! Test Acc: {test_acc*100:.2f}%")
            ssl_obj.model.train()

    # Save results
    result = {
        "timestamp": datetime.now().isoformat(),
        "dataset": args.dataset,
        "algorithm": args.alg,
        "entropy_coefficient": args.em,
        "lr": alg_cfg["lr"],
        "best_val_acc": best_val_acc,
        "test_acc": test_acc
    }
    out_dir = args.output
    os.makedirs(out_dir, exist_ok=True)
    fname = f"{args.dataset}_{args.alg}_em_{int(time.time())}.json"
    with open(os.path.join(out_dir, fname), "w") as fp:
        json.dump(result, fp, indent=2)
    print(f"Results saved to {os.path.join(out_dir, fname)}")

def evaluate(model, loader, device):
    model.eval()
    correct = 0
    total = 0
    with torch.no_grad():
        for inputs, targets in loader:
            inputs, targets = inputs.to(device), targets.to(device)
            outputs = model(inputs)
            preds = outputs.argmax(dim=1)
            correct += (preds == targets).sum().item()
            total += targets.size(0)
    model.train()
    return correct / total

# ---------- Argument Parsing ----------
def parse_args():
    parser = argparse.ArgumentParser(description="SSL Training")
    parser.add_argument("--alg", type=str, required=True,
                        choices=["supervised", "PI", "MT", "VAT", "PL", "ICT"],
                        help="SSL algorithm")
    parser.add_argument("--em", type=float, default=0.0,
                        help="Entropy minimization coefficient")
    parser.add_argument("--dataset", type=str, required=True,
                        choices=["SVHN", "CIFAR10"],
                        help="Dataset")
    parser.add_argument("--root", type=str, default="./data",
                        help="Root directory for data")
    parser.add_argument("--output", type=str, default="./outputs",
                        help="Output directory")
    parser.add_argument("--validation", type=int, default=1000,
                        help="Validation interval")
    return parser.parse_args()

# ---------- Main ----------
if __name__ == "__main__":
    args = parse_args()
    train(args)