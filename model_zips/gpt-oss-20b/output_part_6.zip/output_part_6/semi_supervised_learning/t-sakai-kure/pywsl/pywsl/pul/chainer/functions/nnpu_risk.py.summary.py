import chainer
import chainer.functions as F
import chainer.backends.cuda as cuda
import numpy as np

class PU_Risk(chainer.Function):
    def __init__(self, prior, loss=None, gamma=1.0, beta=0.0, nnPU=True):
        self.prior = float(prior)
        self.loss = loss if loss is not None else lambda x: F.sigmoid(-x)
        self.gamma = float(gamma)
        self.beta = float(beta)
        self.nnPU = bool(nnPU)

    def check_type_forward(self, in_types):
        # Expect two inputs: x (float32), t (int32)
        if len(in_types) != 2:
            raise TypeError("PU_Risk requires two inputs: x and t")
        x_type, t_type = in_types
        if x_type.dtype != np.float32:
            raise TypeError("x must be float32")
        if t_type.dtype != np.int32:
            raise TypeError("t must be int32")
        if x_type.shape[0] != t_type.shape[0]:
            raise ValueError("x and t must have the same first dimension")
        if t_type.ndim != 1:
            raise ValueError("t must be a 1D array")

    def forward(self, inputs):
        x, t = inputs
        self.x_shape = x.shape
        self.t_shape = t.shape

        t_col = t.reshape(-1, 1)
        positive_mask = (t_col == 1).astype(np.float32)
        unl_mask = (t_col == 0).astype(np.float32)

        n_pos = positive_mask.sum()
        n_unl = unl_mask.sum()
        n_pos = float(n_pos if n_pos > 0 else 1)
        n_unl = float(n_unl if n_unl > 0 else 1)

        # Store for backward
        self.positive_mask = positive_mask
        self.unl_mask = unl_mask
        self.n_pos = n_pos
        self.n_unl = n_unl

        loss_pos = self.loss(x)
        loss_neg = self.loss(-x)

        positive_risk = (self.prior / self.n_pos) * positive_mask * loss_pos
        negative_risk = ((unl_mask / self.n_unl) - (self.prior / self.n_pos) * positive_mask) * loss_neg

        positive_risk_sum = positive_risk.sum()
        negative_risk_sum = negative_risk.sum()
        objective = positive_risk_sum + negative_risk_sum

        # Determine adjustment
        self.adjust = self.nnPU and negative_risk_sum < -self.beta

        if self.adjust:
            loss_value = positive_risk_sum - self.beta
            self.grad_output_factor = -self.gamma
        else:
            loss_value = objective
            self.grad_output_factor = 1.0

        self.loss_value = loss_value
        return (loss_value,)

    def backward(self, indexes, grads):
        gy, = grads
        # Retrieve stored values
        positive_mask = self.positive_mask
        unl_mask = self.unl_mask
        n_pos = self.n_pos
        n_unl = self.n_unl
        prior = self.prior
        gamma = self.gamma
        beta = self.beta

        # Compute gradients of loss components
        x = self.inputs[0]
        loss_pos = self.loss(x)
        loss_neg = self.loss(-x)

        s_pos = F.sigmoid(-x)
        d_pos = -s_pos * (1 - s_pos)
        s_neg = F.sigmoid(x)
        d_neg = s_neg * (1 - s_neg)

        d_positive = (prior / n_pos) * positive_mask * d_pos
        d_negative = ((unl_mask / n_unl) - (prior / n_pos) * positive_mask) * d_neg

        if self.adjust:
            grad_x = gy * self.grad_output_factor * d_negative
        else:
            grad_x = gy * (d_positive + d_negative)

        return (grad_x, None)

def pu_risk(x, t, prior, loss=None, gamma=1.0, beta=0.0, nnPU=True):
    """Convenience wrapper for PU risk."""
    return PU_Risk(prior, loss, gamma, beta, nnPU)(x, t)[:0]  # returns scalar

# Example usage:
# x = chainer.Variable(np.random.randn(100, 10).astype(np.float32))
# t = chainer.Variable(np.random.randint(0, 2, size=(100,)).astype(np.int32))
# loss = pu_risk(x, t, prior=0.1, nnPU=True)
# loss.backward()