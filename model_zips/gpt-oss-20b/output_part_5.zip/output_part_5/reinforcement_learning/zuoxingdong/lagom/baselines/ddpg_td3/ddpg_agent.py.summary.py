import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import numpy as np
from collections import deque
import random

# Actor network
class Actor(nn.Module):
    def __init__(self, obs_dim, action_dim, max_action):
        super(Actor, self).__init__()
        self.fc1 = nn.Linear(obs_dim, 400)
        self.fc2 = nn.Linear(400, 300)
        self.out = nn.Linear(300, action_dim)
        self.max_action = max_action

    def forward(self, obs):
        x = F.relu(self.fc1(obs))
        x = F.relu(self.fc2(x))
        x = torch.tanh(self.out(x))
        return x * self.max_action

# Critic network
class Critic(nn.Module):
    def __init__(self, obs_dim, action_dim):
        super(Critic, self).__init__()
        self.fc1 = nn.Linear(obs_dim + action_dim, 400)
        self.fc2 = nn.Linear(400, 300)
        self.out = nn.Linear(300, 1)

    def forward(self, obs, act):
        x = torch.cat([obs, act], dim=1)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        return self.out(x)

# Replay buffer
class ReplayBuffer:
    def __init__(self, max_size, obs_dim, action_dim):
        self.max_size = max_size
        self.obs_buf = np.zeros((max_size, obs_dim), dtype=np.float32)
        self.next_obs_buf = np.zeros((max_size, obs_dim), dtype=np.float32)
        self.acts_buf = np.zeros((max_size, action_dim), dtype=np.float32)
        self.rews_buf = np.zeros((max_size, 1), dtype=np.float32)
        self.masks_buf = np.zeros((max_size, 1), dtype=np.float32)
        self.ptr = 0
        self.size = 0

    def add(self, obs, act, rew, next_obs, mask):
        self.obs_buf[self.ptr] = obs
        self.acts_buf[self.ptr] = act
        self.rews_buf[self.ptr] = rew
        self.next_obs_buf[self.ptr] = next_obs
        self.masks_buf[self.ptr] = mask
        self.ptr = (self.ptr + 1) % self.max_size
        self.size = min(self.size + 1, self.max_size)

    def sample(self, batch_size):
        idxs = np.random.choice(self.size, batch_size, replace=False)
        return dict(
            obs=torch.tensor(self.obs_buf[idxs], device=device),
            acts=torch.tensor(self.acts_buf[idxs], device=device),
            rews=torch.tensor(self.rews_buf[idxs], device=device),
            next_obs=torch.tensor(self.next_obs_buf[idxs], device=device),
            masks=torch.tensor(self.masks_buf[idxs], device=device)
        )

# Helper describe function
def describe(values):
    vals = values.cpu().detach().numpy()
    return dict(mean=vals.mean(), std=vals.std(), min=vals.min(), max=vals.max())

# Agent
class Agent:
    def __init__(self, env, config):
        self.obs_dim = env.observation_space.shape[0]
        self.action_dim = env.action_space.shape[0]
        self.max_action = float(env.action_space.high[0])
        self.gamma = config['agent.gamma']
        self.polyak = config['agent.polyak']
        self.max_grad_norm = config['agent.max_grad_norm']
        self.action_noise = config['agent.action_noise']

        # Networks
        self.actor = Actor(self.obs_dim, self.action_dim, self.max_action).to(device)
        self.actor_target = Actor(self.obs_dim, self.action_dim, self.max_action).to(device)
        self.critic = Critic(self.obs_dim, self.action_dim).to(device)
        self.critic_target = Critic(self.obs_dim, self.action_dim).to(device)

        # Copy weights to target
        self.actor_target.load_state_dict(self.actor.state_dict())
        self.critic_target.load_state_dict(self.critic.state_dict())

        # Optimizers
        self.actor_opt = optim.Adam(self.actor.parameters(), lr=config['agent.actor_lr'])
        self.critic_opt = optim.Adam(self.critic.parameters(), lr=config['agent.critic_lr'])

        # Replay buffer
        self.replay = ReplayBuffer(config['replay_buffer_size'], self.obs_dim, self.action_dim)

    def select_action(self, obs, train=True):
        obs = torch.tensor(obs, dtype=torch.float32, device=device).unsqueeze(0)
        action = self.actor(obs).squeeze(0)
        if train:
            noise = torch.randn_like(action) * self.action_noise
            action = action + noise
        return action.clamp(-self.max_action, self.max_action).cpu().detach().numpy()

    def train_from_batch(self, batch_size):
        batch = self.replay.sample(batch_size)

        # Critic loss
        current_q = self.critic(batch['obs'], batch['acts'])
        with torch.no_grad():
            next_actions = self.actor_target(batch['next_obs'])
            next_q = self.critic_target(batch['next_obs'], next_actions)
            target_q = batch['rews'] + self.gamma * batch['masks'] * next_q
        critic_loss = F.mse_loss(current_q, target_q)

        self.critic_opt.zero_grad()
        critic_loss.backward()
        nn.utils.clip_grad_norm_(self.critic.parameters(), self.max_grad_norm)
        self.critic_opt.step()

        # Actor loss
        actor_actions = self.actor(batch['obs'])
        actor_loss = -self.critic(batch['obs'], actor_actions).mean()

        self.actor_opt.zero_grad()
        actor_loss.backward()
        nn.utils.clip_grad_norm_(self.actor.parameters(), self.max_grad_norm)
        self.actor_opt.step()

        # Polyak update
        for target_param, param in zip(self.actor_target.parameters(), self.actor.parameters()):
            target_param.data.copy_(self.polyak * target_param.data + (1 - self.polyak) * param.data)
        for target_param, param in zip(self.critic_target.parameters(), self.critic.parameters()):
            target_param.data.copy_(self.polyak * target_param.data + (1 - self.polyak) * param.data)

        # Logging
        log = {
            'critic_loss': critic_loss.item(),
            'actor_loss': actor_loss.item(),
            'q_mean': describe(current_q)['mean'],
            'q_std': describe(current_q)['std'],
            'grad_norm_actor': self._grad_norm(self.actor),
            'grad_norm_critic': self._grad_norm(self.critic)
        }
        return log

    def _grad_norm(self, module):
        total_norm = 0.0
        for p in module.parameters():
            if p.grad is not None:
                param_norm = p.grad.data.norm(2)
                total_norm += param_norm.item() ** 2
        return total_norm ** 0.5

    def save_checkpoint(self, path):
        torch.save({
            'actor': self.actor.state_dict(),
            'actor_target': self.actor_target.state_dict(),
            'critic': self.critic.state_dict(),
            'critic_target': self.critic_target.state_dict(),
            'actor_opt': self.actor_opt.state_dict(),
            'critic_opt': self.critic_opt.state_dict(),
            'replay': {
                'obs_buf': self.replay.obs_buf,
                'acts_buf': self.replay.acts_buf,
                'rews_buf': self.replay.rews_buf,
                'next_obs_buf': self.replay.next_obs_buf,
                'masks_buf': self.replay.masks_buf,
                'ptr': self.replay.ptr,
                'size': self.replay.size
            }
        }, path)

    def load_checkpoint(self, path):
        checkpoint = torch.load(path, map_location=device)
        self.actor.load_state_dict(checkpoint['actor'])
        self.actor_target.load_state_dict(checkpoint['actor_target'])
        self.critic.load_state_dict(checkpoint['critic'])
        self.critic_target.load_state_dict(checkpoint['critic_target'])
        self.actor_opt.load_state_dict(checkpoint['actor_opt'])
        self.critic_opt.load_state_dict(checkpoint['critic_opt'])
        replay = checkpoint['replay']
        self.replay.obs_buf = replay['obs_buf']
        self.replay.acts_buf = replay['acts_buf']
        self.replay.rews_buf = replay['rews_buf']
        self.replay.next_obs_buf = replay['next_obs_buf']
        self.replay.masks_buf = replay['masks_buf']
        self.replay.ptr = replay['ptr']
        self.replay.size = replay['size']

# Device
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
```