import torch
import torch.nn.functional as F
from torch.distributions.beta import Beta

def make_pseudo_label(logits: torch.Tensor, threshold: float) -> tuple[torch.Tensor, torch.Tensor]:
    """Compute hard pseudo-labels and a mask based on a probability threshold."""
    probs = F.softmax(logits, dim=1)
    max_probs, hard_labels = probs.max(dim=1)
    mask = (max_probs > threshold).float()
    return hard_labels, mask

def sharpening(soft_labels: torch.Tensor, temp: float) -> torch.Tensor:
    """Raise soft labels to a temperature power and renormalize."""
    sharpened = soft_labels.pow(temp)
    denom = sharpened.abs().sum(dim=1, keepdim=True) + 1e-6
    return sharpened / denom

def tempereture_softmax(logits: torch.Tensor, tau: float) -> torch.Tensor:
    """Apply temperature-scaled softmax to logits."""
    scaled = logits / tau
    return F.softmax(scaled, dim=1)

def mixup(x: torch.Tensor, y: torch.Tensor, alpha: float) -> tuple[torch.Tensor, torch.Tensor]:
    """Perform mixup data augmentation on inputs and labels."""
    batch_size = x.size(0)
    perm = torch.randperm(batch_size, device=x.device)
    x_perm = x[perm]
    y_perm = y[perm]

    beta_dist = Beta(alpha, alpha)
    lam = beta_dist.sample((batch_size,)).to(x.device)
    lam_shape = [batch_size] + [1] * (x.dim() - 1)
    lam = lam.reshape(lam_shape)

    mixed_x = lam * x + (1 - lam) * x_perm
    mixed_y = lam * y + (1 - lam) * y_perm
    return mixed_x, mixed_y

def get_tsa_threshold(
    global_step: int,
    max_iter: int,
    schedule: str,
    num_classes: int,
) -> float:
    """Compute the TSA threshold based on the training schedule."""
    step_ratio = min(max(global_step / max_iter, 0.0), 1.0)
    start = 1.0 / num_classes
    end = 1.0

    if schedule == "linear":
        coeff = step_ratio
    elif schedule == "exponential":
        coeff = (torch.exp(step_ratio * 5.0) - 1.0) / (torch.exp(5.0) - 1.0)
    elif schedule == "logarithmic":
        coeff = torch.log(step_ratio * 5.0 + 1.0) / torch.log(torch.tensor(6.0))
    else:
        raise ValueError(f"Unsupported schedule: {schedule}")

    threshold = coeff * (end - start) + start
    return threshold.item()

def anneal_loss(
    logits: torch.Tensor,
    labels: torch.Tensor,
    loss: torch.Tensor,
    global_step: int,
    max_iter: int,
    schedule: str,
    num_classes: int,
) -> torch.Tensor:
    """Apply thresholded sharpness annealing to the loss."""
    threshold = get_tsa_threshold(global_step, max_iter, schedule, num_classes)
    probs = F.softmax(logits, dim=1)
    correct_probs = probs.gather(1, labels.unsqueeze(1)).squeeze(1)
    mask = (correct_probs < threshold).float()

    masked_loss = (loss * mask).sum()
    denom = mask.sum() + 1e-6
    return masked_loss / denom
