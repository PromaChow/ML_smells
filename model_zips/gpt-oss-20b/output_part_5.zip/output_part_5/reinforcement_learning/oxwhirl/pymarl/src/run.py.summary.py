import argparse
import logging
import os
import random
import sys
import time
import uuid

import gym
import numpy as np
import torch
from torch.utils.tensorboard import SummaryWriter

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


class Runner:
    def __init__(self, env_name, config):
        self.env = gym.make(env_name)
        self.num_agents = 1
        self.action_space = self.env.action_space
        self.observation_space = self.env.observation_space
        self.config = config

    def reset(self):
        obs = self.env.reset()
        return obs

    def step(self, action):
        next_obs, reward, done, info = self.env.step(action)
        return next_obs, reward, done, info

    def close(self):
        self.env.close()


class ReplayBuffer:
    def __init__(self, capacity):
        self.capacity = capacity
        self.buffer = []

    def add(self, transition):
        if len(self.buffer) >= self.capacity:
            self.buffer.pop(0)
        self.buffer.append(transition)

    def sample(self, batch_size):
        return random.sample(self.buffer, batch_size)

    def __len__(self):
        return len(self.buffer)


class MAC:
    def __init__(self, obs_dim, act_dim, device):
        self.obs_dim = obs_dim
        self.act_dim = act_dim
        self.device = device
        self.network = torch.nn.Linear(obs_dim, act_dim).to(device)

    def forward(self, obs):
        return self.network(obs)

    def parameters(self):
        return self.network.parameters()


class Learner:
    def __init__(self, mac, lr=1e-3):
        self.mac = mac
        self.optimizer = torch.optim.Adam(self.mac.parameters(), lr=lr)
        self.loss_fn = torch.nn.MSELoss()

    def train(self, batch):
        obs = torch.stack([torch.tensor(t[0], dtype=torch.float32) for t in batch]).to(self.mac.device)
        actions = torch.tensor([t[1] for t in batch], dtype=torch.long).to(self.mac.device)
        rewards = torch.tensor([t[2] for t in batch], dtype=torch.float32).to(self.mac.device)
        next_obs = torch.stack([torch.tensor(t[3], dtype=torch.float32) for t in batch]).to(self.mac.device)
        dones = torch.tensor([t[4] for t in batch], dtype=torch.float32).to(self.mac.device)

        q_values = self.mac.forward(obs).gather(1, actions.unsqueeze(1)).squeeze()
        with torch.no_grad():
            next_q = self.mac.forward(next_obs).max(1)[0]
        target = rewards + (1 - dones) * 0.99 * next_q

        loss = self.loss_fn(q_values, target)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        return loss.item()

    def state_dict(self):
        return self.mac.network.state_dict()

    def load_state_dict(self, state_dict):
        self.mac.network.load_state_dict(state_dict)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--env", type=str, default="CartPole-v1", help="Gym environment")
    parser.add_argument("--max_steps", type=int, default=100000, help="Maximum training steps")
    parser.add_argument("--batch_size", type=int, default=64, help="Replay buffer batch size")
    parser.add_argument("--buffer_capacity", type=int, default=100000, help="Replay buffer capacity")
    parser.add_argument("--test_interval", type=int, default=5000, help="Steps between test runs")
    parser.add_argument("--log_interval", type=int, default=100, help="Steps between logs")
    parser.add_argument("--save_interval", type=int, default=10000, help="Steps between checkpoints")
    parser.add_argument("--test_episodes", type=int, default=10, help="Number of test episodes")
    parser.add_argument("--cuda", action="store_true", help="Use CUDA if available")
    parser.add_argument("--checkpoint", type=str, default=None, help="Path to checkpoint")
    parser.add_argument("--eval_only", action="store_true", help="Run only evaluation")
    return parser.parse_args()


def main():
    args = parse_args()

    if args.cuda and not torch.cuda.is_available():
        logger.warning("CUDA requested but not available. Falling back to CPU.")
    device = torch.device("cuda" if args.cuda and torch.cuda.is_available() else "cpu")

    test_episodes = args.test_episodes
    if test_episodes % args.batch_size != 0:
        test_episodes = (test_episodes // args.batch_size) * args.batch_size

    token = uuid.uuid4().hex[:8]
    logger.info(f"Experiment token: {token}")

    writer = SummaryWriter(log_dir=f"runs/{token}")

    config = {
        "max_steps": args.max_steps,
        "batch_size": args.batch_size,
        "buffer_capacity": args.buffer_capacity,
        "test_interval": args.test_interval,
        "log_interval": args.log_interval,
        "save_interval": args.save_interval,
        "test_episodes": test_episodes,
        "eval_only": args.eval_only,
    }

    runner = Runner(args.env, config)
    obs_dim = runner.observation_space.shape[0]
    act_dim = runner.action_space.n if hasattr(runner.action_space, "n") else 1

    mac = MAC(obs_dim, act_dim, device)
    learner = Learner(mac)

    buffer = ReplayBuffer(args.buffer_capacity)

    if args.checkpoint and os.path.exists(args.checkpoint):
        state_dict = torch.load(args.checkpoint, map_location=device)
        learner.load_state_dict(state_dict)
        logger.info(f"Loaded checkpoint from {args.checkpoint}")

    if config["eval_only"]:
        run_evaluation(runner, learner, config, writer, device)
        runner.close()
        writer.close()
        return

    start_time = time.time()
    total_steps = 0
    episode = 0
    while total_steps < config["max_steps"]:
        obs = runner.reset()
        done = False
        episode_reward = 0.0
        while not done:
            obs_tensor = torch.tensor(obs, dtype=torch.float32).to(device)
            with torch.no_grad():
                q_values = mac.forward(obs_tensor)
                action = torch.argmax(q_values).item()
            next_obs, reward, done, _ = runner.step(action)
            buffer.add((obs, action, reward, next_obs, float(done)))
            obs = next_obs
            episode_reward += reward
            total_steps += 1

            if len(buffer) >= config["batch_size"]:
                batch = buffer.sample(config["batch_size"])
                loss = learner.train(batch)

            if total_steps % config["log_interval"] == 0:
                elapsed = time.time() - start_time
                avg_step_time = elapsed / total_steps
                remaining = (config["max_steps"] - total_steps) * avg_step_time
                logger.info(
                    f"Step {total_steps}/{config['max_steps']}, "
                    f"Avg Loss {loss:.4f}, "
                    f"Avg Step Time {avg_step_time:.4f}s, "
                    f"ETA {remaining/60:.1f}min"
                )
                writer.add_scalar("loss/train", loss, total_steps)
                writer.add_scalar("step/avg_step_time", avg_step_time, total_steps)

            if total_steps % config["test_interval"] == 0:
                avg_reward = evaluate_policy(runner, learner, config, device)
                logger.info(f"Test at step {total_steps}: Avg Reward {avg_reward:.2f}")
                writer.add_scalar("reward/test", avg_reward, total_steps)

            if total_steps % config["save_interval"] == 0:
                save_path = os.path.join("checkpoints", token, f"step_{total_steps}.pt")
                os.makedirs(os.path.dirname(save_path), exist_ok=True)
                torch.save(learner.state_dict(), save_path)
                logger.info(f"Saved checkpoint to {save_path}")

        episode += 1
        logger.info(f"Episode {episode} finished with reward {episode_reward:.2f}")

    runner.close()
    writer.close()
    logger.info("Training completed.")


def evaluate_policy(runner, learner, config, device):
    total_rewards = []
    for _ in range(config["test_episodes"]):
        obs = runner.reset()
        done = False
        episode_reward = 0.0
        while not done:
            obs_tensor = torch.tensor(obs, dtype=torch.float32).to(device)
            with torch.no_grad():
                q_values = learner.mac.forward(obs_tensor)
                action = torch.argmax(q_values).item()
            obs, reward, done, _ = runner.step(action)
            episode_reward += reward
        total_rewards.append(episode_reward)
    return np.mean(total_rewards)


def run_evaluation(runner, learner, config, writer, device):
    avg_reward = evaluate_policy(runner, learner, config, device)
    logger.info(f"Evaluation reward: {avg_reward:.2f}")
    writer.add_scalar("reward/eval", avg_reward, 0)
    writer.close()
    runner.close()


if __name__ == "__main__":
    main()
