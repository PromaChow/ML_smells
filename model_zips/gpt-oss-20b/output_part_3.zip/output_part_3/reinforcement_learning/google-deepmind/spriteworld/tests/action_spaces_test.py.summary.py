import numpy as np
import pytest

# ---------- Simulation primitives ----------

class Sprite:
    def __init__(self, pos):
        self.pos = np.array(pos, dtype=float)
        self.carried_by = None

    def move(self, delta):
        self.pos += delta

class ActionSpaceBase:
    def __init__(self, scale=1.0, motion_cost=0.0, noise_scale=0.0):
        self.scale = scale
        self.motion_cost = motion_cost
        self.noise_scale = noise_scale

    def get_motion(self, action):
        raise NotImplementedError

    def apply_noise_to_action(self, action):
        if self.noise_scale > 0:
            noise = np.random.uniform(-1, 1, size=action.shape) * self.noise_scale
            return action + noise
        return action

    def step(self, action, sprites, keep_in_frame=True):
        raise NotImplementedError

# ---------- Action spaces ----------

class SelectMove(ActionSpaceBase):
    def get_motion(self, action):
        return np.array(action, dtype=float) * self.scale

    def step(self, action, sprites, keep_in_frame=True):
        motion = self.get_motion(action)
        cost = np.linalg.norm(motion) * self.motion_cost
        for sprite in sprites:
            new_pos = sprite.pos + motion
            if keep_in_frame:
                new_pos = np.clip(new_pos, 0.0, 1.0)
            sprite.pos = new_pos
        return cost

class DragAndDrop(ActionSpaceBase):
    def get_motion(self, action):
        return np.array(action, dtype=float) * self.scale

    def step(self, action, sprites, keep_in_frame=True):
        motion = self.get_motion(action)
        cost = np.linalg.norm(motion) * self.motion_cost
        for sprite in sprites:
            new_pos = sprite.pos + motion
            if keep_in_frame:
                new_pos = np.clip(new_pos, 0.0, 1.0)
            sprite.pos = new_pos
        return cost

class Embodied(ActionSpaceBase):
    ACTIONS = {
        0: np.array([0.0, 1.0]),   # up
        1: np.array([-1.0, 0.0]),  # left
        2: np.array([0.0, -1.0]),  # down
        3: np.array([1.0, 0.0]),   # right
    }

    def __init__(self, step_size=0.1):
        super().__init__(scale=step_size)
        self.step_size = step_size

    def action_to_motion(self, motion_action):
        return self.ACTIONS[motion_action] * self.step_size

    def step(self, action_tuple, sprites, keep_in_frame=True):
        carrying_idx, motion_action = action_tuple
        delta = self.action_to_motion(motion_action)
        cost = np.linalg.norm(delta) * self.motion_cost
        # Move target sprite
        target = sprites[carrying_idx]
        new_pos = target.pos + delta
        if keep_in_frame:
            new_pos = np.clip(new_pos, 0.0, 1.0)
        target.pos = new_pos
        # Move carried sprites
        for sprite in sprites:
            if sprite.carried_by == carrying_idx:
                new_pos = sprite.pos + delta
                if keep_in_frame:
                    new_pos = np.clip(new_pos, 0.0, 1.0)
                sprite.pos = new_pos
        return cost

# ---------- Tests ----------

TOL = 1e-6

@pytest.mark.parametrize(
    "scale, action, expected",
    [
        (0.5, [1, -2], [0.5, -1]),
        (2.0, [0.5, 0.5], [1.0, 1.0]),
    ],
)
def test_select_move_get_motion(scale, action, expected):
    sm = SelectMove(scale=scale)
    motion = sm.get_motion(action)
    assert np.allclose(motion, expected, atol=TOL)

@pytest.mark.parametrize(
    "scale, action, motion_cost, expected_cost",
    [
        (0.5, [1, 0], 1.0, 0.5),
        (1.0, [1, 1], 0.5, np.sqrt(2) * 0.5),
    ],
)
def test_select_move_motion_cost(scale, action, motion_cost, expected_cost):
    sm = SelectMove(scale=scale, motion_cost=motion_cost)
    cost = sm.step(action, sprites=[], keep_in_frame=False)
    assert np.isclose(cost, expected_cost, atol=TOL)

@pytest.mark.parametrize(
    "scale, init_positions, actions, keep_in_frame, expected_positions",
    [
        (
            0.1,
            [[0.5, 0.5]],
            [[1, 0], [0, -1]],
            True,
            [[0.6, 0.5], [0.6, 0.4]],
        ),
        (
            0.2,
            [[0.9, 0.9]],
            [[1, 1]],
            False,
            [[1.1, 1.1]],
        ),
    ],
)
def test_select_move_move_sprites(scale, init_positions, actions, keep_in_frame, expected_positions):
    sm = SelectMove(scale=scale)
    sprites = [Sprite(pos) for pos in init_positions]
    for act, exp in zip(actions, expected_positions):
        sm.step(act, sprites, keep_in_frame=keep_in_frame)
        for sprite, expected in zip(sprites, exp):
            assert np.allclose(sprite.pos, expected, atol=TOL)

@pytest.mark.parametrize(
    "action, noise_scale, expected_in_bounds",
    [
        ([0.0, 0.0], 0.1, True),
        ([0.5, -0.5], 0.05, True),
    ],
)
def test_select_move_noise_scale(action, noise_scale, expected_in_bounds):
    np.random.seed(0)
    sm = SelectMove(scale=0.1, noise_scale=noise_scale)
    noisy_action = sm.apply_noise_to_action(np.array(action))
    if expected_in_bounds:
        assert np.all(noisy_action >= -noise_scale) and np.all(noisy_action <= noise_scale)
    else:
        assert False  # placeholder for negative test

@pytest.mark.parametrize(
    "scale, action, expected",
    [
        (0.5, [1, -2], [0.5, -1]),
        (2.0, [0.5, 0.5], [1.0, 1.0]),
    ],
)
def test_drag_and_drop_get_motion(scale, action, expected):
    dd = DragAndDrop(scale=scale)
    motion = dd.get_motion(action)
    assert np.allclose(motion, expected, atol=TOL)

@pytest.mark.parametrize(
    "scale, init_positions, actions, keep_in_frame, expected_positions",
    [
        (
            0.1,
            [[0.5, 0.5]],
            [[1, 0], [0, -1]],
            True,
            [[0.6, 0.5], [0.6, 0.4]],
        ),
        (
            0.2,
            [[0.9, 0.9]],
            [[1, 1]],
            False,
            [[1.1, 1.1]],
        ),
    ],
)
def test_drag_and_drop_move_sprites(scale, init_positions, actions, keep_in_frame, expected_positions):
    dd = DragAndDrop(scale=scale)
    sprites = [Sprite(pos) for pos in init_positions]
    for act, exp in zip(actions, expected_positions):
        dd.step(act, sprites, keep_in_frame=keep_in_frame)
        for sprite, expected in zip(sprites, exp):
            assert np.allclose(sprite.pos, expected, atol=TOL)

@pytest.mark.parametrize(
    "motion_action, step_size, expected",
    [
        (0, 0.1, [0.0, 0.1]),
        (3, 0.2, [0.2, 0.0]),
    ],
)
def test_embodied_get_motion(motion_action, step_size, expected):
    e = Embodied(step_size=step_size)
    motion = e.action_to_motion(motion_action)
    assert np.allclose(motion, expected, atol=TOL)

@pytest.mark.parametrize(
    "init_positions, action, final_positions, keep_in_frame",
    [
        (
            [[0.2, 0.2], [0.3, 0.3]],
            (0, 3),
            [[0.3, 0.2], [0.3, 0.3]],
            True,
        ),
        (
            [[0.2, 0.2], [0.3, 0.3]],
            (0, 3),
            [[0.4, 0.2], [0.4, 0.3]],
            False,
        ),
    ],
)
def test_embodied_move_sprites(init_positions, action, final_positions, keep_in_frame):
    e = Embodied(step_size=0.1)
    sprites = [Sprite(pos) for pos in init_positions]
    # create carrying relationship for second test
    if not keep_in_frame:
        sprites[1].carried_by = 0
    e.step(action, sprites, keep_in_frame=keep_in_frame)
    for sprite, expected in zip(sprites, final_positions):
        assert np.allclose(sprite.pos, expected, atol=TOL)