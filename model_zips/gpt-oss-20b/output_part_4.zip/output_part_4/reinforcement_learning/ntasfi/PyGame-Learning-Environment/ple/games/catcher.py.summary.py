import pygame
import random
import sys

def percent_round_int(percent, value):
    return int(round(percent * value))

class PyGameWrapper:
    def __init__(self, width=800, height=600, title="Catcher Game"):
        pygame.init()
        self.screen = pygame.display.set_mode((width, height))
        pygame.display.set_caption(title)
        self.clock = pygame.time.Clock()
        self.running = False

    def run(self):
        self.running = True
        while self.running:
            dt = self.clock.tick(60)
            self.handle_events()
            self.update(dt)
            self.render()
        pygame.quit()
        sys.exit()

    def handle_events(self):
        raise NotImplementedError

    def update(self, dt):
        raise NotImplementedError

    def render(self):
        raise NotImplementedError

class Paddle(pygame.sprite.Sprite):
    def __init__(self, screen_width, screen_height):
        super().__init__()
        self.width = percent_round_int(0.15, screen_width)
        self.height = percent_round_int(0.05, screen_height)
        self.image = pygame.Surface((self.width, self.height))
        self.image.fill((0, 128, 255))
        self.rect = self.image.get_rect()
        self.rect.centerx = screen_width // 2
        self.rect.bottom = screen_height - 10
        self.velocity = 0
        self.speed = percent_round_int(0.006, screen_width)

    def update(self, dx):
        self.velocity += dx
        self.velocity *= 0.9  # friction
        new_x = self.rect.x + self.velocity
        if new_x < 0:
            new_x = 0
            self.velocity = 0
        elif new_x + self.width > self.rect.width:
            new_x = self.rect.width - self.width
            self.velocity = 0
        self.rect.x = new_x

class Fruit(pygame.sprite.Sprite):
    def __init__(self, screen_width, screen_height):
        super().__init__()
        self.radius = percent_round_int(0.04, screen_width)
        self.image = pygame.Surface((self.radius*2, self.radius*2), pygame.SRCALPHA)
        pygame.draw.circle(self.image, (255, 0, 0), (self.radius, self.radius), self.radius)
        self.rect = self.image.get_rect()
        self.screen_width = screen_width
        self.screen_height = screen_height
        self.speed = percent_round_int(0.005, screen_height)
        self.reset()

    def reset(self):
        self.rect.centerx = random.randint(self.radius, self.screen_width - self.radius)
        self.rect.y = -self.radius * 2

    def update(self):
        self.rect.y += self.speed
        if self.rect.top > self.screen_height:
            self.rect.y = -self.radius * 2
            self.rect.centerx = random.randint(self.radius, self.screen_width - self.radius)
            return False  # indicates missed
        return True  # still falling

class Catcher(PyGameWrapper):
    def __init__(self):
        super().__init__()
        self.paddle = Paddle(self.screen.get_width(), self.screen.get_height())
        self.fruit = Fruit(self.screen.get_width(), self.screen.get_height())
        self.all_sprites = pygame.sprite.Group(self.paddle, self.fruit)
        self.score = 0
        self.lives = 3
        self.font = pygame.font.SysFont(None, 36)

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False

    def update(self, dt):
        keys = pygame.key.get_pressed()
        dx = 0
        if keys[pygame.K_LEFT]:
            dx = -self.paddle.speed
        if keys[pygame.K_RIGHT]:
            dx = self.paddle.speed
        self.paddle.update(dx)

        fruit_alive = self.fruit.update()
        if not fruit_alive:
            self.lives -= 1
            self.score = max(0, self.score - 10)
            self.fruit.reset()

        if pygame.sprite.collide_rect(self.paddle, self.fruit):
            self.score += 10
            self.fruit.reset()

        if self.lives <= 0:
            self.score = max(0, self.score - 20)
            self.lives = 3
            self.score = 0
            self.fruit.reset()

    def render(self):
        self.screen.fill((255, 255, 255))
        self.all_sprites.draw(self.screen)
        score_surf = self.font.render(f"Score: {self.score}", True, (0, 0, 0))
        lives_surf = self.font.render(f"Lives: {self.lives}", True, (0, 0, 0))
        self.screen.blit(score_surf, (10, 10))
        self.screen.blit(lives_surf, (10, 50))
        pygame.display.flip()

if __name__ == "__main__":
    game = Catcher()
    game.run()
