import torch
import torchvision.utils as vutils
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def plot_images_grid(
    images_tensor: torch.Tensor,
    nrow: int = 8,
    padding: int = 2,
    normalize: bool = False,
    pad_value: int = 0,
    title: str = '',
    export_img: str = 'output.png'
) -> None:
    """
    Arrange a 4D tensor of images (B x C x H x W) into a grid, display it,
    and save to a file.

    Parameters
    ----------
    images_tensor : torch.Tensor
        Input tensor containing images.
    nrow : int, optional
        Number of images per row in the grid.
    padding : int, optional
        Amount of padding between images.
    normalize : bool, optional
        Whether to normalize the image tensor.
    pad_value : int, optional
        Value for the padding pixels.
    title : str, optional
        Title for the plot.
    export_img : str, optional
        Path to save the exported image.
    """
    # 1. Grid creation
    grid_tensor = vutils.make_grid(
        images_tensor,
        nrow=nrow,
        padding=padding,
        normalize=normalize,
        pad_value=pad_value
    )

    # 2. Tensor conversion to NumPy
    grid_numpy = grid_tensor.cpu().detach().numpy()

    # 3. Dimension adjustment (C, H, W) -> (H, W, C)
    grid_numpy = np.transpose(grid_numpy, (1, 2, 0))

    # 4. Image display
    plt.figure()
    plt.imshow(grid_numpy, interpolation='nearest')
    plt.axis('off')

    # 5. Title handling
    if title:
        plt.title(title)

    # 6. Export
    plt.savefig(export_img, bbox_inches='tight', pad_inches=0.05)

    # 7. Cleanup
    plt.clf()
    plt.close()