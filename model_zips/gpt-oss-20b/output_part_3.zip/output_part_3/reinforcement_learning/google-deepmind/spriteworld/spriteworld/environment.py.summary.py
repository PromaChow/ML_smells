import dm_env
from typing import Any, Dict, Iterable, Callable, List

class SpriteworldEnvironment(dm_env.Environment):
    def __init__(
        self,
        task: Any,
        action_space: Any,
        renderers: Iterable[Any],
        init_sprites: Callable[[], List[Any]],
        max_episode_length: int = 200,
        keep_in_frame: bool = True,
    ) -> None:
        self.task = task
        self.action_space = action_space
        self.renderers = list(renderers)
        self.init_sprites = init_sprites
        self.max_episode_length = max_episode_length
        self.keep_in_frame = keep_in_frame

        self.sprites: List[Any] = self.init_sprites()
        self._step_count = 0
        self._obs_spec: Dict[str, Any] | None = None

    def reset(self) -> dm_env.TimeStep:
        self.sprites = self.init_sprites()
        self._step_count = 0
        obs = self.observation()
        return dm_env.restart(obs)

    def step(self, action: Any) -> dm_env.TimeStep:
        self.action_space.step(action, self.sprites, self.keep_in_frame)

        for sprite in self.sprites:
            if hasattr(sprite, "update_position"):
                sprite.update_position()

        reward = 0.0
        if hasattr(self.action_space, "reward"):
            reward += self.action_space.reward()
        if hasattr(self.task, "reward"):
            reward += self.task.reward()

        self._step_count += 1

        obs = self.observation()

        if self.should_terminate():
            return dm_env.termination(reward=reward, observation=obs)
        else:
            return dm_env.transition(reward=reward, observation=obs)

    def observation(self) -> Dict[str, Any]:
        obs: Dict[str, Any] = {}
        for renderer in self.renderers:
            if hasattr(renderer, "render"):
                renderer_output = renderer.render(self.sprites)
                if isinstance(renderer_output, dict):
                    obs.update(renderer_output)
                else:
                    obs[renderer.__class__.__name__] = renderer_output

        obs["success"] = self.task.success() if hasattr(self.task, "success") else False
        obs["metadata"] = (
            self.task.metadata() if hasattr(self.task, "metadata") else {}
        )
        return obs

    def observation_spec(self) -> Dict[str, Any]:
        if self._obs_spec is None:
            # Force an initial observation to set up renderer specs
            _ = self.observation()
            self._obs_spec = {}
            for renderer in self.renderers:
                if hasattr(renderer, "observation_spec"):
                    self._obs_spec.update(renderer.observation_spec())
        return self._obs_spec

    def should_terminate(self) -> bool:
        if self.task.success():
            return True
        if self._step_count >= self.max_episode_length:
            return True
        if not self.keep_in_frame:
            for sprite in self.sprites:
                if hasattr(sprite, "is_out_of_frame") and sprite.is_out_of_frame():
                    return True
        return False

    def state(self) -> Dict[str, Any]:
        sprite_states = []
        for sprite in self.sprites:
            if hasattr(sprite, "to_dict"):
                sprite_states.append(sprite.to_dict())
            else:
                sprite_states.append(str(sprite))
        return {
            "sprites": sprite_states,
            "success": self.task.success() if hasattr(self.task, "success") else False,
            "metadata": (
                self.task.metadata() if hasattr(self.task, "metadata") else {}
            ),
        }