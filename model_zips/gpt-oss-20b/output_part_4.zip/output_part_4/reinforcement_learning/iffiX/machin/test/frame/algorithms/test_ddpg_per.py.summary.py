import gym
import numpy as np
import torch
import torch.nn as nn
import pytest
from collections import deque

# Import DDPGPer and neural network utilities from rlkit
# If rlkit is not available, these imports will fail and the tests will error accordingly.
from rlkit.torch.networks.mlp import MLP
from rlkit.torch.networks.normalizer import Normalizer
from rlkit.algorithms.ddpg.ddpg_per import DDPGPer


# ---------- Actor and Critic definitions ----------
class Actor(nn.Module):
    def __init__(self, state_dim: int, action_dim: int, hidden_sizes=(256, 256, 256)):
        super().__init__()
        self.net = MLP(state_dim, action_dim, hidden_sizes, output_activation=nn.Tanh)

    def forward(self, state):
        return self.net(state)


class Critic(nn.Module):
    def __init__(self, state_dim: int, action_dim: int, hidden_sizes=(256, 256, 256)):
        super().__init__()
        # Critic takes concatenated state-action as input
        self.net = MLP(state_dim + action_dim, 1, hidden_sizes, output_activation=None)

    def forward(self, state, action):
        sa = torch.cat([state, action], dim=-1)
        return self.net(sa)


# ---------- Fixtures ----------
@pytest.fixture
def train_config():
    env = gym.make("Pendulum-v0")
    env.render(mode="human")  # GUI disabled by default in gym but included for completeness
    config = {
        "env": env,
        "max_episodes": 1000,
        "replay_size": 100000,
        "batch_size": 64,
        "lr": 1e-3,
        "gamma": 0.99,
        "tau": 0.005,
        "noise_param": (0, 0.2),
        "noise_interval": 1,
        "device": torch.device("cuda" if torch.cuda.is_available() else "cpu"),
    }
    return config


@pytest.fixture
def ddpg_per(ddpg_per_train):
    # Standard configuration
    return ddpg_per_train


@pytest.fixture
def ddpg_per_vis(ddpg_per_train):
    # Visualization configuration (placeholder)
    return ddpg_per_train


@pytest.fixture
def ddpg_per_train(train_config):
    env = train_config["env"]
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.shape[0]
    actor = Actor(state_dim, action_dim)
    critic = Critic(state_dim, action_dim)

    # Normalizer for state input
    normalizer = Normalizer(state_dim)

    ddpg = DDPGPer(
        env=env,
        actor=actor,
        critic=critic,
        actor_lr=train_config["lr"],
        critic_lr=train_config["lr"],
        gamma=train_config["gamma"],
        tau=train_config["tau"],
        replay_size=train_config["replay_size"],
        batch_size=train_config["batch_size"],
        noise_param=train_config["noise_param"],
        noise_interval=train_config["noise_interval"],
        normalizer=normalizer,
        device=train_config["device"],
    )
    return ddpg


# ---------- Tests ----------
def test_criterion_reduction_property(ddpg_per_train):
    """Test that DDPGPer enforces a loss criterion with a reduction property."""
    class DummyCriterion:
        def __call__(self, *args, **kwargs):
            return torch.tensor(0.0)

    # Replace criterion in the critic's loss function
    with pytest.raises(RuntimeError):
        ddpg_per_train.criterion = DummyCriterion()


def test_update_functionality(ddpg_per_train):
    """Test partial updates and sample concatenation."""
    env = ddpg_per_train.env
    # Create synthetic episode: 3 steps of zero state/action/reward
    states = [np.zeros(env.observation_space.shape) for _ in range(3)]
    actions = [np.zeros(env.action_space.shape) for _ in range(3)]
    rewards = [0.0 for _ in range(3)]
    next_states = [np.zeros(env.observation_space.shape) for _ in range(3)]
    dones = [False, False, True]

    ddpg_per_train.store_episode(
        states, actions, rewards, next_states, dones
    )

    # Ensure buffer has data
    assert len(ddpg_per_train.replay_buffer) >= 3

    # Update with different flags
    ddpg_per_train.update(
        update_value=True, update_policy=False, update_target=False
    )
    ddpg_per_train.update(
        update_value=False, update_policy=True, update_target=False
    )
    ddpg_per_train.update(
        update_value=False, update_policy=False, update_target=True
    )


def test_config_and_initialization(ddpg_per_train):
    """Test DDPGPer.generate_config and initialization."""
    config = ddpg_per_train.generate_config()
    config["Actor"] = Actor
    config["Critic"] = Critic

    ddpg = DDPGPer.from_config(config)

    env = ddpg.env
    # Store synthetic episode
    states = [np.zeros(env.observation_space.shape) for _ in range(3)]
    actions = [np.zeros(env.action_space.shape) for _ in range(3)]
    rewards = [0.0 for _ in range(3)]
    next_states = [np.zeros(env.observation_space.shape) for _ in range(3)]
    dones = [False, False, True]
    ddpg.store_episode(states, actions, rewards, next_states, dones)

    # Perform update
    ddpg.update(update_value=True, update_policy=True, update_target=True)


@pytest.mark.skipif(not sys.platform.startswith("linux"), reason="Linux-only test")
def test_full_training(train_config):
    """Run a full training loop on Pendulum-v0."""
    env = train_config["env"]
    max_episodes = train_config["max_episodes"]
    device = train_config["device"]
    noise_interval = train_config["noise_interval"]
    noise_param = train_config["noise_param"]

    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.shape[0]
    actor = Actor(state_dim, action_dim)
    critic = Critic(state_dim, action_dim)
    normalizer = Normalizer(state_dim)

    ddpg = DDPGPer(
        env=env,
        actor=actor,
        critic=critic,
        actor_lr=train_config["lr"],
        critic_lr=train_config["lr"],
        gamma=train_config["gamma"],
        tau=train_config["tau"],
        replay_size=train_config["replay_size"],
        batch_size=train_config["batch_size"],
        noise_param=noise_param,
        noise_interval=noise_interval,
        normalizer=normalizer,
        device=device,
    )

    reward_history = []
    solved = False
    consecutive_solved = 0

    for episode in range(max_episodes):
        state = env.reset()
        total_reward = 0.0
        done = False
        step = 0
        while not done:
            state_tensor = torch.tensor(state, dtype=torch.float32).to(device)
            with torch.no_grad():
                action = ddpg.actor(state_tensor).cpu().numpy()
            if step % noise_interval == 0:
                noise = np.random.normal(*noise_param, size=action_dim)
                action = (action + noise).clip(env.action_space.low, env.action_space.high)
            next_state, reward, done, _ = env.step(action)
            total_reward += reward
            ddpg.store_transition(state, action, reward, next_state, done)
            state = next_state
            step += 1

        reward_history.append(total_reward)

        # Start training after 100 episodes
        if episode >= 100 and len(ddpg.replay_buffer) >= ddpg.batch_size:
            ddpg.update(update_value=True, update_policy=True, update_target=True)

        # Check if solved
        if len(reward_history) >= 5:
            if np.mean(reward_history[-5:]) > -400:
                consecutive_solved += 1
            else:
                consecutive_solved = 0
        if consecutive_solved >= 5:
            solved = True
            break

    assert solved, f"Pendulum not solved after {max_episodes} episodes. Last reward: {reward_history[-1]}"