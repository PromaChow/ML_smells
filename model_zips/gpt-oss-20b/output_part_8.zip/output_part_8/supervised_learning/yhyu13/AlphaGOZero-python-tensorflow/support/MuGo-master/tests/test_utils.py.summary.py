import unittest
import numpy as np
import random
import re
import time

# Go constants
EMPTY = 0
BLACK = 1
WHITE = 2

class Go:
    _size = 9
    @classmethod
    def set_board_size(cls, size):
        cls._size = size

    @classmethod
    def size(cls):
        return cls._size

def load_board(board_str):
    size = Go.size()
    expected_len = size * size
    if len(board_str) != expected_len:
        raise ValueError(f"Board string length {len(board_str)} does not match expected {expected_len}")
    mapping = {'.': EMPTY, 'X': BLACK, 'O': WHITE}
    board = np.empty((size, size), dtype=int)
    for idx, ch in enumerate(board_str):
        if ch not in mapping:
            raise ValueError(f"Invalid board character: {ch}")
        row = idx // size
        col = idx % size
        board[row, col] = mapping[ch]
    return board

# Coordinate utilities
def sgf_to_coord(sgf):
    if len(sgf) != 2:
        raise ValueError(f"Invalid SGF coordinate: {sgf}")
    col = ord(sgf[0]) - ord('a')
    row = ord(sgf[1]) - ord('a')
    return (row, col)

def coord_to_sgf(coord):
    row, col = coord
    return chr(ord('a') + col) + chr(ord('a') + row)

def kgs_to_coord(kgs):
    if len(kgs) < 2:
        raise ValueError(f"Invalid KGS coordinate: {kgs}")
    col_char = kgs[0]
    row_num = int(kgs[1:])
    size = Go.size()
    col = ord(col_char.upper()) - ord('A')
    row = size - row_num
    return (row, col)

def coord_to_kgs(coord):
    row, col = coord
    size = Go.size()
    col_char = chr(ord('A') + col)
    row_num = size - row
    return f"{col_char}{row_num}"

def pygtp_to_coord(pygtp):
    row, col = pygtp
    size = Go.size()
    return (size - row, col - 1)

def coord_to_pygtp(coord):
    row, col = coord
    size = Go.size()
    return (size - row, col + 1)

def flatten_coord(coord):
    row, col = coord
    return row * Go.size() + col

def unflatten_coord(index):
    size = Go.size()
    row = index // size
    col = index % size
    return (row, col)

def shuffler(iterable):
    random.seed(1)
    return list(random.sample(list(iterable), len(iterable)))

def parse_game_result(result_str):
    m = re.match(r'^[BW]\+([0-9.]+|T)$', result_str.strip())
    if not m:
        return None
    return BLACK if result_str[0] == 'B' else WHITE

# Minimal liberty tracker structures for testing
class LibertyTracker:
    def __init__(self):
        self.group_ids = {}          # (row, col) -> group id
        self.group_liberties = {}    # group id -> set of liberties
        self.group_stones = {}       # group id -> list of (row, col)

    def add_group(self, group_id, stones, liberties):
        self.group_ids.update({stone: group_id for stone in stones})
        self.group_liberties[group_id] = set(liberties)
        self.group_stones[group_id] = list(stones)

class GoPosition:
    def __init__(self, board=None, liberty_tracker=None, move_count=0, captures=None, ko=None, history=None):
        self.board = board if board is not None else np.full((Go.size(), Go.size()), EMPTY, dtype=int)
        self.liberty_tracker = liberty_tracker if liberty_tracker is not None else LibertyTracker()
        self.move_count = move_count
        self.captures = captures if captures is not None else {BLACK:0, WHITE:0}
        self.ko = ko
        self.history = history if history is not None else []

class GoPositionTestCase(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls._start_time = time.time()

    @classmethod
    def tearDownClass(cls):
        duration = time.time() - cls._start_time
        print(f"{cls.__name__} executed in {duration:.3f}s")

    def assertEqualNPArray(self, a, b, msg=None):
        if not np.array_equal(a, b):
            standardMsg = f"Arrays are not equal\n{a}\n!=\n{b}"
            self.fail(self._formatMessage(msg, standardMsg))

    def assertEqualLibertyTracker(self, lt1, lt2, msg=None):
        # Map group ids by their stones to compare
        map1 = {frozenset(lt1.group_stones[g]): g for g in lt1.group_ids.values()}
        map2 = {frozenset(lt2.group_stones[g]): g for g in lt2.group_ids.values()}
        if set(map1.keys()) != set(map2.keys()):
            self.fail(self._formatMessage(msg, "Group stone sets differ"))
        for stone_set in map1:
            g1 = map1[stone_set]
            g2 = map2[stone_set]
            if lt1.group_liberties[g1] != lt2.group_liberties[g2]:
                self.fail(self._formatMessage(msg, f"Liberties differ for group {stone_set}"))

    def assertEqualPosition(self, pos1, pos2, msg=None):
        self.assertEqualNPArray(pos1.board, pos2.board)
        self.assertEqualLibertyTracker(pos1.liberty_tracker, pos2.liberty_tracker)
        self.assertEqual(pos1.move_count, pos2.move_count, msg)
        self.assertEqual(pos1.captures, pos2.captures, msg)
        self.assertEqual(pos1.ko, pos2.ko, msg)
        self.assertEqual(pos1.history, pos2.history, msg)

class TestBoardLoading(GoPositionTestCase):
    def test_load_board_valid(self):
        Go.set_board_size(9)
        s = "X" * 81
        board = load_board(s)
        self.assertTrue(np.all(board == BLACK))
    def test_load_board_invalid_length(self):
        Go.set_board_size(9)
        s = "X" * 80
        with self.assertRaises(ValueError):
            load_board(s)

class TestCoordinateParsing(GoPositionTestCase):
    def test_sgf(self):
        self.assertEqual(sgf_to_coord('aa'), (0,0))
        self.assertEqual(coord_to_sgf((3,2)), 'cd')
    def test_kgs(self):
        self.assertEqual(kgs_to_coord('A1'), (8,0))
        self.assertEqual(coord_to_kgs((0,8)), 'I9')
    def test_pygtp(self):
        self.assertEqual(pygtp_to_coord((1,1)), (8,0))
        self.assertEqual(coord_to_pygtp((4,3)), (5,4))
    def test_flatten(self):
        self.assertEqual(flatten_coord((3,0)), 27)
        self.assertEqual(unflatten_coord(27), (3,0))

class TestShuffler(GoPositionTestCase):
    def test_shuffler_reproducible(self):
        seq = list(range(10))
        shuffled = shuffler(seq)
        self.assertNotEqual(seq, shuffled)
        self.assertEqual(shuffler(seq), shuffled)  # same seed gives same result

class TestGameResult(GoPositionTestCase):
    def test_parse_game_result(self):
        self.assertEqual(parse_game_result('B+3.5'), BLACK)
        self.assertEqual(parse_game_result('W+T'), WHITE)
        self.assertIsNone(parse_game_result('C+1'))

class TestPositionComparison(GoPositionTestCase):
    def setUp(self):
        Go.set_board_size(9)
        self.board1 = np.full((9,9), EMPTY, dtype=int)
        self.board1[0,0] = BLACK
        self.board1[1,1] = WHITE
        lt1 = LibertyTracker()
        lt1.add_group(1, [(0,0)], [(0,1),(1,0)])
        lt1.add_group(2, [(1,1)], [(0,1),(2,1)])
        self.pos1 = GoPosition(board=self.board1, liberty_tracker=lt1, move_count=5,
                               captures={BLACK:2, WHITE:1}, ko=(4,4), history=[(0,0)])
        # Clone pos2 with same logical state but different group ids
        board2 = self.board1.copy()
        lt2 = LibertyTracker()
        lt2.add_group(10, [(0,0)], [(0,1),(1,0)])
        lt2.add_group(20, [(1,1)], [(0,1),(2,1)])
        self.pos2 = GoPosition(board=board2, liberty_tracker=lt2, move_count=5,
                               captures={BLACK:2, WHITE:1}, ko=(4,4), history=[(0,0)])
    def test_position_equality(self):
        self.assertEqualPosition(self.pos1, self.pos2)

if __name__ == "__main__":
    unittest.main()