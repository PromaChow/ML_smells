import random
import numpy as np
import gym
import pytest

from machin.env.wrappers.openai_gym import ParallelWrapperDummy, ParallelWrapperSubProc
from machin.util.testing import linux_only_forall

ENV_NAME = "CartPole-v0"
ENV_NUM = 2
SAMPLE_NUM = 1


@pytest.fixture
def envs():
    def make_env():
        return gym.make(ENV_NAME)

    return [make_env for _ in range(ENV_NUM)]


@pytest.fixture
def wrappers(envs):
    return {
        "dummy": ParallelWrapperDummy(envs),
        "subproc": ParallelWrapperSubProc(envs),
    }


def index_cases():
    yield None
    for _ in range(ENV_NUM):
        yield [_]
    yield random.sample(range(ENV_NUM), SAMPLE_NUM)
    yield [i for i in range(ENV_NUM)]


@linux_only_forall()
@pytest.mark.parametrize("wrapper_type", ["dummy", "subproc"])
def test_reset(envs, wrappers, wrapper_type):
    wrapper = wrappers[wrapper_type]
    env = gym.make(ENV_NAME)
    for idxs in index_cases():
        obs = wrapper.reset(idxs)
        if idxs is None:
            assert isinstance(obs, np.ndarray) or isinstance(obs, list)
            if isinstance(obs, np.ndarray):
                assert obs.shape[0] == ENV_NUM
            else:
                assert len(obs) == ENV_NUM
        else:
            assert isinstance(obs, np.ndarray) or isinstance(obs, list)
            if isinstance(obs, np.ndarray):
                assert obs.shape[0] == len(idxs)
            else:
                assert len(obs) == len(idxs)
        # check observation space conformity
        if isinstance(obs, np.ndarray):
            for o in obs:
                assert env.observation_space.contains(o)
        else:
            for o in obs:
                assert env.observation_space.contains(o)


@linux_only_forall()
@pytest.mark.parametrize("wrapper_type", ["dummy", "subproc"])
def test_step(envs, wrappers, wrapper_type):
    wrapper = wrappers[wrapper_type]
    env = gym.make(ENV_NAME)
    for idxs in index_cases():
        actions = []
        for _ in idxs if idxs is not None else range(ENV_NUM):
            if isinstance(env.action_space, gym.spaces.Discrete):
                actions.append(env.action_space.sample())
            else:
                actions.append(env.action_space.sample())
        obs, rewards, dones, infos = wrapper.step(actions, idxs)
        # Length checks
        if idxs is None:
            expected_len = ENV_NUM
        else:
            expected_len = len(idxs)
        assert len(obs) == expected_len
        assert len(rewards) == expected_len
        assert len(dones) == expected_len
        assert len(infos) == expected_len
        # Observation space
        for o in obs:
            assert env.observation_space.contains(o)
        # Reward type
        for r in rewards:
            assert isinstance(r, (int, float))
        # Done type
        for d in dones:
            assert isinstance(d, bool)
        # Info type
        for inf in infos:
            assert isinstance(inf, dict)


@linux_only_forall()
@pytest.mark.parametrize("wrapper_type", ["dummy", "subproc"])
def test_seed(envs, wrappers, wrapper_type):
    wrapper = wrappers[wrapper_type]
    for idxs in index_cases():
        seeds = wrapper.seed(seed=42, idxs=idxs)
        if idxs is None:
            expected_len = ENV_NUM
        else:
            expected_len = len(idxs)
        assert len(seeds) == expected_len
        for s in seeds:
            assert isinstance(s, int)


@linux_only_forall()
@pytest.mark.parametrize("wrapper_type", ["dummy", "subproc"])
def test_render(envs, wrappers, wrapper_type):
    wrapper = wrappers[wrapper_type]
    for idxs in index_cases():
        frames = wrapper.render(idxs, mode="rgb_array")
        if idxs is None:
            expected_len = ENV_NUM
        else:
            expected_len = len(idxs)
        assert isinstance(frames, list) or isinstance(frames, np.ndarray)
        if isinstance(frames, np.ndarray):
            assert frames.shape[0] == expected_len
            for f in frames:
                assert isinstance(f, np.ndarray)
                assert f.ndim == 3
                assert f.shape[2] == 3
        else:
            assert len(frames) == expected_len
            for f in frames:
                assert isinstance(f, np.ndarray)
                assert f.ndim == 3
                assert f.shape[2] == 3


@linux_only_forall()
@pytest.mark.parametrize("wrapper_type", ["dummy", "subproc"])
def test_close(envs, wrappers, wrapper_type):
    wrapper = wrappers[wrapper_type]
    wrapper.close()


@linux_only_forall()
@pytest.mark.parametrize("wrapper_type", ["dummy", "subproc"])
def test_active(envs, wrappers, wrapper_type):
    wrapper = wrappers[wrapper_type]
    active_status = wrapper.active()
    assert isinstance(active_status, list)
    assert len(active_status) == ENV_NUM
    for status in active_status:
        assert isinstance(status, bool)


@linux_only_forall()
@pytest.mark.parametrize("wrapper_type", ["dummy", "subproc"])
def test_size(envs, wrappers, wrapper_type):
    wrapper = wrappers[wrapper_type]
    size = wrapper.size()
    assert size == ENV_NUM
