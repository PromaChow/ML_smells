import numpy as np
import pandas as pd
from statsmodels.tsa.api import VAR

def softmax(x: np.ndarray) -> np.ndarray:
    """Compute softmax values for each set of scores in x."""
    e_x = np.exp(x - np.max(x, axis=-1, keepdims=True))
    return e_x / e_x.sum(axis=-1, keepdims=True)

class VARAgent:
    def __init__(self, df: pd.DataFrame, max_order: int, policy: str = "softmax"):
        """
        Initialize the VAR-based agent.

        Parameters
        ----------
        df : pd.DataFrame
            Historical returns data.
        max_order : int
            Maximum lag order for the VAR model.
        policy : str, optional
            Decision policy ('softmax' or 'best'). Defaults to 'softmax'.
        """
        self.df = df.copy()
        self.max_order = max_order
        self.policy = policy.lower()
        self.var_result = VAR(self.df).fit(maxlags=self.max_order, ic="aic")
        self.memory = pd.DataFrame(columns=self.df.columns)

    def observe(self, observation: dict, next_observation: dict):
        """
        Append the returns from the current and next observations to memory.

        Parameters
        ----------
        observation : dict
            Contains a 'returns' key with a DataFrame or Series of returns.
        next_observation : dict
            Contains a 'returns' key with a DataFrame or Series of returns.
        """
        returns_current = observation.get("returns")
        returns_next = next_observation.get("returns")
        if returns_current is not None:
            self.memory = pd.concat([self.memory, returns_current], ignore_index=True)
        if returns_next is not None:
            self.memory = pd.concat([self.memory, returns_next], ignore_index=True)

    def act(self, observation: dict) -> pd.Series:
        """
        Generate an action distribution based on the current observation.

        Parameters
        ----------
        observation : dict
            Current observation data (not used directly for forecasting).

        Returns
        -------
        pd.Series
            Probability distribution over actions.
        """
        # Determine forecasted returns
        if self.memory.empty or len(self.memory) < self.max_order:
            # Use random uniform values matching the shape of the VAR coefficients
            forecast_values = np.random.uniform(
                low=0, high=1, size=self.var_result.params.shape[0]
            )
        else:
            # Use the latest `max_order` rows for forecasting
            recent = self.memory.tail(self.max_order).values
            # Statsmodels expects shape (n_obs, k_vars); ensure correct shape
            if recent.ndim == 1:
                recent = recent.reshape(1, -1)
            forecast = self.var_result.forecast(recent, steps=1)
            forecast_values = forecast[0]

        # Convert forecast to Series with appropriate index
        if len(forecast_values) == len(self.df.columns):
            forecast_series = pd.Series(forecast_values, index=self.df.columns)
        else:
            # If dimensions mismatch, flatten and use generic indices
            forecast_series = pd.Series(forecast_values)

        # Apply policy
        if self.policy == "softmax":
            probs = softmax(forecast_series.values)
            action_distribution = pd.Series(probs, index=forecast_series.index)
        elif self.policy == "best":
            idx = np.argmax(forecast_series.values)
            probs = np.zeros_like(forecast_series.values)
            probs[idx] = 1.0
            action_distribution = pd.Series(probs, index=forecast_series.index)
        else:
            raise ValueError(f"Unsupported policy: {self.policy}")

        return action_distribution
