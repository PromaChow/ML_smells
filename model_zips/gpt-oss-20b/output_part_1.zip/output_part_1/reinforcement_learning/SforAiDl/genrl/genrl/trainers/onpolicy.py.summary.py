import os
import json
import csv
import logging
from pathlib import Path

import numpy as np
import torch
from torch.utils.tensorboard import SummaryWriter


class Trainer:
    def __init__(
        self,
        env,
        agent,
        epochs,
        rollout_size,
        log_interval=10,
        save_interval=50,
        render=False,
        max_timesteps=None,
        save_model="checkpoints",
        load_weights=None,
        load_hyperparams=None,
        logger=None,
    ):
        self.env = env
        self.agent = agent
        self.epochs = epochs
        self.rollout_size = rollout_size
        self.log_interval = log_interval
        self.save_interval = save_interval
        self.render = render
        self.max_timesteps = max_timesteps
        self.save_model = Path(save_model)
        self.load_weights = load_weights
        self.load_hyperparams = load_hyperparams
        self.logger = logger or self._setup_logger()
        self.tb_writer = SummaryWriter() if hasattr(agent, "tensorboard") else None

    def _setup_logger(self):
        logger = logging.getLogger("OnPolicyTrainer")
        logger.setLevel(logging.INFO)
        handler = logging.StreamHandler()
        formatter = logging.Formatter("[%(asctime)s] %(levelname)s:%(name)s: %(message)s")
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        return logger

    def load(self):
        if self.load_weights and os.path.exists(self.load_weights):
            state_dict = torch.load(self.load_weights, map_location="cpu")
            self.agent.load_state_dict(state_dict)
            self.logger.info(f"Loaded weights from {self.load_weights}")
        if self.load_hyperparams and os.path.exists(self.load_hyperparams):
            with open(self.load_hyperparams, "r") as f:
                hyperparams = json.load(f)
            for k, v in hyperparams.items():
                setattr(self.agent, k, v)
            self.logger.info(f"Loaded hyperparameters from {self.load_hyperparams}")

    def train(self):
        self.load()
        os.makedirs(self.save_model, exist_ok=True)
        csv_path = self.save_model / "train_log.csv"
        csv_exists = csv_path.exists()
        with csv_path.open("a", newline="") as csvfile:
            writer = csv.DictWriter(
                csvfile,
                fieldnames=[
                    "timestep",
                    "epoch",
                    *(
                        self.agent.get_logging_params().keys()
                        if hasattr(self.agent, "get_logging_params")
                        else []
                    ),
                ],
            )
            if not csv_exists:
                writer.writeheader()

            for epoch in range(1, self.epochs + 1):
                # Epoch initialization
                if hasattr(self.agent, "epoch_reward"):
                    self.agent.epoch_reward = np.zeros(self.env.num_envs)
                if hasattr(self.agent, "rollout") and hasattr(self.agent.rollout, "clear"):
                    self.agent.rollout.clear()

                # Environment reset
                state = self.env.reset()

                # Rollout collection
                self.agent.collect_rollouts(state)

                # Loss calculation
                values = (
                    self.agent.get_values()
                    if hasattr(self.agent, "get_values")
                    else None
                )
                done = (
                    self.agent.done
                    if hasattr(self.agent, "done")
                    else self.env.dones
                )
                loss = self.agent.get_traj_loss(values, done)

                # Parameter update
                self.agent.update_params(loss)

                # Logging
                if epoch % self.log_interval == 0:
                    timestep = epoch * self.rollout_size
                    log_params = (
                        self.agent.get_logging_params()
                        if hasattr(self.agent, "get_logging_params")
                        else {}
                    )
                    row = {"timestep": timestep, "epoch": epoch, **log_params}
                    writer.writerow(row)
                    csvfile.flush()
                    self.logger.info(f"Epoch {epoch} - {log_params}")

                    if self.tb_writer:
                        for key, val in log_params.items():
                            self.tb_writer.add_scalar(key, val, step=timestep)

                # Rendering
                if self.render:
                    self.env.render()

                # Early termination
                if self.max_timesteps and epoch * self.rollout_size > self.max_timesteps:
                    self.logger.info("Reached max timesteps, stopping training.")
                    break

                # Model saving
                if epoch % self.save_interval == 0:
                    checkpoint_path = self.save_model / f"checkpoint_epoch_{epoch}.pt"
                    torch.save(self.agent.state_dict(), checkpoint_path)
                    self.logger.info(f"Saved checkpoint to {checkpoint_path}")

        self.env.close()
        if self.tb_writer:
            self.tb_writer.close()
        self.logger.info("Training finished.")