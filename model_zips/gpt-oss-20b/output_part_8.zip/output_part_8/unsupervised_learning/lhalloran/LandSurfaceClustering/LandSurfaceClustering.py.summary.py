import os
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt
import imageio

# User-defined parameters
IMAGE_FOLDER = 'path_to_folder'
FILE_FORMAT = 'tif'  # e.g., 'tif', 'png', 'jpg'
BAND_NAMES = ['band1', 'band2', 'band3']  # names matching file prefixes
NUM_SAMPLES = 10000
NUM_CLUSTERS = 5
CMAP = 'tab20'

def load_band_images(folder, file_format, band_names):
    images = {}
    for band in band_names:
        path = os.path.join(folder, f"{band}.{file_format}")
        if not os.path.exists(path):
            raise FileNotFoundError(f"Band file not found: {path}")
        img = imageio.imread(path)
        if img.ndim == 3:
            img = img[:, :, 0]
        images[band] = img.astype(np.float32) / 256.0
    return images

def build_image_cube(images, band_names):
    arrs = [images[band] for band in band_names]
    cube = np.stack(arrs, axis=2)
    return cube

def sample_pixels(cube, n_samples):
    h, w, _ = cube.shape
    pixels = cube.reshape(-1, cube.shape[2])
    idx = np.random.choice(pixels.shape[0], size=n_samples, replace=False)
    samples = pixels[idx]
    return pd.DataFrame(samples, columns=band_names)

def apply_clustering(cube, kmeans):
    h, w, _ = cube.shape
    pixels = cube.reshape(-1, cube.shape[2])
    labels = kmeans.predict(pixels)
    return labels.reshape(h, w)

def visualize_clusters(labels, cmap):
    plt.figure(figsize=(8, 6))
    plt.imshow(labels, cmap=cmap)
    plt.title("Land Surface Clustering")
    plt.colorbar(label='Cluster')
    plt.axis('off')
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    images = load_band_images(IMAGE_FOLDER, FILE_FORMAT, BAND_NAMES)
    image_cube = build_image_cube(images, BAND_NAMES)
    df_samples = sample_pixels(image_cube, NUM_SAMPLES)
    # import seaborn as sns
    # sns.pairplot(df_samples)
    kmeans = KMeans(n_clusters=NUM_CLUSTERS, random_state=42)
    kmeans.fit(df_samples)
    cluster_labels = apply_clustering(image_cube, kmeans)
    visualize_clusters(cluster_labels, CMAP)