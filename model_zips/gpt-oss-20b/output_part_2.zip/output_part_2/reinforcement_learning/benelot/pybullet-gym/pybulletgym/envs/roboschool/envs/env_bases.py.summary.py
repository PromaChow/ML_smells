import gym
import numpy as np
import pybullet
import pybullet_data


class BaseBulletEnv(gym.Env):
    def __init__(
        self,
        robot,
        render: bool = False,
        seed: int | None = None,
        camera_position=(0.0, 0.0, 1.0),
        camera_yaw=0.0,
        camera_pitch=-30.0,
        resolution=(800, 600),
    ):
        super().__init__()
        self.robot = robot
        self.render_mode = render
        self.seed(seed)
        self.client_id = pybullet.connect(pybullet.GUI if render else pybullet.DIRECT)
        pybullet.setAdditionalSearchPath(pybullet_data.getDataPath())
        self.camera_position = np.array(camera_position, dtype=float)
        self.camera_yaw = camera_yaw
        self.camera_pitch = camera_pitch
        self.resolution = resolution
        self.action_space = robot.action_space
        self.observation_space = robot.observation_space
        self._initialize_scene()

    def _initialize_scene(self):
        pybullet.setGravity(0, 0, -9.81, physicsClientId=self.client_id)
        pybullet.loadURDF("plane.urdf", physicsClientId=self.client_id)
        if hasattr(self.robot, "load"):
            self.robot.load(self.client_id)
        if hasattr(self.robot, "reset"):
            self.robot.reset()

    def configure(self, **kwargs):
        if hasattr(self.robot, "configure"):
            self.robot.configure(**kwargs)

    def _seed(self, seed: int | None = None):
        if seed is None:
            seed = np.random.randint(0, 2**32 - 1)
        self.np_random = np.random.RandomState(seed)
        if hasattr(self.robot, "randomizer") and hasattr(self.robot.randomizer, "seed"):
            self.robot.randomizer.seed(seed)
        return seed

    def _reset(self):
        if not hasattr(self, "client_id"):
            self.client_id = pybullet.connect(pybullet.GUI if self.render_mode else pybullet.DIRECT)
            pybullet.setAdditionalSearchPath(pybullet_data.getDataPath())
            self._initialize_scene()
        self._initialize_scene()
        if hasattr(self.robot, "reset"):
            self.robot.reset()
        base_pos, _ = pybullet.getBasePositionAndOrientation(
            self.robot.id if hasattr(self.robot, "id") else -1,
            physicsClientId=self.client_id,
        )
        mass = (
            pybullet.getDynamicsInfo(
                self.robot.id if hasattr(self.robot, "id") else -1, -1, physicsClientId=self.client_id
            )[0]
            if hasattr(self.robot, "id")
            else 0
        )
        potential_energy = mass * 9.81 * base_pos[2]
        self._potential_energy = potential_energy
        if hasattr(self.robot, "get_observation"):
            return self.robot.get_observation()
        return np.zeros(self.observation_space.shape)

    def _step(self, action):
        if hasattr(self.robot, "step"):
            observation, reward, done, info = self.robot.step(action)
        else:
            observation = np.zeros(self.observation_space.shape)
            reward = 0.0
            done = False
            info = {}
        return observation, reward, done, info

    def _render(self, mode="rgb_array"):
        if mode != "rgb_array":
            return None
        view_matrix = pybullet.computeViewMatrixFromYawPitchRoll(
            self.camera_position,
            distance=2.0,
            yaw=self.camera_yaw,
            pitch=self.camera_pitch,
            roll=0.0,
            upAxisIndex=2,
            physicsClientId=self.client_id,
        )
        projection_matrix = pybullet.computeProjectionMatrixFOV(
            fov=60,
            aspect=self.resolution[0] / self.resolution[1],
            nearVal=0.1,
            farVal=100.0,
            physicsClientId=self.client_id,
        )
        _, _, rgb, _, _ = pybullet.getCameraImage(
            self.resolution[0],
            self.resolution[1],
            viewMatrix=view_matrix,
            projectionMatrix=projection_matrix,
            renderer=pybullet.ER_TINY_RENDERER,
            physicsClientId=self.client_id,
        )
        rgb_arr = np.array(rgb, dtype=np.uint8).reshape(
            (self.resolution[1], self.resolution[0], 4)
        )[:, :, :3]
        return rgb_arr

    def _close(self):
        if hasattr(self, "client_id"):
            pybullet.disconnect(self.client_id)
            del self.client_id

    def HUD(self):
        pass

    # Compatibility overrides
    def step(self, action):
        return self._step(action)

    def reset(self, *, seed=None, options=None):
        if seed is not None:
            self.seed(seed)
        return self._reset()

    def seed(self, seed=None):
        return self._seed(seed)

    def close(self):
        self._close()


class Camera:
    def __init__(self, client_id: int):
        self.client_id = client_id

    def move_and_look_at(self, target, distance=2.0, yaw=0.0, pitch=-30.0):
        pybullet.resetDebugVisualizerCamera(
            cameraDistance=distance,
            cameraYaw=yaw,
            cameraPitch=pitch,
            cameraTargetPosition=target,
            physicsClientId=self.client_id,
        )
        view_matrix = pybullet.computeViewMatrixFromYawPitchRoll(
            target,
            distance=distance,
            yaw=yaw,
            pitch=pitch,
            roll=0.0,
            upAxisIndex=2,
            physicsClientId=self.client_id,
        )
        return view_matrix
