import unittest
import numpy as np
import chainer
from chainer import Chain, Variable, Parameter
from chainer.links import Linear
from chainer import copy_param


def set_random_grad(link):
    for name, param in link.params().items():
        if isinstance(param, chainer.Parameter):
            param.grad = np.random.rand(*param.shape).astype(np.float32)
        else:
            # For scalar parameters
            param.grad = np.array([np.random.rand()], dtype=np.float32)


class TestCopyParam(unittest.TestCase):
    def test_copy_param(self):
        a = Linear(10, 5)
        b = Linear(10, 5)
        x = np.random.randn(3, 10).astype(np.float32)
        out_a = a(Variable(x)).data
        out_b = b(Variable(x)).data
        self.assertFalse(np.allclose(out_a, out_b))
        copy_param.copy_param(b, a)
        out_a2 = a(Variable(x)).data
        out_b2 = b(Variable(x)).data
        self.assertTrue(np.allclose(out_a2, out_b2))

    def test_copy_param_scalar(self):
        class ScalarChain(Chain):
            def __init__(self, value):
                super().__init__()
                self.x = Parameter(np.array([value], dtype=np.float32))

        a = ScalarChain(2.0)
        b = ScalarChain(3.0)
        self.assertFalse(np.allclose(a.x.data, b.x.data))
        copy_param.copy_param(b, a)
        self.assertTrue(np.allclose(a.x.data, b.x.data))

    def test_copy_param_type_check(self):
        class DummyLink(Chain):
            def __init__(self):
                super().__init__()

        a = DummyLink()
        b = Linear(10, 5)
        with self.assertRaises(TypeError):
            copy_param.copy_param(b, a)

    def test_soft_copy_param(self):
        a = Linear(10, 5)
        b = Linear(10, 5)
        a.W.data.fill(0.5)
        b.W.data.fill(1.0)
        copy_param.soft_copy_param(b, a, tau=0.1)
        expected = 0.5 * 0.9 + 1.0 * 0.1
        self.assertTrue(np.allclose(a.W.data, expected))
        self.assertTrue(np.allclose(b.W.data, 1.0))
        copy_param.soft_copy_param(b, a, tau=0.1)
        expected = expected * 0.9 + 1.0 * 0.1
        self.assertTrue(np.allclose(a.W.data, expected))
        self.assertTrue(np.allclose(b.W.data, 1.0))

    def test_soft_copy_param_scalar(self):
        class ScalarChain(Chain):
            def __init__(self, value):
                super().__init__()
                self.x = Parameter(np.array([value], dtype=np.float32))

        a = ScalarChain(0.5)
        b = ScalarChain(1.0)
        copy_param.soft_copy_param(b, a, tau=0.1)
        expected = 0.5 * 0.9 + 1.0 * 0.1
        self.assertAlmostEqual(a.x.data[0], expected)
        self.assertAlmostEqual(b.x.data[0], 1.0)
        copy_param.soft_copy_param(b, a, tau=0.1)
        expected = expected * 0.9 + 1.0 * 0.1
        self.assertAlmostEqual(a.x.data[0], expected)

    def test_soft_copy_param_type_check(self):
        class DummyLink(Chain):
            def __init__(self):
                super().__init__()

        a = DummyLink()
        b = Linear(10, 5)
        with self.assertRaises(TypeError):
            copy_param.soft_copy_param(b, a, tau=0.1)

    def test_copy_grad(self):
        source = Linear(10, 5)
        target = Linear(10, 5)

        # Scenario 1: source has grads, target does not
        set_random_grad(source)
        copy_param.copy_grad(source, target)
        for name in source.params().keys():
            self.assertIsNotNone(target.params()[name].grad)
            self.assertTrue(np.allclose(source.params()[name].grad,
                                        target.params()[name].grad))
        for name in source.params().keys():
            self.assertIsNotNone(source.params()[name].grad)

        # Scenario 2: both have grads
        set_random_grad(target)
        copy_param.copy_grad(source, target)
        for name in source.params().keys():
            self.assertTrue(np.allclose(source.params()[name].grad,
                                        target.params()[name].grad))

        # Scenario 3: source has no grads, target has grads
        for name in source.params().keys():
            source.params()[name].grad = None
        for name in target.params().keys():
            target.params()[name].grad = np.random.rand(*target.params()[name].shape)
        copy_param.copy_grad(source, target)
        for name in target.params().keys():
            self.assertIsNone(target.params()[name].grad)
        for name in source.params().keys():
            self.assertIsNone(source.params()[name].grad)

        # Scenario 4: neither has grads
        copy_param.copy_grad(source, target)
        for name in target.params().keys():
            self.assertIsNone(target.params()[name].grad)


if __name__ == "__main__":
    unittest.main()