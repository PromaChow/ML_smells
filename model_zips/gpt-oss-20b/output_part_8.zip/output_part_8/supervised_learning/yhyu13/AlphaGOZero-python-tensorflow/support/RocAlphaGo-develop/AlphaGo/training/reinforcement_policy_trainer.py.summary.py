import os
import json
import random
import argparse
import datetime
import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

# ---------- Helper Functions ----------

def load_policy_model(json_path, h5_path=None):
    """Load model architecture from JSON and optionally weights from HDF5."""
    with open(json_path, 'r') as f:
        config = json.load(f)
    model = keras.models.model_from_config(config)
    if h5_path and os.path.exists(h5_path):
        model.load_weights(h5_path)
    return model

def save_policy_weights(model, out_dir, prefix="learner"):
    """Save model weights with a timestamp."""
    if not os.path.isdir(out_dir):
        os.makedirs(out_dir)
    timestamp = datetime.datetime.utcnow().strftime("%Y%m%d%H%M%S")
    path = os.path.join(out_dir, f"{prefix}_{timestamp}.h5")
    model.save_weights(path)
    return path

def preprocess_state(board):
    """Convert board to a tensor representation."""
    # board: 2D array with 0 empty, 1 learner stone, -1 opponent stone
    learner_mask = (board == 1).astype(np.float32)
    opponent_mask = (board == -1).astype(np.float32)
    state = np.stack([learner_mask, opponent_mask], axis=-1)  # shape (size, size, 2)
    return state

def record_metadata(metadata_path, data):
    """Write metadata JSON."""
    with open(metadata_path, 'w') as f:
        json.dump(data, f, indent=2)

# ---------- Game Environment ----------

class GoGame:
    def __init__(self, size=9, move_limit=200):
        self.size = size
        self.board = np.zeros((size, size), dtype=int)
        self.current_player = 1  # 1: learner, -1: opponent
        self.move_limit = move_limit
        self.moves_played = 0
        self.done = False
        self.winner = None  # 1, -1, or 0 for draw

    def valid_moves(self):
        return list(zip(*np.where(self.board == 0)))

    def step(self, move):
        if self.done:
            raise ValueError("Game already finished")
        if self.board[move] != 0:
            raise ValueError("Invalid move")
        self.board[move] = self.current_player
        self.moves_played += 1
        self.current_player *= -1
        if self.moves_played >= self.move_limit or len(self.valid_moves()) == 0:
            self.done = True
            self.winner = random.choice([1, -1, 0])  # random outcome for placeholder
        return self.board.copy(), self.done, self.winner

    def reset(self):
        self.board = np.zeros((self.size, self.size), dtype=int)
        self.current_player = 1
        self.moves_played = 0
        self.done = False
        self.winner = None

# ---------- Policy Players ----------

class ProbabilisticPolicyPlayer:
    def __init__(self, model, temperature=1.0):
        self.model = model
        self.temperature = temperature

    def select_action(self, state):
        state_tensor = tf.convert_to_tensor(state[None, ...], dtype=tf.float32)
        logits = self.model(state_tensor, training=False)[0]
        logits /= self.temperature
        probs = tf.nn.softmax(logits).numpy()
        action = np.random.choice(len(probs), p=probs)
        return action

# ---------- Custom Loss (REINFORCE) ----------

def reinforce_loss(y_true, y_pred, advantage):
    # y_true: integer action indices
    # y_pred: logits
    loss = tf.nn.sparse_softmax_cross_entropy_with_logits(labels=y_true, logits=y_pred)
    loss *= advantage
    return tf.reduce_mean(loss)

# ---------- Training Loop ----------

def train(
    config_path,
    weights_path,
    output_dir,
    metadata_path,
    iterations=1000,
    batch_size=32,
    record_every=50,
    save_every=20,
    learning_rate=1e-3,
    temperature=1.0,
    move_limit=200
):
    # Load base model
    base_model = load_policy_model(config_path, weights_path)
    base_model.compile(optimizer=keras.optimizers.Adam(learning_rate))

    # Prepare optimizer and learning rate variable
    lr_var = tf.Variable(learning_rate, trainable=False, dtype=tf.float32)
    optimizer = keras.optimizers.Adam(learning_rate=lr_var)

    # Opponent weights list
    opponent_weights = []
    if os.path.exists(metadata_path):
        with open(metadata_path, 'r') as f:
            metadata = json.load(f)
        opponent_weights = metadata.get("opponent_weights", [])
    else:
        metadata = {
            "iterations": 0,
            "opponent_weights": [],
            "win_ratios": {}
        }

    for it in range(1, iterations + 1):
        # ---- Opponent Selection ----
        if opponent_weights:
            opp_path = random.choice(opponent_weights)
        else:
            opp_path = weights_path  # fallback to base weights
        opponent_model = load_policy_model(config_path, opp_path)
        opponent_player = ProbabilisticPolicyPlayer(opponent_model, temperature)

        # ---- Game Simulation ----
        states = []
        actions = []
        advantages = []

        win_count = 0
        for _ in range(batch_size):
            game = GoGame(size=9, move_limit=move_limit)
            learner_model = load_policy_model(config_path, weights_path)
            learner_player = ProbabilisticPolicyPlayer(learner_model, temperature)
            game_history = []

            while not game.done:
                current_state = preprocess_state(game.board)
                if game.current_player == 1:
                    action = learner_player.select_action(current_state)
                    action_coord = np.unravel_index(action, game.board.shape)
                    game.step(action_coord)
                    game_history.append((current_state, action))
                else:
                    action = opponent_player.select_action(current_state)
                    action_coord = np.unravel_index(action, game.board.shape)
                    game.step(action_coord)

            # Determine win/loss
            if game.winner == 1:
                win_count += 1
                adv = 1.0
            elif game.winner == -1:
                adv = -1.0
            else:
                adv = 0.0

            for st, act in game_history:
                states.append(st)
                actions.append(act)
                advantages.append(adv)

        # ---- Training Phase ----
        states_np = np.array(states, dtype=np.float32)
        actions_np = np.array(actions, dtype=np.int32)
        advantages_np = np.array(advantages, dtype=np.float32)

        with tf.GradientTape() as tape:
            logits = base_model(states_np, training=True)
            loss = reinforce_loss(actions_np, logits, advantages_np)
        grads = tape.gradient(loss, base_model.trainable_variables)
        optimizer.apply_gradients(zip(grads, base_model.trainable_variables))

        # ---- Learning Rate Adjustment ----
        if win_count > batch_size / 2:
            new_lr = lr_var * 1.05
        else:
            new_lr = lr_var * 0.95
        lr_var.assign(tf.maximum(new_lr, 1e-6))

        # ---- Save Model ----
        if it % record_every == 0:
            save_policy_weights(base_model, output_dir, prefix="learner")

        # ---- Metadata Update ----
        metadata["iterations"] = it
        if it % save_every == 0:
            new_weight_path = save_policy_weights(base_model, output_dir, prefix="learner")
            opponent_weights.append(new_weight_path)
            metadata["opponent_weights"] = opponent_weights

        win_ratio = win_count / batch_size
        metadata["win_ratios"][opp_path] = metadata["win_ratios"].get(opp_path, 0) + win_ratio

        record_metadata(metadata_path, metadata)

        print(f"Iteration {it}/{iterations} | Win Ratio: {win_ratio:.3f} | LR: {lr_var.numpy():.6f}")

# ---------- Main ----------

def main():
    parser = argparse.ArgumentParser(description="Reinforce Go Policy Training")
    parser.add_argument("--config", type=str, required=True, help="JSON config file for model architecture")
    parser.add_argument("--weights", type=str, required=False, help="HDF5 file with initial weights")
    parser.add_argument("--output", type=str, default="output", help="Output directory for weights")
    parser.add_argument("--metadata", type=str, default="metadata.json", help="Metadata JSON file")
    parser.add_argument("--iterations", type=int, default=1000, help="Number of training iterations")
    parser.add_argument("--batch", type=int, default=32, help="Games per batch")
    parser.add_argument("--record-every", type=int, default=50, help="Iterations between weight saves")
    parser.add_argument("--save-every", type=int, default=20, help="Iterations between adding opponent weights")
    parser.add_argument("--lr", type=float, default=1e-3, help="Initial learning rate")
    parser.add_argument("--temp", type=float, default=1.0, help="Temperature for policy sampling")
    parser.add_argument("--move-limit", type=int, default=200, help="Maximum moves per game")
    args = parser.parse_args()

    train(
        config_path=args.config,
        weights_path=args.weights,
        output_dir=args.output,
        metadata_path=args.metadata,
        iterations=args.iterations,
        batch_size=args.batch,
        record_every=args.record_every,
        save_every=args.save_every,
        learning_rate=args.lr,
        temperature=args.temp,
        move_limit=args.move_limit
    )

if __name__ == "__main__":
    main()
