import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.cluster import KMeans
from PIL import Image

def rgb_to_hex(rgb):
    r, g, b = rgb
    return f"#{int(r):02x}{int(g):02x}{int(b):02x}"

# 1. Load image
img = Image.open("dogs.jpeg")
image_np = np.array(img)
height, width, channels = image_np.shape
print(f"Image shape: {height}x{width}x{channels}")

# 2. Reshape image data
pixels = image_np.reshape(-1, 3)

# 3. Apply KMeans clustering
kmeans = KMeans(n_clusters=3, random_state=42)
labels = kmeans.fit_predict(pixels)
centroids = kmeans.cluster_centers_
print("Cluster centroids (RGB):")
print(centroids.astype(int))

# 4. Analyze cluster distribution
unique, counts = np.unique(labels, return_counts=True)
print("Cluster distribution:")
for cls, cnt in zip(unique, counts):
    print(f"  Cluster {cls}: {cnt} pixels")

# 5. Create DataFrame
df = pd.DataFrame(pixels, columns=["col1", "col2", "col3"])
df["cluster"] = labels

# 6. Visualize clusters
sns.lmplot(data=df, x="col1", y="col2", hue="cluster", fit_reg=False, palette="tab10")
plt.title("Pixel distribution in RGB space")
plt.show()

# 7. Reconstruct compressed image
compressed_pixels = centroids[labels].astype(np.uint8)
compressed_img = compressed_pixels.reshape(height, width, 3)

# 8. Display original and compressed images
fig, axes = plt.subplots(1, 2, figsize=(12, 6))
axes[0].imshow(image_np)
axes[0].set_title("Original Image")
axes[0].axis("off")
axes[1].imshow(compressed_img)
axes[1].set_title("Compressed Image (3 colors)")
axes[1].axis("off")
plt.tight_layout()
plt.show()

# 9. Extract and display dominant colors
hex_colors = [rgb_to_hex(centroid) for centroid in centroids]
print("Dominant colors (hex):")
for c in hex_colors:
    print(f"  {c}")
sns.palplot(hex_colors)
plt.title("Dominant Color Palette")
plt.show()