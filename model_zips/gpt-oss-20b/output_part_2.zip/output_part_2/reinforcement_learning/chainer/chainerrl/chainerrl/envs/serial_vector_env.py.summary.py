import gym
from chainerrl import vector
from typing import List, Any, Tuple, Optional


class SerialVectorEnv(vector.VectorEnv):
    def __init__(self, envs: List[gym.Env]) -> None:
        self.envs = envs
        self.last_obs: List[Optional[Any]] = [None] * len(self.envs)
        first_env = self.envs[0]
        self.action_space = first_env.action_space
        self.observation_space = first_env.observation_space
        self.spec = getattr(first_env, "spec", None)

    def step(self, actions: List[Any]) -> Tuple[List[Any], List[float], List[bool], List[dict]]:
        results = []
        for env, a in zip(self.envs, actions):
            results.append(env.step(a))
        self.last_obs, rews, dones, infos = zip(*results)
        return list(self.last_obs), list(rews), list(dones), list(infos)

    def reset(self, mask: Optional[List[bool]] = None) -> List[Any]:
        if mask is None:
            mask = [False] * len(self.envs)
        new_obs = []
        for env, m, prev in zip(self.envs, mask, self.last_obs):
            if not m:
                o = env.reset()
            else:
                o = prev
            new_obs.append(o)
        self.last_obs = new_obs
        return new_obs

    def seed(self, seeds: List[int]) -> None:
        for env, seed in zip(self.envs, seeds):
            env.seed(seed)

    def close(self) -> None:
        for env in self.envs:
            env.close()

    @property
    def num_envs(self) -> int:
        return len(self.envs)