import tensorflow as tf
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class InputExample:
    guid: str
    text_a: str
    label: Optional[str] = None


@dataclass
class PaddingInputExample:
    guid: str = "padding"
    text_a: str = ""
    label: Optional[str] = None


class QCDataProcessor:
    def _read_tsv(self, input_file: str) -> List[str]:
        with tf.io.gfile.GFile(input_file, "r") as f:
            return f.read().splitlines()

    def _create_examples(self, lines: List[str], dataset_type: str) -> List[InputExample]:
        examples: List[InputExample] = []
        for i, line in enumerate(lines[1:], start=1):
            parts = line.split("\t")
            if not parts:
                continue
            label = parts[0]
            text_a = "\t".join(parts[1:])
            guid = f"{dataset_type}-{i}"
            examples.append(InputExample(guid=guid, text_a=text_a, label=label))
        return examples

    def get_labeled_examples(self, data_dir: str) -> List[InputExample]:
        tsv_path = tf.io.gfile.join(data_dir, "labeled.tsv")
        lines = self._read_tsv(tsv_path)
        return self._create_examples(lines, dataset_type="train")

    def get_unlabeled_examples(self, data_dir: str) -> List[InputExample]:
        tsv_path = tf.io.gfile.join(data_dir, "unlabeled.tsv")
        lines = self._read_tsv(tsv_path)
        examples: List[InputExample] = []
        for i, line in enumerate(lines[1:], start=1):
            parts = line.split("\t")
            if not parts:
                continue
            text_a = "\t".join(parts[1:])
            guid = f"unlabeled-{i}"
            examples.append(InputExample(guid=guid, text_a=text_a))
        return examples

    def get_test_examples(self, data_dir: str) -> List[InputExample]:
        tsv_path = tf.io.gfile.join(data_dir, "test.tsv")
        lines = self._read_tsv(tsv_path)
        return self._create_examples(lines, dataset_type="test")

    def get_labels(self) -> List[str]:
        return ["UNK_UNK", "ABBR_abb"] + [f"CLASS_{i}" for i in range(2, 51)]