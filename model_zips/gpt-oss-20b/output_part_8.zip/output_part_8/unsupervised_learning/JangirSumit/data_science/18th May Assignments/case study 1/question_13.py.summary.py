import numpy as np

# Generate a 3x3 array with random values between 0 and 1
arr = np.random.rand(3, 3)

# Print the original array
print("Original array:")
print(arr)

# Swap the first and second rows using advanced indexing
arr[[0, 1]] = arr[[1, 0]]

# Print the modified array
print("\nArray after swapping the first and second rows:")
print(arr)