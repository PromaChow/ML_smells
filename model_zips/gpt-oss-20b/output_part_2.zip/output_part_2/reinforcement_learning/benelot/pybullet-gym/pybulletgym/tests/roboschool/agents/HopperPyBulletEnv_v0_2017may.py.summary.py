import numpy as np

class LinearModel:
    def __init__(self, input_dim: int = 768, hidden1: int = 128, hidden2: int = 64, output_dim: int = 3, seed: int | None = None):
        if seed is not None:
            np.random.seed(seed)
        # Weight matrices
        self.weights_dense1_w = np.random.randn(input_dim, hidden1)          # (768, 128)
        self.weights_dense2_w = np.random.randn(hidden1, hidden2)            # (128, 64)
        self.weights_final_w = np.random.randn(hidden2, output_dim)          # (64, 3)
        # Bias vectors
        self.weights_dense1_b = np.random.randn(hidden1)                     # (128,)
        self.weights_dense2_b = np.random.randn(hidden2)                     # (64,)
        self.weights_final_b = np.random.randn(output_dim)                   # (3,)

    def forward(self, x: np.ndarray) -> np.ndarray:
        """
        Perform a forward pass through the network.
        Parameters:
            x: Input tensor of shape (batch_size, 768)
        Returns:
            Output tensor of shape (batch_size, 3)
        """
        # Dense1: (batch, 768) @ (768, 128) + (128,) -> (batch, 128)
        dense1 = np.dot(x, self.weights_dense1_w) + self.weights_dense1_b
        # Dense2: (batch, 128) @ (128, 64) + (64,) -> (batch, 64)
        dense2 = np.dot(dense1, self.weights_dense2_w) + self.weights_dense2_b
        # DenseFinal: (batch, 64) @ (64, 3) + (3,) -> (batch, 3)
        output = np.dot(dense2, self.weights_final_w) + self.weights_final_b
        return output

if __name__ == "__main__":
    # Example usage
    batch_size = 5
    input_tensor = np.random.randn(batch_size, 768)   # Dummy input
    model = LinearModel(seed=42)
    predictions = model.forward(input_tensor)
    print("Predictions shape:", predictions.shape)
    print(predictions)