import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score
sns.set(font_scale=1.2, style='whitegrid', rc={'lines.linewidth': 2})
plt.rcParams['figure.figsize'] = (8, 6)

# Synthetic data generator
def gen_twonorm_ssl(n_l, n_u, n_t, prior_l, prior_u, random_state=None):
    rng = np.random.default_rng(random_state)
    # class labels: -1 and +1
    # labeled data (balanced)
    n_l_per = n_l // 2
    mean_pos, mean_neg = [np.array([2, 2]), np.array([-2, -2])]
    cov = np.eye(2)
    x_l_pos = rng.multivariate_normal(mean_pos, cov, n_l_per)
    y_l_pos = rng.choice([1], size=n_l_per)
    x_l_neg = rng.multivariate_normal(mean_neg, cov, n_l_per)
    y_l_neg = rng.choice([-1], size=n_l_per)
    x_l = np.vstack([x_l_pos, x_l_neg])
    y_l = np.hstack([y_l_pos, y_l_neg])

    # unlabeled data
    n_u_pos = int(n_u * prior_u)
    n_u_neg = n_u - n_u_pos
    x_u_pos = rng.multivariate_normal(mean_pos, cov, n_u_pos)
    x_u_neg = rng.multivariate_normal(mean_neg, cov, n_u_neg)
    x_u = np.vstack([x_u_pos, x_u_neg])

    # test data
    n_t_pos = int(n_t * prior_u)
    n_t_neg = n_t - n_t_pos
    x_t_pos = rng.multivariate_normal(mean_pos, cov, n_t_pos)
    x_t_neg = rng.multivariate_normal(mean_neg, cov, n_t_neg)
    x_t = np.vstack([x_t_pos, x_t_neg])
    y_t = np.hstack([np.ones(n_t_pos), -np.ones(n_t_neg)])

    return x_l, y_l, x_u, x_t, y_t

# Class prior estimation (placeholder)
def cpe(y_l, x_u):
    return 0.3

# Semi-supervised learning model wrapper
class PNU_SL:
    def __init__(self, prior, lam=0.1, basis='lm', eta=1.0):
        self.prior = prior
        self.lam = lam
        self.basis = basis
        self.eta = eta
        self.model = LogisticRegression(solver='lbfgs', max_iter=1000)

    def fit(self, X, y):
        self.model.fit(X, y)
        return self

    def predict(self, X):
        return np.sign(self.model.decision_function(X))

    def get_coef(self):
        return self.model.coef_[0], self.model.intercept_[0]

# Misclassification error
def bin_clf_err(y_true, y_pred, prior):
    return np.mean(y_true != y_pred)

# Parameters
n_l = 20
n_u = 1000
n_t = 1000
prior_l = 0.5
prior_u = 0.3
eta_list = np.arange(-0.9, 1, 0.1)
n_trial = 20
lam = 0.1
rng_seed = 42
rng = np.random.default_rng(rng_seed)

errs1 = []
priors = []
best_models = []

for trial in range(n_trial):
    x_l, y_l, x_u, x_t, y_t = gen_twonorm_ssl(n_l, n_u, n_t, prior_l, prior_u, random_state=rng_seed+trial)
    prior_est = cpe(y_l, x_u)
    priors.append(prior_est)

    X = np.vstack([x_l, x_u])
    y = np.hstack([y_l, np.full_like(x_u[:,0], -1)])  # unlabeled as -1 placeholder

    # Grid search over eta
    param_grid = {'eta': eta_list}
    base = PNU_SL(prior_est, lam=lam, basis='lm')
    grid = GridSearchCV(base, param_grid, cv=2, scoring='accuracy')
    grid.fit(X, y)
    best_eta = grid.best_params_['eta']

    model = PNU_SL(prior_est, lam=lam, basis='lm', eta=best_eta)
    model.fit(X, y)
    y_pred = model.predict(x_t)
    err = bin_clf_err(y_t, y_pred, prior_u)
    errs1.append(err)

    best_models.append((model, err))

best_err = min(errs1)
best_index = errs1.index(best_err)
best_w, best_b = best_models[best_index][0].get_coef()

# Hyperparameter sensitivity
errs2 = np.zeros(len(eta_list))
for i, eta in enumerate(eta_list):
    errors = []
    for trial in range(n_trial):
        x_l, y_l, x_u, x_t, y_t = gen_twonorm_ssl(n_l, n_u, n_t, prior_l, prior_u, random_state=rng_seed+trial)
        prior_est = cpe(y_l, x_u)
        X = np.vstack([x_l, x_u])
        y = np.hstack([y_l, np.full_like(x_u[:,0], -1)])
        model = PNU_SL(prior_est, lam=lam, basis='lm', eta=eta)
        model.fit(X, y)
        y_pred = model.predict(x_t)
        err = bin_clf_err(y_t, y_pred, prior_u)
        errors.append(err)
    errs2[i] = np.mean(errors)

# Reporting
print(f'Average misclassification error: {np.mean(errs1):.4f} ± {np.std(errs1)/np.sqrt(n_trial):.4f}')
print(f'Average prior estimate: {np.mean(priors):.4f} ± {np.std(priors)/np.sqrt(n_trial):.4f}')

# Visualization
x_min, x_max = -5, 5
y_min, y_max = -5, 5
xx, yy = np.meshgrid(np.linspace(x_min, x_max, 200), np.linspace(y_min, y_max, 200))
grid_points = np.c_[xx.ravel(), yy.ravel()]

# Decision boundaries
plt.figure()
plt.scatter(x_l[y_l==1,0], x_l[y_l==1,1], color='blue', label='Labeled +')
plt.scatter(x_l[y_l==-1,0], x_l[y_l==-1,1], color='red', label='Labeled -')
plt.scatter(x_u[:,0], x_u[:,1], color='gray', alpha=0.3, label='Unlabeled')

# Prior boundary
w_prior = np.array([1, -1])
b_prior = 0
probs_prior = w_prior @ grid_points.T + b_prior
plt.contour(xx, yy, probs_prior.reshape(xx.shape), levels=[0], colors='green', linestyles='dashed', label='Prior boundary')

# Best model boundary
probs_best = best_w @ grid_points.T + best_b
plt.contour(xx, yy, probs_best.reshape(xx.shape), levels=[0], colors='black', linestyles='solid', label='Best boundary')

plt.xlim(x_min, x_max)
plt.ylim(y_min, y_max)
plt.legend()
plt.title('Data and Decision Boundaries')
plt.savefig('data.pdf')

# Error curve
plt.figure()
plt.errorbar(eta_list, errs2, yerr=np.std(errs2)/np.sqrt(n_trial), fmt='-o')
plt.xlabel('eta')
plt.ylabel('Misclassification Error')
plt.title('Error vs eta')
plt.savefig('err_curve.pdf')

plt.show()