import argparse
import sys
import numpy as np
import matplotlib.pyplot as plt

def kmeans(data, k, epochs=10, max_iter=100, verbose=False):
    n_samples, n_features = data.shape
    best_sse = np.inf
    best_labels = None
    best_centroids = None

    for epoch in range(epochs):
        # Randomly initialize centroids from data points
        rng = np.random.default_rng()
        centroids = data[rng.choice(n_samples, k, replace=False)]
        for iteration in range(max_iter):
            # Assign points to nearest centroid
            distances = np.linalg.norm(data[:, np.newaxis] - centroids, axis=2)
            labels = np.argmin(distances, axis=1)

            # Compute new centroids
            new_centroids = np.array([data[labels == i].mean(axis=0) if np.any(labels == i) else centroids[i]
                                      for i in range(k)])

            # Check for convergence
            if np.allclose(centroids, new_centroids):
                if verbose:
                    print(f"Epoch {epoch + 1}, Iteration {iteration + 1}: Converged")
                break
            centroids = new_centroids
            if verbose:
                print(f"Epoch {epoch + 1}, Iteration {iteration + 1}: Updated centroids")

        # Compute SSE for this epoch
        sse = np.sum((data - centroids[labels]) ** 2)
        if verbose:
            print(f"Epoch {epoch + 1}: SSE = {sse:.4f}")

        if sse < best_sse:
            best_sse = sse
            best_labels = labels
            best_centroids = centroids

    return best_labels, best_centroids

def bisecting_kmeans(data, k, epochs=10, max_iter=100, verbose=False):
    n_samples = data.shape[0]
    # Each cluster is represented as a list of indices
    clusters = [np.arange(n_samples)]
    centroids_list = []

    while len(clusters) < k:
        # Compute SSE for each cluster
        sse_list = []
        for cluster_idx, indices in enumerate(clusters):
            cluster_data = data[indices]
            _, centroids = kmeans(cluster_data, 2, epochs=1, max_iter=max_iter, verbose=verbose)
            distances = np.linalg.norm(cluster_data[:, np.newaxis] - centroids, axis=2)
            labels = np.argmin(distances, axis=1)
            sse = np.sum((cluster_data - centroids[labels]) ** 2)
            sse_list.append(sse)

        # Choose cluster with highest SSE to split
        split_idx = np.argmax(sse_list)
        indices_to_split = clusters.pop(split_idx)

        # Split the selected cluster into two
        cluster_data = data[indices_to_split]
        labels, centroids = kmeans(cluster_data, 2, epochs=epochs, max_iter=max_iter, verbose=verbose)

        # Append new clusters
        clusters.append(indices_to_split[labels == 0])
        clusters.append(indices_to_split[labels == 1])

        if verbose:
            print(f"Split cluster {split_idx} into two. Total clusters: {len(clusters)}")

    # Assign final labels
    labels = np.empty(n_samples, dtype=int)
    for cluster_id, indices in enumerate(clusters):
        labels[indices] = cluster_id
        centroids_list.append(data[indices].mean(axis=0))

    centroids = np.array(centroids_list)
    return labels, centroids

def visualize_clusters(data, labels, centroids):
    plt.figure(figsize=(8, 6))
    scatter = plt.scatter(data[:, 0], data[:, 1], c=labels, cmap='viridis', alpha=0.6)
    plt.scatter(centroids[:, 0], centroids[:, 1], c='red', marker='X', s=200, label='Centroids')
    plt.title('Cluster Visualization')
    plt.xlabel('Feature 1')
    plt.ylabel('Feature 2')
    plt.legend()
    plt.grid(True)
    plt.show()

def main():
    parser = argparse.ArgumentParser(description='K-Means and Bisecting K-Means CLI')
    parser.add_argument('datafile', type=str, help='Path to input data file (CSV or whitespace separated)')
    parser.add_argument('--bisecting', action='store_true', help='Use bisecting k-means instead of standard k-means')
    parser.add_argument('--k', type=int, default=2, help='Number of clusters (default: 2)')
    parser.add_argument('--epochs', type=int, default=10, help='Number of random initializations (default: 10)')
    parser.add_argument('--max_iter', type=int, default=100, help='Maximum iterations per run (default: 100)')
    parser.add_argument('--verbose', action='store_true', help='Enable detailed output')

    args = parser.parse_args()

    try:
        data = np.loadtxt(args.datafile)
    except Exception as e:
        print(f"Error loading data: {e}", file=sys.stderr)
        sys.exit(1)

    if data.ndim != 2 or data.shape[1] < 2:
        print("Data must be a 2D array with at least two columns.", file=sys.stderr)
        sys.exit(1)

    if args.bisecting:
        labels, centroids = bisecting_kmeans(
            data,
            k=args.k,
            epochs=args.epochs,
            max_iter=args.max_iter,
            verbose=args.verbose
        )
    else:
        labels, centroids = kmeans(
            data,
            k=args.k,
            epochs=args.epochs,
            max_iter=args.max_iter,
            verbose=args.verbose
        )

    visualize_clusters(data, labels, centroids)

if __name__ == "__main__":
    main()
