import gym
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import numpy as np
from collections import deque
import random

# ---------- Model Definitions ----------

class ACERSeparateModel(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden_dim=128):
        super().__init__()
        self.obs_dim = obs_dim
        self.act_dim = act_dim
        self.shared = nn.Sequential(
            nn.Linear(obs_dim, hidden_dim),
            nn.ReLU(),
        )
        self.policy_head = nn.Linear(hidden_dim, act_dim)
        self.value_head = nn.Linear(hidden_dim, 1)
        self.q_head = nn.Linear(hidden_dim, act_dim)

    def forward(self, x):
        h = self.shared(x)
        logits = self.policy_head(h)
        pi = F.softmax(logits, dim=-1)
        dist = torch.distributions.Categorical(pi)
        value = self.value_head(h)
        q_values = self.q_head(h)
        return dist, value.squeeze(-1), q_values

class ACERSDNSeparateModel(nn.Module):
    """
    Shared Dense Network (SDN) with separate heads.
    """
    def __init__(self, obs_dim, act_dim, hidden_dim=128):
        super().__init__()
        self.obs_dim = obs_dim
        self.act_dim = act_dim
        self.shared = nn.Sequential(
            nn.Linear(obs_dim, hidden_dim),
            nn.ReLU(),
        )
        self.policy_head = nn.Linear(hidden_dim, act_dim)
        self.value_head = nn.Linear(hidden_dim, 1)
        self.q_head = nn.Linear(hidden_dim, act_dim)

    def forward(self, x):
        h = self.shared(x)
        logits = self.policy_head(h)
        pi = F.softmax(logits, dim=-1)
        dist = torch.distributions.Categorical(pi)
        value = self.value_head(h)
        q_values = self.q_head(h)
        return dist, value.squeeze(-1), q_values

# ---------- Replay Buffer ----------

class ReplayBuffer:
    def __init__(self, capacity=1000):
        self.capacity = capacity
        self.buffer = deque(maxlen=capacity)

    def store_episode(self, episode):
        # episode: list of dicts
        self.buffer.append(episode)

    def sample(self, batch_size=1):
        return random.sample(self.buffer, min(batch_size, len(self.buffer)))

    def __len__(self):
        return len(self.buffer)

# ---------- ACER Agent ----------

class ACER:
    def __init__(
        self,
        env,
        model_cls=ACERSeparateModel,
        gamma=0.99,
        t_max=20,
        truncation=0.5,
        trust_region_alpha=0.01,
        beta=0.01,
        lr=1e-3,
        use_trust_region=True,
        use_Q_opc=False,
        replay_buffer_capacity=200,
        average_value_decay=0.99,
        average_entropy_decay=0.99,
        average_kl_decay=0.99,
    ):
        self.env = env
        self.obs_dim = env.observation_space.shape[0]
        self.act_dim = env.action_space.n
        self.gamma = gamma
        self.t_max = t_max
        self.truncation = truncation
        self.trust_region_alpha = trust_region_alpha
        self.beta = beta
        self.use_trust_region = use_trust_region
        self.use_Q_opc = use_Q_opc

        self.model = model_cls(self.obs_dim, self.act_dim).to("cpu")
        self.avg_model = model_cls(self.obs_dim, self.act_dim).to("cpu")
        self.avg_model.load_state_dict(self.model.state_dict())

        self.optimizer = optim.Adam(self.model.parameters(), lr=lr)
        self.replay_buffer = ReplayBuffer(capacity=replay_buffer_capacity)

        # Statistics
        self.average_value = 0.0
        self.average_entropy = 0.0
        self.average_kl = 0.0
        self.average_value_decay = average_value_decay
        self.average_entropy_decay = average_entropy_decay
        self.average_kl_decay = average_kl_decay

        # Episode memory
        self.episode = []
        self.t_count = 0

    def act_and_train(self, obs):
        obs = torch.tensor(obs, dtype=torch.float32).unsqueeze(0)
        dist, value, q_values = self.model(obs)
        action = dist.sample()
        log_prob = dist.log_prob(action)
        entropy = dist.entropy().mean()

        transition = {
            "obs": obs,
            "action": action,
            "log_prob": log_prob,
            "value": value,
            "q_values": q_values,
            "entropy": entropy,
        }
        self.episode.append(transition)
        self.t_count += 1

        if self.t_count >= self.t_max:
            self.stop_episode_and_train()
        return action.item()

    def stop_episode_and_train(self, last_reward=None, done=None, next_obs=None):
        # Compute returns and advantages
        rewards = []
        for trans in self.episode:
            rewards.append(0.0)  # placeholder, will fill later
        if last_reward is not None:
            rewards[-1] = last_reward
        else:
            # if episode ended naturally, compute using value estimate
            rewards[-1] = 0.0
        # Compute discounted returns
        returns = []
        R = 0.0
        for r in reversed(rewards):
            R = r + self.gamma * R
            returns.insert(0, R)
        returns = torch.tensor(returns, dtype=torch.float32)

        values = torch.stack([trans["value"] for trans in self.episode])
        advantages = returns - values

        # Policy loss
        policy_losses = []
        entropy_losses = []
        kl_losses = []
        q_losses = []

        for i, trans in enumerate(self.episode):
            # Importance sampling ratio
            dist_new, _, _ = self.model(trans["obs"])
            pi_new = dist_new.probs
            pi_old = torch.exp(trans["log_prob"])  # reconstruct
            ratio = pi_new[trans["action"]].detach() / pi_old
            ratio = torch.clamp(ratio, 1.0 - self.truncation, 1.0 + self.truncation)

            policy_loss = -ratio * advantages[i]
            policy_losses.append(policy_loss)

            entropy_losses.append(-self.beta * trans["entropy"])

            # KL divergence with average policy
            if self.use_trust_region:
                dist_avg, _, _ = self.avg_model(trans["obs"])
                kl = torch.distributions.kl_divergence(dist_new, dist_avg).mean()
                kl_losses.append(kl)
            else:
                kl_losses.append(torch.tensor(0.0))

            # Q loss
            q_target = advantages[i] + trans["value"]
            q_pred = trans["q_values"][trans["action"]]
            q_loss = F.mse_loss(q_pred, q_target.detach())
            q_losses.append(q_loss)

        loss = torch.stack(policy_losses).mean()
        loss += torch.stack(entropy_losses).mean()
        loss += torch.stack(kl_losses).mean() * (self.trust_region_alpha if self.use_trust_region else 0.0)
        loss += torch.stack(q_losses).mean()

        self.optimizer.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(self.model.parameters(), 0.5)
        self.optimizer.step()

        # Soft update average model
        self.soft_update(self.avg_model, self.model, self.trust_region_alpha)

        # Update statistics
        mean_value = values.mean().item()
        mean_entropy = torch.stack([trans["entropy"] for trans in self.episode]).mean().item()
        mean_kl = torch.stack(kl_losses).mean().item()
        self.average_value = self.average_value_decay * self.average_value + (1 - self.average_value_decay) * mean_value
        self.average_entropy = self.average_entropy_decay * self.average_entropy + (1 - self.average_entropy_decay) * mean_entropy
        self.average_kl = self.average_kl_decay * self.average_kl + (1 - self.average_kl_decay) * mean_kl

        # Reset episode
        self.episode = []
        self.t_count = 0

    def soft_update(self, target, source, tau):
        for t_param, s_param in zip(target.parameters(), source.parameters()):
            t_param.data.copy_(t_param.data * (1.0 - tau) + s_param.data * tau)

    def update_from_replay(self, batch_size=1):
        episodes = self.replay_buffer.sample(batch_size)
        for episode in episodes:
            # Similar to stop_episode_and_train but with stored transitions
            rewards = [trans["reward"] for trans in episode]
            returns = []
            R = 0.0
            for r in reversed(rewards):
                R = r + self.gamma * R
                returns.insert(0, R)
            returns = torch.tensor(returns, dtype=torch.float32)
            values = torch.stack([trans["value"] for trans in episode])
            advantages = returns - values

            policy_losses = []
            entropy_losses = []
            kl_losses = []
            q_losses = []

            for i, trans in enumerate(episode):
                dist_new, _, _ = self.model(trans["obs"])
                pi_new = dist_new.probs
                pi_old = torch.exp(trans["log_prob"])
                ratio = pi_new[trans["action"]].detach() / pi_old
                ratio = torch.clamp(ratio, 1.0 - self.truncation, 1.0 + self.truncation)

                policy_loss = -ratio * advantages[i]
                policy_losses.append(policy_loss)

                entropy_losses.append(-self.beta * trans["entropy"])

                if self.use_trust_region:
                    dist_avg, _, _ = self.avg_model(trans["obs"])
                    kl = torch.distributions.kl_divergence(dist_new, dist_avg).mean()
                    kl_losses.append(kl)
                else:
                    kl_losses.append(torch.tensor(0.0))

                q_target = advantages[i] + trans["value"]
                q_pred = trans["q_values"][trans["action"]]
                q_loss = F.mse_loss(q_pred, q_target.detach())
                q_losses.append(q_loss)

            loss = torch.stack(policy_losses).mean()
            loss += torch.stack(entropy_losses).mean()
            loss += torch.stack(kl_losses).mean() * (self.trust_region_alpha if self.use_trust_region else 0.0)
            loss += torch.stack(q_losses).mean()

            self.optimizer.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(self.model.parameters(), 0.5)
            self.optimizer.step()

            self.soft_update(self.avg_model, self.model, self.trust_region_alpha)

# ---------- Example Usage ----------

def main():
    env = gym.make("CartPole-v1")
    agent = ACER(env, model_cls=ACERSeparateModel, t_max=20)

    num_episodes = 10
    for ep in range(num_episodes):
        obs = env.reset()
        done = False
        total_reward = 0.0
        while not done:
            action = agent.act_and_train(obs)
            next_obs, reward, done, _ = env.step(action)
            total_reward += reward
            obs = next_obs
        agent.stop_episode_and_train(last_reward=0.0, done=True, next_obs=None)
        print(f"Episode {ep+1} reward: {total_reward}")

if __name__ == "__main__":
    main()