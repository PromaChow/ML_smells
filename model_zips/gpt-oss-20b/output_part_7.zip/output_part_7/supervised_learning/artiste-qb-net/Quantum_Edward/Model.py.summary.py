import numpy as np
from abc import ABC, abstractmethod

class Model(ABC):
    DPI = np.pi / 2  # scaling constant for angles

    def __init__(self, na, nb, list1_conc0_prior=None, list1_conc1_prior=None):
        self.na = na
        self.nb = nb

        # Determine shapes for prior concentration parameters
        shapes = self.get_shapes1()
        if list1_conc0_prior is None:
            list1_conc0_prior = self._random_prior_shapes(shapes)
        if list1_conc1_prior is None:
            list1_conc1_prior = self._random_prior_shapes(shapes)

        self.list1_conc0_prior = list1_conc0_prior
        self.list1_conc1_prior = list1_conc1_prior

        # Compute prior angles as mean of beta distributions scaled by DPI
        mean = list1_conc0_prior / (list1_conc0_prior + list1_conc1_prior)
        self.list1_angs_prior = mean * self.DPI

    @staticmethod
    def _random_prior_shapes(shapes):
        """Generate uniformly random arrays for prior concentrations."""
        rng = np.random.default_rng()
        return [rng.uniform(0.1, 10.0, size=s) for s in shapes]

    @abstractmethod
    def get_shapes1(self):
        """Return list of shapes for the angle arrays in list1_angs."""
        raise NotImplementedError

    @abstractmethod
    def prob_x(self, x, list1_angs):
        """Return probability of input state x given list1_angs."""
        raise NotImplementedError

    @abstractmethod
    def prob_y_given_x_and_angs_prior(self, y, x, list1_angs):
        """Return probability of output state y given input x and list1_angs."""
        raise NotImplementedError

    def sum_over_x_of_prob_x(self, list1_angs):
        total = 0.0
        for x in range(1 << self.na):
            total += self.prob_x(x, list1_angs)
        return total

    def sum_over_y_of_prob_y(self, x, list1_angs):
        total = 0.0
        for y in range(1 << self.nb):
            total += self.prob_y_given_x_and_angs_prior(y, x, list1_angs)
        return total

    def _int_to_bin_vec(self, value, bits):
        """Convert integer to binary vector of length bits."""
        return np.array([(value >> (bits - 1 - i)) & 1 for i in range(bits)], dtype=int)

    def gen_toy_data(self, nsam, verbose=False):
        # Sample x according to prob_x distribution
        probs_x = np.array([self.prob_x(x, self.list1_angs_prior) for x in range(1 << self.na)])
        probs_x /= probs_x.sum()
        xs = np.random.choice(1 << self.na, size=nsam, p=probs_x)

        ys = np.empty(nsam, dtype=int)
        for i, x in enumerate(xs):
            probs_y = np.array([self.prob_y_given_x_and_angs_prior(y, x, self.list1_angs_prior)
                                for y in range(1 << self.nb)])
            probs_y /= probs_y.sum()
            ys[i] = np.random.choice(1 << self.nb, p=probs_y)

        x_vecs = np.vstack([self._int_to_bin_vec(x, self.na) for x in xs])
        y_vecs = np.vstack([self._int_to_bin_vec(y, self.nb) for y in ys])

        if verbose:
            print(f"Generated {nsam} samples.")
        return x_vecs, y_vecs
