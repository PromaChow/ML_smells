import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.distributions import Categorical, Normal
from collections import namedtuple
import os
import json

def tensorify(x, device='cpu'):
    return torch.as_tensor(x, dtype=torch.float32, device=device)

def numpify(x):
    return np.array(x, dtype=np.float32)

class MLP(nn.Module):
    def __init__(self, input_dim, sizes, device='cpu'):
        super().__init__()
        layers = []
        in_dim = input_dim
        for out_dim in sizes:
            linear = nn.Linear(in_dim, out_dim, bias=True)
            nn.init.orthogonal_(linear.weight, nn.init.calculate_gain('relu'))
            nn.init.constant_(linear.bias, 0.0)
            layers.append(linear)
            layers.append(nn.ReLU())
            layers.append(nn.LayerNorm(out_dim))
            in_dim = out_dim
        self.net = nn.Sequential(*layers)
        self.to(device)

    def forward(self, x):
        return self.net(x)

class CategoricalHead(nn.Module):
    def __init__(self, input_dim, num_actions, device='cpu'):
        super().__init__()
        self.logits_layer = nn.Linear(input_dim, num_actions)
        nn.init.orthogonal_(self.logits_layer.weight, nn.init.calculate_gain('linear'))
        nn.init.constant_(self.logits_layer.bias, 0.0)
        self.to(device)

    def forward(self, features):
        logits = self.logits_layer(features)
        dist = Categorical(logits=logits)
        return dist

class DiagGaussianHead(nn.Module):
    def __init__(self, input_dim, action_dim, device='cpu'):
        super().__init__()
        self.mean_layer = nn.Linear(input_dim, action_dim)
        nn.init.orthogonal_(self.mean_layer.weight, nn.init.calculate_gain('linear'))
        nn.init.constant_(self.mean_layer.bias, 0.0)
        self.log_std = nn.Parameter(torch.zeros(action_dim))
        self.to(device)

    def forward(self, features):
        mean = self.mean_layer(features)
        std = torch.exp(self.log_std)
        dist = Normal(mean, std)
        return dist

class VHead(nn.Module):
    def __init__(self, input_dim, device='cpu'):
        super().__init__()
        self.value_layer = nn.Linear(input_dim, 1)
        nn.init.orthogonal_(self.value_layer.weight, nn.init.calculate_gain('linear'))
        nn.init.constant_(self.value_layer.bias, 0.0)
        self.to(device)

    def forward(self, features):
        return self.value_layer(features).squeeze(-1)

class VTrace:
    def __init__(self, gamma, clip_rho, clip_pg_rho):
        self.gamma = gamma
        self.clip_rho = clip_rho
        self.clip_pg_rho = clip_pg_rho

    def compute(self, rewards, values, next_values, logp_behav, logp, done_mask):
        rho = torch.exp(logp_behav - logp)
        c = torch.clamp(rho, max=self.clip_rho)
        rho = torch.clamp(rho, max=self.clip_pg_rho)
        delta = rho * (rewards + self.gamma * next_values * (1 - done_mask) - values)
        adv = torch.zeros_like(delta)
        vs = torch.zeros_like(values)
        acc_adv = torch.zeros_like(delta[0])
        acc_v = torch.zeros_like(delta[0])
        for t in reversed(range(len(delta))):
            acc_adv = delta[t] + self.gamma * c[t] * acc_adv
            adv[t] = acc_adv
            acc_v = delta[t] + self.gamma * c[t] * acc_v
            vs[t] = values[t] + acc_v
        return adv, vs

class RLAgent:
    def __init__(self, env, config, checkpoint_dir='checkpoints'):
        self.env = env
        self.config = config
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        obs_shape = env.observation_space.shape[0]
        self.feature_net = MLP(obs_shape, config['nn.sizes'], device=self.device)
        if isinstance(env.action_space, gym.spaces.Discrete):
            self.action_head = CategoricalHead(config['nn.sizes'][-1], env.action_space.n, device=self.device)
        else:
            self.action_head = DiagGaussianHead(config['nn.sizes'][-1], env.action_space.shape[0], device=self.device)
        self.value_head = VHead(config['nn.sizes'][-1], device=self.device)
        self.optimizer = optim.Adam(
            list(self.feature_net.parameters()) +
            list(self.action_head.parameters()) +
            list(self.value_head.parameters()),
            lr=config['agent.lr']
        )
        if config.get('agent.use_lr_scheduler', False):
            self.scheduler = optim.lr_scheduler.LinearLR(self.optimizer, start_factor=1.0, end_factor=0.1, total_iters=1000)
        else:
            self.scheduler = None
        self.vtrace = VTrace(
            gamma=config['agent.gamma'],
            clip_rho=config['agent.clip_rho'],
            clip_pg_rho=config['agent.clip_pg_rho']
        )
        self.v_coeff = config.get('agent.v_coeff', 0.5)
        self.entropy_coeff = config.get('agent.entropy_coeff', 0.01)
        self.standardize_adv = config.get('agent.standardize_adv', True)
        self.max_grad_norm = config.get('agent.max_grad_norm', 0.5)
        self.timestep = 0
        self.checkpoint_dir = checkpoint_dir
        os.makedirs(checkpoint_dir, exist_ok=True)

    def act(self, observation):
        obs = tensorify(observation, device=self.device).unsqueeze(0)
        with torch.no_grad():
            features = self.feature_net(obs)
            dist = self.action_head(features)
            action = dist.sample()
            logp = dist.log_prob(action)
            entropy = dist.entropy()
            value = self.value_head(features)
        return {
            'action': numpify(action.cpu().numpy()),
            'logp': logp.item(),
            'entropy': entropy.item(),
            'value': value.item()
        }

    def learn(self, batch):
        observations = tensorify(batch['observations'], device=self.device)
        actions = tensorify(batch['actions'], device=self.device)
        rewards = tensorify(batch['rewards'], device=self.device)
        dones = tensorify(batch['dones'], device=self.device)
        behavior_logp = tensorify(batch['behavior_logp'], device=self.device)

        features = self.feature_net(observations)
        dist = self.action_head(features)
        values = self.value_head(features)

        next_features = self.feature_net(tensorify(batch['next_observations'], device=self.device))
        next_values = self.value_head(next_features)

        adv, vs = self.vtrace.compute(
            rewards, values, next_values, behavior_logp, dist.log_prob(actions), dones
        )

        if self.standardize_adv:
            adv_mean = adv.mean()
            adv_std = adv.std() + 1e-8
            adv = (adv - adv_mean) / adv_std

        policy_loss = -(dist.log_prob(actions) * adv).mean()
        value_loss = (values - vs).pow(2).mean() * self.v_coeff
        entropy_loss = -dist.entropy().mean() * self.entropy_coeff

        loss = policy_loss + value_loss + entropy_loss

        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(list(self.feature_net.parameters()) +
                                       list(self.action_head.parameters()) +
                                       list(self.value_head.parameters()),
                                       self.max_grad_norm)
        self.optimizer.step()
        if self.scheduler:
            self.scheduler.step()

        self.timestep += len(rewards)
        if self.timestep % self.config.get('checkpoint_interval', 10000) == 0:
            self._save_checkpoint()

        return {
            'loss': loss.item(),
            'policy_loss': policy_loss.item(),
            'value_loss': value_loss.item(),
            'entropy_loss': entropy_loss.item(),
            'adv_mean': adv.mean().item(),
            'adv_std': adv.std().item()
        }

    def _save_checkpoint(self):
        checkpoint = {
            'feature_net': self.feature_net.state_dict(),
            'action_head': self.action_head.state_dict(),
            'value_head': self.value_head.state_dict(),
            'optimizer': self.optimizer.state_dict(),
            'timestep': self.timestep
        }
        if hasattr(self.env, 'observation_mean') and hasattr(self.env, 'observation_var'):
            checkpoint['observation_mean'] = self.env.observation_mean
            checkpoint['observation_var'] = self.env.observation_var
        filename = os.path.join(self.checkpoint_dir, f'checkpoint_{self.timestep}.pth')
        torch.save(checkpoint, filename)

    def load_checkpoint(self, path):
        checkpoint = torch.load(path, map_location=self.device)
        self.feature_net.load_state_dict(checkpoint['feature_net'])
        self.action_head.load_state_dict(checkpoint['action_head'])
        self.value_head.load_state_dict(checkpoint['value_head'])
        self.optimizer.load_state_dict(checkpoint['optimizer'])
        self.timestep = checkpoint['timestep']

import gym
class TrajectoryBatch:
    def __init__(self, observations, actions, rewards, dones, behavior_logp, next_observations):
        self.observations = observations
        self.actions = actions
        self.rewards = rewards
        self.dones = dones
        self.behavior_logp = behavior_logp
        self.next_observations = next_observations

    def to_dict(self):
        return {
            'observations': self.observations,
            'actions': self.actions,
            'rewards': self.rewards,
            'dones': self.dones,
            'behavior_logp': self.behavior_logp,
            'next_observations': self.next_observations
        }
```