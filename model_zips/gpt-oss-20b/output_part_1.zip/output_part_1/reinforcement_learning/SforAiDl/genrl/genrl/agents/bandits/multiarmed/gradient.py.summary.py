import numpy as np

class MultiArmedBandit:
    """Placeholder environment. Implement get_reward(context, action)."""
    def __init__(self, num_contexts, num_actions):
        self.num_contexts = num_contexts
        self.num_actions = num_actions

    def get_reward(self, context, action):
        return np.random.rand()

class GradientBanditAgent:
    def __init__(self, mab, alpha=0.1, temp=1.0):
        self.mab = mab
        self.alpha = alpha
        self.temp = temp
        self.num_contexts = mab.num_contexts
        self.num_actions = mab.num_actions
        self.quality = np.zeros((self.num_contexts, self.num_actions))
        self.action_hist = []
        self.reward_hist = []
        self.regret_hist = []
        self.probability_hist = []

    def _softmax(self, context):
        q = self.quality[context]
        exp_q = np.exp(q / self.temp)
        probs = exp_q / exp_q.sum()
        return probs

    def select_action(self, context):
        probs = self._softmax(context)
        action = np.random.choice(self.num_actions, p=probs)
        self.action_hist.append((context, action))
        self.probability_hist.append(probs.copy())
        return action

    def update_params(self, context, action):
        reward = self.mab.get_reward(context, action)
        max_q = self.quality[context].max()
        regret = max_q - self.quality[context][action]
        self.regret_hist.append(regret)
        baseline = np.mean(self.reward_hist) if self.reward_hist else 0.0
        diff = reward - baseline
        probs = self.probability_hist[-1]
        self.quality[context][action] += self.alpha * diff * (1 - probs[action])
        for a in range(self.num_actions):
            if a != action:
                self.quality[context][a] -= self.alpha * diff * probs[a]
        self.reward_hist.append(reward)

    def step(self, context):
        action = self.select_action(context)
        self.update_params(context, action)
        return action
