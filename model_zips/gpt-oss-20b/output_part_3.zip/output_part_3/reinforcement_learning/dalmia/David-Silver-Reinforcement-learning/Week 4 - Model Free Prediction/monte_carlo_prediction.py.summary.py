import numpy as np
from gymnasium.envs.toy_text import BlackjackEnv
from plotting import plot_value_function

def mc_prediction(env, policy, num_episodes, discount_factor=1.0):
    returns_num = {}
    V = {}
    for _ in range(num_episodes):
        obs, _ = env.reset()
        state = tuple(obs)
        eligibility_traces = {}
        episode_rewards = {}
        done = False
        while not done:
            for s in eligibility_traces:
                eligibility_traces[s] *= discount_factor
            if state not in eligibility_traces:
                eligibility_traces[state] = 1.0
            action = np.argmax(policy(state))
            next_state, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated
            for s, trace in eligibility_traces.items():
                episode_rewards[s] = episode_rewards.get(s, 0.0) + trace * reward
            state = tuple(next_state)
        for s, G in episode_rewards.items():
            if s in returns_num:
                returns_num[s] += 1
            else:
                returns_num[s] = 1
                V[s] = 0.0
            V[s] += (G - V[s]) / returns_num[s]
    return V

def sample_policy(state):
    player_sum, dealer_card, usable_ace = state
    if player_sum >= 20:
        return np.array([1.0, 0.0])
    return np.array([0.0, 1.0])

if __name__ == "__main__":
    env = BlackjackEnv()
    V_10k = mc_prediction(env, sample_policy, num_episodes=10000)
    V_500k = mc_prediction(env, sample_policy, num_episodes=500000)
    plot_value_function(V_10k, title="Value Function (10,000 Episodes)")
    plot_value_function(V_500k, title="Value Function (500,000 Episodes)")