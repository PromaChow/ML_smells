import os
import tkinter as tk
from collections import deque

CELL_SIZE = 40
GRID_SIZE = 9
OBSTACLES = [
    (1, 2), (2, 2), (3, 5), (4, 3), (5, 1), (5, 4), (6, 0), (6, 2), (7, 7),
    (0, 5), (1, 6), (2, 4), (3, 3), (4, 5), (5, 7), (7, 0), (7, 3), (8, 8),
    (2, 8), (4, 1), (6, 6), (8, 2), (0, 0)  # last one is robot start (will be overridden)
]
GOAL_POS = (6, 6)
ACTION_MAP = {
    'up': (-1, 0),
    'down': (1, 0),
    'left': (0, -1),
    'right': (0, 1)
}


class GridEnv:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Robot Navigation Environment")
        self.canvas = tk.Canvas(
            self.root,
            width=GRID_SIZE * CELL_SIZE,
            height=GRID_SIZE * CELL_SIZE,
            bg='white'
        )
        self.canvas.pack()
        self._draw_grid()
        self._load_images()
        self._place_obstacles()
        self._place_goal()
        self.robot = None
        self.robot_pos = (0, 0)
        self.d = deque()
        self.routes = []
        self.reset()

    def _draw_grid(self):
        for i in range(GRID_SIZE + 1):
            self.canvas.create_line(
                i * CELL_SIZE, 0, i * CELL_SIZE, GRID_SIZE * CELL_SIZE, fill='gray'
            )
            self.canvas.create_line(
                0, i * CELL_SIZE, GRID_SIZE * CELL_SIZE, i * CELL_SIZE, fill='gray'
            )

    def _load_images(self):
        def load(name):
            if os.path.isfile(name):
                return tk.PhotoImage(file=name)
            else:
                img = tk.PhotoImage(width=CELL_SIZE, height=CELL_SIZE)
                img.put("#dddddd", to=(0, 0, CELL_SIZE, CELL_SIZE))
                return img
        self.obstacle_img = load('tree1.png')
        self.goal_img = load('flag.png')
        self.robot_img = load('robot.png')

    def _place_obstacles(self):
        self.obstacle_ids = set()
        for r, c in OBSTACLES:
            if (r, c) == GOAL_POS or (r, c) == (0, 0):
                continue
            x = c * CELL_SIZE
            y = r * CELL_SIZE
            oid = self.canvas.create_image(x, y, anchor='nw', image=self.obstacle_img)
            self.obstacle_ids.add((r, c))

    def _place_goal(self):
        r, c = GOAL_POS
        x = c * CELL_SIZE
        y = r * CELL_SIZE
        self.goal_id = self.canvas.create_image(x, y, anchor='nw', image=self.goal_img)

    def reset(self):
        if self.robot:
            self.canvas.delete(self.robot)
        self.robot_pos = (0, 0)
        x = self.robot_pos[1] * CELL_SIZE
        y = self.robot_pos[0] * CELL_SIZE
        self.robot = self.canvas.create_image(x, y, anchor='nw', image=self.robot_img)
        self.d.clear()

    def step(self, action):
        if action not in ACTION_MAP:
            raise ValueError("Invalid action")
        delta = ACTION_MAP[action]
        new_r = self.robot_pos[0] + delta[0]
        new_c = self.robot_pos[1] + delta[1]
        if not (0 <= new_r < GRID_SIZE and 0 <= new_c < GRID_SIZE):
            reward = 0
            done = False
            return reward, done
        if (new_r, new_c) in self.obstacle_ids:
            self._move_robot(new_r, new_c)
            reward = -1
            done = True
            return reward, done
        self._move_robot(new_r, new_c)
        reward = 0
        done = False
        if (new_r, new_c) == GOAL_POS:
            reward = 1
            done = True
            self.routes.append(list(self.d))
        return reward, done

    def _move_robot(self, r, c):
        self.robot_pos = (r, c)
        x = c * CELL_SIZE
        y = r * CELL_SIZE
        self.canvas.coords(self.robot, x, y)
        self.d.append((r, c))

    def final(self):
        if not self.routes:
            return
        shortest = min(self.routes, key=len)
        for r, c in shortest:
            x = c * CELL_SIZE + CELL_SIZE // 2
            y = r * CELL_SIZE + CELL_SIZE // 2
            self.canvas.create_oval(
                x-5, y-5, x+5, y+5,
                fill='blue', outline=''
            )

    def final_states(self):
        if not self.routes:
            return []
        shortest = min(self.routes, key=len)
        return shortest

    def mainloop(self):
        self.root.mainloop()


if __name__ == "__main__":
    env = GridEnv()
    env.reset()
    # Simple demonstration: move right 6 times, down 6 times
    actions = ['right'] * 6 + ['down'] * 6
    for act in actions:
        reward, done = env.step(act)
        env.root.update()
        if done:
            break
    env.final()
    env.mainloop()