import numpy as np

class ThreeLayerPolicy:
    def __init__(self, input_dim, hidden1_dim, hidden2_dim, output_dim):
        self.W1 = np.random.randn(input_dim, hidden1_dim)
        self.b1 = np.zeros(hidden1_dim)
        self.W2 = np.random.randn(hidden1_dim, hidden2_dim)
        self.b2 = np.zeros(hidden2_dim)
        self.W3 = np.random.randn(hidden2_dim, output_dim)
        self.b3 = np.zeros(output_dim)

    @staticmethod
    def relu(x):
        return np.maximum(0, x)

    def forward(self, observation):
        a1 = self.relu(observation @ self.W1 + self.b1)
        a2 = self.relu(a1 @ self.W2 + self.b2)
        action = a2 @ self.W3 + self.b3
        return action

    def __call__(self, observation):
        return self.forward(observation)

if __name__ == "__main__":
    policy = ThreeLayerPolicy(input_dim=4, hidden1_dim=8, hidden2_dim=5, output_dim=2)
    obs = np.array([0.1, -0.2, 0.3, 0.4])
    action = policy(obs)
    print("Action:", action)