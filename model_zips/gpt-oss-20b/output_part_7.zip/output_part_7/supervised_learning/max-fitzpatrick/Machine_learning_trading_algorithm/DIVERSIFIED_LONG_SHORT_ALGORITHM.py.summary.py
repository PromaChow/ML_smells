import pandas as pd
import numpy as np
import talib
import urllib.request
from sklearn.ensemble import RandomForestClassifier
from quantopian.api import attach_pipeline, pipeline_output
from quantopian.api import (
    get_open_orders, order_optimal_portfolio, schedule_function,
    date_rules, time_rules, symbol, get_datetime, set_commission,
    set_slippage, set_order_cost, set_benchmark, set_leverage,
    set_fundamentals, set_slippage, set_commission, set_order_cost,
    set_allocation, set_position, log, set_long_short, Constraints, GrossExposure,
)

# ---------------------------------
# Utility functions
# ---------------------------------
def download_csv(url):
    with urllib.request.urlopen(url) as response:
        return pd.read_csv(response)

def calc_indicators(sym, data):
    hist = data.history(sym, ['open', 'high', 'low', 'close'], 100, '1d')
    close = hist['close'].values
    high = hist['high'].values
    low = hist['low'].values
    open_ = hist['open'].values

    # Delta: percentage change over 30 days
    delta = (close[0] / close[30] - 1) if len(close) >= 31 else 0

    # Moving averages
    ma10 = np.mean(close[-10:])
    ma20 = np.mean(close[-20:])
    ma100 = np.mean(close)

    # Rate of Change (ROC)
    roc = talib.ROC(close, timeperiod=10)[-1] if len(close) >= 11 else 0

    # Bollinger Bands (using middle band)
    upper, middle, lower = talib.BBANDS(close, timeperiod=20)
    bbands = middle[-1] if len(middle) > 0 else 0

    # Stochastic Oscillator %K (fastk)
    slowk, slowd = talib.STOCH(high, low, close, fastk_period=14,
                               slowk_period=3, slowk_matype=0,
                               slowd_period=3, slowd_matype=0)
    so_k = slowk[-1] if len(slowk) > 0 else 0

    # MACD
    macd, macdsignal, macdhist = talib.MACD(close, fastperiod=12,
                                            slowperiod=26, signalperiod=9)
    macd_val = macd[-1] if len(macd) > 0 else 0

    # RSI
    rsi = talib.RSI(close, timeperiod=14)
    rsi_val = rsi[-1] if len(rsi) > 0 else 0

    # CCI
    cci = talib.CCI(high, low, close, timeperiod=20)
    cci_val = cci[-1] if len(cci) > 0 else 0

    return {
        'Delta': delta,
        'MA10': ma10,
        'MA20': ma20,
        'MA100': ma100,
        'ROC': roc,
        'BBANDS': bbands,
        'SO_K': so_k,
        'MACD': macd_val,
        'RSI14': rsi_val,
        'CCI': cci_val,
    }

# ---------------------------------
# Strategy initialization
# ---------------------------------
def initialize(context):
    context.universe = [
        symbol('AAPL'), symbol('MSFT'), symbol('GOOG'), symbol('AMZN'),
        symbol('FB'), symbol('TSLA'), symbol('NVDA'), symbol('JPM'),
        symbol('V'), symbol('JNJ'), symbol('WMT'), symbol('PG'),
        symbol('MA'), symbol('DIS'), symbol('HD'), symbol('BAC'),
        symbol('XOM'), symbol('PFE'), symbol('CSCO'), symbol('INTC'),
        # ... add more symbols to reach 100+ ...
    ]

    # Training data URL
    train_url = 'https://www.dropbox.com/s/yourfile/training_data.csv?raw=1'
    train_df = download_csv(train_url)

    # Train classifier per stock
    clf_list = {}
    for sym in context.universe:
        sym_str = sym._symbol
        df_sym = train_df[train_df['Ticker'] == sym_str]
        if df_sym.empty:
            continue
        X = df_sym[['Delta', 'MA10', 'MA20', 'MA100', 'ROC',
                    'BBANDS', 'SO_K', 'MACD', 'RSI14', 'CCI']]
        y = df_sym['Class']
        clf = RandomForestClassifier(n_estimators=1000, random_state=42, n_jobs=-1)
        clf.fit(X, y)
        clf_list[sym_str] = clf
    context.clf_list = clf_list

    schedule_function(rebalance, date_rules.every_nth_day(30), time_rules.market_open())

    # Logging and order settings
    set_commission(commission.PerTrade(cost=2.0))
    set_slippage(slippage.VolumeShareSlippage(volume_limit=0.25))
    set_leverage(1.0)

# ---------------------------------
# Rebalancing logic
# ---------------------------------
def rebalance(context, data):
    predictions = []
    for sym in context.universe:
        try:
            features = calc_indicators(sym, data)
            feat_series = pd.Series(features)
            clf = context.clf_list.get(sym._symbol)
            if clf is None:
                prob_long = 0.5
            else:
                prob_long = clf.predict_proba([feat_series.values])[0][1]
        except Exception as e:
            log.warning(f'Error processing {sym}: {e}')
            prob_long = 0.5
        predictions.append((sym, prob_long))

    # Sort by probability
    predictions.sort(key=lambda x: x[1], reverse=True)
    half = len(predictions) // 2
    longs = [p[0] for p in predictions[:half]]
    shorts = [p[0] for p in predictions[half:]]

    # Assign equal weights
    weight_long = 1.0 / len(longs) if longs else 0
    weight_short = -1.0 / len(shorts) if shorts else 0
    weights = {}
    for sym in longs:
        weights[sym] = weight_long
    for sym in shorts:
        weights[sym] = weight_short

    # Order portfolio with gross exposure constraint
    constraints = Constraints([GrossExposure(1.0)])
    order_optimal_portfolio(weights, constraints=constraints)

    log.info(f'Rebalanced at {get_datetime()}')
    log.info(f'Longs: {[s._symbol for s in longs]}')
    log.info(f'Shorts: {[s._symbol for s in shorts]}')
    log.info(f'Weights: {weights}')