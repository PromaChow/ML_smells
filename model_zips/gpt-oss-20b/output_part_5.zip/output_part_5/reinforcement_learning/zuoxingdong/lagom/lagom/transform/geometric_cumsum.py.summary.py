import numpy as np
from scipy.signal import lfilter

def geometric_cumsum(x, alpha):
    """
    Compute a weighted cumulative sum of the input sequence x using an
    exponential factor alpha.

    Parameters
    ----------
    x : array_like
        Input sequence. Can be 1‑D or 2‑D.
    alpha : float
        Exponential decay factor (0 <= alpha < 1).

    Returns
    -------
    numpy.ndarray
        Weighted cumulative sum with the same dimensionality as the input.
    """
    # 1. Input Conversion
    x = np.asarray(x)

    # 2. Dimension Adjustment
    if x.ndim == 1:
        x = np.expand_dims(x, 0)

    # 3. Validation
    assert x.ndim == 2, "Input must be 2‑D after conversion."

    # 4. Signal Filtering
    # Reverse along axis 1, filter, then reverse back
    filtered = lfilter(b=[1], a=[1, -alpha], x=x[:, ::-1], axis=1)
    result = filtered[:, ::-1]

    # 5. Return result with original shape
    if result.shape[0] == 1:
        return result.squeeze()
    return result
