import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.linear_model import LogisticRegression
from sklearn import metrics

# Step 1: Load data
df = pd.read_csv("bio-degradabale-data.csv", sep=";")
print(df.head())

# Step 2: Rename columns to numeric indices
df.columns = list(range(42))

# Step 3: Separate features and target
X = df.iloc[:, 0:41]
Y = df.iloc[:, 41]

# Step 4: Train-test split
train_x, test_x, train_y, test_y = train_test_split(
    X, Y, test_size=0.30, random_state=5, stratify=Y
)

# Step 5: Initialize and train logistic regression
model = LogisticRegression(max_iter=1000, random_state=5)
model.fit(train_x, train_y)

# Step 6: Predict and evaluate accuracy on test set
predictions = model.predict(test_x)
accuracy = metrics.accuracy_score(test_y, predictions)
print(f"Test set accuracy: {accuracy:.4f}")

# Step 7: 10-fold cross-validation
cv_scores = cross_val_score(model, X, Y, cv=10, scoring="accuracy")
print(f"Cross-validated accuracy (mean ± std): {cv_scores.mean():.4f} ± {cv_scores.std():.4f}")