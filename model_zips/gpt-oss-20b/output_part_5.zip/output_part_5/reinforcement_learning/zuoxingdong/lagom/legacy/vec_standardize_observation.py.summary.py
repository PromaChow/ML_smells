import numpy as np
import gymnasium as gym
from gymnasium.vector import VectorEnvWrapper


class RunningMeanVar:
    """Online computation of mean and variance using Welford's algorithm."""

    def __init__(self, shape, dtype=np.float32):
        self.shape = shape
        self.dtype = dtype
        self.count = 0
        self.mean = np.zeros(shape, dtype=dtype)
        self.M2 = np.zeros(shape, dtype=dtype)

    def update(self, x):
        x = np.asarray(x, dtype=self.dtype)
        self.count += 1
        delta = x - self.mean
        self.mean += delta / self.count
        delta2 = x - self.mean
        self.M2 += delta * delta2

    @property
    def var(self):
        if self.count < 2:
            return np.zeros(self.shape, dtype=self.dtype)
        return self.M2 / (self.count - 1)


class StandardizeObsWrapper(VectorEnvWrapper):
    """Vectorized environment wrapper that standardizes observations."""

    def __init__(self, env, clip: float = 5.0, constant_moments: tuple | None = None):
        super().__init__(env)
        self.clip = clip
        self._online = constant_moments is None

        if self._online:
            obs_shape = env.observation_space.shape
            self._running = RunningMeanVar(shape=obs_shape)
        else:
            self.constant_mean, self.constant_var = constant_moments

    def reset(self, **kwargs):
        obs, infos = super().reset(**kwargs)
        obs = self.process_obs(obs)
        return obs, infos

    def step(self, actions):
        obs, rewards, dones, infos = super().step(actions)
        obs = self.process_obs(obs)
        for info in infos:
            if 'last_observation' in info:
                info['last_observation'] = self.process_obs(info['last_observation'])
        return obs, rewards, dones, infos

    def process_obs(self, obs):
        obs = np.asarray(obs, dtype=np.float32)
        if self._online:
            self._running.update(obs)
            mean = self._running.mean
            std = np.sqrt(self._running.var + 1e-8)
        else:
            mean = np.array(self.constant_mean, dtype=np.float32)
            std = np.sqrt(np.array(self.constant_var, dtype=np.float32) + 1e-8)
        standardized = (obs - mean) / std
        return np.clip(standardized, -self.clip, self.clip)

    @property
    def mean(self):
        if not self._online:
            raise AttributeError("Mean is only available in online mode.")
        return self._running.mean

    @property
    def var(self):
        if not self._online:
            raise AttributeError("Variance is only available in online mode.")
        return self._running.var
