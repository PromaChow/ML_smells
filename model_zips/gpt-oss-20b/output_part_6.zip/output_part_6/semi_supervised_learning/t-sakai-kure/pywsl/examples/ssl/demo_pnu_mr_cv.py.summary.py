import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV, cross_val_predict
from sklearn.metrics import make_scorer
import time

np.random.seed(1)

class Timer:
    def __init__(self):
        self.start_time = None
        self.elapsed = 0.0

    def start(self):
        self.start_time = time.time()

    def stop(self):
        if self.start_time is not None:
            self.elapsed = time.time() - self.start_time
            self.start_time = None

    def get_elapsed(self):
        return self.elapsed

def gen_twonorm_ssl(n_l, n_u, n_t, prior_l, prior_u):
    n_l1 = int(round(n_l * prior_l))
    n_l0 = n_l - n_l1
    x_l0 = np.random.randn(n_l0, 2) - 1
    x_l1 = np.random.randn(n_l1, 2) + 1
    y_l0 = np.zeros(n_l0)
    y_l1 = np.ones(n_l1)
    x_l = np.vstack([x_l0, x_l1])
    y_l = np.concatenate([y_l0, y_l1])

    n_u1 = int(round(n_u * prior_u))
    n_u0 = n_u - n_u1
    x_u0 = np.random.randn(n_u0, 2) - 1
    x_u1 = np.random.randn(n_u1, 2) + 1
    x_u = np.vstack([x_u0, x_u1])

    n_t1 = int(round(n_t * prior_u))
    n_t0 = n_t - n_t1
    x_t0 = np.random.randn(n_t0, 2) - 1
    x_t1 = np.random.randn(n_t1, 2) + 1
    x_t = np.vstack([x_t0, x_t1])
    y_t = np.concatenate([np.zeros(n_t0), np.ones(n_t1)])

    return x_l, y_l, x_u, x_t, y_t

def cpe(x_l, y_l, x_u):
    return np.mean(y_l)

def calc_etab(n_l, n_u, prior_est):
    return 0.0

class PNU_SL:
    def __init__(self, prior, basis='lm', eta=0.0, lam=0.1):
        self.prior = prior
        self.basis = basis
        self.eta = eta
        self.lam = lam
        self.clf = LogisticRegression(C=1 / lam, max_iter=1000)

    def fit(self, X, y):
        self.clf.fit(X, y)

    def predict(self, X):
        return self.clf.predict(X)

class PNU_SL_FastCV:
    def __init__(self, x, y, prior, eta_list, lambda_list, n_folds, basis='lm', nargout=1):
        self.x = x
        self.y = y
        self.prior = prior
        self.eta_list = eta_list
        self.lambda_list = lambda_list
        self.n_folds = n_folds
        self.basis = basis
        self.nargout = nargout
        self.best_eta = None
        self.best_lam = None
        self.model = None

    def fit(self):
        self.best_eta = self.eta_list[0]
        self.best_lam = self.lambda_list[0]
        self.model = LogisticRegression(C=1 / self.best_lam, max_iter=1000)
        self.model.fit(self.x, self.y)

    def predict(self, X):
        return self.model.predict(X)

def pnu_risk(estimator, X, y, prior, etah):
    preds = estimator.predict(X)
    err = np.mean(preds != y)
    return err

def bin_clf_err(estimator, X, y, prior_u):
    preds = estimator.predict(X)
    return np.mean(preds != y)

if __name__ == "__main__":
    n_l = 20
    n_u = 1000
    n_t = 1000
    prior_l = 0.5
    prior_u = 0.3

    x_l, y_l, x_u, x_t, y_t = gen_twonorm_ssl(n_l, n_u, n_t, prior_l, prior_u)

    prior_est = cpe(x_l, y_l, x_u)

    eta_list = list(np.linspace(-0.9, 0.9, 19))
    lam_list = [0.1]
    etah = calc_etab(n_l, n_u, prior_est)

    scorer = make_scorer(lambda estimator, X, y: -pnu_risk(estimator, X, y, prior_est, etah), greater_is_better=True)

    grid = GridSearchCV(PNU_SL(prior=prior_est, basis='lm'), param_grid={'eta': eta_list, 'lam': lam_list},
                        cv=3, scoring=scorer, n_jobs=-1)

    timer_pnu = Timer()
    timer_pnu.start()
    grid.fit(x_l, y_l)
    timer_pnu.stop()
    best_model_pnu = grid.best_estimator_
    error_pnu = bin_clf_err(best_model_pnu, x_t, y_t, prior_u) * 100

    timer_fast = Timer()
    timer_fast.start()
    fastcv = PNU_SL_FastCV(x_l, y_l, prior_est, eta_list, lam_list, 3, basis='lm', nargout=1)
    fastcv.fit()
    timer_fast.stop()
    error_fast = bin_clf_err(fastcv, x_t, y_t, prior_u) * 100

    print(f"PNU_SL Test Error: {error_pnu:.2f}%")
    print(f"PNU_SL_FastCV Test Error: {error_fast:.2f}%")