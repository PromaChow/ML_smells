import gym
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import logging
import math
import sys

logging.basicConfig(level=logging.INFO, format="%(message)s")
logger = logging.getLogger(__name__)

class Actor(nn.Module):
    def __init__(self, obs_dim, act_dim):
        super().__init__()
        self.fc1 = nn.Linear(obs_dim, 16)
        self.fc2 = nn.Linear(16, 16)
        self.fc3 = nn.Linear(16, act_dim)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        logits = self.fc3(x)
        return logits

class Critic(nn.Module):
    def __init__(self, obs_dim):
        super().__init__()
        self.fc1 = nn.Linear(obs_dim, 16)
        self.fc2 = nn.Linear(16, 16)
        self.fc3 = nn.Linear(16, 1)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        value = self.fc3(x)
        return value.squeeze(-1)

class PPO:
    def __init__(self, actor, critic, lr=3e-4, gamma=0.99, clip_eps=0.2, entropy_coef=0.01):
        self.actor = actor
        self.critic = critic
        self.gamma = gamma
        self.clip_eps = clip_eps
        self.entropy_coef = entropy_coef
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=lr)
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=lr)
        self.memory = []

    def act(self, state):
        state = torch.tensor(state, dtype=torch.float32)
        logits = self.actor(state)
        dist = torch.distributions.Categorical(logits=logits)
        action = dist.sample()
        logprob = dist.log_prob(action)
        entropy = dist.entropy()
        return int(action.item()), logprob, entropy

    def store_transition(self, transition):
        self.memory.append(transition)

    def store_episode(self, episode_transitions):
        self.memory.extend(episode_transitions)

    def update(self):
        if not self.memory:
            return
        states = torch.tensor([t[0] for t in self.memory], dtype=torch.float32)
        actions = torch.tensor([t[1] for t in self.memory], dtype=torch.int64)
        rewards = [t[2] for t in self.memory]
        dones = [t[3] for t in self.memory]

        # Compute returns and advantages
        returns = []
        G = 0
        for r, d in zip(reversed(rewards), reversed(dones)):
            if d:
                G = 0
            G = r + self.gamma * G
            returns.insert(0, G)
        returns = torch.tensor(returns, dtype=torch.float32)
        values = self.critic(states)
        advantages = returns - values.detach()

        # Policy loss
        logits = self.actor(states)
        dist = torch.distributions.Categorical(logits=logits)
        logprobs = dist.log_prob(actions)
        entropy = dist.entropy().mean()

        ratios = torch.exp(logprobs - torch.log(self.actor(states)[range(len(actions)), actions] + 1e-10))
        surr1 = ratios * advantages
        surr2 = torch.clamp(ratios, 1 - self.clip_eps, 1 + self.clip_eps) * advantages
        policy_loss = -torch.min(surr1, surr2).mean() - self.entropy_coef * entropy

        # Value loss
        value_loss = F.mse_loss(values, returns)

        # Optimize
        self.actor_optimizer.zero_grad()
        policy_loss.backward()
        self.actor_optimizer.step()

        self.critic_optimizer.zero_grad()
        value_loss.backward()
        self.critic_optimizer.step()

        self.memory = []

def main():
    env = gym.make("CartPole-v0")
    obs_dim = env.observation_space.shape[0]
    act_dim = env.action_space.n
    max_episodes = 1000
    max_steps = 200
    solved_reward = 190
    solved_repeat = 5

    actor = Actor(obs_dim, act_dim)
    critic = Critic(obs_dim)
    ppo = PPO(actor, critic)

    smoothed_reward = 0
    reward_fulfilled = 0

    for episode in range(1, max_episodes + 1):
        obs = env.reset()
        if isinstance(obs, tuple):
            obs = obs[0]
        episode_reward = 0
        tmp_transitions = []

        for t in range(max_steps):
            action, logprob, entropy = ppo.act(obs)
            next_obs, reward, done, _, _ = env.step(action)
            if isinstance(next_obs, tuple):
                next_obs = next_obs[0]
            episode_reward += reward
            tmp_transitions.append((obs, action, reward, done))
            obs = next_obs
            if done:
                break

        ppo.store_episode(tmp_transitions)
        ppo.update()

        smoothed_reward = smoothed_reward * 0.9 + episode_reward * 0.1

        if smoothed_reward > solved_reward:
            reward_fulfilled += 1
            if reward_fulfilled >= solved_repeat:
                logger.info(f"Solved at episode {episode} with smoothed reward {smoothed_reward:.2f}")
                break
        else:
            reward_fulfilled = 0

        logger.info(f"Episode {episode}\tReward: {episode_reward:.2f}\tSmoothed: {smoothed_reward:.2f}")

if __name__ == "__main__":
    main()
