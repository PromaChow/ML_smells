import numpy as np
import random
from sklearn.svm import SVC
from scikitTSVM import SKTSVM
from CPLELearningModel import CPLELearningModel
from evaluate_and_plot import evaluate_and_plot

# Parameter setup
kernel = 'linear'
n_samples = 60
n_supervised = 2
noise_prob = 0.1

# Data generation
mean = [0.5, 0.5]
cov = [[0.5, 0], [0, 0.5]]
Xs = np.random.multivariate_normal(mean, cov, size=n_samples)

# True labels
ytrue = np.where(np.sum(Xs, axis=1) > 1, 1, -1)

# Introduce noise in 10% of samples
n_noise = int(noise_prob * n_samples)
noise_indices = np.random.choice(n_samples, n_noise, replace=False)
ytrue[noise_indices] = np.random.choice([-1, 1], size=n_noise)

# Pseudo-labels
ys = -np.ones(n_samples, dtype=int)

# Randomly select one labeled sample per class
class1_indices = np.where(ytrue == 1)[0]
class_minus1_indices = np.where(ytrue == -1)[0]
if len(class1_indices) > 0:
    idx1 = np.random.choice(class1_indices)
    ys[idx1] = ytrue[idx1]
if len(class_minus1_indices) > 0:
    idx_minus1 = np.random.choice(class_minus1_indices)
    ys[idx_minus1] = ytrue[idx_minus1]

# Model 1: Purely Supervised SVM
labeled_indices = np.where(ys != -1)[0]
svm_supervised = SVC(kernel=kernel)
svm_supervised.fit(Xs[labeled_indices], ytrue[labeled_indices])
pred_supervised = svm_supervised.predict(Xs)
evaluate_and_plot(Xs, ytrue, ys, pred_supervised, title='Purely Supervised SVM')

# Model 2: S3VM (SKTSVM)
s3vm = SKTSVM(kernel=kernel)
s3vm.fit(Xs, ys)
pred_s3vm = s3vm.predict(Xs)
evaluate_and_plot(Xs, ytrue, ys, pred_s3vm, title='S3VM (Gieseke et al. 2012)')

# Model 3: CPLE (pessimistic)
cple_pess = CPLELearningModel(estimator=SVC(kernel=kernel))
cple_pess.set_uncertainty('pessimistic')
cple_pess.fit(Xs, ys)
pred_cple_pess = cple_pess.predict(Xs)
evaluate_and_plot(Xs, ytrue, ys, pred_cple_pess, title='CPLE (pessimistic)')

# Model 4: CPLE (optimistic)
cple_opt = CPLELearningModel(estimator=SVC(kernel=kernel))
cple_opt.set_uncertainty('optimistic')
cple_opt.fit(Xs, ys)
pred_cple_opt = cple_opt.predict(Xs)
evaluate_and_plot(Xs, ytrue, ys, pred_cple_opt, title='CPLE (optimistic)')