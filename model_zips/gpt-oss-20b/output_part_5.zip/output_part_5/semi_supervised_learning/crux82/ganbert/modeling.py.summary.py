import json
import math
from typing import Any, Dict, Optional, Tuple, Union

import torch
import torch.nn as nn
import torch.nn.functional as F


def _truncated_normal_(tensor: torch.Tensor, mean: float = 0.0, std: float = 0.02) -> torch.Tensor:
    """Fill the tensor with values drawn from a truncated normal distribution."""
    size = tensor.shape
    tmp = tensor.new_empty(size + (4,)).normal_()
    valid = (tmp < 2) & (tmp > -2)
    ind = valid.max(-1, keepdim=True)[1]
    tensor.data.copy_(tmp.gather(-1, ind).squeeze(-1))
    return tensor.mul_(std).add_(mean)


class BertConfig:
    def __init__(
        self,
        vocab_size: int = 30522,
        hidden_size: int = 768,
        num_hidden_layers: int = 12,
        num_attention_heads: int = 12,
        intermediate_size: int = 3072,
        hidden_act: Union[str, nn.Module] = "gelu",
        hidden_dropout_prob: float = 0.1,
        attention_probs_dropout_prob: float = 0.1,
        max_position_embeddings: int = 512,
        type_vocab_size: int = 16,
        initializer_range: float = 0.02,
        layer_norm_eps: float = 1e-12,
        do_return_all_layers: bool = False,
        **kwargs,
    ):
        self.vocab_size = vocab_size
        self.hidden_size = hidden_size
        self.num_hidden_layers = num_hidden_layers
        self.num_attention_heads = num_attention_heads
        self.intermediate_size = intermediate_size
        self.hidden_act = hidden_act
        self.hidden_dropout_prob = hidden_dropout_prob
        self.attention_probs_dropout_prob = attention_probs_dropout_prob
        self.max_position_embeddings = max_position_embeddings
        self.type_vocab_size = type_vocab_size
        self.initializer_range = initializer_range
        self.layer_norm_eps = layer_norm_eps
        self.do_return_all_layers = do_return_all_layers
        for k, v in kwargs.items():
            setattr(self, k, v)

    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> "BertConfig":
        return cls(**config_dict)

    @classmethod
    def from_json_file(cls, json_file: str) -> "BertConfig":
        with open(json_file, "r", encoding="utf-8") as f:
            config_dict = json.load(f)
        return cls(**config_dict)


class BertEmbeddings(nn.Module):
    def __init__(self, config: BertConfig):
        super().__init__()
        self.word_embeddings = nn.Embedding(config.vocab_size, config.hidden_size, padding_idx=0)
        self.position_embeddings = nn.Embedding(config.max_position_embeddings, config.hidden_size)
        self.token_type_embeddings = nn.Embedding(config.type_vocab_size, config.hidden_size)
        self.LayerNorm = nn.LayerNorm(config.hidden_size, eps=config.layer_norm_eps)
        self.dropout = nn.Dropout(config.hidden_dropout_prob)
        self._init_weights()

    def _init_weights(self):
        _truncated_normal_(self.word_embeddings.weight, std=self.config.initializer_range)
        _truncated_normal_(self.position_embeddings.weight, std=self.config.initializer_range)
        _truncated_normal_(self.token_type_embeddings.weight, std=self.config.initializer_range)

    @property
    def config(self) -> BertConfig:
        return self._config

    @config.setter
    def config(self, value: BertConfig):
        self._config = value

    def forward(
        self,
        input_ids: torch.Tensor,
        token_type_ids: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        seq_length = input_ids.size(1)
        if token_type_ids is None:
            token_type_ids = torch.zeros_like(input_ids)
        if position_ids is None:
            position_ids = torch.arange(seq_length, dtype=torch.long, device=input_ids.device).unsqueeze(0).expand_as(input_ids)
        words_embeddings = self.word_embeddings(input_ids)
        position_embeddings = self.position_embeddings(position_ids)
        token_type_embeddings = self.token_type_embeddings(token_type_ids)
        embeddings = words_embeddings + position_embeddings + token_type_embeddings
        embeddings = self.LayerNorm(embeddings)
        embeddings = self.dropout(embeddings)
        return embeddings


class BertSelfAttention(nn.Module):
    def __init__(self, config: BertConfig):
        super().__init__()
        if config.hidden_size % config.num_attention_heads != 0:
            raise ValueError(
                f"The hidden size ({config.hidden_size}) is not a multiple of the number of attention "
                f"heads ({config.num_attention_heads})"
            )
        self.num_attention_heads = config.num_attention_heads
        self.attention_head_size = int(config.hidden_size / config.num_attention_heads)
        self.all_head_size = self.num_attention_heads * self.attention_head_size
        self.query = nn.Linear(config.hidden_size, self.all_head_size)
        self.key = nn.Linear(config.hidden_size, self.all_head_size)
        self.value = nn.Linear(config.hidden_size, self.all_head_size)
        self.dropout = nn.Dropout(config.attention_probs_dropout_prob)
        self._init_weights()

    def _init_weights(self):
        _truncated_normal_(self.query.weight, std=self.config.initializer_range)
        _truncated_normal_(self.key.weight, std=self.config.initializer_range)
        _truncated_normal_(self.value.weight, std=self.config.initializer_range)
        if self.query.bias is not None:
            nn.init.zeros_(self.query.bias)
            nn.init.zeros_(self.key.bias)
            nn.init.zeros_(self.value.bias)

    @property
    def config(self) -> BertConfig:
        return self._config

    @config.setter
    def config(self, value: BertConfig):
        self._config = value

    def transpose_for_scores(self, x: torch.Tensor) -> torch.Tensor:
        new_x_shape = x.size()[:-1] + (self.num_attention_heads, self.attention_head_size)
        x = x.view(*new_x_shape)
        return x.permute(0, 2, 1, 3)

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        mixed_query_layer = self.query(hidden_states)
        mixed_key_layer = self.key(hidden_states)
        mixed_value_layer = self.value(hidden_states)
        query_layer = self.transpose_for_scores(mixed_query_layer)
        key_layer = self.transpose_for_scores(mixed_key_layer)
        value_layer = self.transpose_for_scores(mixed_value_layer)
        attention_scores = torch.matmul(query_layer, key_layer.transpose(-1, -2))
        attention_scores = attention_scores / math.sqrt(float(self.attention_head_size))
        attention_scores = attention_scores + attention_mask
        attention_probs = nn.Softmax(dim=-1)(attention_scores)
        attention_probs = self.dropout(attention_probs)
        context_layer = torch.matmul(attention_probs, value_layer)
        context_layer = context_layer.permute(0, 2, 1, 3).contiguous()
        new_context_shape = context_layer.size()[:-2] + (self.all_head_size,)
        context_layer = context_layer.view(*new_context_shape)
        return context_layer, attention_probs


class BertAttention(nn.Module):
    def __init__(self, config: BertConfig):
        super().__init__()
        self.self = BertSelfAttention(config)
        self.output_dense = nn.Linear(config.hidden_size, config.hidden_size)
        self.output_dropout = nn.Dropout(config.hidden_dropout_prob)
        self.output_layer_norm = nn.LayerNorm(config.hidden_size, eps=config.layer_norm_eps)
        self._init_weights()

    def _init_weights(self):
        _truncated_normal_(self.output_dense.weight, std=self.config.initializer_range)
        if self.output_dense.bias is not None:
            nn.init.zeros_(self.output_dense.bias)

    @property
    def config(self) -> BertConfig:
        return self._config

    @config.setter
    def config(self, value: BertConfig):
        self._config = value

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        self_output, attention_probs = self.self(hidden_states, attention_mask)
        attention_output = self.output_dense(self_output)
        attention_output = self.output_dropout(attention_output)
        attention_output = self.output_layer_norm(attention_output + hidden_states)
        return attention_output, attention_probs


class BertIntermediate(nn.Module):
    def __init__(self, config: BertConfig):
        super().__init__()
        self.dense = nn.Linear(config.hidden_size, config.intermediate_size)
        if isinstance(config.hidden_act, str):
            if config.hidden_act.lower() == "gelu":
                self.intermediate_act_fn = F.gelu
            else:
                raise ValueError(f"Unsupported hidden_act: {config.hidden_act}")
        else:
            self.intermediate_act_fn = config.hidden_act
        self._init_weights()

    def _init_weights(self):
        _truncated_normal_(self.dense.weight, std=self.config.initializer_range)
        if self.dense.bias is not None:
            nn.init.zeros_(self.dense.bias)

    @property
    def config(self) -> BertConfig:
        return self._config

    @config.setter
    def config(self, value: BertConfig):
        self._config = value

    def forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
        hidden_states = self.dense(hidden_states)
        hidden_states = self.intermediate_act_fn(hidden_states)
        return hidden_states


class BertOutput(nn.Module):
    def __init__(self, config: BertConfig):
        super().__init__()
        self.dense = nn.Linear(config.intermediate_size, config.hidden_size)
        self.dropout = nn.Dropout(config.hidden_dropout_prob)
        self.LayerNorm = nn.LayerNorm(config.hidden_size, eps=config.layer_norm_eps)
        self._init_weights()

    def _init_weights(self):
        _truncated_normal_(self.dense.weight, std=self.config.initializer_range)
        if self.dense.bias is not None:
            nn.init.zeros_(self.dense.bias)

    @property
    def config(self) -> BertConfig:
        return self._config

    @config.setter
    def config(self, value: BertConfig):
        self._config = value

    def forward(self, hidden_states: torch.Tensor, input_tensor: torch.Tensor) -> torch.Tensor:
        hidden_states = self.dense(hidden_states)
        hidden_states = self.dropout(hidden_states)
        hidden_states = self.LayerNorm(hidden_states + input_tensor)
        return hidden_states


class BertLayer(nn.Module):
    def __init__(self, config: BertConfig):
        super().__init__()
        self.attention = BertAttention(config)
        self.intermediate = BertIntermediate(config)
        self.output = BertOutput(config)

    def forward(self, hidden_states: torch.Tensor, attention_mask: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        attention_output, attention_probs = self.attention(hidden_states, attention_mask)
        intermediate_output = self.intermediate(attention_output)
        layer_output = self.output(intermediate_output, attention_output)
        return layer_output, attention_probs


class BertEncoder(nn.Module):
    def __init__(self, config: BertConfig):
        super().__init__()
        self.config = config
        self.layer = nn.ModuleList([BertLayer(config) for _ in range(config.num_hidden_layers)])

    def forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        all_hidden_states = ()
        all_attn_probs = ()
        for layer_module in self.layer:
            hidden_states, attn_probs = layer_module(hidden_states, attention_mask)
            if self.config.do_return_all_layers:
                all_hidden_states = all_hidden_states + (hidden_states,)
                all_attn_probs = all_attn_probs + (attn_probs,)
        if self.config.do_return_all_layers:
            return all_hidden_states, all_attn_probs
        else:
            return hidden_states, all_attn_probs


class BertPooler(nn.Module):
    def __init__(self, config: BertConfig):
        super().__init__()
        self.dense = nn.Linear(config.hidden_size, config.hidden_size)
        self.activation = nn.Tanh()
        self._init_weights()

    def _init_weights(self):
        _truncated_normal_(self.dense.weight, std=self.config.initializer_range)
        if self.dense.bias is not None:
            nn.init.zeros_(self.dense.bias)

    @property
    def config(self) -> BertConfig:
        return self._config

    @config.setter
    def config(self, value: BertConfig):
        self._config = value

    def forward(self, hidden_states: torch.Tensor) -> torch.Tensor:
        first_token_tensor = hidden_states[:, 0]
        pooled_output = self.dense(first_token_tensor)
        pooled_output = self.activation(pooled_output)
        return pooled_output


def _expand_mask(mask: torch.Tensor, dtype: torch.dtype, tgt_len: Optional[int] = None) -> torch.Tensor:
    """Create 2D attention mask from 1D mask."""
    if tgt_len is None:
        tgt_len = mask.size(-1)
    mask = mask.unsqueeze(1).unsqueeze(2)  # [batch, 1, 1, seq_len]
    mask = mask.to(dtype)
    mask = (1.0 - mask) * -10000.0
    return mask


class BertModel(nn.Module):
    def __init__(self, config: BertConfig):
        super().__init__()
        self.config = config
        self.embeddings = BertEmbeddings(config)
        self.encoder = BertEncoder(config)
        self.pooler = BertPooler(config)
        self.init_weights()

    def init_weights(self):
        self.embeddings._init_weights()
        self.encoder
        self.pooler._init_weights()

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        token_type_ids: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        if attention_mask is None:
            attention_mask = torch.ones_like(input_ids)
        if token_type_ids is None:
            token_type_ids = torch.zeros_like(input_ids)
        extended_attention_mask = _expand_mask(attention_mask, dtype=input_ids.dtype, tgt_len=input_ids.size(-1))
        embedding_output = self.embeddings(input_ids, token_type_ids=token_type_ids, position_ids=position_ids)
        encoder_outputs = self.encoder(embedding_output, extended_attention_mask)
        if self.config.do_return_all_layers:
            sequence_output, all_attn_probs = encoder_outputs
            sequence_output = sequence_output[-1]
        else:
            sequence_output, all_attn_probs = encoder_outputs
        pooled_output = self.pooler(sequence_output)
        return sequence_output, pooled_output
