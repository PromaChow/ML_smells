import unittest
import numpy as np
from pywsl import PU_SL, gen_twonorm_pu, bin_clf_err
from sklearn.model_selection import GridSearchCV


class TestPUSLModel(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Synthetic data generation
        n_p, n_u, n_t = 30, 200, 100
        cls.x, cls.y, cls.x_u, cls.y_u, cls.x_t, cls.y_t = gen_twonorm_pu(
            n_p=n_p,
            n_u=n_u,
            n_t=n_t,
            prior=0.5,
            random_state=0
        )
        cls.prior = 0.5

    def test_fit(self):
        model = PU_SL(prior=self.prior, basis='lm')
        model.fit(self.x, self.y)
        preds = model.predict(self.x_t)
        error = bin_clf_err(self.y_t, preds, prior=self.prior)
        self.assertLess(error, 0.2, msg=f"Fit error too high: {error}")

    def test_cv(self):
        param_grid = {
            'prior': [self.prior],
            'lam': np.logspace(-3, 1, 5),
            'basis': ['lm']
        }
        grid = GridSearchCV(PU_SL(), param_grid, cv=5, n_jobs=1)
        grid.fit(self.x, self.y)
        best_model = grid.best_estimator_
        preds = best_model.predict(self.x_t)
        error = bin_clf_err(self.y_t, preds, prior=self.prior)
        self.assertLess(error, 0.2, msg=f"CV error too high: {error}")


if __name__ == "__main__":
    unittest.main()