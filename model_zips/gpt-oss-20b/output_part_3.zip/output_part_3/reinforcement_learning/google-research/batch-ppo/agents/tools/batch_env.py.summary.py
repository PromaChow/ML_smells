import numpy as np

class BatchEnv:
    """
    A batched environment wrapper that aggregates multiple environments into a single interface.
    """

    def __init__(self, envs, blocking=True):
        """
        Parameters
        ----------
        envs : list
            List of environment instances.
        blocking : bool, optional
            If True, all operations are performed synchronously. If False, operations can be
            performed asynchronously and returned as callables.
        """
        if not envs:
            raise ValueError("The envs list must not be empty.")
        self.envs = list(envs)
        self.blocking = blocking

        # Validate that all environments share the same observation and action spaces
        first_obs_space = self.envs[0].observation_space
        first_act_space = self.envs[0].action_space
        for env in self.envs[1:]:
            if env.observation_space != first_obs_space or env.action_space != first_act_space:
                raise ValueError("All environments must have identical observation and action spaces.")

    def step(self, actions):
        """
        Step all environments with the provided batch of actions.

        Parameters
        ----------
        actions : sequence
            Actions for each environment. Must have the same length as the number of environments.

        Returns
        -------
        observations : ndarray
            Batched observations.
        rewards : ndarray
            Batched rewards.
        dones : ndarray
            Batched done flags.
        infos : tuple
            Tuple of info dictionaries from each environment.
        """
        if len(actions) != len(self.envs):
            raise ValueError("Number of actions must match number of environments.")

        # Validate actions
        for env, act in zip(self.envs, actions):
            if not env.action_space.contains(act):
                raise ValueError(f"Invalid action {act} for environment {env}")

        observations = []
        rewards = []
        dones = []
        infos = []

        if self.blocking:
            for env, act in zip(self.envs, actions):
                obs, rew, done, info = env.step(act)
                observations.append(obs)
                rewards.append(rew)
                dones.append(done)
                infos.append(info)
        else:
            callables = []
            for env, act in zip(self.envs, actions):
                step_callable = env.step(act, blocking=False)
                if not callable(step_callable):
                    raise RuntimeError("Environment returned non-callable when blocking=False.")
                callables.append(step_callable)

            for step_callable in callables:
                obs, rew, done, info = step_callable()
                observations.append(obs)
                rewards.append(rew)
                dones.append(done)
                infos.append(info)

        observations = np.stack(observations, axis=0)
        rewards = np.stack(rewards, axis=0)
        dones = np.stack(dones, axis=0)

        return observations, rewards, dones, tuple(infos)

    def reset(self, indices=None):
        """
        Reset specified environments and return batched observations.

        Parameters
        ----------
        indices : sequence or None, optional
            Indices of environments to reset. If None, all environments are reset.

        Returns
        -------
        observations : ndarray
            Batched observations after reset.
        """
        if indices is None:
            indices = range(len(self.envs))

        observations = []

        if self.blocking:
            for idx in indices:
                obs = self.envs[idx].reset()
                observations.append(obs)
        else:
            callables = []
            for idx in indices:
                reset_callable = self.envs[idx].reset(blocking=False)
                if not callable(reset_callable):
                    raise RuntimeError("Environment returned non-callable when resetting with blocking=False.")
                callables.append(reset_callable)

            for reset_callable in callables:
                obs = reset_callable()
                observations.append(obs)

        return np.stack(observations, axis=0)

    def close(self):
        """
        Close all underlying environments.
        """
        for env in self.envs:
            if hasattr(env, "close"):
                env.close()