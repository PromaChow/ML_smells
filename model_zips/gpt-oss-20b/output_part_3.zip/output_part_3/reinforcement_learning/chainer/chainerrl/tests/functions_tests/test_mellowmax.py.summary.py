import itertools
import numpy

import chainer
import chainer.functions as F
import chainer.cuda as cuda
from chainer import testing


# Parameter sets for the tests
shapes = [(1, 1), (2, 3), (3, 2, 4)]
dtypes = [numpy.float32]
omegas = [-10.0, -1.0, 0.0, 1.0, 10.0]
axes = [0, 1, -1, -2]
same_values = [True, False]

params = []
for shape, dtype, omega, axis, same_value in itertools.product(
    shapes, dtypes, omegas, axes, same_values
):
    params.append(
        dict(
            shape=shape,
            dtype=dtype,
            omega=omega,
            axis=axis,
            same_value=same_value,
        )
    )


@testing.parameterize(*params)
class TestMellowmax(testing.TestCase):
    def setUp(self):
        self.x = numpy.random.randn(*self.shape).astype(self.dtype)
        if self.same_value:
            self.x.fill(numpy.random.randn())

    def _check_forward(self, x):
        y = F.mellowmax(x, omega=self.omega, axis=self.axis)
        testing.assert_equal(y.dtype, self.dtype)
        testing.assert_less_equal(y.min(), y.max(), err_msg='Output range incorrect')
        testing.assert_less_equal(y.min(), self.x.max(), err_msg='Output > max input')
        testing.assert_less_equal(self.x.min(), y.max(), err_msg='Output < min input')
        if self.omega > 0:
            testing.assert_greater_equal(y.mean(), self.x.mean(), err_msg='Output < mean input')
        if self.omega < 0:
            testing.assert_less_equal(y.mean(), self.x.mean(), err_msg='Output > mean input')

    def test_forward_cpu(self):
        self._check_forward(self.x)

    @testing.attr('needs-cuda')
    def test_forward_gpu(self):
        with cuda.get_device_from_id(0).use():
            x_gpu = cuda.to_gpu(self.x)
            self._check_forward(x_gpu)


@testing.parameterize(*params)
class TestMaximumEntropyMellowmax(testing.TestCase):
    def setUp(self):
        self.x = numpy.random.randn(*self.shape).astype(self.dtype)
        if self.same_value:
            self.x.fill(numpy.random.randn())

    def _check_forward(self, x):
        y = F.maximum_entropy_mellowmax(x, omega=self.omega, axis=self.axis)
        testing.assert_equal(y.dtype, self.dtype)
        testing.assert_true(numpy.all(y > 0), err_msg='Output contains non‑positive values')
        sum_y = y.sum(axis=self.axis)
        testing.assert_allclose(
            sum_y,
            numpy.ones_like(sum_y),
            atol=1e-4,
            rtol=1e-4,
            err_msg='Probabilities do not sum to 1',
        )
        expected = F.mellowmax(x, omega=self.omega, axis=self.axis)
        expectation = (y * x).sum(axis=self.axis)
        testing.assert_allclose(
            expectation,
            expected,
            atol=1e-4,
            rtol=1e-4,
            err_msg='Expectation does not match mellowmax',
        )

    def test_forward_cpu(self):
        self._check_forward(self.x)

    @testing.attr('needs-cuda')
    def test_forward_gpu(self):
        with cuda.get_device_from_id(0).use():
            x_gpu = cuda.to_gpu(self.x)
            self._check_forward(x_gpu)


if __name__ == '__main__':
    testing.run_module(__name__, __file__)