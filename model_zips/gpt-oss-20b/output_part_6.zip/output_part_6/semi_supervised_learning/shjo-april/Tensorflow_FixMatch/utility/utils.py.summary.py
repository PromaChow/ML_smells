import os
import pickle
import cv2
import numpy as np
import xml.etree.ElementTree as ET
from datetime import datetime
import json

class Colors:
    RESET = '\033[0m'
    BOLD = '\033[01m'
    DIM = '\033[02m'
    UNDERLINE = '\033[04m'
    REVERSED = '\033[07m'
    BLINK = '\033[05m'
    HIDDEN = '\033[08m'

    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[34m'
    MAGENTA = '\033[35m'
    CYAN = '\033[36m'
    WHITE = '\033[37m'

    BG_RED = '\033[41m'
    BG_GREEN = '\033[42m'
    BG_YELLOW = '\033[43m'
    BG_BLUE = '\033[44m'
    BG_MAGENTA = '\033[45m'
    BG_CYAN = '\033[46m'
    BG_WHITE = '\033[47m'

class BlackBackground(Colors):
    TEXT = Colors.WHITE
    BACKGROUND = Colors.BG_BLACK if hasattr(Colors, 'BG_BLACK') else ''

class WhiteBackground(Colors):
    TEXT = Colors.BLACK if hasattr(Colors, 'BLACK') else Colors.BLACK
    BACKGROUND = Colors.BG_WHITE

def load_pickle(file_path: str):
    with open(file_path, 'rb') as f:
        return pickle.load(f)

def dump_pickle(obj, file_path: str):
    with open(file_path, 'wb') as f:
        pickle.dump(obj, f)

def encode_image(img: np.ndarray) -> bytes:
    success, buffer = cv2.imencode('.jpg', img)
    if not success:
        raise ValueError('Image encoding failed')
    return buffer.tobytes()

def decode_image(data: bytes) -> np.ndarray:
    nparr = np.frombuffer(data, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError('Image decoding failed')
    return img

def read_xml(xml_path: str):
    tree = ET.parse(xml_path)
    root = tree.getroot()
    size = root.find('size')
    width = int(size.find('width').text)
    height = int(size.find('height').text)

    boxes = []
    labels = []

    for obj in root.findall('object'):
        name = obj.find('name').text
        bndbox = obj.find('bndbox')
        xmin = int(float(bndbox.find('xmin').text))
        ymin = int(float(bndbox.find('ymin').text))
        xmax = int(float(bndbox.find('xmax').text))
        ymax = int(float(bndbox.find('ymax').text))

        # Clamp to image bounds
        xmin = max(0, min(xmin, width))
        ymin = max(0, min(ymin, height))
        xmax = max(0, min(xmax, width))
        ymax = max(0, min(ymax, height))

        if xmax - xmin <= 0 or ymax - ymin <= 0:
            continue

        boxes.append([xmin, ymin, xmax, ymax])
        labels.append(name)

    boxes_np = np.array(boxes, dtype=int) if boxes else np.empty((0, 4), dtype=int)
    return boxes_np, labels

def get_today() -> str:
    return datetime.now().strftime('%Y-%m-%d-%H%M%S')

def log_print(message: str, log_file: str = 'log.txt'):
    print(message)
    with open(log_file, 'a', encoding='utf-8') as f:
        f.write(message + '\n')

def csv_print(data: list, csv_file: str = 'log.csv'):
    line = ','.join(map(str, data))
    with open(csv_file, 'a', encoding='utf-8') as f:
        f.write(line + '\n')

def read_json(json_path: str):
    with open(json_path, 'r', encoding='utf-8') as f:
        return json.load(f)

def write_json(data, json_path: str):
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4)

def single_one_hot(label: int, num_classes: int) -> np.ndarray:
    if label < 0 or label >= num_classes:
        raise ValueError('Label out of range')
    vec = np.zeros(num_classes, dtype=int)
    vec[label] = 1
    return vec

def multiple_one_hot(labels: list, num_classes: int) -> np.ndarray:
    vec = np.zeros(num_classes, dtype=int)
    for lbl in labels:
        if lbl < 0 or lbl >= num_classes:
            raise ValueError('Label out of range')
        vec[lbl] = 1
    return vec

if __name__ == "__main__":
    # Example usage
    today = get_today()
    log_print(f"Script started at {today}")

    # Dummy image array
    dummy_img = np.zeros((100, 100, 3), dtype=np.uint8)
    encoded = encode_image(dummy_img)
    decoded = decode_image(encoded)
    log_print(f"Encoded size: {len(encoded)} bytes, Decoded shape: {decoded.shape}")

    # Example one-hot
    vec = single_one_hot(3, 10)
    log_print(f"One-hot vector for label 3: {vec}")

    # Example XML parsing (needs actual file path)
    # boxes, labels = read_xml('sample.xml')
    # log_print(f"Parsed {len(boxes)} boxes")
    pass

