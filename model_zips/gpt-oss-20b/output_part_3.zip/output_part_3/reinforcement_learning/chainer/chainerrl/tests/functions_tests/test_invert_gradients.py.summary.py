import unittest
import numpy as np
import chainer
from chainer import Variable
import chainer.functions as F
import chainer.testing as testing
from chainer import attr
import chainer.cuda as cuda
from chainer.cuda import get_array_module


@testing.parameterize(
    dict(shape=(), dtype=np.float32),
    dict(shape=(1, 1), dtype=np.float32),
    dict(shape=(2, 3), dtype=np.float32),
    dict(shape=(4, 5, 6), dtype=np.float32),
)
class TestInvertGradients(unittest.TestCase):
    def setUp(self):
        self.x_data = np.random.uniform(-1, 1, self.shape).astype(self.dtype)
        self.x = Variable(self.x_data)

    def check_forward(self, x):
        xp = get_array_module(x.data)

        # Case 1: No Range Exceedance
        range_min = xp.array(self.x_data - 0.1, dtype=self.dtype)
        range_max = xp.array(self.x_data + 0.1, dtype=self.dtype)
        y = F.invert_gradients(x, range_min=range_min, range_max=range_max)

        loss = y.sum()
        loss.backward()
        self.assertTrue(np.all(x.grad > 0))
        x.cleargrad()

        loss = (-y).sum()
        loss.backward()
        self.assertTrue(np.all(x.grad < 0))
        x.cleargrad()

        # Case 2: Exceeding range_max
        range_min = xp.array(self.x_data - 0.2, dtype=self.dtype)
        range_max = xp.array(self.x_data - 0.1, dtype=self.dtype)
        y = F.invert_gradients(x, range_min=range_min, range_max=range_max)

        loss = y.sum()
        loss.backward()
        self.assertTrue(np.all(x.grad > 0))
        x.cleargrad()

        loss = (-y).sum()
        loss.backward()
        self.assertTrue(np.all(x.grad > 0))
        x.cleargrad()

        # Case 3: Exceeding range_min
        range_min = xp.array(self.x_data + 0.1, dtype=self.dtype)
        range_max = xp.array(self.x_data + 0.2, dtype=self.dtype)
        y = F.invert_gradients(x, range_min=range_min, range_max=range_max)

        loss = y.sum()
        loss.backward()
        self.assertTrue(np.all(x.grad < 0))
        x.cleargrad()

        loss = (-y).sum()
        loss.backward()
        self.assertTrue(np.all(x.grad < 0))
        x.cleargrad()

    def test_forward_cpu(self):
        for _ in range(2):
            try:
                self.check_forward(self.x)
                break
            except AssertionError:
                continue

    @attr.gpu
    def test_forward_gpu(self):
        x_gpu = cuda.to_gpu(self.x.data)
        x_var_gpu = Variable(x_gpu)
        for _ in range(2):
            try:
                self.check_forward(x_var_gpu)
                break
            except AssertionError:
                continue


if __name__ == "__main__":
    testing.run_module(__name__, __file__)