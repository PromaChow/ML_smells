import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics.pairwise import cosine_similarity
import matplotlib.pyplot as plt
import seaborn as sns

def arctanh_clip(y: np.ndarray, eps: float = 1e-6) -> np.ndarray:
    """Clip values to the open interval (-1, 1) and apply arctanh."""
    y_clipped = np.clip(y, -1 + eps, 1 - eps)
    return np.arctanh(y_clipped)

def find_feature_axis(z: np.ndarray, y: np.ndarray, method: str = "linear") -> np.ndarray:
    """
    Fit a linear model (or its tanh-transformed variant) to predict y from z.
    Returns feature axes as a matrix of shape (num_latent_dim, num_features).
    """
    if method == "tanh":
        y = arctanh_clip(y)
    model = LinearRegression().fit(z, y)
    # coef_ shape: (num_features, num_latent_dim)
    return model.coef_.T  # shape: (num_latent_dim, num_features)

def normalize_feature_axis(feature_axes: np.ndarray) -> np.ndarray:
    """
    Normalize each feature axis (column) to unit L2 norm.
    """
    norms = np.linalg.norm(feature_axes, axis=0, keepdims=True)
    norms[norms == 0] = 1.0
    return feature_axes / norms

def orthogonalize_one_vector(v: np.ndarray, base: np.ndarray) -> np.ndarray:
    """
    Subtract the projection of v onto base (Gram–Schmidt step).
    """
    base_norm_sq = np.dot(base, base)
    if base_norm_sq == 0:
        return v.copy()
    projection = (np.dot(v, base) / base_norm_sq) * base
    return v - projection

def orthogonalize_vectors(vectors: np.ndarray) -> np.ndarray:
    """
    Orthogonalize a set of vectors column-wise using Gram–Schmidt.
    """
    ortho = vectors.copy()
    n = ortho.shape[1]
    for i in range(n):
        for j in range(i):
            ortho[:, i] = orthogonalize_one_vector(ortho[:, i], ortho[:, j])
    return ortho

def disentangle_feature_axis(
    feature_axis_target: np.ndarray,
    feature_axis_base: np.ndarray,
    skip_orthogonalize_base: bool = False,
) -> np.ndarray:
    """
    Decorrelate target feature axes from the base feature axes.
    """
    if not skip_orthogonalize_base:
        feature_axis_base = orthogonalize_vectors(feature_axis_base)
    target = feature_axis_target.copy()
    for j in range(feature_axis_base.shape[1]):
        base_vec = feature_axis_base[:, j]
        for i in range(target.shape[1]):
            target[:, i] = orthogonalize_one_vector(target[:, i], base_vec)
    return target

def disentangle_feature_axis_by_idx(
    feature_axes: np.ndarray,
    base_indices: list[int] | np.ndarray,
    target_indices: list[int] | np.ndarray,
    normalize: bool = True,
) -> np.ndarray:
    """
    Perform index-based disentanglement and optional normalization.
    """
    if base_indices is None or len(base_indices) == 0:
        return feature_axes.copy()
    feature_axes = feature_axes.copy()
    base_axes = feature_axes[:, base_indices]
    target_axes = feature_axes[:, target_indices]
    base_axes_ortho = orthogonalize_vectors(base_axes)
    target_axes_disentangled = disentangle_feature_axis(
        target_axes, base_axes_ortho, skip_orthogonalize_base=True
    )
    feature_axes[:, base_indices] = base_axes_ortho
    feature_axes[:, target_indices] = target_axes_disentangled
    if normalize:
        feature_axes = normalize_feature_axis(feature_axes)
    return feature_axes

def plot_feature_correlation(feature_axes: np.ndarray, title: str = "Feature Correlation Heatmap"):
    """
    Plot a heatmap of pairwise correlation between feature axes.
    """
    corr = np.corrcoef(feature_axes, rowvar=False)
    plt.figure(figsize=(8, 6))
    sns.heatmap(corr, annot=False, cmap="coolwarm", square=True,
                cbar_kws={"shrink": .5})
    plt.title(title)
    plt.xlabel("Feature")
    plt.ylabel("Feature")
    plt.tight_layout()
    plt.show()

def plot_feature_cos_sim(feature_axes: np.ndarray, title: str = "Feature Cosine Similarity Heatmap"):
    """
    Plot a heatmap of pairwise cosine similarity between feature axes.
    """
    cos_sim = cosine_similarity(feature_axes.T)
    plt.figure(figsize=(8, 6))
    sns.heatmap(cos_sim, annot=False, cmap="viridis", square=True,
                cbar_kws={"shrink": .5})
    plt.title(title)
    plt.xlabel("Feature")
    plt.ylabel("Feature")
    plt.tight_layout()
    plt.show()