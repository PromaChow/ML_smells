import random
import numpy as np
import matplotlib.pyplot as plt
from collections import defaultdict
import env  # assumes env.py provides final_states() and obstacle_states (optional)


class SarsaTable:
    def __init__(self, actions, lr=0.01, gamma=0.9, epsilon=0.9):
        self.actions = actions
        self.lr = lr
        self.gamma = gamma
        self.epsilon = epsilon
        self.q_table = defaultdict(lambda: {a: 0.0 for a in self.actions})
        self.q_table_final = defaultdict(lambda: {a: 0.0 for a in self.actions})

    def check_state_exist(self, state):
        if state not in self.q_table:
            self.q_table[state] = {a: 0.0 for a in self.actions}

    def is_terminal(self, state):
        goal_states = set(env.final_states())
        obstacle_states = getattr(env, 'obstacle_states', set())
        return state in goal_states or state in obstacle_states

    def choose_action(self, state):
        self.check_state_exist(state)
        if random.random() < self.epsilon:
            q_values = self.q_table[state]
            max_q = max(q_values.values())
            actions_with_max_q = [a for a, q in q_values.items() if q == max_q]
            return random.choice(actions_with_max_q)
        else:
            return random.choice(self.actions)

    def learn(self, state, action, reward, next_state, next_action):
        self.check_state_exist(next_state)
        q_predict = self.q_table[state][action]
        if self.is_terminal(next_state):
            q_target = reward
        else:
            q_target = reward + self.gamma * self.q_table[next_state][next_action]
        self.q_table[state][action] += self.lr * (q_target - q_predict)

    def print_q_table(self):
        final_states = set(env.final_states())
        for state, actions in self.q_table.items():
            if state in final_states:
                self.q_table_final[state] = actions.copy()

    def plot_results(self, steps_per_episode, cost_per_episode):
        episodes = range(1, len(steps_per_episode) + 1)

        fig, axes = plt.subplots(2, 1, figsize=(10, 8))
        axes[0].plot(episodes, steps_per_episode, label='Steps per Episode')
        axes[0].set_xlabel('Episode')
        axes[0].set_ylabel('Steps')
        axes[0].legend()
        axes[0].grid(True)

        axes[1].plot(episodes, cost_per_episode, label='Cost per Episode', color='orange')
        axes[1].set_xlabel('Episode')
        axes[1].set_ylabel('Cost')
        axes[1].legend()
        axes[1].grid(True)

        plt.tight_layout()
        plt.show()
        plt.close()

        plt.figure(figsize=(6, 4))
        plt.plot(episodes, steps_per_episode, label='Steps per Episode')
        plt.xlabel('Episode')
        plt.ylabel('Steps')
        plt.title('Steps per Episode')
        plt.grid(True)
        plt.legend()
        plt.show()
        plt.close()

        plt.figure(figsize=(6, 4))
        plt.plot(episodes, cost_per_episode, label='Cost per Episode', color='orange')
        plt.xlabel('Episode')
        plt.ylabel('Cost')
        plt.title('Cost per Episode')
        plt.grid(True)
        plt.legend()
        plt.show()
        plt.close()