import random
import time
import collections
import math
from typing import Optional, List, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.tensorboard import SummaryWriter


# ==============================
#  Network Components
# ==============================

class NoisyLinear(nn.Module):
    def __init__(self, in_features: int, out_features: int, sigma_init: float = 0.017):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight_mu = nn.Parameter(torch.empty(out_features, in_features))
        self.weight_sigma = nn.Parameter(torch.empty(out_features, in_features))
        self.register_buffer("weight_epsilon", torch.empty(out_features, in_features))
        self.bias_mu = nn.Parameter(torch.empty(out_features))
        self.bias_sigma = nn.Parameter(torch.empty(out_features))
        self.register_buffer("bias_epsilon", torch.empty(out_features))
        self.sigma_init = sigma_init
        self.reset_parameters()
        self.reset_noise()

    def reset_parameters(self):
        mu_range = 1 / math.sqrt(self.in_features)
        self.weight_mu.data.uniform_(-mu_range, mu_range)
        self.weight_sigma.data.fill_(self.sigma_init)
        self.bias_mu.data.uniform_(-mu_range, mu_range)
        self.bias_sigma.data.fill_(self.sigma_init)

    def reset_noise(self):
        epsilon_in = self._f(torch.randn(self.in_features))
        epsilon_out = self._f(torch.randn(self.out_features))
        self.weight_epsilon.copy_(epsilon_out.ger(epsilon_in))
        self.bias_epsilon.copy_(epsilon_out)

    @staticmethod
    def _f(x):
        return x.sign().mul(x.abs().sqrt())

    def forward(self, input):
        if self.training:
            weight = self.weight_mu + self.weight_sigma * self.weight_epsilon
            bias = self.bias_mu + self.bias_sigma * self.bias_epsilon
        else:
            weight = self.weight_mu
            bias = self.bias_mu
        return nn.functional.linear(input, weight, bias)


class DQNNet(nn.Module):
    def __init__(
        self,
        state_dim: int,
        action_dim: int,
        hidden_dim: int = 128,
        dueling: bool = False,
        noisy: bool = False,
    ):
        super().__init__()
        self.dueling = dueling
        self.noisy = noisy
        layer_cls = NoisyLinear if noisy else nn.Linear

        self.feature = nn.Sequential(
            layer_cls(state_dim, hidden_dim),
            nn.ReLU(),
            layer_cls(hidden_dim, hidden_dim),
            nn.ReLU(),
        )

        if dueling:
            self.value_stream = nn.Sequential(
                layer_cls(hidden_dim, hidden_dim),
                nn.ReLU(),
                layer_cls(hidden_dim, 1),
            )
            self.advantage_stream = nn.Sequential(
                layer_cls(hidden_dim, hidden_dim),
                nn.ReLU(),
                layer_cls(hidden_dim, action_dim),
            )
        else:
            self.head = layer_cls(hidden_dim, action_dim)

    def forward(self, x):
        x = self.feature(x)
        if self.dueling:
            value = self.value_stream(x)
            advantage = self.advantage_stream(x)
            q = value + advantage - advantage.mean(dim=1, keepdim=True)
        else:
            q = self.head(x)
        return q


# ==============================
#  Replay Buffer with n-step
# ==============================

Experience = collections.namedtuple(
    "Experience",
    ["state", "action", "next_state", "reward", "done"],
)

class ReplayBuffer:
    def __init__(
        self,
        capacity: int,
        batch_size: int,
        gamma: float,
        n_step: int,
        device: torch.device,
    ):
        self.capacity = capacity
        self.batch_size = batch_size
        self.gamma = gamma
        self.n_step = n_step
        self.device = device
        self.buffer = collections.deque(maxlen=capacity)
        self.n_step_buffer = []

    def push(self, state, action, next_state, reward, done):
        self.n_step_buffer.append((state, action, next_state, reward, done))
        if len(self.n_step_buffer) < self.n_step:
            return
        # compute n-step return
        reward_n = 0.0
        for idx, (_, _, _, r, d) in enumerate(self.n_step_buffer):
            reward_n += (self.gamma ** idx) * r
            if d:
                break
        state_n = self.n_step_buffer[0][0]
        action_n = self.n_step_buffer[0][1]
        next_state_n = self.n_step_buffer[-1][2]
        done_n = self.n_step_buffer[-1][4]
        exp = Experience(
            torch.tensor(state_n, dtype=torch.float32, device=self.device),
            action_n,
            torch.tensor(next_state_n, dtype=torch.float32, device=self.device),
            reward_n,
            done_n,
        )
        self.buffer.append(exp)
        if done:
            self.n_step_buffer.clear()
        else:
            self.n_step_buffer.pop(0)

    def sample(self):
        batch = random.sample(self.buffer, self.batch_size)
        states = torch.stack([e.state for e in batch])
        actions = torch.tensor([e.action for e in batch], dtype=torch.long, device=self.device)
        next_states = torch.stack([e.next_state for e in batch])
        rewards = torch.tensor([e.reward for e in batch], dtype=torch.float32, device=self.device)
        dones = torch.tensor([e.done for e in batch], dtype=torch.float32, device=self.device)
        return states, actions, next_states, rewards, dones

    def __len__(self):
        return len(self.buffer)


# ==============================
#  Central Control
# ==============================

class CentralControl:
    def __init__(
        self,
        state_dim: int,
        action_dim: int,
        lr: float,
        dueling: bool = False,
        noisy: bool = False,
        double_dqn: bool = False,
        device: torch.device = torch.device("cpu"),
    ):
        self.policy_net = DQNNet(state_dim, action_dim, dueling=dueling, noisy=noisy).to(device)
        self.target_net = DQNNet(state_dim, action_dim, dueling=dueling, noisy=noisy).to(device)
        self.target_net.load_state_dict(self.policy_net.state_dict())
        self.target_net.eval()
        self.optimizer = optim.Adam(self.policy_net.parameters(), lr=lr)
        self.double_dqn = double_dqn
        self.device = device

    def act(self, state: np.ndarray) -> int:
        state_t = torch.tensor(state, dtype=torch.float32, device=self.device).unsqueeze(0)
        with torch.no_grad():
            q_values = self.policy_net(state_t)
        return q_values.max(1)[1].item()

    def optimize(self, batch):
        states, actions, next_states, rewards, dones = batch
        q_values = self.policy_net(states).gather(1, actions.unsqueeze(1)).squeeze(1)

        with torch.no_grad():
            if self.double_dqn:
                next_actions = self.policy_net(next_states).max(1)[1].unsqueeze(1)
                next_q_values = self.target_net(next_states).gather(1, next_actions).squeeze(1)
            else:
                next_q_values = self.target_net(next_states).max(1)[0]
            target_q = rewards + (1 - dones) * self.gamma * next_q_values

        loss = nn.functional.mse_loss(q_values, target_q)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        return loss.item()

    def update_target(self):
        self.target_net.load_state_dict(self.policy_net.state_dict())


# ==============================
#  Agent
# ==============================

class DQNAgent:
    def __init__(
        self,
        env,
        device: torch.device,
        hyperparams: dict,
        writer: Optional[SummaryWriter] = None,
    ):
        self.env = env
        self.device = device
        self.writer = writer

        state_dim = env.observation_space.shape[0]
        action_dim = env.action_space.n

        # Hyperparameters
        self.lr = hyperparams.get("learning_rate", 1e-3)
        self.gamma = hyperparams.get("gamma", 0.99)
        self.batch_size = hyperparams.get("batch_size", 32)
        self.capacity = hyperparams.get("buffer_capacity", 100000)
        self.n_step = hyperparams.get("n_step", 3)
        self.buffer_start_size = hyperparams.get("buffer_start_size", 5000)
        self.n_iter_update_target = hyperparams.get("n_iter_update_target", 1000)
        self.double_dqn = hyperparams.get("double_dqn", True)
        self.dueling = hyperparams.get("dueling", True)
        self.noisy = hyperparams.get("noisy", False)

        # Exploration
        self.epsilon_start = hyperparams.get("epsilon_start", 1.0)
        self.epsilon_end = hyperparams.get("epsilon_end", 0.01)
        self.epsilon_decay = hyperparams.get("epsilon_decay", 0.995)
        self.epsilon = self.epsilon_start

        # Statistics
        self.total_reward = 0.0
        self.iterations = 0
        self.games = 0
        self.rewards_history = []
        self.loss_history = []

        # Components
        self.central = CentralControl(
            state_dim,
            action_dim,
            self.lr,
            dueling=self.dueling,
            noisy=self.noisy,
            double_dqn=self.double_dqn,
            device=self.device,
        )
        self.central.gamma = self.gamma  # expose gamma for target calculation

        self.replay_buffer = ReplayBuffer(
            capacity=self.capacity,
            batch_size=self.batch_size,
            gamma=self.gamma,
            n_step=self.n_step,
            device=self.device,
        )

        self.start_time = time.time()

    def act(self, state: np.ndarray) -> int:
        return self.central.act(state)

    def act_eps_greedy(self, state: np.ndarray) -> int:
        if self.noisy:
            return self.act(state)
        if random.random() < self.epsilon:
            return self.env.action_space.sample()
        else:
            return self.act(state)

    def add_env_feedback(
        self,
        state: np.ndarray,
        action: int,
        next_state: np.ndarray,
        reward: float,
        done: bool,
    ):
        self.replay_buffer.push(state, action, next_state, reward, done)
        self.iterations += 1
        self.total_reward += reward
        self.epsilon = max(self.epsilon * self.epsilon_decay, self.epsilon_end)

    def sample_and_optimize(self):
        if len(self.replay_buffer) < self.buffer_start_size:
            return
        batch = self.replay_buffer.sample()
        loss = self.central.optimize(batch)
        self.loss_history.append(loss)

        if self.iterations % self.n_iter_update_target == 0:
            self.central.update_target()

    def reset_stats(self):
        self.rewards_history.append(self.total_reward)
        self.total_reward = 0.0
        self.games += 1

    def print_info(self):
        elapsed = time.time() - self.start_time
        fps = self.iterations / elapsed if elapsed > 0 else 0.0
        mean_reward = np.mean(self.rewards_history[-40:]) if self.rewards_history else 0.0
        mean_loss = np.mean(self.loss_history) if self.loss_history else 0.0

        info = (
            f"Iter: {self.iterations}, FPS: {fps:.2f}, "
            f"Games: {self.games}, Total Reward: {self.total_reward:.2f}, "
            f"Mean Reward (last 40): {mean_reward:.2f}, Epsilon: {self.epsilon:.3f}, "
            f"Loss: {mean_loss:.5f}"
        )
        print(info)

        if self.writer:
            self.writer.add_scalar("FPS", fps, self.iterations)
            self.writer.add_scalar("TotalReward", self.total_reward, self.iterations)
            self.writer.add_scalar("MeanReward", mean_reward, self.iterations)
            self.writer.add_scalar("Epsilon", self.epsilon, self.iterations)
            self.writer.add_scalar("Loss", mean_loss, self.iterations)

    def train_one_step(self):
        state = self.env.reset()
        done = False
        while not done:
            action = self.act_eps_greedy(state)
            next_state, reward, done, _ = self.env.step(action)
            self.add_env_feedback(state, action, next_state, reward, done)
            self.sample_and_optimize()
            state = next_state
        self.reset_stats()
        self.print_info()
```