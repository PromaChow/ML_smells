import torch
import torch.nn as nn
from abc import ABC, abstractmethod
from typing import Optional


class NeuralNetworkModule(nn.Module, ABC):
    def __init__(self):
        super().__init__()
        self.input_module: Optional[nn.Module] = None
        self.output_module: Optional[nn.Module] = None

    @staticmethod
    def find_child(seq: nn.Sequential, direction: str = "first") -> nn.Module:
        if not isinstance(seq, nn.Sequential):
            return seq
        children = list(seq.children())
        if not children:
            return seq
        if direction == "first":
            return NeuralNetworkModule.find_child(children[0], direction)
        else:
            return NeuralNetworkModule.find_child(children[-1], direction)

    def _module_device(self, module: nn.Module) -> Optional[torch.device]:
        devices = {p.device for p in module.parameters() if p is not None}
        if not devices:
            return None
        if len(devices) > 1:
            raise RuntimeError("Parameters span multiple devices")
        return next(iter(devices))

    def set_input_module(self, module: nn.Module):
        if isinstance(module, NeuralNetworkModule):
            self.input_module = module
        else:
            leaf = self.find_child(module, "first") if isinstance(module, nn.Sequential) else module
            _ = self._module_device(leaf)  # validate device consistency
            self.input_module = leaf

    def set_output_module(self, module: nn.Module):
        if isinstance(module, NeuralNetworkModule):
            self.output_module = module
        else:
            leaf = self.find_child(module, "last") if isinstance(module, nn.Sequential) else module
            _ = self._module_device(leaf)  # validate device consistency
            self.output_module = leaf

    @property
    def input_device(self) -> Optional[torch.device]:
        if self.input_module is None:
            return None
        if isinstance(self.input_module, NeuralNetworkModule):
            return self.input_module.input_device
        return self._module_device(self.input_module)

    @property
    def output_device(self) -> Optional[torch.device]:
        if self.output_module is None:
            return None
        if isinstance(self.output_module, NeuralNetworkModule):
            return self.output_module.output_device
        return self._module_device(self.output_module)

    @abstractmethod
    def forward(self, *args, **kwargs):
        pass


def static_module_wrapper(module: nn.Module) -> nn.Module:
    if isinstance(module, NeuralNetworkModule):
        raise ValueError("Module is already a NeuralNetworkModule")
    if isinstance(module, nn.Sequential):
        leaf = NeuralNetworkModule.find_child(module, "first")
    else:
        leaf = module
    devices = {p.device for p in leaf.parameters() if p is not None}
    if devices and len(devices) > 1:
        raise RuntimeError("Parameters span multiple devices")
    device = next(iter(devices)) if devices else None
    setattr(module, "input_device", device)
    setattr(module, "output_device", device)
    return module


def dynamic_module_wrapper(module: nn.Module) -> NeuralNetworkModule:
    if isinstance(module, NeuralNetworkModule):
        raise ValueError("Module is already a NeuralNetworkModule")

    class _DynamicWrapper(NeuralNetworkModule):
        def __init__(self, wrapped: nn.Module):
            super().__init__()
            self.wrapped_module = wrapped
            self.set_input_module(wrapped)
            self.set_output_module(wrapped)

        def forward(self, *args, **kwargs):
            return self.wrapped_module(*args, **kwargs)

    return _DynamicWrapper(module)