import os
import sys
import glob
import pickle
import numpy as np
import tensorflow as tf
from datetime import datetime
from PIL import Image

# Load feature directions and names
feature_files = glob.glob('./asset_results/pg_gan_celeba_feature_direction_40/feature_direction_*.pkl')
if not feature_files:
    raise FileNotFoundError('No feature direction pickle files found.')
with open(feature_files[0], 'rb') as f:
    data = pickle.load(f)
    feature_direction = data['feature_direction']
    feature_name = data['feature_name']

# Set up model paths
model_code_path = os.path.abspath('./src/model/pggan')
model_weights_path = os.path.abspath('./asset_model/karras2018iclr-celebahq-1024x1024.pkl')
output_dir = os.path.abspath('./asset_results/pggan_celeba_feature_axis_explore')
os.makedirs(output_dir, exist_ok=True)

# Add model path to sys.path and import generator
sys.path.append(model_code_path)
try:
    from generator import Generator
except ImportError:
    raise ImportError('Could not import Generator from model path.')

# Initialize TensorFlow session
tf.compat.v1.disable_eager_execution()
sess = tf.compat.v1.Session()
sess.__enter__()

# Load pre-trained generator
Gs = Generator()
Gs.init_from_ckpt(model_weights_path, sess)

# Determine latent dimension
latent_dim = Gs.n_latent

# Initialize central latent vector
latents_c = np.random.randn(1, latent_dim)

# Exploration parameters
perturbation = 0.07
batch_size = 7

for i_feature, dir_vec in enumerate(feature_direction):
    dir_vec = dir_vec.reshape(1, -1)
    latents_0 = latents_c + perturbation * dir_vec
    latents_1 = latents_c - perturbation * dir_vec

    # Verify magnitude
    diff_sq_mean = np.mean((latents_0 - latents_1) ** 2)
    print(f'Feature {i_feature} ({feature_name[i_feature]}): mean squared diff = {diff_sq_mean:.6f}')

    # Generate interpolated latent vectors
    alphas = np.linspace(0, 1, batch_size)
    latents_interp = np.concatenate([latents_0 * (1 - a) + latents_1 * a for a in alphas], axis=0)

    # Dummy labels
    labels = np.zeros((batch_size, 0))

    # Generate images
    images = Gs.run(latents_interp, labels, is_validation=False, return_latents=False, input_is_latent=True)

    # Post-process and save
    images = np.clip(images, 0, 255).astype(np.uint8)
    for idx, img in enumerate(images):
        img = img.transpose(1, 2, 0)  # NHWC
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f'{timestamp}_{feature_name[i_feature]}_{idx:02d}.png'
        Image.fromarray(img).save(os.path.join(output_dir, filename))

        # Save corresponding label
        label_filename = f'{timestamp}_{feature_name[i_feature]}_{idx:02d}.pkl'
        with open(os.path.join(output_dir, label_filename), 'wb') as f:
            pickle.dump(labels[idx], f)

sess.__exit__(None, None, None)