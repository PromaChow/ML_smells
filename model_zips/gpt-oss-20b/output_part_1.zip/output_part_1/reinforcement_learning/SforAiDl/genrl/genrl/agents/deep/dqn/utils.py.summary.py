import torch
import torch.nn.functional as F
from typing import Optional, Tuple

# ----------------------------------------------------------------------
# Double DQN utilities
# ----------------------------------------------------------------------
def ddqn_q_target(
    agent,
    states: torch.Tensor,
    next_states: torch.Tensor,
    rewards: torch.Tensor,
    dones: torch.Tensor,
    gamma: float,
) -> torch.Tensor:
    """
    Compute the Double DQN target values for a batch.

    Parameters
    ----------
    agent : object
        Agent containing ``model`` and ``target_model`` attributes.
    states : torch.Tensor
        Current state batch, shape (batch, state_dim).
    next_states : torch.Tensor
        Next state batch, shape (batch, state_dim).
    rewards : torch.Tensor
        Reward tensor, shape (batch,).
    dones : torch.Tensor
        Done flag tensor, shape (batch,).
    gamma : float
        Discount factor.

    Returns
    -------
    torch.Tensor
        Target Q-values, shape (batch,).
    """
    with torch.no_grad():
        # Q-values from the online network
        q_next = agent.model(next_states)          # (B, A)
        # Best actions according to the online network
        best_actions = q_next.argmax(dim=1)        # (B,)
        # Q-values from the target network
        q_target = agent.target_model(next_states)  # (B, A)
        # Gather the Q-values of the best actions
        target_q = q_target.gather(1, best_actions.unsqueeze(1)).squeeze(1)
        # Combine rewards with discounted target Q-values
        target = rewards + gamma * target_q * (1.0 - dones)
    return target


def prioritized_q_loss(
    agent,
    states: torch.Tensor,
    actions: torch.Tensor,
    next_states: torch.Tensor,
    rewards: torch.Tensor,
    dones: torch.Tensor,
    gamma: float,
    priorities: Optional[torch.Tensor] = None,
    replay_buffer: Optional[object] = None,
    indices: Optional[torch.Tensor] = None,
    weight: Optional[torch.Tensor] = None,
    epsilon: float = 1e-6,
) -> torch.Tensor:
    """
    Compute weighted MSE loss for prioritized replay and update priorities.

    Parameters
    ----------
    agent : object
        Agent containing ``model`` and ``target_model`` attributes.
    states : torch.Tensor
        Current state batch, shape (B, state_dim).
    actions : torch.Tensor
        Action indices, shape (B,).
    next_states : torch.Tensor
        Next state batch, shape (B, state_dim).
    rewards : torch.Tensor
        Reward tensor, shape (B,).
    dones : torch.Tensor
        Done flag tensor, shape (B,).
    gamma : float
        Discount factor.
    priorities : torch.Tensor, optional
        Priorities for the batch, shape (B,).
    replay_buffer : object, optional
        Replay buffer with ``update_priorities`` method.
    indices : torch.Tensor, optional
        Indices of the samples in the buffer.
    weight : torch.Tensor, optional
        Importance-sampling weights, shape (B,).
    epsilon : float
        Small value to avoid zero priorities.

    Returns
    -------
    torch.Tensor
        Scalar loss value.
    """
    # Current Q-values
    q_values = agent.model(states)                    # (B, A)
    q_sa = q_values.gather(1, actions.unsqueeze(1)).squeeze(1)

    # Target Q-values from Double DQN
    target_q = ddqn_q_target(agent, states, next_states, rewards, dones, gamma)

    # TD error
    td_error = target_q - q_sa

    # Weighted MSE loss
    if weight is None:
        weight = torch.ones_like(td_error)
    loss = (weight * td_error.pow(2)).mean()

    # Update priorities in replay buffer
    if replay_buffer is not None and indices is not None:
        new_priorities = td_error.abs() + epsilon
        replay_buffer.update_priorities(indices, new_priorities)

    return loss


# ----------------------------------------------------------------------
# Categorical (Distributional) DQN utilities
# ----------------------------------------------------------------------
def categorical_greedy_action(agent, state: torch.Tensor) -> int:
    """
    Select action greedily based on the expected value of the categorical distribution.

    Parameters
    ----------
    agent : object
        Agent containing ``model`` and distributional parameters.
    state : torch.Tensor
        Single state, shape (state_dim,).

    Returns
    -------
    int
        Selected action index.
    """
    logits = agent.model(state.unsqueeze(0))          # (1, A, N)
    support = torch.linspace(agent.v_min, agent.v_max, agent.num_atoms, device=logits.device)
    # Expected Q-values
    q_values = (logits.squeeze(0) * support).sum(dim=1)   # (A,)
    return int(q_values.argmax().item())


def categorical_q_values(
    agent,
    states: torch.Tensor,
    actions: torch.Tensor,
) -> torch.Tensor:
    """
    Retrieve categorical Q-values for selected actions.

    Parameters
    ----------
    agent : object
        Agent containing ``model`` and distributional parameters.
    states : torch.Tensor
        State batch, shape (B, state_dim).
    actions : torch.Tensor
        Action indices, shape (B,).

    Returns
    -------
    torch.Tensor
        Q-values distribution, shape (B, N).
    """
    logits = agent.model(states)  # (B, A, N)
    # Expand action indices to match atoms dimension
    actions_expanded = actions.unsqueeze(-1).expand(-1, -1, agent.num_atoms)  # (B, A, N)
    q_dist = logits.gather(1, actions_expanded).squeeze(1)  # (B, N)
    # Numerical stability clamp
    q_dist = q_dist.clamp(0.01, 0.99)
    return q_dist


def categorical_q_target(
    agent,
    next_states: torch.Tensor,
    rewards: torch.Tensor,
    dones: torch.Tensor,
    gamma: float,
) -> torch.Tensor:
    """
    Project the target distribution onto the support (C51 algorithm).

    Parameters
    ----------
    agent : object
        Agent containing ``target_model`` and distributional parameters.
    next_states : torch.Tensor
        Next state batch, shape (B, state_dim).
    rewards : torch.Tensor
        Reward tensor, shape (B,).
    dones : torch.Tensor
        Done flag tensor, shape (B,).
    gamma : float
        Discount factor.

    Returns
    -------
    torch.Tensor
        Projected target distribution, shape (B, N).
    """
    with torch.no_grad():
        # Compute Q-values from target network
        next_logits = agent.target_model(next_states)  # (B, A, N)
        support = torch.linspace(agent.v_min, agent.v_max, agent.num_atoms, device=next_logits.device)
        delta_z = (agent.v_max - agent.v_min) / (agent.num_atoms - 1)

        # Expected Q-values for next states
        next_q = (next_logits * support).sum(dim=2)  # (B, A)
        # Optimal actions
        best_actions = next_q.argmax(dim=1)          # (B,)
        # Distribution for optimal actions
        next_dist = next_logits[torch.arange(next_states.size(0)), best_actions]  # (B, N)

        # Bellman update for support
        Tz = rewards.unsqueeze(1) + gamma * support * (1 - dones.unsqueeze(1))
        Tz = Tz.clamp(agent.v_min, agent.v_max)

        # Projection
        b = (Tz - agent.v_min) / delta_z
        l = b.floor().long()
        u = b.ceil().long()

        l = l.clamp(0, agent.num_atoms - 1)
        u = u.clamp(0, agent.num_atoms - 1)

        m = torch.zeros_like(next_dist)

        for i in range(next_states.size(0)):
            for j in range(agent.num_atoms):
                lo = l[i, j]
                hi = u[i, j]
                val = next_dist[i, j]
                if lo == hi:
                    m[i, lo] += val
                else:
                    m[i, lo] += val * (hi - b[i, j])
                    m[i, hi] += val * (b[i, j] - lo)

    return m


def categorical_q_loss(
    agent,
    states: torch.Tensor,
    actions: torch.Tensor,
    target_dist: torch.Tensor,
    epsilon: float = 1e-12,
) -> torch.Tensor:
    """
    Compute negative log-likelihood loss for categorical DQN.

    Parameters
    ----------
    agent : object
        Agent containing ``model`` and distributional parameters.
    states : torch.Tensor
        Current state batch, shape (B, state_dim).
    actions : torch.Tensor
        Action indices, shape (B,).
    target_dist : torch.Tensor
        Target distribution, shape (B, N).
    epsilon : float
        Small value for numerical stability.

    Returns
    -------
    torch.Tensor
        Mean loss over the batch.
    """
    q_dist = categorical_q_values(agent, states, actions)  # (B, N)
    log_q = torch.log(q_dist + epsilon)
    loss = -torch.sum(target_dist * log_q, dim=1).mean()
    return loss
