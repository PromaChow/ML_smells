import numpy as np
from abc import ABC, abstractmethod
from typing import Any


class Agent(ABC):
    """Base agent interface."""

    @abstractmethod
    def act(self) -> Any:
        """Return an action or action distribution."""
        raise NotImplementedError


class UniformAgent(Agent):
    """
    Agent that returns a uniform probability distribution over all actions.

    Parameters
    ----------
    action_space : object
        An object with a `shape` attribute, where the first dimension
        indicates the number of possible actions.
    """

    def __init__(self, action_space: Any):
        self.action_space = action_space
        self.num_actions = int(action_space.shape[0])

    def act(self) -> np.ndarray:
        """Return a uniform distribution over all actions."""
        return np.ones(self.num_actions, dtype=float) / self.num_actions
