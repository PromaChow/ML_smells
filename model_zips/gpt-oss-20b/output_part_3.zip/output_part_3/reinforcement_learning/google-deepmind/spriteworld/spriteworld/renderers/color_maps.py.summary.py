import colorsys
import numpy as np

def hsv_to_rgb(c):
    r, g, b = colorsys.hsv_to_rgb(*c)
    rgb = np.array([r, g, b]) * 255
    rgb_uint8 = rgb.astype(np.uint8)
    return tuple(int(v) for v in rgb_uint8)