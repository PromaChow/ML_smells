import torch
import torch.nn as nn
import torch.nn.functional as F

BOARD_SIZE = 19
NUM_POSITIONS = BOARD_SIZE * BOARD_SIZE
INPUT_PLANES = 17
DEFAULT_FILTERS = 32


class Linear(nn.Module):
    def __init__(self, checkpoint_dir: str, learning_rate: float):
        super().__init__()
        self.checkpoint_dir = checkpoint_dir
        self.learning_rate = learning_rate
        self.linear = nn.Linear(INPUT_PLANES * NUM_POSITIONS, NUM_POSITIONS)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b = x.size(0)
        x_flat = x.view(b, -1)
        logits = self.linear(x_flat)
        return logits


class SingleFull(nn.Module):
    def __init__(self, checkpoint_dir: str, learning_rate: float):
        super().__init__()
        self.checkpoint_dir = checkpoint_dir
        self.learning_rate = learning_rate
        self.fc1 = nn.Linear(INPUT_PLANES * NUM_POSITIONS, 1024)
        self.fc2 = nn.Linear(1024, NUM_POSITIONS)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b = x.size(0)
        x_flat = x.view(b, -1)
        h = F.relu(self.fc1(x_flat))
        logits = self.fc2(h)
        return logits


class Conv3Full(nn.Module):
    def __init__(self, checkpoint_dir: str, learning_rate: float):
        super().__init__()
        self.checkpoint_dir = checkpoint_dir
        self.learning_rate = learning_rate
        self.conv1 = nn.Conv2d(INPUT_PLANES, DEFAULT_FILTERS, 5, padding=2)
        self.conv2 = nn.Conv2d(DEFAULT_FILTERS, DEFAULT_FILTERS, 3, padding=1)
        self.conv3 = nn.Conv2d(DEFAULT_FILTERS, DEFAULT_FILTERS, 3, padding=1)
        self.fc1 = nn.Linear(DEFAULT_FILTERS * NUM_POSITIONS, 1024)
        self.fc2 = nn.Linear(1024, NUM_POSITIONS)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = F.relu(self.conv1(x))
        h = F.relu(self.conv2(h))
        h = F.relu(self.conv3(h))
        b = h.size(0)
        h_flat = h.view(b, -1)
        h = F.relu(self.fc1(h_flat))
        logits = self.fc2(h)
        return logits


class Conv4Full(Conv3Full):
    def __init__(self, checkpoint_dir: str, learning_rate: float):
        super().__init__(checkpoint_dir, learning_rate)
        self.conv4 = nn.Conv2d(DEFAULT_FILTERS, DEFAULT_FILTERS, 3, padding=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = F.relu(self.conv1(x))
        h = F.relu(self.conv2(h))
        h = F.relu(self.conv3(h))
        h = F.relu(self.conv4(h))
        b = h.size(0)
        h_flat = h.view(b, -1)
        h = F.relu(self.fc1(h_flat))
        logits = self.fc2(h)
        return logits


class Conv5Full(Conv4Full):
    def __init__(self, checkpoint_dir: str, learning_rate: float):
        super().__init__(checkpoint_dir, learning_rate)
        self.conv5 = nn.Conv2d(DEFAULT_FILTERS, DEFAULT_FILTERS, 3, padding=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = F.relu(self.conv1(x))
        h = F.relu(self.conv2(h))
        h = F.relu(self.conv3(h))
        h = F.relu(self.conv4(h))
        h = F.relu(self.conv5(h))
        b = h.size(0)
        h_flat = h.view(b, -1)
        h = F.relu(self.fc1(h_flat))
        logits = self.fc2(h)
        return logits


class Conv8(nn.Module):
    def __init__(self, checkpoint_dir: str, learning_rate: float):
        super().__init__()
        self.checkpoint_dir = checkpoint_dir
        self.learning_rate = learning_rate
        self.convs = nn.ModuleList()
        kernels = [5, 3, 3, 3, 3, 3, 3, 1]
        in_ch = INPUT_PLANES
        for i, k in enumerate(kernels):
            out_ch = 1 if i == len(kernels) - 1 else DEFAULT_FILTERS
            self.convs.append(nn.Conv2d(in_ch, out_ch, k, padding=k // 2))
            in_ch = out_ch
        self.bias = nn.Parameter(torch.zeros(NUM_POSITIONS))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = x
        for i, conv in enumerate(self.convs):
            h = conv(h)
            if i < len(self.convs) - 1:
                h = F.relu(h)
        h = h.view(h.size(0), -1)
        logits = h + self.bias
        return logits


class Conv8Full(nn.Module):
    def __init__(self, checkpoint_dir: str, learning_rate: float):
        super().__init__()
        self.checkpoint_dir = checkpoint_dir
        self.learning_rate = learning_rate
        self.convs = nn.ModuleList()
        kernels = [5, 3, 3, 3, 3, 3, 3, 3]
        in_ch = INPUT_PLANES
        for k in kernels:
            self.convs.append(nn.Conv2d(in_ch, DEFAULT_FILTERS, k, padding=k // 2))
            in_ch = DEFAULT_FILTERS
        self.fc1 = nn.Linear(DEFAULT_FILTERS * NUM_POSITIONS, 1024)
        self.fc2 = nn.Linear(1024, NUM_POSITIONS)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = x
        for conv in self.convs:
            h = F.relu(conv(h))
        b = h.size(0)
        h_flat = h.view(b, -1)
        h = F.relu(self.fc1(h_flat))
        logits = self.fc2(h)
        return logits


class Conv12(nn.Module):
    def __init__(self, checkpoint_dir: str, learning_rate: float):
        super().__init__()
        self.checkpoint_dir = checkpoint_dir
        self.learning_rate = learning_rate
        self.convs = nn.ModuleList()
        kernels = [5, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 1]
        in_ch = INPUT_PLANES
        for i, k in enumerate(kernels):
            out_ch = 1 if i == len(kernels) - 1 else DEFAULT_FILTERS
            self.convs.append(nn.Conv2d(in_ch, out_ch, k, padding=k // 2))
            in_ch = out_ch
        self.bias = nn.Parameter(torch.zeros(NUM_POSITIONS))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = x
        for i, conv in enumerate(self.convs):
            h = conv(h)
            if i < len(self.convs) - 1:
                h = F.relu(h)
        h = h.view(h.size(0), -1)
        logits = h + self.bias
        return logits


class MaddisonMinimal(nn.Module):
    def __init__(self, checkpoint_dir: str, learning_rate: float):
        super().__init__()
        self.checkpoint_dir = checkpoint_dir
        self.learning_rate = learning_rate
        self.convs = nn.ModuleList()
        kernels = [5, 3, 3, 1]
        in_ch = INPUT_PLANES
        for k in kernels:
            self.convs.append(nn.Conv2d(in_ch, 16, k, padding=k // 2))
            in_ch = 16
        self.bias = nn.Parameter(torch.zeros(NUM_POSITIONS))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = x
        for i, conv in enumerate(self.convs):
            h = conv(h)
            if i < len(self.convs) - 1:
                h = F.relu(h)
        h = h.view(h.size(0), -1)
        logits = h + self.bias
        return logits


class Conv6PosDep(nn.Module):
    def __init__(self, training_dir: str):
        super().__init__()
        self.training_dir = training_dir
        self.convs = nn.ModuleList()
        kernels = [5, 3, 3, 3, 3, 3]
        in_ch = INPUT_PLANES
        for k in kernels:
            self.convs.append(nn.Conv2d(in_ch, DEFAULT_FILTERS, k, padding=k // 2))
            in_ch = DEFAULT_FILTERS
        self.out_conv = nn.Conv2d(DEFAULT_FILTERS, 1, 3, padding=1)
        self.bias = nn.Parameter(torch.zeros(NUM_POSITIONS))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = x
        for conv in self.convs:
            h = F.relu(conv(h))
        h = self.out_conv(h)
        h = h.view(h.size(0), -1)
        logits = h + self.bias
        return logits


class Conv8PosDep(Conv6PosDep):
    def __init__(self, training_dir: str):
        super().__init__(training_dir)
        self.convs = nn.ModuleList()
        kernels = [5, 3, 3, 3, 3, 3, 3, 3]
        in_ch = INPUT_PLANES
        for k in kernels:
            self.convs.append(nn.Conv2d(in_ch, DEFAULT_FILTERS, k, padding=k // 2))
            in_ch = DEFAULT_FILTERS
        self.out_conv = nn.Conv2d(DEFAULT_FILTERS, 1, 3, padding=1)


class Conv10PosDep(Conv8PosDep):
    def __init__(self, training_dir: str):
        super().__init__(training_dir)
        self.convs = nn.ModuleList()
        kernels = [5, 3, 3, 3, 3, 3, 3, 3, 3, 3]
        in_ch = INPUT_PLANES
        for k in kernels:
            self.convs.append(nn.Conv2d(in_ch, DEFAULT_FILTERS, k, padding=k // 2))
            in_ch = DEFAULT_FILTERS
        self.out_conv = nn.Conv2d(DEFAULT_FILTERS, 1, 3, padding=1)


class Conv10PosDepELU(Conv10PosDep):
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = x
        for conv in self.convs:
            h = F.elu(conv(h))
        h = self.out_conv(h)
        h = h.view(h.size(0), -1)
        logits = h + self.bias
        return logits


class Conv12PosDepELU(Conv10PosDepELU):
    def __init__(self, training_dir: str):
        super().__init__(training_dir)
        self.convs = nn.ModuleList()
        kernels = [5, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3]
        in_ch = INPUT_PLANES
        for k in kernels:
            self.convs.append(nn.Conv2d(in_ch, DEFAULT_FILTERS, k, padding=k // 2))
            in_ch = DEFAULT_FILTERS
        self.out_conv = nn.Conv2d(DEFAULT_FILTERS, 1, 3, padding=1)


class Conv12PosDepELUBig(nn.Module):
    def __init__(self, training_dir: str):
        super().__init__()
        self.training_dir = training_dir
        self.convs = nn.ModuleList()
        kernels = [5, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3]
        in_ch = INPUT_PLANES
        for k in kernels:
            self.convs.append(nn.Conv2d(in_ch, 512, k, padding=k // 2))
            in_ch = 512
        self.out_conv = nn.Conv2d(512, 1, 3, padding=1)
        self.bias = nn.Parameter(torch.zeros(NUM_POSITIONS))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = x
        for conv in self.convs:
            h = F.elu(conv(h))
        h = self.out_conv(h)
        h = h.view(h.size(0), -1)
        logits = h + self.bias
        return logits


class Conv16PosDepELU(Conv12PosDepELU):
    def __init__(self, training_dir: str):
        super().__init__(training_dir)
        self.convs = nn.ModuleList()
        kernels = [5, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3]
        in_ch = INPUT_PLANES
        for k in kernels:
            self.convs.append(nn.Conv2d(in_ch, DEFAULT_FILTERS, k, padding=k // 2))
            in_ch = DEFAULT_FILTERS
        self.out_conv = nn.Conv2d(DEFAULT_FILTERS, 1, 3, padding=1)


class Conv4PosDepELU(Conv6PosDep):
    def __init__(self, training_dir: str):
        super().__init__(training_dir)
        self.convs = nn.ModuleList()
        kernels = [5, 3, 3, 3]
        in_ch = INPUT_PLANES
        for k in kernels:
            self.convs.append(nn.Conv2d(in_ch, DEFAULT_FILTERS, k, padding=k // 2))
            in_ch = DEFAULT_FILTERS
        self.out_conv = nn.Conv2d(DEFAULT_FILTERS, 1, 3, padding=1)


class Conv12PosDep(Conv10PosDep):
    def __init__(self, training_dir: str):
        super().__init__(training_dir)
        self.convs = nn.ModuleList()
        kernels = [5, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3]
        in_ch = INPUT_PLANES
        for k in kernels:
            self.convs.append(nn.Conv2d(in_ch, DEFAULT_FILTERS, k, padding=k // 2))
            in_ch = DEFAULT_FILTERS
        self.out_conv = nn.Conv2d(DEFAULT_FILTERS, 1, 3, padding=1)


class ResidualBlock(nn.Module):
    def __init__(self, channels: int):
        super().__init__()
        self.conv1 = nn.Conv2d(channels, channels, 3, padding=1)
        self.conv2 = nn.Conv2d(channels, channels, 3, padding=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = F.elu(x)
        h = self.conv1(h)
        h = F.elu(h)
        h = self.conv2(h)
        return x + h


class Res5x2PreELU(nn.Module):
    def __init__(self, training_dir: str):
        super().__init__()
        self.training_dir = training_dir
        self.blocks = nn.ModuleList([ResidualBlock(DEFAULT_FILTERS) for _ in range(5)])
        self.out_conv = nn.Conv2d(DEFAULT_FILTERS, 1, 3, padding=1)
        self.bias = nn.Parameter(torch.zeros(NUM_POSITIONS))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = x
        for block in self.blocks:
            h = block(h)
        h = self.out_conv(h)
        h = h.view(h.size(0), -1)
        logits = h + self.bias
        return logits


class Res10x2PreELU(Res5x2PreELU):
    def __init__(self, training_dir: str):
        super().__init__(training_dir)
        self.blocks = nn.ModuleList([ResidualBlock(DEFAULT_FILTERS) for _ in range(10)])


class FirstMoveTest(nn.Module):
    def __init__(self, training_dir: str):
        super().__init__()
        self.training_dir = training_dir
        self.bias = nn.Parameter(torch.zeros(NUM_POSITIONS))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.bias.expand(x.size(0), -1)
