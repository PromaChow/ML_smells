import os
import time
import logging
import pickle
from dataclasses import dataclass, field
from typing import Optional, Any, Dict, List

import numpy as np

try:
    import torch
except ImportError:
    torch = None


@dataclass
class ReplayBuffer:
    capacity: int
    state_dim: int
    action_dim: int
    next_state_dim: int
    dtype: Any = np.float32
    buffer: Dict[str, np.ndarray] = field(init=False)

    def __post_init__(self):
        self.buffer = {
            "states": np.empty((self.capacity, self.state_dim), dtype=self.dtype),
            "actions": np.empty((self.capacity, self.action_dim), dtype=self.dtype),
            "rewards": np.empty((self.capacity, 1), dtype=self.dtype),
            "next_states": np.empty((self.capacity, self.next_state_dim), dtype=self.dtype),
            "dones": np.empty((self.capacity, 1), dtype=bool),
        }
        self.idx = 0
        self.size = 0

    def add(self, state, action, reward, next_state, done):
        self.buffer["states"][self.idx] = state
        self.buffer["actions"][self.idx] = action
        self.buffer["rewards"][self.idx] = reward
        self.buffer["next_states"][self.idx] = next_state
        self.buffer["dones"][self.idx] = done
        self.idx = (self.idx + 1) % self.capacity
        self.size = min(self.size + 1, self.capacity)

    def sample(self, batch_size: int):
        indices = np.random.choice(self.size, batch_size, replace=False)
        return {k: v[indices] for k, v in self.buffer.items()}


@dataclass
class OffPolicyTrainerConfig:
    max_timesteps: int
    max_episode_length: int = 500
    warmup_steps: int = 1000
    start_update: int = 1000
    update_interval: int = 50
    log_interval: int = 1000
    save_interval: int = 10000
    buffer_capacity: int = 1000000
    batch_size: int = 256
    env_kwargs: Dict[str, Any] = field(default_factory=dict)
    save_path: str = "./checkpoints"
    render: bool = False
    pretrain_path: Optional[str] = None


class OffPolicyTrainer:
    def __init__(
        self,
        agent,
        env,
        buffer: Optional[ReplayBuffer] = None,
        config: Optional[OffPolicyTrainerConfig] = None,
    ):
        self.agent = agent
        self.env = env
        self.config = config or OffPolicyTrainerConfig(max_timesteps=100000)
        self.logger = logging.getLogger("OffPolicyTrainer")
        handler = logging.StreamHandler()
        formatter = logging.Formatter("[%(asctime)s] %(levelname)s: %(message)s")
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)
        self.logger.setLevel(logging.INFO)

        state_dim = env.observation_space.shape[0]
        action_dim = env.action_space.shape[0]
        self.buffer = buffer or ReplayBuffer(
            capacity=self.config.buffer_capacity,
            state_dim=state_dim,
            action_dim=action_dim,
            next_state_dim=state_dim,
        )

        if self.config.pretrain_path and os.path.exists(self.config.pretrain_path):
            self._load_pretrained(self.config.pretrain_path)

        os.makedirs(self.config.save_path, exist_ok=True)

        self.total_timesteps = 0
        self.episode_rewards: List[float] = []
        self.episode_lengths: List[int] = []
        self.current_episode_reward = 0.0
        self.current_episode_length = 0

    def _load_pretrained(self, path: str):
        if torch and hasattr(self.agent, "load_state_dict"):
            state_dict = torch.load(path)
            self.agent.load_state_dict(state_dict)
            self.logger.info(f"Loaded pretrained weights from {path}")
        else:
            with open(path, "rb") as f:
                state = pickle.load(f)
                self.agent.set_params(state)
            self.logger.info(f"Loaded pretrained weights from {path}")

    def _save_checkpoint(self, step: int):
        checkpoint_path = os.path.join(self.config.save_path, f"checkpoint_{step}.pt")
        if torch and hasattr(self.agent, "state_dict"):
            torch.save(self.agent.state_dict(), checkpoint_path)
        else:
            with open(checkpoint_path, "wb") as f:
                pickle.dump(self.agent.get_params(), f)
        self.logger.info(f"Saved checkpoint at {checkpoint_path}")

    def train(self):
        state = self.env.reset()
        if hasattr(self.agent, "reset_noise"):
            self.agent.reset_noise()

        while self.total_timesteps < self.config.max_timesteps:
            if self.total_timesteps < self.config.warmup_steps:
                action = self.env.action_space.sample()
            else:
                action = self.agent.select_action(state)

            next_state, reward, done, _ = self.env.step(action)

            if self.config.render:
                self.env.render()

            self.buffer.add(state, action, reward, next_state, done)

            self.current_episode_reward += reward
            self.current_episode_length += 1
            self.total_timesteps += 1

            if done or self.current_episode_length >= self.config.max_episode_length:
                self.episode_rewards.append(self.current_episode_reward)
                self.episode_lengths.append(self.current_episode_length)
                state = self.env.reset()
                self.current_episode_reward = 0.0
                self.current_episode_length = 0
                if hasattr(self.agent, "reset_noise"):
                    self.agent.reset_noise()
            else:
                state = next_state

            if (
                self.total_timesteps >= self.config.start_update
                and self.total_timesteps % self.config.update_interval == 0
            ):
                batch = self.buffer.sample(self.config.batch_size)
                self.agent.update(batch)

            if self.total_timesteps % self.config.log_interval == 0:
                avg_reward = np.mean(self.episode_rewards[-10:]) if self.episode_rewards else 0.0
                self.logger.info(
                    f"Step: {self.total_timesteps}, AvgReward: {avg_reward:.3f}, "
                    f"EpisodeCount: {len(self.episode_rewards)}"
                )

            if self.total_timesteps % self.config.save_interval == 0:
                self._save_checkpoint(self.total_timesteps)

        self.env.close()
        self.logger.info("Training completed.")
        self._save_checkpoint(self.total_timesteps)