import numpy as np

def relu(x: np.ndarray) -> np.ndarray:
    return np.maximum(0, x)

def dense(x: np.ndarray, w: np.ndarray, b: np.ndarray) -> np.ndarray:
    return x @ w + b

def main() -> None:
    # Input data (example)
    input_data = np.array([0.5, -1.2, 0.3, 0.8])

    # Weights and biases for the first dense layer
    weights_dense1_w = np.array([
        [0.2, -0.5, 0.1, 0.4, -0.3],
        [0.7, 0.3, -0.6, 0.8, 0.2],
        [-0.4, 0.9, 0.5, -0.2, 0.1],
        [0.6, -0.1, -0.3, 0.7, -0.5]
    ])
    weights_dense1_b = np.array([0.1, -0.2, 0.05, 0.0, 0.3])

    # Weights and biases for the second dense layer
    weights_dense2_w = np.array([
        [0.3, -0.7, 0.2],
        [-0.5, 0.4, -0.1],
        [0.6, -0.2, 0.5],
        [0.1, 0.9, -0.3],
        [-0.4, 0.2, 0.8]
    ])
    weights_dense2_b = np.array([0.05, -0.1, 0.2])

    # Weights and biases for the final output layer
    weights_final_w = np.array([
        [0.4, -0.6],
        [-0.2, 0.3],
        [0.5, -0.1]
    ])
    weights_final_b = np.array([0.0, 0.1])

    # Forward pass
    a1 = relu(dense(input_data, weights_dense1_w, weights_dense1_b))
    a2 = relu(dense(a1, weights_dense2_w, weights_dense2_b))
    output = dense(a2, weights_final_w, weights_final_b)

    print("Network output:", output)

if __name__ == "__main__":
    main()