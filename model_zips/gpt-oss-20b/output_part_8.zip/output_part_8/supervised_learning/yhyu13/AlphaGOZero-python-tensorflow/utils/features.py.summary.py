import numpy as np
from functools import wraps
from collections import deque

# Decorator to annotate plane count
def planes(num_planes):
    def decorator(fn):
        fn.num_planes = num_planes
        @wraps(fn)
        def wrapper(*args, **kwargs):
            return fn(*args, **kwargs)
        return wrapper
    return decorator

def make_onehot(values):
    """
    values: 2D array of integers
    returns: 3D array (H, W, 8) with one-hot encoding for 1..8 (0 -> all zeros)
    """
    capped = np.clip(values, 0, 8)
    planes = (capped[..., None] == np.arange(1, 9)).astype(np.float32)
    return planes

@planes(3)
def stone_color_feature(board, player):
    player_plane = (board == player).astype(np.float32)
    opponent_plane = (board == -player).astype(np.float32)
    empty_plane = (board == 0).astype(np.float32)
    return np.stack([player_plane, opponent_plane, empty_plane], axis=2)

@planes(1)
def ones_feature(board, _):
    return np.ones(board.shape + (1,), dtype=np.float32)

@planes(8)
def recent_move_feature(board, moves):
    planes = np.zeros(board.shape + (8,), dtype=np.float32)
    rev_moves = list(reversed(moves[:8]))
    for i, (r, c) in enumerate(rev_moves):
        if 0 <= r < board.shape[0] and 0 <= c < board.shape[1]:
            planes[r, c, i] = 1.0
    return planes

def _adjacent_positions(pos, shape):
    r, c = pos
    for dr, dc in [(-1,0),(1,0),(0,-1),(0,1)]:
        nr, nc = r+dr, c+dc
        if 0 <= nr < shape[0] and 0 <= nc < shape[1]:
            yield (nr, nc)

def _bfs_group(start, board, player):
    shape = board.shape
    visited = np.zeros(shape, dtype=bool)
    queue = deque([start])
    group = []
    liberties = set()
    visited[start] = True
    while queue:
        r, c = queue.popleft()
        group.append((r, c))
        for nr, nc in _adjacent_positions((r, c), shape):
            if board[nr, nc] == 0:
                liberties.add((nr, nc))
            elif board[nr, nc] == player and not visited[nr, nc]:
                visited[nr, nc] = True
                queue.append((nr, nc))
    return group, liberties

@planes(8)
def liberty_feature(board, _):
    shape = board.shape
    liberties = np.zeros(shape, dtype=np.int32)
    for r in range(shape[0]):
        for c in range(shape[1]):
            if board[r, c] == 0:
                continue
            group, lib_set = _bfs_group((r, c), board, board[r, c])
            liberties[r, c] = len(lib_set)
    return make_onehot(liberties)

def _compute_capture_size(board, move, player):
    r, c = move
    if board[r, c] != 0:
        return 0
    shape = board.shape
    captured = 0
    for nr, nc in _adjacent_positions((r, c), shape):
        if board[nr, nc] == -player:
            group, lib_set = _bfs_group((nr, nc), board, -player)
            if len(lib_set) == 1:
                captured += len(group)
    return captured

@planes(8)
def capture_size_feature(board, moves, player):
    shape = board.shape
    values = np.zeros(shape, dtype=np.int32)
    for r in range(shape[0]):
        for c in range(shape[1]):
            if board[r, c] == 0:
                values[r, c] = _compute_capture_size(board, (r, c), player)
    return make_onehot(values)

def _compute_self_atari(board, move, player):
    r, c = move
    if board[r, c] != 0:
        return 0
    shape = board.shape
    captured = 0
    for nr, nc in _adjacent_positions((r, c), shape):
        if board[nr, nc] == player:
            group, lib_set = _bfs_group((nr, nc), board, player)
            if len(lib_set) == 1:
                captured += len(group)
    return captured

@planes(8)
def self_atari_size_feature(board, moves, player):
    shape = board.shape
    values = np.zeros(shape, dtype=np.int32)
    for r in range(shape[0]):
        for c in range(shape[1]):
            if board[r, c] == 0:
                values[r, c] = _compute_self_atari(board, (r, c), player)
    return make_onehot(values)

def _compute_liberties_after_move(board, move, player):
    r, c = move
    if board[r, c] != 0:
        return 0
    temp = board.copy()
    temp[r, c] = player
    # remove opponent groups with zero liberties
    shape = board.shape
    removed = 0
    for nr, nc in _adjacent_positions((r, c), shape):
        if temp[nr, nc] == -player:
            group, lib_set = _bfs_group((nr, nc), temp, -player)
            if len(lib_set) == 0:
                for gr, gc in group:
                    temp[gr, gc] = 0
                removed += len(group)
    # compute liberties of the new stone/group
    group, lib_set = _bfs_group((r, c), temp, player)
    return len(lib_set)

@planes(8)
def liberties_after_move_feature(board, moves, player):
    shape = board.shape
    values = np.zeros(shape, dtype=np.int32)
    for r in range(shape[0]):
        for c in range(shape[1]):
            if board[r, c] == 0:
                values[r, c] = _compute_liberties_after_move(board, (r, c), player)
    return make_onehot(values)

@planes(1)
def ladder_capture_feature(board, _):
    return np.zeros(board.shape + (1,), dtype=np.float32)

@planes(1)
def ladder_escape_feature(board, _):
    return np.zeros(board.shape + (1,), dtype=np.float32)

@planes(1)
def sensibleness_feature(board, moves, player):
    shape = board.shape
    values = np.zeros(shape, dtype=np.float32)
    for r in range(shape[0]):
        for c in range(shape[1]):
            if board[r, c] != 0:
                continue
            # simple legality: not suicide unless capturing
            temp = board.copy()
            temp[r, c] = player
            group, lib_set = _bfs_group((r, c), temp, player)
            if len(lib_set) == 0:
                # check if captures opponent
                captures = False
                for nr, nc in _adjacent_positions((r, c), shape):
                    if board[nr, nc] == -player:
                        group_o, lib_o = _bfs_group((nr, nc), board, -player)
                        if len(lib_o) == 1:
                            captures = True
                            break
                values[r, c] = 1.0 if captures else 0.0
            else:
                values[r, c] = 1.0
    return values[..., None]

@planes(1)
def zeros_feature(board, _):
    return np.zeros(board.shape + (1,), dtype=np.float32)

# AlphaGo Zero specific
@planes(16)
def player_opponent_recent_moves_feature(board, moves, player):
    shape = board.shape
    planes = np.zeros(shape + (16,), dtype=np.float32)
    rev_moves = list(reversed(moves[:8]))
    for i, move in enumerate(rev_moves):
        r, c = move
        if 0 <= r < shape[0] and 0 <= c < shape[1]:
            if i < 8:
                # player plane
                if move in moves and board[r, c] == player:
                    planes[r, c, i] = 1.0
                else:
                    planes[r, c, i+8] = 1.0
    return planes

@planes(1)
def player_color_feature(board, player):
    plane = np.full(board.shape, 1.0 if player == 1 else 0.0, dtype=np.float32)
    return plane[..., None]

# List of all feature functions
ALL_FEATURES = [
    stone_color_feature,
    ones_feature,
    recent_move_feature,
    liberty_feature,
    capture_size_feature,
    self_atari_size_feature,
    liberties_after_move_feature,
    ladder_capture_feature,
    ladder_escape_feature,
    sensibleness_feature,
    zeros_feature,
    player_opponent_recent_moves_feature,
    player_color_feature,
]

def extract_features(board, moves, player, dihedral_transform=None):
    """
    board: 2D numpy array with 0 empty, 1 black, -1 white
    moves: list of (row, col) tuples, oldest first
    player: 1 for black, -1 for white
    dihedral_transform: optional function taking (board, moves) and returning transformed ones
    """
    if dihedral_transform:
        board, moves = dihedral_transform(board, moves)
    planes_list = []
    for fn in ALL_FEATURES:
        if fn == stone_color_feature or fn == ones_feature or fn == recent_move_feature or fn == liberty_feature or fn == ladder_capture_feature or fn == ladder_escape_feature or fn == zeros_feature or fn == player_color_feature:
            plane = fn(board, player if fn in [stone_color_feature] else None)
        elif fn == capture_size_feature or fn == self_atari_size_feature or fn == liberties_after_move_feature:
            plane = fn(board, moves, player)
        else:
            plane = fn(board, moves, player)
        planes_list.append(plane)
    return np.concatenate(planes_list, axis=2)

def bulk_extract_features(positions, dihedral_transform=None):
    """
    positions: list of dicts with keys 'board', 'moves', 'player'
    returns: 4D array (N, H, W, planes)
    """
    feature_tensors = [extract_features(pos['board'], pos['moves'], pos['player'], dihedral_transform) for pos in positions]
    return np.stack(feature_tensors, axis=0)