import random
from typing import List, Dict

import utils
import augmentation_pool


class RandAugment:
    def __init__(
        self,
        nops: int,
        magnitude: int = 10,
        prob: float = 0.5,
        alg: str = "uda",
    ) -> None:
        if alg == "fixmatch":
            self.ops_list: List[str] = utils.FIXMATCH_RANDAUGMENT_OPS_LIST
        elif alg == "uda":
            self.ops_list: List[str] = utils.UDA_RANDAUGMENT_OPS_LIST
        else:
            raise ValueError(f"Unsupported algorithm type: {alg!r}")

        self.nops = nops
        self.magnitude = magnitude
        self.prob = prob
        self.ops_max_level: Dict[str, int] = utils.RANDAUGMENT_MAX_LEVELS

    def __call__(self, image):
        selected_ops = random.sample(self.ops_list, min(self.nops, len(self.ops_list)))

        for op_name in selected_ops:
            if random.random() <= self.prob:
                level = random.randint(1, self.magnitude)
                max_level = self.ops_max_level.get(op_name, 10)
                func = getattr(augmentation_pool, op_name)
                image = func(
                    image,
                    level=level,
                    magnitude=self.magnitude,
                    max_level=max_level,
                )

        return image

    def __repr__(self) -> str:
        return f"RandAugment(nops={self.nops}, magnitude={self.magnitude})"