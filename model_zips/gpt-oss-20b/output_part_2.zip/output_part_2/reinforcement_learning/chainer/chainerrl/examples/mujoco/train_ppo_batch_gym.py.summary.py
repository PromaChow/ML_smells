import argparse
import logging
import os
import random
import time
from collections import deque, namedtuple

import gymnasium as gym
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim


# --------------------------------------------------------------------------- #
# Utility functions and wrappers
# --------------------------------------------------------------------------- #
def set_random_seed(seed, use_cuda=False):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if use_cuda:
        torch.cuda.manual_seed_all(seed)


class CastObservationToFloat32(gym.Wrapper):
    def observation(self, observation):
        if isinstance(observation, np.ndarray):
            return observation.astype(np.float32)
        return observation


class ScaleReward(gym.RewardWrapper):
    def __init__(self, env, scale=1.0):
        super().__init__(env)
        self.scale = scale

    def reward(self, reward):
        return reward * self.scale


class Render(gym.Wrapper):
    def __init__(self, env, render_mode=None):
        super().__init__(env)
        self.render_mode = render_mode

    def reset(self, **kwargs):
        return self.env.reset(**kwargs)

    def step(self, action):
        observation, reward, terminated, truncated, info = self.env.step(action)
        if self.render_mode:
            self.env.render()
        return observation, reward, terminated, truncated, info


def process_seeds(seed, num_envs):
    return [seed + i * 1000 for i in range(num_envs)], [seed + 999999 + i * 1000 for i in range(num_envs)]


# --------------------------------------------------------------------------- #
# Normalization
# --------------------------------------------------------------------------- #
class EmpiricalNormalization:
    def __init__(self, shape):
        self.mean = torch.zeros(shape, dtype=torch.float32)
        self.var = torch.ones(shape, dtype=torch.float32)
        self.count = 1e-4

    def update(self, batch):
        batch = torch.tensor(batch, dtype=torch.float32)
        batch_mean = batch.mean(dim=0)
        batch_var = batch.var(dim=0, unbiased=False)
        batch_count = batch.size(0)

        delta = batch_mean - self.mean
        tot_count = self.count + batch_count
        new_mean = self.mean + delta * batch_count / tot_count
        m_a = self.var * self.count
        m_b = batch_var * batch_count
        M2 = m_a + m_b + (delta**2) * self.count * batch_count / tot_count
        new_var = M2 / tot_count
        self.mean = new_mean
        self.var = new_var
        self.count = tot_count

    def normalize(self, observation):
        obs = torch.tensor(observation, dtype=torch.float32)
        return (obs - self.mean) / (torch.sqrt(self.var) + 1e-8)


# --------------------------------------------------------------------------- #
# Networks
# --------------------------------------------------------------------------- #
class MLP(nn.Module):
    def __init__(self, input_dim, output_dim, hidden_sizes=(64, 64, 64)):
        super().__init__()
        layers = []
        last_dim = input_dim
        for h in hidden_sizes:
            layers.append(nn.Linear(last_dim, h))
            layers.append(nn.ReLU())
            last_dim = h
        layers.append(nn.Linear(last_dim, output_dim))
        self.model = nn.Sequential(*layers)

    def forward(self, x):
        return self.model(x)


class PolicyNetwork(nn.Module):
    def __init__(self, observation_space, action_space):
        super().__init__()
        if isinstance(action_space, gym.spaces.Discrete):
            self.discrete = True
            self.action_dim = action_space.n
            self.net = MLP(observation_space.shape[0], self.action_dim)
        else:
            self.discrete = False
            self.action_dim = action_space.shape[0]
            self.net = MLP(observation_space.shape[0], self.action_dim)
            self.log_std = nn.Parameter(torch.zeros(self.action_dim))

    def forward(self, x):
        if self.discrete:
            logits = self.net(x)
            return F.softmax(logits, dim=-1)
        else:
            mean = self.net(x)
            std = torch.exp(self.log_std)
            return mean, std


class ValueNetwork(nn.Module):
    def __init__(self, observation_space):
        super().__init__()
        self.net = MLP(observation_space.shape[0], 1)

    def forward(self, x):
        return self.net(x).squeeze(-1)


class BranchedModel(nn.Module):
    def __init__(self, observation_space, action_space):
        super().__init__()
        self.policy = PolicyNetwork(observation_space, action_space)
        self.value = ValueNetwork(observation_space)

    def forward(self, x):
        if self.policy.discrete:
            action_probs = self.policy(x)
            value = self.value(x)
            return action_probs, value
        else:
            mean, std = self.policy(x)
            value = self.value(x)
            return mean, std, value


# --------------------------------------------------------------------------- #
# PPO Agent
# --------------------------------------------------------------------------- #
class PPOAgent:
    def __init__(
        self,
        model,
        optimizer,
        normalizer,
        update_interval=2048,
        minibatch_size=64,
        epochs=10,
        gamma=0.99,
        lam=0.95,
        entropy_coef=0.0,
        value_coef=0.5,
        max_grad_norm=0.5,
        standardize_advantages=True,
    ):
        self.model = model
        self.optimizer = optimizer
        self.normalizer = normalizer
        self.update_interval = update_interval
        self.minibatch_size = minibatch_size
        self.epochs = epochs
        self.gamma = gamma
        self.lam = lam
        self.entropy_coef = entropy_coef
        self.value_coef = value_coef
        self.max_grad_norm = max_grad_norm
        self.standardize_advantages = standardize_advantages

        self.transition = namedtuple(
            "Transition",
            [
                "obs",
                "action",
                "reward",
                "done",
                "value",
                "log_prob",
                "next_value",
            ],
        )

    def collect_trajectories(self, envs, device):
        obs = envs.reset()
        trajectories = []
        for _ in range(self.update_interval):
            obs_tensor = torch.tensor(obs, dtype=torch.float32, device=device)
            self.normalizer.update(obs)
            obs_norm = self.normalizer.normalize(obs)
            if self.model.policy.discrete:
                action_probs = self.model.policy(obs_norm)
                dist = torch.distributions.Categorical(action_probs)
                action = dist.sample()
                log_prob = dist.log_prob(action)
            else:
                mean, std = self.model.policy(obs_norm)
                dist = torch.distributions.Normal(mean, std)
                action = dist.sample()
                log_prob = dist.log_prob(action).sum(-1)
            action_np = action.cpu().numpy()
            value = self.model.value(obs_norm).detach().cpu().numpy()
            next_obs, reward, terminated, truncated, info = envs.step(action_np)
            next_done = terminated or truncated
            next_obs_tensor = torch.tensor(next_obs, dtype=torch.float32, device=device)
            self.normalizer.update(next_obs)
            next_obs_norm = self.normalizer.normalize(next_obs)
            next_value = self.model.value(next_obs_norm).detach().cpu().numpy()
            transition = self.transition(
                obs=obs,
                action=action.cpu().numpy(),
                reward=reward,
                done=next_done,
                value=value,
                log_prob=log_prob.detach().cpu().numpy(),
                next_value=next_value,
            )
            trajectories.append(transition)
            obs = next_obs
        return trajectories

    def compute_returns_and_advantages(self, trajectories):
        returns = []
        advantages = []
        gae = 0
        for i in reversed(range(len(trajectories))):
            t = trajectories[i]
            delta = t.reward + self.gamma * t.next_value * (1 - t.done) - t.value
            gae = delta + self.gamma * self.lam * (1 - t.done) * gae
            advantage = gae
            ret = advantage + t.value
            advantages.insert(0, advantage)
            returns.insert(0, ret)
        adv_arr = np.array(advantages, dtype=np.float32)
        ret_arr = np.array(returns, dtype=np.float32)
        if self.standardize_advantages:
            adv_arr = (adv_arr - adv_arr.mean()) / (adv_arr.std() + 1e-8)
        return adv_arr, ret_arr

    def update(self, trajectories, adv_arr, ret_arr, device):
        obs = torch.tensor(np.concatenate([t.obs for t in trajectories]), dtype=torch.float32, device=device)
        actions = torch.tensor(np.concatenate([t.action for t in trajectories]), dtype=torch.float32, device=device)
        old_log_probs = torch.tensor(np.concatenate([t.log_prob for t in trajectories]), dtype=torch.float32, device=device)
        returns = torch.tensor(ret_arr, dtype=torch.float32, device=device)
        advantages = torch.tensor(adv_arr, dtype=torch.float32, device=device)

        self.normalizer.update(obs.cpu().numpy())
        obs_norm = self.normalizer.normalize(obs)

        dataset = torch.utils.data.TensorDataset(obs_norm, actions, old_log_probs, returns, advantages)
        loader = torch.utils.data.DataLoader(dataset, batch_size=self.minibatch_size, shuffle=True)

        for _ in range(self.epochs):
            for batch in loader:
                b_obs, b_act, b_old_logp, b_ret, b_adv = batch
                if self.model.policy.discrete:
                    action_probs = self.model.policy(b_obs)
                    dist = torch.distributions.Categorical(action_probs)
                    logp = dist.log_prob(b_act.long())
                    entropy = dist.entropy()
                else:
                    mean, std = self.model(b_obs)[:2]
                    dist = torch.distributions.Normal(mean, std)
                    logp = dist.log_prob(b_act).sum(-1)
                    entropy = dist.entropy().sum(-1)
                ratio = torch.exp(logp - b_old_logp)
                surrogate1 = ratio * b_adv
                surrogate2 = torch.clamp(ratio, 0.8, 1.2) * b_adv
                policy_loss = -torch.min(surrogate1, surrogate2).mean()
                value = self.model.value(b_obs)
                value_loss = F.mse_loss(value, b_ret)
                loss = policy_loss + self.value_coef * value_loss - self.entropy_coef * entropy.mean()
                self.optimizer.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(self.model.parameters(), self.max_grad_norm)
                self.optimizer.step()

    def train(self, envs, eval_envs, device, total_steps, eval_interval, eval_n_runs, log_interval):
        step = 0
        start_time = time.time()
        while step < total_steps:
            trajectories = self.collect_trajectories(envs, device)
            adv_arr, ret_arr = self.compute_returns_and_advantages(trajectories)
            self.update(trajectories, adv_arr, ret_arr, device)
            step += self.update_interval
            if step % eval_interval == 0:
                avg_return = self.evaluate(eval_envs, device, eval_n_runs)
                elapsed = time.time() - start_time
                logging.info(f"Step {step} | Eval Return {avg_return:.2f} | Time {elapsed:.2f}s")
            if step % log_interval == 0:
                avg_return = self.evaluate(eval_envs, device, eval_n_runs)
                logging.info(f"Step {step} | Eval Return {avg_return:.2f}")
        return

    def evaluate(self, envs, device, n_runs):
        returns = []
        for _ in range(n_runs):
            obs = envs.reset()
            done = False
            total_reward = 0.0
            while not done:
                obs_tensor = torch.tensor(obs, dtype=torch.float32, device=device)
                self.normalizer.update(obs)
                obs_norm = self.normalizer.normalize(obs)
                if self.model.policy.discrete:
                    action_probs = self.model.policy(obs_norm)
                    dist = torch.distributions.Categorical(action_probs)
                    action = dist.sample().cpu().numpy()
                else:
                    mean, std = self.model.policy(obs_norm)
                    dist = torch.distributions.Normal(mean, std)
                    action = dist.sample().cpu().numpy()
                obs, reward, terminated, truncated, info = envs.step(action)
                done = terminated or truncated
                total_reward += reward
            returns.append(total_reward)
        return np.mean(returns)


# --------------------------------------------------------------------------- #
# Environment factory
# --------------------------------------------------------------------------- #
def make_env(env_id, seed, rank, is_testing=False, render_mode=None, reward_scale_factor=1.0):
    def _thunk():
        env = gym.make(env_id)
        env.seed(seed)
        env.action_space.seed(seed)
        env.observation_space.seed(seed)
        env = CastObservationToFloat32(env)
        if not is_testing:
            env = ScaleReward(env, scale=reward_scale_factor)
        env = gym.wrappers.Monitor(env, directory=None, force=True)
        if render_mode:
            env = Render(env, render_mode=render_mode)
        return env

    return _thunk


def make_vec_env(env_id, num_envs, seed, is_testing=False, render_mode=None, reward_scale_factor=1.0):
    env_seeds, test_seeds = process_seeds(seed, num_envs)
    env_fns = [
        make_env(
            env_id,
            env_seeds[i] if not is_testing else test_seeds[i],
            i,
            is_testing=is_testing,
            render_mode=render_mode,
            reward_scale_factor=reward_scale_factor,
        )
        for i in range(num_envs)
    ]
    return gym.vector.AsyncVectorEnv(env_fns)


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--env", default="CartPole-v1")
    parser.add_argument("--gpu", type=int, default=-1)
    parser.add_argument("--num-envs", type=int, default=8)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--outdir", default="runs")
    parser.add_argument("--steps", type=int, default=1_000_000)
    parser.add_argument("--eval-interval", type=int, default=10_000)
    parser.add_argument("--reward-scale-factor", type=float, default=1.0)
    parser.add_argument("--lr", type=float, default=3e-4)
    parser.add_argument("--weight-decay", type=float, default=0.0)
    parser.add_argument("--eval-n-runs", type=int, default=10)
    parser.add_argument("--demo", action="store_true")
    parser.add_argument("--load", type=str, default=None)
    parser.add_argument("--log-interval", type=int, default=1000)
    parser.add_argument("--window-size", type=int, default=1000)
    parser.add_argument("--standardize-advantages", action="store_true")
    parser.add_argument("--entropy-coef", type=float, default=0.0)
    return parser.parse_args()


def main():
    args = parse_args()
    os.makedirs(args.outdir, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=[logging.FileHandler(os.path.join(args.outdir, "train.log"))],
    )

    device = torch.device("cuda" if args.gpu >= 0 and torch.cuda.is_available() else "cpu")
    set_random_seed(args.seed, use_cuda=device.type == "cuda")

    train_envs = make_vec_env(
        args.env,
        args.num_envs,
        args.seed,
        is_testing=False,
        render_mode=None,
        reward_scale_factor=args.reward_scale_factor,
    )
    eval_envs = make_vec_env(
        args.env,
        args.num_envs,
        args.seed,
        is_testing=True,
        render_mode=None,
        reward_scale_factor=args.reward_scale_factor,
    )

    sample_env = gym.make(args.env)
    sample_obs = sample_env.reset()
    obs_shape = np.array(sample_obs).shape[0] if isinstance(sample_obs, np.ndarray) else 1

    normalizer = EmpiricalNormalization(obs_shape)
    model = BranchedModel(sample_env.observation_space, sample_env.action_space).to(device)
    optimizer = optim.Adam(
        model.parameters(), lr=args.lr, weight_decay=args.weight_decay
    )
    agent = PPOAgent(
        model=model,
        optimizer=optimizer,
        normalizer=normalizer,
        update_interval=2048,
        minibatch_size=64,
        epochs=10,
        gamma=0.99,
        lam=0.95,
        entropy_coef=args.entropy_coef,
        value_coef=0.5,
        max_grad_norm=0.5,
        standardize_advantages=args.standardize_advantages,
    )

    if args.load:
        checkpoint = torch.load(args.load, map_location=device)
        agent.model.load_state_dict(checkpoint["model_state"])
        agent.optimizer.load_state_dict(checkpoint["optimizer_state"])
        logging.info(f"Loaded checkpoint from {args.load}")

    if args.demo:
        avg_return = agent.evaluate(eval_envs, device, args.eval_n_runs)
        logging.info(f"Demo return: {avg_return:.2f}")
        return

    agent.train(
        train_envs,
        eval_envs,
        device,
        total_steps=args.steps,
        eval_interval=args.eval_interval,
        eval_n_runs=args.eval_n_runs,
        log_interval=args.log_interval,
    )

    # Save checkpoint
    checkpoint_path = os.path.join(args.outdir, "final_checkpoint.pt")
    torch.save(
        {
            "model_state": agent.model.state_dict(),
            "optimizer_state": agent.optimizer.state_dict(),
        },
        checkpoint_path,
    )
    logging.info(f"Training completed. Checkpoint saved to {checkpoint_path}")


if __name__ == "__main__":
    main()
