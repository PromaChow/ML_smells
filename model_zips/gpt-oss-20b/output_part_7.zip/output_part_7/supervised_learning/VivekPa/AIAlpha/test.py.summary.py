import os
import pandas as pd
import numpy as np

# Define file paths
input_file = os.path.join('data', 'raw_data', 'price_vol.csv')
output_dir = os.path.join('sample_data', 'raw_data')
output_file = os.path.join(output_dir, 'price_vol.csv')

# Load data with the first column as index
df = pd.read_csv(input_file, index_col=0)

# Print the shape of the loaded DataFrame
print(df.shape)

# Take the first 1,000,000 rows
subset = df.iloc[:1_000_000]

# Ensure output directory exists
os.makedirs(output_dir, exist_ok=True)

# Save the subset to CSV, overwriting if it exists
subset.to_csv(output_file)