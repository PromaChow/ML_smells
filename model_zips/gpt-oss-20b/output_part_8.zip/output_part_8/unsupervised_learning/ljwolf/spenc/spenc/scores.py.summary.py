import numpy as np

def boundary_fraction(W, labels):
    W = np.asarray(W)
    labels = np.asarray(labels)
    n = W.shape[0]
    boundary = 0
    for i in range(n):
        neighbors = np.nonzero(W[i])[0]
        if neighbors.size == 0:
            continue
        neighbor_labels = labels[neighbors]
        if np.any(neighbor_labels != labels[i]):
            boundary += 1
    return boundary / n

def boundary_score(W, labels):
    return np.log(boundary_fraction(W, labels))