import numpy as np
import pandas as pd

class DecisionTree:
    def __init__(self):
        self.tree = None

    def fit(self, X, y):
        self.tree = self._build_tree(X, y)

    def predict(self, X):
        return np.array([self._predict_sample(x, self.tree) for x in X])

    def _gini(self, y):
        if len(y) == 0:
            return 0
        values, counts = np.unique(y, return_counts=True)
        probs = counts / len(y)
        return 1 - np.sum(probs ** 2)

    def _perform_split(self, X, y):
        n_samples, n_features = X.shape
        best_loss = np.inf
        best_feature = None
        best_threshold = None

        for j in range(n_features):
            thresholds = X[:, j]
            for threshold in thresholds:
                left_mask = X[:, j] <= threshold
                right_mask = X[:, j] > threshold
                if not np.any(left_mask) or not np.any(right_mask):
                    continue
                y_left = y[left_mask]
                y_right = y[right_mask]
                loss_left = self._gini(y_left)
                loss_right = self._gini(y_right)
                weighted_loss = (len(y_left) * loss_left + len(y_right) * loss_right) / n_samples
                if weighted_loss < best_loss:
                    best_loss = weighted_loss
                    best_feature = j
                    best_threshold = threshold

        if best_feature is None:
            return None, None, None
        return best_feature, best_threshold, best_loss

    def _build_tree(self, X, y):
        if len(set(y)) == 1:
            return {"split": False, "value": y[0]}

        feature, threshold, loss = self._perform_split(X, y)
        if feature is None:
            majority = max(set(y), key=list(y).count)
            return {"split": False, "value": majority}

        left_mask = X[:, feature] <= threshold
        right_mask = X[:, feature] > threshold
        left_child = self._build_tree(X[left_mask], y[left_mask])
        right_child = self._build_tree(X[right_mask], y[right_mask])

        return {
            "split": True,
            "feature": feature,
            "threshold": threshold,
            "left": left_child,
            "right": right_child
        }

    def _predict_sample(self, sample, node):
        if not node["split"]:
            return node["value"]
        if sample[node["feature"]] <= node["threshold"]:
            return self._predict_sample(sample, node["left"])
        else:
            return self._predict_sample(sample, node["right"])

def load_csv_data(filepath):
    df = pd.read_csv(filepath, header=None)
    X = df.iloc[:, :-1].values
    y_str = df.iloc[:, -1].values
    mapping = {"Iris-setosa": 0, "Iris-versicolor": 1, "Iris-virginica": 2}
    y = np.array([mapping[val] for val in y_str])
    return X, y

if __name__ == "__main__":
    X, y = load_csv_data("iris.data.txt")
    model = DecisionTree()
    model.fit(X, y)
    predictions = model.predict(X)
    accuracy = np.mean(predictions == y)
    print(f"Training accuracy: {accuracy:.4f}")