import tensorflow as tf
from tensorflow.keras import layers, models, regularizers, initializers, optimizers, metrics


def create_base_model(input_shape):
    """
    Builds the base Conv1D model for activity recognition.

    Args:
        input_shape: Tuple of (window_size, num_channels).

    Returns:
        A Keras Model that outputs a feature vector from global max pooling.
    """
    l2_reg = regularizers.l2(1e-4)

    inp = layers.Input(shape=input_shape, name="input")

    x = layers.Conv1D(32, 24, activation="relu", kernel_regularizer=l2_reg, name="conv1")(inp)
    x = layers.Dropout(0.1, name="dropout1")(x)

    x = layers.Conv1D(64, 16, activation="relu", kernel_regularizer=l2_reg, name="conv2")(x)
    x = layers.Dropout(0.1, name="dropout2")(x)

    x = layers.Conv1D(96, 8, activation="relu", kernel_regularizer=l2_reg, name="conv3")(x)
    x = layers.Dropout(0.1, name="dropout3")(x)

    out = layers.GlobalMaxPooling1D(name="global_pool")(x)

    return models.Model(inp, out, name="base_model")


def attach_simclr_head(base_output, hidden_1=256, hidden_2=128, hidden_3=50):
    """
    Adds a SimCLR projection head on top of the base model output.

    Args:
        base_output: Tensor from the base model.
        hidden_1: Units in the first dense layer.
        hidden_2: Units in the second dense layer.
        hidden_3: Units in the third dense layer (output of the head).

    Returns:
        The output tensor of the projection head.
    """
    x = layers.Dense(hidden_1, activation="relu", name="simclr_dense1")(base_output)
    x = layers.Dense(hidden_2, activation="relu", name="simclr_dense2")(x)
    return layers.Dense(hidden_3, activation=None, name="simclr_dense3")(x)


def create_linear_model_from_base_model(base_model, intermediate_layer=7, output_shape=10):
    """
    Creates a linear classification model on top of the base model.

    Args:
        base_model: The pre-built base model.
        intermediate_layer: Index of the layer to tap for features.
        output_shape: Number of output classes.

    Returns:
        Compiled Keras Model ready for training.
    """
    inp = base_model.input
    feature = base_model.layers[intermediate_layer].output

    # Freeze base layers up to the chosen intermediate layer
    for layer in base_model.layers[:intermediate_layer + 1]:
        layer.trainable = False

    out = layers.Dense(
        output_shape,
        kernel_initializer=initializers.RandomNormal(stddev=0.01),
        bias_initializer="zeros",
        activation=None,
        name="linear_dense",
    )(feature)
    out = layers.Softmax(name="softmax")(out)

    model = models.Model(inp, out, name="linear_model")
    model.compile(
        optimizer=optimizers.SGD(learning_rate=0.03),
        loss="categorical_crossentropy",
        metrics=[
            metrics.CategoricalAccuracy(name="categorical_accuracy"),
            metrics.AUC(name="auc"),
            metrics.Precision(name="precision"),
            metrics.Recall(name="recall"),
        ],
    )
    return model


def create_full_classification_model_from_base_model(
    base_model,
    intermediate_layer=7,
    output_shape=10,
    last_freeze_layer=4,
):
    """
    Creates a full classification model with additional trainable layers.

    Args:
        base_model: The pre-built base model.
        intermediate_layer: Index of the layer to tap for features.
        output_shape: Number of output classes.
        last_freeze_layer: Index of the last layer to keep frozen.

    Returns:
        Compiled Keras Model ready for training.
    """
    inp = base_model.input
    feature = base_model.layers[intermediate_layer].output

    # Initially freeze all base layers
    for layer in base_model.layers:
        layer.trainable = False

    # Unfreeze layers after last_freeze_layer
    for layer in base_model.layers[last_freeze_layer + 1 :]:
        layer.trainable = True

    x = layers.Dense(1024, activation="relu", name="fc1")(feature)
    out = layers.Dense(
        output_shape, activation="softmax", name="output_dense"
    )(x)

    model = models.Model(inp, out, name="full_classification_model")
    model.compile(
        optimizer=optimizers.Adam(learning_rate=0.001),
        loss="categorical_crossentropy",
        metrics=[
            metrics.CategoricalAccuracy(name="categorical_accuracy"),
            metrics.AUC(name="auc"),
            metrics.Precision(name="precision"),
            metrics.Recall(name="recall"),
        ],
    )
    return model


def extract_intermediate_model_from_base_model(
    base_model, intermediate_layer=7
):
    """
    Extracts a model that outputs activations from a specified intermediate layer.

    Args:
        base_model: The pre-built base model.
        intermediate_layer: Index of the layer to extract.

    Returns:
        Keras Model that takes the same input and outputs the selected layer.
    """
    inp = base_model.input
    out = base_model.layers[intermediate_layer].output
    return models.Model(inp, out, name="intermediate_model")
