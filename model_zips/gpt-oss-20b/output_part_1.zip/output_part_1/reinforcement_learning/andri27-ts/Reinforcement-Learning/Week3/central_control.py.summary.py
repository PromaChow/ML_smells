import torch
import torch.nn as nn
import torch.nn.functional as F
import math


class NoisyLinear(nn.Module):
    def __init__(self, in_features, out_features, sigma_init=0.017):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features

        self.weight_mu = nn.Parameter(torch.empty(out_features, in_features))
        self.weight_sigma = nn.Parameter(torch.empty(out_features, in_features))
        self.bias_mu = nn.Parameter(torch.empty(out_features))
        self.bias_sigma = nn.Parameter(torch.empty(out_features))

        self.register_buffer("weight_eps", torch.empty(out_features, in_features))
        self.register_buffer("bias_eps", torch.empty(out_features))

        self.sigma_init = sigma_init
        self.reset_parameters()

    def reset_parameters(self):
        bound = 1 / math.sqrt(self.in_features)
        nn.init.uniform_(self.weight_mu, -bound, bound)
        nn.init.uniform_(self.bias_mu, -bound, bound)
        nn.init.constant_(self.weight_sigma, self.sigma_init)
        nn.init.constant_(self.bias_sigma, self.sigma_init)

    def forward(self, input):
        self.sample_noise()
        weight = self.weight_mu + self.weight_sigma * self.weight_eps
        bias = self.bias_mu + self.bias_sigma * self.bias_eps
        return F.linear(input, weight, bias)

    def sample_noise(self):
        eps_in = torch.randn(self.in_features, device=self.weight_mu.device)
        eps_out = torch.randn(self.out_features, device=self.weight_mu.device)
        self.weight_eps.copy_(torch.ger(eps_out, eps_in))
        self.bias_eps.copy_(eps_out)


class DQN(nn.Module):
    def __init__(self, state_dim, action_dim, hidden_dim=128, noisy=False):
        super().__init__()
        Linear = NoisyLinear if noisy else nn.Linear
        self.net = nn.Sequential(
            Linear(state_dim, hidden_dim),
            nn.ReLU(),
            Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            Linear(hidden_dim, action_dim),
        )

    def forward(self, x):
        return self.net(x)


class DuelingDQN(nn.Module):
    def __init__(self, state_dim, action_dim, hidden_dim=128, noisy=False):
        super().__init__()
        Linear = NoisyLinear if noisy else nn.Linear
        self.feature_extractor = nn.Sequential(
            Linear(state_dim, hidden_dim),
            nn.ReLU(),
        )
        self.value_stream = nn.Sequential(
            Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            Linear(hidden_dim, 1),
        )
        self.advantage_stream = nn.Sequential(
            Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            Linear(hidden_dim, action_dim),
        )

    def forward(self, x):
        features = self.feature_extractor(x)
        values = self.value_stream(features)
        advantages = self.advantage_stream(features)
        q_vals = values + advantages - advantages.mean(dim=1, keepdim=True)
        return q_vals


class CentralControl:
    def __init__(
        self,
        state_dim,
        action_dim,
        gamma=0.99,
        n_multi_step=1,
        double_DQN=False,
        noisy=False,
        dueling=False,
        device="cpu",
        learning_rate=1e-3,
    ):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.gamma = gamma
        self.n_multi_step = n_multi_step
        self.double_DQN = double_DQN
        self.noisy = noisy
        self.dueling = dueling
        self.device = torch.device(device)
        self.learning_rate = learning_rate

        if dueling:
            self.target_nn = DuelingDQN(state_dim, action_dim, noisy=noisy).to(self.device)
            self.moving_nn = DuelingDQN(state_dim, action_dim, noisy=noisy).to(self.device)
        else:
            self.target_nn = DQN(state_dim, action_dim, noisy=noisy).to(self.device)
            self.moving_nn = DQN(state_dim, action_dim, noisy=noisy).to(self.device)

        self.set_optimizer()

    def set_optimizer(self):
        self.optimizer = torch.optim.Adam(self.moving_nn.parameters(), lr=self.learning_rate)

    def optimize(self, states, actions, next_states, rewards, dones):
        self.optimizer.zero_grad()
        loss = self._calulate_loss(states, actions, next_states, rewards, dones)
        loss.backward()
        self.optimizer.step()
        return loss.item()

    def update_target(self):
        self.target_nn.load_state_dict(self.moving_nn.state_dict())

    def get_max_action(self, observation):
        obs = torch.tensor(observation, dtype=torch.float32, device=self.device).unsqueeze(0)
        with torch.no_grad():
            q_vals = self.moving_nn(obs)
        return int(torch.argmax(q_vals, dim=1).item())

    def _calulate_loss(self, states, actions, next_states, rewards, dones):
        states = torch.tensor(states, dtype=torch.float32, device=self.device)
        actions = torch.tensor(actions, dtype=torch.long, device=self.device)
        next_states = torch.tensor(next_states, dtype=torch.float32, device=self.device)
        rewards = torch.tensor(rewards, dtype=torch.float32, device=self.device)
        dones = torch.tensor(dones, dtype=torch.float32, device=self.device)

        state_action_values = self.moving_nn(states).gather(1, actions.unsqueeze(1)).squeeze(1)

        if self.double_DQN:
            with torch.no_grad():
                next_actions = self.moving_nn(next_states).argmax(1)
                next_state_values = self.target_nn(next_states).gather(1, next_actions.unsqueeze(1)).squeeze(1)
        else:
            with torch.no_grad():
                next_state_values = self.target_nn(next_states).max(1)[0]

        discount = self.gamma ** self.n_multi_step
        expected_state_action_values = rewards + discount * next_state_values * (1 - dones)
        loss = F.mse_loss(state_action_values, expected_state_action_values)
        return loss
