import numpy as np
import pandas as pd

class PersistenceAgent:
    def __init__(self):
        pass

    def _softmax(self, values: np.ndarray) -> np.ndarray:
        exp_vals = np.exp(values - np.max(values))
        return exp_vals / exp_vals.sum()

    def act(self, observation: dict) -> pd.Series:
        returns = observation["returns"]
        if not isinstance(returns, pd.Series):
            raise TypeError("Expected 'returns' to be a pandas Series")

        if returns.isnull().any():
            mask = returns.isnull()
            random_vals = np.random.uniform(0, 1, size=mask.sum())
            processed = returns.copy()
            processed[mask] = random_vals
        else:
            processed = returns

        probs = self._softmax(processed.values)
        return pd.Series(probs, index=processed.index, name=processed.name)