import cv2
import numpy as np

# Mapping of interpolation modes
INTER_MODE = {
    'NEAREST': cv2.INTER_NEAREST,
    'BILINEAR': cv2.INTER_LINEAR,
    'BICUBIC': cv2.INTER_CUBIC,
}

# Mapping of padding modes to OpenCV border types
PAD_MOD = {
    'constant': cv2.BORDER_CONSTANT,
    'edge': cv2.BORDER_REPLICATE,
    'reflect': cv2.BORDER_REFLECT_101,
    'symmetric': cv2.BORDER_REFLECT,
}

def _is_numpy_image(img):
    return isinstance(img, np.ndarray) and img.ndim in (2, 3)

def add_padding(img, border_size):
    if not _is_numpy_image(img):
        raise ValueError("Input must be a NumPy array representing an image.")
    pad = ((border_size, border_size), (border_size, border_size))
    if img.ndim == 3:
        pad += ((0, 0),)
    return np.pad(img, pad, mode='reflect')

def resize(img, size, interpolation='BILINEAR'):
    if not _is_numpy_image(img):
        raise ValueError("Input must be a NumPy array representing an image.")
    if isinstance(size, int):
        h, w = img.shape[:2]
        if h < w:
            new_h = size
            new_w = int(w * size / h)
        else:
            new_w = size
            new_h = int(h * size / w)
        dsize = (new_w, new_h)
    elif isinstance(size, tuple) and len(size) == 2:
        dsize = (size[1], size[0])
    else:
        raise ValueError("Size must be int or tuple of (h, w).")
    return cv2.resize(img, dsize, interpolation=INTER_MODE[interpolation])

def pad(img, padding, mode='constant', value=0):
    if not _is_numpy_image(img):
        raise ValueError("Input must be a NumPy array representing an image.")
    top = bottom = left = right = padding
    return cv2.copyMakeBorder(img, top, bottom, left, right, PAD_MOD[mode], value=value)

def crop(img, x, y, h, w):
    if not _is_numpy_image(img):
        raise ValueError("Input must be a NumPy array representing an image.")
    h_img, w_img = img.shape[:2]
    # Pad if needed
    if x < 0 or y < 0 or x + w > w_img or y + h > h_img:
        pad_left = max(0, -x)
        pad_top = max(0, -y)
        pad_right = max(0, x + w - w_img)
        pad_bottom = max(0, y + h - h_img)
        img = cv2.copyMakeBorder(img, pad_top, pad_bottom, pad_left, pad_right, cv2.BORDER_REFLECT_101)
        x += pad_left
        y += pad_top
    return img[y:y + h, x:x + w]

def center_crop(img, output_size):
    if not _is_numpy_image(img):
        raise ValueError("Input must be a NumPy array representing an image.")
    h, w = img.shape[:2]
    if isinstance(output_size, int):
        output_size = (output_size, output_size)
    out_h, out_w = output_size
    start_x = (w - out_w) // 2
    start_y = (h - out_h) // 2
    return crop(img, start_x, start_y, out_h, out_w)

def resized_crop(img, crop_box, size, interpolation='BILINEAR'):
    x, y, h, w = crop_box
    cropped = crop(img, x, y, h, w)
    return resize(cropped, size, interpolation)

def hflip(img):
    if not _is_numpy_image(img):
        raise ValueError("Input must be a NumPy array representing an image.")
    return cv2.flip(img, 1)

def vflip(img):
    if not _is_numpy_image(img):
        raise ValueError("Input must be a NumPy array representing an image.")
    return cv2.flip(img, 0)

def five_crop(img, size):
    if not _is_numpy_image(img):
        raise ValueError("Input must be a NumPy array representing an image.")
    h, w = img.shape[:2]
    if isinstance(size, int):
        size = (size, size)
    out_h, out_w = size
    crops = []
    # Top-left
    crops.append(crop(img, 0, 0, out_h, out_w))
    # Top-right
    crops.append(crop(img, w - out_w, 0, out_h, out_w))
    # Bottom-left
    crops.append(crop(img, 0, h - out_h, out_h, out_w))
    # Bottom-right
    crops.append(crop(img, w - out_w, h - out_h, out_h, out_w))
    # Center
    crops.append(center_crop(img, size))
    return crops

def ten_crop(img, size):
    crops = five_crop(img, size)
    flipped = hflip(img)
    flips = five_crop(flipped, size)
    return crops + flips

def adjust_brightness(img, brightness_factor):
    if not _is_numpy_image(img):
        raise ValueError("Input must be a NumPy array representing an image.")
    img = img.astype(np.float32) * brightness_factor
    img = np.clip(img, 0, 255)
    return img.astype(img.dtype)

def adjust_contrast(img, contrast_factor):
    if not _is_numpy_image(img):
        raise ValueError("Input must be a NumPy array representing an image.")
    mean = np.mean(img, axis=(0, 1), keepdims=True)
    img = (img - mean) * contrast_factor + mean
    img = np.clip(img, 0, 255)
    return img.astype(img.dtype)

def adjust_saturation(img, saturation_factor):
    if not _is_numpy_image(img):
        raise ValueError("Input must be a NumPy array representing an image.")
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV).astype(np.float32)
    hsv[:, :, 1] *= saturation_factor
    hsv[:, :, 1] = np.clip(hsv[:, :, 1], 0, 255)
    return cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2BGR)

def adjust_hue(img, hue_factor):
    if not _is_numpy_image(img):
        raise ValueError("Input must be a NumPy array representing an image.")
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV).astype(np.float32)
    hsv[:, :, 0] = (hsv[:, :, 0] + hue_factor * 180) % 180
    return cv2.cvtColor(hsv.astype(np.uint8), cv2.COLOR_HSV2BGR)

def adjust_gamma(img, gamma, gain=1.0):
    if not _is_numpy_image(img):
        raise ValueError("Input must be a NumPy array representing an image.")
    inv_gamma = 1.0 / gamma
    table = np.array([((i / 255.0) ** inv_gamma) * 255 * gain for i in range(256)]).clip(0, 255).astype(np.uint8)
    return cv2.LUT(img, table)

def to_grayscale(img, num_output_channels=1):
    if not _is_numpy_image(img):
        raise ValueError("Input must be a NumPy array representing an image.")
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    if num_output_channels == 3:
        gray = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
    return gray

def rotate(img, angle, expand=False, interpolation='BILINEAR'):
    if not _is_numpy_image(img):
        raise ValueError("Input must be a NumPy array representing an image.")
    h, w = img.shape[:2]
    center = (w / 2, h / 2)
    M = cv2.getRotationMatrix2D(center, angle, 1.0)
    if expand:
        cos = np.abs(M[0, 0])
        sin = np.abs(M[0, 1])
        new_w = int((h * sin) + (w * cos))
        new_h = int((h * cos) + (w * sin))
        M[0, 2] += (new_w / 2) - center[0]
        M[1, 2] += (new_h / 2) - center[1]
        return cv2.warpAffine(img, M, (new_w, new_h), flags=INTER_MODE[interpolation], borderMode=cv2.BORDER_REFLECT_101)
    else:
        return cv2.warpAffine(img, M, (w, h), flags=INTER_MODE[interpolation], borderMode=cv2.BORDER_REFLECT_101)

def affine(img, angle=0, translate=(0, 0), scale=1.0, shear=0, interpolation='BILINEAR', fill_color=(0, 0, 0)):
    if not _is_numpy_image(img):
        raise ValueError("Input must be a NumPy array representing an image.")
    h, w = img.shape[:2]
    angle_rad = np.deg2rad(angle)
    shear_rad = np.deg2rad(shear)
    M = np.array([
        [scale * np.cos(angle_rad), -scale * np.sin(angle_rad + shear_rad), translate[0]],
        [scale * np.sin(angle_rad),  scale * np.cos(angle_rad + shear_rad), translate[1]]
    ])
    return cv2.warpAffine(img, M, (w, h), flags=INTER_MODE[interpolation], borderMode=cv2.BORDER_CONSTANT, borderValue=fill_color)

def affine6(img, angle=0, anglez=0, translate=(0, 0), scale=1.0, shear=0, interpolation='BILINEAR', fill_color=(0, 0, 0)):
    # Simplified version using 2D affine
    return affine(img, angle=angle, translate=translate, scale=scale, shear=shear, interpolation=interpolation, fill_color=fill_color)

def perspective(img, fov=90, rotations=(0, 0, 0), scale=1.0, translations=(0, 0), interpolation='BILINEAR', fill_color=(0, 0, 0)):
    if not _is_numpy_image(img):
        raise ValueError("Input must be a NumPy array representing an image.")
    h, w = img.shape[:2]
    # Simple perspective transform: use four corner points
    center = np.array([w / 2, h / 2])
    pts1 = np.float32([[0, 0], [w, 0], [w, h], [0, h]])
    offset = np.array([translations[0], translations[1]])
    scale_mat = np.array([[scale, 0, 0], [0, scale, 0], [0, 0, 1]])
    rot_x = np.array([[1, 0, 0], [0, np.cos(np.deg2rad(rotations[0])), -np.sin(np.deg2rad(rotations[0]))], [0, np.sin(np.deg2rad(rotations[0])), np.cos(np.deg2rad(rotations[0]))]])
    rot_y = np.array([[np.cos(np.deg2rad(rotations[1])), 0, np.sin(np.deg2rad(rotations[1]))], [0, 1, 0], [-np.sin(np.deg2rad(rotations[1])), 0, np.cos(np.deg2rad(rotations[1]))]])
    rot_z = np.array([[np.cos(np.deg2rad(rotations[2])), -np.sin(np.deg2rad(rotations[2])), 0], [np.sin(np.deg2rad(rotations[2])), np.cos(np.deg2rad(rotations[2])), 0], [0, 0, 1]])
    proj = rot_z @ rot_y @ rot_x @ scale_mat
    proj[2, 2] = 1
    proj = proj[:2, :]
    src = pts1
    dst = (proj @ np.vstack((src.T, np.ones((1, 4)))).T).T
    M = cv2.getPerspectiveTransform(src, dst)
    return cv2.warpPerspective(img, M, (w, h), flags=INTER_MODE[interpolation], borderMode=cv2.BORDER_CONSTANT, borderValue=fill_color)

def gaussian_noise(img, mean=0, std=10):
    if not _is_numpy_image(img):
        raise ValueError("Input must be a NumPy array representing an image.")
    gauss = np.random.normal(mean, std, img.shape).astype(np.float32)
    noisy = img.astype(np.float32) + gauss
    noisy = np.clip(noisy, 0, 255)
    return noisy.astype(img.dtype)

def poisson_noise(img, lam=30):
    if not _is_numpy_image(img):
        raise ValueError("Input must be a NumPy array representing an image.")
    vals = np.random.poisson(img / 255.0 * lam)
    noisy = vals * (255.0 / lam)
    noisy = np.clip(noisy, 0, 255)
    return noisy.astype(img.dtype)

def salt_and_pepper(img, amount=0.01, s_vs_p=0.5):
    if not _is_numpy_image(img):
        raise ValueError("Input must be a NumPy array representing an image.")
    out = img.copy()
    num_pixels = int(amount * img.size)
    num_salt = int(num_pixels * s_vs_p)
    num_pepper = num_pixels - num_salt
    coords = [np.random.randint(0, i - 1, num_salt) for i in img.shape]
    out[tuple(coords)] = 255
    coords = [np.random.randint(0, i - 1, num_pepper) for i in img.shape]
    out[tuple(coords)] = 0
    return out

__all__ = [
    'add_padding', 'resize', 'pad', 'crop', 'center_crop', 'resized_crop',
    'hflip', 'vflip', 'five_crop', 'ten_crop', 'adjust_brightness',
    'adjust_contrast', 'adjust_saturation', 'adjust_hue', 'adjust_gamma',
    'to_grayscale', 'rotate', 'affine', 'affine6', 'perspective',
    'gaussian_noise', 'poisson_noise', 'salt_and_pepper'
]