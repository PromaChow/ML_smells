import pytest
import numpy as np
from lagom import returns, bootstrapped_returns, td0_target, td0_error, gae, vtrace


@pytest.mark.parametrize(
    "rewards,gamma,expected",
    [
        (
            np.array([1.0, 2.0, 3.0]),
            0.9,
            np.array(
                [
                    1.0 + 0.9 * 2.0 + 0.9 ** 2 * 3.0,
                    2.0 + 0.9 * 3.0,
                    3.0,
                ]
            ),
        ),
        (
            np.array([0.1, 0.2, 0.3]),
            0.95,
            np.array(
                [
                    0.1 + 0.95 * 0.2 + 0.95 ** 2 * 0.3,
                    0.2 + 0.95 * 0.3,
                    0.3,
                ]
            ),
        ),
    ],
)
def test_returns(rewards, gamma, expected):
    assert np.allclose(returns(rewards, gamma), expected, atol=1e-6)


@pytest.mark.parametrize(
    "rewards,gamma,last_V,reach_terminal,expected",
    [
        (
            np.array([1.0, 2.0]),
            0.9,
            5.0,
            True,
            np.array([1.0 + 0.9 * 2.0, 2.0]),
        ),
        (
            np.array([1.0, 2.0]),
            0.9,
            5.0,
            False,
            np.array([1.0 + 0.9 * 2.0 + 0.9 ** 2 * 5.0, 2.0 + 0.9 * 5.0, 5.0]),
        ),
    ],
)
def test_bootstrapped_returns(rewards, gamma, last_V, reach_terminal, expected):
    assert np.allclose(
        bootstrapped_returns(
            rewards, gamma, last_V, reach_terminal=reach_terminal
        ),
        expected,
        atol=1e-6,
    )


@pytest.mark.parametrize(
    "rewards,Vs,gamma,last_V,expected_targets,expected_errors",
    [
        (
            np.array([1.0, 2.0]),
            np.array([3.0, 4.0]),
            0.9,
            5.0,
            np.array([1.0 + 0.9 * 4.0, 2.0 + 0.9 * 5.0]),
            np.array([1.0 + 0.9 * 4.0 - 3.0, 2.0 + 0.9 * 5.0 - 4.0]),
        ),
    ],
)
def test_td0_target_and_error(
    rewards, Vs, gamma, last_V, expected_targets, expected_errors
):
    targets = td0_target(rewards, Vs, gamma, last_V)
    errors = td0_error(rewards, Vs, gamma, last_V)
    assert np.allclose(targets, expected_targets, atol=1e-6)
    assert np.allclose(errors, expected_errors, atol=1e-6)


@pytest.mark.parametrize(
    "rewards,Vs,gamma,lam,last_V,expected_advantages",
    [
        (
            np.array([1.0, 2.0]),
            np.array([3.0, 4.0]),
            0.9,
            0.95,
            5.0,
            np.array(
                [
                    (1.0 + 0.9 * 4.0 - 3.0)
                    + (0.9 * 0.95) * (2.0 + 0.9 * 5.0 - 4.0),
                    (2.0 + 0.9 * 5.0 - 4.0),
                ]
            ),
        ),
    ],
)
def test_gae(rewards, Vs, gamma, lam, last_V, expected_advantages):
    advantages = gae(rewards, Vs, gamma, lam, last_V)
    assert np.allclose(advantages, expected_advantages, atol=1e-6)


@pytest.mark.parametrize(
    "log_pi,log_mu,rewards,Vs,gamma,clip_rho,clip_pg_rho,expected_values,expected_advantages",
    [
        (
            np.array([0.0, 0.0]),  # log probabilities of target policy
            np.array([0.0, 0.0]),  # log probabilities of behavior policy
            np.array([1.0, 2.0]),
            np.array([3.0, 4.0]),
            0.9,
            1.0,
            1.0,
            np.array(
                [
                    3.0 + (1.0) * (1.0 + 0.9 * 4.0 - 3.0),
                    4.0 + (1.0) * (2.0 + 0.9 * 5.0 - 4.0),  # last V assumed 5.0
                ]
            ),
            np.array(
                [
                    1.0 + 0.9 * 4.0 - 3.0,
                    2.0 + 0.9 * 5.0 - 4.0,
                ]
            ),
        ),
    ],
)
def test_vtrace(
    log_pi,
    log_mu,
    rewards,
    Vs,
    gamma,
    clip_rho,
    clip_pg_rho,
    expected_values,
    expected_advantages,
):
    # Extend Vs to include last_V=5.0 for convenience
    Vs_ext = np.append(Vs, 5.0)
    values, advantages = vtrace(
        log_pi,
        log_mu,
        rewards,
        Vs_ext,
        gamma=gamma,
        clip_rho=clip_rho,
        clip_pg_rho=clip_pg_rho,
    )
    # Expected values should have length len(rewards)
    assert np.allclose(values, expected_values, atol=1e-6)
    assert np.allclose(advantages, expected_advantages, atol=1e-6)