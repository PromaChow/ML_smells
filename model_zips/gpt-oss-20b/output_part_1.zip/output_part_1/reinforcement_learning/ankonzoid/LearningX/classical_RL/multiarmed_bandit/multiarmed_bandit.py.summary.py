import os
import numpy as np
import matplotlib.pyplot as plt

class Environment:
    def __init__(self, probs, rng):
        self.probs = np.asarray(probs)
        self.rng = rng

    def step(self, action):
        return self.rng.binomial(1, self.probs[action])

class Agent:
    def __init__(self, n_arms, eps, rng):
        self.n_arms = n_arms
        self.eps = eps
        self.rng = rng
        self.n = np.zeros(n_arms, dtype=int)
        self.Q = np.zeros(n_arms, dtype=float)

    def select_action(self):
        if self.rng.random() < self.eps:
            return self.rng.integers(self.n_arms)
        else:
            return int(np.argmax(self.Q))

    def update(self, action, reward):
        self.n[action] += 1
        alpha = 1.0 / self.n[action]
        self.Q[action] += alpha * (reward - self.Q[action])

def run_experiment(n_steps, env, agent):
    rewards = np.empty(n_steps, dtype=int)
    actions = np.empty(n_steps, dtype=int)
    for t in range(n_steps):
        a = agent.select_action()
        r = env.step(a)
        agent.update(a, r)
        rewards[t] = r
        actions[t] = a
    return rewards, actions

def main():
    # Simulation parameters
    N_steps = 500
    N_experiments = 10000
    eps = 0.1
    probs = [0.05, 0.15, 0.25, 0.35, 0.45, 0.55, 0.65, 0.75, 0.85, 0.95]
    n_arms = len(probs)

    # Accumulators
    total_rewards = np.zeros(N_steps, dtype=float)
    action_counts = np.zeros((N_steps, n_arms), dtype=int)

    base_seed = 42
    for exp_idx in range(N_experiments):
        rng = np.random.default_rng(base_seed + exp_idx)
        env = Environment(probs, rng)
        agent = Agent(n_arms, eps, rng)
        rewards, actions = run_experiment(N_steps, env, agent)
        total_rewards += rewards
        action_counts[np.arange(N_steps), actions] += 1

    avg_rewards = total_rewards / N_experiments
    action_frequencies = action_counts / N_experiments * 100  # percentage

    # Plot average reward per step
    plt.figure(figsize=(10, 6))
    plt.plot(avg_rewards, label='Average Reward')
    plt.xlabel('Step')
    plt.ylabel('Average Reward')
    plt.title('Average Reward per Step')
    plt.grid(True)
    plt.legend()
    os.makedirs('output', exist_ok=True)
    plt.savefig('output/reward.png')
    plt.close()

    # Plot action selection frequencies
    plt.figure(figsize=(10, 6))
    for arm in range(n_arms):
        plt.plot(action_frequencies[:, arm], label=f'Arm {arm}')
    plt.xlabel('Step')
    plt.ylabel('Selection Frequency (%)')
    plt.title('Action Selection Frequencies')
    plt.grid(True)
    plt.legend()
    plt.savefig('output/action_frequency.png')
    plt.close()

if __name__ == "__main__":
    main()
