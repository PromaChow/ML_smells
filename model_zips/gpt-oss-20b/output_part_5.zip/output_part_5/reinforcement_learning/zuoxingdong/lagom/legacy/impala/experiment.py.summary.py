import gym
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import multiprocessing as mp
import time
import pickle
from collections import deque, defaultdict
from dataclasses import dataclass, field

# ================== Configuration ==================

@dataclass
class Config:
    env_id: str = "Hopper-v3"
    network_sizes: list = field(default_factory=lambda: [64, 64])
    learning_rate: float = 7e-4
    gamma: float = 0.99
    clip_action: bool = True
    standardize_obs: bool = True
    standardize_reward: bool = True
    total_timesteps: int = int(1e6)
    timestep_per_iter: int = 200
    batch_size: int = 64
    num_actors: int = 2
    eval_freq: int = 5000
    eval_num_episode: int = 10
    log_freq: int = 1000
    checkpoint_num: int = 3
    log_dir: str = "logs/default"
    seed: int = 42

config = Config()

# ================== Utility Functions ==================

def set_global_seeds(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

# ================== Environment Wrappers ==================

class ClipAction(gym.ActionWrapper):
    def __init__(self, env, low=-1.0, high=1.0):
        super().__init__(env)
        self.low = low
        self.high = high

    def action(self, action):
        return np.clip(action, self.low, self.high)

class VecMonitor(gym.Wrapper):
    def __init__(self, env):
        super().__init__(env)
        self.episode_rewards = []
        self.episode_lengths = []
        self._episode_reward = 0.0
        self._episode_length = 0

    def step(self, action):
        obs, reward, done, info = self.env.step(action)
        self._episode_reward += reward
        self._episode_length += 1
        if done:
            self.episode_rewards.append(self._episode_reward)
            self.episode_lengths.append(self._episode_length)
            info["episode"] = {"r": self._episode_reward, "l": self._episode_length}
            self._episode_reward = 0.0
            self._episode_length = 0
        return obs, reward, done, info

    def reset(self, **kwargs):
        return self.env.reset(**kwargs)

class VecStandardizeObservation(gym.Wrapper):
    def __init__(self, env, eps=1e-5):
        super().__init__(env)
        self.eps = eps
        self.mean = np.zeros(self.env.observation_space.shape)
        self.var = np.ones(self.env.observation_space.shape)

    def step(self, action):
        obs, reward, done, info = self.env.step(action)
        obs = (obs - self.mean) / (np.sqrt(self.var) + self.eps)
        return obs, reward, done, info

    def reset(self, **kwargs):
        return self.env.reset(**kwargs)

class VecStandardizeReward(gym.Wrapper):
    def __init__(self, env, eps=1e-5):
        super().__init__(env)
        self.eps = eps
        self.mean = 0.0
        self.var = 1.0

    def step(self, action):
        obs, reward, done, info = self.env.step(action)
        reward = (reward - self.mean) / (np.sqrt(self.var) + self.eps)
        return obs, reward, done, info

    def reset(self, **kwargs):
        return self.env.reset(**kwargs)

def make_env():
    env = gym.make(config.env_id)
    if config.clip_action:
        env = ClipAction(env)
    env = VecMonitor(env)
    if config.standardize_obs:
        env = VecStandardizeObservation(env)
    if config.standardize_reward:
        env = VecStandardizeReward(env)
    return env

# ================== Policy Network ==================

class PolicyNetwork(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden_sizes):
        super().__init__()
        layers = []
        in_dim = obs_dim
        for size in hidden_sizes:
            layers.append(nn.Linear(in_dim, size))
            layers.append(nn.ReLU())
            in_dim = size
        layers.append(nn.Linear(in_dim, act_dim))
        self.model = nn.Sequential(*layers)

    def forward(self, x):
        return self.model(x)

# ================== Agent ==================

class Agent:
    def __init__(self):
        env = make_env()
        obs_dim = env.observation_space.shape[0]
        act_dim = env.action_space.shape[0]
        self.policy = PolicyNetwork(obs_dim, act_dim, config.network_sizes)
        self.optimizer = optim.Adam(self.policy.parameters(), lr=config.learning_rate)

    def act(self, obs):
        obs = torch.tensor(obs, dtype=torch.float32)
        with torch.no_grad():
            action = self.policy(obs).numpy()
        return action

# ================== Episode Runner ==================

def run_episode(env, agent, timesteps):
    obs = env.reset()
    trajectories = []
    for _ in range(timesteps):
        action = agent.act(obs)
        next_obs, reward, done, _ = env.step(action)
        trajectories.append((obs, action, reward, done))
        obs = next_obs
        if done:
            obs = env.reset()
    return trajectories

# ================== Training Engine ==================

class Engine:
    def __init__(self, agent):
        self.agent = agent

    def train(self, batch):
        observations, actions, rewards, dones = zip(*batch)
        obs_tensor = torch.tensor(observations, dtype=torch.float32)
        act_tensor = torch.tensor(actions, dtype=torch.float32)
        rew_tensor = torch.tensor(rewards, dtype=torch.float32)
        # Dummy loss: mean squared error between action and observation (placeholder)
        loss = nn.MSELoss()(act_tensor, obs_tensor[:, :act_tensor.shape[1]])
        self.agent.optimizer.zero_grad()
        loss.backward()
        self.agent.optimizer.step()
        return loss.item()

# ================== Actor Process ==================

def actor_process(actor_id, shared_state, data_queue, stop_event):
    set_global_seeds(config.seed + actor_id)
    env = make_env()
    agent = Agent()
    timesteps_collected = 0
    while not stop_event.is_set():
        if shared_state["total_timesteps"] >= config.total_timesteps:
            break
        # Load latest policy from shared state
        if shared_state["policy_state"]:
            agent.policy.load_state_dict(shared_state["policy_state"])
        traj = run_episode(env, agent, config.timestep_per_iter)
        data_queue.put(traj)
        timesteps_collected += config.timestep_per_iter
        with shared_state.get_lock():
            shared_state["total_timesteps"] += config.timestep_per_iter

# ================== Learner Process ==================

def learner_process(shared_state, data_queue, stop_event, logs):
    set_global_seeds(config.seed)
    agent = Agent()
    engine = Engine(agent)
    batch = []
    last_log_step = 0
    checkpoint_steps = []
    while not stop_event.is_set():
        try:
            traj = data_queue.get(timeout=1)
            batch.extend(traj)
            if len(batch) >= config.batch_size:
                loss = engine.train(batch[:config.batch_size])
                batch = batch[config.batch_size:]
                if shared_state["total_timesteps"] - last_log_step >= config.log_freq:
                    logs["train"].append({
                        "step": shared_state["total_timesteps"],
                        "loss": loss
                    })
                    last_log_step = shared_state["total_timesteps"]
                # Checkpointing
                if (shared_state["total_timesteps"] // config.checkpoint_num
                        not in checkpoint_steps):
                    checkpoint_steps.append(shared_state["total_timesteps"] // config.checkpoint_num)
                    torch.save(agent.policy.state_dict(),
                               f"{config.log_dir}/checkpoint_{shared_state['total_timesteps']}.pt")
                if shared_state["total_timesteps"] >= config.total_timesteps:
                    stop_event.set()
        except:
            pass
    # Save final policy
    torch.save(agent.policy.state_dict(), f"{config.log_dir}/final_policy.pt")

# ================== Evaluator Process ==================

def evaluator_process(shared_state, data_queue, stop_event, logs):
    set_global_seeds(config.seed + 100)
    env = make_env()
    agent = Agent()
    evaluated_steps = 0
    while not stop_event.is_set():
        time.sleep(5)
        if shared_state["total_timesteps"] - evaluated_steps >= config.eval_freq:
            if shared_state["policy_state"]:
                agent.policy.load_state_dict(shared_state["policy_state"])
            returns = []
            horizons = []
            for _ in range(config.eval_num_episode):
                obs = env.reset()
                ep_ret = 0.0
                ep_len = 0
                done = False
                while not done:
                    action = agent.act(obs)
                    obs, reward, done, _ = env.step(action)
                    ep_ret += reward
                    ep_len += 1
                returns.append(ep_ret)
                horizons.append(ep_len)
            logs["eval"].append({
                "step": shared_state["total_timesteps"],
                "returns": returns,
                "horizons": horizons
            })
            evaluated_steps = shared_state["total_timesteps"]

# ================== Main Execution ==================

def run():
    mp.set_start_method("spawn", force=True)
    manager = mp.Manager()
    shared_state = manager.dict()
    shared_state["total_timesteps"] = 0
    shared_state["policy_state"] = None
    stop_event = mp.Event()
    data_queue = mp.Queue()
    logs = manager.dict()
    logs["train"] = manager.list()
    logs["eval"] = manager.list()

    # Start learner
    learner = mp.Process(target=learner_process, args=(shared_state, data_queue, stop_event, logs))
    learner.start()

    # Start actors
    actors = []
    for i in range(config.num_actors):
        p = mp.Process(target=actor_process, args=(i, shared_state, data_queue, stop_event))
        p.start()
        actors.append(p)

    # Start evaluator
    evaluator = mp.Process(target=evaluator_process, args=(shared_state, data_queue, stop_event, logs))
    evaluator.start()

    # Wait for all processes
    learner.join()
    for p in actors:
        p.join()
    evaluator.join()

    # Dump logs
    with open(f"{config.log_dir}/train_logs.pkl", "wb") as f:
        pickle.dump(list(logs["train"]), f)
    with open(f"{config.log_dir}/eval_logs.pkl", "wb") as f:
        pickle.dump(list(logs["eval"]), f)

if __name__ == "__main__":
    run()
