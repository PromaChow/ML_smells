import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.decomposition import PCA
from sklearn.manifold import MDS
from sklearn.cluster import KMeans, DBSCAN
from sklearn.decomposition import LatentDirichletAllocation
from scipy.cluster.hierarchy import linkage, dendrogram

# ------------------------------------------------------------------
# Data Preparation
# ------------------------------------------------------------------
cleaned_file = 'cleaned_content.txt'
freq_removed_file = 'freq_words_removed_content.txt'
metadata_file = 'metadata.csv'

with open(cleaned_file, 'r', encoding='utf-8') as f:
    cleaned_texts = [line.strip() for line in f if line.strip()]

with open(freq_removed_file, 'r', encoding='utf-8') as f:
    freq_removed_texts = [line.strip() for line in f if line.strip()]

metadata = pd.read_csv(metadata_file)
book_names = metadata['book_name'].tolist()
authors = metadata['author'].tolist()

# ------------------------------------------------------------------
# Text Representation
# ------------------------------------------------------------------
tfidf_vectorizer = TfidfVectorizer()
tfidf_matrix = tfidf_vectorizer.fit_transform(freq_removed_texts)

similarity_matrix = cosine_similarity(tfidf_matrix)

# ------------------------------------------------------------------
# Dimensionality Reduction and Clustering
# ------------------------------------------------------------------
# KMeans
kmeans = KMeans(n_clusters=5, random_state=42)
kmeans_labels = kmeans.fit_predict(tfidf_matrix)

pca = PCA(n_components=10, random_state=42)
pca_coords = pca.fit_transform(similarity_matrix)

plt.figure(figsize=(8, 6))
scatter = plt.scatter(pca_coords[:, 0], pca_coords[:, 1], c=kmeans_labels, cmap='tab10')
plt.title('KMeans Clustering (5 clusters)')
plt.xlabel('PC1')
plt.ylabel('PC2')
plt.legend(handles=scatter.legend_elements()[0], labels=[f'Cluster {i}' for i in range(5)])
for i, txt in enumerate(authors):
    plt.annotate(txt, (pca_coords[i, 0], pca_coords[i, 1]), fontsize=8, alpha=0.7)
plt.tight_layout()
plt.show()

# DBSCAN
dbscan = DBSCAN(eps=1.2, min_samples=5)
dbscan_labels = dbscan.fit_predict(tfidf_matrix)
dbscan_labels_adj = dbscan_labels + 2  # shift to start from 1

mds = MDS(n_components=2, dissimilarity='precomputed', random_state=42)
mds_coords = mds.fit_transform(1 - similarity_matrix)  # convert similarity to distance

plt.figure(figsize=(8, 6))
scatter = plt.scatter(mds_coords[:, 0], mds_coords[:, 1], c=dbscan_labels_adj, cmap='tab10')
plt.title('DBSCAN Clustering (eps=1.2)')
plt.xlabel('MDS1')
plt.ylabel('MDS2')
unique_labels = np.unique(dbscan_labels_adj)
plt.legend(handles=scatter.legend_elements()[0], labels=[f'Cluster {lbl}' for lbl in unique_labels])
for i, txt in enumerate(authors):
    plt.annotate(txt, (mds_coords[i, 0], mds_coords[i, 1]), fontsize=8, alpha=0.7)
plt.tight_layout()
plt.show()

# ------------------------------------------------------------------
# Hierarchical Analysis
# ------------------------------------------------------------------
linked = linkage(similarity_matrix, method='average')
plt.figure(figsize=(10, 7))
dendrogram(linked, labels=book_names, leaf_rotation=90)
plt.title('Hierarchical Clustering Dendrogram')
plt.xlabel('Book')
plt.ylabel('Distance')
plt.tight_layout()
plt.show()

# ------------------------------------------------------------------
# Topic Modeling
# ------------------------------------------------------------------
count_vectorizer = CountVectorizer()
count_matrix = count_vectorizer.fit_transform(freq_removed_texts)

lda = LatentDirichletAllocation(n_components=5, random_state=42, learning_method='batch')
lda.fit(count_matrix)

feature_names = count_vectorizer.get_feature_names_out()
for idx, topic in enumerate(lda.components_):
    top_indices = topic.argsort()[-5:][::-1]
    top_words = [feature_names[i] for i in top_indices]
    print(f"Topic {idx + 1}: {' '.join(top_words)}")