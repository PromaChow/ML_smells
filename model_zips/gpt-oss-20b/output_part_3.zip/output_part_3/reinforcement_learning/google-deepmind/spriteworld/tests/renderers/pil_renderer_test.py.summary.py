import unittest
import math
import colorsys
from PIL import Image, ImageDraw, ImageFont, ImageEnhance


class Sprite:
    def __init__(self, position, shape, color, scale=1.0):
        self.position = position
        self.shape = shape
        self.color = color
        self.scale = scale


class PILRenderer:
    def __init__(self, size, background=None, antialias=1, color_func=None):
        self.size = size
        self.background = background
        self.antialias = antialias
        self.color_func = color_func or (lambda c: c)

    def render(self, sprites):
        width, height = self.size
        scale = self.antialias
        if scale > 1:
            canvas = Image.new("RGB", (width * scale, height * scale), (0, 0, 0))
        else:
            canvas = Image.new("RGB", (width, height), (0, 0, 0))
        draw = ImageDraw.Draw(canvas)

        if self.background is not None:
            if scale > 1:
                draw.rectangle(
                    [0, 0, width * scale, height * scale],
                    fill=self.background,
                )
            else:
                draw.rectangle([0, 0, width, height], fill=self.background)

        for sprite in sprites:
            col = self.color_func(sprite.color)
            self._draw_shape(draw, sprite, scale, col)

        if scale > 1:
            canvas = canvas.resize((width, height), Image.ANTIALIAS)
        return canvas

    def _draw_shape(self, draw, sprite, scale, color):
        x, y = sprite.position
        s = sprite.scale * scale
        if sprite.shape == "triangle":
            points = [
                (x, y - s),
                (x - s, y + s),
                (x + s, y + s),
            ]
        elif sprite.shape == "square":
            points = [
                (x - s, y - s),
                (x - s, y + s),
                (x + s, y + s),
                (x + s, y - s),
            ]
        elif sprite.shape == "spoke":
            points = []
            for i in range(8):
                angle = i * math.pi / 4
                points.append((x + s * math.cos(angle), y + s * math.sin(angle)))
        else:
            return
        draw.polygon(points, fill=color)


class TestPILRenderer(unittest.TestCase):
    def setUp(self):
        self.sprites = [
            Sprite(position=(32, 32), shape="triangle", color=(255, 0, 0)),
            Sprite(position=(32, 50), shape="square", color=(0, 255, 0)),
            Sprite(position=(5, 5), shape="spoke", color=(5, 6, 7)),
        ]

    def test_basic_functionality(self):
        renderer = PILRenderer(size=(64, 64))
        try:
            img = renderer.render(self.sprites)
        except Exception as e:
            self.fail(f"Rendering raised an exception: {e}")

    def test_background_color(self):
        bg_color = (5, 6, 7)
        renderer = PILRenderer(size=(64, 64), background=bg_color)
        img = renderer.render(self.sprites)
        self.assertEqual(img.getpixel((5, 5)), bg_color)

    def test_occlusion(self):
        renderer = PILRenderer(size=(64, 64))
        img = renderer.render(self.sprites)
        self.assertEqual(img.getpixel((32, 32)), (255, 0, 0))
        self.assertEqual(img.getpixel((32, 50)), (0, 255, 0))

    def test_antialiasing(self):
        # Factor 5
        renderer = PILRenderer(size=(16, 16), antialias=5)
        img = renderer.render(
            [
                Sprite(position=(8, 8), shape="square", color=(255, 0, 0), scale=2)
            ]
        )
        def check_range(pixel, low, high):
            return all(low <= v <= high for v in pixel)

        self.assertTrue(check_range(img.getpixel((4, 6)), 200, 255))
        self.assertTrue(check_range(img.getpixel((5, 6)), 200, 255))
        self.assertTrue(check_range(img.getpixel((6, 6)), 200, 255))
        self.assertTrue(check_range(img.getpixel((7, 6)), 200, 255))

        # Factor 1
        renderer = PILRenderer(size=(16, 16), antialias=1)
        img = renderer.render(
            [
                Sprite(position=(8, 8), shape="square", color=(255, 0, 0), scale=2)
            ]
        )
        self.assertEqual(img.getpixel((4, 6)), (255, 0, 0))
        self.assertEqual(img.getpixel((5, 6)), (255, 0, 0))
        self.assertEqual(img.getpixel((6, 6)), (255, 0, 0))
        self.assertEqual(img.getpixel((7, 6)), (255, 0, 0))

    def test_color_conversion(self):
        def hsv_to_rgb(hsv):
            h, s, v = hsv
            r, g, b = colorsys.hsv_to_rgb(h, s, v)
            return (int(r * 255), int(g * 255), int(b * 255))

        renderer = PILRenderer(size=(64, 64), color_func=hsv_to_rgb)
        sprite = Sprite(position=(32, 32), shape="square", color=(0.2, 0.5, 0.5))
        img = renderer.render([sprite])
        self.assertEqual(img.getpixel((32, 32)), (114, 127, 63))


if __name__ == "__main__":
    unittest.main()
