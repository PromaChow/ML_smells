import argparse
import os
import numpy as np
import gym
import chainer
import chainer.links as L
import chainer.functions as F
import chainerrl as rl
from chainerrl import optimizers
from chainerrl import agents
from chainerrl import env_wrappers
from chainerrl import training
from chainerrl import replay_buffer
from chainerrl import episode_evaluator
from chainerrl.wrappers import atari as atari_wrappers

# ---- Argument Parsing ----
parser = argparse.ArgumentParser(description="PPO training on Atari")
parser.add_argument("--env", type=str, default="BreakoutNoFrameskip-v4",
                    help="Gym environment name")
parser.add_argument("--steps", type=int, default=10_000_000,
                    help="Total training timesteps")
parser.add_argument("--num-envs", type=int, default=8,
                    help="Number of parallel environments")
parser.add_argument("--lr", type=float, default=2.5e-4,
                    help="Learning rate")
parser.add_argument("--batch-size", type=int, default=256,
                    help="Batch size")
parser.add_argument("--epochs", type=int, default=4,
                    help="Epochs per update")
parser.add_argument("--update-interval", type=int, default=1024,
                    help="Timesteps per update")
parser.add_argument("--eval-interval", type=int, default=100_000,
                    help="Timesteps between evaluations")
parser.add_argument("--eval-episodes", type=int, default=10,
                    help="Episodes per evaluation")
parser.add_argument("--monitor", action="store_true",
                    help="Record monitoring videos")
parser.add_argument("--render", action="store_true",
                    help="Render training environments")
parser.add_argument("--recurrent", action="store_true",
                    help="Use recurrent network")
parser.add_argument("--flicker", action="store_true",
                    help="Apply flicker to test environments")
parser.add_argument("--no-frame-stack", action="store_true",
                    help="Disable frame stacking")
parser.add_argument("--seed", type=int, default=0,
                    help="Random seed")
parser.add_argument("--outdir", type=str, default="results",
                    help="Output directory")
parser.add_argument("--checkpoint-frequency", type=int, default=0,
                    help="Frequency (steps) to save checkpoints")
parser.add_argument("--demo", action="store_true",
                    help="Run evaluation only (no training)")
args = parser.parse_args()

# ---- Setup ----
np.random.seed(args.seed)
random_seed = args.seed
os.makedirs(args.outdir, exist_ok=True)

# ---- Environment factories ----
def make_env(rank, is_test=False):
    def thunk():
        env = gym.make(args.env)
        env.seed(random_seed + rank)
        env = atari_wrappers.wrap_deepmind(
            env,
            episode_life=not is_test,
            clip_rewards=not is_test,
            frame_stack=not args.no_frame_stack,
            flicker=args.flicker if is_test else False
        )
        return env
    return thunk

# Main training vector env
main_env = env_wrappers.MultiprocessVectorEnv(
    [make_env(i) for i in range(args.num_envs)]
)
# Evaluation vector env
eval_env = env_wrappers.MultiprocessVectorEnv(
    [make_env(i, is_test=True) for i in range(1)]
)

# ---- Model definition ----
class PolicyValueNet(chainer.Chain):
    def __init__(self, n_actions, recurrent=False):
        super().__init__()
        with self.init_scope():
            self.conv1 = L.Convolution2D(3, 32, 8, stride=4)
            self.conv2 = L.Convolution2D(32, 64, 4, stride=2)
            self.conv3 = L.Convolution2D(64, 64, 3, stride=1)
            self.fc1 = L.Linear(None, 512)
            self.policy_fc = L.Linear(512, n_actions, wscale=rl.initializers.lecun_normal)
            self.value_fc = L.Linear(512, 1)
            if recurrent:
                self.rnn = L.NStepGRU(512, 512, 1)
            else:
                self.rnn = None

    def __call__(self, x, hidden_state=None):
        h = F.relu(self.conv1(x))
        h = F.relu(self.conv2(h))
        h = F.relu(self.conv3(h))
        h = F.reshape(h, (h.shape[0], -1))
        h = F.relu(self.fc1(h))
        logits = self.policy_fc(h)
        value = self.value_fc(h)
        if self.rnn:
            if hidden_state is None:
                hidden_state = chainer.Variable(
                    chainer.cuda.cupy.zeros((1, h.shape[0], 512), dtype=np.float32)
                )
            h, next_hidden = self.rnn(hidden_state, h)
            logits = self.policy_fc(h)
            value = self.value_fc(h)
            return logits, value, next_hidden
        else:
            return logits, value

# Instantiate network
obs_shape = main_env.observation_space.shape
n_actions = main_env.action_space.n
policy_value_net = PolicyValueNet(n_actions, recurrent=args.recurrent)

# ---- Optimizer ----
optimizer = optimizers.Adam(alpha=args.lr, eps=1e-5, clip=0.5)
optimizer.setup(policy_value_net)

# ---- Agent ----
if args.recurrent:
    agent = agents.PPORecurrent(
        policy_value_net,
        clip_eps=0.1,
        clip_eps_vf=None,
        entropy_coef=1e-2,
        standardize_advantages=True,
        recurrent=args.recurrent
    )
else:
    agent = agents.PPO(
        policy_value_net,
        clip_eps=0.1,
        clip_eps_vf=None,
        entropy_coef=1e-2,
        standardize_advantages=True,
        recurrent=args.recurrent
    )
agent.optimizer = optimizer

# ---- Logging ----
log_interval = 10_000

# ---- Evaluation ----
evaluator = episode_evaluator.EpisodeEvaluator(
    eval_env,
    agent,
    eval_episodes=args.eval_episodes
)

# ---- Checkpoint ----
def save_checkpoint(step):
    ckpt_path = os.path.join(args.outdir, f"checkpoint_{step}.npz")
    np.savez(ckpt_path, params=agent.parameters())

# ---- Training or Demo ----
if args.demo:
    evaluator.evaluate()
else:
    total_steps = 0
    while total_steps < args.steps:
        # Linear learning rate decay
        lr = args.lr * (1 - total_steps / args.steps)
        agent.optimizer.lr = lr

        # Train for one update interval
        for _ in range(args.update_interval):
            obs, reward, done, info = main_env.step(agent.act(main_env.obs))
            agent.observe(obs, reward, done, info)
            main_env.obs = obs
            total_steps += args.num_envs
            if total_steps % args.eval_interval == 0:
                evaluator.evaluate()
            if args.checkpoint_frequency > 0 and total_steps % args.checkpoint_frequency == 0:
                save_checkpoint(total_steps)
            if total_steps % log_interval == 0:
                print(f"Step: {total_steps} / {args.steps}")

    # Final evaluation
    evaluator.evaluate()

# ---- Graph visualization ----
try:
    import matplotlib.pyplot as plt
    from chainer import plot
    fig, ax = plt.subplots()
    plot.plot_computational_graph(policy_value_net, shape=obs_shape)
    fig.savefig(os.path.join(args.outdir, "model.png"))
except Exception:
    pass
