import numpy as np

try:
    from gym.envs.mujoco.walker import WalkerBase
    from gym.envs.mujoco import MJCFBasedRobot
except Exception:
    class WalkerBase:
        def __init__(self, power=1.0):
            self.power = power

        def calc_state(self):
            return np.zeros(0)

    class MJCFBasedRobot:
        def __init__(self, xml_path, root, action_dim, observation_dim):
            self.xml_path = xml_path
            self.root = root
            self.action_dim = action_dim
            self.observation_dim = observation_dim
            # Placeholder attributes for demonstration
            self.torso_pose = np.zeros(7)   # [x, y, z, qx, qy, qz, qw]
            self.torso_vel = np.zeros(6)   # [vx, vy, vz, wx, wy, wz]
            self.joint_pos = np.zeros(15)
            self.joint_vel = np.zeros(14)

        def get_torso_pose(self):
            return self.torso_pose

        def get_torso_vel(self):
            return self.torso_vel

        def get_ordered_joint_pos(self):
            return self.joint_pos

        def get_ordered_joint_vel(self):
            return self.joint_vel


class Ant(WalkerBase, MJCFBasedRobot):
    foot_list = ["front_left_foot", "front_right_foot", "rear_left_foot", "rear_right_foot"]

    def __init__(self):
        WalkerBase.__init__(self, power=2.5)
        MJCFBasedRobot.__init__(self, "ant.xml", root="torso", action_dim=8, observation_dim=111)

    def calc_state(self):
        base_state = WalkerBase.calc_state(self)
        torso_pose = self.get_torso_pose()
        qpos = self.get_ordered_joint_pos()  # 15-element array
        torso_vel = self.get_torso_vel()
        qvel = self.get_ordered_joint_vel()  # 14-element array
        cfrc_ext = np.zeros((14, 6))
        state = np.concatenate([
            qpos[2:],
            qvel,
            np.clip(cfrc_ext, -1, 1).reshape(-1)
        ])
        return state

    def alive_bonus(self):
        z = self.get_torso_pose()[2]
        return 1.0 if z > 0.26 else -1.0
