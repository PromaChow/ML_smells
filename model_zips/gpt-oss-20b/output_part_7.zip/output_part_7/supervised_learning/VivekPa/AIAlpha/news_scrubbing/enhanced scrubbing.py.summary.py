import random
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from textblob import TextBlob
import numpy as np
import pandas as pd
import nltk
from datetime import datetime

# Ensure required NLTK data packages are available
nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')

# POS tag identifiers and punctuation list
indentifiers = ['NN', 'NNS', 'NNP', 'NNPS', 'JJ', 'JJR', 'JJS']
PUNC_LIST = ['.', ',', ';', ':', '!', '?', '(', ')', '-', '--', '—', '"', "'"]

# Suppress chained assignment warnings
pd.options.mode.chained_assignment = None

# Sentiment analyzer initialization
sia = SentimentIntensityAnalyzer()

def print_sentiment_scores(sentence: str):
    """Compute and print VADER sentiment scores for a given sentence."""
    scores = sia.polarity_scores(sentence)
    print(scores)

def attention_check(text: str) -> str:
    """Process text by randomly deleting tokens based on defined rules."""
    tokens = nltk.word_tokenize(text)
    tagged = nltk.pos_tag(tokens)
    original_len = len(text)
    min_len = max(56, int(0.2 * original_len))
    new_tokens = []

    for token, tag in zip(tokens, tagged):
        keep = True

        # Random removal for short words (length 2-3) excluding punctuation
        if 2 <= len(token) <= 3 and token not in PUNC_LIST:
            if random.random() < 0.25:
                keep = False

        # Random removal based on POS tags
        if keep:
            if tag in indentifiers:
                if random.random() < 1/7:
                    keep = False
            else:
                if random.random() < 1/3:
                    keep = False

        # Enforce minimum length constraint
        tentative_text = ' '.join(new_tokens + ([token] if keep else []))
        if len(tentative_text) < min_len:
            keep = True

        if keep:
            new_tokens.append(token)

    return ' '.join(new_tokens)

def process_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """Compute overall sentiment for each article in the dataframe."""
    df = df.copy()
    df['Overall Sentiment'] = np.random.rand(len(df))
    for idx, row in df.iterrows():
        body_processed = attention_check(row['Body'])
        body_sent = TextBlob(body_processed).sentiment.polarity
        title_sent = TextBlob(row['Title']).sentiment.polarity
        overall = 0.2 * body_sent + 0.8 * title_sent
        df.at[idx, 'Overall Sentiment'] = overall
    return df

# Load data
news_df = pd.read_csv('news.csv', usecols=['Title', 'Body', 'Date'])
competitor_df = pd.read_csv('competitornews.csv', usecols=['Title', 'Body', 'Date'])

# Process dataframes
news_processed = process_dataframe(news_df)
competitor_processed = process_dataframe(competitor_df)

# Aggregate data
df5 = pd.concat([news_processed, competitor_processed], ignore_index=True)
df5.index = range(1, len(df5) + 1)

# Save aggregated data
df5.to_csv('FinalisedNewsData.csv', index=False)

# Exponentially weighted moving average
ewm_series = df5['Overall Sentiment'].ewm(halflife=0.3289666, adjust=False).mean()
final_value = ewm_series.iloc[-1]

print(ewm_series)
print('Final weighted average:', final_value)