import argparse
import os
import logging
import numpy as np
import gym
import chainer
from chainer import Chain, links as L, functions as F
from chainer import optimizers
from chainer import utils
from chainer import cuda
from chainer_rl import policy
from chainer_rl.agent import REINFORCE, eval_performance, train_agent_with_evaluation

def set_random_seed(seed):
    np.random.seed(seed)
    chainer.random.init_random_state(seed)

class RewardScalingWrapper(gym.Wrapper):
    def __init__(self, env, factor):
        super().__init__(env)
        self.factor = factor
    def step(self, action):
        obs, reward, done, info = self.env.step(action)
        return obs, reward * self.factor, done, info

def make_env(env_name, seed, render=False, monitor=False, outdir=None, reward_scale=1.0):
    env = gym.make(env_name)
    env.seed(seed)
    env.action_space.seed(seed)
    if monitor and outdir:
        env = gym.wrappers.Monitor(env, outdir, force=True)
    env = RewardScalingWrapper(env, reward_scale)
    env._np_random, _ = env.seed(seed)
    if render:
        env.render()
    return env

def build_policy(env):
    if isinstance(env.action_space, gym.spaces.Box):
        return policy.GaussianPolicy(
            L.Linear(env.observation_space.shape[0], 200),
            L.Linear(200, 200),
            L.Linear(200, env.action_space.shape[0]),
            activation=F.leaky_relu,
            std=0.1)
    else:
        return policy.CategoricalPolicy(
            L.Linear(env.observation_space.shape[0], 200),
            L.Linear(200, 200),
            L.Linear(200, env.action_space.n),
            activation=F.leaky_relu)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--env', default='CartPole-v1')
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--gpu', type=int, default=-1)
    parser.add_argument('--outdir', default='output')
    parser.add_argument('--beta', type=float, default=1.0)
    parser.add_argument('--batchsize', type=int, default=1)
    parser.add_argument('--lr', type=float, default=1e-3)
    parser.add_argument('--steps', type=int, default=100000)
    parser.add_argument('--eval-interval', type=int, default=10000)
    parser.add_argument('--eval-n-runs', type=int, default=10)
    parser.add_argument('--reward-scale-factor', type=float, default=1.0)
    parser.add_argument('--render', action='store_true')
    parser.add_argument('--demo', action='store_true')
    parser.add_argument('--load', type=str, default=None)
    parser.add_argument('--logger-level', default='INFO')
    parser.add_argument('--monitor', action='store_true')
    args = parser.parse_args()

    logging.basicConfig(level=getattr(logging, args.logger_level.upper()))
    set_random_seed(args.seed)
    os.makedirs(args.outdir, exist_ok=True)

    train_env = make_env(args.env, args.seed, render=args.render,
                         monitor=args.monitor, outdir=args.outdir,
                         reward_scale=args.reward_scale_factor)
    eval_env = make_env(args.env, args.seed + 1, render=False,
                        monitor=args.monitor, outdir=args.outdir,
                        reward_scale=args.reward_scale_factor)

    pol = build_policy(train_env)
    pol.to_gpu(args.gpu) if args.gpu >= 0 else None

    utils.plot_model(pol, os.path.join(args.outdir, 'model.png'))

    opt = optimizers.Adam(alpha=args.lr)
    opt.setup(pol)
    opt.add_hook(optimizers.GradientClipping(1))

    agent = REINFORCE(pol, opt, beta=args.beta, batchsize=args.batchsize)
    if args.load:
        agent.load(args.load)

    if args.demo:
        results = eval_performance(agent, eval_env, num_episodes=args.eval_n_runs)
        logging.info('Demo results: %s', results)
    else:
        train_agent_with_evaluation(agent, train_env, eval_env,
                                    steps=args.steps,
                                    eval_interval=args.eval_interval,
                                    outdir=args.outdir,
                                    max_episode_steps=train_env._max_episode_steps)

if __name__ == '__main__':
    main()
