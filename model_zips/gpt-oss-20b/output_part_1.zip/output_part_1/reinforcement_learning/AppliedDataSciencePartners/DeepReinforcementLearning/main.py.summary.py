import os
import shutil
import pickle
import logging
from datetime import datetime
from pathlib import Path
import numpy as np
import tensorflow as tf
from tensorflow import keras

# Custom modules (assumed to be available)
from game import Game
from agent import Agent
from memory import MemoryBuffer
from model import build_residual_cnn


# ---------- Configuration ----------
class Config:
    def __init__(self, cfg_file: str):
        # Load configuration from a JSON file
        import json
        with open(cfg_file, 'r') as f:
            data = json.load(f)
        self.EPISODES = data.get('EPISODES', 100)
        self.EVAL_EPISODES = data.get('EVAL_EPISODES', 20)
        self.MEMORY_SIZE = data.get('MEMORY_SIZE', 5000)
        self.SCORING_THRESHOLD = data.get('SCORING_THRESHOLD', 0.55)
        self.CPUCT = data.get('CPUCT', 1.0)
        self.SIMULATIONS = data.get('SIMULATIONS', 100)
        self.MODEL_DIR = Path(data.get('MODEL_DIR', 'models'))
        self.MEMORY_DIR = Path(data.get('MEMORY_DIR', 'memory'))
        self.CONFIG_TEMPLATE = Path(data.get('CONFIG_TEMPLATE', 'config_template.json'))
        self.CONFIG_FILE = Path(cfg_file)
        self.ITER_LOG_INTERVAL = data.get('ITER_LOG_INTERVAL', 5)


def setup_logging():
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')

    # Console handler
    ch = logging.StreamHandler()
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    # File handler
    log_file = Path('training.log')
    fh = logging.FileHandler(log_file)
    fh.setFormatter(formatter)
    logger.addHandler(fh)


# ---------- Main training routine ----------
def main():
    setup_logging()
    logger = logging.getLogger()

    # Load or copy configuration
    cfg_path = Path('config.json')
    if not cfg_path.exists():
        shutil.copyfile(Config.CONFIG_TEMPLATE, cfg_path)
    config = Config(str(cfg_path))

    # Initialize game environment
    game = Game()

    # Memory handling
    memory_file = config.MEMORY_DIR / 'memory.pkl'
    if memory_file.exists():
        with open(memory_file, 'rb') as f:
            memory = pickle.load(f)
        logger.info('Loaded existing memory from %s', memory_file)
    else:
        memory = MemoryBuffer()
        logger.info('Initialized new memory buffer')

    # Neural network setup
    config.MODEL_DIR.mkdir(parents=True, exist_ok=True)
    current_nn_path = config.MODEL_DIR / 'current_model.h5'
    best_nn_path = config.MODEL_DIR / 'best_model.h5'

    current_NN = build_residual_cnn()
    best_NN = build_residual_cnn()

    # Load weights if available
    if current_nn_path.exists():
        current_NN.load_weights(current_nn_path)
        logger.info('Loaded weights for current_NN from %s', current_nn_path)
    else:
        current_NN.save_weights(current_nn_path)
        logger.info('Saved initial weights for current_NN')

    if best_nn_path.exists():
        best_NN.load_weights(best_nn_path)
        logger.info('Loaded weights for best_NN from %s', best_nn_path)
    else:
        best_NN.set_weights(current_NN.get_weights())
        best_NN.save_weights(best_nn_path)
        logger.info('Set best_NN weights to current_NN and saved')

    # Agent creation
    current_player = Agent(
        model=current_NN,
        simulations=config.SIMULATIONS,
        c_puct=config.CPUCT,
        player_id=1
    )
    best_player = Agent(
        model=best_NN,
        simulations=config.SIMULATIONS,
        c_puct=config.CPUCT,
        player_id=1
    )

    iteration = 0
    while True:
        iteration += 1
        logger.info('=== Iteration %d started ===', iteration)

        # Reload configuration to capture any updates
        config = Config(str(cfg_path))

        # Self-play episodes
        for ep in range(config.EPISODES):
            state_history = []
            action_history = []
            value_history = []

            game.reset()
            current_player.reset()
            best_player.reset()

            # Self-play: best_player plays both sides
            turn = 1
            while not game.is_over():
                player = best_player if turn == 1 else best_player  # same agent
                move, value = player.select_action(game)
                game.apply_move(move)
                state_history.append(game.get_state())
                action_history.append(move)
                value_history.append(value)
                turn = 2 if turn == 1 else 1

            # Store episode data in short-term memory
            for state, action, value in zip(state_history, action_history, value_history):
                memory.add(state, action, value, is_long_term=False)

        # Clear short-term memory after iteration
        memory.clear_short()

        # Check for retraining
        if memory.long_size() >= config.MEMORY_SIZE:
            logger.info('Long-term memory reached size %d, starting retraining',
                        memory.long_size())
            # Experience replay
            X, y = memory.get_long_term_batch()
            current_player.train_on_batch(X, y)
            # Log sampled entries
            sample = memory.sample_long_term(5)
            for s, a, v in sample:
                pred = current_NN.predict(np.array([s]))[0]
                logger.info('Sampled state: %s, action: %s, value: %.3f, NN pred: %.3f',
                            s, a, v, pred)

            # Save current model
            current_NN.save_weights(current_nn_path)
            logger.info('Saved current model weights to %s', current_nn_path)

        # Tournament evaluation
        scores = {'best': 0, 'current': 0}
        for eval_ep in range(config.EVAL_EPISODES):
            game.reset()
            turn = 1  # best_player starts first
            while not game.is_over():
                player = best_player if turn == 1 else current_player
                move, _ = player.select_action(game)
                game.apply_move(move)
                turn = 2 if turn == 1 else 1

            winner = game.get_winner()
            if winner == 1:
                scores['best'] += 1
            elif winner == -1:
                scores['current'] += 1
            # draws not counted

        logger.info('Tournament results: Best %d vs Current %d',
                    scores['best'], scores['current'])
        win_rate = scores['current'] / (scores['best'] + scores['current'])
        logger.info('Current win rate: %.2f%%', win_rate * 100)

        # Model update condition
        if win_rate >= config.SCORING_THRESHOLD:
            best_NN.set_weights(current_NN.get_weights())
            best_NN.save_weights(best_nn_path)
            logger.info('Updated best_NN with current_NN weights and saved')

        # Periodic memory snapshot
        if iteration % config.ITER_LOG_INTERVAL == 0:
            snap_file = config.MEMORY_DIR / f'memory_iter_{iteration}.pkl'
            with open(snap_file, 'wb') as f:
                pickle.dump(memory, f)
            logger.info('Saved memory snapshot to %s', snap_file)

        logger.info('=== Iteration %d completed ===', iteration)


if __name__ == '__main__':
    main()