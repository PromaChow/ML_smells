import os
import json
import random
import time
import multiprocessing
from dataclasses import dataclass, field
from pathlib import Path
from typing import Tuple, List, Any

import gymnasium as gym
import numpy as np
import torch
import torch.nn as nn
from torch import optim

# ----------------------------------------------------------------------
# Configuration
# ----------------------------------------------------------------------
@dataclass
class Config:
    # Training settings
    generations: int = 500
    population_size: int = 32
    lr: float = 1e-2
    sigma_schedule: Tuple[float, float] = (1.0, 0.1)
    rank_transform: bool = True

    # Environment settings
    envs: List[str] = field(default_factory=lambda: [
        "Acrobot-v1",
        "BipedalWalker-v2",
        "Pendulum-v0",
        "LunarLanderContinuous-v2",
    ])
    clip_action: bool = True
    init_std: float = 0.6

    # Logging and checkpointing
    log_every: int = 10
    checkpoint_every: int = 50
    num_checkpoints: int = 3

    # Misc
    use_gpu: bool = False
    output_dir: str = "logs/default"
    worker_chunksize: int = 4
    max_workers: int = 7


config = Config()

# ----------------------------------------------------------------------
# Utility functions
# ----------------------------------------------------------------------
def set_global_seeds(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available() and config.use_gpu:
        torch.cuda.manual_seed_all(seed)


# ----------------------------------------------------------------------
# Gym wrappers
# ----------------------------------------------------------------------
class ClipAction(gym.Wrapper):
    def __init__(self, env: gym.Env):
        super().__init__(env)

    def step(self, action):
        if isinstance(self.action_space, gym.spaces.Box):
            action = np.clip(action, self.action_space.low, self.action_space.high)
        return self.env.step(action)


class TimeStepEnv(gym.Wrapper):
    def __init__(self, env: gym.Env):
        super().__init__(env)
        self.t = 0

    def reset(self, **kwargs):
        obs, info = self.env.reset(**kwargs)
        self.t = 0
        return obs, info

    def step(self, action):
        obs, reward, terminated, truncated, info = self.env.step(action)
        self.t += 1
        info["t"] = self.t
        return obs, reward, terminated, truncated, info


def make_env(env_id: str, seed: int):
    env = gym.make(env_id)
    env = gym.wrappers.RecordEpisodeStatistics(env, deque_size=1)
    env.seed(seed)
    env.action_space.seed(seed)
    if config.clip_action and isinstance(env.action_space, gym.spaces.Box):
        env = ClipAction(env)
    env = TimeStepEnv(env)
    return env


# ----------------------------------------------------------------------
# Policy network
# ----------------------------------------------------------------------
class PolicyNet(nn.Module):
    def __init__(self, obs_dim: int, act_dim: int, hidden_dim: int = 64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, act_dim),
        )

    def forward(self, x: torch.Tensor):
        return self.net(x)


def to_param_vector(model: nn.Module) -> torch.Tensor:
    return torch.cat([p.view(-1) for p in model.parameters()])


def from_param_vector(model: nn.Module, vector: torch.Tensor):
    idx = 0
    for p in model.parameters():
        numel = p.numel()
        p.data.copy_(vector[idx : idx + numel].view_as(p))
        idx += numel


# ----------------------------------------------------------------------
# Episode runner
# ----------------------------------------------------------------------
def run_episode(env: gym.Env, agent: nn.Module, device: torch.device):
    obs, _ = env.reset()
    total_reward = 0.0
    steps = 0
    done = False
    while not done:
        obs_tensor = torch.tensor(obs, dtype=torch.float32, device=device)
        with torch.no_grad():
            action = agent(obs_tensor).cpu().numpy()
        obs, reward, terminated, truncated, _ = env.step(action)
        total_reward += reward
        steps += 1
        done = terminated or truncated
    return total_reward, steps


# ----------------------------------------------------------------------
# Fitness evaluation
# ----------------------------------------------------------------------
def fitness(param_vector: np.ndarray, env_id: str, seed: int) -> Tuple[float, float]:
    torch.set_num_threads(1)
    env = make_env(env_id, seed)
    obs_dim = env.observation_space.shape[0]
    act_dim = env.action_space.shape[0]
    agent = PolicyNet(obs_dim, act_dim)
    device = torch.device("cuda" if torch.cuda.is_available() and config.use_gpu else "cpu")
    agent.to(device)
    from_param_vector(agent, torch.tensor(param_vector, dtype=torch.float32))
    rewards = []
    lengths = []
    for _ in range(10):
        r, l = run_episode(env, agent, device)
        rewards.append(r)
        lengths.append(l)
    env.close()
    return float(np.mean(rewards)), float(np.mean(lengths))


# ----------------------------------------------------------------------
# ES optimizer (simple implementation)
# ----------------------------------------------------------------------
class OpenAIES:
    def __init__(self, dim: int, popsize: int, lr: float, sigma: float):
        self.dim = dim
        self.popsize = popsize
        self.lr = lr
        self.sigma = sigma
        self.mu = torch.zeros(dim)
        self.cov = torch.eye(dim)

    def ask(self) -> List[torch.Tensor]:
        eps = torch.randn(self.popsize, self.dim)
        return [self.mu + self.sigma * e for e in eps]

    def tell(self, rewards: List[float]):
        rewards = torch.tensor(rewards)
        idx = torch.argsort(rewards, descending=True)
        top_idx = idx[: self.popsize // 2]
        grads = torch.stack([e for e in self.ask()]) * rewards.view(-1, 1)
        grad_estimate = grads.mean(0)
        self.mu += self.lr * grad_estimate
        self.sigma *= 0.99


# ----------------------------------------------------------------------
# Training loop
# ----------------------------------------------------------------------
def run(seed: int):
    set_global_seeds(seed)
    output_path = Path(config.output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    best_fitness = -float("inf")
    best_params = None

    env_id = random.choice(config.envs)
    env = make_env(env_id, seed)
    obs_dim = env.observation_space.shape[0]
    act_dim = env.action_space.shape[0]
    dim = (obs_dim + act_dim) * 64  # rough estimate of parameters
    es = OpenAIES(dim, config.population_size, config.lr, config.sigma_schedule[0])

    pool = multiprocessing.Pool(processes=config.max_workers)

    for gen in range(1, config.generations + 1):
        start = time.time()
        candidates = es.ask()
        results = pool.map(
            lambda vec: fitness(vec.numpy(), env_id, seed),
            candidates,
            chunksize=config.worker_chunksize,
        )
        Rs, Hs = zip(*results)
        es.tell(Rs)

        fbest = max(Rs)
        if fbest > best_fitness:
            best_fitness = fbest
            best_params = candidates[np.argmax(Rs)]

        elapsed = time.time() - start
        print(
            f"Seed {seed} | Gen {gen}/{config.generations} | Time {elapsed:.2f}s | "
            f"Best Reward {best_fitness:.2f} | Avg Reward {np.mean(Rs):.2f} | Avg Steps {np.mean(Hs):.2f}"
        )

        if gen % config.checkpoint_every == 0:
            ckpt_path = output_path / f"checkpoint_{gen}.pt"
            torch.save(best_params, ckpt_path)

    pool.close()
    pool.join()


# ----------------------------------------------------------------------
# Experiment orchestration
# ----------------------------------------------------------------------
def run_experiment():
    seeds = [1770966829, 1500925526, 2054191100]
    with multiprocessing.Pool(processes=config.max_workers) as pool:
        pool.map(run, seeds)


if __name__ == "__main__":
    run_experiment()
