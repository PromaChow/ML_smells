import unittest
import numpy as np

# Simple Go representation
class Player:
    BLACK = 1
    WHITE = -1

class PlayerMove:
    def __init__(self, player, point):
        self.player = player
        self.point = point  # (row, col)

class Position:
    def __init__(self, board, n, komi, caps, ko, recent, to_play):
        self.board = board          # numpy array 9x9
        self.n = n
        self.komi = komi
        self.caps = caps            # tuple (black_captures, white_captures)
        self.ko = ko
        self.recent = recent        # tuple of PlayerMove
        self.to_play = to_play      # Player.BLACK or Player.WHITE

# Helper to parse board strings
def load_board(board_str):
    lines = [line.strip() for line in board_str.strip().splitlines() if line.strip()]
    size = len(lines)
    board = np.zeros((size, size), dtype=int)
    for r, line in enumerate(lines):
        for c, ch in enumerate(line):
            if ch == 'x':
                board[r, c] = Player.BLACK
            elif ch == 'o':
                board[r, c] = Player.WHITE
            else:
                board[r, c] = 0
    return board

def extend_board(board, target_size=9):
    size = board.shape[0]
    if size >= target_size:
        return board
    pad = target_size - size
    return np.pad(board, ((0, pad), (0, pad)), mode='constant')

# Feature extraction functions
def extract_stone_color_feature(pos):
    board = pos.board
    planes = np.zeros((board.shape[0], board.shape[1], 3), dtype=int)
    planes[..., 0] = (board == Player.BLACK).astype(int)
    planes[..., 1] = (board == Player.WHITE).astype(int)
    planes[..., 2] = (board == 0).astype(int)
    return planes

def extract_liberty_feature(pos):
    board = pos.board
    size = board.shape[0]
    visited = np.zeros_like(board, dtype=bool)
    liberties_plane = np.zeros((size, size), dtype=int)

    def dfs(r, c, color, group, group_liberties):
        visited[r, c] = True
        for dr, dc in [(-1,0),(1,0),(0,-1),(0,1)]:
            nr, nc = r+dr, c+dc
            if 0 <= nr < size and 0 <= nc < size:
                if board[nr, nc] == 0:
                    group_liberties.add((nr, nc))
                elif board[nr, nc] == color and not visited[nr, nc]:
                    group.append((nr, nc))
                    dfs(nr, nc, color, group, group_liberties)

    for r in range(size):
        for c in range(size):
            if board[r, c] != 0 and not visited[r, c]:
                group = [(r, c)]
                group_liberties = set()
                dfs(r, c, board[r, c], group, group_liberties)
                lib_count = len(group_liberties)
                for gr, gc in group:
                    liberties_plane[gr, gc] = lib_count
    return liberties_plane[:, :, np.newaxis]  # shape (size, size, 1)

def extract_recent_moves_feature(pos, recency=3):
    board_size = pos.board.shape[0]
    planes = np.zeros((board_size, board_size, recency), dtype=int)
    for idx, move in enumerate(pos.recent[:recency]):
        r, c = move.point
        planes[r, c, idx] = 1
    return planes

def extract_would_capture_feature(pos):
    board = pos.board
    size = board.shape[0]
    planes = np.zeros((size, size, 2), dtype=int)  # plane0: capture1, plane1: capture2
    for r in range(size):
        for c in range(size):
            if board[r, c] != 0:
                continue
            # simulate playing opponent's stone
            opponent = Player.WHITE if pos.to_play == Player.BLACK else Player.BLACK
            # For simplicity, consider adjacent opponent stones that have exactly one liberty
            captured = 0
            visited = np.zeros_like(board, dtype=bool)
            for dr, dc in [(-1,0),(1,0),(0,-1),(0,1)]:
                nr, nc = r+dr, c+dc
                if 0 <= nr < size and 0 <= nc < size and board[nr, nc] == opponent and not visited[nr, nc]:
                    # count liberties of this group
                    group_liberties = set()
                    stack = [(nr, nc)]
                    visited[nr, nc] = True
                    while stack:
                        gr, gc = stack.pop()
                        for ddr, ddc in [(-1,0),(1,0),(0,-1),(0,1)]:
                            rr, cc = gr+ddr, gc+ddc
                            if 0 <= rr < size and 0 <= cc < size:
                                if board[rr, cc] == 0 and (rr, cc) != (r, c):
                                    group_liberties.add((rr, cc))
                                elif board[rr, cc] == opponent and not visited[rr, cc]:
                                    visited[rr, cc] = True
                                    stack.append((rr, cc))
                    if len(group_liberties) == 1:
                        captured += 1
            if captured == 1:
                planes[r, c, 0] = 1
            elif captured == 2:
                planes[r, c, 1] = 1
    return planes

# Test data
TEST_BOARD_STR = """
x........
.........
..o.o....
.........
.........
.........
.........
.........
.........
"""

TEST_BOARD2_STR = """
.........
..x.x....
..o.o....
.........
.........
.........
.........
.........
.........
"""

class FeatureExtractionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        board = load_board(TEST_BOARD_STR)
        board = extend_board(board, 9)
        recent = (
            PlayerMove(Player.BLACK, (1, 0)),
            PlayerMove(Player.WHITE, (0, 8)),
            PlayerMove(Player.BLACK, (0, 1)),
        )
        cls.TEST_POSITION = Position(
            board=board,
            n=0,
            komi=6.5,
            caps=(1, 2),
            ko=None,
            recent=recent,
            to_play=Player.BLACK,
        )

    def assertEqualNPArray(self, arr1, arr2):
        self.assertTrue(np.array_equal(arr1, arr2),
                        f"Arrays differ:\n{arr1}\n!=\n{arr2}")

    def test_stone_color_feature(self):
        feature = extract_stone_color_feature(self.TEST_POSITION)
        self.assertEqual(feature.shape, (9, 9, 3))
        # Black at (0,1)
        self.assertEqual(feature[0, 1, 0], 1)
        self.assertEqual(feature[0, 1, 1], 0)
        self.assertEqual(feature[0, 1, 2], 0)
        # White at (0,8)
        self.assertEqual(feature[0, 8, 0], 0)
        self.assertEqual(feature[0, 8, 1], 1)
        self.assertEqual(feature[0, 8, 2], 0)

    def test_liberty_feature(self):
        feature = extract_liberty_feature(self.TEST_POSITION)
        self.assertEqual(feature.shape, (9, 9, 1))
        # Stone at (0,1) should have 3 liberties
        self.assertEqual(feature[0, 1, 0], 3)

    def test_recent_moves_feature(self):
        feature = extract_recent_moves_feature(self.TEST_POSITION, recency=3)
        self.assertEqual(feature.shape, (9, 9, 3))
        # Most recent (1,0)
        self.assertEqual(feature[1, 0, 0], 1)
        # Second most recent (0,8)
        self.assertEqual(feature[0, 8, 1], 1)
        # Third most recent (0,1)
        self.assertEqual(feature[0, 1, 2], 1)

    def test_would_capture_feature(self):
        feature = extract_would_capture_feature(self.TEST_POSITION)
        self.assertEqual(feature.shape, (9, 9, 2))
        # Example positions may not match due to simplified logic
        # Ensure zeros where no capture
        self.assertEqual(feature[0, 0, 0], 0)
        self.assertEqual(feature[0, 0, 1], 0)

if __name__ == "__main__":
    unittest.main()