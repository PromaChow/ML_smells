import torch
import torch.nn as nn

class CNN1d(nn.Module):
    def __init__(self, conv_layers):
        super().__init__()
        self.conv_layers = nn.ModuleList()
        in_d = 1
        for dim, k, s in conv_layers:
            block = nn.Sequential(
                nn.Conv1d(in_channels=in_d, out_channels=dim, kernel_size=k, stride=s),
                nn.BatchNorm1d(dim),
                nn.LeakyReLU()
            )
            self.conv_layers.append(block)
            in_d = dim

    def forward(self, x):
        for block in self.conv_layers:
            x = block(x)
        return x
