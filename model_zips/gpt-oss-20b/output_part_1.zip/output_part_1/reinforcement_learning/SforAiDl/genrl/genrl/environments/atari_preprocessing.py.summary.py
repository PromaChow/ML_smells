import gym
import numpy as np
import cv2


class AtariPreprocessing(gym.Wrapper):
    def __init__(self, env, frameskip=4, grayscale=True, screen_size=(84, 84)):
        super().__init__(env)
        self.frameskip = frameskip
        if isinstance(frameskip, int):
            self.frameskip = (frameskip, frameskip + 1)
        self.grayscale = grayscale
        self.screen_size = screen_size
        self.frames = [None, None]

        # Determine observation space
        if self.grayscale:
            shape = (self.screen_size[0], self.screen_size[1])
        else:
            shape = (self.screen_size[0], self.screen_size[1], 3)
        self.observation_space = gym.spaces.Box(low=0, high=255,
                                                shape=shape, dtype=np.uint8)

    def reset(self, **kwargs):
        obs, info = self.env.reset(**kwargs) if isinstance(self.env.reset(), tuple) else self.env.reset(**kwargs), {}
        self._get_screen(0)
        self.frames[1] = np.zeros_like(self.frames[0])
        return self._get_obs()

    def step(self, action):
        skip = np.random.randint(self.frameskip[0], self.frameskip[1] + 1)
        total_reward = 0.0
        done = False
        info = {}

        for i in range(skip):
            step_ret = self.env.step(action)
            if len(step_ret) == 5:
                _, reward, terminated, truncated, step_info = step_ret
                done = terminated or truncated
                info = step_info
            else:
                _, reward, done, info = step_ret

            total_reward += reward
            if done:
                break

            if i >= skip - 2:
                self._get_screen(i - (skip - 2))

        return self._get_obs(), total_reward, done, info

    def _get_screen(self, idx):
        screen = self.env.render(mode="rgb_array")
        if self.grayscale:
            gray = cv2.cvtColor(screen, cv2.COLOR_RGB2GRAY)
            self.frames[idx] = gray
        else:
            self.frames[idx] = screen

    def _get_obs(self):
        max_frame = np.maximum(self.frames[0], self.frames[1])
        resized = cv2.resize(max_frame, (self.screen_size[1], self.screen_size[0]),
                             interpolation=cv2.INTER_AREA)
        return resized.astype(np.uint8)
