import threading
import random
import bisect
from collections import defaultdict
from typing import List, Dict, Tuple, Any, Optional

import numpy as np
import torch


class RpcGroup:
    """
    Minimal RPC group implementation for demonstration purposes.
    In a real distributed setting, this would handle inter-process communication.
    """

    def __init__(self):
        self.services = {}
        self.name = "local"

    def register_service(self, name: str, func):
        self.services[name] = func

    def call(self, name: str, *args, **kwargs):
        return self.services[name](*args, **kwargs)

    def call_all(self, name: str, *args, **kwargs):
        results = []
        for svc in self.services.values():
            results.append(svc(*args, **kwargs))
        return results


class DistributedPrioritizedBuffer:
    def __init__(
        self,
        buffer_size: int,
        epsilon: float = 0.01,
        alpha: float = 0.6,
        beta: float = 0.4,
        rpc_group: Optional[RpcGroup] = None,
    ):
        self.buffer_size = buffer_size
        self.epsilon = epsilon
        self.alpha = alpha
        self.beta = beta
        self.rpc_group = rpc_group or RpcGroup()

        self.data: List[Optional[Dict[str, Any]]] = [None] * buffer_size
        self.priorities: List[float] = [0.0] * buffer_size
        self.versions: List[int] = [0] * buffer_size
        self.max_priority: float = 1.0
        self.ptr: int = 0
        self.size_: int = 0

        self.rw_lock = threading.RLock()
        self.version_table: Dict[int, int] = {}

        # Register RPC services
        self.rpc_group.register_service("_size_service", self._size_service)
        self.rpc_group.register_service("_clear_service", self._clear_service)
        self.rpc_group.register_service("_weight_sum_service", self._weight_sum_service)
        self.rpc_group.register_service("_update_priority_service", self._update_priority_service)
        self.rpc_group.register_service("_sample_service", self._sample_service)

    # -------------------------------------------------------------------------
    # Public API
    # -------------------------------------------------------------------------

    def store_episode(self, episodes: List[Dict[str, Any]], priorities: Optional[List[float]] = None):
        with self.rw_lock:
            n = len(episodes)
            if priorities is None:
                # Use current max priority
                priorities = [self.max_priority] * n
            else:
                if len(priorities) != n:
                    raise ValueError("Length of priorities must match episodes")
                priorities = [float(p) for p in priorities]

            # Normalize priorities
            priorities = [max(p, self.epsilon) for p in priorities]
            priorities = [p ** self.alpha for p in priorities]

            for i in range(n):
                idx = (self.ptr + i) % self.buffer_size
                self.data[idx] = episodes[i]
                self.priorities[idx] = priorities[i]
                self.versions[idx] += 1
                self.version_table[idx] = self.versions[idx]
                self.max_priority = max(self.max_priority, priorities[i])

            self.ptr = (self.ptr + n) % self.buffer_size
            self.size_ = min(self.size_ + n, self.buffer_size)

    def size(self) -> int:
        with self.rw_lock:
            return self.size_

    def all_size(self) -> int:
        sizes = self.rpc_group.call_all("_size_service")
        return sum(sizes)

    def clear(self):
        with self.rw_lock:
            self.data = [None] * self.buffer_size
            self.priorities = [0.0] * self.buffer_size
            self.versions = [0] * self.buffer_size
            self.version_table.clear()
            self.ptr = 0
            self.size_ = 0
            self.max_priority = 1.0

    def all_clear(self):
        self.rpc_group.call_all("_clear_service")

    def update_priority(
        self,
        indices: List[int],
        priorities: List[float],
        versions: List[int],
    ):
        if len(indices) != len(priorities) or len(indices) != len(versions):
            raise ValueError("indices, priorities, and versions must have same length")

        # Split indices by process
        # For demonstration, assume all indices belong to local buffer
        payload = {
            "indices": indices,
            "priorities": priorities,
            "versions": versions,
        }
        self.rpc_group.call_all("_update_priority_service", payload)

    def sample_batch(self, batch_size: int) -> Tuple[int, Dict[str, Any], Dict[str, List[Tuple[int, int]]], List[float]]:
        with self.rw_lock:
            local_weight_sum = sum(self.priorities[:self.size_])
        # Get global weight sum
        weight_sums = self.rpc_group.call_all("_weight_sum_service")
        global_weight_sum = sum(weight_sums)

        # Determine local sample size
        local_fraction = local_weight_sum / global_weight_sum if global_weight_sum > 0 else 0
        local_batch_size = max(1, int(round(batch_size * local_fraction)))
        if local_batch_size > batch_size:
            local_batch_size = batch_size

        # Request samples from all processes
        samples = self.rpc_group.call_all(
            "_sample_service",
            local_batch_size,
            global_weight_sum,
            self.beta,
        )

        total_samples = 0
        batch_dict: Dict[str, List[Any]] = defaultdict(list)
        index_version_map: Dict[str, List[Tuple[int, int]]] = {}
        importance_weights: List[float] = []

        for proc_name, sample in zip(self.rpc_group.services.keys(), samples):
            indices = sample["indices"]
            versions = sample["versions"]
            transitions = sample["transitions"]
            weights = sample["weights"]

            n = len(transitions)
            total_samples += n
            index_version_map[proc_name] = list(zip(indices, versions))
            importance_weights.extend(weights)

            for t in transitions:
                for k, v in t.items():
                    batch_dict[k].append(v)

        # Post-process batch
        processed_batch = self.post_process_batch(batch_dict)

        return total_samples, processed_batch, index_version_map, importance_weights

    # -------------------------------------------------------------------------
    # RPC Services
    # -------------------------------------------------------------------------

    def _size_service(self) -> int:
        with self.rw_lock:
            return self.size_

    def _clear_service(self):
        with self.rw_lock:
            self.clear()

    def _weight_sum_service(self) -> float:
        with self.rw_lock:
            return sum(self.priorities[:self.size_])

    def _update_priority_service(self, payload: Dict[str, List[Any]]):
        indices = payload["indices"]
        new_priorities = payload["priorities"]
        provided_versions = payload["versions"]

        with self.rw_lock:
            for idx, prio, ver in zip(indices, new_priorities, provided_versions):
                if 0 <= idx < self.size_ and self.versions[idx] == ver:
                    prio = max(prio, self.epsilon)
                    prio = prio ** self.alpha
                    self.priorities[idx] = prio
                    self.versions[idx] += 1
                    self.version_table[idx] = self.versions[idx]
                    self.max_priority = max(self.max_priority, prio)

    def _sample_service(self, local_batch_size: int, global_weight_sum: float, beta: float):
        with self.rw_lock:
            local_weight_sum = sum(self.priorities[:self.size_])
            if local_weight_sum == 0 or local_batch_size == 0:
                return {
                    "indices": [],
                    "versions": [],
                    "transitions": [],
                    "weights": [],
                }

            cumulative = np.cumsum(self.priorities[:self.size_])
            indices = []
            versions = []
            transitions = []
            weights = []

            for _ in range(local_batch_size):
                r = random.uniform(0, local_weight_sum)
                idx = bisect.bisect_left(cumulative, r)
                indices.append(idx)
                versions.append(self.versions[idx])
                transitions.append(self.data[idx])
                # Importance weight
                prob = self.priorities[idx] / local_weight_sum
                weight = (1.0 / (self.size_ * prob)) ** beta
                weights.append(weight)

            return {
                "indices": indices,
                "versions": versions,
                "transitions": transitions,
                "weights": weights,
            }

    # -------------------------------------------------------------------------
    # Utility Methods
    # -------------------------------------------------------------------------

    def post_process_batch(self, batch_dict: Dict[str, List[Any]]) -> Dict[str, Any]:
        result = {}
        std_keys = {"state", "action", "next_state", "reward"}
        for k, v_list in batch_dict.items():
            if k in std_keys:
                result[k] = torch.cat([torch.as_tensor(v) for v in v_list], dim=0)
            else:
                result[k] = v_list
        return result
