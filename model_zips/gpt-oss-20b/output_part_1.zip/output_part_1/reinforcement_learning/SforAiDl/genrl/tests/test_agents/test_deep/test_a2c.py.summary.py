import shutil
import os
from genrl.env import VectorEnv, make_env
from genrl.algorithms import A2C
from genrl.trainers import OnPolicyTrainer


def run_test(name, env_name, network_type, shared_layers=None):
    print(f"Running test: {name}")
    # Environment setup
    if env_name == "Pong-v0":
        env = VectorEnv([make_env(env_name, env_type="atari")])
    else:
        env = VectorEnv([make_env(env_name)])
    # Algorithm setup
    if shared_layers:
        algo = A2C(network_type=network_type, rollout_size=128, shared_layers=shared_layers)
    else:
        algo = A2C(network_type=network_type, rollout_size=128)
    # Trainer setup
    trainer = OnPolicyTrainer(
        algo,
        env,
        log_mode="csv",
        log_dir="./logs",
        epochs=1,
    )
    # Training and evaluation
    trainer.train()
    trainer.evaluate()
    # Cleanup
    if os.path.isdir("./logs"):
        shutil.rmtree("./logs")
    print(f"Test {name} completed.\n")


if __name__ == "__main__":
    # Test 1: CartPole-v0 with MLP
    run_test(
        name="CartPole_MLP",
        env_name="CartPole-v0",
        network_type="mlp",
    )
    # Test 2: CartPole-v0 with CNN
    run_test(
        name="CartPole_CNN",
        env_name="CartPole-v0",
        network_type="cnn",
    )
    # Test 3: Pendulum-v0 with MLP and shared layers
    run_test(
        name="Pendulum_MLP_Shared",
        env_name="Pendulum-v0",
        network_type="mlp",
        shared_layers=[32, 32],
    )
    # Test 4: Pong-v0 with CNN (atari environment)
    run_test(
        name="Pong_CNN",
        env_name="Pong-v0",
        network_type="cnn",
    )