import numpy as np

class OrthogonalInitializer:
    def __init__(self, scale=1.0, dtype=np.float32, mode='auto', backend='numpy'):
        self.scale = scale
        self.dtype = dtype
        self.mode = mode.lower()
        if backend == 'cupy':
            try:
                import cupy as xp
            except ImportError as e:
                raise ImportError("CuPy is not installed") from e
            self.xp = xp
        else:
            self.xp = np

    def __call__(self, array):
        xp = self.xp
        shape = array.shape
        if array.ndim == 0:
            val = xp.random.choice([-1, 1]) * self.scale
            array[...] = val
            return

        out_dim = shape[0]
        in_dim = int(xp.prod(shape[1:])) if len(shape) > 1 else 1

        if out_dim > in_dim:
            msg = f"out_dim ({out_dim}) > in_dim ({in_dim})"
            if self.mode == 'auto':
                raise ValueError(f"{msg} for mode 'auto'")
            elif self.mode == 'embedding':
                raise ValueError(f"{msg} for mode 'embedding'")
            elif self.mode == 'projection':
                raise ValueError(f"{msg} for mode 'projection'")
            elif self.mode == 'basis':
                raise ValueError(f"{msg} for mode 'basis'")
            else:
                raise ValueError(f"{msg} for unsupported mode '{self.mode}'")

        mat = xp.random.randn(out_dim, in_dim)
        transposed = False
        if in_dim > out_dim:
            mat = mat.T
            out_dim, in_dim = in_dim, out_dim
            transposed = True

        q, r = xp.linalg.qr(mat)
        d = xp.sign(xp.diag(r))
        q *= d
        q *= self.scale

        if transposed:
            q = q.T

        q = q.reshape(shape)
        array[:] = q.astype(self.dtype, copy=False)