import os
import glob
import shutil
import unittest
import numpy as np
import numpy.testing as npt

# Attempt to import AlphaGo components; fall back to mock implementations if unavailable
try:
    from AlphaGo.cnn_policy import CNNPolicy
    from AlphaGo.losses import log_loss
    from AlphaGo.run import run_n_games
except ImportError:  # pragma: no cover
    class CNNPolicy:
        def __init__(self, weights=None):
            if weights is None:
                self.weights = np.random.randn(10)
            else:
                self.weights = np.array(weights, dtype=float)

        def load_weights(self, path):
            # Dummy load: read weights from a text file
            if os.path.exists(path):
                self.weights = np.loadtxt(path)

        def save_weights(self, path):
            np.savetxt(path, self.weights)

        def predict(self, board):
            # Simple softmax over weights
            z = np.dot(board, self.weights)
            exp_z = np.exp(z - np.max(z))
            return exp_z / exp_z.sum()

        def train_on_state(self, state):
            # Dummy training: adjust weights toward winner
            grad = np.random.randn(*self.weights.shape) * 0.01
            if state.winner == 1:  # Black wins
                self.weights += grad
            else:
                self.weights -= grad

    def log_loss(y_true, y_pred):
        return -np.sum(y_true * np.log(y_pred + 1e-9)) / len(y_true)

    def run_n_games(policies, states, optimizer, n=1):
        for _ in range(n):
            for state in states:
                policies[0].train_on_state(state)


# Helper constants
SGF_FOLDER = "./sgf"

# Helper functions
def _is_sgf(file_path):
    return file_path.lower().endswith(".sgf")

def _list_mock_games(directory):
    return [f for f in os.listdir(directory) if _is_sgf(f)]

def get_sgf_move_probs(sgf_file, policy):
    # Dummy implementation: return random probabilities for each move in the SGF
    with open(os.path.join(SGF_FOLDER, sgf_file), "r") as f:
        moves = [line.strip() for line in f if line.strip()]
    probs = np.random.rand(len(moves), len(policy.weights))
    probs /= probs.sum(axis=1, keepdims=True)
    return probs

class MockPlayer:
    def __init__(self, moves, winner):
        self.moves = moves
        self.winner = winner
        self.index = 0

    def get_move(self, board):
        if self.index < len(self.moves):
            move = self.moves[self.index]
            self.index += 1
            return move
        return None

class MockState:
    def __init__(self, moves, winner):
        self.moves = moves
        self.winner = winner
        self.index = 0
        self.done = False

    def get_board(self):
        # Dummy board representation: vector of zeros with one-hot at current move index
        board = np.zeros(10)
        if self.index < len(self.moves):
            board[self.index] = 1
        return board

    def step(self):
        self.index += 1
        if self.index >= len(self.moves):
            self.done = True

    def is_terminal(self):
        return self.done

    def get_winner(self):
        return self.winner


class TestAlphaGoTraining(unittest.TestCase):
    def setUp(self):
        # Create SGF folder if it doesn't exist
        os.makedirs(SGF_FOLDER, exist_ok=True)
        # Create a dummy SGF file for testing
        sgf_path = os.path.join(SGF_FOLDER, "dummy.sgf")
        with open(sgf_path, "w") as f:
            for i in range(5):
                f.write(f"Move{i}\n")

    def tearDown(self):
        # Clean up SGF folder
        shutil.rmtree(SGF_FOLDER, ignore_errors=True)
        # Remove any generated weight files
        for file in glob.glob("*.hdf5") + glob.glob("metadata.json"):
            try:
                os.remove(file)
            except OSError:
                pass

    def testTrain(self):
        policy = CNNPolicy()
        policy.save_weights("initial_weights.hdf5")
        policy.load_weights("initial_weights.hdf5")

        # Dummy training parameters
        game_batch = 2
        iterations = 1

        # Simulate training loop
        for _ in range(iterations):
            for _ in range(game_batch):
                state = MockState(moves=[1, 2, 3], winner=1)
                policy.train_on_state(state)

        # Save final weights
        policy.save_weights("final_weights.hdf5")
        # Verify file creation
        self.assertTrue(os.path.exists("final_weights.hdf5"))

        # Clean up
        os.remove("initial_weights.hdf5")
        os.remove("final_weights.hdf5")

    def testGradientDirectionChangesWithGameResult(self):
        # Initial weights
        initial_weights = np.random.randn(10)

        # Policy 1: Black wins
        policy1 = CNNPolicy(weights=initial_weights.copy())
        state_black = MockState(moves=[1, 2, 3], winner=1)
        policy1.train_on_state(state_black)

        # Policy 2: White wins
        policy2 = CNNPolicy(weights=initial_weights.copy())
        state_white = MockState(moves=[1, 2, 3], winner=0)
        policy2.train_on_state(state_white)

        diff1 = policy1.weights - initial_weights
        diff2 = initial_weights - policy2.weights

        npt.assert_allclose(diff1, diff2, rtol=1e-3, atol=1e-3)

    def testRunNGamesUpdatesWeights(self):
        policy = CNNPolicy()
        initial_weights = policy.weights.copy()
        states = [MockState(moves=[1, 2, 3], winner=1) for _ in range(3)]
        run_n_games([policy], states, optimizer=None, n=2)
        self.assertFalse(np.array_equal(initial_weights, policy.weights))

    def testWinIncreasesMoveProbability(self):
        policy = CNNPolicy()
        sgf_file = "dummy.sgf"

        probs_before = get_sgf_move_probs(sgf_file, policy)
        avg_before = probs_before[:, 0].mean()

        # Simulate training on a win
        state = MockState(moves=[1, 2, 3], winner=1)
        policy.train_on_state(state)

        probs_after = get_sgf_move_probs(sgf_file, policy)
        avg_after = probs_after[:, 0].mean()

        self.assertGreater(avg_after, avg_before)

    def testLoseDecreasesMoveProbability(self):
        policy = CNNPolicy()
        sgf_file = "dummy.sgf"

        probs_before = get_sgf_move_probs(sgf_file, policy)
        avg_before = probs_before[:, 0].mean()

        # Simulate training on a loss
        state = MockState(moves=[1, 2, 3], winner=0)
        policy.train_on_state(state)

        probs_after = get_sgf_move_probs(sgf_file, policy)
        avg_after = probs_after[:, 0].mean()

        self.assertLess(avg_after, avg_before)

if __name__ == "__main__":
    unittest.main()