import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from sklearn import neighbors, datasets

# Parameters
n_neighbors = 15

# Load data
iris = datasets.load_iris()
X = iris.data[:, :2]
y = iris.target

# Meshgrid resolution
h = 0.02

# Colormaps
cmap_light = ListedColormap(['#FFBBBB', '#BBFFBB', '#BBBBFF'])
cmap_bold = ListedColormap(['#FF0000', '#00FF00', '#0000FF'])

# Weight types to explore
weight_types = ['uniform', 'distance']

for w in weight_types:
    # Train classifier
    clf = neighbors.KNeighborsClassifier(n_neighbors=n_neighbors, weights=w)
    clf.fit(X, y)

    # Create meshgrid
    x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
                         np.arange(y_min, y_max, h))

    # Predict over meshgrid
    Z = clf.predict(np.c_[xx.ravel(), yy.ravel()])
    Z = Z.reshape(xx.shape)

    # Plot decision boundaries
    plt.figure()
    plt.pcolormesh(xx, yy, Z, cmap=cmap_light)

    # Plot training points
    plt.scatter(X[:, 0], X[:, 1], c=y, cmap=cmap_bold,
                edgecolor='k', s=20)

    # Axis limits
    plt.xlim(xx.min(), xx.max())
    plt.ylim(yy.min(), yy.max())

    # Title
    plt.title(f"KNN with k={n_neighbors}, weights={w}")

    # Labels
    plt.xlabel(iris.feature_names[0])
    plt.ylabel(iris.feature_names[1])

plt.show()
