import argparse
import os
import random
import csv
import time
import numpy as np
import tensorflow.compat.v1 as tf
from tensorflow.keras.datasets import cifar10

tf.disable_eager_execution()
tf.logging.set_verbosity(tf.logging.INFO)

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--batch_size', type=int, default=64, help='Batch size')
    parser.add_argument('--labeled_samples', type=int, default=4000, help='Number of labeled samples')
    parser.add_argument('--epochs', type=int, default=200, help='Number of epochs')
    parser.add_argument('--output_dir', type=str, default='output', help='Output directory')
    parser.add_argument('--learning_rate', type=float, default=0.03, help='Initial learning rate')
    parser.add_argument('--threshold', type=float, default=0.95, help='Confidence threshold for pseudo-labels')
    parser.add_argument('--ema_decay', type=float, default=0.9999, help='EMA decay')
    args = parser.parse_args()
    return args

def set_seeds(seed=1234):
    random.seed(seed)
    np.random.seed(seed)
    tf.set_random_seed(seed)

def configure_gpu():
    gpus = tf.config.experimental.list_physical_devices('GPU')
    if gpus:
        try:
            for gpu in gpus:
                tf.config.experimental.set_memory_growth(gpu, True)
        except RuntimeError:
            pass

def prepare_dirs(base_dir):
    checkpoints = os.path.join(base_dir, 'checkpoints')
    logs = os.path.join(base_dir, 'logs')
    csv_dir = os.path.join(base_dir, 'csv')
    for d in [checkpoints, logs, csv_dir]:
        os.makedirs(d, exist_ok=True)
    return checkpoints, logs, csv_dir

def load_cifar10():
    (x_train, y_train), (x_test, y_test) = cifar10.load_data()
    x_train = x_train.astype(np.float32) / 255.0
    y_train = y_train.squeeze()
    x_test = x_test.astype(np.float32) / 255.0
    y_test = y_test.squeeze()
    return x_train, y_train, x_test, y_test

def split_labeled_unlabeled(x_train, y_train, labeled_samples):
    indices = np.arange(len(x_train))
    np.random.shuffle(indices)
    labeled_idx = indices[:labeled_samples]
    unlabeled_idx = indices[labeled_samples:]
    x_labeled = x_train[labeled_idx]
    y_labeled = y_train[labeled_idx]
    x_unlabeled = x_train[unlabeled_idx]
    y_unlabeled = y_train[unlabeled_idx]  # labels not used
    return x_labeled, y_labeled, x_unlabeled, y_unlabeled

def weak_augmentation(image):
    image = tf.image.random_flip_left_right(image)
    image = tf.image.random_crop(image, size=[32, 32, 3])
    return image

def strong_augmentation(image):
    image = tf.image.random_flip_left_right(image)
    image = tf.image.random_crop(image, size=[32, 32, 3])
    # Simple RandAugment: random brightness, contrast, saturation
    image = tf.image.random_brightness(image, max_delta=0.4)
    image = tf.image.random_contrast(image, lower=0.8, upper=1.2)
    image = tf.image.random_saturation(image, lower=0.8, upper=1.2)
    return image

def build_dataset(x, y, batch_size, augment_fn, shuffle=True, repeat=True):
    dataset = tf.data.Dataset.from_tensor_slices((x, y))
    if shuffle:
        dataset = dataset.shuffle(buffer_size=10000)
    dataset = dataset.map(lambda img, lbl: (augment_fn(img), lbl), num_parallel_calls=tf.data.AUTOTUNE)
    dataset = dataset.batch(batch_size)
    if repeat:
        dataset = dataset.repeat()
    dataset = dataset.prefetch(tf.data.AUTOTUNE)
    return dataset

def build_unlabeled_dataset(x, batch_size, weak_fn, strong_fn):
    dataset = tf.data.Dataset.from_tensor_slices(x)
    def aug(img):
        weak = weak_fn(img)
        strong = strong_fn(img)
        return weak, strong
    dataset = dataset.map(aug, num_parallel_calls=tf.data.AUTOTUNE)
    dataset = dataset.batch(batch_size)
    dataset = dataset.repeat()
    dataset = dataset.prefetch(tf.data.AUTOTUNE)
    return dataset

def cnn_classifier(inputs, is_training, reuse=False):
    with tf.variable_scope('cnn', reuse=reuse):
        net = tf.layers.conv2d(inputs, 64, 3, padding='same', activation=tf.nn.relu, name='conv1')
        net = tf.layers.batch_normalization(net, training=is_training, name='bn1')
        net = tf.layers.max_pooling2d(net, 2, 2, name='pool1')
        net = tf.layers.conv2d(net, 128, 3, padding='same', activation=tf.nn.relu, name='conv2')
        net = tf.layers.batch_normalization(net, training=is_training, name='bn2')
        net = tf.layers.max_pooling2d(net, 2, 2, name='pool2')
        net = tf.layers.flatten(net, name='flatten')
        net = tf.layers.dense(net, 256, activation=tf.nn.relu, name='fc1')
        net = tf.layers.batch_normalization(net, training=is_training, name='bn3')
        logits = tf.layers.dense(net, 10, name='logits')
    return logits

def create_summary(tensor, name):
    tf.summary.scalar(name, tensor)

def main():
    args = parse_args()
    set_seeds()
    configure_gpu()

    checkpoints_dir, logs_dir, csv_dir = prepare_dirs(args.output_dir)

    x_train, y_train, x_test, y_test = load_cifar10()
    x_labeled, y_labeled, x_unlabeled, _ = split_labeled_unlabeled(x_train, y_train, args.labeled_samples)

    tf.logging.info(f'Labeled samples: {len(x_labeled)}')
    tf.logging.info(f'Unlabeled samples: {len(x_unlabeled)}')
    tf.logging.info(f'Test samples: {len(x_test)}')

    # Placeholders for feeding data
    labeled_input = tf.placeholder(tf.float32, [args.batch_size, 32, 32, 3], name='labeled_input')
    labeled_label = tf.placeholder(tf.int32, [args.batch_size], name='labeled_label')
    unlabeled_weak = tf.placeholder(tf.float32, [args.batch_size, 32, 32, 3], name='unlabeled_weak')
    unlabeled_strong = tf.placeholder(tf.float32, [args.batch_size, 32, 32, 3], name='unlabeled_strong')

    is_training = tf.placeholder(tf.bool, name='is_training')

    # Model forward
    logits_labeled = cnn_classifier(labeled_input, is_training, reuse=False)
    logits_unlabeled_strong = cnn_classifier(unlabeled_strong, is_training, reuse=True)

    # Losses
    ce_loss = tf.reduce_mean(tf.nn.sparse_softmax_cross_entropy_with_logits(labels=labeled_label, logits=logits_labeled))
    probs_unlabeled = tf.nn.softmax(logits_unlabeled_strong)
    max_probs = tf.reduce_max(probs_unlabeled, axis=1)
    pseudo_labels = tf.argmax(probs_unlabeled, axis=1, output_type=tf.int32)
    mask = tf.cast(max_probs >= args.threshold, tf.float32)
    ce_loss_unlabeled = tf.reduce_mean(tf.nn.sparse_softmax_cross_entropy_with_logits(labels=pseudo_labels, logits=logits_unlabeled_strong))
    loss = ce_loss + mask * ce_loss_unlabeled

    # L2 regularization
    l2 = tf.add_n([tf.nn.l2_loss(v) for v in tf.trainable_variables()]) * 1e-4
    total_loss = loss + l2

    # Learning rate schedule
    global_step = tf.Variable(0, trainable=False, name='global_step')
    steps_per_epoch = len(x_labeled) // args.batch_size
    total_steps = steps_per_epoch * args.epochs
    lr = tf.train.cosine_decay(args.learning_rate, global_step, total_steps)

    optimizer = tf.train.MomentumOptimizer(lr, momentum=0.9)
    train_op = optimizer.minimize(total_loss, global_step=global_step)

    # EMA
    ema = tf.train.ExponentialMovingAverage(args.ema_decay, global_step)
    ema_op = ema.apply(tf.trainable_variables())

    with tf.control_dependencies([train_op, ema_op]):
        train_op = tf.no_op(name='train')

    # Evaluation ops
    logits_test = cnn_classifier(tf.placeholder(tf.float32, [None, 32, 32, 3], name='test_input'), is_training=False, reuse=True)
    preds_test = tf.argmax(logits_test, axis=1)
    correct = tf.equal(preds_test, tf.placeholder(tf.int32, [None], name='test_label'))
    acc = tf.reduce_mean(tf.cast(correct, tf.float32))

    # Summaries
    create_summary(total_loss, 'total_loss')
    create_summary(ce_loss, 'labeled_loss')
    create_summary(ce_loss_unlabeled, 'unlabeled_loss')
    create_summary(lr, 'learning_rate')
    create_summary(mask, 'pseudo_mask_ratio')

    merged_summary = tf.summary.merge_all()
    writer = tf.summary.FileWriter(os.path.join(logs_dir, 'train'), tf.get_default_graph())
    summary_writer = tf.summary.FileWriter(os.path.join(logs_dir, 'eval'), tf.get_default_graph())

    saver = tf.train.Saver(max_to_keep=5)

    # CSV logger
    csv_path = os.path.join(csv_dir, 'training_log.csv')
    csv_file = open(csv_path, 'w', newline='')
    csv_writer = csv.writer(csv_file)
    csv_writer.writerow(['step', 'total_loss', 'labeled_loss', 'unlabeled_loss', 'learning_rate', 'pseudo_mask_ratio', 'train_accuracy', 'val_accuracy', 'test_accuracy'])

    with tf.Session() as sess:
        sess.run(tf.global_variables_initializer())
        coord = tf.train.Coordinator()
        threads = tf.train.start_queue_runners(coord=coord)

        best_val_acc = 0.0
        for epoch in range(args.epochs):
            for _ in range(steps_per_epoch):
                batch_labeled = sess.run(build_dataset(x_labeled, y_labeled, args.batch_size, weak_augmentation))
                batch_unlabeled = sess.run(build_unlabeled_dataset(x_unlabeled, args.batch_size, weak_augmentation, strong_augmentation))
                feed_dict = {
                    labeled_input: batch_labeled[0],
                    labeled_label: batch_labeled[1],
                    unlabeled_weak: batch_unlabeled[0],
                    unlabeled_strong: batch_unlabeled[1],
                    is_training: True
                }
                _, loss_val, step, summary = sess.run([train_op, total_loss, global_step, merged_summary], feed_dict=feed_dict)
                writer.add_summary(summary, step)

                if step % 100 == 0:
                    acc_val = sess.run(acc, feed_dict={
                        'test_input:0': x_test[:args.batch_size],
                        'test_label:0': y_test[:args.batch_size]
                    })
                    csv_writer.writerow([step, loss_val, ce_loss_val, ce_loss_unlabeled_val, sess.run(lr), sess.run(mask), acc_val, 0, 0])

            # Validation
            val_acc = sess.run(acc, feed_dict={
                'test_input:0': x_test[:args.batch_size],
                'test_label:0': y_test[:args.batch_size]
            })
            test_acc = sess.run(acc, feed_dict={
                'test_input:0': x_test,
                'test_label:0': y_test
            })
            csv_writer.writerow([global_step.eval(), loss_val, ce_loss_val, ce_loss_unlabeled_val, sess.run(lr), sess.run(mask), 0, val_acc, test_acc])
            if val_acc > best_val_acc:
                best_val_acc = val_acc
                saver.save(sess, os.path.join(checkpoints_dir, 'best_model.ckpt'), global_step=global_step)

        # Final checkpoint
        saver.save(sess, os.path.join(checkpoints_dir, 'final_model.ckpt'), global_step=global_step)
        csv_file.close()
        coord.request_stop()
        coord.join(threads)

if __name__ == '__main__':
    main()
