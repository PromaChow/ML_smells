import numpy as np


class GameState:
    def __init__(self, board=None, player_turn=1):
        self.board = np.zeros(42, dtype=int) if board is None else board.copy()
        self.player_turn = player_turn
        self.win_patterns = self._generate_win_patterns()

    @staticmethod
    def _generate_win_patterns():
        patterns = []
        # horizontal
        for r in range(6):
            for c in range(4):
                patterns.append(
                    [r * 7 + c + i for i in range(4)]
                )
        # vertical
        for r in range(3):
            for c in range(7):
                patterns.append(
                    [ (r + i) * 7 + c for i in range(4) ]
                )
        # diagonal /
        for r in range(3, 6):
            for c in range(4):
                patterns.append(
                    [ (r - i) * 7 + c + i for i in range(4) ]
                )
        # diagonal \
        for r in range(3):
            for c in range(4):
                patterns.append(
                    [ (r + i) * 7 + c + i for i in range(4) ]
                )
        return patterns

    def take_action(self, action):
        """Apply action for current player. Returns new board, reward, done."""
        # Find lowest empty spot in column
        col = action
        for row in reversed(range(6)):
            idx = row * 7 + col
            if self.board[idx] == 0:
                break
        else:
            raise ValueError("Column is full")

        new_board = self.board.copy()
        new_board[idx] = self.player_turn

        # Check win
        win = any(
            all(new_board[pos] == self.player_turn for pos in pattern)
            for pattern in self.win_patterns
        )
        if win:
            return new_board, 1, True

        # Check draw
        if not new_board.any():
            return new_board, 0, True

        return new_board, 0, False

    def _allowed_actions(self):
        """Return list of columns where top cell is empty."""
        return [c for c in range(7) if self.board[c] == 0]

    def _binary(self):
        """Return binary representation of current board for current player."""
        current = (self.board == self.player_turn).astype(int)
        opponent = (self.board == -self.player_turn).astype(int)
        return np.concatenate([current, opponent])

    def _convert_state_to_id(self):
        """Return string ID of the state for current player."""
        return ''.join(self._binary().astype(str))


class Game:
    def __init__(self):
        self.current_player = 1
        self.state = GameState()
        self.action_space = list(range(7))
        self.grid_shape = (6, 7)
        self.state_size = 42
        self.action_size = 7

    def reset(self):
        self.state = GameState()
        self.current_player = 1
        return self.state._binary()

    def step(self, action):
        new_board, reward, done = self.state.take_action(action)
        self.state.board = new_board
        self.current_player = -self.current_player
        self.state.player_turn = self.current_player
        return self.state._binary(), reward, done, {}

    def identities(self):
        """Return list of state representations with vertical symmetry."""
        original = self.state._binary()
        board = self.state.board.reshape(self.grid_shape)
        flipped_board = np.fliplr(board).flatten()
        flipped_state = GameState(board=flipped_board, player_turn=self.state.player_turn)
        return [original, flipped_state._binary()]

    def render(self):
        pieces = {1: 'X', -1: 'O', 0: '-'}
        board = self.state.board.reshape(self.grid_shape)
        print("\n".join(' '.join(pieces[cell] for cell in row) for row in board))
        print(f"Current player: {'X' if self.current_player == 1 else 'O'}")