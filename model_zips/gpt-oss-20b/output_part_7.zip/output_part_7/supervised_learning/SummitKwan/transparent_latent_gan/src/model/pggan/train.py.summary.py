import os
import time
import math
import numpy as np
import tensorflow as tf
from pathlib import Path

# --------- Configuration ---------
class Config:
    # General settings
    batch_size_base = 16
    learning_rate_base = 0.001
    training_images_per_k = 1000  # number of images processed per thousand images
    snapshot_interval_k = 500  # snapshot every 500k images
    image_base_resolution = 4  # starting resolution 4x4
    max_resolution = 64  # maximum resolution 64x64 (for demonstration)
    latent_dim = 512
    device = "/gpu:0"
    log_dir = "logs"
    snapshot_dir = "snapshots"
    data_dir = "data"

    # LOD settings
    lod_fade_samples = 8000  # number of samples over which to fade LOD
    minibatch_factor = 2  # minibatch factor for higher resolutions

    # Network architecture
    gen_layers = 8
    disc_layers = 8


config = Config()


# --------- Dataset ---------
def load_dataset(path, image_size):
    """
    Loads images from directory, resizes them to image_size and returns a tf.data.Dataset.
    """
    def _load_image(file_path):
        img = tf.io.read_file(file_path)
        img = tf.image.decode_jpeg(img, channels=3)
        img = tf.image.resize(img, [image_size, image_size])
        img = tf.cast(img, tf.float32) / 255.0
        return img

    dataset = tf.data.Dataset.list_files(os.path.join(path, "*.jpg"))
    dataset = dataset.map(_load_image, num_parallel_calls=tf.data.AUTOTUNE)
    dataset = dataset.batch(config.batch_size_base, drop_remainder=True)
    dataset = dataset.prefetch(tf.data.AUTOTUNE)
    return dataset


# --------- Snapshot Grid Setup ---------
def calculate_grid_dims(target_resolution, num_classes=10, row_per_class=False):
    """
    Calculates grid dimensions for snapshot based on target resolution and layout.
    """
    if row_per_class:
        rows = num_classes
        cols = target_resolution // 2
    else:
        side = int(math.sqrt(target_resolution))
        rows = cols = side
    return rows, cols


def build_snapshot_grid(images, labels=None, layout="row_per_class"):
    """
    Builds a grid of images for visualization.
    """
    batch, h, w, c = images.shape
    rows, cols = calculate_grid_dims(batch, row_per_class=(layout=="row_per_class"))
    grid = tf.reshape(images, (rows, cols, h, w, c))
    grid = tf.transpose(grid, [0, 2, 1, 3, 4])  # rows, h, cols, w, c
    grid = tf.reshape(grid, (rows * h, cols * w, c))
    return grid


def generate_latent_vectors(batch_size, latent_dim):
    return tf.random.normal([batch_size, latent_dim])


# --------- Image Preprocessing ---------
def preprocess_image(img, flip=True, lod=0.0):
    """
    Applies dynamic range, mirror flip, LOD fade, and upscaling.
    """
    # Dynamic range adjustment to [-1, 1]
    img = img * 2.0 - 1.0

    if flip and tf.random.uniform([]) < 0.5:
        img = tf.image.flip_left_right(img)

    # LOD fade (simple linear interpolation)
    lower_res = 2 ** int(math.floor(lod))
    upper_res = 2 ** int(math.ceil(lod))
    if lower_res != upper_res:
        weight = lod - math.floor(lod)
        img_low = tf.image.resize(img, [lower_res, lower_res])
        img_high = tf.image.resize(img, [upper_res, upper_res])
        img = (1 - weight) * img_low + weight * img_high

    return img


# --------- Training Schedule Management ---------
def compute_training_parameters(iteration):
    """
    Computes current LOD, resolution, minibatch size, learning rate.
    """
    # Each resolution level covers 1 million images (for demonstration)
    images_per_level = config.training_images_per_k * 1000
    level = iteration * config.batch_size_base // images_per_level
    resolution = min(config.image_base_resolution * (2 ** level), config.max_resolution)

    # LOD calculation
    lod = max(0, level - iteration * config.batch_size_base / images_per_level)
    lod = min(lod, math.log2(resolution) - math.log2(config.image_base_resolution))

    # Minibatch size scaling
    minibatch = config.batch_size_base * (2 ** level)

    # Learning rate scaling
    lr = config.learning_rate_base / (2 ** level)

    return lod, resolution, minibatch, lr


# --------- Network Construction ---------
def build_generator(latent_dim, resolution):
    """
    Builds a simple generator model.
    """
    def block(x, filters):
        x = tf.keras.layers.Dense(filters * 4 * 4)(x)
        x = tf.keras.layers.Reshape((4, 4, filters))(x)
        for _ in range(int(math.log2(resolution)) - 2):
            x = tf.keras.layers.UpSampling2D()(x)
            x = tf.keras.layers.Conv2D(filters // 2, 3, padding="same", activation="relu")(x)
        x = tf.keras.layers.Conv2D(3, 1, padding="same", activation="tanh")(x)
        return x

    inputs = tf.keras.Input(shape=(latent_dim,))
    x = block(inputs, 512)
    model = tf.keras.Model(inputs, x)
    return model


def build_discriminator(resolution):
    """
    Builds a simple discriminator model.
    """
    def block(x, filters):
        for _ in range(int(math.log2(resolution)) - 2):
            x = tf.keras.layers.Conv2D(filters, 3, padding="same", activation="leaky_relu")(x)
            x = tf.keras.layers.AveragePooling2D()(x)
        x = tf.keras.layers.Flatten()(x)
        x = tf.keras.layers.Dense(1)(x)
        return x

    inputs = tf.keras.Input(shape=(resolution, resolution, 3))
    x = block(inputs, 512)
    model = tf.keras.Model(inputs, x)
    return model


def update_moving_average(ma, model, decay=0.999):
    for var, ma_var in zip(model.trainable_variables, ma.variables()):
        ma_var.assign(decay * ma_var + (1 - decay) * var)


# --------- Training Execution ---------
class ProGANTrainer:
    def __init__(self, dataset):
        self.dataset = dataset
        self.iteration = 0
        self.total_iterations = 10000  # for demonstration
        self.build_graph()

    def build_graph(self):
        tf.compat.v1.disable_eager_execution()
        self.lod_ph = tf.compat.v1.placeholder(tf.float32, shape=(), name="lod")
        self.lr_ph = tf.compat.v1.placeholder(tf.float32, shape=(), name="learning_rate")
        self.mb_ph = tf.compat.v1.placeholder(tf.int32, shape=(), name="minibatch_size")
        self.z_ph = tf.compat.v1.placeholder(tf.float32, shape=(None, config.latent_dim), name="latent")
        self.real_ph = tf.compat.v1.placeholder(tf.float32, shape=(None, None, None, 3), name="real_images")

        # Build models
        self.generator = build_generator(config.latent_dim, config.max_resolution)
        self.discriminator = build_discriminator(config.max_resolution)
        self.generator_ma = build_generator(config.latent_dim, config.max_resolution)

        # Losses
        fake_images = self.generator(self.z_ph)
        real_logits = self.discriminator(self.real_ph)
        fake_logits = self.discriminator(fake_images)

        self.d_loss = tf.reduce_mean(tf.nn.relu(1.0 - real_logits)) + tf.reduce_mean(tf.nn.relu(1.0 + fake_logits))
        self.g_loss = -tf.reduce_mean(fake_logits)

        # Optimizers
        self.d_opt = tf.train.AdamOptimizer(self.lr_ph, beta1=0.0, beta2=0.99).minimize(self.d_loss)
        self.g_opt = tf.train.AdamOptimizer(self.lr_ph, beta1=0.0, beta2=0.99).minimize(self.g_loss)

        # Moving average update
        self.ma_update = tf.group([var.assign(var * 0.999 + (1 - 0.999) * var_) for var, var_ in zip(self.generator_ma.trainable_variables, self.generator.trainable_variables)])

        # Summaries
        tf.summary.scalar("d_loss", self.d_loss)
        tf.summary.scalar("g_loss", self.g_loss)
        self.summary_op = tf.summary.merge_all()

    def train(self):
        with tf.compat.v1.Session() as sess:
            sess.run(tf.compat.v1.global_variables_initializer())
            writer = tf.summary.FileWriter(config.log_dir, sess.graph)

            for _ in range(self.total_iterations):
                # Determine dynamic parameters
                lod, resolution, minibatch, lr = compute_training_parameters(self.iteration)
                z = generate_latent_vectors(minibatch, config.latent_dim)
                real_images_batch = self.get_next_real_batch(minibatch, resolution)

                # Train discriminator
                sess.run(self.d_opt, feed_dict={
                    self.lod_ph: lod,
                    self.lr_ph: lr,
                    self.mb_ph: minibatch,
                    self.z_ph: z,
                    self.real_ph: real_images_batch
                })

                # Train generator
                sess.run(self.g_opt, feed_dict={
                    self.lod_ph: lod,
                    self.lr_ph: lr,
                    self.mb_ph: minibatch,
                    self.z_ph: z,
                    self.real_ph: real_images_batch
                })

                # Update moving average
                sess.run(self.ma_update)

                # Logging
                if self.iteration % 100 == 0:
                    summary = sess.run(self.summary_op, feed_dict={
                        self.lod_ph: lod,
                        self.lr_ph: lr,
                        self.mb_ph: minibatch,
                        self.z_ph: z,
                        self.real_ph: real_images_batch
                    })
                    writer.add_summary(summary, self.iteration)

                # Snapshot
                if self.iteration % config.snapshot_interval_k == 0:
                    self.save_snapshot(sess, self.iteration)

                self.iteration += 1

    def get_next_real_batch(self, batch_size, resolution):
        # Simple random sampling from dataset for demonstration
        for batch in self.dataset:
            return tf.image.resize(batch, [resolution, resolution]).numpy()
        return np.zeros((batch_size, resolution, resolution, 3))

    def save_snapshot(self, sess, step):
        # Generate fake images
        z = generate_latent_vectors(config.batch_size_base, config.latent_dim)
        fake_images = sess.run(self.generator(z))
        grid = build_snapshot_grid(fake_images)
        grid_image = tf.image.convert_image_dtype(grid, dtype=tf.uint8)
        grid_np = sess.run(grid_image)
        Path(config.snapshot_dir).mkdir(parents=True, exist_ok=True)
        grid_path = os.path.join(config.snapshot_dir, f"snapshot_{step}.png")
        tf.keras.preprocessing.image.save_img(grid_path, grid_np)


if __name__ == "__main__":
    # Load dataset
    dataset = load_dataset(config.data_dir, config.max_resolution)
    trainer = ProGANTrainer(dataset)
    trainer.train()
