import numpy as np

def same_dim(x1: np.ndarray, x2: np.ndarray) -> None:
    """
    Ensure that the second dimension of x1 and x2 match.
    Raises a ValueError if they do not.
    """
    if x1.shape[1] != x2.shape[1]:
        raise ValueError(
            f"Array dimensions do not match: expected x1.shape[1] == x2.shape[1] "
            f"but got x1.shape[1]={x1.shape[1]}, x2.shape[1]={x2.shape[1]}"
        )

def in_range(x: float, a: float, b: float, name: str) -> None:
    """
    Validate that a scalar x lies strictly between bounds a and b.
    Raises a ValueError if the condition a < x < b is not met.
    """
    if not (a < x < b):
        raise ValueError(f"Variable {name}={x} is out of bounds [{a}, {b}]")

def check_bags(bags) -> list[np.ndarray]:
    """
    Validate and standardize a list of input arrays (bags).
    Steps:
        1. Ensure bags is a list.
        2. Convert each element to a NumPy array.
        3. Verify each array is at least 2D; raise an error for 1D arrays.
        4. Use np.atleast_2d to ensure all arrays are 2D or higher.
    Returns a list of processed 2D arrays.
    """
    if not isinstance(bags, list):
        raise TypeError(f"Expected a list of arrays, got {type(bags).__name__}")

    processed = []
    for idx, item in enumerate(bags):
        arr = np.array(item)
        if arr.ndim == 1:
            raise ValueError(
                f"Array at index {idx} is 1D. Reshape it using reshape(-1, 1) "
                f"or reshape(1, -1) before passing to check_bags."
            )
        arr_2d = np.atleast_2d(arr)
        processed.append(arr_2d)

    return processed
