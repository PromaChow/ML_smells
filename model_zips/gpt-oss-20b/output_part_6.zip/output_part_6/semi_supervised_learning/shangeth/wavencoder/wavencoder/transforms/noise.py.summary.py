import os
import random
import math

import torch
import torchaudio


class AdditiveNoise:
    def __init__(self, noise_dir: str, p: float = 0.5, snr_levels: list = None):
        self.noise_dir = noise_dir
        self.p = p
        self.snr_levels = snr_levels if snr_levels is not None else [5, 10, 15, 20]
        self.noise_files = [
            os.path.join(noise_dir, f) for f in os.listdir(noise_dir)
            if os.path.isfile(os.path.join(noise_dir, f))
        ]

    def __call__(self, wav: torch.Tensor) -> torch.Tensor:
        if random.random() > self.p or not self.noise_files:
            return wav

        # Load a random noise file
        noise_path = random.choice(self.noise_files)
        noise, _ = torchaudio.load(noise_path)
        noise = noise.squeeze(0) if noise.shape[0] == 1 else noise

        signal_len = wav.shape[-1]
        noise_len = noise.shape[-1]

        if noise_len > signal_len:
            start = random.randint(0, noise_len - signal_len)
            noise = noise[..., start : start + signal_len]
        elif noise_len < signal_len:
            pad = torch.zeros_like(wav)[:, :signal_len - noise_len]
            noise = torch.cat([noise, pad], dim=-1)

        snr = random.choice(self.snr_levels)
        K = self._compute_snr_k(wav, noise, snr)
        noise = noise * K
        noisy = wav + noise

        # Energy normalization
        Ex = torch.mean(wav ** 2)
        oenergy = torch.mean(noisy ** 2)
        eps = 1e-8
        noisy = torch.sqrt(Ex / (oenergy + eps)) * noisy

        if torch.mean(noise ** 2) > 0:
            return noisy
        else:
            return wav

    @staticmethod
    def _compute_snr_k(signal: torch.Tensor, noise: torch.Tensor, snr: float) -> float:
        Ex = torch.mean(signal ** 2)
        En = torch.mean(noise ** 2)
        if En > 0:
            K = math.sqrt(Ex / (En * (10 ** (snr / 10.0))))
            return K
        return 1.0


class AWGNoise:
    def __init__(self, p: float = 0.5, snr_range: tuple = (0.0, 10.0)):
        self.p = p
        self.snr_range = snr_range
        self.bits = 16

    def __call__(self, wav: torch.Tensor) -> torch.Tensor:
        if random.random() > self.p:
            return wav

        noise = torch.randn_like(wav)

        # Normalization
        divisor = 2 ** (self.bits - 1)
        wav_norm = wav / divisor
        noise_norm = noise / divisor

        signal_power = torch.mean(wav_norm ** 2)
        noise_power = torch.mean(noise_norm ** 2)

        if noise_power == 0:
            return wav

        snr = random.uniform(*self.snr_range)
        covariance = math.sqrt(signal_power / noise_power * (10 ** (-snr / 10.0)))
        scaled_noise = noise * covariance

        return wav + scaled_noise
