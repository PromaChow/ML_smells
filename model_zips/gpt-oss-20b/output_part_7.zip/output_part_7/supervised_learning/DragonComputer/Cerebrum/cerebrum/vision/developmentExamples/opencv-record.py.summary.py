import cv2
import numpy as np
import os
from datetime import datetime

# Construct output filename
date_str = datetime.now().strftime("%Y-%m-%d")
output_dir = "memory"
os.makedirs(output_dir, exist_ok=True)
filename = os.path.join(output_dir, f"{date_str}.avi")

# Initialize video capture
cap = cv2.VideoCapture(0)

# Define codec and create VideoWriter
try:
    fourcc = cv2.cv.CV_FOURCC('X', 'V', 'I', 'D')
except AttributeError:
    fourcc = cv2.VideoWriter_fourcc(*'XVID')
writer = cv2.VideoWriter(filename, fourcc, 20.0, (640, 480))

# Capture and process frames
while True:
    ret, frame = cap.read()
    if not ret:
        break
    writer.write(frame)
    cv2.imshow('frame', frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Cleanup
cap.release()
writer.release()
cv2.destroyAllWindows()
