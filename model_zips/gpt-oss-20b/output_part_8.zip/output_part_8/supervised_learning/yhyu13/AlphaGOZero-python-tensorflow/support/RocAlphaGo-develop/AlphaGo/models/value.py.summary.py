import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, Flatten, Dense
from tensorflow.keras.optimizers import SGD

class value_trainer:
    def __init__(self):
        self.model = Sequential()
        self.model.add(
            Conv2D(
                filters=152,
                kernel_size=(5, 5),
                activation='relu',
                padding='same',
                kernel_initializer='uniform',
                input_shape=(49, 19, 19),
            )
        )
        for _ in range(2, 13):
            self.model.add(
                Conv2D(
                    filters=152,
                    kernel_size=(3, 3),
                    activation='relu',
                    padding='same',
                    kernel_initializer='uniform',
                )
            )
        self.model.add(
            Conv2D(
                filters=1,
                kernel_size=(1, 1),
                activation='linear',
                padding='same',
                kernel_initializer='uniform',
            )
        )
        self.model.add(Flatten())
        self.model.add(
            Dense(
                units=256,
                kernel_initializer='uniform',
            )
        )
        self.model.add(
            Dense(
                units=1,
                activation='tanh',
            )
        )
        # LEARNING_RATE = 0.01
        # DECAY = 1e-6
        # optimizer = SGD(learning_rate=LEARNING_RATE, decay=DECAY, momentum=0.9)
        # self.model.compile(optimizer=optimizer, loss='mean_squared_error')

    def get_samples(self):
        """Non-terminating loop to draw training samples uniformly at random."""
        # TODO: Implement sampling logic
        pass

    def train(self):
        """Use model.fit_generator for training."""
        # TODO: Implement training logic
        pass

if __name__ == "__main__":
    # TODO: Add command-line instantiation or testing logic
    trainer = value_trainer()
    print(trainer.model.summary())
