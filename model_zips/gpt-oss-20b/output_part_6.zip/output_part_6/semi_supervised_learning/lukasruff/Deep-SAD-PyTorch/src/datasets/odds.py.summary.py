import numpy as np
import torch
from torch.utils.data import DataLoader, Subset
from odds_dataset import ODDSDataset  # Assumed to be provided elsewhere


def create_semisupervised_setting(
    targets,
    normal_classes,
    outlier_classes,
    ratio_known_normal,
    ratio_known_outlier,
    ratio_pollution,
    random_state,
):
    rng = np.random.RandomState(random_state)

    normal_idx = np.where(np.isin(targets, normal_classes))[0]
    outlier_idx = np.where(np.isin(targets, outlier_classes))[0]

    n_known_normal = int(len(normal_idx) * ratio_known_normal)
    n_known_outlier = int(len(outlier_idx) * ratio_known_outlier)

    if n_known_normal > 0:
        known_normal_idx = rng.choice(normal_idx, size=n_known_normal, replace=False)
    else:
        known_normal_idx = np.array([], dtype=int)

    if n_known_outlier > 0:
        known_outlier_idx = rng.choice(outlier_idx, size=n_known_outlier, replace=False)
    else:
        known_outlier_idx = np.array([], dtype=int)

    used_idx = np.concatenate([known_normal_idx, known_outlier_idx])
    all_idx = np.arange(len(targets))
    unknown_idx = np.setdiff1d(all_idx, used_idx)

    n_pollution = int(len(unknown_idx) * ratio_pollution)
    if n_pollution > 0:
        pollution_idx = rng.choice(unknown_idx, size=n_pollution, replace=False)
    else:
        pollution_idx = np.array([], dtype=int)

    final_idx = np.concatenate([known_normal_idx, known_outlier_idx, pollution_idx, np.setdiff1d(unknown_idx, pollution_idx)])
    semi_targets = np.full_like(targets, fill_value=-1)
    semi_targets[known_normal_idx] = 0
    semi_targets[known_outlier_idx] = 1
    semi_targets[pollution_idx] = 1

    return final_idx, semi_targets[final_idx]


class ODDSADDataset:
    def __init__(
        self,
        dataset_root,
        dataset_name,
        n_known_outlier_classes=1,
        ratio_known_normal=1.0,
        ratio_known_outlier=1.0,
        ratio_pollution=0.0,
        random_state=42,
    ):
        self.num_classes = 2
        self.normal_classes = (0,)
        self.outlier_classes = (1,)
        self.known_outlier_classes = (1,) if n_known_outlier_classes > 0 else ()

        self.train_set_raw = ODDSDataset(root=dataset_root, name=dataset_name, train=True)

        if hasattr(self.train_set_raw, "targets"):
            targets = np.array(self.train_set_raw.targets)
        elif hasattr(self.train_set_raw, "labels"):
            targets = np.array(self.train_set_raw.labels)
        else:
            raise AttributeError("Training dataset must have 'targets' or 'labels' attribute.")

        idx, semi_targets = create_semisupervised_setting(
            targets,
            self.normal_classes,
            self.outlier_classes,
            ratio_known_normal,
            ratio_known_outlier,
            ratio_pollution,
            random_state,
        )

        if not hasattr(self.train_set_raw, "semi_targets"):
            self.train_set_raw.semi_targets = np.full_like(targets, -1)
        self.train_set_raw.semi_targets[idx] = semi_targets
        self.train_set = Subset(self.train_set_raw, idx)

        self.test_set = ODDSDataset(root=dataset_root, name=dataset_name, train=False)

    def loaders(
        self,
        batch_size=64,
        num_workers=4,
        pin_memory=False,
    ):
        train_loader = DataLoader(
            self.train_set,
            batch_size=batch_size,
            shuffle=True,
            drop_last=True,
            num_workers=num_workers,
            pin_memory=pin_memory,
        )
        test_loader = DataLoader(
            self.test_set,
            batch_size=batch_size,
            shuffle=False,
            drop_last=False,
            num_workers=num_workers,
            pin_memory=pin_memory,
        )
        return train_loader, test_loader
