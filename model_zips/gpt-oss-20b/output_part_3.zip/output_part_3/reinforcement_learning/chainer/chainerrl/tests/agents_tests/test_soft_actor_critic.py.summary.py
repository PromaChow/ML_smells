import os
import tempfile
import numpy as np
import gym
import chainerrl
import chainerrl.agent
import chainerrl.sac
import chainerrl.envs
import chainerrl.training
import chainerrl.replay_buffer
import chainerrl.network
import chainerrl.distribution
import chainerrl.optimizer
import chainerrl.device
import chainer
import chainer.functions as F
import chainer.links as L
import pytest

# --------------------------------------------------------------------------- #
# 1. Environment ------------------------------------------------------------- #
# --------------------------------------------------------------------------- #

class ABCEnv(gym.Env):
    def __init__(self, episodic: bool = False, deterministic: bool = False):
        super().__init__()
        self.observation_space = gym.spaces.Box(
            low=-np.ones(2, dtype=np.float32),
            high=np.ones(2, dtype=np.float32),
            dtype=np.float32,
        )
        self.action_space = gym.spaces.Box(
            low=-1.0 * np.ones(2, dtype=np.float32),
            high=1.0 * np.ones(2, dtype=np.float32),
            dtype=np.float32,
        )
        self.episodic = episodic
        self.deterministic = deterministic
        self.step_count = 0
        self.max_steps = 10 if episodic else 2

    def reset(self):
        self.step_count = 0
        return np.zeros(2, dtype=np.float32)

    def step(self, action):
        self.step_count += 1
        reward = 1.0
        done = self.step_count >= self.max_steps
        return np.zeros(2, dtype=np.float32), reward, done, {}

# --------------------------------------------------------------------------- #
# 2. Networks --------------------------------------------------------------- #
# --------------------------------------------------------------------------- #

def make_mlp_output(shape):
    return L.Linear(None, shape)

class PolicyNetwork(chainer.Chain):
    def __init__(self, obs_shape, act_shape):
        super().__init__()
        with self.init_scope():
            self.l1 = L.Linear(obs_shape[0], 64)
            self.l2 = L.Linear(64, 64)
            self.mean = L.Linear(64, act_shape[0])
            self.log_std = L.Linear(64, act_shape[0])

    def __call__(self, x):
        h = F.relu(self.l1(x))
        h = F.relu(self.l2(h))
        mean = self.mean(h)
        log_std = self.log_std(h)
        log_std = F.clip(log_std, -20, 2)
        return mean, log_std

class QNetwork(chainer.Chain):
    def __init__(self, obs_shape, act_shape):
        super().__init__()
        with self.init_scope():
            self.l1 = L.Linear(obs_shape[0] + act_shape[0], 64)
            self.l2 = L.Linear(64, 64)
            self.q = L.Linear(64, 1)

    def __call__(self, obs, act):
        x = F.concat((obs, act), axis=1)
        h = F.relu(self.l1(x))
        h = F.relu(self.l2(h))
        return self.q(h)

# --------------------------------------------------------------------------- #
# 3. Evaluation ------------------------------------------------------------- #
# --------------------------------------------------------------------------- #

def run_evaluation(agent, env, n_episodes=5, require_success=True):
    rewards = chainerrl.training.run_evaluation_episodes(
        agent, env, n_episodes, deterministic=True
    )
    if require_success:
        assert all(r >= 1.0 for r in rewards), f"Success check failed: {rewards}"
    return rewards

# --------------------------------------------------------------------------- #
# 4. Test Helpers ----------------------------------------------------------- #
# --------------------------------------------------------------------------- #

def create_agent(episodic, gpu, tmpdir, deterministic=True):
    obs_shape = (2,)
    act_shape = (2,)
    policy_net = PolicyNetwork(obs_shape, act_shape)
    q1 = QNetwork(obs_shape, act_shape)
    q2 = QNetwork(obs_shape, act_shape)

    # Distributions
    dist_cls = chainerrl.distribution.SquashedGaussianDistribution

    # Optimizers
    policy_opt = chainerrl.optimizer.Adam(
        policy_net, lr=1e-3, clip_norm=1.0
    )
    q1_opt = chainerrl.optimizer.Adam(q1, lr=1e-2, clip_norm=1.0)
    q2_opt = chainerrl.optimizer.Adam(q2, lr=1e-2, clip_norm=1.0)

    # Replay buffer
    replay_buffer = chainerrl.replay_buffer.ReplayBuffer(
        1_000_000, burnin_action_func=lambda s: np.random.uniform(
            low=s.action_space.low, high=s.action_space.high, size=s.action_space.shape
        )
    )

    agent = chainerrl.sac.SAC(
        policy_net,
        q1,
        q2,
        dist_cls,
        gamma=0.99,
        tau=0.005,
        batch_size=64,
        start_steps=100,
        replay_buffer=replay_buffer,
        policy_optimizer=policy_opt,
        q_optimizer=[q1_opt, q2_opt],
    )

    if gpu >= 0:
        agent.to_gpu(gpu)

    return agent

def create_env_factory(episodic, deterministic=True):
    def env_factory():
        return ABCEnv(episodic=episodic, deterministic=deterministic)
    return env_factory

# --------------------------------------------------------------------------- #
# 5. Tests ------------------------------------------------------------------ #
# --------------------------------------------------------------------------- #

@pytest.mark.parametrize("episodic,gpu,batch,slow,require_success,load_model", [
    (True, -1, False, False, False, False),   # CPU single fast
    (False, -1, False, True, True, False),    # CPU single slow
    (True, 0, False, False, True, False),     # GPU single fast
    (False, 0, False, True, True, False),     # GPU single slow
    (True, -1, True, False, False, False),    # CPU batch fast
    (False, -1, True, True, True, False),     # CPU batch slow
    (True, 0, True, False, True, True),       # GPU batch fast
    (False, 0, True, True, True, True),       # GPU batch slow
])
def test_sac(episodic, gpu, batch, slow, require_success, load_model):
    # Device setup
    if gpu >= 0:
        chainerrl.device.set_device(gpu)
    else:
        chainerrl.device.set_device(-1)

    # Temporary directory
    tmpdir = tempfile.mkdtemp()

    # Environment
    env_factory = create_env_factory(episodic)
    if batch:
        env = chainerrl.envs.MultiprocessVectorEnv([env_factory for _ in range(3)])
    else:
        env = env_factory()

    # Agent
    agent = create_agent(episodic, gpu, tmpdir)

    # Training parameters
    n_steps = 100_000 if slow else 100
    eval_interval = 200
    eval_episodes = 5

    # Train
    chainerrl.training.train_agent_with_evaluation(
        agent,
        env,
        n_steps=n_steps,
        eval_interval=eval_interval,
        eval_episodes=eval_episodes,
        eval_func=None,
        device=gpu,
    )

    # Evaluation after training
    run_evaluation(agent, env, n_episodes=5, require_success=require_success)

    # Save
    agent_path = os.path.join(tmpdir, "agent")
    agent.save(agent_path)

    if load_model:
        # Load into new agent instance
        loaded_agent = create_agent(episodic, gpu, tmpdir)
        loaded_agent.load(agent_path)
        run_evaluation(loaded_agent, env, n_episodes=5, require_success=require_success)
```