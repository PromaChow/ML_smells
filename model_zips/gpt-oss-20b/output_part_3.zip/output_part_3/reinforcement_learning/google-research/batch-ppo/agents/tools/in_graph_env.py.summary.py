import tensorflow as tf
import gym
import numpy as np

tf.compat.v1.disable_eager_execution()


class InGraphEnv:
    def __init__(self, env: gym.Env):
        self.env = env
        self._ob_shape, self._ob_dtype = self._parse_space(env.observation_space)
        self._ac_shape, self._ac_dtype = self._parse_space(env.action_space)

        self._observ = tf.Variable(
            tf.zeros(self._ob_shape, dtype=self._ob_dtype), name="observ"
        )
        self._action = tf.Variable(
            tf.zeros(self._ac_shape, dtype=self._ac_dtype), name="action"
        )
        self._reward = tf.Variable(tf.zeros([], dtype=tf.float32), name="reward")
        self._done = tf.Variable(tf.constant(True, dtype=tf.bool), name="done")
        self._step = tf.Variable(tf.zeros([], dtype=tf.int32), name="step")

    def simulate(self, action_tensor):
        def step_fn(action_np):
            obs, reward, done, _ = self.env.step(action_np)
            return obs, reward, done

        obs, reward, done = tf.py_func(
            step_fn, [action_tensor], [self._ob_dtype, tf.float32, tf.bool]
        )
        obs = tf.convert_to_tensor(obs, dtype=self._ob_dtype)
        reward = tf.convert_to_tensor(reward, dtype=tf.float32)
        done = tf.convert_to_tensor(done, dtype=tf.bool)

        tf.check_numerics(obs, "obs contains NaN or Inf")
        tf.check_numerics(reward, "reward contains NaN or Inf")
        tf.check_numerics(done, "done contains NaN or Inf")

        assign_ops = [
            self._observ.assign(obs),
            self._action.assign(action_tensor),
            self._reward.assign(reward),
            self._done.assign(done),
            self._step.assign_add(1),
        ]
        with tf.control_dependencies(assign_ops):
            return tf.no_op()

    def reset(self):
        def reset_fn():
            obs = self.env.reset()
            return obs

        obs = tf.py_func(reset_fn, [], [self._ob_dtype])
        obs = tf.convert_to_tensor(obs, dtype=self._ob_dtype)

        assign_ops = [
            self._observ.assign(obs),
            self._reward.assign(tf.zeros([], dtype=tf.float32)),
            self._done.assign(tf.constant(False, dtype=tf.bool)),
            self._step.assign(tf.zeros([], dtype=tf.int32)),
        ]
        with tf.control_dependencies(assign_ops):
            return tf.no_op()

    @property
    def observ(self):
        return self._observ

    @property
    def action(self):
        return self._action

    @property
    def reward(self):
        return self._reward

    @property
    def done(self):
        return self._done

    @property
    def step(self):
        return self._step

    def _parse_space(self, space):
        if isinstance(space, gym.spaces.Box):
            shape = space.shape
            dtype = tf.as_dtype(space.dtype)
        elif isinstance(space, gym.spaces.Discrete):
            shape = ()
            dtype = tf.int32
        else:
            raise NotImplementedError(f"Unsupported space type: {type(space)}")
        return shape, dtype
