import numpy as np
from arm_env import ArmEnv
from rl_ddpg import DDPG

MAX_EPISODES = 500
MAX_EP_STEPS = 200
ON_TRAIN = True


def train(rl, env, max_episodes, max_steps):
    for ep in range(max_episodes):
        s = env.reset()
        total_reward = 0.0
        for step in range(max_steps):
            env.render()
            a = rl.choose_action(s)
            s_, r, done, _ = env.step(a)
            total_reward += r
            try:
                rl.memory.store_transition(s, a, r, s_)
            except AttributeError:
                rl.memory.store(s, a, r, s_)
            if hasattr(rl.memory, "is_full"):
                if rl.memory.is_full():
                    rl.learn()
            else:
                try:
                    if len(rl.memory) >= rl.memory.capacity:
                        rl.learn()
                except Exception:
                    pass
            s = s_
            if done:
                break
        print(f"Episode: {ep+1}, Reward: {total_reward:.2f}, Steps: {step+1}")
    rl.save()


def eval(rl, env):
    rl.restore()
    env.render(vsync=True)
    while True:
        s = env.reset()
        done = False
        while not done:
            env.render()
            a = rl.choose_action(s)
            s_, _, done, _ = env.step(a)
            s = s_


if __name__ == "__main__":
    env = ArmEnv()
    s_dim = env.state_dim
    a_dim = env.action_dim
    a_bound = env.action_bound
    rl = DDPG(a_dim, s_dim, a_bound)
    if ON_TRAIN:
        train(rl, env, MAX_EPISODES, MAX_EP_STEPS)
    else:
        eval(rl, env)