import numpy as np
from some_simulation_library import BaseBulletEnv, SingleRobotEmptyScene
from some_robot_library import Striker


class StrikerBulletEnv(BaseBulletEnv):
    def __init__(self, robot: Striker, **kwargs):
        super().__init__(**kwargs)
        self.robot = robot
        self._striked = False
        self._min_strike_dist = float("inf")
        self.strike_threshold = 0.1
        self.last_potential = None

    def create_single_player_scene(self):
        self.scene = SingleRobotEmptyScene(
            robot=self.robot,
            gravity=[0.0, 0.0, -9.81],
            timestep=0.0020,
            frame_skip=5,
        )
        return self.scene

    def reset(self):
        self._striked = False
        self._min_strike_dist = float("inf")
        self.last_potential = None
        if hasattr(self, "scene"):
            self.scene.reset()
        return self.robot.calc_state()

    def step(self, a):
        # Apply action to the robot
        self.robot.apply_action(a)

        # Advance the physics simulation
        self.scene.global_step()

        # Compute the robot state
        state = self.robot.calc_state()
        to_target_vec = state.get("to_target_vec", np.zeros(3))

        # Potential calculation
        current_potential = self.calc_potential(state)
        potential_diff = (
            current_potential - self.last_potential
            if self.last_potential is not None
            else 0.0
        )
        self.last_potential = current_potential

        # Electricity cost
        electricity_cost = (
            np.sum(np.abs(a) * self.robot.joint_velocities) + 0.01 * np.sum(np.abs(a))
        )

        # Stuck joint cost
        stuck_joint_cost = 0.0
        for joint in self.robot.joints:
            rel_pos = (
                (joint.position - joint.min_pos)
                / (joint.max_pos - joint.min_pos)
            )
            if rel_pos < 0.01 or rel_pos > 0.99:
                stuck_joint_cost += 10.0

        # Strike detection
        fingertip_pos = self.robot.fingertip_position()
        object_pos = self.robot.object_position()
        dist_to_fingertip = np.linalg.norm(object_pos - fingertip_pos)

        if dist_to_fingertip < self.strike_threshold:
            self._striked = True
            self._strike_position = object_pos.copy()

        self._min_strike_dist = min(self._min_strike_dist, dist_to_fingertip)

        # Reward components
        reward_dist = -3.0 * self._min_strike_dist
        reward_ctrl = -0.1 * np.sum(np.square(a))
        if self._striked:
            reward_near = -np.linalg.norm(object_pos - self._strike_position)
        else:
            reward_near = -np.linalg.norm(object_pos - fingertip_pos)

        total_reward = reward_dist + reward_ctrl + reward_near

        # Build info dictionary
        info = {
            "potential": current_potential,
            "potential_diff": potential_diff,
            "electricity_cost": electricity_cost,
            "stuck_joint_cost": stuck_joint_cost,
            "strike": self._striked,
        }

        # Update camera view
        self.adjust_camera()

        # Termination condition can be customized; for now we never end
        done = False

        return state, total_reward, done, info

    def calc_potential(self, state):
        to_target_vec = state.get("to_target_vec", np.zeros(3))
        return -100.0 * np.linalg.norm(to_target_vec)

    def adjust_camera(self):
        fingertip = self.robot.fingertip_position()
        if hasattr(self.scene, "set_camera_target"):
            self.scene.set_camera_target(fingertip * 0.5)