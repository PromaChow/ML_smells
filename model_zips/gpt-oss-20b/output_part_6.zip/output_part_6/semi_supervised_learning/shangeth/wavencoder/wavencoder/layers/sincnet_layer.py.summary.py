import math
import torch
import torch.nn as nn
import torch.nn.functional as F

def to_mel(freq):
    return 2595.0 * torch.log10(1.0 + freq / 700.0)

def to_hz(mel):
    return 700.0 * (10.0 ** (mel / 2595.0) - 1.0)

class SincConvLayer(nn.Module):
    def __init__(
        self,
        out_channels,
        kernel_size,
        sample_rate,
        stride=1,
        padding=0,
        dilation=1,
    ):
        super().__init__()
        if kernel_size % 2 == 0:
            kernel_size += 1
        self.kernel_size = kernel_size
        self.out_channels = out_channels
        self.sample_rate = sample_rate
        self.stride = stride
        self.padding = padding
        self.dilation = dilation

        # Frequency initialization
        min_low_hz = 30.0
        min_band_hz = 50.0
        high_hz = sample_rate / 2.0 - (min_low_hz + min_band_hz)

        mel_low = to_mel(torch.tensor(min_low_hz))
        mel_high = to_mel(torch.tensor(high_hz))
        mel_points = torch.linspace(mel_low, mel_high, out_channels + 1)
        hz = to_hz(mel_points)

        low_hz_init = hz[:-1] - min_low_hz
        band_hz_init = (hz[1:] - hz[:-1]) - min_band_hz

        self.low_hz_ = nn.Parameter(low_hz_init)
        self.band_hz_ = nn.Parameter(band_hz_init)

        # Hamming window
        n = torch.arange(kernel_size, dtype=torch.float32)
        window = 0.54 - 0.46 * torch.cos(2 * math.pi * n / kernel_size)
        self.register_buffer("window", window)

        # Time axis
        half_len = (kernel_size - 1) // 2
        t = torch.linspace(-half_len, 0, half_len + 1, dtype=torch.float32)
        t = t * 2 * math.pi / sample_rate
        self.register_buffer("t", t)

    def forward(self, x):
        device = x.device
        low = self.low_hz_.abs() + 30.0
        band = self.band_hz_.abs() + 50.0
        high = low + band
        high = high.clamp(max=self.sample_rate / 2.0)

        t = self.t.to(device)
        window = self.window.to(device)
        half_len = (self.kernel_size - 1) // 2
        window_left = window[: half_len + 1]

        low = low[:, None]
        high = high[:, None]
        band = band[:, None]

        # Left band
        denom = t / 2.0
        numer = torch.sin(high * t) - torch.sin(low * t)
        left_band = torch.where(t == 0, 2 * (high - low), numer / denom)
        left_band = left_band * window_left

        # Center and right
        center = 2 * band
        right_band = torch.flip(left_band[:, :-1], dims=[1])

        filt = torch.cat([left_band, center, right_band], dim=1)
        filt = filt / (2 * band)

        filt = filt.unsqueeze(1)

        return F.conv1d(
            x,
            filt,
            stride=self.stride,
            padding=self.padding,
            dilation=self.dilation,
        )