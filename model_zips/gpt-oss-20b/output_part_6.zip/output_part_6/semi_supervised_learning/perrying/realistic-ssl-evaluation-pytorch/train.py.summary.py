import argparse
import json
import os
import random
import time
from datetime import datetime

import torch
import torch.nn as nn
import torch.optim as optim
import torch.utils.data as data
import torchvision.transforms as T
from torch.nn.functional import kl_div, softmax
from torch.utils.data.sampler import Sampler

# Dummy config module
class DatasetConfig:
    def __init__(self, name):
        self.name = name
        if name == "cifar10":
            self.num_classes = 10
            self.batch_size = 128
            self.transform_fn = lambda m: m
            self.dataset_class = torchvision.datasets.CIFAR10
            self.root = "./data"
            self.download = True
            self.train_transform = T.Compose(
                [T.RandomHorizontalFlip(), T.RandomCrop(32, padding=4), T.ToTensor(), T.Normalize((0.5,), (0.5,))]
            )
            self.test_transform = T.Compose([T.ToTensor(), T.Normalize((0.5,), (0.5,))])
        elif name == "svhn":
            self.num_classes = 10
            self.batch_size = 128
            self.transform_fn = lambda m: m
            self.dataset_class = torchvision.datasets.SVHN
            self.root = "./data"
            self.download = True
            self.train_transform = T.Compose(
                [T.RandomCrop(32, padding=4), T.ToTensor(), T.Normalize((0.5,), (0.5,))]
            )
            self.test_transform = T.Compose([T.ToTensor(), T.Normalize((0.5,), (0.5,))])
        else:
            raise ValueError("Unsupported dataset")

    def get_split(self, split):
        if split == "train":
            return self.dataset_class(
                root=self.root, split="train", transform=self.train_transform, download=self.download
            )
        elif split == "val":
            return self.dataset_class(
                root=self.root, split="train", transform=self.test_transform, download=self.download
            )
        elif split == "test":
            return self.dataset_class(
                root=self.root, split="test", transform=self.test_transform, download=self.download
            )
        else:
            raise ValueError("Unsupported split")

config = {
    "cifar10": DatasetConfig("cifar10"),
    "svhn": DatasetConfig("svhn"),
}

# Simple Wide ResNet placeholder
class SimpleWRN(nn.Module):
    def __init__(self, depth, widen_factor, num_classes):
        super().__init__()
        self.conv1 = nn.Conv2d(3, 16, kernel_size=3, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(16)
        self.relu = nn.ReLU(inplace=True)
        self.layer = nn.Sequential(
            nn.Conv2d(16, 16 * widen_factor, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(16 * widen_factor),
            nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d(1),
        )
        self.fc = nn.Linear(16 * widen_factor, num_classes)

    def forward(self, x):
        x = self.relu(self.bn1(self.conv1(x)))
        x = self.layer(x).view(x.size(0), -1)
        return self.fc(x)

# Random sampler ensuring consistent indices across epochs
class CustomRandomSampler(Sampler):
    def __init__(self, dataset, replacement=False):
        self.dataset = dataset
        self.replacement = replacement
        self.num_samples = len(dataset)

    def __iter__(self):
        indices = list(range(self.num_samples))
        if self.replacement:
            indices = random.choices(indices, k=self.num_samples)
        else:
            random.shuffle(indices)
        return iter(indices)

    def __len__(self):
        return self.num_samples

# Algorithm base
class SSLAlgorithm:
    def __init__(self, model, device, params):
        self.model = model
        self.device = device
        self.params = params

    def compute_ssl_loss(self, logits, unlabeled_mask):
        return torch.tensor(0.0, device=self.device)

    def ema_update(self, teacher, student):
        pass

# VAT implementation
class VAT(SSLAlgorithm):
    def __init__(self, model, device, params):
        super().__init__(model, device, params)
        self.epsilon = params.get("epsilon", 1.0)
        self.xi = params.get("xi", 0.01)
        self.num_power_iter = params.get("num_power_iter", 1)

    def _kl_divergence(self, p, q):
        return kl_div(softmax(p, dim=1).log(), softmax(q, dim=1), reduction="batchmean")

    def _compute_adv(self, x):
        x_adv = x + self.xi * torch.randn_like(x, requires_grad=True)
        for _ in range(self.num_power_iter):
            logits = self.model(x_adv)
            loss = self._kl_divergence(logits, self.model(x))
            loss.backward()
            x_adv = x + self.epsilon * x_adv.grad.sign()
            x_adv = x_adv.detach()
            x_adv.requires_grad = True
        return x_adv

    def compute_ssl_loss(self, logits, unlabeled_mask):
        x = logits[unlabeled_mask]
        logits_orig = logits[unlabeled_mask]
        x_adv = self._compute_adv(x)
        logits_adv = self.model(x_adv)
        loss = self._kl_divergence(logits_orig, logits_adv)
        return loss

# PL implementation
class PL(SSLAlgorithm):
    def __init__(self, model, device, params):
        super().__init__(model, device, params)
        self.threshold = params.get("threshold", 0.95)

    def compute_ssl_loss(self, logits, unlabeled_mask):
        probs = softmax(logits[unlabeled_mask], dim=1)
        max_vals, pseudo_labels = probs.max(dim=1)
        mask = max_vals >= self.threshold
        if mask.sum() == 0:
            return torch.tensor(0.0, device=self.device)
        loss = nn.CrossEntropyLoss()(logits[unlabeled_mask][mask], pseudo_labels[mask])
        return loss

# MT implementation
class MT(SSLAlgorithm):
    def __init__(self, model, device, params):
        super().__init__(model, device, params)
        self.alpha = params.get("alpha", 0.99)
        self.teacher = SimpleWRN(2, 1, model.fc.out_features).to(device)
        self.teacher.load_state_dict(model.state_dict())

    def compute_ssl_loss(self, logits, unlabeled_mask):
        preds_student = logits[unlabeled_mask]
        with torch.no_grad():
            preds_teacher = self.teacher(logits[unlabeled_mask])
        loss = nn.KLDivLoss(reduction="batchmean")(softmax(preds_student, dim=1).log(), softmax(preds_teacher, dim=1))
        return loss

    def ema_update(self, teacher, student):
        for p_t, p_s in zip(teacher.parameters(), student.parameters()):
            p_t.data.mul_(self.alpha).add_(p_s.data, alpha=1 - self.alpha)

# Placeholder for ICT, PI, MixMatch
class ICT(SSLAlgorithm):
    def compute_ssl_loss(self, logits, unlabeled_mask):
        return torch.tensor(0.0, device=self.device)

class PI(SSLAlgorithm):
    def compute_ssl_loss(self, logits, unlabeled_mask):
        return torch.tensor(0.0, device=self.device)

class MixMatch(SSLAlgorithm):
    def compute_ssl_loss(self, logits, unlabeled_mask):
        return torch.tensor(0.0, device=self.device)

ALGORITHM_MAP = {
    "vat": VAT,
    "pl": PL,
    "mt": MT,
    "ict": ICT,
    "pi": PI,
    "mixmatch": MixMatch,
}

def main():
    parser = argparse.ArgumentParser(description="SSL Training Framework")
    parser.add_argument("--alg", type=str, default="vat", choices=ALGORITHM_MAP.keys())
    parser.add_argument("--em", type=float, default=0.0, help="Entropy minimization coefficient")
    parser.add_argument("--dataset", type=str, default="cifar10", choices=config.keys())
    parser.add_argument("--output", type=str, default="./output")
    parser.add_argument("--validation", type=int, default=1000, help="Validation interval")
    parser.add_argument("--lr_decay_iter", type=int, default=5000, help="Iteration to decay lr")
    args = parser.parse_args()

    os.makedirs(args.output, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    torch.backends.cudnn.benchmark = True

    ds_cfg = config[args.dataset]
    num_classes = ds_cfg.num_classes

    l_train_ds = ds_cfg.get_split("train")
    u_train_ds = ds_cfg.get_split("train")
    val_ds = ds_cfg.get_split("val")
    test_ds = ds_cfg.get_split("test")

    # Statistics
    print(f"Labeled: {len(l_train_ds)}, Unlabeled: {len(u_train_ds)}, Val: {len(val_ds)}, Test: {len(test_ds)}")

    batch_size = ds_cfg.batch_size
    if args.alg != "supervised":
        batch_size = batch_size // 2

    l_loader = data.DataLoader(
        l_train_ds,
        batch_size=batch_size,
        sampler=CustomRandomSampler(l_train_ds, replacement=False),
        num_workers=4,
        pin_memory=True,
    )
    u_loader = data.DataLoader(
        u_train_ds,
        batch_size=batch_size,
        sampler=CustomRandomSampler(u_train_ds, replacement=False),
        num_workers=4,
        pin_memory=True,
    )
    val_loader = data.DataLoader(
        val_ds, batch_size=128, shuffle=False, num_workers=4, pin_memory=True
    )
    test_loader = data.DataLoader(
        test_ds, batch_size=128, shuffle=False, num_workers=4, pin_memory=True
    )

    model = SimpleWRN(2, 1, num_classes).to(device)
    ds_cfg.transform_fn(model)

    algorithm_params = {"epsilon": 1.0, "xi": 0.01, "num_power_iter": 1, "alpha": 0.99, "threshold": 0.95}
    algorithm = ALGORITHM_MAP[args.alg](model, device, algorithm_params)

    optimizer = optim.Adam(model.parameters(), lr=0.001)
    lr_scheduler = optim.lr_scheduler.MultiStepLR(optimizer, milestones=[args.lr_decay_iter], gamma=0.1)

    criterion = nn.CrossEntropyLoss()
    best_val_acc = 0.0
    best_test_acc = 0.0

    start_time = time.time()
    max_iter = min(len(l_loader), len(u_loader))
    for epoch in range(1000):  # large number, will break by condition
        for i, ((l_imgs, l_targets), (u_imgs, _)) in enumerate(zip(l_loader, u_loader)):
            if i >= max_iter:
                break
            model.train()
            l_imgs = l_imgs.to(device)
            l_targets = l_targets.to(device)
            u_imgs = u_imgs.to(device)

            inputs = torch.cat([l_imgs, u_imgs], dim=0)
            logits = model(inputs)
            sup_loss = criterion(logits[:len(l_imgs)], l_targets)

            unlabeled_mask = torch.tensor([False] * len(l_imgs) + [True] * len(u_imgs), device=device)
            ssl_loss = algorithm.compute_ssl_loss(logits, unlabeled_mask)

            loss = sup_loss + ssl_loss
            if args.em > 0.0:
                entropy = -(softmax(logits, dim=1) * softmax(logits, dim=1).log()).sum(dim=1).mean()
                loss -= args.em * entropy

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            if hasattr(algorithm, "ema_update"):
                algorithm.ema_update(algorithm.teacher, model)

            if (i + 1) % args.validation == 0:
                model.eval()
                correct = 0
                total = 0
                with torch.no_grad():
                    for val_imgs, val_targets in val_loader:
                        val_imgs = val_imgs.to(device)
                        val_targets = val_targets.to(device)
                        outputs = model(val_imgs)
                        _, preds = outputs.max(1)
                        correct += preds.eq(val_targets).sum().item()
                        total += val_targets.size(0)
                val_acc = correct / total
                print(f"Epoch {epoch}, Iter {i+1}, Val Acc: {val_acc:.4f}")
                if val_acc > best_val_acc:
                    best_val_acc = val_acc
                    # Test
                    model.eval()
                    correct = 0
                    total = 0
                    with torch.no_grad():
                        for test_imgs, test_targets in test_loader:
                            test_imgs = test_imgs.to(device)
                            test_targets = test_targets.to(device)
                            outputs = model(test_imgs)
                            _, preds = outputs.max(1)
                            correct += preds.eq(test_targets).sum().item()
                            total += test_targets.size(0)
                    best_test_acc = correct / total
                    print(f"New best! Test Acc: {best_test_acc:.4f}")

            if i == max_iter - 1:
                break

        if epoch == 0 and i == max_iter - 1:
            # Only run one epoch for brevity
            break

    elapsed = time.time() - start_time
    print(f"Training finished in {elapsed:.2f}s. Best Test Acc: {best_test_acc:.4f}")

    result = {
        "dataset": args.dataset,
        "algorithm": args.alg,
        "entropy_minimization": args.em,
        "best_test_accuracy": best_test_acc,
        "training_time_sec": elapsed,
    }
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_path = os.path.join(args.output, f"result_{timestamp}.json")
    with open(out_path, "w") as f:
        json.dump(result, f, indent=2)

if __name__ == "__main__":
    main()
