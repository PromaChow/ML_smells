import gym
import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt
from huskarl.agent.dqn import DQNAgent
from huskarl.simulation import Simulation

# 1. Environment Setup
env_creator = lambda: gym.make('CartPole-v0').unwrapped
dummy_env = env_creator()
obs_dim = dummy_env.observation_space.shape[0]
action_dim = dummy_env.action_space.n

# 2. Neural Network Construction
class QNetwork(nn.Module):
    def __init__(self, input_dim: int, output_dim: int):
        super().__init__()
        self.model = nn.Sequential(
            nn.Linear(input_dim, 16),
            nn.ReLU(),
            nn.Linear(16, 16),
            nn.ReLU(),
            nn.Linear(16, 16),
            nn.ReLU(),
            nn.Linear(16, output_dim)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.model(x)

model = QNetwork(obs_dim, action_dim)

# 3. Agent Initialization
agent = DQNAgent(
    env=env_creator(),
    model=model,
    lr=1e-3,
    gamma=0.99,
    nsteps=2,
    buffer_size=10000,
    batch_size=64,
    epsilon_start=1.0,
    epsilon_end=0.01,
    epsilon_decay=0.995
)

# 4. Reward Visualization Function
def plot_rewards(rewards, title='Cumulative Rewards'):
    plt.figure(figsize=(10, 5))
    plt.plot(rewards, label='Episode Reward')
    plt.xlabel('Episode')
    plt.ylabel('Cumulative Reward')
    plt.title(title)
    plt.legend()
    plt.grid(True)
    plt.show()

# 5. Training and Testing
def train_agent(agent: DQNAgent, max_steps: int = 3000):
    episode_rewards = []
    state = agent.env.reset()
    total_steps = 0
    while total_steps < max_steps:
        episode_reward = 0
        done = False
        while not done:
            action = agent.select_action(state)
            next_state, reward, done, _ = agent.env.step(action)
            agent.store_transition(state, action, reward, next_state, done)
            agent.learn()
            state = next_state
            episode_reward += reward
            total_steps += 1
            if total_steps >= max_steps:
                break
        episode_rewards.append(episode_reward)
        state = agent.env.reset()
        plot_rewards(episode_rewards)
    return episode_rewards

def test_agent(agent: DQNAgent, test_steps: int = 1000):
    state = agent.env.reset()
    total_reward = 0
    for _ in range(test_steps):
        action = agent.select_action(state, evaluate=True)
        next_state, reward, done, _ = agent.env.step(action)
        total_reward += reward
        state = next_state
        if done:
            state = agent.env.reset()
    print(f"Test over {test_steps} steps: Total reward = {total_reward}")

# Run training and testing
train_agent(agent, max_steps=3000)
test_agent(agent, test_steps=1000)