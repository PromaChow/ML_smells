import random
import pygame
from ple import PLE
from ple.games.raycastmaze import RaycastMaze


class NaiveAgent:
    def __init__(self, action_set):
        self.action_set = action_set

    def get_action(self):
        return random.choice(self.action_set)


def main():
    pygame.init()
    game = RaycastMaze(map_size=6)
    action_set = game.get_action_set()

    ple = PLE(
        game,
        fps=30,
        display_screen=True,
        force_fps=False,
        frame_skip=2,
        max_steps_per_action=1,
    )

    agent = NaiveAgent(action_set)

    # Initial NOOPs
    noop_count = random.randint(0, 20)
    for _ in range(noop_count):
        ple.act(action_set[0])

    for frame in range(15000):
        if ple.game_over():
            ple.reset_game()
        obs = ple.get_screen()
        action = agent.get_action()
        ple.act(action)
        if frame % 50 == 0:
            surface = pygame.surfarray.make_surface(obs.swapaxes(0, 1))
            pygame.image.save(surface, "screen_capture.png")


if __name__ == "__main__":
    main()
