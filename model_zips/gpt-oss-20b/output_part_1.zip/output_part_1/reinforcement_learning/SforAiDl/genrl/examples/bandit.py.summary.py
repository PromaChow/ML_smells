import os
from pathlib import Path

import matplotlib.pyplot as plt
import genrl

def main():
    # Bandit initialization
    bandit = genrl.bandits.CovertypeDataBandit()

    # Agent setup
    agent = genrl.agents.NeuralLinearPosteriorAgent(bandit)

    # Trainer configuration
    log_dir = Path("logs")
    log_dir.mkdir(parents=True, exist_ok=True)
    trainer = genrl.trainers.DCBTrainer(
        agent,
        bandit,
        log_dir=log_dir,
        log_modes=["stdout", "tensorboard"],
    )

    # Training execution
    trainer.train(steps=100)

    # Retrieve results
    results = trainer.results

    # Prepare metric lists
    cum_regret = results.get("cumulative_regret", [])
    cum_reward = results.get("cumulative_reward", [])
    regret_ma = results.get("regret_ma", [])
    reward_ma = results.get("reward_ma", [])

    # Plotting
    fig, axes = plt.subplots(2, 2, figsize=(12, 8))
    axes[0, 0].plot(cum_regret, label="Cumulative Regret")
    axes[0, 0].set_title("Cumulative Regret")
    axes[0, 0].set_xlabel("Timestep")
    axes[0, 0].set_ylabel("Regret")
    axes[0, 0].legend()

    axes[0, 1].plot(cum_reward, label="Cumulative Reward")
    axes[0, 1].set_title("Cumulative Reward")
    axes[0, 1].set_xlabel("Timestep")
    axes[0, 1].set_ylabel("Reward")
    axes[0, 1].legend()

    axes[1, 0].plot(regret_ma, label="Regret Moving Average")
    axes[1, 0].set_title("Regret Moving Average")
    axes[1, 0].set_xlabel("Timestep")
    axes[1, 0].set_ylabel("Regret MA")
    axes[1, 0].legend()

    axes[1, 1].plot(reward_ma, label="Reward Moving Average")
    axes[1, 1].set_title("Reward Moving Average")
    axes[1, 1].set_xlabel("Timestep")
    axes[1, 1].set_ylabel("Reward MA")
    axes[1, 1].legend()

    plt.tight_layout()
    output_path = log_dir / "dcb_example.png"
    plt.savefig(output_path)
    plt.close(fig)

if __name__ == "__main__":
    main()