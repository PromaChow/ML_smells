import argparse
import logging
import os
import random
import sys
import time
from collections import deque
from datetime import datetime

import gym
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import torch.distributions as dist
from torch.autograd import Variable

# ---------- Argument Parsing ----------
parser = argparse.ArgumentParser(description="SAC training script for Mujoco environments.")
parser.add_argument("--env", default="Hopper-v2", help="Gym environment name.")
parser.add_argument("--num-envs", type=int, default=1, help="Number of parallel environments.")
parser.add_argument("--seed", type=int, default=0, help="Random seed.")
parser.add_argument("--gpu", type=int, default=0, help="GPU id to use.")
parser.add_argument("--buffer-size", type=int, default=1000000, help="Replay buffer size.")
parser.add_argument("--batch-size", type=int, default=256, help="Mini-batch size.")
parser.add_argument("--steps", type=int, default=1000000, help="Total training steps.")
parser.add_argument("--eval-interval", type=int, default=5000, help="Evaluation interval.")
parser.add_argument("--eval-n-runs", type=int, default=10, help="Number of evaluation runs.")
parser.add_argument("--logger-level", default="INFO", help="Logging level.")
parser.add_argument("--debug", action="store_true", help="Enable debug mode.")
parser.add_argument("--render", action="store_true", help="Render environments.")
parser.add_argument("--demo", action="store_true", help="Run demo mode.")
parser.add_argument("--load", type=str, default="", help="Load model from path.")
parser.add_argument("--load-pretrained", action="store_true", help="Load pretrained model.")
parser.add_argument("--monitor", action="store_true", help="Record monitoring data.")
parser.add_argument("--output-dir", default="experiments", help="Base output directory.")
args = parser.parse_args()

# ---------- Logging ----------
logging.basicConfig(
    level=getattr(logging, args.logger_level.upper(), logging.INFO),
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
logger = logging.getLogger()

# ---------- Output Directory ----------
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
out_dir = os.path.join(args.output_dir, f"{args.env}_{timestamp}")
os.makedirs(out_dir, exist_ok=True)
logger.info(f"Output directory: {out_dir}")

# ---------- Random Seeds ----------
def set_global_seeds(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

set_global_seeds(args.seed)
torch.set_num_threads(1)

device = torch.device(f"cuda:{args.gpu}" if torch.cuda.is_available() else "cpu")
logger.info(f"Using device: {device}")

# ---------- Environment Creation ----------
def make_env(seed, env_name, render=False, monitor=False):
    def _thunk():
        env = gym.make(env_name)
        env.seed(seed)
        env.action_space.seed(seed)
        if monitor:
            env = gym.wrappers.Monitor(env, os.path.join(out_dir, "monitor"), video_callable=lambda x: False)
        if render:
            env = gym.wrappers.Render(env)
        return env
    return _thunk

process_seeds = np.arange(args.num_envs) + args.seed * args.num_envs
env_fns = [make_env(int(process_seeds[i]), args.env, render=args.render, monitor=args.monitor) for i in range(args.num_envs)]
vec_env = gym.vector.AsyncVectorEnv(env_fns) if args.num_envs > 1 else gym.vector.VectorEnv([env_fns[0]])

# ---------- Observation & Action Space ----------
obs_space = vec_env.single_observation_space
act_space = vec_env.single_action_space
obs_dim = obs_space.shape[0]
act_dim = act_space.shape[0]
logger.info(f"Observation dim: {obs_dim}, Action dim: {act_dim}")

# ---------- Networks ----------
def init_weights(m):
    if isinstance(m, nn.Linear):
        nn.init.xavier_uniform_(m.weight)
        nn.init.constant_(m.bias, 0.0)

class PolicyNet(nn.Module):
    def __init__(self, obs_dim, act_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim, 256), nn.ReLU(),
            nn.Linear(256, 256), nn.ReLU(),
            nn.Linear(256, act_dim * 2)
        )
        self.apply(init_weights)

    def forward(self, x):
        x = self.net(x)
        mu, log_std = torch.chunk(x, 2, dim=-1)
        log_std = torch.clamp(log_std, -20, 2)
        std = torch.exp(log_std)
        return mu, std

class QNet(nn.Module):
    def __init__(self, obs_dim, act_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim + act_dim, 256), nn.ReLU(),
            nn.Linear(256, 256), nn.ReLU(),
            nn.Linear(256, 1)
        )
        self.apply(init_weights)

    def forward(self, obs, act):
        x = torch.cat([obs, act], dim=-1)
        return self.net(x)

policy = PolicyNet(obs_dim, act_dim).to(device)
q1 = QNet(obs_dim, act_dim).to(device)
q2 = QNet(obs_dim, act_dim).to(device)
q1_target = QNet(obs_dim, act_dim).to(device)
q2_target = QNet(obs_dim, act_dim).to(device)
q1_target.load_state_dict(q1.state_dict())
q2_target.load_state_dict(q2.state_dict())

policy_optimizer = optim.Adam(policy.parameters(), lr=3e-4)
q1_optimizer = optim.Adam(q1.parameters(), lr=3e-4)
q2_optimizer = optim.Adam(q2.parameters(), lr=3e-4)
alpha = Variable(torch.tensor(0.2, device=device), requires_grad=True)
alpha_optimizer = optim.Adam([alpha], lr=3e-4)

# ---------- Replay Buffer ----------
class ReplayBuffer:
    def __init__(self, capacity):
        self.capacity = capacity
        self.buffer = deque(maxlen=capacity)

    def push(self, obs, act, rew, next_obs, done):
        self.buffer.append((obs, act, rew, next_obs, done))

    def sample(self, batch_size):
        batch = random.sample(self.buffer, batch_size)
        obs, act, rew, next_obs, done = map(np.stack, zip(*batch))
        return (
            torch.tensor(obs, dtype=torch.float32, device=device),
            torch.tensor(act, dtype=torch.float32, device=device),
            torch.tensor(rew, dtype=torch.float32, device=device).unsqueeze(1),
            torch.tensor(next_obs, dtype=torch.float32, device=device),
            torch.tensor(done, dtype=torch.float32, device=device).unsqueeze(1),
        )

    def __len__(self):
        return len(self.buffer)

replay_buffer = ReplayBuffer(args.buffer_size)

# ---------- SAC Agent ----------
def soft_update(target, source, tau=0.005):
    for target_param, source_param in zip(target.parameters(), source.parameters()):
        target_param.data.copy_(tau * source_param.data + (1 - tau) * target_param.data)

def compute_target(q1, q2, next_obs, rewards, dones, gamma=0.99):
    with torch.no_grad():
        mu, std = policy(next_obs)
        dist_norm = dist.Normal(mu, std)
        z = dist_norm.rsample()
        action = torch.tanh(z)
        logp = dist_norm.log_prob(z) - torch.log(1 - action.pow(2) + 1e-6)
        logp = logp.sum(-1, keepdim=True)
        q1_next = q1_target(next_obs, action)
        q2_next = q2_target(next_obs, action)
        q_next = torch.min(q1_next, q2_next) - alpha * logp
        target = rewards + (1 - dones) * gamma * q_next
    return target

def sac_update():
    if len(replay_buffer) < args.batch_size:
        return
    obs, act, rew, next_obs, done = replay_buffer.sample(args.batch_size)

    # Q1 loss
    q1_val = q1(obs, act)
    target = compute_target(q1, q2, next_obs, rew, done)
    q1_loss = nn.functional.mse_loss(q1_val, target)

    # Q2 loss
    q2_val = q2(obs, act)
    q2_loss = nn.functional.mse_loss(q2_val, target)

    # Policy loss
    mu, std = policy(obs)
    dist_norm = dist.Normal(mu, std)
    z = dist_norm.rsample()
    action = torch.tanh(z)
    logp = dist_norm.log_prob(z) - torch.log(1 - action.pow(2) + 1e-6)
    logp = logp.sum(-1, keepdim=True)
    q1_pi = q1(obs, action)
    q2_pi = q2(obs, action)
    q_pi = torch.min(q1_pi, q2_pi)
    policy_loss = (alpha * logp - q_pi).mean()

    # Alpha loss
    alpha_loss = -(alpha * (logp + target.mean())).mean()

    # Optimize
    q1_optimizer.zero_grad()
    q1_loss.backward()
    q1_optimizer.step()

    q2_optimizer.zero_grad()
    q2_loss.backward()
    q2_optimizer.step()

    policy_optimizer.zero_grad()
    policy_loss.backward()
    policy_optimizer.step()

    alpha_optimizer.zero_grad()
    alpha_loss.backward()
    alpha_optimizer.step()

    # Soft update targets
    soft_update(q1_target, q1)
    soft_update(q2_target, q2)

# ---------- Evaluation ----------
def evaluate_policy(env, n_runs=10):
    returns = []
    for _ in range(n_runs):
        obs = env.reset()
        done = False
        total_r = 0.0
        while not done:
            obs_t = torch.tensor(obs, dtype=torch.float32, device=device).unsqueeze(0)
            with torch.no_grad():
                mu, _ = policy(obs_t)
                action = torch.tanh(mu).cpu().numpy()[0]
            obs, r, done, _ = env.step(action)
            total_r += r
        returns.append(total_r)
    returns = np.array(returns)
    logger.info(f"Eval returns: mean={returns.mean():.2f}, median={np.median(returns):.2f}, std={returns.std():.2f}")
    return returns.mean()

# ---------- Training Loop ----------
if args.demo:
    test_env = gym.make(args.env)
    evaluate_policy(test_env, args.eval_n_runs)
    sys.exit(0)

total_steps = 0
obs = vec_env.reset()
while total_steps < args.steps:
    for _ in range(args.num_envs):
        with torch.no_grad():
            mu, _ = policy(torch.tensor(obs, dtype=torch.float32, device=device))
            action = torch.tanh(mu).cpu().numpy()
        next_obs, rew, done, _ = vec_env.step(action)
        replay_buffer.push(obs, action, rew, next_obs, done)
        obs = next_obs
        total_steps += 1

        sac_update()

        if total_steps % args.eval_interval == 0:
            test_env = gym.make(args.env)
            evaluate_policy(test_env, args.eval_n_runs)

    if total_steps % 1000 == 0:
        logger.info(f"Step: {total_steps}/{args.steps}")

# ---------- Save Model ----------
torch.save({
    "policy_state_dict": policy.state_dict(),
    "q1_state_dict": q1.state_dict(),
    "q2_state_dict": q2.state_dict(),
    "q1_target_state_dict": q1_target.state_dict(),
    "q2_target_state_dict": q2_target.state_dict(),
    "policy_optimizer_state_dict": policy_optimizer.state_dict(),
    "q1_optimizer_state_dict": q1_optimizer.state_dict(),
    "q2_optimizer_state_dict": q2_optimizer.state_dict(),
    "alpha_state_dict": alpha,
    "alpha_optimizer_state_dict": alpha_optimizer.state_dict(),
    "seed": args.seed,
}, os.path.join(out_dir, "sac_final.pth"))
logger.info("Training finished and model saved.")
