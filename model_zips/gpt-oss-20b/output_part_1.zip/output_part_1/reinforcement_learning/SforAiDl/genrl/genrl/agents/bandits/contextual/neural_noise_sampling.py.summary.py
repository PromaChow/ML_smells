import math
import random
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from collections import deque
from typing import List, Tuple


class DataBasedBandit:
    """Placeholder environment interface."""

    def __init__(self, n_actions: int, context_dim: int):
        self.n_actions = n_actions
        self.context_dim = context_dim

    def get_context(self) -> torch.Tensor:
        return torch.randn(self.context_dim)

    def get_reward(self, action: int) -> float:
        # Simple synthetic reward: higher reward for action 0
        base = random.random()
        return base + (1.0 if action == 0 else 0.0)


class NeuralBanditModel(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int, n_actions: int, dropout: bool = False):
        super().__init__()
        self.dropout = dropout
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, n_actions)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = F.relu(self.fc1(x))
        if self.dropout:
            x = F.dropout(x, p=0.5, training=self.training)
        return self.fc2(x)


class TransitionDB:
    def __init__(self, capacity: int = 100000):
        self.buffer = deque(maxlen=capacity)

    def add(self, context: torch.Tensor, action: int, reward: float):
        self.buffer.append((context, action, reward))

    def sample(self, batch_size: int) -> List[Tuple[torch.Tensor, int, float]]:
        batch = random.sample(self.buffer, min(batch_size, len(self.buffer)))
        return batch

    def __len__(self):
        return len(self.buffer)


class NeuralBanditAgent:
    def __init__(
        self,
        env: DataBasedBandit,
        hidden_dim: int = 64,
        lr: float = 1e-3,
        noise_std_dev: float = 0.1,
        eps: float = 0.1,
        init_pulls: int = 10,
        update_interval: int = 50,
        epochs: int = 5,
        batch_size: int = 32,
        dropout: bool = False,
    ):
        self.env = env
        self.n_actions = env.n_actions
        self.context_dim = env.context_dim
        self.model = NeuralBanditModel(
            input_dim=self.context_dim + self.n_actions,
            hidden_dim=hidden_dim,
            n_actions=self.n_actions,
            dropout=dropout,
        )
        self.optimizer = optim.Adam(self.model.parameters(), lr=lr)
        self.transition_db = TransitionDB()
        self.noise_std_dev = noise_std_dev
        self.eps = eps
        self.init_pulls = init_pulls
        self.update_interval = update_interval
        self.epochs = epochs
        self.batch_size = batch_size
        self.t = 0
        self.update_count = 0

    def _get_input(self, context: torch.Tensor, action: int = None) -> torch.Tensor:
        if action is None:
            action_onehot = torch.zeros(self.n_actions)
        else:
            action_onehot = torch.zeros(self.n_actions)
            action_onehot[action] = 1.0
        return torch.cat([context, action_onehot])

    def _sample_noise(self) -> List[torch.Tensor]:
        noise = []
        for param in self.model.parameters():
            noise.append(torch.randn_like(param) * self.noise_std_dev)
        return noise

    def _apply_noise(self, noise: List[torch.Tensor]):
        for param, n in zip(self.model.parameters(), noise):
            param.data.add_(n)

    def _reset_noise(self, noise: List[torch.Tensor]):
        for param, n in zip(self.model.parameters(), noise):
            param.data.sub_(n)

    def _noisy_prediction(self, context: torch.Tensor) -> torch.Tensor:
        noise = self._sample_noise()
        self._apply_noise(noise)
        with torch.no_grad():
            logits = self.model(self._get_input(context))
        self._reset_noise(noise)
        return logits

    def _clean_prediction(self, context: torch.Tensor) -> torch.Tensor:
        with torch.no_grad():
            logits = self.model(self._get_input(context))
        return logits

    def select_action(self, context: torch.Tensor) -> int:
        if self.t < self.init_pulls * self.n_actions:
            action = self.t % self.n_actions
        else:
            logits = self._noisy_prediction(context)
            action = int(torch.argmax(logits).item())
        self.t += 1
        return action

    def update_transition(self, context: torch.Tensor, action: int, reward: float):
        self.transition_db.add(context, action, reward)

    def train_model(self):
        if len(self.transition_db) < self.batch_size:
            return
        for _ in range(self.epochs):
            batch = self.transition_db.sample(self.batch_size)
            contexts, actions, rewards = zip(*batch)
            inputs = torch.stack([self._get_input(c, a) for c, a in zip(contexts, actions)])
            rewards_tensor = torch.tensor(rewards, dtype=torch.float32)
            self.model.train()
            logits = self.model(inputs)
            preds = logits.gather(1, torch.tensor(actions).unsqueeze(1)).squeeze()
            loss = F.mse_loss(preds, rewards_tensor)
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()

    def _update_noise(self):
        if len(self.transition_db) < self.batch_size:
            return
        batch = self.transition_db.sample(self.batch_size)
        contexts, actions, rewards = zip(*batch)
        inputs_clean = torch.stack([self._get_input(c, a) for c, a in zip(contexts, actions)])
        with torch.no_grad():
            logits_clean = self.model(inputs_clean)
            probs_clean = F.softmax(logits_clean, dim=1)
        logits_noisy = self._noisy_prediction_batch(contexts)
        probs_noisy = F.softmax(logits_noisy, dim=1)
        kl = torch.sum(probs_clean * (torch.log(probs_clean + 1e-10) - torch.log(probs_noisy + 1e-10)), dim=1).mean().item()
        delta = -math.log(1 - self.eps + self.eps / self.n_actions)
        if kl < delta:
            self.noise_std_dev *= 1.0101
        else:
            self.noise_std_dev /= 1.0101
        self.eps *= 0.99

    def _noisy_prediction_batch(self, contexts: List[torch.Tensor]) -> torch.Tensor:
        noise = self._sample_noise()
        self._apply_noise(noise)
        with torch.no_grad():
            inputs = torch.stack([self._get_input(c) for c in contexts])
            logits = self.model(inputs)
        self._reset_noise(noise)
        return logits

    def step(self):
        context = self.env.get_context()
        action = self.select_action(context)
        reward = self.env.get_reward(action)
        self.update_transition(context, action, reward)
        if self.t % self.update_interval == 0:
            self.train_model()
            self._update_noise()


def main():
    env = DataBasedBandit(n_actions=5, context_dim=10)
    agent = NeuralBanditAgent(env)
    for _ in range(1000):
        agent.step()


if __name__ == "__main__":
    main()
