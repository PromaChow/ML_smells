import argparse
import os
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim

# rlpyt imports
from rlpyt.envs.atari import wrap_deepmind
from rlpyt.envs import atari as env_atari
from rlpyt.models import links
from rlpyt.models import nn as nn_models
from rlpyt.models import misc as model_misc
from rlpyt.algos import nsq
from rlpyt.samplers.async_sampler import AsyncSampler
from rlpyt.runners.async_train import train_agent_async
from rlpyt.utils.logging import get_logger, create_outdir
from rlpyt.utils.misc import set_random_seed
from rlpyt.utils.data import ReplayBuffer
from rlpyt.utils.batch import batch_to_device
from rlpyt.agents.nsq import NSQAgent
from rlpyt.explorers import linear_decay_epsilon_greedy
from rlpyt.hooks import linear_interpolation_hook
from rlpyt.algos.nsq import nsq
from rlpyt.utils.logging import monitor_logger

# ----------------------------------------------------------------------
# Custom network components
# ----------------------------------------------------------------------
class NIPSDQNHead(nn.Module):
    """Custom convolutional head for feature extraction."""
    def __init__(self, input_shape):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(input_shape[0], 32, kernel_size=8, stride=4),
            nn.ReLU(),
            nn.Conv2d(32, 64, kernel_size=4, stride=2),
            nn.ReLU(),
            nn.Conv2d(64, 64, kernel_size=3, stride=1),
            nn.ReLU(),
            nn.Flatten()
        )

    def forward(self, x):
        return self.conv(x)

class DiscreteActionValue(nn.Module):
    """Head that maps features to action values."""
    def __init__(self, input_dim, num_actions):
        super().__init__()
        self.fc = nn.Linear(input_dim, num_actions)

    def forward(self, x):
        return self.fc(x)

# ----------------------------------------------------------------------
# Argument parsing
# ----------------------------------------------------------------------
def parse_args():
    parser = argparse.ArgumentParser(description="NSQ agent for Breakout")
    parser.add_argument("--env", default="BreakoutNoFrameskip-v4")
    parser.add_argument("--processes", type=int, default=8)
    parser.add_argument("--lr", type=float, default=0.0005)
    parser.add_argument("--steps", type=int, default=10_000_000)
    parser.add_argument("--final_exploration_frames", type=int, default=1_000_000)
    parser.add_argument("--eval_interval", type=int, default=10_000_000)
    parser.add_argument("--eval_n_runs", type=int, default=10)
    parser.add_argument("--outdir", default="out")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--demo", action="store_true")
    parser.add_argument("--load", help="Path to a checkpoint")
    parser.add_argument("--monitor", action="store_true")
    parser.add_argument("--render", action="store_true")
    args = parser.parse_args()
    return args

# ----------------------------------------------------------------------
# Feature extractor
# ----------------------------------------------------------------------
def phi(x):
    return np.asarray(x, dtype=np.float32) / 255.0

# ----------------------------------------------------------------------
# Environment creation
# ----------------------------------------------------------------------
def make_env(process_idx, test=False):
    env_seed = 2**31 - 1 - (np.arange(args.processes) + args.seed * args.processes)[process_idx]
    env = env_atari.make_atari_env(
        env_id=args.env,
        seed=int(env_seed),
        frame_stack=True,
        clip_rewards=False if test else True,
        scale_obs=False,
        life_loss=True
    )
    if args.monitor:
        env = env_atari.ATARI_ENV_MONITOR(env, args.outdir, process_idx)
    if args.render:
        env = env_atari.ATARI_ENV_RENDER(env)
    return env

# ----------------------------------------------------------------------
# Agent creation
# ----------------------------------------------------------------------
def make_agent(process_idx, action_space):
    # Random epsilon target
    eps_target = np.random.choice([0.1, 0.01, 0.5])
    explorer = linear_decay_epsilon_greedy.LinearDecayEpsilonGreedy(
        eps_start=1.0,
        eps_end=eps_target,
        steps=args.final_exploration_frames
    )
    # Model definition
    input_shape = (4, 84, 84)  # after DeepMind wrappers
    head = NIPSDQNHead(input_shape)
    output_layer = nn.Linear(64 * 7 * 7, action_space.n)
    model = links.Sequence(head, output_layer, DiscreteActionValue(64 * 7 * 7, action_space.n))
    optimizer = optim.RMSprop(model.parameters(), lr=args.lr, eps=1e-1, alpha=0.99)
    agent = NSQAgent(
        algo_cls=nsq.NSQ,
        algo_kwargs=dict(
            t_max=5,
            gamma=0.99,
            i_target=40000,
            phi=phi,
            optimizer=optimizer
        ),
        explorer=explorer,
        model=model
    )
    return agent

# ----------------------------------------------------------------------
# Evaluation
# ----------------------------------------------------------------------
def eval_performance(agent, env, n_runs=10):
    rewards = []
    for _ in range(n_runs):
        obs = env.reset()
        done = False
        total = 0.0
        while not done:
            action = agent.act(obs, deterministic=True)
            obs, reward, done, info = env.step(action)
            total += reward
        rewards.append(total)
    rewards = np.array(rewards)
    print(f"Eval: mean={rewards.mean():.2f}, median={np.median(rewards):.2f}, std={rewards.std():.2f}")

# ----------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------
def main():
    global args
    args = parse_args()
    os.environ["OMP_NUM_THREADS"] = "1"
    set_random_seed(args.seed)

    process_seeds = np.arange(args.processes) + args.seed * args.processes

    if args.demo:
        from rlpyt.utils.data import load_agent
        agent = load_agent(args.load)
        test_env = make_env(0, test=True)
        eval_performance(agent, test_env, n_runs=args.eval_n_runs)
        return

    # Training
    outdir = create_outdir(args.outdir)
    monitor_logger.setup(outdir)

    # Hook for LR decay
    lr_hook = linear_interpolation_hook.LinearInterpolationHook(
        param_name="lr",
        start_value=args.lr,
        end_value=0.0,
        total_steps=args.steps
    )

    # Create agents per process
    agent_factory = lambda i: make_agent(i, atari_env.action_space(args.env))
    sampler = AsyncSampler(
        env_fns=[lambda i=i: make_env(i) for i in range(args.processes)],
        process_seeds=process_seeds,
        num_envs_per_process=1
    )
    train_agent_async(
        env_fns=[lambda i=i: make_env(i) for i in range(args.processes)],
        process_seeds=process_seeds,
        agent_factory=agent_factory,
        sampler=sampler,
        steps=args.steps,
        eval_interval=args.eval_interval,
        eval_n_steps=20000,
        eval_n_runs=args.eval_n_runs,
        outdir=outdir,
        hooks=[lr_hook]
    )

if __name__ == "__main__":
    main()
