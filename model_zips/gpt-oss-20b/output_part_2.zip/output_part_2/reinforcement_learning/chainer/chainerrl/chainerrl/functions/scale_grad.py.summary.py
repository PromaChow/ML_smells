import numpy as np
import chainer
from chainer import Function, type_check


class ScaleGrad(Function):
    """Custom Chainer function that scales gradients during backpropagation."""

    def __init__(self, scale):
        self.scale = scale

    def check_type_forward(self, in_types):
        """Ensure the input is a single float32 tensor."""
        type_check(self, in_types, in_type=chainer.Variable, in_dtype=np.float32)

    def forward(self, inputs):
        """Identity forward pass."""
        x, = inputs
        return (x,)

    def backward(self, inputs, grad_outputs):
        """Scale the gradient by the specified factor."""
        gy, = grad_outputs
        return (gy * self.scale,)


def scale_grad(x, scale):
    """Apply the ScaleGrad function to a tensor."""
    return ScaleGrad(scale)(x)