import chainer
from chainer import ChainList, Sequential
from chainer.utils import cached_property
from chainer.recurrent import StatelessRecurrentChainList
import chainer.functions as F
import numpy as np


def split_batched_sequences(batched):
    """Split a batched input into a list of time step tensors."""
    if isinstance(batched, chainer.Variable):
        data = batched.data
    else:
        data = np.array(batched)
    seq_len = data.shape[0]
    return [chainer.Variable(data[i]) for i in range(seq_len)]


def concatenate_sequences(sequences):
    """Concatenate a list of time step tensors into a batched tensor."""
    data_list = [s.data if isinstance(s, chainer.Variable) else s for s in sequences]
    concatenated = np.concatenate(data_list, axis=0)
    return chainer.Variable(concatenated)


def call_recurrent_link(layer, h, state):
    """Call a recurrent link with input h and state."""
    if state is None:
        return layer(h)
    else:
        return layer(h, state)


def is_recurrent_link(layer):
    """Check if the layer is a recurrent link."""
    return isinstance(layer, chainer.links.RecurrentLink)


class StatelessRecurrentSequential(StatelessRecurrentChainList, Sequential):
    """Sequential container that supports stateless recurrent links."""

    def n_step_forward(
        self,
        sequences,
        output_mode="split",
        recurrent_state=None,
    ):
        if not sequences:
            raise ValueError("Input sequences must not be empty.")
        if output_mode not in ("split", "concat"):
            raise ValueError("output_mode must be 'split' or 'concat'.")

        seq_mode = isinstance(sequences, list)
        if not seq_mode:
            h = sequences
        else:
            h = sequences

        # Initialize recurrent state queue
        if recurrent_state is None:
            recurrent_state_queue = [None] * len(self.recurrent_children)
        else:
            recurrent_state_queue = list(reversed(recurrent_state))

        new_recurrent_state = []

        for layer in self._layers:
            if is_recurrent_link(layer):
                if not seq_mode:
                    h = split_batched_sequences(h)
                state = recurrent_state_queue.pop()
                output, new_state = call_recurrent_link(layer, h, state)
                h = output
                new_recurrent_state.append(new_state)
            else:
                if seq_mode:
                    h = concatenate_sequences(h)
                    seq_mode = False
                h = layer(h)

        # Post-processing output
        if output_mode == "split" and not seq_mode:
            h = split_batched_sequences(h)
            seq_mode = True
        elif output_mode == "concat" and seq_mode:
            h = concatenate_sequences(h)
            seq_mode = False

        if (output_mode == "split" and not seq_mode) or (
            output_mode == "concat" and seq_mode
        ):
            raise ValueError("Output mode mismatch after processing.")

        return h, new_recurrent_state[::-1]

    @cached_property
    def recurrent_children(self):
        """Return tuple of recurrent layers in order."""
        return tuple(filter(is_recurrent_link, self._layers))