import torch

def build_td_lambda_targets(
    target_qs: torch.Tensor,
    rewards: torch.Tensor,
    mask: torch.Tensor,
    terminated: torch.Tensor,
    gamma: float,
    td_lambda: float,
) -> torch.Tensor:
    """
    Compute TD(lambda) returns for multi‑agent experiences.

    Args:
        target_qs (torch.Tensor): Tensor of shape (B, T, A) containing target Q-values.
        rewards (torch.Tensor): Tensor of shape (B, T) containing rewards.
        mask (torch.Tensor): Tensor of shape (B, T) containing step masks (1 for valid steps, 0 for padding).
        terminated (torch.Tensor): Tensor of shape (B, T) containing termination flags (1 if episode ended at that step, 0 otherwise).
        gamma (float): Discount factor.
        td_lambda (float): Lambda parameter for TD(lambda).

    Returns:
        torch.Tensor: TD(lambda) returns of shape (B, T-1, A).
    """
    B, T, A = target_qs.shape
    ret = torch.zeros_like(target_qs)

    # Final step initialization
    termination_factor = 1.0 - torch.sum(terminated, dim=1, keepdim=True)  # shape (B, 1)
    ret[:, -1, :] = target_qs[:, -1, :] * termination_factor

    # Backward recursion
    for t in range(T - 2, -1, -1):
        next_ret = ret[:, t + 1, :]  # shape (B, A)
        next_target = target_qs[:, t + 1, :]  # shape (B, A)
        mask_t = mask[:, t].unsqueeze(-1)  # shape (B, 1)
        terminated_t = terminated[:, t].unsqueeze(-1)  # shape (B, 1)
        reward_t = rewards[:, t].unsqueeze(-1)  # shape (B, 1)

        bootstrapped = reward_t + (1.0 - td_lambda) * gamma * next_target * (1.0 - terminated_t)
        ret[:, t, :] = td_lambda * gamma * next_ret + mask_t * bootstrapped

    return ret[:, :-1, :]  # shape (B, T-1, A)