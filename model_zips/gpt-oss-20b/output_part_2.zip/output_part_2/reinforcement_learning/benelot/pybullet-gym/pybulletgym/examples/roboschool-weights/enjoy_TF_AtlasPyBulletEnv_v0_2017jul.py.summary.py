import numpy as np

def relu(x: np.ndarray) -> np.ndarray:
    return np.maximum(0, x)

def dense(input_tensor: np.ndarray, weights: np.ndarray, bias: np.ndarray) -> np.ndarray:
    return relu(np.dot(input_tensor, weights) + bias)

def main(batch_size: int = 1, input_features: int = 784) -> np.ndarray:
    # Random input tensor
    X = np.random.randn(batch_size, input_features)

    # Weights and biases (randomly initialized for demonstration)
    weights_dense1_w = np.random.randn(input_features, 512)
    weights_dense1_b = np.random.randn(512)

    weights_dense2_w = np.random.randn(512, 512)
    weights_dense2_b = np.random.randn(512)

    weights_final_w = np.random.randn(512, 30)
    weights_final_b = np.random.randn(30)

    # Forward pass
    out1 = dense(X, weights_dense1_w, weights_dense1_b)
    out2 = dense(out1, weights_dense2_w, weights_dense2_b)
    logits = np.dot(out2, weights_final_w) + weights_final_b

    return logits

if __name__ == "__main__":
    output = main(batch_size=5, input_features=784)
    print(output)