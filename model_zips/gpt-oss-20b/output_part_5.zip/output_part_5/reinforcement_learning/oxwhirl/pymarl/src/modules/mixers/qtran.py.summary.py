import torch
import torch.nn as nn
import torch.nn.functional as F
import math


class QTranBase(nn.Module):
    def __init__(self, args):
        super().__init__()
        self.n_agents = args.n_agents
        self.n_actions = args.n_actions
        self.state_shape = args.state_shape
        self.state_dim = math.prod(self.state_shape) if isinstance(self.state_shape, (list, tuple)) else self.state_shape
        self.qtran_arch = args.qtran_arch  # "coma_critic" or "qtran_paper"
        self.network_size = args.network_size  # "small" or "big"
        self.embed_dim = args.mixing_embed_dim
        self.rnn_hidden_dim = getattr(args, "rnn_hidden_dim", 64)

        # Determine Q input size
        if self.qtran_arch == "coma_critic":
            q_input_dim = self.state_dim + self.n_agents * self.n_actions
        elif self.qtran_arch == "qtran_paper":
            # We'll encode hidden + action per agent, then sum
            q_input_dim = self.state_dim + self.embed_dim
        else:
            raise ValueError(f"Unsupported qtran_arch: {self.qtran_arch}")

        # Q network
        if self.network_size == "small":
            hidden_sizes_q = [128, 128]
        elif self.network_size == "big":
            hidden_sizes_q = [256, 256, 256]
        else:
            raise ValueError(f"Unsupported network_size: {self.network_size}")
        q_layers = [nn.Linear(q_input_dim, hidden_sizes_q[0]), nn.ReLU()]
        for h_in, h_out in zip(hidden_sizes_q[:-1], hidden_sizes_q[1:]):
            q_layers += [nn.Linear(h_in, h_out), nn.ReLU()]
        q_layers += [nn.Linear(hidden_sizes_q[-1], 1)]
        self.q_network = nn.Sequential(*q_layers)

        # V network (same depth as Q)
        if self.network_size == "small":
            hidden_sizes_v = [128, 128]
        else:
            hidden_sizes_v = [256, 256, 256]
        v_layers = [nn.Linear(self.state_dim, hidden_sizes_v[0]), nn.ReLU()]
        for h_in, h_out in zip(hidden_sizes_v[:-1], hidden_sizes_v[1:]):
            v_layers += [nn.Linear(h_in, h_out), nn.ReLU()]
        v_layers += [nn.Linear(hidden_sizes_v[-1], 1)]
        self.v_network = nn.Sequential(*v_layers)

        # Action encoding network (only for qtran_paper)
        if self.qtran_arch == "qtran_paper":
            enc_layers = [
                nn.Linear(self.rnn_hidden_dim + self.n_actions, self.embed_dim),
                nn.ReLU(),
                nn.Linear(self.embed_dim, self.embed_dim),
                nn.ReLU()
            ]
            self.action_encoder = nn.Sequential(*enc_layers)

    def forward(self, batch, actions=None):
        # Batch states: (batch, seq, *state_shape)
        states = batch["states"]  # torch tensor
        batch_size, seq_len = states.shape[0], states.shape[1]
        state_flat = states.reshape(batch_size * seq_len, -1)  # (B*L, state_dim)

        if actions is None:
            actions = batch["actions_onehot"]  # (B, L, n_agents, n_actions)
            actions = actions.reshape(batch_size * seq_len, self.n_agents, self.n_actions)

        if self.qtran_arch == "coma_critic":
            # Concatenate flattened actions per agent
            actions_flat = actions.reshape(batch_size * seq_len, -1)  # (B*L, n_agents*n_actions)
            q_input = torch.cat([state_flat, actions_flat], dim=-1)  # (B*L, state_dim + n_agents*n_actions)
        else:  # qtran_paper
            hidden_states = batch["hidden_states"]  # (B, L, n_agents, rnn_hidden_dim)
            hidden_flat = hidden_states.reshape(batch_size * seq_len, self.n_agents, self.rnn_hidden_dim)
            # Concatenate hidden and action per agent
            hidden_action = torch.cat([hidden_flat, actions], dim=-1)  # (B*L, n_agents, rnn_hidden_dim + n_actions)
            # Encode each agent
            encodings = self.action_encoder(hidden_action)  # (B*L, n_agents, embed_dim)
            enc_sum = encodings.sum(dim=1)  # (B*L, embed_dim)
            q_input = torch.cat([state_flat, enc_sum], dim=-1)  # (B*L, state_dim + embed_dim)

        q_outputs = self.q_network(q_input).squeeze(-1)  # (B*L,)
        v_outputs = self.v_network(state_flat).squeeze(-1)  # (B*L,)

        return q_outputs, v_outputs

# Example usage:
# class Args:
#     n_agents = 3
#     n_actions = 5
#     state_shape = (10,)
#     qtran_arch = "qtran_paper"
#     network_size = "small"
#     mixing_embed_dim = 64
#     rnn_hidden_dim = 32
#
# args = Args()
# model = QTranBase(args)
# batch = {
#     "states": torch.randn(2, 5, *args.state_shape),
#     "actions_onehot": torch.randint(0, 2, (2, 5, args.n_agents, args.n_actions)).float(),
#     "hidden_states": torch.randn(2, 5, args.n_agents, args.rnn_hidden_dim)
# }
# q, v = model(batch)
# print(q.shape, v.shape)