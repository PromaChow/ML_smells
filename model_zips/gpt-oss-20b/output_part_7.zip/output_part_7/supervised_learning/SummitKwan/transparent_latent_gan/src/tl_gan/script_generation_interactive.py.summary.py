import os
import sys
import pickle
import datetime
import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
import matplotlib.widgets as widgets

# TensorFlow 1.x compatibility
tf.compat.v1.disable_eager_execution()
sess = tf.compat.v1.Session()

# ------------------------------------------------------------------
# Environment Setup
# ------------------------------------------------------------------
output_dir = "path_gan_explore_interactive"
os.makedirs(output_dir, exist_ok=True)

# ------------------------------------------------------------------
# Feature Direction Loading
# ------------------------------------------------------------------
with open("feature_direction.pkl", "rb") as f:
    feat_data = pickle.load(f)
feature_direction = feat_data["feature_direction"]          # shape (latent_dim, num_features)
feature_name = feat_data["feature_name"]                    # list of strings
num_feature = feature_direction.shape[1]

# ------------------------------------------------------------------
# Model Loading
# ------------------------------------------------------------------
# Assuming the PGGAN model code directory is in the current path or in PYTHONPATH
# If not, adjust the path accordingly
# sys.path.append("pggan")  # Uncomment if the model code directory is required

model_path = "karras2018iclr-celebahq-1024x1024.pkl"
with open(model_path, "rb") as f:
    model = pickle.load(f)
Gs = model["Gs"]  # Generator network
num_latent = Gs.Z_dim
num_labels = Gs.input_neurons

# ------------------------------------------------------------------
# Helper to generate image from latents and labels
# ------------------------------------------------------------------
def gen_image(latents, labels):
    img = Gs.run(
        latents,
        labels,
        truncation_psi=1.0,
        noise_mode="const",
        output_transform=dict(func=lambda x: (x + 1) / 2, nchw_to_nhwc=True),
        sess=sess,
    )
    return img[0]  # shape (H, W, 3)

# ------------------------------------------------------------------
# GUI Callback Class
# ------------------------------------------------------------------
class GuiCallback:
    def __init__(self, sess, Gs, latents, labels, feature_direction, feature_name):
        self.sess = sess
        self.Gs = Gs
        self.latents = latents
        self.labels = labels
        self.feature_direction = feature_direction
        self.feature_name = feature_name
        self.num_features = feature_direction.shape[1]
        self.locked = [False] * self.num_features
        self.step_scale = 0.5
        self.image_ax = None
        self.figure = None
        self.lock_buttons = []

    def init_gui(self, fig, image_ax):
        self.figure = fig
        self.image_ax = image_ax
        self.image_ax.axis("off")
        self.update_image()
        self.update_lock_buttons()

    def update_image(self):
        img = gen_image(self.latents, self.labels)
        self.image_ax.clear()
        self.image_ax.imshow(img)
        self.image_ax.axis("off")
        self.figure.canvas.draw_idle()

    def random_generate(self, event):
        self.latents = np.random.randn(1, num_latent).astype(np.float32)
        self.labels = np.zeros((1, num_labels), dtype=np.float32)
        self.update_image()

    def toggle_lock(self, idx, event):
        self.locked[idx] = not self.locked[idx]
        self.update_lock_buttons()
        self.update_image()

    def update_lock_buttons(self):
        for btn, locked in zip(self.lock_buttons, self.locked):
            btn.label.set_text("Unlock" if locked else "Lock")

    def adjust_feature(self, idx, sign, event):
        # Disentangle based on locked features
        from feature_axis import disentangle_feature_axis_by_idx
        current_dir = disentangle_feature_axis_by_idx(
            self.feature_direction, [i for i, l in enumerate(self.locked) if l]
        )
        vec = current_dir[:, idx]
        self.latents += (vec * self.step_scale * sign).reshape(1, -1)
        self.update_image()
        self.save_image(idx, sign)

    def save_image(self, idx, sign):
        img = gen_image(self.latents, self.labels)
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        action = "plus" if sign > 0 else "minus"
        fname = f"{timestamp}_feat{idx}_{action}.png"
        path = os.path.join(output_dir, fname)
        plt.imsave(path, img)

# ------------------------------------------------------------------
# Initial Latent Generation
# ------------------------------------------------------------------
latents = np.random.randn(1, num_latent).astype(np.float32)
labels = np.zeros((1, num_labels), dtype=np.float32)

# ------------------------------------------------------------------
# GUI Setup
# ------------------------------------------------------------------
fig = plt.figure(figsize=(10, 6))
gs = fig.add_gridspec(2, 2, width_ratios=[3, 1], height_ratios=[1, 9], wspace=0.05, hspace=0.05)
image_ax = fig.add_subplot(gs[1, 0])
control_ax = fig.add_subplot(gs[:, 1])
control_ax.axis("off")

callback = GuiCallback(sess, Gs, latents, labels, feature_direction, feature_name)
callback.init_gui(fig, image_ax)

# Random generation button
rand_ax = fig.add_axes([0.82, 0.92, 0.15, 0.05])
rand_btn = widgets.Button(rand_ax, "Random Image")
rand_btn.on_clicked(callback.random_generate)

# Feature buttons
button_width = 0.15
button_height = 0.04
start_y = 0.85
spacing = 0.07

for i in range(num_feature):
    y = start_y - i * spacing
    # '-' button
    minus_ax = fig.add_axes([0.68, y, button_width, button_height])
    minus_btn = widgets.Button(minus_ax, f"- {feature_name[i]}")
    minus_btn.on_clicked(lambda event, idx=i: callback.adjust_feature(idx, -1, event))
    # '+' button
    plus_ax = fig.add_axes([0.85, y, button_width, button_height])
    plus_btn = widgets.Button(plus_ax, f"+ {feature_name[i]}")
    plus_btn.on_clicked(lambda event, idx=i: callback.adjust_feature(idx, 1, event))
    # Lock button
    lock_ax = fig.add_axes([0.52, y, button_width, button_height])
    lock_btn = widgets.Button(lock_ax, "Lock")
    lock_btn.on_clicked(lambda event, idx=i: callback.toggle_lock(idx, event))
    callback.lock_buttons.append(lock_btn)

plt.show()