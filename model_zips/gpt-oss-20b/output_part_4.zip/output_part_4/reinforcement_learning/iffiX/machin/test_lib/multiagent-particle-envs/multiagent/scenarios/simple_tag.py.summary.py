import numpy as np

class Agent:
    def __init__(self, name, adversary=False, collide=True, size=0.05, max_speed=1.0, max_accel=0.5, color=(1, 1, 1)):
        self.name = name
        self.adversary = adversary
        self.collide = collide
        self.size = size
        self.max_speed = max_speed
        self.max_accel = max_accel
        self.color = color
        self.state = None  # placeholder for state: [pos, vel, acc, comm]

class Landmark:
    def __init__(self, name, movable=False, size=0.2, color=(0.5, 0.5, 0.5)):
        self.name = name
        self.movable = movable
        self.size = size
        self.color = color
        self.state = None

class World:
    def __init__(self, dim_c=2):
        self.dim_c = dim_c
        self.agents = []
        self.landmarks = []

def init_world():
    world = World()
    num_good = 1
    num_adversaries = 3
    num_landmarks = 2
    total_agents = num_good + num_adversaries

    for i in range(total_agents):
        adversary = i < num_adversaries
        if adversary:
            size = 0.08
            max_speed = 0.8
            max_accel = 0.4
            color = (1, 0, 0)
        else:
            size = 0.05
            max_speed = 1.0
            max_accel = 0.5
            color = (0, 1, 0)
        agent = Agent(name=f"agent {i}",
                      adversary=adversary,
                      collide=True,
                      size=size,
                      max_speed=max_speed,
                      max_accel=max_accel,
                      color=color)
        world.agents.append(agent)

    for i in range(num_landmarks):
        landmark = Landmark(name=f"landmark {i}",
                            movable=False,
                            size=0.2,
                            color=(0.5, 0.5, 0.5))
        world.landmarks.append(landmark)

    setup_world(world)
    return world

def setup_world(world):
    for agent in world.agents:
        pos = np.random.uniform(-1, 1, size=2)
        vel = np.zeros(2)
        acc = np.zeros(2)
        comm = np.zeros(world.dim_c)
        agent.state = np.concatenate([pos, vel, acc, comm])

    for landmark in world.landmarks:
        pos = np.random.uniform(-0.9, 0.9, size=2)
        vel = np.zeros(2)
        acc = np.zeros(2)
        landmark.state = np.concatenate([pos, vel, acc])

def distance(a, b):
    return np.linalg.norm(a - b)

def collision(a, b):
    a_pos = a.state[:2]
    b_pos = b.state[:2]
    return distance(a_pos, b_pos) <= (a.size + b.size)

def bound(pos):
    penalty = 0
    if pos[0] < -1 or pos[0] > 1:
        penalty += 1
    if pos[1] < -1 or pos[1] > 1:
        penalty += 1
    return penalty

def benchmark(agent, world, shaped=False):
    if agent.adversary:
        count = 0
        for other in world.agents:
            if not other.adversary and collision(agent, other):
                count += 1
        return count
    return 0

def reward(agent, world, shaped=False):
    r = 0
    if agent.adversary:
        for other in world.agents:
            if not other.adversary and collision(agent, other):
                r += 10
        if shaped:
            for other in world.agents:
                if not other.adversary:
                    dist = distance(agent.state[:2], other.state[:2])
                    r -= dist
    else:
        for other in world.agents:
            if other.adversary and collision(agent, other):
                r -= 10
        r -= bound(agent.state[:2])
        if shaped:
            for other in world.agents:
                if other.adversary:
                    dist = distance(agent.state[:2], other.state[:2])
                    r += dist
    return r

def observation(agent, world):
    own_state = agent.state
    own_vel = own_state[2:4]
    own_pos = own_state[:2]
    obs = [own_vel, own_pos]

    for landmark in world.landmarks:
        rel_pos = landmark.state[:2] - own_pos
        obs.append(rel_pos)

    for other in world.agents:
        if other is not agent:
            rel_pos = other.state[:2] - own_pos
            rel_vel = other.state[2:4] - own_vel
            comm = other.state[4+2:4+2+world.dim_c]
            obs.extend([rel_pos, rel_vel, comm])
    return np.concatenate(obs)

if __name__ == "__main__":
    world = init_world()
    for agent in world.agents:
        print(f"{agent.name} observation: {observation(agent, world)}")
        print(f"{agent.name} reward: {reward(agent, world)}")
        print(f"{agent.name} benchmark: {benchmark(agent, world)}")