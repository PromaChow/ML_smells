import pygame
import sys
import random

pygame.init()

# ---------- Base Wrapper ----------
class PyGameWrapper:
    def __init__(self, width, height, fps, actions):
        self.width = width
        self.height = height
        self.fps = fps
        self.actions = actions
        self.screen = pygame.display.set_mode((self.width, self.height))
        self.clock = pygame.time.Clock()
        self.running = True

    def run(self):
        while self.running:
            self.step()
            pygame.display.flip()
            self.clock.tick(self.fps)
        pygame.quit()
        sys.exit()

# ---------- Sprite Classes ----------
class Player(pygame.sprite.Sprite):
    def __init__(self, pos, images):
        super().__init__()
        self.images = images
        self.image = self.images['still']
        self.rect = self.image.get_rect(topleft=pos)
        self.vel_y = 0
        self.on_ladder = False
        self.dir = 'right'
        self.lives = 3

    def update(self):
        self.rect.y += self.vel_y

class Wall(pygame.sprite.Sprite):
    def __init__(self, rect):
        super().__init__()
        self.image = pygame.Surface(rect.size)
        self.image.fill((139, 69, 19))
        self.rect = self.image.get_rect(topleft=rect.topleft)

class Ladder(pygame.sprite.Sprite):
    def __init__(self, rect):
        super().__init__()
        self.image = pygame.Surface(rect.size)
        self.image.fill((210, 180, 140))
        self.rect = self.image.get_rect(topleft=rect.topleft)

class Enemy(pygame.sprite.Sprite):
    def __init__(self, pos):
        super().__init__()
        self.image = pygame.Surface((30, 30))
        self.image.fill((255, 0, 0))
        self.rect = self.image.get_rect(topleft=pos)
        self.vel_x = random.choice([-2, 2])

    def update(self):
        self.rect.x += self.vel_x

class Coin(pygame.sprite.Sprite):
    def __init__(self, pos):
        super().__init__()
        self.image = pygame.Surface((15, 15))
        self.image.fill((255, 215, 0))
        self.rect = self.image.get_rect(center=pos)
        self.animation_phase = 0

    def update(self):
        self.animation_phase = (self.animation_phase + 1) % 60
        scale = 1 + 0.1 * pygame.math.sin(2 * pygame.math.pi * self.animation_phase / 60)
        size = int(15 * scale)
        self.image = pygame.Surface((size, size), pygame.SRCALPHA)
        pygame.draw.circle(self.image, (255, 215, 0), (size // 2, size // 2), size // 2)
        self.rect = self.image.get_rect(center=self.rect.center)

class Fireball(pygame.sprite.Sprite):
    def __init__(self, pos, direction):
        super().__init__()
        self.image = pygame.Surface((10, 10))
        self.image.fill((255, 69, 0))
        self.rect = self.image.get_rect(center=pos)
        self.vel_x = direction * 5

    def update(self):
        self.rect.x += self.vel_x

# ---------- Board ----------
class Board:
    def __init__(self):
        self.playerGroup = pygame.sprite.Group()
        self.wallGroup = pygame.sprite.Group()
        self.ladderGroup = pygame.sprite.Group()
        self.enemyGroup = pygame.sprite.Group()
        self.coinGroup = pygame.sprite.Group()
        self.fireballGroup = pygame.sprite.Group()
        self.lives = 3
        self.tick_reward = 1

    def continuousUpdate(self, group, collides_with):
        for sprite in group:
            sprite.update()
            hits = pygame.sprite.spritecollide(sprite, collides_with, False)
            if hits:
                if isinstance(sprite, Player):
                    if sprite.vel_y > 0:  # falling
                        sprite.rect.bottom = hits[0].rect.top
                        sprite.vel_y = 0
                elif isinstance(sprite, Enemy):
                    if sprite.rect.colliderect(pygame.Rect(0, 0, 0, 0)):
                        pass

# ---------- MonsterKong ----------
class MonsterKong(PyGameWrapper):
    def __init__(self):
        width, height, fps = 800, 600, 60
        actions = ['left', 'right', 'jump', 'up', 'down']
        super().__init__(width, height, fps, actions)
        self.board = Board()
        self.score = 0
        self.frame_count = 0
        # Load images
        self.images = {
            'left': pygame.Surface((30, 50)),
            'right': pygame.Surface((30, 50)),
            'still': pygame.Surface((30, 50))
        }
        self.images['left'].fill((0, 255, 0))
        self.images['right'].fill((0, 255, 0))
        self.images['still'].fill((0, 255, 0))
        self.init_game()

    def init_game(self):
        # Create player
        player = Player((100, 500), self.images)
        self.board.playerGroup.add(player)
        # Create walls
        for i in range(0, self.width, 50):
            self.board.wallGroup.add(Wall(pygame.Rect(i, self.height - 20, 50, 20)))
        # Create ladders
        self.board.ladderGroup.add(Ladder(pygame.Rect(200, self.height - 120, 30, 100)))
        # Create enemies
        self.board.enemyGroup.add(Enemy((400, 500)))
        # Create coins
        self.board.coinGroup.add(Coin((350, 450)))
        self.board.coinGroup.add(Coin((450, 350)))

    def step(self):
        # Score Update
        self.score += self.board.tick_reward
        self.frame_count += 1

        # Fireball Management
        if self.frame_count % 70 == 0:
            for enemy in self.board.enemyGroup:
                direction = -1 if enemy.rect.centerx < self.board.playerGroup.sprite.rect.centerx else 1
                fireball = Fireball(enemy.rect.center, direction)
                self.board.fireballGroup.add(fireball)

        # Coin Animation handled by update
        self.board.coinGroup.update()

        # Collision Checks (temporary movement)
        player = next(iter(self.board.playerGroup))
        original_y = player.rect.y
        # Downward check
        player.rect.y += 1
        on_ladder = pygame.sprite.spritecollideany(player, self.board.ladderGroup)
        on_wall_below = pygame.sprite.spritecollideany(player, self.board.wallGroup)
        player.on_ladder = bool(on_ladder)
        player.rect.y = original_y
        # Upward check
        player.rect.y -= 1
        on_wall_above = pygame.sprite.spritecollideany(player, self.board.wallGroup)
        player.rect.y = original_y

        # Event Handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
        keys = pygame.key.get_pressed()
        # Jump/Up
        if (keys[pygame.K_UP] or keys[pygame.K_SPACE]) and (player.on_ladder or on_wall_below):
            player.vel_y = -10
        # Left/Right
        if keys[pygame.K_LEFT]:
            player.dir = 'left'
            player.rect.x -= 5
            if pygame.sprite.spritecollideany(player, self.board.wallGroup):
                player.rect.x += 5
        if keys[pygame.K_RIGHT]:
            player.dir = 'right'
            player.rect.x += 5
            if pygame.sprite.spritecollideany(player, self.board.wallGroup):
                player.rect.x -= 5
        # Up/Down on Ladder
        if player.on_ladder:
            if keys[pygame.K_UP]:
                player.rect.y -= 5
            if keys[pygame.K_DOWN]:
                player.rect.y += 5

        # Player Physics
        gravity = 1
        player.vel_y += gravity
        player.rect.y += player.vel_y
        # Collision with walls
        wall_hit = pygame.sprite.spritecollideany(player, self.board.wallGroup)
        if wall_hit:
            if player.vel_y > 0:
                player.rect.bottom = wall_hit.rect.top
                player.vel_y = 0
            elif player.vel_y < 0:
                player.rect.top = wall_hit.rect.bottom
                player.vel_y = 0

        # Screen Rendering
        self.screen.fill((135, 206, 235))
        self.board.wallGroup.draw(self.screen)
        self.board.ladderGroup.draw(self.screen)
        self.board.enemyGroup.draw(self.screen)
        self.board.coinGroup.draw(self.screen)
        self.board.fireballGroup.draw(self.screen)
        self.board.playerGroup.draw(self.screen)

        # Fireball Collision Check
        if pygame.sprite.spritecollideany(player, self.board.fireballGroup):
            player.lives -= 1
            if player.lives <= 0:
                self.running = False

        # Coin Collection
        collected = pygame.sprite.spritecollide(player, self.board.coinGroup, dokill=True)
        if collected:
            self.score += 10 * len(collected)

        # Victory Check (placeholder: reaching right edge)
        if player.rect.right >= self.width:
            self.running = False

        # Enemy Updates
        self.board.enemyGroup.update()

    def game_over(self):
        return self.board.lives <= 0

    def getScore(self):
        return self.score

# ---------- Run ----------
if __name__ == "__main__":
    game = MonsterKong()
    game.run()
