import argparse
import json
import logging
import os
import random
import sys
from dataclasses import dataclass, asdict
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import torchvision.transforms as transforms
from sklearn.metrics import roc_auc_score
from torch.utils.data import DataLoader, Subset
from torchvision import datasets, models


@dataclass
class Config:
    dataset: str
    net_name: str
    experiment_path: str
    data_path: str
    eta: float
    lr: float
    batch_size: int
    seed: int
    pretrain: bool
    epochs: int
    milestones: str
    device: str


def parse_args():
    parser = argparse.ArgumentParser(description="DeepSAD Anomaly Detection")
    parser.add_argument("--dataset", type=str, required=True, help="Dataset name (mnist, cifar10)")
    parser.add_argument("--net_name", type=str, required=True, help="Neural net architecture name")
    parser.add_argument("--experiment_path", type=str, required=True, help="Path to store experiment")
    parser.add_argument("--data_path", type=str, required=True, help="Path to data")
    parser.add_argument("--eta", type=float, default=1.0, help="DeepSAD eta hyperparameter")
    parser.add_argument("--lr", type=float, default=0.001, help="Learning rate")
    parser.add_argument("--batch_size", type=int, default=128, help="Batch size")
    parser.add_argument("--seed", type=int, default=None, help="Random seed")
    parser.add_argument("--pretrain", action="store_true", help="Enable pretraining")
    parser.add_argument("--epochs", type=int, default=50, help="Training epochs")
    parser.add_argument("--milestones", type=str, default="", help="Comma separated lr milestones")
    return parser.parse_args()


def setup_logging(log_file):
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        handlers=[logging.FileHandler(log_file), logging.StreamHandler(sys.stdout)],
    )


def set_seed(seed, device):
    if seed is not None:
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        logging.info(f"Random seed set to {seed}")
    if device == "cuda":
        torch.backends.cudnn.enabled = True
    else:
        torch.backends.cudnn.enabled = False


def load_dataset(config):
    transform = transforms.Compose(
        [transforms.ToTensor(), transforms.Normalize((0.5,), (0.5,))]
    )
    if config.dataset.lower() == "mnist":
        train_set = datasets.MNIST(
            root=config.data_path, train=True, download=True, transform=transform
        )
        test_set = datasets.MNIST(
            root=config.data_path, train=False, download=True, transform=transform
        )
    elif config.dataset.lower() == "cifar10":
        train_set = datasets.CIFAR10(
            root=config.data_path, train=True, download=True, transform=transform
        )
        test_set = datasets.CIFAR10(
            root=config.data_path, train=False, download=True, transform=transform
        )
    else:
        raise ValueError(f"Unsupported dataset {config.dataset}")

    # Simple split: use all train data for training, all test data for testing
    train_loader = DataLoader(train_set, batch_size=config.batch_size, shuffle=True, num_workers=4)
    test_loader = DataLoader(test_set, batch_size=config.batch_size, shuffle=False, num_workers=4)

    # For simplicity, treat class 0 as normal, others as outliers
    normal_class = 0
    known_outliers = [i for i in range(10) if i != normal_class]
    logging.info(f"Dataset: {config.dataset}, Normal class: {normal_class}, Known outliers: {known_outliers}")

    return train_loader, test_loader, normal_class, known_outliers


def get_autoencoder(net_name, device):
    if net_name.lower() == "mnist_lenet":
        class Encoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.conv = nn.Sequential(
                    nn.Conv2d(1, 32, 3, stride=2, padding=1),
                    nn.ReLU(),
                    nn.Conv2d(32, 64, 3, stride=2, padding=1),
                    nn.ReLU(),
                )
                self.fc = nn.Linear(64 * 7 * 7, 128)

            def forward(self, x):
                x = self.conv(x)
                x = x.view(x.size(0), -1)
                x = self.fc(x)
                return x

        class Decoder(nn.Module):
            def __init__(self):
                super().__init__()
                self.fc = nn.Linear(128, 64 * 7 * 7)
                self.deconv = nn.Sequential(
                    nn.ConvTranspose2d(64, 32, 3, stride=2, padding=1, output_padding=1),
                    nn.ReLU(),
                    nn.ConvTranspose2d(32, 1, 3, stride=2, padding=1, output_padding=1),
                    nn.Sigmoid(),
                )

            def forward(self, x):
                x = self.fc(x)
                x = x.view(x.size(0), 64, 7, 7)
                x = self.deconv(x)
                return x

        encoder = Encoder().to(device)
        decoder = Decoder().to(device)
        return encoder, decoder
    elif net_name.lower() == "cifar10_resnet":
        model = models.resnet18(pretrained=False, num_classes=10)
        encoder = nn.Sequential(*list(model.children())[:-1]).to(device)
        decoder = nn.Sequential(
            nn.ConvTranspose2d(512, 256, 4, stride=2, padding=1),
            nn.ReLU(),
            nn.ConvTranspose2d(256, 128, 4, stride=2, padding=1),
            nn.ReLU(),
            nn.ConvTranspose2d(128, 3, 4, stride=2, padding=1),
            nn.Sigmoid(),
        ).to(device)
        return encoder, decoder
    else:
        raise ValueError(f"Unsupported net {net_name}")


class DeepSAD:
    def __init__(self, encoder, decoder, eta, device):
        self.encoder = encoder
        self.decoder = decoder
        self.eta = eta
        self.device = device
        self.optimizer = None

    def pretrain(self, loader, epochs, lr, weight_decay):
        criterion = nn.MSELoss()
        self.optimizer = optim.Adam(
            list(self.encoder.parameters()) + list(self.decoder.parameters()),
            lr=lr,
            weight_decay=weight_decay,
        )
        self.encoder.train()
        self.decoder.train()
        for epoch in range(epochs):
            epoch_loss = 0.0
            for imgs, _ in loader:
                imgs = imgs.to(self.device)
                self.optimizer.zero_grad()
                z = self.encoder(imgs)
                recon = self.decoder(z)
                loss = criterion(recon, imgs)
                loss.backward()
                self.optimizer.step()
                epoch_loss += loss.item() * imgs.size(0)
            epoch_loss /= len(loader.dataset)
            logging.info(f"Pretrain epoch {epoch+1}/{epochs}, loss: {epoch_loss:.4f}")

    def train(self, loader, epochs, lr, weight_decay, milestones):
        criterion = nn.MSELoss()
        self.optimizer = optim.Adam(
            list(self.encoder.parameters()) + list(self.decoder.parameters()),
            lr=lr,
            weight_decay=weight_decay,
        )
        scheduler = optim.lr_scheduler.MultiStepLR(self.optimizer, milestones=milestones, gamma=0.1)
        self.encoder.train()
        self.decoder.train()
        for epoch in range(epochs):
            epoch_loss = 0.0
            for imgs, _ in loader:
                imgs = imgs.to(self.device)
                self.optimizer.zero_grad()
                z = self.encoder(imgs)
                recon = self.decoder(z)
                loss = criterion(recon, imgs)
                loss.backward()
                self.optimizer.step()
                epoch_loss += loss.item() * imgs.size(0)
            epoch_loss /= len(loader.dataset)
            scheduler.step()
            logging.info(f"Train epoch {epoch+1}/{epochs}, loss: {epoch_loss:.4f}")

    def test(self, loader):
        self.encoder.eval()
        self.decoder.eval()
        scores = []
        labels = []
        with torch.no_grad():
            for imgs, targets in loader:
                imgs = imgs.to(self.device)
                z = self.encoder(imgs)
                recon = self.decoder(z)
                loss = nn.functional.mse_loss(recon, imgs, reduction="none")
                loss = loss.view(loss.size(0), -1).mean(dim=1)
                scores.extend(loss.cpu().numpy())
                labels.extend(targets.numpy())
        return np.array(scores), np.array(labels)


def evaluate(scores, labels, normal_class):
    y_true = np.where(labels == normal_class, 0, 1)
    auc = roc_auc_score(y_true, scores)
    logging.info(f"AUC: {auc:.4f}")
    return auc


def visualize(dataset, scores, labels, normal_class, output_dir, num=32):
    import matplotlib.pyplot as plt

    indices = np.argsort(scores)
    sorted_scores = scores[indices]
    sorted_labels = labels[indices]
    sorted_imgs = [dataset[i][0].squeeze().numpy() for i in indices]

    def plot_grid(imgs, title, save_path):
        plt.figure(figsize=(6, 6))
        for i in range(num):
            plt.subplot(4, 8, i + 1)
            plt.imshow(imgs[i], cmap="gray")
            plt.axis("off")
        plt.suptitle(title)
        plt.tight_layout()
        plt.savefig(save_path)
        plt.close()

    # Most anomalous
    plot_grid(sorted_imgs[:num], f"Top {num} Anomalous", os.path.join(output_dir, "all_low.png"))
    # Most normal (lowest scores)
    normal_indices = [i for i, l in enumerate(sorted_labels) if l == normal_class]
    plot_grid([sorted_imgs[i] for i in normal_indices[:num]], f"Top {num} Normals", os.path.join(output_dir, "normals_low.png"))
    # Least anomalous
    plot_grid(sorted_imgs[-num:], f"Bottom {num} Anomalous", os.path.join(output_dir, "all_high.png"))
    # Most normal (highest scores)
    normal_indices_rev = [i for i in reversed(range(len(sorted_labels))) if sorted_labels[i] == normal_class]
    plot_grid([sorted_imgs[i] for i in normal_indices_rev[:num]], f"Bottom {num} Normals", os.path.join(output_dir, "normals_high.png"))


def save_json(data, path):
    with open(path, "w") as f:
        json.dump(data, f, indent=4)


def main():
    args = parse_args()
    config = Config(
        dataset=args.dataset,
        net_name=args.net_name,
        experiment_path=args.experiment_path,
        data_path=args.data_path,
        eta=args.eta,
        lr=args.lr,
        batch_size=args.batch_size,
        seed=args.seed,
        pretrain=args.pretrain,
        epochs=args.epochs,
        milestones=[int(x) for x in args.milestones.split(",") if x.strip().isdigit()],
        device="cuda" if torch.cuda.is_available() else "cpu",
    )
    Path(config.experiment_path).mkdir(parents=True, exist_ok=True)
    setup_logging(os.path.join(config.experiment_path, "log.txt"))
    set_seed(config.seed, config.device)
    train_loader, test_loader, normal_class, _ = load_dataset(config)
    encoder, decoder = get_autoencoder(config.net_name, config.device)
    model = DeepSAD(encoder, decoder, config.eta, config.device)

    if config.pretrain:
        logging.info("Starting pretraining")
        model.pretrain(train_loader, epochs=100, lr=0.001, weight_decay=1e-6)
        save_json({"pretrain_epochs": 100, "lr": 0.001, "weight_decay": 1e-6}, os.path.join(config.experiment_path, "pretrain.json"))

    logging.info("Starting training")
    model.train(train_loader, epochs=config.epochs, lr=config.lr, weight_decay=1e-6, milestones=config.milestones)
    torch.save(
        {"encoder_state_dict": encoder.state_dict(), "decoder_state_dict": decoder.state_dict()},
        os.path.join(config.experiment_path, "model.tar"),
    )

    logging.info("Testing model")
    scores, labels = model.test(test_loader)
    auc = evaluate(scores, labels, normal_class)

    results = {
        "scores": scores.tolist(),
        "labels": labels.tolist(),
        "auc": auc,
    }
    save_json(results, os.path.join(config.experiment_path, "results.json"))
    save_json(asdict(config), os.path.join(config.experiment_path, "config.json"))

    if config.dataset.lower() in ["mnist", "cifar10"]:
        logging.info("Visualizing results")
        visualize(test_loader.dataset, scores, labels, normal_class, config.experiment_path)


if __name__ == "__main__":
    main()
