import os
import datetime
import gym
import numpy as np
import torch
from torch import nn
from torch.utils.data import IterableDataset
import pytorch_lightning as pl
from pytorch_lightning.callbacks import ModelCheckpoint, EarlyStopping
from pytorch_lightning.loggers import TensorBoardLogger
from pytorch_lightning.utilities.distributed import rank_zero_only


# ---------- Helpers ----------
def _is_simple_space(space):
    return isinstance(space, (gym.spaces.Box, gym.spaces.Discrete, gym.spaces.MultiDiscrete, gym.spaces.MultiBinary))


def _is_discrete_space(space):
    return isinstance(space, gym.spaces.Discrete)


def _is_continuous_space(space):
    return isinstance(space, gym.spaces.Box)


# ---------- Algorithm placeholder ----------
class RLAlgorithm(pl.LightningModule):
    def __init__(self):
        super().__init__()
        # Example network
        self.policy_net = nn.Sequential(
            nn.Linear(4, 128),
            nn.ReLU(),
            nn.Linear(128, 2)
        )
        self.save_hyperparameters()

    def act(self, state):
        with torch.no_grad():
            logits = self.policy_net(state)
            return torch.argmax(logits, dim=-1).item()

    def act_with_noise(self, state):
        with torch.no_grad():
            action = self.policy_net(state)
            noise = torch.randn_like(action) * 0.1
            return (action + noise).clamp(-1, 1).numpy()

    def training_step(self, batch, batch_idx):
        # Dummy loss
        loss = torch.tensor(0.0, device=self.device)
        self.log("loss", loss)
        return loss

    def configure_optimizers(self):
        return torch.optim.Adam(self.parameters(), lr=1e-3)


# ---------- Datasets ----------
class RLGymDiscActDataset(IterableDataset):
    def __init__(self, env, algorithm, render_every_episode=1, max_steps_per_episode=200):
        assert _is_discrete_space(env.action_space), "Environment must have a discrete action space."
        assert _is_simple_space(env.observation_space), "Observation space must be simple."
        self.env = env
        self.algorithm = algorithm
        self.render_every_episode = render_every_episode
        self.max_steps = max_steps_per_episode
        self.episode = 0

    def __iter__(self):
        return self

    def __next__(self):
        state_np = self.env.reset()
        state = torch.tensor(state_np, dtype=torch.float32)
        total_reward = 0.0
        for t in range(self.max_steps):
            if self.episode % self.render_every_episode == 0:
                self.env.render()
            action = self.algorithm.act(state)
            next_state_np, reward, done, _ = self.env.step(action)
            total_reward += reward
            if done:
                break
            state = torch.tensor(next_state_np, dtype=torch.float32)
        self.episode += 1
        return {"total_reward": total_reward}


class RLGymContActDataset(IterableDataset):
    def __init__(self, env, algorithm, render_every_episode=1, max_steps_per_episode=200):
        assert _is_continuous_space(env.action_space), "Environment must have a continuous action space."
        assert _is_simple_space(env.observation_space), "Observation space must be simple."
        self.env = env
        self.algorithm = algorithm
        self.render_every_episode = render_every_episode
        self.max_steps = max_steps_per_episode
        self.episode = 0

    def __iter__(self):
        return self

    def __next__(self):
        state_np = self.env.reset()
        state = torch.tensor(state_np, dtype=torch.float32)
        total_reward = 0.0
        for t in range(self.max_steps):
            if self.episode % self.render_every_episode == 0:
                self.env.render()
            action = self.algorithm.act_with_noise(state)
            next_state_np, reward, done, _ = self.env.step(action)
            total_reward += reward
            if done:
                break
            state = torch.tensor(next_state_np, dtype=torch.float32)
        self.episode += 1
        return {"total_reward": total_reward}


# ---------- Environment Configuration ----------
def generate_env_config():
    return {
        "env_name": "CartPole-v1",
        "render_every_episode": 10,
        "max_steps_per_episode": 200,
        "output_dir": "rl_output",
    }


def gym_env_dataset_creator(config, algorithm):
    env = gym.make(config["env_name"])
    if _is_discrete_space(env.action_space):
        return RLGymDiscActDataset(env, algorithm,
                                   render_every_episode=config["render_every_episode"],
                                   max_steps_per_episode=config["max_steps_per_episode"])
    elif _is_continuous_space(env.action_space):
        return RLGymContActDataset(env, algorithm,
                                   render_every_episode=config["render_every_episode"],
                                   max_steps_per_episode=config["max_steps_per_episode"])
    else:
        raise ValueError("Unsupported action space type.")


# ---------- Utilities ----------
class SaveEnv:
    def __init__(self, base_dir, name="run"):
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        self.base_dir = os.path.join(base_dir, f"{name}_{timestamp}")
        os.makedirs(self.base_dir, exist_ok=True)

    def join(self, *parts):
        return os.path.join(self.base_dir, *parts)


class LocalMediaLogger:
    def __init__(self, media_dir):
        self.media_dir = media_dir
        os.makedirs(self.media_dir, exist_ok=True)

    def log_video(self, episode, video_frames):
        # Placeholder: save frames as numpy array
        path = os.path.join(self.media_dir, f"episode_{episode}.npy")
        np.save(path, video_frames)


class Launcher:
    def __init__(self, trainer):
        self.trainer = trainer

    def launch(self, model, dataset):
        self.trainer.fit(model, datamodule=dataset)


class DistributedLauncher(Launcher):
    def launch(self, model, dataset):
        # In a real distributed setting, we would launch via Lightning CLI or launch script.
        super().launch(model, dataset)


def is_algorithm_distributed(algorithm):
    # Placeholder: return False for single process
    return False


# ---------- Training Pipeline ----------
def launch():
    config = generate_env_config()
    env_config = SaveEnv(config["output_dir"])
    log_dir = env_config.join("logs")
    checkpoint_dir = env_config.join("checkpoints")
    media_dir = env_config.join("media")

    algorithm = RLAlgorithm()

    dataset = gym_env_dataset_creator(config, algorithm)

    checkpoint_callback = ModelCheckpoint(
        dirpath=checkpoint_dir,
        monitor="total_reward",
        mode="max",
        save_top_k=1,
        verbose=True,
    )

    early_stop_callback = EarlyStopping(
        monitor="total_reward",
        patience=5,
        mode="max",
    )

    logger = TensorBoardLogger(save_dir=log_dir, name="tensorboard")

    trainer_kwargs = dict(
        max_epochs=100,
        callbacks=[checkpoint_callback, early_stop_callback],
        logger=logger,
        enable_progress_bar=True,
    )

    # Use GPU if available
    if torch.cuda.is_available():
        trainer_kwargs["gpus"] = 1

    trainer = pl.Trainer(**trainer_kwargs)

    if is_algorithm_distributed(algorithm):
        launcher = DistributedLauncher(trainer)
    else:
        launcher = Launcher(trainer)

    launcher.launch(algorithm, dataset)


if __name__ == "__main__":
    launch()
