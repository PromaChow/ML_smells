import os
import sys
import glob
import logging
import numpy as np
import scipy.linalg
import tensorflow.compat.v1 as tf
import urllib.request
import tarfile

tf.disable_eager_execution()
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

MODEL_URL = "https://storage.googleapis.com/download.tensorflow.org/models/inception-2015-12-05.tgz"
MODEL_DIR = "inception_model"
MODEL_FILE = os.path.join(MODEL_DIR, "classify_image_graph_def.pb")
TMP_TAR = os.path.join(MODEL_DIR, "inception.tgz")


def download_and_extract_model():
    if os.path.exists(MODEL_FILE):
        logger.info("Inception model already exists.")
        return
    os.makedirs(MODEL_DIR, exist_ok=True)
    logger.info(f"Downloading Inception model from {MODEL_URL}")
    urllib.request.urlretrieve(MODEL_URL, TMP_TAR)
    logger.info("Extracting model")
    with tarfile.open(TMP_TAR, "r:gz") as tar:
        tar.extractall(path=MODEL_DIR)
    os.remove(TMP_TAR)
    logger.info("Model downloaded and extracted.")


def create_inception_graph():
    download_and_extract_model()
    graph_def = tf.GraphDef()
    with tf.gfile.GFile(MODEL_FILE, "rb") as f:
        graph_def.ParseFromString(f.read())
    with tf.Graph().as_default() as graph:
        tf.import_graph_def(graph_def, name="")
    return graph


def get_image_paths(directory):
    exts = ("*.jpg", "*.jpeg", "*.png", "*.bmp")
    paths = []
    for ext in exts:
        paths.extend(glob.glob(os.path.join(directory, "**", ext), recursive=True))
    return paths


def get_activations(image_paths, graph, batch_size=50):
    if len(image_paths) == 0:
        raise ValueError("No images found.")
    input_tensor = graph.get_tensor_by_name("input:0")
    out_tensor = graph.get_tensor_by_name("pool_3:0")
    activations = []

    with tf.Session(graph=graph) as sess:
        for i in range(0, len(image_paths), batch_size):
            batch_paths = image_paths[i : i + batch_size]
            batch_images = [np.asarray(open(p, "rb").read(), dtype=np.uint8) for p in batch_paths]
            out = sess.run(out_tensor, feed_dict={input_tensor: batch_images})
            activations.append(out)
    activations = np.concatenate(activations, axis=0)
    return activations


def calculate_activation_statistics(activations):
    mu = np.mean(activations, axis=0)
    sigma = np.cov(activations, rowvar=False)
    return mu, sigma


def calculate_frechet_distance(mu1, sigma1, mu2, sigma2, eps=1e-6):
    diff = mu1 - mu2
    covmean, _ = scipy.linalg.sqrtm(sigma1.dot(sigma2), disp=False)
    if np.iscomplexobj(covmean):
        covmean = covmean.real
    tr_covmean = np.trace(covmean)
    fid = diff.dot(diff) + np.trace(sigma1) + np.trace(sigma2) - 2 * tr_covmean
    return fid


def load_stats(npz_path):
    with np.load(npz_path) as data:
        mu = data["mu"]
        sigma = data["sigma"]
    return mu, sigma


def calculate_fid_given_paths(path1, path2, batch_size=50, use_raw=True):
    if path1.endswith(".npz"):
        mu1, sigma1 = load_stats(path1)
    else:
        graph = create_inception_graph()
        paths = get_image_paths(path1)
        activations = get_activations(paths, graph, batch_size)
        mu1, sigma1 = calculate_activation_statistics(activations)

    if path2.endswith(".npz"):
        mu2, sigma2 = load_stats(path2)
    else:
        graph = create_inception_graph()
        paths = get_image_paths(path2)
        activations = get_activations(paths, graph, batch_size)
        mu2, sigma2 = calculate_activation_statistics(activations)

    fid_value = calculate_frechet_distance(mu1, sigma1, mu2, sigma2)
    return fid_value


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python fid.py <path1> <path2> [batch_size]")
        sys.exit(1)
    p1 = sys.argv[1]
    p2 = sys.argv[2]
    bs = int(sys.argv[3]) if len(sys.argv) > 3 else 50
    fid = calculate_fid_given_paths(p1, p2, batch_size=bs)
    print(f"FID: {fid}")