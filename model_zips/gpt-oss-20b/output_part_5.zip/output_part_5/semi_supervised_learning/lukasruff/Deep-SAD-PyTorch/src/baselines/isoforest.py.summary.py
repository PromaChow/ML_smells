import json
import time
import os
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from sklearn.ensemble import IsolationForest
from sklearn.metrics import roc_auc_score

class IsoForest:
    def __init__(self, n_estimators=100, max_samples='auto', contamination='auto', hybrid=False, device=None):
        self.n_estimators = n_estimators
        self.max_samples = max_samples
        self.contamination = contamination
        self.hybrid = hybrid
        self.device = device or torch.device('cpu')
        self.model = IsolationForest(
            n_estimators=self.n_estimators,
            max_samples=self.max_samples,
            contamination=self.contamination,
            behaviour='new'
        )
        self.ae_net = None
        self.results = {
            'training_time': None,
            'test_time': None,
            'auc': None,
            'test_scores': None
        }

    def load_ae(self, path):
        if not os.path.exists(path):
            raise FileNotFoundError(f"Autoencoder checkpoint not found: {path}")
        self.ae_net = torch.load(path, map_location=self.device)
        self.ae_net.eval()

    def train(self, train_dataset):
        dataloader = DataLoader(train_dataset, batch_size=128, shuffle=True, drop_last=False)
        features = []
        start_time = time.time()
        with torch.no_grad():
            for batch in dataloader:
                if isinstance(batch, (list, tuple)):
                    data = batch[0]
                else:
                    data = batch
                data = data.to(self.device)
                if self.hybrid and self.ae_net is not None:
                    encoded = self.ae_net.encoder(data)
                    feat = encoded.cpu().numpy()
                else:
                    feat = data.cpu().numpy().reshape(data.size(0), -1)
                features.append(feat)
        X = np.concatenate(features, axis=0)
        self.model.fit(X)
        self.results['training_time'] = time.time() - start_time

    def test(self, test_dataset):
        dataloader = DataLoader(test_dataset, batch_size=128, shuffle=False, drop_last=False)
        features = []
        indices = []
        labels = []
        start_time = time.time()
        with torch.no_grad():
            for idx_batch, batch in enumerate(dataloader):
                if isinstance(batch, (list, tuple)):
                    data = batch[0]
                    label = batch[1]
                else:
                    data = batch
                    label = None
                data = data.to(self.device)
                if self.hybrid and self.ae_net is not None:
                    encoded = self.ae_net.encoder(data)
                    feat = encoded.cpu().numpy()
                else:
                    feat = data.cpu().numpy().reshape(data.size(0), -1)
                features.append(feat)
                batch_indices = np.arange(idx_batch * dataloader.batch_size, idx_batch * dataloader.batch_size + data.size(0))
                indices.extend(batch_indices.tolist())
                if label is not None:
                    labels.extend(label.cpu().numpy().tolist())
        X = np.concatenate(features, axis=0)
        scores = -self.model.decision_function(X)
        if labels:
            auc = roc_auc_score(labels, scores)
            self.results['auc'] = auc
        else:
            self.results['auc'] = None
        self.results['test_time'] = time.time() - start_time
        self.results['test_scores'] = list(zip(indices, labels, scores))

    def save_results(self, path):
        with open(path, 'w') as f:
            json.dump(self.results, f, indent=4)

    def save_model(self, path):
        pass

    def load_model(self, path):
        pass
