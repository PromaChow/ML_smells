import os
import csv
from pathlib import Path

import numpy as np
from gensim.models.keyedvectors import KeyedVectors


def parseFastText(path: str) -> dict:
    """
    Parse a FastText embedding file and return a dictionary mapping words to vectors.
    """
    data = {}
    with open(path, encoding="utf-8") as f:
        header = f.readline().strip().split()
        num_words, embedding_size = int(header[0]), int(header[1])
        for idx, line in enumerate(f, start=1):
            # Split only on the first space to keep the vector intact
            parts = line.rstrip().split(" ", 1)
            if len(parts) != 2:
                continue
            word, vector_str = parts
            vector = np.fromstring(vector_str, sep=" ", dtype=float)
            if vector.size != embedding_size:
                continue
            data[word] = vector
            if idx % max(1, num_words // 10) == 0 or idx == num_words:
                percent = (idx / num_words) * 100
                print(f"{percent:.1f}% complete")
    return data


def loadEmbeddingsDataset(path: str, binaryFormat: bool = False) -> KeyedVectors:
    """
    Load pre-trained word embeddings using gensim.
    """
    return KeyedVectors.load_word2vec_format(path, binary=binaryFormat)


def readMyPersonality() -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Read raw statuses and Big Five personality scores from local files.
    """
    data = []
    with open("statuses_unicode.txt", encoding="utf-8") as f:
        for line in f:
            data.append(line.rstrip("\n"))

    y_O, y_C, y_E, y_A, y_N = [], [], [], [], []
    with open("big5labels.txt", encoding="utf-8") as f:
        for line in f:
            parts = line.strip().split()
            if len(parts) < 5:
                continue
            o, c, e, a, n = map(float, parts[:5])
            y_O.append(o)
            y_C.append(c)
            y_E.append(e)
            y_A.append(a)
            y_N.append(n)

    return (
        np.array(data, dtype=object),
        np.array(y_O, dtype=float),
        np.array(y_C, dtype=float),
        np.array(y_E, dtype=float),
        np.array(y_A, dtype=float),
        np.array(y_N, dtype=float),
    )


def readMyPersonalityUserWise() -> tuple[list[str], np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Aggregate user statuses per user and return Big Five scores.
    """
    user_statuses = {}
    y_O_all, y_C_all, y_E_all, y_A_all, y_N_all = [], [], [], [], []

    with open("mypersonality_final.csv", encoding="utf-8") as f:
        reader = csv.reader(f)
        header = next(reader, None)
        for row in reader:
            if len(row) < 7:
                continue
            user_id, status, o, c, e, a, n = row[0], row[1], row[2], row[3], row[4], row[5], row[6]
            user_statuses.setdefault(user_id, []).append(status)

            y_O_all.append(float(o))
            y_C_all.append(float(c))
            y_E_all.append(float(e))
            y_A_all.append(float(a))
            y_N_all.append(float(n))

    data_all = [ " ".join(statuses) for statuses in user_statuses.values() ]

    return (
        data_all,
        np.array(y_O_all, dtype=float),
        np.array(y_C_all, dtype=float),
        np.array(y_E_all, dtype=float),
        np.array(y_A_all, dtype=float),
        np.array(y_N_all, dtype=float),
    )


def readMyPersonalityUserWise_v2() -> tuple[dict[str, str], np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Store user statuses in a dictionary keyed by user ID.
    """
    user_statuses = {}
    y_O_all, y_C_all, y_E_all, y_A_all, y_N_all = [], [], [], [], []

    with open("mypersonality_final.csv", encoding="utf-8") as f:
        reader = csv.reader(f)
        header = next(reader, None)
        for row in reader:
            if len(row) < 7:
                continue
            user_id, status, o, c, e, a, n = row[0], row[1], row[2], row[3], row[4], row[5], row[6]
            if user_id in user_statuses:
                user_statuses[user_id] += " " + status
            else:
                user_statuses[user_id] = status

            y_O_all.append(float(o))
            y_C_all.append(float(c))
            y_E_all.append(float(e))
            y_A_all.append(float(a))
            y_N_all.append(float(n))

    return (
        user_statuses,
        np.array(y_O_all, dtype=float),
        np.array(y_C_all, dtype=float),
        np.array(y_E_all, dtype=float),
        np.array(y_A_all, dtype=float),
        np.array(y_N_all, dtype=float),
    )


def parseMyPersonality() -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Parse the MyPersonality CSV, extract data, write to dataset folder, and return arrays.
    """
    data, sizes, y_O, y_C, y_E, y_A, y_N = [], [], [], [], [], [], []

    with open("mypersonality_final.csv", encoding="utf-8") as f:
        reader = csv.reader(f)
        header = next(reader, None)
        for row in reader:
            if len(row) < 8:
                continue
            user_id, status, o, c, e, a, n, nsize = row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7]
            data.append(status)
            sizes.append(int(nsize))
            y_O.append(float(o))
            y_C.append(float(c))
            y_E.append(float(e))
            y_A.append(float(a))
            y_N.append(float(n))

    dataset_dir = Path("dataset")
    dataset_dir.mkdir(exist_ok=True)

    with open(dataset_dir / "statuses.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(data))
    with open(dataset_dir / "big5labels.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(f"{o} {c} {e} {a} {n}" for o, c, e, a, n in zip(y_O, y_C, y_E, y_A, y_N)))
    with open(dataset_dir / "nfriends.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(map(str, sizes)))

    return (
        np.array(data, dtype=object),
        np.array(y_O, dtype=float),
        np.array(y_C, dtype=float),
        np.array(y_E, dtype=float),
        np.array(y_A, dtype=float),
        np.array(y_N, dtype=float),
        np.array(sizes, dtype=int),
    )
