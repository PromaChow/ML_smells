import numpy as np
from collections import deque, defaultdict

# Global board variables
N = None
ALL_COORDS = None
EMPTY_BOARD = None
NEIGHBORS = None
DIAGONALS = None

# Stone colors
EMPTY = 0
BLACK = 1
WHITE = 2
COLOURS = {BLACK: "B", WHITE: "W"}

def set_board_size(n: int) -> None:
    global N, ALL_COORDS, EMPTY_BOARD, NEIGHBORS, DIAGONALS
    N = n
    ALL_COORDS = [(i, j) for i in range(N) for j in range(N)]
    EMPTY_BOARD = np.zeros((N, N), dtype=int)

    def neighbors(coord):
        i, j = coord
        neigh = []
        for di, dj in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            ni, nj = i + di, j + dj
            if 0 <= ni < N and 0 <= nj < N:
                neigh.append((ni, nj))
        return neigh

    def diagonals(coord):
        i, j = coord
        diag = []
        for di, dj in [(-1, -1), (-1, 1), (1, -1), (1, 1)]:
            ni, nj = i + di, j + dj
            if 0 <= ni < N and 0 <= nj < N:
                diag.append((ni, nj))
        return diag

    NEIGHBORS = {coord: neighbors(coord) for coord in ALL_COORDS}
    DIAGONALS = {coord: diagonals(coord) for coord in ALL_COORDS}

def place_stones(board: np.ndarray, coords, color: int) -> None:
    for (i, j) in coords:
        board[i, j] = color

def find_reached(board: np.ndarray, start, color: int):
    visited = set()
    group = set()
    liberties = set()
    queue = deque([start])
    while queue:
        c = queue.popleft()
        if c in visited:
            continue
        visited.add(c)
        if board[c] == color:
            group.add(c)
            for n in NEIGHBORS[c]:
                if board[n] == EMPTY:
                    liberties.add(n)
                elif board[n] == color:
                    queue.append(n)
    return group, liberties

def is_koish(board: np.ndarray, move, color: int) -> bool:
    i, j = move
    opp = BLACK if color == WHITE else WHITE
    if any(board[n] == opp for n in NEIGHBORS[(i, j)]):
        # All neighbors must be opponent stones after move
        return all(board[n] == opp for n in NEIGHBORS[(i, j)])
    return False

def is_eyeish(board: np.ndarray, move, color: int) -> bool:
    i, j = move
    neigh = NEIGHBORS[(i, j)]
    if any(board[n] != color and board[n] != EMPTY for n in neigh):
        return False
    return all(board[n] == color or board[n] == EMPTY for n in neigh)

class Group:
    def __init__(self, gid, color):
        self.id = gid
        self.color = color
        self.stones = set()
        self.liberties = set()

class LibertyTracker:
    def __init__(self):
        self.groups = {}
        self.stone_to_group = {}
        self.next_gid = 1

    @classmethod
    def from_board(cls, board: np.ndarray):
        tracker = cls()
        visited = set()
        for coord in ALL_COORDS:
            if board[coord] != EMPTY and coord not in visited:
                color = board[coord]
                group, liberties = find_reached(board, coord, color)
                gid = tracker.next_gid
                tracker.next_gid += 1
                g = Group(gid, color)
                g.stones = group
                g.liberties = liberties
                tracker.groups[gid] = g
                for stone in group:
                    tracker.stone_to_group[stone] = gid
                visited.update(group)
        return tracker

    def add_stone(self, board: np.ndarray, move, color: int):
        i, j = move
        board[i, j] = color
        new_group = Group(self.next_gid, color)
        self.next_gid += 1
        new_group.stones.add((i, j))
        new_group.liberties = set(NEIGHBORS[(i, j)])
        self.groups[new_group.id] = new_group
        self.stone_to_group[(i, j)] = new_group.id

        # Check neighboring groups of same color to merge
        for n in NEIGHBORS[(i, j)]:
            if board[n] == color and n in self.stone_to_group:
                self._merge_groups(new_group.id, self.stone_to_group[n])

        # Update liberties of new group and capture opponent groups if liberties removed
        for n in NEIGHBORS[(i, j)]:
            if board[n] != color and board[n] != EMPTY:
                gid = self.stone_to_group.get(n)
                if gid:
                    self.groups[gid].liberties.discard((i, j))
                    if not self.groups[gid].liberties:
                        self._capture_group(board, gid)

        # Remove liberties from opponent groups where new stone is a liberty
        for n in NEIGHBORS[(i, j)]:
            if board[n] != color and board[n] != EMPTY:
                gid = self.stone_to_group.get(n)
                if gid:
                    self.groups[gid].liberties.discard((i, j))

    def _merge_groups(self, gid1, gid2):
        if gid1 == gid2:
            return
        g1 = self.groups[gid1]
        g2 = self.groups[gid2]
        g1.stones.update(g2.stones)
        g1.liberties.update(g2.liberties)
        g1.liberties.discard(g2.stones)  # remove liberties that are now stones
        for stone in g2.stones:
            self.stone_to_group[stone] = gid1
        del self.groups[gid2]

    def _capture_group(self, board: np.ndarray, gid):
        group = self.groups[gid]
        for stone in group.stones:
            board[stone] = EMPTY
            del self.stone_to_group[stone]
        del self.groups[gid]

class Position:
    def __init__(self):
        self.board = EMPTY_BOARD.copy()
        self.captures = {BLACK: 0, WHITE: 0}
        self.tracker = LibertyTracker.from_board(self.board)
        self.ko = None
        self.recent_moves = []
        self.turn = BLACK

    def is_move_legal(self, move):
        i, j = move
        if self.board[i, j] != EMPTY:
            return False
        if self.ko == move:
            return False
        if self.is_move_suicidal(move):
            return False
        return True

    def is_move_suicidal(self, move):
        temp_board = self.board.copy()
        temp_tracker = LibertyTracker.from_board(temp_board)
        temp_tracker.add_stone(temp_board, move, self.turn)
        group_id = temp_tracker.stone_to_group.get(move)
        if group_id is None:
            return True
        group = temp_tracker.groups[group_id]
        return len(group.liberties) == 0

    def play_move(self, move):
        if not self.is_move_legal(move):
            raise ValueError("Illegal move")
        self.tracker.add_stone(self.board, move, self.turn)
        # Update captures
        opp = BLACK if self.turn == WHITE else WHITE
        # Count captured stones
        for coord in ALL_COORDS:
            if self.board[coord] == opp:
                gid = self.tracker.stone_to_group.get(coord)
                if gid and not self.tracker.groups[gid].liberties:
                    self.captures[self.turn] += len(self.tracker.groups[gid].stones)
        # Ko rule: if move captures exactly one stone and results in a single empty point
        if len(self.tracker.groups) == 1:
            g = next(iter(self.tracker.groups.values()))
            if len(g.stones) == 1 and len(g.liberties) == 1:
                self.ko = next(iter(g.liberties))
            else:
                self.ko = None
        else:
            self.ko = None
        self.recent_moves.append((move, self.turn))
        self.turn = opp

    def score(self, komi=6.5):
        black_score = self.captures[BLACK]
        white_score = self.captures[WHITE]
        # Simple territory scoring
        visited = set()
        for coord in ALL_COORDS:
            if self.board[coord] == EMPTY and coord not in visited:
                queue = deque([coord])
                owner = None
                region = set()
                while queue:
                    c = queue.popleft()
                    if c in visited:
                        continue
                    visited.add(c)
                    region.add(c)
                    for n in NEIGHBORS[c]:
                        if self.board[n] == EMPTY:
                            queue.append(n)
                        else:
                            if owner is None:
                                owner = self.board[n]
                            elif owner != self.board[n]:
                                owner = None
                if owner == BLACK:
                    black_score += len(region)
                elif owner == WHITE:
                    white_score += len(region)
        white_score += komi
        return black_score, white_score

    def result(self, komi=6.5):
        black, white = self.score(komi)
        if abs(black - white) < 0.5:
            return "DRAW"
        winner = "B" if black > white else "W"
        diff = round(abs(black - white), 1)
        return f"{winner}+{diff}"

set_board_size(19)