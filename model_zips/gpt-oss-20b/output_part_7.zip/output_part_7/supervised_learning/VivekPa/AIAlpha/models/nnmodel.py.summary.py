import numpy as np
import pandas as pd
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, LSTM, Dense
from tensorflow.keras.regularizers import l2
from tensorflow.keras.optimizers import Adam


class NNModel:
    def __init__(self, input_shape: int):
        self.input_shape = input_shape
        self.model = self._build_model()

    def _build_model(self) -> Model:
        inp = Input(shape=(1, self.input_shape))
        lstm1 = LSTM(
            units=5,
            return_sequences=True,
            dropout=0.2,
            recurrent_dropout=0.2,
            activity_regularizer=l2(0.01),
            recurrent_regularizer=l2(0.01),
        )(inp)
        dense1 = Dense(
            units=5,
            activation="sigmoid",
            activity_regularizer=l2(0.005),
        )(lstm1)
        lstm2 = LSTM(
            units=2,
            dropout=0.2,
            recurrent_dropout=0.2,
            activity_regularizer=l2(0.01),
            recurrent_regularizer=l2(0.001),
        )(dense1)
        out = Dense(
            units=1,
            activation="sigmoid",
            activity_regularizer=l2(0.001),
        )(lstm2)
        model = Model(inputs=inp, outputs=out)
        return model

    def train(
        self,
        train_x: np.ndarray,
        train_y: np.ndarray,
        epochs: int = 10,
        save_model: bool = False,
        model_name: str = "nn_model.h5",
    ) -> None:
        if train_x.ndim == 2:
            train_x = train_x.reshape(train_x.shape[0], 1, self.input_shape)
        self.model.compile(optimizer=Adam(), loss="mse")
        self.model.fit(train_x, train_y, epochs=epochs, verbose=0)
        if save_model:
            self.model.save(model_name)

    def test(self, test_x: np.ndarray, test_y: np.ndarray) -> tuple:
        if test_x.ndim == 2:
            test_x = test_x.reshape(test_x.shape[0], 1, self.input_shape)
        return self.model.evaluate(test_x, test_y, verbose=0)

    def predict_ret(self, x: np.ndarray) -> pd.DataFrame:
        if x.ndim == 2:
            x = x.reshape(x.shape[0], 1, self.input_shape)
        preds = self.model.predict(x, verbose=0).flatten()
        return pd.DataFrame({"prediction": preds})

    def predict_prices(self, x: np.ndarray, prices: np.ndarray) -> tuple:
        if x.ndim == 2:
            x = x.reshape(x.shape[0], 1, self.input_shape)
        preds = self.model.predict(x, verbose=0).flatten()
        predicted_prices = np.exp(preds) * prices
        return preds.tolist(), predicted_prices.tolist()