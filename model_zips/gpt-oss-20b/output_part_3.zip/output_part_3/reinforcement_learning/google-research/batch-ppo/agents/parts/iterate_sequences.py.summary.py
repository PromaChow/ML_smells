import tensorflow as tf

def remove_padding(sequence: tf.Tensor, length: tf.Tensor) -> tf.Tensor:
    """
    Trims the input sequence to its actual length.

    Args:
        sequence: Tensor of shape [seq_len, ...].
        length: Scalar integer tensor representing the true length.

    Returns:
        Tensor of shape [length, ...].
    """
    return tf.slice(sequence, [0], [length])


def chunk_sequence(sequence: tf.Tensor,
                   length: tf.Tensor,
                   chunk_length: int) -> dict:
    """
    Splits the trimmed sequence into chunks of size `chunk_length`,
    padding the last chunk if necessary. Returns a dictionary with
    'chunks' and 'chunk_lengths'.

    Args:
        sequence: Tensor of shape [length, ...].
        length: Scalar integer tensor representing the true length.
        chunk_length: Desired chunk size.

    Returns:
        Dict containing:
            - 'chunks': Tensor of shape [num_chunks, chunk_length, ...].
            - 'chunk_lengths': Tensor of shape [num_chunks] with the actual
              length of each chunk (last chunk may be shorter).
    """
    # Trim to true length
    trimmed = tf.slice(sequence, [0], [length])
    # Compute number of chunks
    num_chunks = tf.cast(
        tf.math.ceil(tf.cast(length, tf.float32) / tf.cast(chunk_length, tf.float32)),
        tf.int32)
    # Pad sequence to full size
    padded_len = num_chunks * chunk_length
    padding_needed = padded_len - length
    padded = tf.pad(trimmed,
                    paddings=[[0, padding_needed]],
                    mode="CONSTANT")
    # Reshape into chunks
    chunks = tf.reshape(padded, [num_chunks, chunk_length])
    # Compute lengths for each chunk
    last_chunk_len = tf.math.mod(length, chunk_length)
    last_chunk_len = tf.where(tf.equal(last_chunk_len, 0), chunk_length, last_chunk_len)
    chunk_lengths = tf.fill([num_chunks], chunk_length)
    chunk_lengths = tf.tensor_scatter_nd_update(chunk_lengths,
                                                [[num_chunks - 1]],
                                                [last_chunk_len])
    return {"chunks": chunks, "chunk_lengths": chunk_lengths}


def iterate_sequences(sequences: tf.Tensor,
                      lengths: tf.Tensor,
                      chunk_length: int | None = None,
                      batch_size: int | None = None,
                      epochs: int = 1,
                      consumer_fn: callable | None = None) -> tf.Tensor:
    """
    Builds a data processing pipeline from sequences and their lengths,
    optionally applying chunking and batching, and processes the data
    with `consumer_fn` using tf.scan.

    Args:
        sequences: Tensor of shape [num_sequences, seq_len, ...].
        lengths: Tensor of shape [num_sequences] with actual lengths.
        chunk_length: If provided, sequences are split into chunks.
        batch_size: If provided, dataset is shuffled and batched.
        epochs: Number of times the dataset should be repeated.
        consumer_fn: Callable that takes (prev_state, batch) and returns
                     new state. Must be compatible with tf.scan.

    Returns:
        Tensor produced by the final state of tf.scan.
    """
    # Determine number of sequences
    num_sequences = tf.shape(lengths)[0]

    # Create dataset
    ds = tf.data.Dataset.from_tensor_slices((sequences, lengths))
    ds = ds.repeat(epochs)

    # Remove padding
    ds = ds.map(lambda seq, l: remove_padding(seq, l),
                num_parallel_calls=tf.data.AUTOTUNE)

    # Optional chunking
    if chunk_length is not None:
        ds = ds.map(lambda seq, l: chunk_sequence(seq, l, chunk_length),
                    num_parallel_calls=tf.data.AUTOTUNE)

    # Shuffling and batching
    if batch_size is not None:
        ds = ds.shuffle(buffer_size=1000, reshuffle_each_iteration=True)
        ds = ds.batch(batch_size, drop_remainder=False)
    else:
        ds = ds.batch(num_sequences)

    ds = ds.prefetch(tf.data.AUTOTUNE)

    # Convert dataset to tensor for tf.scan
    batches = list(ds)
    batched_tensor = tf.stack(batches, axis=0)

    # Define scan step
    def scan_step(prev_state, batch):
        return consumer_fn(prev_state, batch)

    # Initial state: zero tensor matching batch shape
    init_state = tf.zeros_like(batched_tensor[0])

    # Apply tf.scan
    final_state = tf.scan(scan_step, batched_tensor, initializer=init_state)

    return final_state


# Example consumer function: accumulate sum over batches
def sum_consumer(prev_state: tf.Tensor, batch: tf.Tensor) -> tf.Tensor:
    """
    Accumulates the sum of all elements in each batch.

    Args:
        prev_state: Tensor representing the cumulative sum so far.
        batch: Tensor of shape [batch_size, ...].

    Returns:
        Updated cumulative sum tensor.
    """
    return prev_state + tf.reduce_sum(batch)


# Example usage
if __name__ == "__main__":
    # Create dummy data
    num_sequences = 5
    seq_len = 10
    features = 3

    # Random sequences and lengths
    rng = tf.random.Generator.from_seed(42)
    sequences = rng.normal(shape=(num_sequences, seq_len, features), seed=1)
    lengths = tf.constant([8, 9, 7, 10, 6], dtype=tf.int32)

    # Run pipeline with chunking and batching
    result = iterate_sequences(sequences,
                               lengths,
                               chunk_length=4,
                               batch_size=2,
                               epochs=1,
                               consumer_fn=sum_consumer)

    print("Final accumulated sum:", result.numpy())
