import os
import urllib.request
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F


class Fp32GroupNorm(nn.Module):
    def __init__(self, num_groups: int, num_channels: int, eps: float = 1e-5, affine: bool = True):
        super().__init__()
        self.num_groups = num_groups
        self.num_channels = num_channels
        self.eps = eps
        self.affine = affine
        if affine:
            self.weight = nn.Parameter(torch.ones(num_channels))
            self.bias = nn.Parameter(torch.zeros(num_channels))
        else:
            self.register_parameter("weight", None)
            self.register_parameter("bias", None)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        orig_dtype = x.dtype
        x = x.to(torch.float32)
        out = F.group_norm(
            x,
            self.num_groups,
            weight=self.weight,
            bias=self.bias,
            eps=self.eps,
        )
        return out.to(orig_dtype)


class Fp32LayerNorm(nn.Module):
    def __init__(self, normalized_shape, eps: float = 1e-5, affine: bool = True):
        super().__init__()
        if isinstance(normalized_shape, int):
            normalized_shape = (normalized_shape,)
        self.normalized_shape = normalized_shape
        self.eps = eps
        self.affine = affine
        if affine:
            self.weight = nn.Parameter(torch.ones(*normalized_shape))
            self.bias = nn.Parameter(torch.zeros(*normalized_shape))
        else:
            self.register_parameter("weight", None)
            self.register_parameter("bias", None)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        orig_dtype = x.dtype
        x = x.to(torch.float32)
        out = F.layer_norm(
            x,
            self.normalized_shape,
            weight=self.weight,
            bias=self.bias,
            eps=self.eps,
        )
        return out.to(orig_dtype)


class TransposeLast(nn.Module):
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x.transpose(-1, -2)


def norm_block(
    num_features: int,
    is_layer_norm: bool = False,
    affine: bool = True,
    num_groups: int = 32,
) -> nn.Module:
    if is_layer_norm:
        return Fp32LayerNorm(num_features, affine=affine)
    else:
        return Fp32GroupNorm(num_groups, num_features, affine=affine)


class ConvFeatureExtractionModel(nn.Module):
    def __init__(
        self,
        conv_cfg,
        activation: nn.Module = nn.ReLU(),
        dropout: float = 0.0,
        log_compression: bool = True,
        residual_scale: float = 0.5,
        skip_connections_feat: bool = False,
        is_layer_norm: bool = False,
        num_groups: int = 32,
    ):
        super().__init__()
        self.activation = activation
        self.dropout = nn.Dropout(dropout)
        self.log_compression = log_compression
        self.residual_scale = residual_scale
        self.skip_connections_feat = skip_connections_feat
        self.is_layer_norm = is_layer_norm
        self.num_groups = num_groups

        layers = []
        in_channels = 1
        for idx, (out_channels, kernel_size, stride) in enumerate(conv_cfg):
            conv = nn.Conv1d(in_channels, out_channels, kernel_size, stride)
            norm = norm_block(
                out_channels,
                is_layer_norm=self.is_layer_norm,
                affine=True,
                num_groups=self.num_groups,
            )
            layers.append(nn.Sequential(conv, self.dropout, norm, self.activation))
            in_channels = out_channels

        self.layers = nn.ModuleList(layers)

        # Projection for residuals if channels differ
        self.residual_proj = None
        if self.skip_connections_feat:
            self.residual_proj = nn.Conv1d(1, out_channels, kernel_size=1, stride=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = x
        for layer in self.layers:
            residual = out
            out = layer(out)
            if self.skip_connections_feat:
                if self.residual_proj is not None:
                    residual = self.residual_proj(residual)
                out = out + residual * self.residual_scale
        if self.log_compression:
            out = torch.log(torch.abs(out) + 1)
        return out


class Wav2VecEncoder(nn.Module):
    def __init__(
        self,
        device: torch.device = torch.device("cpu"),
        pretrained: bool = False,
        pretrained_url: str = "https://dl.fbaipublicfiles.com/fairseq/wav2vec_large.pt",
        pretrained_path: str = "wav2vec_large.pt",
    ):
        super().__init__()
        self.device = device
        self.pretrained = pretrained
        self.pretrained_url = pretrained_url
        self.pretrained_path = pretrained_path

        conv_cfg = [
            (512, 10, 5),
            (512, 8, 4),
            (512, 4, 2),
            (512, 4, 2),
            (512, 4, 2),
            (512, 1, 1),
            (512, 1, 1),
        ]

        self.feature_extractor = ConvFeatureExtractionModel(
            conv_cfg,
            activation=nn.ReLU(),
            dropout=0.0,
            log_compression=True,
            residual_scale=0.5,
            skip_connections_feat=False,
            is_layer_norm=False,
            num_groups=32,
        ).to(self.device)

        if self.pretrained:
            self._load_pretrained_weights()

    def _download_pretrained(self):
        url = self.pretrained_url
        path = Path(self.pretrained_path)
        if not path.is_file():
            urllib.request.urlretrieve(url, str(path))

    def _load_pretrained_weights(self):
        self._download_pretrained()
        state_dict = torch.load(
            self.pretrained_path,
            map_location=self.device,
        )
        model_state = self.state_dict()
        filtered_state = {
            k: v for k, v in state_dict.items() if k in model_state
        }
        self.load_state_dict(filtered_state, strict=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x shape: (batch, time)
        x = x.unsqueeze(1)  # (batch, 1, time)
        return self.feature_extractor(x)


# Example usage:
# if __name__ == "__main__":
#     device = torch.device("cpu")
#     model = Wav2VecEncoder(device=device, pretrained=False)
#     dummy_input = torch.randn(2, 16000)  # batch of 2, 1-second audio at 16kHz
#     output = model(dummy_input)
#     print(output.shape)
