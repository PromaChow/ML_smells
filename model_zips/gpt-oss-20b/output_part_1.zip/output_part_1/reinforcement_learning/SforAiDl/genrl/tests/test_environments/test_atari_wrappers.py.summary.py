import os
import shutil

import gym
import numpy as np
from gym.wrappers import AtariPreprocessing, FrameStack

from stable_baselines3 import DQN


def test_atari_preprocessing():
    env = gym.make("Pong-v0")
    env = AtariPreprocessing(env, screen_size=84, frame_skip=1)
    state = env.reset()
    assert state.shape == (84, 84), f"Expected shape (84, 84), got {state.shape}"
    action = env.action_space.sample()
    next_state, reward, done, info = env.step(action)
    assert isinstance(next_state, np.ndarray), "next_state is not ndarray"
    assert isinstance(reward, (float, int)), "reward is not a number"
    assert isinstance(done, bool), "done is not bool"
    assert isinstance(info, dict), "info is not dict"
    env.close()


def test_frame_stack():
    env = gym.make("Pong-v0")
    env = FrameStack(env, 4)
    state = env.reset()
    # FrameStack returns shape (4, 210, 160, 3)
    assert state.shape == (4, 210, 160, 3), f"Expected shape (4, 210, 160, 3), got {state.shape}"
    action = env.action_space.sample()
    next_state, reward, done, info = env.step(action)
    assert isinstance(next_state, np.ndarray), "next_state is not ndarray"
    assert isinstance(reward, (float, int)), "reward is not a number"
    assert isinstance(done, bool), "done is not bool"
    assert isinstance(info, dict), "info is not dict"
    env.close()


def test_atari_env_and_training():
    env = gym.make("Pong-v0")
    env = AtariPreprocessing(env, screen_size=84, frame_skip=1)
    env = FrameStack(env, 4)

    model = DQN(
        "CnnPolicy",
        env,
        batch_size=5,
        buffer_size=100,
        net_arch=[1, 1],
        verbose=0,
        tensorboard_log="./logs",
    )

    # Warmup
    state = env.reset()
    for _ in range(10):
        action = env.action_space.sample()
        next_state, reward, done, info = env.step(action)
        if done:
            state = env.reset()
        else:
            state = next_state

    total_steps = 5 * 200
    remaining_steps = total_steps - 10
    model.learn(total_timesteps=remaining_steps)

    shutil.rmtree("./logs", ignore_errors=True)


if __name__ == "__main__":
    test_atari_preprocessing()
    test_frame_stack()
    test_atari_env_and_training()
    print("All tests completed successfully.")