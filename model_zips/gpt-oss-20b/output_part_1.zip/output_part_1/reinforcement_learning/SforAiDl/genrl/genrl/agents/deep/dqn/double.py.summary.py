import torch
from genrl.agents.deep.dqn.dqn import DQN
from genrl.agents.deep.dqn.utils import ddqn_q_target


class DoubleDQN(DQN):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.empty_logs()
        if getattr(self, "create_model", True):
            self._create_model()

    def get_target_q_values(self, batch, *args, **kwargs):
        return ddqn_q_target(self, batch, *args, **kwargs)