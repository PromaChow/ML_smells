import unittest
import numpy as np
from parameterized import parameterized

class Sprite:
    def __init__(self, position, color=None):
        self.position = np.array(position, dtype=float)
        self.color = color

class FindGoalPosition:
    def __init__(self, goal_position, terminate_distance, terminate_bonus,
                 weights_dimensions=(1.0, 1.0), raw_reward_multiplier=1.0,
                 sparse_reward=False):
        self.goal_position = np.array(goal_position, dtype=float)
        self.terminate_distance = terminate_distance
        self.terminate_bonus = terminate_bonus
        self.weights_dimensions = np.array(weights_dimensions, dtype=float)
        self.raw_reward_multiplier = raw_reward_multiplier
        self.sparse_reward = sparse_reward

    def evaluate(self, sprites):
        if not sprites:
            return np.nan, False
        distances = []
        for s in sprites:
            diff = s.position - self.goal_position
            weighted_diff = diff * self.weights_dimensions
            distances.append(np.linalg.norm(weighted_diff))
        min_dist = min(distances)
        success = min_dist <= self.terminate_distance
        if self.sparse_reward:
            reward = self.terminate_bonus if success else 0.0
        else:
            reward = (1.0 - min_dist) * self.raw_reward_multiplier
        return reward, success

class Clustering:
    def __init__(self, filter_distrib, termination_threshold,
                 terminate_bonus, reward_range=(0.0, 1.0), sparse_reward=False):
        self.filter_distrib = filter_distrib
        self.termination_threshold = termination_threshold
        self.terminate_bonus = terminate_bonus
        self.reward_range = reward_range
        self.sparse_reward = sparse_reward

    def evaluate(self, sprites):
        filtered = [s for s in sprites if s.color == self.filter_distrib]
        if len(filtered) < 2:
            return np.nan, False
        means = []
        for color in set(s.color for s in filtered):
            cluster = [s.position for s in filtered if s.color == color]
            means.append(np.mean(cluster, axis=0))
        distances = []
        for i in range(len(means)):
            for j in range(i + 1, len(means)):
                distances.append(np.linalg.norm(means[i] - means[j]))
        if not distances:
            return np.nan, False
        max_dist = max(distances)
        success = max_dist >= self.termination_threshold
        if self.sparse_reward:
            reward = self.terminate_bonus if success else 0.0
        else:
            scale = (max_dist - self.reward_range[0]) / (self.reward_range[1] - self.reward_range[0])
            reward = max(0.0, min(scale, 1.0))
        return reward, success

class MetaAggregated:
    def __init__(self, subtasks, aggregation_method='sum',
                 termination_condition='all', terminate_bonus=0.0):
        self.subtasks = subtasks
        self.aggregation_method = aggregation_method
        self.termination_condition = termination_condition
        self.terminate_bonus = terminate_bonus

    def evaluate(self, sprites):
        rewards = []
        successes = []
        for task in self.subtasks:
            reward, success = task.evaluate(sprites)
            rewards.append(reward)
            successes.append(success)
        if self.aggregation_method == 'sum':
            agg_reward = sum(rewards)
        elif self.aggregation_method == 'max':
            agg_reward = max(rewards)
        elif self.aggregation_method == 'min':
            agg_reward = min(rewards)
        elif self.aggregation_method == 'mean':
            agg_reward = sum(rewards) / len(rewards)
        else:
            agg_reward = 0.0
        if self.termination_condition == 'all':
            overall_success = all(successes)
        else:
            overall_success = any(successes)
        if overall_success:
            agg_reward += self.terminate_bonus
        return agg_reward, overall_success

class TestFindGoalPosition(unittest.TestCase):
    @parameterized.expand([
        # (goal, terminate_distance, terminate_bonus, weights, multiplier, sparse, sprites, expected_reward, expected_success)
        ((0, 0), 1.0, 10.0, (1.0, 1.0), 1.0, False,
         [Sprite((0, 0))], 1.0, True),
        ((0, 0), 1.0, 10.0, (1.0, 1.0), 1.0, False,
         [Sprite((3, 4))], -5.0, False),
        ((0, 0), 5.0, 5.0, (2.0, 0.5), 0.5, True,
         [Sprite((1, 1))], 5.0, True),
        ((0, 0), 0.5, 2.0, (1.0, 1.0), 1.0, True,
         [Sprite((1, 1))], 0.0, False),
        ((0, 0), 1.0, 10.0, (1.0, 1.0), 1.0, False,
         [], np.nan, False),
    ])
    def test_evaluate(self, goal, dist, bonus, weights, mult, sparse,
                      sprites, exp_reward, exp_success):
        task = FindGoalPosition(goal, dist, bonus, weights,
                                mult, sparse)
        reward, success = task.evaluate(sprites)
        if np.isnan(exp_reward):
            self.assertTrue(np.isnan(reward))
        else:
            self.assertAlmostEqual(reward, exp_reward, places=5)
        self.assertEqual(success, exp_success)

class TestClustering(unittest.TestCase):
    @parameterized.expand([
        # (filter, threshold, bonus, reward_range, sparse, sprites, exp_reward, exp_success)
        ('red', 1.0, 5.0, (0.0, 10.0), False,
         [Sprite((0, 0), 'red'), Sprite((10, 0), 'red')], 1.0, True),
        ('blue', 15.0, 10.0, (0.0, 20.0), False,
         [Sprite((0, 0), 'blue'), Sprite((10, 0), 'blue')], 0.0, False),
        ('green', 2.0, 3.0, (0.0, 5.0), True,
         [Sprite((0, 0), 'green'), Sprite((3, 4), 'green')], 3.0, True),
        ('yellow', 5.0, 7.0, (0.0, 10.0), True,
         [Sprite((0, 0), 'yellow')], 0.0, False),
        ('red', 1.0, 5.0, (0.0, 10.0), False,
         [], np.nan, False),
    ])
    def test_evaluate(self, filt, thresh, bonus, r_range, sparse,
                      sprites, exp_reward, exp_success):
        task = Clustering(filt, thresh, bonus, r_range, sparse)
        reward, success = task.evaluate(sprites)
        if np.isnan(exp_reward):
            self.assertTrue(np.isnan(reward))
        else:
            self.assertAlmostEqual(reward, exp_reward, places=5)
        self.assertEqual(success, exp_success)

class TestMetaAggregated(unittest.TestCase):
    @parameterized.expand([
        # (agg_method, term_cond, bonus, subtask_defs, sprites, exp_reward, exp_success)
        ('sum', 'all', 2.0,
         [{'goal':(0,0), 'dist':1.0, 'bonus':5.0, 'sparse':False},
          {'goal':(0,0), 'dist':2.0, 'bonus':5.0, 'sparse':False}],
         [Sprite((0,0)), Sprite((0,0))],
         2.0, True),
        ('max', 'any', 0.0,
         [{'goal':(0,0), 'dist':1.0, 'bonus':5.0, 'sparse':False},
          {'goal':(5,5), 'dist':1.0, 'bonus':5.0, 'sparse':False}],
         [Sprite((0,0)), Sprite((5,5))],
         1.0, True),
        ('min', 'all', 1.0,
         [{'goal':(0,0), 'dist':0.5, 'bonus':5.0, 'sparse':False},
          {'goal':(1,1), 'dist':0.5, 'bonus':5.0, 'sparse':False}],
         [Sprite((0,0)), Sprite((1,1))],
         -0.5 + 1.0, False),
        ('mean', 'any', 3.0,
         [{'goal':(0,0), 'dist':1.0, 'bonus':5.0, 'sparse':True},
          {'goal':(10,10), 'dist':1.0, 'bonus':5.0, 'sparse':True}],
         [Sprite((0,0)), Sprite((10,10))],
         5.0 + 3.0, True),
    ])
    def test_evaluate(self, agg, cond, bonus, subdefs, sprites,
                      exp_reward, exp_success):
        subtasks = []
        for d in subdefs:
            subtasks.append(
                FindGoalPosition(d['goal'], d['dist'], d['bonus'],
                                 sparse=d['sparse'])
            )
        task = MetaAggregated(subtasks, agg, cond, bonus)
        reward, success = task.evaluate(sprites)
        self.assertAlmostEqual(reward, exp_reward, places=5)
        self.assertEqual(success, exp_success)

if __name__ == "__main__":
    unittest.main()