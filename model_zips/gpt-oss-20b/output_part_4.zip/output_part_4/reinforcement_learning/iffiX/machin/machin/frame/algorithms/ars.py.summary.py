import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.multiprocessing as mp
import gym
import numpy as np
from collections import deque

# ---------- Actor Network ----------
class Actor(nn.Module):
    def __init__(self, state_dim, action_dim, hidden_dim=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, action_dim),
            nn.Tanh()
        )

    def forward(self, x):
        return self.net(x)

# ---------- Mean-Std Filter ----------
class MeanStdFilter:
    def __init__(self, shape, eps=1e-8):
        self.mean = torch.zeros(shape)
        self.var = torch.ones(shape)
        self.count = eps

    def update(self, x):
        batch_mean = x.mean(0)
        batch_var = x.var(0, unbiased=False)
        batch_count = x.size(0)

        delta = batch_mean - self.mean
        tot_count = self.count + batch_count

        new_mean = self.mean + delta * batch_count / tot_count
        m_a = self.var * (self.count - 1)
        m_b = batch_var * (batch_count - 1)
        M2 = m_a + m_b + torch.pow(delta, 2) * self.count * batch_count / tot_count
        new_var = M2 / (tot_count - 1)

        self.mean = new_mean
        self.var = new_var
        self.count = tot_count

    def normalize(self, x):
        return (x - self.mean) / (torch.sqrt(self.var) + 1e-8)

# ---------- Worker Function ----------
def worker_process(worker_id, env_name, shared_model, shared_noise, noise_std, rollout_idx_start,
                   rollout_idx_end, state_filter, result_queue, param_queue, barrier, batch_size):
    env = gym.make(env_name)
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.shape[0]
    param_shape = sum(p.numel() for p in shared_model.parameters())
    num_directions = shared_noise.shape[0]

    local_mean = torch.zeros_like(state_filter.mean)
    local_var = torch.zeros_like(state_filter.var)
    local_count = 0

    while True:
        barrier.wait()
        # Retrieve latest parameters
        shared_model_state = param_queue.get()
        shared_model.load_state_dict(shared_model_state)

        rewards_pos = []
        rewards_neg = []

        for idx in range(rollout_idx_start, rollout_idx_end):
            noise = shared_noise[idx]
            noise_tensor = torch.from_numpy(noise).float()

            # Positive perturbation
            pos_params = {}
            offset = 0
            for name, param in shared_model.named_parameters():
                numel = param.numel()
                delta = noise_tensor[offset:offset + numel].view_as(param)
                pos_params[name] = param.data + noise_std * delta
                offset += numel
            # Negative perturbation
            neg_params = {}
            offset = 0
            for name, param in shared_model.named_parameters():
                numel = param.numel()
                delta = noise_tensor[offset:offset + numel].view_as(param)
                neg_params[name] = param.data - noise_std * delta
                offset += numel

            # Run rollout with positive perturbation
            obs = env.reset()
            done = False
            ep_reward = 0.0
            while not done:
                obs_t = torch.tensor(obs, dtype=torch.float32)
                obs_norm = state_filter.normalize(obs_t)
                action = shared_model(obs_norm).detach().numpy()
                obs, reward, done, _ = env.step(action)
                ep_reward += reward
                local_mean += obs
                local_var += obs ** 2
                local_count += 1
            rewards_pos.append(ep_reward)

            # Run rollout with negative perturbation
            obs = env.reset()
            done = False
            ep_reward = 0.0
            while not done:
                obs_t = torch.tensor(obs, dtype=torch.float32)
                obs_norm = state_filter.normalize(obs_t)
                action = shared_model(obs_norm).detach().numpy()
                obs, reward, done, _ = env.step(action)
                ep_reward += reward
                local_mean += obs
                local_var += obs ** 2
                local_count += 1
            rewards_neg.append(ep_reward)

        result_queue.put((rewards_pos, rewards_neg, local_mean, local_var, local_count))

        barrier.wait()

# ---------- Manager ----------
def manager(env_name='CartPole-v1', num_workers=4, rollout_per_worker=5, steps=100,
            noise_dim=30, noise_std=0.02, lr=0.01, top_k=10, batch_size=32):
    env = gym.make(env_name)
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.shape[0]

    model = Actor(state_dim, action_dim)
    model.share_memory()
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)

    state_filter = MeanStdFilter(state_dim)

    total_rollouts = num_workers * rollout_per_worker
    param_shape = sum(p.numel() for p in model.parameters())
    shared_noise = torch.randn(noise_dim, param_shape)
    shared_noise_np = shared_noise.numpy()

    ctx = mp.get_context('spawn')
    result_queue = ctx.Queue()
    param_queue = ctx.Queue()
    barrier = ctx.Barrier(num_workers + 1)

    workers = []
    idx_start = 0
    for i in range(num_workers):
        idx_end = idx_start + rollout_per_worker
        p = ctx.Process(target=worker_process,
                        args=(i, env_name, model, shared_noise_np, noise_std,
                              idx_start, idx_end, state_filter,
                              result_queue, param_queue, barrier, batch_size))
        p.start()
        workers.append(p)
        idx_start = idx_end

    for step in range(steps):
        # Send current params to workers
        for _ in range(num_workers):
            param_queue.put(model.state_dict())
        barrier.wait()

        all_rewards_pos = []
        all_rewards_neg = []
        combined_mean = torch.zeros(state_dim)
        combined_var = torch.zeros(state_dim)
        combined_count = 0

        for _ in range(num_workers):
            rewards_pos, rewards_neg, local_mean, local_var, local_count = result_queue.get()
            all_rewards_pos.extend(rewards_pos)
            all_rewards_neg.extend(rewards_neg)
            combined_mean += local_mean
            combined_var += local_var
            combined_count += local_count

        # Update global state filter
        state_filter.mean = combined_mean / combined_count
        state_filter.var = (combined_var / combined_count) - state_filter.mean ** 2
        state_filter.count = combined_count

        rewards_pos = np.array(all_rewards_pos)
        rewards_neg = np.array(all_rewards_neg)

        best_rewards = np.maximum(rewards_pos, rewards_neg)
        top_indices = np.argsort(best_rewards)[-top_k:]

        grad = torch.zeros(param_shape)
        for idx in top_indices:
            noise = shared_noise[idx]
            diff = rewards_pos[idx] - rewards_neg[idx]
            grad += diff * noise

        grad = grad / (top_k * noise_std)
        grad_tensor = torch.from_numpy(grad).float()

        offset = 0
        for param in model.parameters():
            numel = param.numel()
            grad_slice = grad_tensor[offset:offset + numel].view_as(param)
            param.data += lr * grad_slice
            offset += numel

        barrier.wait()

    for p in workers:
        p.terminate()
    env.close()

if __name__ == '__main__':
    manager()