import tensorflow as tf

def vectorized_step(
    batch_env,
    algo,
    reset,
    log,
    score_var,
    length_var,
    mean_score,
    mean_length,
    prev_observations
):
    """
    Performs a vectorized in‑graph simulation step for a reinforcement learning
    algorithm with environment interactions.

    Args:
        batch_env: Environment object with reset, simulate, done, observations.
        algo: Algorithm object with begin_episode, perform, experience, end_episode.
        reset: Boolean tensor indicating whether to reset environments.
        log: Boolean tensor indicating whether to produce summaries.
        score_var: tf.Variable holding cumulative scores per agent.
        length_var: tf.Variable holding episode lengths per agent.
        mean_score: tf.keras.metrics.Mean for averaging scores.
        mean_length: tf.keras.metrics.Mean for averaging episode lengths.
        prev_observations: Tensor of previous observations per agent.

    Returns:
        done: Tensor indicating episode termination per agent.
        score_var: Updated scores tensor.
        summary: Merged summary tensor.
    """
    # ----- Reset logic ------------------------------------------------------
    with tf.control_dependencies([reset]):
        if tf.reduce_any(reset):
            batch_env.reset()

    done = batch_env.done

    new_episodes = tf.logical_or(reset, done)

    # ----- Episode initialization --------------------------------------------
    def init_new_episodes():
        indices = tf.reshape(tf.where(new_episodes), [-1])
        zero_scores = tf.zeros([tf.shape(indices)[0],], dtype=score_var.dtype)
        zero_lengths = tf.zeros([tf.shape(indices)[0],], dtype=length_var.dtype)
        score_var.scatter_update(tf.IndexedSlices(zero_scores, indices))
        length_var.scatter_update(tf.IndexedSlices(zero_lengths, indices))
        algo.begin_episode(indices)

    tf.cond(tf.reduce_any(new_episodes), init_new_episodes, lambda: None)

    # ----- Action selection --------------------------------------------------
    actions, perform_summary = algo.perform(prev_observations)

    # ----- Environment simulation --------------------------------------------
    new_observations, rewards, new_done, simulate_summary = batch_env.simulate(actions)

    # ----- Update length and score ------------------------------------------
    increment = tf.where(new_done, tf.zeros_like(length_var), tf.ones_like(length_var))
    score_increment = tf.where(new_done, tf.zeros_like(rewards), rewards)
    length_var.assign_add(increment)
    score_var.assign_add(score_increment)

    # ----- Experience processing ---------------------------------------------
    exp_summary = algo.experience(prev_observations, actions, rewards, new_done, new_observations)

    # ----- Episode termination handling -------------------------------------
    def handle_termination():
        indices = tf.reshape(tf.where(new_done), [-1])
        algo.end_episode(indices)
        mean_score.update_state(tf.gather(score_var, indices))
        mean_length.update_state(tf.gather(length_var, indices))

    tf.cond(tf.reduce_any(new_done), handle_termination, lambda: None)

    # ----- Summary generation ------------------------------------------------
    if log:
        mean_score_summary = tf.expand_dims(mean_score.result(), 0)
        mean_length_summary = tf.expand_dims(mean_length.result(), 0)
        summary = tf.concat(
            [perform_summary, exp_summary, mean_score_summary, mean_length_summary],
            axis=0,
        )
    else:
        summary = tf.concat([perform_summary, exp_summary], axis=0)

    return new_done, score_var, summary

# ---------------------------------------------------------------------------

# Example placeholders to illustrate usage (not part of core logic)

class DummyBatchEnv:
    def __init__(self, batch_size):
        self.batch_size = batch_size
        self.done = tf.zeros([batch_size], dtype=tf.bool)
        self.observations = tf.zeros([batch_size, 4])

    def reset(self):
        self.done = tf.zeros_like(self.done)
        self.observations = tf.zeros_like(self.observations)

    def simulate(self, actions):
        new_obs = self.observations + tf.cast(tf.expand_dims(actions, -1), tf.float32)
        rewards = tf.random.uniform([self.batch_size], minval=0.0, maxval=1.0)
        done = tf.cast(tf.random.uniform([self.batch_size], minval=0, maxval=2, dtype=tf.int32), tf.bool)
        summary = tf.zeros([1], dtype=tf.float32)
        return new_obs, rewards, done, summary

class DummyAlgo:
    def begin_episode(self, indices):
        pass

    def perform(self, observations):
        actions = tf.random.uniform([tf.shape(observations)[0]], minval=0, maxval=2, dtype=tf.int32)
        summary = tf.zeros([1], dtype=tf.float32)
        return actions, summary

    def experience(self, obs, actions, rewards, dones, new_obs):
        summary = tf.zeros([1], dtype=tf.float32)
        return summary

    def end_episode(self, indices):
        pass

# ---------------------------------------------------------------

# Usage example
batch_size = 5
env = DummyBatchEnv(batch_size)
algo = DummyAlgo()
score = tf.Variable(tf.zeros([batch_size], dtype=tf.float32))
length = tf.Variable(tf.zeros([batch_size], dtype=tf.int32))
mean_score_metric = tf.keras.metrics.Mean()
mean_length_metric = tf.keras.metrics.Mean()

prev_obs = tf.zeros([batch_size, 4], dtype=tf.float32)
reset = tf.zeros([batch_size], dtype=tf.bool)
log = tf.constant(True)

done, updated_score, summary = vectorized_step(
    env,
    algo,
    reset,
    log,
    score,
    length,
    mean_score_metric,
    mean_length_metric,
    prev_obs
)