import torch
import torch.nn as nn
from machin.auto.config import (
    generate_algorithm_config,
    generate_env_config,
    generate_training_config,
    launch,
)


class SomeQNet(nn.Module):
    def __init__(self, state_dim: int, action_num: int):
        super().__init__()
        self.fc1 = nn.Linear(state_dim, 128)
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, action_num)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = self.fc3(x)
        return x


def main() -> None:
    algo_cfg = generate_algorithm_config("DQN")

    env_cfg = generate_env_config("openai_gym", algo_cfg)

    training_cfg = generate_training_config(
        root_dir="trial",
        episode_per_epoch=10,
        max_episodes=10000,
        config=env_cfg,
    )

    frame_config = training_cfg.get("frame_config", {})
    frame_config["models"] = [SomeQNet, SomeQNet]
    frame_config["model_kwargs"] = {"state_dim": 4, "action_num": 2}
    training_cfg["frame_config"] = frame_config

    launch(training_cfg)


if __name__ == "__main__":
    main()
