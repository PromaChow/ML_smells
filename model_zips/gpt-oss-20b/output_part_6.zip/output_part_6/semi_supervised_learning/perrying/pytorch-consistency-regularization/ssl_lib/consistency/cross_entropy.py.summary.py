import torch
import torch.nn as nn
import torch.nn.functional as F

def cross_entropy(y: torch.Tensor, target: torch.Tensor, mask: torch.Tensor | None = None) -> torch.Tensor:
    """
    Compute the cross‑entropy loss between predictions `y` and `target`.

    Parameters
    ----------
    y : torch.Tensor
        Logits of shape (batch_size, num_classes).
    target : torch.Tensor
        Hard labels of shape (batch_size,) or soft labels of shape (batch_size, num_classes).
    mask : torch.Tensor, optional
        Binary mask of shape (batch_size,) indicating which samples to include.

    Returns
    -------
    torch.Tensor
        Scalar loss tensor.
    """
    # Step 1: Compute per‑sample loss
    if target.dim() == 1:
        # Hard labels
        loss = F.cross_entropy(y, target, reduction="none")
    else:
        # Soft labels
        log_probs = F.log_softmax(y, dim=1)
        loss = -(target * log_probs).sum(dim=1)

    # Step 2: Apply mask if provided
    if mask is not None:
        loss = loss * mask

    # Step 3: Return mean loss
    return loss.mean()

class CrossEntropy(nn.Module):
    """
    PyTorch module wrapping the custom cross‑entropy loss.
    """

    def __init__(self):
        super().__init__()

    def forward(
        self,
        y: torch.Tensor,
        target: torch.Tensor,
        mask: torch.Tensor | None = None,
        *args,
        **kwargs,
    ) -> torch.Tensor:
        """
        Forward pass for the loss module.

        Parameters
        ----------
        y : torch.Tensor
            Logits of shape (batch_size, num_classes).
        target : torch.Tensor
            Hard or soft labels.
        mask : torch.Tensor, optional
            Binary mask of shape (batch_size,).
        """
        detached_target = target.detach()
        return cross_entropy(y, detached_target, mask)