import pandas as pd
import numpy as np
from data_processor.base_bars import BaseBars
import os

def ensure_dir(file_path: str) -> None:
    os.makedirs(os.path.dirname(file_path), exist_ok=True)

def main() -> None:
    raw_data_path = "data/raw_data/price_vol.csv"

    # 1. Tick Bars Creation
    tick_output = "data/processed_data/price_bars/tick_bars.csv"
    ensure_dir(tick_output)
    tick_bars = BaseBars(raw_data_path, tick_output, "tick", 10)
    tick_bars.batch_run()

    # 2. Dollar Bars Creation
    dollar_output = "data/processed_data/price_bars/dollar_bars.csv"
    ensure_dir(dollar_output)
    dollar_bars = BaseBars(raw_data_path, dollar_output, "dollar", 20000)
    dollar_bars.batch_run()

    # 3. Volume Bars Creation
    volume_output = "data/processed_data/price_bars/volume_bars.csv"
    ensure_dir(volume_output)
    volume_bars = BaseBars(raw_data_path, volume_output, "volume", 50)
    volume_bars.batch_run()

if __name__ == "__main__":
    main()
