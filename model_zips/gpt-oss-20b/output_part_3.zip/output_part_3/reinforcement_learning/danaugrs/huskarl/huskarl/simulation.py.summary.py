import multiprocessing
from multiprocessing import Pipe, Process
from collections import namedtuple
from dataclasses import dataclass
from typing import Callable, Any, List, Dict, Optional
import matplotlib.pyplot as plt
import math


RewardState = namedtuple('RewardState', ['reward', 'state'])


@dataclass
class Transition:
    state: Any
    action: Any
    reward: float
    next_state: Any


class Simulation:
    def __init__(self,
                 create_env: Callable[[], Any],
                 agent: Any,
                 mapping: Optional[Dict] = None):
        self.create_env = create_env
        self.agent = agent
        self.mapping = mapping or {}

    def train(self,
              instances: int = 1,
              max_subprocesses: int = 1,
              max_steps: int = 1000,
              visualize: bool = False,
              plot: bool = False):
        if max_subprocesses <= 1:
            self._sp_train(instances, max_steps, visualize, plot)
        else:
            self._mp_train(instances, max_subprocesses, max_steps, visualize, plot)

    def _sp_train(self,
                  instances: int,
                  max_steps: int,
                  visualize: bool,
                  plot: bool):
        envs: List[Any] = [self.create_env() for _ in range(instances)]
        states = [env.reset() for env in envs]
        episode_reward_sequences: List[List[float]] = [[] for _ in range(instances)]
        episode_rewards: List[float] = [0.0 for _ in range(instances)]
        prev_states = [None for _ in range(instances)]
        prev_actions = [None for _ in range(instances)]

        for step in range(max_steps):
            for i, env in enumerate(envs):
                if visualize:
                    env.render()
                action = self.agent.act(states[i], i)
                next_state, reward, done, _ = env.step(action)
                transition = Transition(states[i], action, reward, next_state)
                self.agent.memory.push(transition)

                episode_rewards[i] += reward
                if done:
                    episode_reward_sequences[i].append(episode_rewards[i])
                    episode_rewards[i] = 0.0
                    next_state = env.reset()

                states[i] = next_state

            self.agent.train(step)

            if plot and step % 100 == 0:
                self._plot_rewards(episode_reward_sequences)

    def _mp_train(self,
                  instances: int,
                  max_subprocesses: int,
                  max_steps: int,
                  visualize: bool,
                  plot: bool):
        nprocesses = min(instances, max_subprocesses)
        instances_per_process = math.ceil(instances / nprocesses)

        # Create pipes for each instance
        instance_pipes: Dict[int, Any] = {}
        child_conns: Dict[int, Any] = {}
        for i in range(instances):
            parent_conn, child_conn = Pipe()
            instance_pipes[i] = parent_conn
            child_conns[i] = child_conn

        # Distribute instance ids to processes
        processes = []
        for p in range(nprocesses):
            start = p * instances_per_process
            end = min(start + instances_per_process, instances)
            ids = list(range(start, end))
            child_conns_subset = [child_conns[i] for i in ids]
            proc = Process(target=self._train,
                           args=(self.create_env, ids, max_steps,
                                 child_conns_subset, visualize))
            proc.start()
            processes.append(proc)

        # Initial state reception
        states: Dict[int, Any] = {}
        episode_reward_sequences: Dict[int, List[float]] = {}
        current_episode_reward: Dict[int, float] = {}
        for i in range(instances):
            rs: RewardState = instance_pipes[i].recv()
            states[i] = rs.state
            episode_reward_sequences[i] = []
            current_episode_reward[i] = 0.0

        # Main training loop
        for step in range(max_steps):
            for i in range(instances):
                rs: RewardState = instance_pipes[i].recv()
                if rs.reward is not None:
                    transition = Transition(states[i], None, rs.reward, rs.state)
                    self.agent.memory.push(transition)
                    current_episode_reward[i] += rs.reward
                if rs.state is None:
                    episode_reward_sequences[i].append(current_episode_reward[i])
                    current_episode_reward[i] = 0.0
                states[i] = rs.state
                action = self.agent.act(rs.state, i)
                instance_pipes[i].send(action)

            self.agent.train(step)

            if plot and step % 100 == 0:
                self._plot_rewards(list(episode_reward_sequences.values()))

        # Clean up
        for proc in processes:
            proc.join()
        for conn in instance_pipes.values():
            conn.close()

    @staticmethod
    def _train(create_env: Callable[[], Any],
               instance_ids: List[int],
               max_steps: int,
               child_conns: List[Any],
               visualize: bool):
        envs: Dict[int, Any] = {}
        for idx, conn in zip(instance_ids, child_conns):
            env = create_env()
            state = env.reset()
            envs[idx] = env
            conn.send(RewardState(None, state))

        for step in range(max_steps):
            for idx, conn in zip(instance_ids, child_conns):
                action = conn.recv()
                env = envs[idx]
                if visualize:
                    env.render()
                next_state, reward, done, _ = env.step(action)
                if done:
                    conn.send(RewardState(reward, None))
                    state = env.reset()
                    conn.send(RewardState(None, state))
                else:
                    conn.send(RewardState(reward, next_state))

    def _plot_rewards(self, reward_sequences: List[List[float]]):
        plt.figure(figsize=(10, 5))
        for seq in reward_sequences:
            plt.plot(seq)
        plt.xlabel('Episode')
        plt.ylabel('Reward')
        plt.title('Episode Rewards')
        plt.show()

    def test(self, max_steps: int = 1000, visualize: bool = False):
        env = self.create_env()
        state = env.reset()
        for _ in range(max_steps):
            if visualize:
                env.render()
            action = self.agent.act(state, 0)
            next_state, reward, done, _ = env.step(action)
            if not done:
                state = next_state
            else:
                break

# End of module
