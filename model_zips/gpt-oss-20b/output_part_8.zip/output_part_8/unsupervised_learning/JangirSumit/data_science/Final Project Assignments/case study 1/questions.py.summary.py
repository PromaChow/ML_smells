import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error

# Load dataset
df = pd.read_csv("OnlineNewsPopularity.csv")
print(df.head())

# Separate independent and dependent variables
X = df.iloc[:, :59]
Y = df["shares"]

# Correlation matrix and heatmap
corr_matrix = X.corr()
plt.figure(figsize=(20, 20))
sns.heatmap(corr_matrix, cmap="coolwarm", linewidths=0.5)
plt.title("Feature Correlation Heatmap")
plt.show()

# Split data into training and testing sets
X_train, X_test, Y_train, Y_test = train_test_split(
    X, Y, test_size=0.2, random_state=5
)

# Initialize and train linear regression model
model = LinearRegression()
model.fit(X_train, Y_train)

# Predict on test set
Y_pred = model.predict(X_test)

# Evaluate model performance
mse = mean_squared_error(Y_test, Y_pred)
print(f"Mean Squared Error: {mse:.4f}")

# Scatter plot of predicted vs actual values
plt.figure(figsize=(8, 6))
plt.scatter(Y_pred, Y_test, alpha=0.6)
plt.xlabel("Predicted Shares")
plt.ylabel("Actual Shares")
plt.title("Predicted vs Actual Shares")
plt.plot([Y_test.min(), Y_test.max()], [Y_test.min(), Y_test.max()], 'r--')
plt.show()