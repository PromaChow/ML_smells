from collections import namedtuple
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401


EpisodeStats = namedtuple('EpisodeStats', ['lengths', 'rewards'])


def plot_cost_to_go_mountain_car(env, estimator, num_tiles=200):
    low = env.observation_space.low
    high = env.observation_space.high

    pos = np.linspace(low[0], high[0], num_tiles)
    vel = np.linspace(low[1], high[1], num_tiles)
    X, Y = np.meshgrid(pos, vel)
    states = np.column_stack([X.ravel(), Y.ravel()])

    def predict_state(state):
        return -estimator.predict(state.reshape(1, -1))[0]

    Z = np.apply_along_axis(predict_state, 1, states).reshape(X.shape)

    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    surf = ax.plot_surface(X, Y, Z, cmap='viridis')
    fig.colorbar(surf, ax=ax, shrink=0.5, aspect=10)
    ax.set_xlabel('Position')
    ax.set_ylabel('Velocity')
    ax.set_zlabel('Value')
    ax.set_title("Mountain 'Cost To Go' Function")
    return fig


def plot_value_function(V, title='Value Function'):
    player_vals = sorted({k[0] for k in V.keys()})
    dealer_vals = sorted({k[1] for k in V.keys()})
    X, Y = np.meshgrid(player_vals, dealer_vals)

    def lookup(state, usable_ace):
        key = (state[0], state[1], usable_ace)
        return V.get(key, 0.0)

    def compute_surface(usable_ace):
        Z = np.apply_along_axis(
            lambda p: np.apply_along_axis(
                lambda d: lookup((p, d), usable_ace), 0, dealer_vals), 0, player_vals)
        return Z

    Z_noace = compute_surface(False)
    Z_ace = compute_surface(True)

    def plot_surface(X, Y, Z, ace):
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        surf = ax.plot_surface(X, Y, Z, cmap='viridis')
        fig.colorbar(surf, ax=ax, shrink=0.5, aspect=10)
        ax.set_xlabel('Player Sum')
        ax.set_ylabel('Dealer Showing')
        ax.set_zlabel('Value')
        ace_text = 'Usable Ace' if ace else 'No Usable Ace'
        ax.set_title(f'{title} - {ace_text}')
        return fig

    fig1 = plot_surface(X, Y, Z_noace, False)
    fig2 = plot_surface(X, Y, Z_ace, True)
    return fig1, fig2


def plot_episode_stats(stats, window=10, noshow=False):
    fig1, ax1 = plt.subplots()
    ax1.plot(range(1, len(stats.lengths) + 1), stats.lengths, label='Episode Length')
    ax1.set_xlabel('Episode')
    ax1.set_ylabel('Episode Length')
    ax1.set_title('Episode Length over Time')
    ax1.legend()

    rewards_series = pd.Series(stats.rewards)
    smoothed = rewards_series.rolling(window=window, min_periods=1).mean()

    fig2, ax2 = plt.subplots()
    ax2.plot(range(1, len(smoothed) + 1), smoothed, color='orange')
    ax2.set_xlabel('Episode')
    ax2.set_ylabel('Smoothed Reward')
    ax2.set_title(f'Smoothed Reward (window={window})')

    cumulative_steps = np.cumsum(stats.lengths)
    fig3, ax3 = plt.subplots()
    ax3.plot(range(1, len(cumulative_steps) + 1), cumulative_steps, color='green')
    ax3.set_xlabel('Episode')
    ax3.set_ylabel('Cumulative Time Steps')
    ax3.set_title('Cumulative Time Steps vs Episodes')

    if noshow:
        plt.close('all')
    else:
        plt.show()

    return fig1, fig2, fig3
