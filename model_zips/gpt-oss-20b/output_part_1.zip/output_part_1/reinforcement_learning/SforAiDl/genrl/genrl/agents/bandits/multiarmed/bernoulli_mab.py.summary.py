import numpy as np

class MultiArmedBandit:
    """
    Minimal placeholder for the parent class.
    It stores basic parameters and provides a method to set the current bandit.
    """
    def __init__(self, bandits: int, arms: int, context_type):
        self.bandits = bandits
        self.arms = arms
        self.context_type = context_type
        self.curr_bandit = 0

    def set_current_bandit(self, bandit_index: int):
        if not (0 <= bandit_index < self.bandits):
            raise ValueError(f"bandit_index must be between 0 and {self.bandits - 1}")
        self.curr_bandit = bandit_index

class BernoulliMAB(MultiArmedBandit):
    """
    Contextual bandit with categorical context and Bernoulli reward distribution.
    """
    def __init__(self, bandits: int, arms: int, reward_probs=None, context_type=None):
        super().__init__(bandits, arms, context_type)

        if reward_probs is not None:
            self.reward_probs = np.asarray(reward_probs)
            if self.reward_probs.shape != (bandits, arms):
                raise ValueError(f"reward_probs must have shape ({bandits}, {arms})")
        else:
            self.reward_probs = np.random.random((bandits, arms))

    def _compute_reward(self, action: int):
        """
        Sample a reward for the given action according to a Bernoulli distribution.

        Parameters
        ----------
        action : int
            The chosen arm index.

        Returns
        -------
        tuple
            (reward, max_reward), where reward is 0 or 1 and max_reward is 1.
        """
        if not (0 <= action < self.arms):
            raise ValueError(f"action must be between 0 and {self.arms - 1}")

        prob = self.reward_probs[self.curr_bandit, action]
        rand_val = np.random.random()
        reward = 1 if rand_val > prob else 0
        return reward, 1
