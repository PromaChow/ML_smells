import argparse
import os
import random
import sys
from pathlib import Path
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import gym
import gym.vector
from collections import deque, namedtuple

# ----------------------------------------------------------------------
# Utility functions
# ----------------------------------------------------------------------
def set_random_seed(seed: int, use_cuda: bool = False):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if use_cuda:
        torch.cuda.manual_seed_all(seed)

def ensure_dir(dir_path):
    Path(dir_path).mkdir(parents=True, exist_ok=True)

# ----------------------------------------------------------------------
# Replay buffer
# ----------------------------------------------------------------------
class ReplayBuffer:
    Transition = namedtuple('Transition',
                            ('state', 'action', 'reward', 'next_state', 'done'))

    def __init__(self, capacity, obs_dim, action_dim):
        self.capacity = capacity
        self.ptr = 0
        self.size = 0
        self.state = np.zeros((capacity, obs_dim), dtype=np.float32)
        self.action = np.zeros((capacity, action_dim), dtype=np.float32)
        self.reward = np.zeros((capacity, 1), dtype=np.float32)
        self.next_state = np.zeros((capacity, obs_dim), dtype=np.float32)
        self.done = np.zeros((capacity, 1), dtype=np.float32)

    def push(self, state, action, reward, next_state, done):
        idx = self.ptr
        self.state[idx] = state
        self.action[idx] = action
        self.reward[idx] = reward
        self.next_state[idx] = next_state
        self.done[idx] = done
        self.ptr = (self.ptr + 1) % self.capacity
        self.size = min(self.size + 1, self.capacity)

    def sample(self, batch_size):
        indices = np.random.choice(self.size, batch_size, replace=False)
        return (torch.tensor(self.state[indices]),
                torch.tensor(self.action[indices]),
                torch.tensor(self.reward[indices]),
                torch.tensor(self.next_state[indices]),
                torch.tensor(self.done[indices]))

    def __len__(self):
        return self.size

# ----------------------------------------------------------------------
# Networks
# ----------------------------------------------------------------------
class MLP(nn.Module):
    def __init__(self, input_dim, output_dim, hidden_sizes=(256,256), activation=nn.ReLU, use_bn=False):
        super().__init__()
        layers = []
        last_dim = input_dim
        for h in hidden_sizes:
            layers.append(nn.Linear(last_dim, h))
            if use_bn:
                layers.append(nn.BatchNorm1d(h))
            layers.append(activation())
            last_dim = h
        layers.append(nn.Linear(last_dim, output_dim))
        self.model = nn.Sequential(*layers)

    def forward(self, x):
        return self.model(x)

class DeterministicPolicy(nn.Module):
    def __init__(self, obs_dim, action_dim, hidden_sizes=(256,256), activation=nn.ReLU, use_bn=False):
        super().__init__()
        self.net = MLP(obs_dim, action_dim, hidden_sizes, activation, use_bn)
        self.action_limit = None  # to be set later

    def forward(self, state):
        return self.net(state)

    def set_action_limit(self, low, high):
        self.action_limit = (low + high) / 2.0
        self.action_range = (high - low) / 2.0

    def clip(self, action):
        if self.action_limit is None:
            return action
        return torch.clamp(action, self.action_limit - self.action_range, self.action_limit + self.action_range)

class QFunction(nn.Module):
    def __init__(self, obs_dim, action_dim, hidden_sizes=(256,256), activation=nn.ReLU, use_bn=False):
        super().__init__()
        self.net = MLP(obs_dim + action_dim, 1, hidden_sizes, activation, use_bn)

    def forward(self, state, action):
        x = torch.cat([state, action], dim=-1)
        return self.net(x)

# ----------------------------------------------------------------------
# Ornstein-Uhlenbeck noise
# ----------------------------------------------------------------------
class OUNoise:
    def __init__(self, action_dim, mu=0.0, theta=0.15, sigma=0.2):
        self.action_dim = action_dim
        self.mu = mu
        self.theta = theta
        self.sigma = sigma
        self.state = np.ones(self.action_dim) * self.mu

    def reset(self):
        self.state = np.ones(self.action_dim) * self.mu

    def sample(self):
        dx = self.theta * (self.mu - self.state) + self.sigma * np.random.randn(self.action_dim)
        self.state = self.state + dx
        return self.state

# ----------------------------------------------------------------------
# DDPG agent
# ----------------------------------------------------------------------
class DDPGAgent:
    def __init__(self, obs_dim, action_dim, action_low, action_high, device, actor_lr, critic_lr,
                 gamma, tau, target_update_method='soft', target_update_interval=1,
                 update_interval=1, updates_per_step=1, replay_start_size=1000,
                 exploration_noise=0.2, batch_size=64):
        self.device = device
        self.obs_dim = obs_dim
        self.action_dim = action_dim
        self.action_low = action_low
        self.action_high = action_high
        self.gamma = gamma
        self.tau = tau
        self.target_update_method = target_update_method
        self.target_update_interval = target_update_interval
        self.update_interval = update_interval
        self.updates_per_step = updates_per_step
        self.replay_start_size = replay_start_size
        self.batch_size = batch_size

        # Networks
        self.actor = DeterministicPolicy(obs_dim, action_dim, use_bn=False).to(device)
        self.actor_target = DeterministicPolicy(obs_dim, action_dim, use_bn=False).to(device)
        self.critic = QFunction(obs_dim, action_dim, use_bn=False).to(device)
        self.critic_target = QFunction(obs_dim, action_dim, use_bn=False).to(device)

        self.actor_target.load_state_dict(self.actor.state_dict())
        self.critic_target.load_state_dict(self.critic.state_dict())

        # Optimizers
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=actor_lr)
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=critic_lr)

        # Replay buffer
        self.replay_buffer = ReplayBuffer(capacity=500000, obs_dim=obs_dim, action_dim=action_dim)

        # Exploration noise
        self.exploration_noise = exploration_noise
        self.noise = OUNoise(action_dim)

    def select_action(self, state, deterministic=False):
        state = torch.tensor(state, dtype=torch.float32, device=self.device).unsqueeze(0)
        action = self.actor(state).detach().cpu().numpy()[0]
        if not deterministic:
            noise = self.noise.sample() * self.exploration_noise
            action = action + noise
        action = np.clip(action, self.action_low, self.action_high)
        return action

    def train(self, envs, num_steps, eval_envs=None, eval_interval=1000, save_path=None):
        episode_rewards = []
        total_steps = 0
        start_time = None
        self.noise.reset()
        for step in range(1, num_steps + 1):
            states = envs.reset() if step == 1 else states
            actions = np.array([self.select_action(s) for s in states])
            next_states, rewards, dones, infos = envs.step(actions)
            for s, a, r, ns, d in zip(states, actions, rewards, next_states, dones):
                self.replay_buffer.push(s, a, r, ns, d)
            states = next_states

            if len(self.replay_buffer) >= self.replay_start_size:
                for _ in range(self.updates_per_step):
                    self._update_networks()

            if step % self.target_update_interval == 0:
                self._soft_update(self.actor, self.actor_target)
                self._soft_update(self.critic, self.critic_target)

            if eval_envs is not None and step % eval_interval == 0:
                mean_ret, std_ret = self.evaluate(eval_envs, n_episodes=5)
                print(f"Step {step}: Eval Mean Return: {mean_ret:.2f} Std: {std_ret:.2f}")
                if save_path:
                    torch.save(self.actor.state_dict(), os.path.join(save_path, f"actor_{step}.pth"))
                    torch.save(self.critic.state_dict(), os.path.join(save_path, f"critic_{step}.pth"))

    def _update_networks(self):
        states, actions, rewards, next_states, dones = self.replay_buffer.sample(self.batch_size)
        states = states.to(self.device)
        actions = actions.to(self.device)
        rewards = rewards.to(self.device)
        next_states = next_states.to(self.device)
        dones = dones.to(self.device)

        with torch.no_grad():
            next_actions = self.actor_target(next_states)
            target_q = self.critic_target(next_states, next_actions)
            target_q = rewards + (1 - dones) * self.gamma * target_q

        current_q = self.critic(states, actions)
        critic_loss = nn.functional.mse_loss(current_q, target_q)
        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        nn.utils.clip_grad_norm_(self.critic.parameters(), 1.0)
        self.critic_optimizer.step()

        actor_loss = -self.critic(states, self.actor(states)).mean()
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        nn.utils.clip_grad_norm_(self.actor.parameters(), 1.0)
        self.actor_optimizer.step()

    def _soft_update(self, source, target):
        for src_param, tgt_param in zip(source.parameters(), target.parameters()):
            tgt_param.data.copy_(self.tau * src_param.data + (1.0 - self.tau) * tgt_param.data)

    def evaluate(self, envs, n_episodes=5):
        returns = []
        for _ in range(n_episodes):
            state = envs.reset()[0]
            done = False
            total_reward = 0.0
            while not done:
                action = self.select_action(state, deterministic=True)
                next_state, reward, done, _ = envs.step([action])
                total_reward += reward[0]
                state = next_state[0]
            returns.append(total_reward)
        return np.mean(returns), np.std(returns)

# ----------------------------------------------------------------------
# Environment creation
# ----------------------------------------------------------------------
def make_env(env_name, seed, rank, eval_mode=False, monitor=False):
    def _thunk():
        env = gym.make(env_name)
        env.seed(seed + rank)
        np.random.seed(seed + rank)
        torch.manual_seed(seed + rank)
        if monitor:
            env = gym.wrappers.Monitor(env, f"videos/{env_name}_seed{seed}_rank{rank}", force=True)
        return env
    return _thunk

def create_vector_env(env_name, n_envs, seed, eval_mode=False, monitor=False):
    env_fns = [make_env(env_name, seed, i, eval_mode, monitor) for i in range(n_envs)]
    vec_env = gym.vector.AsyncVectorEnv(env_fns)
    return vec_env

# ----------------------------------------------------------------------
# Argument parsing
# ----------------------------------------------------------------------
def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--env_name", type=str, default="HalfCheetah-v4")
    parser.add_argument("--output_dir", type=str, default="results/ddpg")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--gpu", type=int, default=0)
    parser.add_argument("--actor_lr", type=float, default=1e-4)
    parser.add_argument("--critic_lr", type=float, default=1e-3)
    parser.add_argument("--gamma", type=float, default=0.99)
    parser.add_argument("--tau", type=float, default=0.005)
    parser.add_argument("--target_update_method", type=str, default="soft")
    parser.add_argument("--target_update_interval", type=int, default=1)
    parser.add_argument("--update_interval", type=int, default=1)
    parser.add_argument("--updates_per_step", type=int, default=1)
    parser.add_argument("--replay_start_size", type=int, default=1000)
    parser.add_argument("--exploration_noise", type=float, default=0.2)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--steps", type=int, default=200000)
    parser.add_argument("--eval_interval", type=int, default=5000)
    parser.add_argument("--eval_n_runs", type=int, default=5)
    parser.add_argument("--n_train_envs", type=int, default=8)
    parser.add_argument("--n_test_envs", type=int, default=2)
    parser.add_argument("--demo", action="store_true")
    parser.add_argument("--load", type=str, default=None)
    parser.add_argument("--reward_scale_factor", type=float, default=1.0)
    parser.add_argument("--monitor", action="store_true")
    return parser.parse_args()

# ----------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------
def main():
    args = parse_args()
    ensure_dir(args.output_dir)

    use_cuda = torch.cuda.is_available() and args.gpu >= 0
    device = torch.device(f"cuda:{args.gpu}" if use_cuda else "cpu")
    set_random_seed(args.seed, use_cuda)

    # Create environments
    train_envs = create_vector_env(args.env_name, args.n_train_envs, args.seed, eval_mode=False, monitor=args.monitor)
    test_envs = create_vector_env(args.env_name, args.n_test_envs, args.seed + 1000, eval_mode=True, monitor=args.monitor)

    obs_space = train_envs.single_observation_space
    action_space = train_envs.single_action_space
    obs_dim = obs_space.shape[0]
    action_dim = action_space.shape[0]
    action_low = action_space.low
    action_high = action_space.high

    # Scale rewards
    def reward_filter(reward):
        return reward * args.reward_scale_factor

    # Wrap test envs to apply reward scaling
    test_envs.env_fns = [lambda env=test_envs: gym.wrappers.TransformReward(env, reward_filter) for env in test_envs.env_fns]

    # Initialize agent
    agent = DDPGAgent(obs_dim, action_dim, action_low, action_high, device,
                      args.actor_lr, args.critic_lr, args.gamma, args.tau,
                      args.target_update_method, args.target_update_interval,
                      args.update_interval, args.updates_per_step,
                      args.replay_start_size, args.exploration_noise,
                      args.batch_size)

    # Load pre-trained model if provided
    if args.load:
        agent.actor.load_state_dict(torch.load(args.load, map_location=device))
        agent.critic.load_state_dict(torch.load(args.load, map_location=device))
        agent.actor_target.load_state_dict(agent.actor.state_dict())
        agent.critic_target.load_state_dict(agent.critic.state_dict())
        print(f"Loaded model from {args.load}")

    if args.demo:
        mean_ret, std_ret = agent.evaluate(test_envs, n_episodes=args.eval_n_runs)
        print(f"Demo: Mean return {mean_ret:.2f} Std {std_ret:.2f}")
    else:
        agent.train(train_envs, args.steps, eval_envs=test_envs,
                    eval_interval=args.eval_interval, save_path=args.output_dir)

if __name__ == "__main__":
    main()
