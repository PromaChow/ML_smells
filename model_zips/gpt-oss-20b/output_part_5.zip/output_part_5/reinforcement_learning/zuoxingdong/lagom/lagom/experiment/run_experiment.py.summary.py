import os
import sys
import shutil
import pathlib
import pickle
import yaml
import itertools
import concurrent.futures
import torch
import cloudpickle
from typing import Dict, Any, List, Tuple

# --------------------------------------------------------------------------- #
# Assumed external modules
# --------------------------------------------------------------------------- #
# These modules must provide the following:
#   config.make_configs() -> Dict[str, Any]
#   experiment.run(config, seed, device, logdir) -> Any
# --------------------------------------------------------------------------- #
import config
import experiment

# --------------------------------------------------------------------------- #
# Utility classes
# --------------------------------------------------------------------------- #
class CloudpickleWrapper:
    def __init__(self, obj):
        self.obj = obj

    def __call__(self, *args, **kwargs):
        return self.obj(*args, **kwargs)

    def __getstate__(self):
        return cloudpickle.dumps(self.obj)

    def __setstate__(self, state):
        self.obj = cloudpickle.loads(state)

# --------------------------------------------------------------------------- #
# Core functions
# --------------------------------------------------------------------------- #
def init_logging_dir(root: pathlib.Path) -> pathlib.Path:
    if root.exists():
        print(f"Logging directory '{root}' already exists.")
        while True:
            choice = input("Choose action: [c]lean, [r]ename, [q]uit: ").strip().lower()
            if choice == 'c':
                shutil.rmtree(root)
                root.mkdir(parents=True, exist_ok=True)
                break
            elif choice == 'r':
                new_name = root.parent / f"old_{root.name}"
                shutil.move(str(root), str(new_name))
                root.mkdir(parents=True, exist_ok=True)
                break
            elif choice == 'q':
                sys.exit(0)
    else:
        root.mkdir(parents=True, exist_ok=True)
    return root

def backup_source_files(root: pathlib.Path) -> None:
    src_dir = pathlib.Path.cwd()
    backup_dir = root / "source_files"
    backup_dir.mkdir(exist_ok=True)
    for py_file in src_dir.glob("*.py"):
        shutil.copy2(py_file, backup_dir / py_file.name)

def create_dir_structure(configs: Dict[str, Any], seeds: List[int], root: pathlib.Path) -> None:
    for cfg_id in configs:
        cfg_dir = root / cfg_id
        cfg_dir.mkdir(exist_ok=True)
        for seed in seeds:
            (cfg_dir / str(seed)).mkdir(exist_ok=True)

def save_configs(configs: Dict[str, Any], root: pathlib.Path) -> None:
    for cfg_id, cfg_obj in configs.items():
        cfg_path = root / cfg_id / "config.yml"
        with cfg_path.open("w") as f:
            yaml.safe_dump(cfg_obj, f)
    all_path = root / "configs.pkl"
    with all_path.open("wb") as f:
        pickle.dump(configs, f)

def generate_jobs(configs: Dict[str, Any], seeds: List[int]) -> List[Tuple[int, Any, int]]:
    jobs = []
    for idx, (cfg_id, cfg_obj) in enumerate(configs.items()):
        for seed in seeds:
            jobs.append((idx, cfg_obj, seed))
    return jobs

def _run(job: Tuple[int, Any, int],
         use_gpu: bool,
         gpu_ids: List[int],
         run_func,
         root: pathlib.Path) -> Any:
    job_id, cfg_obj, seed = job
    torch.set_num_threads(1)

    if use_gpu and torch.cuda.is_available():
        device_idx = gpu_ids[job_id % len(gpu_ids)]
        device = torch.device(f"cuda:{device_idx}")
    else:
        device = torch.device("cpu")

    logdir = root / f"{job_id}"
    logdir.mkdir(parents=True, exist_ok=True)

    print(f"Running job {job_id} | Seed: {seed} | Device: {device} | PID: {os.getpid()}")
    print(f"Config: {cfg_obj}")

    result = run_func(cfg_obj, seed, device, logdir)

    if use_gpu and torch.cuda.is_available():
        torch.cuda.empty_cache()

    return result

# --------------------------------------------------------------------------- #
# Main orchestrator
# --------------------------------------------------------------------------- #
def run_experiments(root_dir: str,
                    seeds: List[int],
                    max_workers: int = None,
                    use_gpu: bool = True,
                    gpu_ids: List[int] = None) -> List[Any]:
    if gpu_ids is None:
        gpu_ids = list(range(torch.cuda.device_count())) or [0]
    root = init_logging_dir(pathlib.Path(root_dir).resolve())
    backup_source_files(root)

    configs = config.make_configs()
    create_dir_structure(configs, seeds, root)
    save_configs(configs, root)

    jobs = generate_jobs(configs, seeds)

    results = []
    if max_workers is None:
        for job in jobs:
            results.append(_run(job, use_gpu, gpu_ids, experiment.run, root))
    else:
        with concurrent.futures.ProcessPoolExecutor(max_workers=max_workers) as executor:
            futures = {executor.submit(CloudpickleWrapper(_run),
                                       job,
                                       use_gpu,
                                       gpu_ids,
                                       experiment.run,
                                       root): job for job in jobs}
            for future in concurrent.futures.as_completed(futures):
                results.append(future.result())

    print(f"Experiment completed. Logs are available at: {root.absolute()}")
    return results

# --------------------------------------------------------------------------- #
# Example usage
# --------------------------------------------------------------------------- #
if __name__ == "__main__":
    # Example seeds and workers; modify as needed
    SEEDS = [42, 123, 456]
    MAX_WORKERS = 4
    RUN_DIR = "experiment_logs"

    run_experiments(root_dir=RUN_DIR,
                    seeds=SEEDS,
                    max_workers=MAX_WORKERS,
                    use_gpu=True,
                    gpu_ids=[0, 1])
