import os
import math
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
from torch.distributions import Categorical, Normal

def orthogonal_init(module, gain=1.0):
    if isinstance(module, nn.Linear):
        nn.init.orthogonal_(module.weight, gain)
        if module.bias is not None:
            nn.init.zeros_(module.bias)

class CategoricalHead(nn.Module):
    def __init__(self, in_dim, out_dim):
        super().__init__()
        self.linear = nn.Linear(in_dim, out_dim)
        orthogonal_init(self.linear)

    def forward(self, x):
        logits = self.linear(x)
        return Categorical(logits=logits)

class DiagGaussianHead(nn.Module):
    def __init__(self, in_dim, out_dim):
        super().__init__()
        self.mean_linear = nn.Linear(in_dim, out_dim)
        self.log_std_linear = nn.Linear(in_dim, out_dim)
        orthogonal_init(self.mean_linear)
        orthogonal_init(self.log_std_linear)

    def forward(self, x):
        mean = self.mean_linear(x)
        log_std = self.log_std_linear(x)
        std = torch.exp(log_std)
        return Normal(mean, std)

class VHead(nn.Module):
    def __init__(self, in_dim):
        super().__init__()
        self.linear = nn.Linear(in_dim, 1)
        orthogonal_init(self.linear, gain=0.01)

    def forward(self, x):
        return self.linear(x).squeeze(-1)

class Actor(nn.Module):
    def __init__(self, obs_dim, action_space, config):
        super().__init__()
        layers = []
        input_dim = obs_dim
        for size in config['nn.sizes']:
            layers.append(nn.Linear(input_dim, size))
            layers.append(nn.ReLU())
            orthogonal_init(layers[-2])
            input_dim = size
        self.base = nn.Sequential(*layers)
        if isinstance(action_space, int):  # discrete
            self.head = CategoricalHead(input_dim, action_space)
        else:  # continuous
            self.head = DiagGaussianHead(input_dim, action_space)

    def forward(self, x):
        x = self.base(x)
        return self.head(x)

class Critic(nn.Module):
    def __init__(self, obs_dim, config):
        super().__init__()
        layers = []
        input_dim = obs_dim
        for size in config['nn.sizes']:
            layers.append(nn.Linear(input_dim, size))
            layers.append(nn.ReLU())
            orthogonal_init(layers[-2])
            input_dim = size
        self.base = nn.Sequential(*layers)
        self.v_head = VHead(input_dim)

    def forward(self, x):
        x = self.base(x)
        return self.v_head(x)

class PPOAgent:
    def __init__(self, env, config):
        self.env = env
        obs_dim = env.observation_space.shape[0]
        action_space = env.action_space.n if hasattr(env.action_space, 'n') else env.action_space.shape[0]
        self.actor = Actor(obs_dim, action_space, config).to(torch.device('cpu'))
        self.critic = Critic(obs_dim, config).to(torch.device('cpu'))
        self.actor_opt = optim.Adam(self.actor.parameters(), lr=config['agent.lr'])
        self.critic_opt = optim.Adam(self.critic.parameters(), lr=config['agent.lr'])
        if config['agent.use_lr_scheduler']:
            self.actor_scheduler = optim.lr_scheduler.LinearLR(self.actor_opt, total_iters=config['agent.epochs'])
            self.critic_scheduler = optim.lr_scheduler.LinearLR(self.critic_opt, total_iters=config['agent.epochs'])
        else:
            self.actor_scheduler = None
            self.critic_scheduler = None
        self.config = config
        self.timesteps = 0

    def choose_action(self, observation):
        obs = torch.tensor(observation, dtype=torch.float32).unsqueeze(0)
        dist = self.actor(obs)
        if isinstance(dist, Categorical):
            action = dist.sample()
        else:
            action = dist.sample()
        log_prob = dist.log_prob(action).detach()
        entropy = dist.entropy().detach()
        value = self.critic(obs).detach()
        return action.cpu().numpy(), log_prob, entropy, value

    def _compute_returns_and_advantages(self, trajectories):
        obs = torch.tensor([t['obs'] for t in trajectories], dtype=torch.float32)
        rewards = torch.tensor([t['reward'] for t in trajectories], dtype=torch.float32)
        dones = torch.tensor([t['done'] for t in trajectories], dtype=torch.float32)
        values = torch.tensor([t['value'] for t in trajectories], dtype=torch.float32)
        next_values = torch.tensor([t['next_value'] for t in trajectories], dtype=torch.float32)

        gamma = self.config['agent.gamma']
        lam = self.config['agent.gae_lambda']
        returns = []
        advantages = []
        gae = 0
        for i in reversed(range(len(trajectories))):
            delta = rewards[i] + gamma * next_values[i] * (1 - dones[i]) - values[i]
            gae = delta + gamma * lam * (1 - dones[i]) * gae
            advantages.insert(0, gae)
            ret = gae + values[i]
            returns.insert(0, ret)
        adv_tensor = torch.stack(advantages)
        ret_tensor = torch.stack(returns)
        if self.config['agent.standardize_adv']:
            adv_tensor = (adv_tensor - adv_tensor.mean()) / (adv_tensor.std() + 1e-8)
        return ret_tensor, adv_tensor

    def learn(self, trajectories):
        ret, adv = self._compute_returns_and_advantages(trajectories)
        actions = torch.tensor([t['action'] for t in trajectories], dtype=torch.float32)
        log_probs_old = torch.stack([t['log_prob'] for t in trajectories])
        values_old = torch.tensor([t['value'] for t in trajectories], dtype=torch.float32)
        entropies_old = torch.stack([t['entropy'] for t in trajectories])

        dataset = TensorDataset(
            torch.tensor([t['obs'] for t in trajectories], dtype=torch.float32),
            actions, log_probs_old, entropies_old, values_old, ret, adv
        )
        loader = DataLoader(dataset, batch_size=self.config['agent.batch_size'], shuffle=True)

        clip_param = self.config['agent.clip_param']
        value_loss_coef = self.config['agent.value_loss_coef']
        entropy_coef = self.config['agent.entropy_coef']

        policy_losses, value_losses, entropy_losses, kl_losses, clip_fractions = [], [], [], [], []

        for _ in range(self.config['agent.epochs']):
            for batch in loader:
                obs_batch, act_batch, logp_old_batch, ent_old_batch, val_old_batch, ret_batch, adv_batch = batch

                dist = self.actor(obs_batch)
                logp = dist.log_prob(act_batch).sum(-1)
                entropy = dist.entropy().sum(-1)
                ratio = (logp - logp_old_batch).exp()
                surrogate1 = ratio * adv_batch
                surrogate2 = torch.clamp(ratio, 1 - clip_param, 1 + clip_param) * adv_batch
                policy_loss = -torch.min(surrogate1, surrogate2).mean()

                values = self.critic(obs_batch)
                value_clipped = val_old_batch + torch.clamp(values - val_old_batch, -clip_param, clip_param)
                value_loss1 = (values - ret_batch).pow(2)
                value_loss2 = (value_clipped - ret_batch).pow(2)
                value_loss = 0.5 * torch.max(value_loss1, value_loss2).mean()

                entropy_loss = -entropy.mean()

                total_loss = policy_loss + value_loss_coef * value_loss + entropy_coef * entropy_loss

                self.actor_opt.zero_grad()
                self.critic_opt.zero_grad()
                total_loss.backward()
                nn.utils.clip_grad_norm_(self.actor.parameters(), self.config['agent.max_grad_norm'])
                nn.utils.clip_grad_norm_(self.critic.parameters(), self.config['agent.max_grad_norm'])
                self.actor_opt.step()
                self.critic_opt.step()

                if self.actor_scheduler:
                    self.actor_scheduler.step()
                if self.critic_scheduler:
                    self.critic_scheduler.step()

                with torch.no_grad():
                    kl = (logp_old_batch - logp).mean()
                    clip_frac = ((ratio - 1.0).abs() > clip_param).float().mean()
                    policy_losses.append(policy_loss.item())
                    value_losses.append(value_loss.item())
                    entropy_losses.append(entropy.mean().item())
                    kl_losses.append(kl.item())
                    clip_fractions.append(clip_frac.item())

        metrics = {
            'policy_loss': sum(policy_losses) / len(policy_losses),
            'value_loss': sum(value_losses) / len(value_losses),
            'entropy': sum(entropy_losses) / len(entropy_losses),
            'kl_divergence': sum(kl_losses) / len(kl_losses),
            'clip_fraction': sum(clip_fractions) / len(clip_fractions),
        }
        self.timesteps += len(trajectories)
        if self.timesteps % self.config['agent.checkpoint_every'] == 0:
            os.makedirs(self.config['agent.checkpoint_path'], exist_ok=True)
            torch.save({
                'actor': self.actor.state_dict(),
                'critic': self.critic.state_dict(),
                'timesteps': self.timesteps
            }, os.path.join(self.config['agent.checkpoint_path'], f'ppo_{self.timesteps}.pt'))
        return metrics
