import collections
import numpy as np
import os
import traceback
from datetime import datetime

import gymnasium as gym
from gymnasium.vector import SyncVectorEnv

class Agent:
    def __init__(self, policy, buffer_size=10000, learning_rate=1e-3):
        self.policy = policy
        self.buffer = []
        self.learning_rate = learning_rate

    def batch_act_and_train(self, observations):
        # Placeholder: random actions
        return np.random.randint(self.policy.action_space.n, size=observations.shape[0])

    def batch_observe_and_train(self, obs, rewards, dones, resets):
        # Placeholder: store transitions
        for o, r, d, s in zip(obs, rewards, dones, resets):
            self.buffer.append((o, r, d, s))
        # Dummy training step
        if len(self.buffer) > 1000:
            self.buffer = self.buffer[-1000:]

    def get_stats(self):
        return {"buffer_size": len(self.buffer)}

    def save(self, path):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "wb") as f:
            f.write(b"agent_state_placeholder")

    @staticmethod
    def load(path):
        return Agent(policy=None)


class Evaluator:
    def __init__(self, eval_env, eval_episodes=5):
        self.eval_env = eval_env
        self.eval_episodes = eval_episodes

    def run(self, agent):
        total_reward = 0.0
        for _ in range(self.eval_episodes):
            obs, _ = self.eval_env.reset()
            done = False
            episode_reward = 0.0
            while not done:
                action = agent.batch_act_and_train(obs[np.newaxis])[0]
                obs, reward, done, info = self.eval_env.step(action)
                episode_reward += reward
            total_reward += episode_reward
        avg_reward = total_reward / self.eval_episodes
        return avg_reward


def train_loop(
    agent,
    env,
    evaluator=None,
    steps=1_000_000,
    max_episode_len=1000,
    log_interval=10_000,
    checkpoint_freq=50_000,
    return_window_size=100,
    successful_score=None,
    checkpoint_dir="checkpoints",
):
    """
    Trains an agent in a batched environment with optional evaluation.
    """
    batch_size = env.num_envs
    recent_returns = collections.deque(maxlen=return_window_size)

    episode_r = np.zeros(batch_size, dtype=np.float32)
    episode_idx = np.arange(batch_size, dtype=np.int32)
    episode_len = np.zeros(batch_size, dtype=np.int32)

    obs, info = env.reset()
    rs = np.zeros(batch_size, dtype=np.float32)

    total_steps = 0
    last_log_step = 0
    last_ckpt_step = 0
    best_score = -np.inf

    try:
        while total_steps < steps:
            # Action selection
            actions = agent.batch_act_and_train(obs)

            # Environment step
            new_obs, rewards, dones, infos = env.step(actions)

            # Episode tracking
            episode_r += rewards
            episode_len += 1

            # Determine resets
            resets = np.logical_or(dones, episode_len >= max_episode_len)

            # Agent observe
            agent.batch_observe_and_train(new_obs, rewards, dones, resets)

            # Episode termination handling
            ended = resets
            if np.any(ended):
                finished_indices = np.where(ended)[0]
                for idx in finished_indices:
                    recent_returns.append(episode_r[idx])
                episode_r[ended] = 0.0
                episode_len[ended] = 0

                # Reset environments that finished
                obs, info = env.reset_at(ended)
                rs[ended] = 0.0

            obs = new_obs
            rs = rewards
            total_steps += batch_size

            # Checkpointing
            if checkpoint_freq > 0 and total_steps - last_ckpt_step >= checkpoint_freq:
                ckpt_path = os.path.join(
                    checkpoint_dir,
                    f"agent_step_{total_steps}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.ckpt",
                )
                agent.save(ckpt_path)
                last_ckpt_step = total_steps

            # Logging
            if total_steps - last_log_step >= log_interval:
                avg_recent = np.mean(recent_returns) if recent_returns else 0.0
                stats = agent.get_stats()
                print(
                    f"Step {total_steps}/{steps} | "
                    f"AvgReturn({len(recent_returns)}): {avg_recent:.2f} | "
                    f"Stats: {stats}"
                )
                last_log_step = total_steps

            # Evaluation
            if evaluator is not None:
                eval_score = evaluator.run(agent)
                print(f"Evaluation score: {eval_score:.2f}")
                if eval_score > best_score:
                    best_score = eval_score
                    best_ckpt_path = os.path.join(
                        checkpoint_dir,
                        f"best_agent_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.ckpt",
                    )
                    agent.save(best_ckpt_path)
                    print(f"New best score! Saved to {best_ckpt_path}")
                if successful_score is not None and eval_score >= successful_score:
                    print(
                        f"Success criterion met: {eval_score} >= {successful_score}. Stopping training."
                    )
                    break

    except Exception as e:
        print("Exception encountered during training:", str(e))
        traceback.print_exc()
        ckpt_path = os.path.join(
            checkpoint_dir,
            f"exception_agent_step_{total_steps}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.ckpt",
        )
        agent.save(ckpt_path)
        print(f"Agent state saved to {ckpt_path} before exiting.")
        raise

    finally:
        env.close()
        final_ckpt_path = os.path.join(
            checkpoint_dir,
            f"final_agent_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.ckpt",
        )
        agent.save(final_ckpt_path)
        print(f"Training finished. Final agent state saved to {final_ckpt_path}.")


# Example usage (requires a real environment and policy):
if __name__ == "__main__":
    env_fns = [lambda: gym.make("CartPole-v1") for _ in range(8)]
    env = SyncVectorEnv(env_fns)
    agent = Agent(policy=None)
    eval_env = gym.make("CartPole-v1")
    evaluator = Evaluator(eval_env)

    train_loop(
        agent,
        env,
        evaluator=evaluator,
        steps=100_000,
        max_episode_len=500,
        log_interval=5_000,
        checkpoint_freq=20_000,
        return_window_size=50,
        successful_score=195.0,
        checkpoint_dir="checkpoints",
    )