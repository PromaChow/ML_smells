import unittest
from mab_agents import (
    EpsGreedyMABAgent,
    UCBMABAgent,
    GradientMABAgent,
    BayesianUCBMABAgent,
    ThompsonSamplingMABAgent,
)
from mab_bandits import GaussianMAB, BernoulliMAB
from mab_trainer import MABTrainer


class TestMABAgent(unittest.TestCase):
    def test_epsgreedy_gaussian(self):
        bandit = GaussianMAB(arms=10, context_type="int")
        agent = EpsGreedyMABAgent(bandit=bandit)
        trainer = MABTrainer(agent=agent, bandit=bandit)
        trainer.train(timesteps=10)

    def test_epsgreedy_bernoulli(self):
        bandit = BernoulliMAB(arms=10, context_type="int")
        agent = EpsGreedyMABAgent(bandit=bandit)
        trainer = MABTrainer(agent=agent, bandit=bandit)
        trainer.train(timesteps=10)

    def test_ucb_gaussian(self):
        bandit = GaussianMAB(arms=10, context_type="int")
        agent = UCBMABAgent(bandit=bandit)
        trainer = MABTrainer(agent=agent, bandit=bandit)
        trainer.train(timesteps=10)

    def test_ucb_bernoulli(self):
        bandit = BernoulliMAB(arms=10, context_type="int")
        agent = UCBMABAgent(bandit=bandit)
        trainer = MABTrainer(agent=agent, bandit=bandit)
        trainer.train(timesteps=10)

    def test_gradient_gaussian(self):
        bandit = GaussianMAB(arms=10, context_type="int")
        agent = GradientMABAgent(bandit=bandit)
        trainer = MABTrainer(agent=agent, bandit=bandit)
        trainer.train(timesteps=10)

    def test_gradient_bernoulli(self):
        bandit = BernoulliMAB(arms=10, context_type="int")
        agent = GradientMABAgent(bandit=bandit)
        trainer = MABTrainer(agent=agent, bandit=bandit)
        trainer.train(timesteps=10)

    def test_bayesianucb_gaussian(self):
        bandit = GaussianMAB(arms=10, context_type="int")
        agent = BayesianUCBMABAgent(bandit=bandit)
        trainer = MABTrainer(agent=agent, bandit=bandit)
        trainer.train(timesteps=10)

    def test_bayesianucb_bernoulli(self):
        bandit = BernoulliMAB(arms=10, context_type="int")
        agent = BayesianUCBMABAgent(bandit=bandit)
        trainer = MABTrainer(agent=agent, bandit=bandit)
        trainer.train(timesteps=10)

    def test_thompson_bernoulli(self):
        bandit = BernoulliMAB(arms=10, context_type="int")
        agent = ThompsonSamplingMABAgent(bandit=bandit)
        trainer = MABTrainer(agent=agent, bandit=bandit)
        trainer.train(timesteps=10)


if __name__ == "__main__":
    unittest.main()