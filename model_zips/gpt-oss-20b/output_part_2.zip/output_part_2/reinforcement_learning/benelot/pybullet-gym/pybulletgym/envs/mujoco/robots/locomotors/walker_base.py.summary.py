import math
import random
import numpy as np
import pybullet as p


class WalkerBase:
    def __init__(self,
                 robot_id,
                 bullet_client,
                 scene,
                 power=1.0,
                 camera_x=0.0,
                 start_pos_x=0.0,
                 start_pos_y=0.0,
                 start_pos_z=0.0,
                 walk_target_x=1e3,
                 walk_target_y=0.0):
        self.robot_id = robot_id
        self._p = bullet_client
        self.scene = scene
        self.power = power
        self.camera_x = camera_x
        self.start_pos_x = start_pos_x
        self.start_pos_y = start_pos_y
        self.start_pos_z = start_pos_z
        self.walk_target_x = walk_target_x
        self.walk_target_y = walk_target_y
        self.body_xyz = np.array([0.0, 0.0, 0.0])
        self.initial_z = None
        self.feet = []
        self.feet_contact = []
        self.joint_power_coeff = []

    def robot_specific_reset(self):
        # Assign physics client
        self._p = self._p
        # Randomly initialize joint positions
        joint_count = self._p.getNumJoints(self.robot_id)
        for joint_index in range(joint_count):
            random_pos = random.uniform(-0.1, 0.1)
            self._p.resetJointState(self.robot_id, joint_index, random_pos)
        # Identify feet (simple heuristic: link names containing 'foot')
        for joint_index in range(joint_count):
            joint_info = self._p.getJointInfo(self.robot_id, joint_index)
            joint_name = joint_info[12].decode('utf-8')
            if 'foot' in joint_name.lower():
                self.feet.append(joint_index)
        # Initialize foot contact forces
        self.feet_contact = np.zeros(len(self.feet))
        # Register robot (placeholder)
        # Set initial torso position
        pos, orn = self._p.getBasePositionAndOrientation(self.robot_id)
        self.body_xyz = np.array(pos)
        self.initial_z = pos[2]
        # Initialize joint power coefficients (example: 1.0 for all)
        self.joint_power_coeff = [1.0 for _ in range(joint_count)]

    def apply_action(self, a):
        joint_count = self._p.getNumJoints(self.robot_id)
        for i in range(joint_count):
            coeff = self.joint_power_coeff[i]
            if coeff == 0:
                continue
            action_value = np.clip(a[i], -1.0, 1.0)
            torque = self.power * coeff * action_value
            self._p.setJointMotorControl2(
                bodyIndex=self.robot_id,
                jointIndex=i,
                controlMode=p.TORQUE_CONTROL,
                force=torque
            )

    def calc_state(self):
        # Joint positions and velocities
        joint_states = self._p.getJointStates(self.robot_id, range(self._p.getNumJoints(self.robot_id)))
        positions = np.array([state[0] for state in joint_states])
        velocities = np.array([state[1] for state in joint_states])
        # Separate even indices for positions, odd for velocities
        joint_positions = positions
        joint_speeds = velocities
        # Joints near limits (simple threshold)
        joints_at_limit = np.sum(np.abs(joint_positions) > 0.99 * np.pi)
        # Body pose
        pos, orn = self._p.getBasePositionAndOrientation(self.robot_id)
        self.body_xyz = np.array(pos)
        body_rpy = p.getEulerFromQuaternion(orn)
        z_offset = pos[2] - self.initial_z
        # Target computations
        target_dx = self.walk_target_x - pos[0]
        target_dy = self.walk_target_y - pos[1]
        target_distance = math.hypot(target_dx, target_dy)
        target_angle = math.atan2(target_dy, target_dx)
        # Linear velocity
        lin_vel, ang_vel = self._p.getBaseVelocity(self.robot_id)
        # Transform linear velocity to body frame
        rot_matrix = np.array(p.getMatrixFromQuaternion(orn)).reshape(3, 3)
        body_vel = rot_matrix.T @ np.array(lin_vel)
        vx, vy, vz = body_vel
        # Foot contact forces (placeholder)
        foot_forces = np.zeros(len(self.feet))
        # Concatenate all components
        state = np.concatenate([
            [z_offset],
            [target_angle],
            [vx, vy, vz],
            [body_rpy[0], body_rpy[1], body_rpy[2]],
            joint_positions,
            joint_speeds,
            [joints_at_limit],
            foot_forces
        ])
        # Clip
        state = np.clip(state, -5.0, 5.0)
        return state

    def calc_potential(self):
        pos, _ = self._p.getBasePositionAndOrientation(self.robot_id)
        target_dx = self.walk_target_x - pos[0]
        target_dy = self.walk_target_y - pos[1]
        distance = math.hypot(target_dx, target_dy)
        try:
            dt = self.scene.dt
        except AttributeError:
            dt = None
        if dt is None or dt == 0:
            return -distance
        return -distance / dt
```