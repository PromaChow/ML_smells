import tensorflow as tf
import numpy as np

class WideResNet(tf.keras.Model):
    def __init__(self, option):
        super().__init__()
        self.training_mode = option.get('train', False)
        self.mean = tf.constant(option.get('mean', [0.0, 0.0, 0.0]), dtype=tf.float32)
        self.std = tf.constant(option.get('std', [1.0, 1.0, 1.0]), dtype=tf.float32)
        self.repeat = option.get('repeat', 1)
        self.filters = option.get('filters', [16, 32, 64])
        self.scales = option.get('scales', [1, 1, 1])
        self.dropout = option.get('dropout', 1.0)
        self.classes = option.get('classes', 10)
        self.activate_before_residual = option.get('activate_before_residual', True)
        self.leaky_relu = tf.keras.layers.LeakyReLU(alpha=0.1)

    def _conv_initializer(self, kernel_size, filters):
        stddev = 1.0 / tf.math.sqrt(0.5 * kernel_size * kernel_size * tf.cast(filters, tf.float32))
        return tf.keras.initializers.RandomNormal(stddev=stddev)

    def residual(self, x0, filters, stride=1, activate_before_residual=None, training=None):
        if activate_before_residual is None:
            activate_before_residual = self.activate_before_residual
        x = tf.keras.layers.BatchNormalization(momentum=0.999, epsilon=1e-5)(x0, training=training)
        x = self.leaky_relu(x)
        if activate_before_residual:
            x0 = x
        # first 3x3 conv
        conv1 = tf.keras.layers.Conv2D(
            filters, kernel_size=3, strides=stride, padding='same',
            kernel_initializer=self._conv_initializer(3, filters))
        x = conv1(x)
        x = tf.keras.layers.BatchNormalization(momentum=0.999, epsilon=1e-5)(x, training=training)
        x = self.leaky_relu(x)
        # second 3x3 conv
        conv2 = tf.keras.layers.Conv2D(
            filters, kernel_size=3, strides=1, padding='same',
            kernel_initializer=self._conv_initializer(3, filters))
        x = conv2(x)
        # adjust x0 if channel dims differ
        if tf.shape(x0)[-1] != filters:
            conv0 = tf.keras.layers.Conv2D(
                filters, kernel_size=1, strides=stride, padding='same',
                kernel_initializer=self._conv_initializer(1, filters))
            x0 = conv0(x0)
        return x + x0

    def call(self, inputs, training=None):
        # Normalize input
        x = tf.cast(inputs, tf.float32) / 255.0
        x = x[..., ::-1]  # reverse channels
        x = (x - self.mean) / self.std

        # Initial 3x3 conv with 16 filters
        init0 = tf.keras.initializers.RandomNormal(
            stddev=1.0 / tf.math.sqrt(0.5 * 3 * 3 * 16))
        x = tf.keras.layers.Conv2D(
            16, kernel_size=3, strides=1, padding='same',
            kernel_initializer=init0)(x)

        # Residual blocks
        for idx, filt in enumerate(self.filters):
            stride = 1 if idx == 0 else 2
            x = self.residual(
                x, filt, stride=stride,
                activate_before_residual=self.activate_before_residual,
                training=training)
            for _ in range(self.repeat - 1):
                x = self.residual(
                    x, filt, stride=1,
                    activate_before_residual=False,
                    training=training)

        # Final batchnorm and activation
        x = tf.keras.layers.BatchNormalization(momentum=0.999, epsilon=1e-5)(x, training=training)
        x = self.leaky_relu(x)

        # Global average pooling to get embeddings
        embeds = tf.reduce_mean(x, axis=[1, 2])

        # Dropout if enabled and training
        if self.dropout < 1.0 and training:
            embeds = tf.nn.dropout(embeds, rate=1.0 - self.dropout)

        # Dense layer to produce logits
        logits = tf.keras.layers.Dense(
            self.classes, kernel_initializer='glorot_normal')(embeds)

        # Softmax predictions
        predictions = tf.nn.softmax(logits)

        return {'logits': logits, 'embeddings': embeds, 'predictions': predictions}