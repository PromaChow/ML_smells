import gymnasium as gym
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from collections import namedtuple, deque
from torch.distributions import Normal
from torch.utils.tensorboard import SummaryWriter
import numpy as np
import os

# Hyperparameters and constants
ENV_NAME = "BipedalWalker-v2"
MAX_ITER = 500000
TRAJECTORY_SIZE = 2049
GAMMA = 0.99
LAMBDA = 0.95
BATCH_SIZE = 64
PPO_EPOCHS = 7
POLICY_LR = 0.0004
VALUE_LR = 0.001
CLIP_EPS = 0.2
N_ITER_TEST = 100
TEST_EPISODES = 5
CHECKPOINT_PATH = "ppo_bipedalwalker.pt"

device = torch.device("cpu")

Memory = namedtuple("Memory", [
    "obs", "act", "logp", "val", "reward", "done", "next_val",
    "adv", "ret"
])

class A2C_policy(nn.Module):
    def __init__(self, obs_dim, act_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 64),
            nn.ReLU(),
            nn.Linear(64, act_dim)
        )
        self.log_std = nn.Parameter(torch.zeros(act_dim))

    def forward(self, x):
        mean = torch.tanh(self.net(x))
        std = self.log_std.exp()
        return mean, std

class A2C_value(nn.Module):
    def __init__(self, obs_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 64),
            nn.ReLU(),
            nn.Linear(64, 1)
        )

    def forward(self, x):
        return self.net(x)

class Env:
    def __init__(self, env, traj_size):
        self.env = env
        self.traj_size = traj_size
        self.obs_dim = env.observation_space.shape[0]
        self.act_dim = env.action_space.shape[0]
        self.memory = Memory(
            obs=torch.zeros((traj_size, self.obs_dim), dtype=torch.float32),
            act=torch.zeros((traj_size, self.act_dim), dtype=torch.float32),
            logp=torch.zeros(traj_size, dtype=torch.float32),
            val=torch.zeros(traj_size, dtype=torch.float32),
            reward=torch.zeros(traj_size, dtype=torch.float32),
            done=torch.zeros(traj_size, dtype=torch.bool),
            next_val=torch.zeros(traj_size, dtype=torch.float32),
            adv=torch.zeros(traj_size, dtype=torch.float32),
            ret=torch.zeros(traj_size, dtype=torch.float32)
        )
        self.total_rewards = []
        self.current_reward = 0.0

    def steps(self, policy_net, value_net):
        obs, _ = self.env.reset()
        for step in range(self.traj_size):
            obs_t = torch.tensor(obs, dtype=torch.float32, device=device)
            mean, std = policy_net(obs_t)
            dist = Normal(mean, std)
            act = dist.sample()
            logp = dist.log_prob(act).sum().item()
            val = value_net(obs_t).item()

            act_np = act.detach().cpu().numpy()
            next_obs, reward, terminated, truncated, _ = self.env.step(act_np)
            done = terminated or truncated

            self.memory.obs[step] = torch.tensor(obs, dtype=torch.float32)
            self.memory.act[step] = torch.tensor(act_np, dtype=torch.float32)
            self.memory.logp[step] = logp
            self.memory.val[step] = val
            self.memory.reward[step] = reward
            self.memory.done[step] = done

            self.current_reward += reward
            if done:
                self.total_rewards.append(self.current_reward)
                self.current_reward = 0.0
                obs, _ = self.env.reset()
            else:
                obs = next_obs

        last_obs_t = torch.tensor(obs, dtype=torch.float32, device=device)
        self.memory.next_val[-1] = value_net(last_obs_t).item()
        self.generalized_advantage_estimation()

    def generalized_advantage_estimation(self):
        gae = 0.0
        for step in reversed(range(self.traj_size)):
            delta = (
                self.memory.reward[step]
                + GAMMA * self.memory.next_val[step] * (1 - self.memory.done[step].item())
                - self.memory.val[step]
            )
            gae = delta + GAMMA * LAMBDA * (1 - self.memory.done[step].item()) * gae
            self.memory.adv[step] = gae
            ret = gae + self.memory.val[step]
            self.memory.ret[step] = ret

def main():
    env = gym.make(ENV_NAME)
    env = Env(env, TRAJECTORY_SIZE)

    policy_net = A2C_policy(env.obs_dim, env.act_dim).to(device)
    value_net = A2C_value(env.obs_dim).to(device)

    policy_opt = optim.Adam(policy_net.parameters(), lr=POLICY_LR)
    value_opt = optim.Adam(value_net.parameters(), lr=VALUE_LR)

    writer = SummaryWriter()
    best_mean_reward = -float("inf")
    start_iter = 0

    if os.path.exists(CHECKPOINT_PATH):
        checkpoint = torch.load(CHECKPOINT_PATH, map_location=device)
        policy_net.load_state_dict(checkpoint["policy_state_dict"])
        value_net.load_state_dict(checkpoint["value_state_dict"])
        policy_opt.load_state_dict(checkpoint["policy_opt_state_dict"])
        value_opt.load_state_dict(checkpoint["value_opt_state_dict"])
        best_mean_reward = checkpoint["best_mean_reward"]
        start_iter = checkpoint["iter"] + 1

    for iteration in range(start_iter, MAX_ITER):
        env.steps(policy_net, value_net)

        obs = env.memory.obs.to(device)
        act = env.memory.act.to(device)
        old_logp = env.memory.logp.to(device)
        adv = env.memory.adv.to(device)
        ret = env.memory.ret.to(device)

        adv = (adv - adv.mean()) / (adv.std() + 1e-8)

        dataset_size = TRAJECTORY_SIZE
        indices = torch.randperm(dataset_size)

        policy_loss_acc = 0.0
        value_loss_acc = 0.0

        for epoch in range(PPO_EPOCHS):
            for start in range(0, dataset_size, BATCH_SIZE):
                end = start + BATCH_SIZE
                batch_idx = indices[start:end]

                batch_obs = obs[batch_idx]
                batch_act = act[batch_idx]
                batch_old_logp = old_logp[batch_idx]
                batch_adv = adv[batch_idx]
                batch_ret = ret[batch_idx]

                mean, std = policy_net(batch_obs)
                dist = Normal(mean, std)
                new_logp = dist.log_prob(batch_act).sum(-1)

                ratio = torch.exp(new_logp - batch_old_logp)
                surr1 = ratio * batch_adv
                surr2 = torch.clamp(ratio, 1 - CLIP_EPS, 1 + CLIP_EPS) * batch_adv
                policy_loss = -torch.min(surr1, surr2).mean()

                value_opt.zero_grad()
                value_pred = value_net(batch_obs).squeeze()
                value_loss = F.mse_loss(value_pred, batch_ret)

                policy_opt.zero_grad()
                policy_loss.backward(retain_graph=True)
                policy_opt.step()

                value_opt.zero_grad()
                value_loss.backward()
                value_opt.step()

                policy_loss_acc += policy_loss.item()
                value_loss_acc += value_loss.item()

        writer.add_scalar("policy_loss", policy_loss_acc / (PPO_EPOCHS * (dataset_size // BATCH_SIZE)), iteration)
        writer.add_scalar("value_loss", value_loss_acc / (PPO_EPOCHS * (dataset_size // BATCH_SIZE)), iteration)

        if len(env.total_rewards) > 0:
            last_100_avg = np.mean(env.total_rewards[-100:])
            writer.add_scalar("episode_reward", env.total_rewards[-1], iteration)
            writer.add_scalar("last_100_reward_avg", last_100_avg, iteration)
        else:
            last_100_avg = 0.0

        if iteration % N_ITER_TEST == 0:
            test_rewards = []
            for _ in range(TEST_EPISODES):
                obs, _ = env.env.reset()
                done = False
                episode_reward = 0.0
                while not done:
                    obs_t = torch.tensor(obs, dtype=torch.float32, device=device)
                    with torch.no_grad():
                        mean, std = policy_net(obs_t)
                        act = mean.numpy()
                    obs, reward, terminated, truncated, _ = env.env.step(act)
                    episode_reward += reward
                    done = terminated or truncated
                test_rewards.append(episode_reward)
            avg_test_reward = np.mean(test_rewards)
            writer.add_scalar("test_reward", avg_test_reward, iteration)
            if avg_test_reward > best_mean_reward:
                best_mean_reward = avg_test_reward
                torch.save({
                    "policy_state_dict": policy_net.state_dict(),
                    "value_state_dict": value_net.state_dict(),
                    "policy_opt_state_dict": policy_opt.state_dict(),
                    "value_opt_state_dict": value_opt.state_dict(),
                    "best_mean_reward": best_mean_reward,
                    "iter": iteration
                }, CHECKPOINT_PATH)

    writer.close()
    env.env.close()

if __name__ == "__main__":
    main()
