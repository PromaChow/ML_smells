import os
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import mean_absolute_error

from src.BaggedTrees import BaggedTreeRegressor
from src.RandomForest import RandomForestTreeRegressor
from src.GradientBoostedTree import GradientBoostedTreeRegressor


def plot_model(model_class, X, y, param_grid, output_dir, model_name):
    n_estimators_list = param_grid["n_estimators"]
    max_depth_list = param_grid["max_depth"]
    n_rows = len(max_depth_list)
    n_cols = len(n_estimators_list)

    fig, axes = plt.subplots(n_rows, n_cols, figsize=(5 * n_cols, 4 * n_rows))
    if n_rows == 1 and n_cols == 1:
        axes = np.array([[axes]])
    elif n_rows == 1:
        axes = axes.reshape(1, -1)
    elif n_cols == 1:
        axes = axes.reshape(-1, 1)

    for i, max_depth in enumerate(max_depth_list):
        for j, n_estimators in enumerate(n_estimators_list):
            ax = axes[i, j]
            model = model_class(n_estimators=n_estimators, max_depth=max_depth)
            model.fit(X, y)
            y_pred = model.predict(X)
            mae = mean_absolute_error(y, y_pred)
            print(
                f"{model_name} - n_estimators={n_estimators}, max_depth={max_depth} MAE: {mae:.4f}"
            )
            ax.scatter(X, y, color="black", s=20, label="True")
            ax.scatter(X, y_pred, color="red", s=20, label="Pred")
            ax.set_title(
                f"n_estimators={n_estimators}, max_depth={max_depth}\nMAE={mae:.4f}"
            )
            ax.set_xlabel("x")
            ax.set_ylabel("y")
            ax.legend()

    fig.suptitle(f"{model_name} Predictions", fontsize=16)
    fig.tight_layout(rect=[0, 0.03, 1, 0.95])

    os.makedirs(output_dir, exist_ok=True)
    png_path = os.path.join(output_dir, f"{model_name}.png")
    pdf_path = os.path.join(output_dir, f"{model_name}.pdf")
    fig.savefig(png_path)
    fig.savefig(pdf_path)
    plt.close(fig)


def main():
    x = np.linspace(0, 10, 100)
    y = (x - 1) * (x - 4) * (x - 8) * (x - 8)
    X = x.reshape(-1, 1)

    bagged_params = {"n_estimators": [1, 25, 50], "max_depth": [2, 4, 6]}
    random_forest_params = {"n_estimators": [1, 25, 50], "max_depth": [2, 4, 6]}
    gb_params = {"n_estimators": [1, 10, 20], "max_depth": [1, 2, 3]}

    plot_model(
        BaggedTreeRegressor,
        X,
        y,
        bagged_params,
        "output/bagged_trees",
        "BaggedTree",
    )
    plot_model(
        RandomForestTreeRegressor,
        X,
        y,
        random_forest_params,
        "output/random_forest",
        "RandomForest",
    )
    plot_model(
        GradientBoostedTreeRegressor,
        X,
        y,
        gb_params,
        "output/gradient_boosted_trees",
        "GradientBoostedTree",
    )


if __name__ == "__main__":
    main()
