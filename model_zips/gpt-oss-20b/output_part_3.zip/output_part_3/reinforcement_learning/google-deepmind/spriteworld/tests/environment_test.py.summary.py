import unittest
import numpy as np
from spriteworld.environments import Environment
from spriteworld.tasks import NoReward, FindGoalPosition
from spriteworld.action_spaces import SelectMove
from spriteworld.renderers import SpriteFactors
from spriteworld import Sprite, Position, Color


class EnvironmentEpisodeLengthTest(unittest.TestCase):
    def setUp(self):
        sprite = Sprite(position=Position(2, 2), color=Color(255))
        self.env = Environment(
            task=NoReward(),
            action_space=SelectMove(),
            sprites=[sprite],
            max_episode_length=7,
        )
        self.dummy_action = np.array([0.5, 0.5, 0.5, 0.5])

    def test_max_episode_length(self):
        # First step should be first()
        timestep = self.env.reset()
        self.assertTrue(timestep.first())

        # Take 7 steps and ensure terminal after 7th
        for i in range(7):
            timestep = self.env.step(self.dummy_action)
        self.assertTrue(timestep.last())

        # Step again to trigger reset to first()
        timestep = self.env.step(self.dummy_action)
        self.assertTrue(timestep.first())


class EnvironmentTaskTerminationTest(unittest.TestCase):
    def setUp(self):
        goal = Position(0.5, 0.5)
        sprite = Sprite(position=Position(0.25, 0.25), color=Color(255))
        self.env = Environment(
            task=FindGoalPosition(target=goal),
            action_space=SelectMove(),
            sprites=[sprite],
            max_episode_length=20,
        )
        self.noop_action = np.array([0.25, 0.25, 0.5, 0.5])
        self.success_action = np.array([0.25, 0.25, 0.75, 0.75])

    def test_task_termination(self):
        timestep = self.env.reset()
        self.assertTrue(timestep.first())

        # Non-terminal action
        timestep = self.env.step(self.noop_action)
        self.assertFalse(timestep.last())

        # Terminal action
        timestep = self.env.step(self.success_action)
        self.assertTrue(timestep.last())

        # After termination, next step should reset to first()
        timestep = self.env.step(self.noop_action)
        self.assertTrue(timestep.first())


class EnvironmentRendererTest(unittest.TestCase):
    def setUp(self):
        sprite = Sprite(position=Position(1, 1), color=Color(255))
        self.env = Environment(
            task=NoReward(),
            action_space=SelectMove(),
            sprites=[sprite],
            renderers={"obs": SpriteFactors()},
            max_episode_length=5,
        )
        self.action = np.array([0.5, 0.5, 0.5, 0.5])

    def test_renderer_pipeline(self):
        timestep = self.env.reset()
        self.assertTrue(timestep.first())
        obs = timestep.observation
        self.assertIn("obs", obs)
        self.assertIsNotNone(obs["obs"])

        # Perform a few steps and render
        for _ in range(3):
            timestep = self.env.step(self.action)
            obs = timestep.observation
            self.assertIn("obs", obs)
            self.assertIsNotNone(obs["obs"])
            # Render the observation
            rendered = self.env.render("obs", observation=obs["obs"])
            self.assertIsNotNone(rendered)
            self.assertIsInstance(rendered, np.ndarray)


if __name__ == "__main__":
    unittest.main()
