import math
from typing import Any, Callable, Dict, Iterable, List, Tuple, Optional


class Node:
    def __init__(
        self,
        parent: Optional["Node"],
        prior: float,
        state: Any,
    ):
        self.parent: Optional["Node"] = parent
        self.prior: float = prior
        self.state: Any = state
        self.children: Dict[Any, "Node"] = {}
        self._n_visits: int = 0
        self._Q: float = 0.0
        self._u: float = 0.0

    def is_leaf(self) -> bool:
        return len(self.children) == 0

    def expand(self, policy_fn: Callable[[Any], Iterable[Tuple[Any, float]]]) -> None:
        action_probs = policy_fn(self.state)
        for action, prob in action_probs:
            if action not in self.children:
                child_state = self._apply_action(self.state, action)
                self.children[action] = Node(self, prob, child_state)

    def _apply_action(self, state: Any, action: Any) -> Any:
        return state.apply(action)

    def select(self, c_puct: float) -> Tuple[Any, "Node"]:
        best_action = None
        best_value = -float("inf")
        for action, child in self.children.items():
            child._u = (
                c_puct
                * child.prior
                * math.sqrt(self._n_visits)
                / (1 + child._n_visits)
            )
            val = child._Q + child._u
            if val > best_value:
                best_value = val
                best_action = action
        return best_action, self.children[best_action]


class MCTS:
    def __init__(
        self,
        initial_state: Any,
        policy_fn: Callable[[Any], Iterable[Tuple[Any, float]]],
        value_fn: Callable[[Any], float],
        rollout_policy_fn: Callable[[Any], float],
        *,
        c_puct: float = 1.0,
        lmbda: float = 0.5,
        n_playout: int = 800,
        L: int = 5,
    ):
        self.c_puct = c_puct
        self.lmbda = lmbda
        self.n_playout = n_playout
        self.L = L
        self.policy_fn = policy_fn
        self.value_fn = value_fn
        self.rollout_policy_fn = rollout_policy_fn
        self.root = Node(None, 1.0, initial_state)

    def run(self, state: Any) -> Any:
        self.root = Node(None, 1.0, state)
        for _ in range(self.n_playout):
            self._playout(self.root, 0)
        return self.get_best_action()

    def _playout(self, node: Node, depth: int) -> None:
        if depth >= self.L or node.is_leaf():
            value = self._evaluate_leaf(node.state, depth)
            self._update_recursive(node, value)
            return
        if node.is_leaf():
            node.expand(self.policy_fn)
        _, child = node.select(self.c_puct)
        self._playout(child, depth + 1)

    def _evaluate_leaf(self, state: Any, depth: int) -> float:
        value_estimate = self.value_fn(state)
        rollout_estimate = self.rollout_policy_fn(state)
        return (1 - self.lmbda) * value_estimate + self.lmbda * rollout_estimate

    def _update_recursive(self, node: Node, value: float) -> None:
        node._n_visits += 1
        node._Q = ((node._Q * (node._n_visits - 1)) + value) / node._n_visits
        if node.parent:
            self._update_recursive(node.parent, value)

    def get_best_action(self) -> Any:
        best_action = None
        best_visits = -1
        for action, child in self.root.children.items():
            if child._n_visits > best_visits:
                best_visits = child._n_visits
                best_action = action
        return best_action

    def step(self, action: Any) -> None:
        if action in self.root.children:
            self.root = self.root.children[action]
            self.root.parent = None
        else:
            self.root = Node(None, 1.0, self.root.state.apply(action))
            self.root.expand(self.policy_fn)  # optional initial expansion
        self.root._n_visits = 0
        self.root._Q = 0.0
        self.root._u = 0.0
        self.root.children = {}
        self.root.expand(self.policy_fn)
