import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.nn.init as init


def conv3x3(i_c, o_c, stride=1):
    return nn.Conv2d(i_c, o_c, kernel_size=3, stride=stride, padding=1, bias=False)


class BatchNorm2d(nn.BatchNorm2d):
    def __init__(self, channels, momentum=1e-3, eps=1e-3):
        super().__init__(channels, momentum=momentum, eps=eps)
        self.update_batch_stats = True

    def forward(self, input):
        if self.update_batch_stats:
            return super().forward(input)
        else:
            return F.batch_norm(
                input,
                None,
                None,
                self.weight,
                self.bias,
                training=self.training,
                momentum=0,
                eps=self.eps,
            )


def relu():
    return nn.LeakyReLU(0.1)


class ResidualBlock(nn.Module):
    def __init__(self, input_channels, output_channels, stride=1, activate_before_residual=False):
        super().__init__()
        self.activate_before_residual = activate_before_residual
        self.stride = stride
        self.input_channels = input_channels
        self.output_channels = output_channels

        self.bn1 = BatchNorm2d(input_channels)
        self.relu1 = relu()
        self.conv1 = conv3x3(input_channels, output_channels, stride=stride)
        self.bn2 = BatchNorm2d(output_channels)
        self.relu2 = relu()
        self.conv2 = conv3x3(output_channels, output_channels)

        if stride != 1 or input_channels != output_channels:
            self.shortcut = nn.Conv2d(input_channels, output_channels, kernel_size=1, stride=stride, bias=False)
        else:
            self.shortcut = None

    def forward(self, x):
        identity = x
        if self.activate_before_residual:
            out = self.bn1(x)
            out = self.relu1(out)
            out = self.conv1(out)
            out = self.bn2(out)
            out = self.relu2(out)
            out = self.conv2(out)
            if self.shortcut is not None:
                identity = self.shortcut(x)
            out = out + identity
        else:
            if self.shortcut is not None:
                identity = self.shortcut(x)
            out = self.conv1(x)
            out = self.bn1(out)
            out = self.relu1(out)
            out = self.conv2(out)
            out = self.bn2(out)
            out = out + identity
            out = self.relu2(out)
        return out


class WideResNet(nn.Module):
    def __init__(self, width, num_classes, transform_fn=None):
        super().__init__()
        self.transform_fn = transform_fn

        self.init_conv = conv3x3(3, 16)

        filters = [16, 16 * width, 32 * width, 64 * width]

        self.unit1 = nn.Sequential(
            ResidualBlock(filters[0], filters[1], stride=1, activate_before_residual=True),
            ResidualBlock(filters[1], filters[1]),
            ResidualBlock(filters[1], filters[1]),
            ResidualBlock(filters[1], filters[1]),
        )

        self.unit2 = nn.Sequential(
            ResidualBlock(filters[1], filters[2], stride=2),
            ResidualBlock(filters[2], filters[2]),
            ResidualBlock(filters[2], filters[2]),
            ResidualBlock(filters[2], filters[2]),
        )

        self.unit3 = nn.Sequential(
            ResidualBlock(filters[2], filters[3], stride=2),
            ResidualBlock(filters[3], filters[3]),
            ResidualBlock(filters[3], filters[3]),
            ResidualBlock(filters[3], filters[3]),
        )

        self.unit4 = nn.Sequential(
            BatchNorm2d(filters[3]),
            relu(),
            nn.AdaptiveAvgPool2d(1),
        )

        self.linear = nn.Linear(filters[3], num_classes)

        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
                if m.bias is not None:
                    init.zeros_(m.bias)
            elif isinstance(m, BatchNorm2d):
                init.constant_(m.weight, 1)
                init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                init.xavier_normal_(m.weight)
                init.zeros_(m.bias)

    def update_batch_stats(self, flag):
        for m in self.modules():
            if isinstance(m, BatchNorm2d):
                m.update_batch_stats = flag

    def forward(self, x, return_feature=False):
        if self.transform_fn is not None and self.training:
            x = self.transform_fn(x)

        x = self.init_conv(x)
        x = self.unit1(x)
        x = self.unit2(x)
        x = self.unit3(x)
        x = self.unit4(x)

        features = torch.flatten(x, 1)
        logits = self.linear(features)

        if return_feature:
            return logits, features
        return logits
