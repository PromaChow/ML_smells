import random
from typing import Iterable, Tuple, List

import torch
import numpy as np
from torch.utils.data import Subset
from torchvision.datasets import MNIST as TorchvisionDataset
from torchvision import transforms


def create_semisupervised_setting(
    targets: Iterable[int],
    normal_class: int,
    outlier_classes: List[int],
    known_normal_ratio: float,
    known_outlier_ratio: float,
    pollution_ratio: float,
) -> Tuple[List[int], np.ndarray]:
    """
    Placeholder implementation that returns all indices with semi_targets set to 0.
    Replace with a proper semi-supervised split routine if needed.
    """
    indices = list(range(len(targets)))
    semi_targets = np.zeros(len(targets), dtype=int)
    return indices, semi_targets


class MyMNIST(TorchvisionDataset):
    """
    MNIST subclass that adds a `semi_targets` attribute and returns
    (image, target, semi_target, index) from __getitem__.
    """

    def __init__(
        self,
        root: str = "./data",
        train: bool = True,
        transform=None,
        target_transform=None,
        download: bool = False,
    ):
        super().__init__(
            root=root,
            train=train,
            transform=transform,
            target_transform=target_transform,
            download=download,
        )
        # Initialize semi_targets to zeros
        self.semi_targets = torch.zeros(len(self.targets), dtype=torch.long)

    def __getitem__(self, idx):
        image, target = super().__getitem__(idx)
        semi_target = self.semi_targets[idx]
        return image, target, semi_target, idx


class MNIST_Dataset:
    """
    Custom MNIST dataset for semi-supervised settings.
    """

    def __init__(
        self,
        normal_class: int = 0,
        known_outlier_class: int = 1,
        n_known_outlier_classes: int = 0,
        known_normal_ratio: float = 0.0,
        known_outlier_ratio: float = 0.0,
        pollution_ratio: float = 0.0,
        root: str = "./data",
        download: bool = True,
    ):
        self.normal_class = normal_class
        self.known_outlier_class = known_outlier_class
        self.n_known_outlier_classes = n_known_outlier_classes
        self.known_normal_ratio = known_normal_ratio
        self.known_outlier_ratio = known_outlier_ratio
        self.pollution_ratio = pollution_ratio
        self.root = root
        self.download = download

        # Define outlier classes: all digits except normal_class
        self.outlier_classes = [c for c in range(10) if c != self.normal_class]

        # Sample known outlier classes if requested
        if self.n_known_outlier_classes > 0:
            self.known_outlier_classes = random.sample(
                self.outlier_classes, self.n_known_outlier_classes
            )
        else:
            self.known_outlier_classes = []

        # Image transform: scale to [0, 1]
        self.transform = transforms.ToTensor()

        # Target transform: map to 0 (normal) or 1 (outlier)
        def target_transform(label):
            return 0 if label == self.normal_class else 1

        self.target_transform = target_transform

        # Load training set
        train_set = MyMNIST(
            root=self.root,
            train=True,
            transform=self.transform,
            target_transform=self.target_transform,
            download=self.download,
        )

        # Create semi-supervised setting
        idx, semi_targets = create_semisupervised_setting(
            targets=train_set.targets.numpy(),
            normal_class=self.normal_class,
            outlier_classes=self.outlier_classes,
            known_normal_ratio=self.known_normal_ratio,
            known_outlier_ratio=self.known_outlier_ratio,
            pollution_ratio=self.pollution_ratio,
        )

        # Assign semi_targets to the selected indices
        train_set.semi_targets[idx] = torch.from_numpy(semi_targets)

        # Subset the training set
        self.train_set = Subset(train_set, idx)

        # Load test set
        self.test_set = MyMNIST(
            root=self.root,
            train=False,
            transform=self.transform,
            target_transform=self.target_transform,
            download=self.download,
        )

    def get_train_set(self):
        return self.train_set

    def get_test_set(self):
        return self.test_set
```