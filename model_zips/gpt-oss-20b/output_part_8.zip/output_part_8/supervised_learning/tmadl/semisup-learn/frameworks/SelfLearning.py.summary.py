import numpy as np
from sklearn.metrics import accuracy_score
from sklearn.linear_model import LogisticRegression
from sklearn.base import clone


class SelfLearningModel:
    def __init__(self, base_model, max_iter=10, prob_threshold=0.9):
        """
        Parameters
        ----------
        base_model : estimator
            The base supervised learning model.
        max_iter : int
            Maximum number of self-training iterations.
        prob_threshold : float
            Confidence threshold for selecting pseudo-labeled instances.
        """
        self.base_model = clone(base_model)
        self.max_iter = max_iter
        self.prob_threshold = prob_threshold
        self.platt_lr = None  # Logistic regression for Platt scaling

    def _get_proba(self, X, fit_platt=False):
        """
        Return class probabilities for X. Apply Platt scaling if necessary.
        """
        if hasattr(self.base_model, "predict_proba"):
            return self.base_model.predict_proba(X)

        # Platt scaling
        if fit_platt:
            decision_scores = self.base_model.decision_function(self._labeled_X)
            self.platt_lr = LogisticRegression(solver="lbfgs", max_iter=200)
            self.platt_lr.fit(decision_scores.reshape(-1, 1), self._labeled_y)

        if self.platt_lr is None:
            raise RuntimeError("Platt scaling was not fitted.")
        decision_scores = self.base_model.decision_function(X)
        return self.platt_lr.predict_proba(decision_scores.reshape(-1, 1))

    def fit(self, X, y):
        """
        Fit the self-training model.
        """
        X = np.asarray(X)
        y = np.asarray(y)

        # Separate labeled and unlabeled data
        labeled_mask = y != -1
        unlabeled_mask = y == -1

        self._labeled_X = X[labeled_mask]
        self._labeled_y = y[labeled_mask]
        self._unlabeled_X = X[unlabeled_mask]

        # Train on labeled data
        self.base_model.fit(self._labeled_X, self._labeled_y)

        # Initial pseudo-labels for unlabeled data
        unlabeled_prob = self._get_proba(self._unlabeled_X)
        unlabeled_pred = np.argmax(unlabeled_prob, axis=1)

        for iteration in range(self.max_iter):
            # Thresholding
            high_conf_mask = (
                (unlabeled_prob[:, 0] >= self.prob_threshold)
                | (unlabeled_prob[:, 1] >= self.prob_threshold)
            )

            # Combine labeled and selected unlabeled instances
            if np.any(high_conf_mask):
                X_combined = np.vstack(
                    [self._labeled_X, self._unlabeled_X[high_conf_mask]]
                )
                y_combined = np.concatenate(
                    [self._labeled_y, unlabeled_pred[high_conf_mask]]
                )
                # Retrain
                self.base_model.fit(X_combined, y_combined)

                # Re-evaluate pseudo-labels
                prev_unlabeled_pred = unlabeled_pred.copy()
                unlabeled_prob = self._get_proba(self._unlabeled_X)
                unlabeled_pred = np.argmax(unlabeled_prob, axis=1)

                # Convergence check
                if np.array_equal(unlabeled_pred, prev_unlabeled_pred):
                    break
            else:
                # No high-confidence samples; stop training
                break

        return self

    def predict(self, X):
        """
        Predict class labels for X.
        """
        return self.base_model.predict(X)

    def score(self, X, y):
        """
        Compute accuracy on X and y.
        """
        y_pred = self.predict(X)
        return accuracy_score(y, y_pred)