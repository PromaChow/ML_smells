import numpy as np

class RunningMeanStd:
    def __init__(self, eps=1e-8):
        self.mean = np.array(0.0)
        self.var = np.array(0.0)
        self.count = 0
        self.eps = eps

    def update(self, x):
        batch_mean = np.mean(x, axis=0)
        batch_var = np.var(x, axis=0, ddof=0)
        batch_count = x.shape[0]

        if self.count == 0:
            self.mean = batch_mean
            self.var = batch_var
            self.count = batch_count
            return

        delta = batch_mean - self.mean
        total_count = self.count + batch_count
        new_mean = self.mean + delta * batch_count / total_count
        m2 = self.var * self.count + batch_var * batch_count + \
             delta ** 2 * self.count * batch_count / total_count
        new_var = m2 / total_count

        self.mean = new_mean
        self.var = new_var
        self.count = total_count

    @property
    def std(self):
        return np.sqrt(self.var + self.eps)


class VecNormalize:
    def __init__(self, venv, norm_obs=True, norm_reward=True, clip_reward=10.0):
        self.venv = venv
        self.norm_obs = norm_obs
        self.norm_reward = norm_reward
        self.clip_reward = clip_reward
        self.obs_rms = RunningMeanStd() if norm_obs else None
        self.reward_rms = RunningMeanStd() if norm_reward else None

    def __getattr__(self, name):
        return getattr(self.venv, name)

    def step(self, actions):
        states, rewards, dones, infos = self.venv.step(actions)

        if self.norm_obs:
            states = self._normalize(states, self.obs_rms)

        if self.norm_reward:
            rewards = self._normalize(rewards, self.reward_rms)
            rewards = np.clip(rewards, -self.clip_reward, self.clip_reward)

        return states, rewards, dones, infos

    def _normalize(self, batch, rms, clip=None):
        if rms is None:
            return batch

        rms.update(batch)
        norm = (batch - rms.mean) / rms.std
        if clip is not None:
            norm = np.clip(norm, -clip, clip)
        return norm

    def reset(self):
        states = self.venv.reset()
        if self.norm_obs:
            states = self._normalize(states, self.obs_rms)
        return states

    def close(self):
        self.venv.close()