import numpy as np

# Dimensions of position/velocity space
DIM_P = 2
# Random seed for reproducibility
np.random.seed(42)


class Agent:
    def __init__(self, name, collide=False, silent=False):
        self.name = name
        self.collide = collide
        self.silent = silent
        self.color = np.zeros(3)
        self.p_pos = np.zeros(DIM_P)
        self.p_vel = np.zeros(DIM_P)
        self.c = np.zeros(DIM_P)


class Landmark:
    def __init__(self, name, collide=False, movable=False):
        self.name = name
        self.collide = collide
        self.movable = movable
        self.color = np.zeros(3)
        self.p_pos = np.zeros(DIM_P)
        self.p_vel = np.zeros(DIM_P)


class World:
    def __init__(self):
        self.agents = []
        self.landmarks = []

    def add_agent(self, collide=False, silent=False):
        name = f"agent_{len(self.agents)}"
        agent = Agent(name, collide=collide, silent=silent)
        self.agents.append(agent)

    def add_landmark(self, collide=False, movable=False):
        name = f"landmark_{len(self.landmarks)}"
        landmark = Landmark(name, collide=collide, movable=movable)
        self.landmarks.append(landmark)

    def reset(self):
        # Assign colors
        for agent in self.agents:
            agent.color = np.array([0.25, 0.25, 0.25])

        for i, landmark in enumerate(self.landmarks):
            landmark.color = np.array([0.75, 0.75, 0.75])
            if i == 0:
                landmark.color = np.array([0.75, 0.25, 0.25])

        # Sample positions
        for agent in self.agents:
            agent.p_pos = np.random.uniform(-1, 1, DIM_P)
            agent.p_vel = np.zeros(DIM_P)
            agent.c = np.zeros(DIM_P)

        for landmark in self.landmarks:
            landmark.p_pos = np.random.uniform(-1, 1, DIM_P)
            landmark.p_vel = np.zeros(DIM_P)

    def reward(self, agent):
        if not self.landmarks:
            return 0.0
        first_landmark = self.landmarks[0]
        diff = agent.p_pos - first_landmark.p_pos
        return -np.sum(diff ** 2)

    def observation(self, agent):
        rel_positions = []
        for landmark in self.landmarks:
            rel_positions.append(landmark.p_pos - agent.p_pos)
        rel_vector = np.concatenate(rel_positions).ravel()
        return np.concatenate([agent.p_vel, rel_vector]).ravel()


# Example usage
if __name__ == "__main__":
    world = World()
    world.add_agent(collide=False, silent=False)
    world.add_landmark(collide=False, movable=False)
    world.reset()

    agent = world.agents[0]
    obs = world.observation(agent)
    rew = world.reward(agent)

    print(f"Agent {agent.name} observation: {obs}")
    print(f"Agent {agent.name} reward: {rew}")