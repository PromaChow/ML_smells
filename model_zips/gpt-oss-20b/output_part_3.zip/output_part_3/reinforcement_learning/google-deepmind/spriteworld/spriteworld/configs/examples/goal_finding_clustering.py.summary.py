import random
import math
from dataclasses import dataclass, field
from typing import List, Tuple, Iterator, Optional
import numpy as np
from PIL import Image, ImageDraw

# ------------------- Utility Functions ------------------- #
def sample_uniform(low: float, high: float) -> float:
    return random.uniform(low, high)

def sample_from_ranges(ranges: List[Tuple[float, float]]) -> float:
    low, high = random.choice(ranges)
    return random.uniform(low, high)

def random_color(range_tuple: Tuple[int, int]) -> int:
    return random.randint(*range_tuple)

# ------------------- Sprite Definition ------------------- #
@dataclass
class Sprite:
    shape: str
    position: Tuple[float, float]
    angle: float
    scale: float
    color: Tuple[int, int, int]
    goal_position: Optional[Tuple[float, float]] = None

# ------------------- Sprite Generators ------------------- #
class SpriteGenerator:
    def __init__(self, mode: str):
        self.mode = mode

    def generate_clustering_sprites(self) -> Iterator[Sprite]:
        shapes = ['triangle', 'square', 'pentagon']
        for shape in shapes:
            for _ in range(2):
                sprite = Sprite(
                    shape=shape,
                    position=(sample_uniform(0.1, 0.9), sample_uniform(0.1, 0.9)),
                    angle=sample_uniform(0, 360),
                    scale=sample_uniform(0.08, 0.12),
                    color=(
                        random_color((128, 256)),
                        random_color((64, 256)),
                        random_color((64, 256))
                    )
                )
                yield sprite

    def generate_goal_finding_sprites(self) -> Iterator[Sprite]:
        color_groups = {
            'reddish': (
                (192, 256),  # c0
                (0, 128),    # c1
                (64, 128)    # c2
            ),
            'greenish': (
                (0, 128),    # c0
                (192, 256),  # c1
                (64, 128)    # c2
            )
        }
        goal_positions = {
            'reddish': (0.0, 0.5),
            'greenish': (1.0, 0.5)
        }
        scale_ranges = {
            'train': [(0.05, 0.08), (0.12, 0.15)],
            'test': [(0.08, 0.12)]
        }
        for group, colors in color_groups.items():
            num_sprites = random.randint(1, 2)
            for _ in range(num_sprites):
                sprite = Sprite(
                    shape=random.choice(['spoke_4', 'star_4']),
                    position=(sample_uniform(0.1, 0.9), sample_uniform(0.1, 0.9)),
                    angle=sample_uniform(0, 360),
                    scale=sample_from_ranges(scale_ranges[self.mode]),
                    color=(
                        random_color(colors[0]),
                        random_color(colors[1]),
                        random_color(colors[2])
                    ),
                    goal_position=goal_positions[group]
                )
                yield sprite

    def generate_distractor_sprites(self) -> Iterator[Sprite]:
        num_sprites = random.randint(0, 2)
        for _ in range(num_sprites):
            sprite = Sprite(
                shape='circle',
                position=(sample_uniform(0.1, 0.9), sample_uniform(0.1, 0.9)),
                angle=sample_uniform(0, 360),
                scale=sample_uniform(0.08, 0.12),
                color=(
                    random_color((64, 256)),
                    random_color((64, 256)),
                    random_color((64, 256))
                )
            )
            yield sprite

    def all_sprites(self) -> List[Sprite]:
        sprites = list(self.generate_clustering_sprites())
        sprites.extend(self.generate_goal_finding_sprites())
        sprites.extend(self.generate_distractor_sprites())
        random.shuffle(sprites)
        return sprites

# ------------------- Tasks ------------------- #
class Task:
    def reset(self, sprites: List[Sprite]) -> None:
        pass

    def step(self, action) -> Tuple[float, bool]:
        return 0.0, False

class ClusteringTask(Task):
    def reset(self, sprites: List[Sprite]) -> None:
        self.target_shapes = {'triangle', 'square', 'pentagon'}

    def step(self, action) -> Tuple[float, bool]:
        # Simplified: always return 0 reward and not terminated
        return 0.0, False

class GoalFindingTask(Task):
    def __init__(self, color_group: str):
        self.color_group = color_group
        self.goal_positions = {
            'reddish': (0.0, 0.5),
            'greenish': (1.0, 0.5)
        }

    def reset(self, sprites: List[Sprite]) -> None:
        self.sprites = [s for s in sprites if s.goal_position == self.goal_positions[self.color_group]]
        self.terminated = False

    def step(self, action) -> Tuple[float, bool]:
        # Simplified placeholder logic
        self.terminated = True
        return 1.0, self.terminated

class MetaTask(Task):
    def __init__(self, tasks: List[Task]):
        self.tasks = tasks

    def reset(self, sprites: List[Sprite]) -> None:
        for t in self.tasks:
            t.reset(sprites)

    def step(self, action) -> Tuple[float, bool]:
        total_reward = 0.0
        all_done = True
        for t in self.tasks:
            reward, done = t.step(action)
            total_reward += reward
            if not done:
                all_done = False
        return total_reward, all_done

# ------------------- Renderer ------------------- #
class Renderer:
    def __init__(self, width: int = 64, height: int = 64, antialias: bool = True):
        self.width = width
        self.height = height
        self.antialias = antialias

    def render(self, sprites: List[Sprite]) -> Image:
        img = Image.new('RGB', (self.width, self.height), color=(255, 255, 255))
        draw = ImageDraw.Draw(img)
        for s in sprites:
            x = int(s.position[0] * self.width)
            y = int(s.position[1] * self.height)
            r = int(s.scale * min(self.width, self.height) / 2)
            bbox = [x - r, y - r, x + r, y + r]
            if s.shape == 'circle':
                draw.ellipse(bbox, fill=s.color, outline=None)
            else:
                # Placeholder for polygons
                draw.polygon(self._polygon_points(x, y, r, s.shape), fill=s.color, outline=None)
        return img

    def _polygon_points(self, cx, cy, r, shape):
        if shape == 'triangle':
            points = [
                (cx, cy - r),
                (cx - r * math.sin(math.radians(60)), cy + r * math.cos(math.radians(60))),
                (cx + r * math.sin(math.radians(60)), cy + r * math.cos(math.radians(60)))
            ]
        elif shape == 'square':
            points = [
                (cx - r, cy - r),
                (cx + r, cy - r),
                (cx + r, cy + r),
                (cx - r, cy + r)
            ]
        elif shape == 'pentagon':
            points = []
            for i in range(5):
                angle = math.radians(72 * i - 90)
                points.append((cx + r * math.cos(angle), cy + r * math.sin(angle)))
        else:
            points = []
        return points

# ------------------- Environment ------------------- #
@dataclass
class Environment:
    mode: str
    max_steps: int = 50
    step_count: int = 0
    sprites: List[Sprite] = field(default_factory=list)
    renderer: Renderer = field(default_factory=Renderer)
    action_scale: float = 0.5
    tasks: List[Task] = field(default_factory=list)
    meta_task: Optional[MetaTask] = None

    def __post_init__(self):
        gen = SpriteGenerator(self.mode)
        self.sprites = gen.all_sprites()
        self.tasks = [ClusteringTask(),
                      GoalFindingTask('reddish'),
                      GoalFindingTask('greenish')]
        self.meta_task = MetaTask(self.tasks)
        self.reset()

    def reset(self):
        self.step_count = 0
        for t in self.tasks:
            t.reset(self.sprites)
        self.meta_task.reset(self.sprites)

    def step(self, action) -> Tuple[float, bool]:
        self.step_count += 1
        reward, done = self.meta_task.step(action)
        if self.step_count >= self.max_steps:
            done = True
        return reward, done

    def render(self) -> Image:
        return self.renderer.render(self.sprites)

# ------------------- Example Usage ------------------- #
if __name__ == "__main__":
    env = Environment(mode='train')
    for _ in range(env.max_steps):
        action = None  # placeholder
        reward, done = env.step(action)
        if done:
            break
    img = env.render()
    img.show()
    print(f"Episode finished with reward: {reward}")