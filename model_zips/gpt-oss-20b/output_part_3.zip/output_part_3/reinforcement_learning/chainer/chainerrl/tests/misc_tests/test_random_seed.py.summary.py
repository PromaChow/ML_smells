import unittest
from nose.plugins.attrib import attr
import numpy as np
import chainer.cuda.cupy as cupy
from chainerrl.misc import set_random_seed

class TestSetRandomSeed(unittest.TestCase):
    def _test_xp_random(self, xp, gpu_ids):
        set_random_seed(0, gpu_ids)
        seed0_0 = xp.random.rand()
        set_random_seed(1, gpu_ids)
        seed1_0 = xp.random.rand()
        set_random_seed(0, gpu_ids)
        seed0_1 = xp.random.rand()
        set_random_seed(1, gpu_ids)
        seed1_1 = xp.random.rand()

        if xp is cupy:
            seed0_0 = float(seed0_0)
            seed1_0 = float(seed1_0)
            seed0_1 = float(seed0_1)
            seed1_1 = float(seed1_1)

        self.assertEqual(seed0_0, seed0_1)
        self.assertEqual(seed1_0, seed1_1)
        self.assertNotEqual(seed0_0, seed1_0)

    def test_random(self):
        import random
        random.seed(0)
        seed0_0 = random.random()
        random.seed(1)
        seed1_0 = random.random()
        random.seed(0)
        seed0_1 = random.random()
        random.seed(1)
        seed1_1 = random.random()

        self.assertEqual(seed0_0, seed0_1)
        self.assertEqual(seed1_0, seed1_1)
        self.assertNotEqual(seed0_0, seed1_0)

    def test_numpy_random(self):
        self._test_xp_random(np, ())
        self._test_xp_random(np, (-1,))

    @attr.gpu
    def test_cupy_random(self):
        self._test_xp_random(cupy, (0,))

if __name__ == "__main__":
    unittest.main()
