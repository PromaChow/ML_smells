import itertools
import unittest

import numpy as np
from chainerrl.explorers import AdditiveGaussian
from chainerrl.utils import condition


class TestAdditiveGaussian(unittest.TestCase):
    @condition.retry(3)
    def test_parameterized_behavior(self):
        action_sizes = [1, 3]
        scales = [0, 0.1]
        lows = [None, -0.4]
        highs = [None, 0.4]

        for action_size, scale, low, high in itertools.product(
            action_sizes, scales, lows, highs
        ):
            def greedy_action_func(_t):
                return np.full(action_size, 0.3)

            explorer = AdditiveGaussian(scale=scale, low=low, high=high)
            actions = []

            for t in range(100):
                a = explorer.select_action(t, greedy_action_func)

                if low is not None:
                    self.assertTrue(np.all(a >= low), f"Action below low: {a}")
                if high is not None:
                    self.assertTrue(np.all(a <= high), f"Action above high: {a}")

                if scale == 0:
                    self.assertTrue(
                        np.allclose(a, 0.3),
                        f"Expected no noise but got: {a}",
                    )
                else:
                    self.assertFalse(
                        np.allclose(a, 0.3),
                        f"Expected noise but action matches 0.3: {a}",
                    )

                actions.append(a)

            actions = np.array(actions)

            if low is None and high is None:
                mean_action = actions.mean()
                self.assertAlmostEqual(
                    mean_action,
                    0.3,
                    delta=0.1,
                    msg=f"Mean {mean_action} not close to 0.3 for action_size={action_size}, scale={scale}",
                )


if __name__ == "__main__":
    unittest.main()