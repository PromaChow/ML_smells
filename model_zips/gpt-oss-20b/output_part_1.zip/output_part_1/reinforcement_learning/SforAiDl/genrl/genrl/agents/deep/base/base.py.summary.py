import torch
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional, Sequence

from genrl.utils import set_seeds


class BaseAgent(ABC):
    """
    Abstract base class for reinforcement learning agents.
    """

    def __init__(
        self,
        env: Any,
        network_type: str = "mlp",
        batch_size: int = 32,
        gamma: float = 0.99,
        policy_layers: Sequence[int] = (64, 64),
        value_layers: Sequence[int] = (64, 64),
        lr_policy: float = 1e-3,
        lr_value: float = 1e-3,
        render_mode: Optional[str] = None,
        device_choice: str = "cpu",
        seed: Optional[int] = None,
        create_model: bool = True,
    ) -> None:
        # Attribute assignment
        self.env = env
        self.network_type = network_type
        self.batch_size = batch_size
        self.gamma = gamma
        self.policy_layers = policy_layers
        self.value_layers = value_layers
        self.lr_policy = lr_policy
        self.lr_value = lr_value
        self.render_mode = render_mode

        # Device configuration
        if device_choice.lower() == "cuda" and torch.cuda.is_available():
            self.device = torch.device("cuda")
        else:
            self.device = torch.device("cpu")

        # Seed initialization
        if seed is not None:
            set_seeds(seed, env)

        # Store seed for reproducibility
        self.seed = seed

        # Model creation check
        if create_model:
            self._create_model()

    @abstractmethod
    def _create_model(self) -> None:
        """
        Initialize the agent's neural network models.
        Must be implemented by subclasses.
        """
        raise NotImplementedError

    @abstractmethod
    def select_action(self, state: Any) -> Any:
        """
        Select an action based on the current state.
        Must be implemented by subclasses.
        """
        raise NotImplementedError

    @abstractmethod
    def get_hyperparams(self) -> Dict[str, Any]:
        """
        Return a dictionary of hyperparameters for saving.
        Must be implemented by subclasses.
        """
        raise NotImplementedError

    @abstractmethod
    def _load_weights(self, path: str) -> None:
        """
        Load pretrained model weights from the specified path.
        Must be implemented by subclasses.
        """
        raise NotImplementedError

    @abstractmethod
    def get_logging_params(self) -> Dict[str, Any]:
        """
        Provide parameters for training monitoring.
        Must be implemented by subclasses.
        """
        raise NotImplementedError

    @abstractmethod
    def empty_logs(self) -> None:
        """
        Reset logging data.
        Must be implemented by subclasses.
        """
        raise NotImplementedError
