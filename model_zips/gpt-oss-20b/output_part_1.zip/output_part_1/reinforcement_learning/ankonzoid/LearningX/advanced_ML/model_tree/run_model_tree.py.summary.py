import pandas as pd
import numpy as np
import pickle
import os
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.model_selection import KFold, cross_val_score
from sklearn.metrics import mean_squared_error, accuracy_score
from graphviz import Digraph

# =========================
# Settings Configuration
# =========================
settings = {
    "task": "clf",            # "clf" or "regr"
    "save_tree": True,
    "save_predictions": True,
    "cross_validate": True
}

# =========================
# Data Loading
# =========================
def load_data(task: str):
    file_name = f"data_{task}.csv"
    if not os.path.exists(file_name):
        raise FileNotFoundError(f"Data file '{file_name}' not found.")
    df = pd.read_csv(file_name)
    X = df.drop(columns=["target"]).values
    y = df["target"].values
    headers = df.columns.tolist()
    return X, y, headers

X, y, headers = load_data(settings["task"])

# =========================
# Model Selection
# =========================
class BaseModel:
    def fit(self, X, y):
        raise NotImplementedError
    def predict(self, X):
        raise NotImplementedError
    def loss(self, X, y, y_pred):
        raise NotImplementedError

class LinearRegr(BaseModel):
    def __init__(self):
        self.model = LinearRegression()
    def fit(self, X, y):
        self.model.fit(X, y)
    def predict(self, X):
        return self.model.predict(X)
    def loss(self, X, y, y_pred):
        return mean_squared_error(y, y_pred)

class LogisticClf(BaseModel):
    def __init__(self):
        self.model = LogisticRegression(max_iter=1000)
    def fit(self, X, y):
        self.model.fit(X, y)
    def predict(self, X):
        return self.model.predict(X)
    def loss(self, X, y, y_pred):
        return 1 - accuracy_score(y, y_pred)

model_choice = LinearRegr if settings["task"] == "regr" else LogisticClf
model = model_choice()

# =========================
# Model Tree Initialization
# =========================
class ModelTree:
    def __init__(self, model, max_depth=4, min_samples_leaf=10, search_type="greedy", n_search_grid=100):
        self.model = model
        self.max_depth = max_depth
        self.min_samples_leaf = min_samples_leaf
        self.search_type = search_type
        self.n_search_grid = n_search_grid
        self.trained = False
        self.explanations = []

    def fit(self, X, y):
        self.model.fit(X, y)
        self.trained = True

    def predict(self, X):
        if not self.trained:
            raise RuntimeError("ModelTree not trained yet.")
        return self.model.predict(X)

    def explanations_for(self, X):
        if not self.trained:
            raise RuntimeError("ModelTree not trained yet.")
        # Dummy explanations: one per sample
        return [f"Feature importance used for sample {i}" for i in range(X.shape[0])]

    def export_dot(self, file_path="model_tree.dot"):
        dot = Digraph(comment="Model Tree")
        dot.node("root", f"Root\nModel: {self.model.__class__.__name__}")
        dot.render(file_path, format='png', cleanup=True)
        dot.save(file_path)

# Instantiate
model_tree = ModelTree(
    model=model,
    max_depth=4,
    min_samples_leaf=10,
    search_type="greedy",
    n_search_grid=100
)

# =========================
# Model Tree Training
# =========================
model_tree.fit(X, y)
y_pred = model_tree.predict(X)
train_loss = model_tree.model.loss(X, y, y_pred)
print(f"Training loss: {train_loss}")

explanations = model_tree.explanations_for(X)
model_tree.export_dot("model_tree.dot")

# =========================
# Saving Results
# =========================
if settings["save_tree"]:
    with open("model_tree.p", "wb") as f:
        pickle.dump(model_tree, f)

if settings["save_predictions"]:
    pred_df = pd.DataFrame({
        "true": y,
        "predicted": y_pred,
        "explanation": explanations
    })
    pred_df.to_csv("model_tree_pred.csv", index=False)

# =========================
# Cross-Validation
# =========================
if settings["cross_validate"]:
    kf = KFold(n_splits=5, shuffle=True, random_state=1)
    scores = cross_val_score(model_tree.model, X, y,
                             cv=kf,
                             scoring='accuracy' if settings["task"] == "clf" else 'neg_mean_squared_error')
    print(f"Cross-validation scores: {scores}")
    print(f"Mean CV score: {np.mean(scores)}")
