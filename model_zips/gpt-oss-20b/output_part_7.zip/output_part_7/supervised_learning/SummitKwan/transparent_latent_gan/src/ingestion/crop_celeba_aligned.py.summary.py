import os
import random
import time
from pathlib import Path

import h5py
import numpy as np
import pandas as pd
from PIL import Image
import matplotlib.pyplot as plt


# Flags
yn_interactive_test = False
yn_time_img_loading = False
yn_use_h5 = False


def img_crop(img: np.ndarray, cx: int = 89, cy: int = 121, w: int = 128, h: int = 128) -> np.ndarray:
    """Crop image around center (cx, cy) with width w and height h."""
    y1 = cy - h // 2
    y2 = cy + h // 2
    x1 = cx - w // 2
    x2 = cx + w // 2
    return img[y1:y2, x1:x2]


def save_to_h5_img(h5_path: Path, dataset_name: str, img_array: np.ndarray, maxshape=None):
    """Save a single image array to an H5 dataset, extending if necessary."""
    with h5py.File(h5_path, 'a') as f:
        if dataset_name not in f:
            dset = f.create_dataset(
                dataset_name,
                data=img_array[None, ...],
                maxshape=maxshape,
                compression='gzip',
                compression_opts=4,
            )
        else:
            dset = f[dataset_name]
            old_shape = dset.shape[0]
            new_shape = old_shape + 1
            dset.resize((new_shape, *dset.shape[1:]))
            dset[new_shape - 1, ...] = img_array


def main():
    # Path setup
    path_celeba_img = Path("/path/to/celeba/img")  # replace with actual path
    path_celeba_att = Path("/path/to/celeba/attr")  # replace with actual path
    path_celeba_crop = Path("/path/to/celeba/crop")
    path_celeba_crop_h5 = Path("/path/to/celeba/crop/celebA_crop.h5")

    path_celeba_crop.mkdir(parents=True, exist_ok=True)

    # Load attributes
    attr_path = path_celeba_att / "list_attr_celeba.txt"
    df_attr = pd.read_csv(attr_path, delim_whitespace=True, header=0, index_col=0)

    # Get image filenames
    img_names = sorted([p.name for p in path_celeba_img.glob("*.jpg")])
    if len(img_names) != len(df_attr):
        raise ValueError("Number of images and attribute rows do not match.")

    # Optional timing test
    if yn_time_img_loading:
        total_time = 0.0
        for _ in range(1000):
            img_path = random.choice(list(path_celeba_img.glob("*.jpg")))
            start = time.perf_counter()
            Image.open(img_path).convert("RGB")
            total_time += time.perf_counter() - start
        print(f"Average image load time: {total_time / 1000:.6f} s")

    # Iterate and crop
    for idx, name in enumerate(img_names, 1):
        img_path = path_celeba_img / name
        with Image.open(img_path) as img:
            img_rgb = img.convert("RGB")
            img_arr = np.array(img_rgb)
            cropped_arr = img_crop(img_arr)
            cropped_img = Image.fromarray(cropped_arr)
            cropped_img.save(path_celeba_crop / name)

        if idx % 100 == 0:
            print(f"Processed {idx}/{len(img_names)} images.")

    print("All images processed and saved to:", path_celeba_crop)

    # Optional interactive test
    if yn_interactive_test:
        idx = random.randint(0, len(img_names) - 1)
        name = img_names[idx]
        attrs = df_attr.loc[name]
        print(f"Attributes for {name}:\n{attrs}")

        img_path = path_celeba_img / name
        with Image.open(img_path) as img:
            img_rgb = img.convert("RGB")
            img_arr = np.array(img_rgb)
            cropped_arr = img_crop(img_arr)

        fig, ax = plt.subplots(1, 2, figsize=(8, 4))
        ax[0].imshow(img_arr)
        ax[0].set_title("Original")
        ax[0].axis("off")
        ax[1].imshow(cropped_arr)
        ax[1].set_title("Cropped")
        ax[1].axis("off")
        plt.show()

    # Optional H5 saving
    if yn_use_h5:
        # Example: save first image
        first_name = img_names[0]
        img_path = path_celeba_img / first_name
        with Image.open(img_path) as img:
            img_rgb = img.convert("RGB")
            img_arr = np.array(img_rgb)
            cropped_arr = img_crop(img_arr)

        save_to_h5_img(
            path_celeba_crop_h5,
            "img",
            cropped_arr,
            maxshape=(None, 128, 128, 3),
        )
        print(f"Saved cropped image of {first_name} to H5.")

        # Test reading
        total_read_time = 0.0
        with h5py.File(path_celeba_crop_h5, "r") as f:
            dset = f["img"]
            for _ in range(1000):
                start = time.perf_counter()
                _ = dset[0]
                total_read_time += time.perf_counter() - start
        print(f"Average H5 read time: {total_read_time / 1000:.6f} s")


if __name__ == "__main__":
    main()
