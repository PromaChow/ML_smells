import os
import multiprocessing


class Prefetch_using_queue:
    def __init__(self, class_func, max_size=100, use_cores=None):
        if use_cores is None:
            use_cores = os.cpu_count()
        self.main_queue = multiprocessing.Queue(maxsize=max_size)
        self.instances = [class_func(self.main_queue) for _ in range(use_cores)]

    def start(self):
        for worker in self.instances:
            worker.start()

    def get_size(self):
        return self.main_queue.qsize()


class Prefetch_using_list:
    def __init__(self, class_func, use_cores=None):
        if use_cores is None:
            use_cores = os.cpu_count()
        manager = multiprocessing.Manager()
        self.main_list = manager.list()
        self.instances = [class_func(self.main_list) for _ in range(use_cores)]

    def start(self):
        for worker in self.instances:
            worker.start()

    def get_size(self):
        return len(self.main_list)