import os
import random
import torch
import torch.nn.functional as F
import torchaudio
from torch import Tensor
from torchaudio.transforms import Resample


class Reverberation:
    def __init__(self, ir_files_dir: str, max_reverb_len: int, ir_rate: int, p: float):
        self.ir_files_dir = ir_files_dir
        self.max_reverb_len = max_reverb_len
        self.ir_rate = ir_rate
        self.p = p
        self._ir_files = [os.path.join(ir_files_dir, f) for f in os.listdir(ir_files_dir)
                          if os.path.isfile(os.path.join(ir_files_dir, f))]
        if not self._ir_files:
            raise ValueError(f"No IR files found in directory: {ir_files_dir}")

    def _load_ir(self) -> tuple[Tensor, int]:
        ir_path = random.choice(self._ir_files)
        waveform, sr = torchaudio.load(ir_path)
        if waveform.shape[0] > 1:
            waveform = waveform.mean(dim=0)
        if sr != self.ir_rate:
            resampler = Resample(orig_freq=sr, new_freq=self.ir_rate)
            waveform = resampler(waveform)
        waveform = waveform[:self.max_reverb_len]
        max_val = torch.max(torch.abs(waveform))
        if max_val > 0:
            waveform = waveform / max_val
        p_max = torch.argmax(torch.abs(waveform)).item()
        return waveform, p_max

    @staticmethod
    def _shift(xs: Tensor, n: int) -> Tensor:
        L = xs.shape[0]
        if n == 0:
            return xs
        if n > 0:
            padded = torch.cat([torch.zeros(n, device=xs.device, dtype=xs.dtype), xs])
            return padded[:L]
        else:
            n = -n
            padded = torch.cat([xs, torch.zeros(n, device=xs.device, dtype=xs.dtype)])
            return padded[n:]

    def apply(self, wav: Tensor) -> Tensor:
        if random.random() >= self.p:
            return wav
        signal = wav.squeeze()
        ir, p_max = self._load_ir()
        Ex = torch.dot(signal, signal)
        conv = F.conv1d(signal.unsqueeze(0).unsqueeze(0), ir.unsqueeze(0).unsqueeze(0))
        reverberation = conv.squeeze(0).squeeze(0)
        reverberation = self._shift(reverberation, -p_max)
        Er = torch.dot(reverberation, reverberation)
        scale = torch.sqrt(Ex / Er) if Er > 0 else torch.tensor(1.0, device=signal.device, dtype=signal.dtype)
        reverberation = reverberation * scale
        reverberation = reverberation[:signal.shape[0]]
        return reverberation.unsqueeze(0) if wav.ndim > 1 else reverberation