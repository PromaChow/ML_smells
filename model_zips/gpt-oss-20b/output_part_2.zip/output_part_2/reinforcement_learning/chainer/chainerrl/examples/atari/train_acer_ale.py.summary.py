import argparse
import os
import sys
import numpy as np
import gym
import chainer
import chainer.links as L
import chainer.functions as F
from chainer import Variable
from chainerrl import atari_wrappers, experiments, misc, hooks
from chainerrl.links import SoftmaxDistribution, DiscreteActionValue, NIPSDQNHead
from chainerrl.replay_buffers import EpisodicReplayBuffer
from chainerrl.agents import ACER
from chainerrl.wrappers import Monitor, Render
from chainerrl.optimizers import RMSpropAsync

def make_env(seed, monitor=False, render=False):
    env = gym.make(args.env)
    env = atari_wrappers.wrap_deepmind(env)
    if monitor:
        env = Monitor(env, f'{args.outdir}/monitor_{seed}', allow_early_resets=True)
    if render:
        env = Render(env)
    env.seed(seed)
    return env

def phi(obs):
    return obs.astype(np.float32) / 255.0

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--env', default='BreakoutNoFrameskip-v4')
    parser.add_argument('--processes', type=int, default=4)
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--outdir', default='results')
    parser.add_argument('--lr', type=float, default=7e-4)
    parser.add_argument('--t-max', type=int, default=5)
    parser.add_argument('--replay-start-size', type=int, default=10000)
    parser.add_argument('--n-times-replay', type=int, default=4)
    parser.add_argument('--beta', type=float, default=1e-2)
    parser.add_argument('--steps', type=int, default=int(1e7))
    parser.add_argument('--eval-interval', type=int, default=10000)
    parser.add_argument('--eval-n-runs', type=int, default=10)
    parser.add_argument('--use-lstm', action='store_true')
    parser.add_argument('--demo', action='store_true')
    parser.add_argument('--weight-decay', type=float, default=None)
    parser.add_argument('--load', default=None)
    args = parser.parse_args()

    misc.set_random_seed(args.seed)
    process_seeds = np.arange(args.processes) + args.seed * args.processes

    experiments.prepare_output_dir(args.outdir, exp_name='acer')

    dummy_env = gym.make(args.env)
    dummy_env = atari_wrappers.wrap_deepmind(dummy_env)
    n_actions = dummy_env.action_space.n
    dummy_env.close()

    if args.use_lstm:
        model = chainer.Chain(
            feature_extractor=NIPSDQNHead(),
            lstm=L.LSTM(256, 256),
            pi=L.Linear(256, n_actions),
            q=L.Linear(256, n_actions),
        )
        def forward(obs, hidden_state):
            h = model.feature_extractor(obs)
            h, hs = model.lstm(h, hidden_state)
            return h, hs
        model.forward = forward
    else:
        model = chainer.Chain(
            feature_extractor=NIPSDQNHead(),
            pi=L.Linear(256, n_actions),
            q=L.Linear(256, n_actions),
        )

    model.pi = SoftmaxDistribution(model.pi)
    model.q = DiscreteActionValue(model.q)

    optimizer = RMSpropAsync(
        model, lr=args.lr, eps=4e-3, alpha=0.99, clip_norm=40.0)
    if args.weight_decay is not None:
        optimizer.add_hook(hooks.WeightDecayHook(args.weight_decay))

    replay_buffer = EpisodicReplayBuffer(
        capacity=10**6 // args.processes, num_buffers=args.processes)

    agent = ACER(
        model, optimizer,
        t_max=args.t_max,
        gamma=0.99,
        replay_start_size=args.replay_start_size,
        n_times_replay=args.n_times_replay,
        beta=args.beta,
        phi=phi,
        replay_buffer=replay_buffer,
    )

    if args.load is not None:
        agent.load(args.load)

    train_envs = [make_env(seed) for seed in process_seeds]
    eval_envs = [make_env(seed, monitor=True) for seed in process_seeds]

    if args.demo:
        results = experiments.eval_performance(agent, eval_envs, args.eval_n_runs)
        rewards = [r[0] for r in results]
        print('Demo results:')
        print('Mean:', np.mean(rewards))
        print('Median:', np.median(rewards))
        print('Std:', np.std(rewards))
        sys.exit(0)

    lr_decay = hooks.LinearInterpolationHook(
        initial_value=args.lr, final_value=0.0, steps=args.steps)
    optimizer.add_hook(lr_decay)

    experiments.train_agent_async(
        agent,
        train_envs,
        eval_envs,
        steps=args.steps,
        eval_interval=args.eval_interval,
        output_dir=args.outdir,
        monitor_interval=args.eval_interval,
    )