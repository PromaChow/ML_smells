import numpy as np
from scipy.signal import convolve2d

def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))

class RBM:
    def __init__(self, n_visible, n_hidden, visible_type='binary', seed=None):
        rng = np.random.default_rng(seed)
        self.n_visible = n_visible
        self.n_hidden = n_hidden
        self.visible_type = visible_type
        self.W = rng.normal(0, 0.01, size=(n_visible, n_hidden))
        self.bv = np.zeros(n_visible)
        self.bh = np.zeros(n_hidden)

    def visible_activation(self, v):
        if self.visible_type == 'binary':
            return sigmoid(v)
        else:
            return v

    def hidden_prob(self, v):
        h_input = v @ self.W + self.bh
        return sigmoid(h_input)

    def hidden_sample(self, v):
        prob = self.hidden_prob(v)
        return rng.binomial(1, prob)

    def visible_prob(self, h):
        v_input = h @ self.W.T + self.bv
        return self.visible_activation(v_input)

    def visible_sample(self, h):
        prob = self.visible_prob(h)
        if self.visible_type == 'binary':
            return rng.binomial(1, prob)
        else:
            return prob

    def iter_passes(self, v0, k=1):
        seq = [(v0, self.hidden_sample(v0))]
        v = v0.copy()
        for _ in range(k):
            h = self.hidden_sample(v)
            v = self.visible_sample(h)
            seq.append((v, h))
        return seq

    def reconstruct(self, v, k=1):
        seq = self.iter_passes(v, k)
        return seq[-1][0]

class Trainer:
    def __init__(self, rbm, lr=0.01, momentum=0.5, l2=0.0002, sparsity=0.05, sparsity_lr=0.0001):
        self.rbm = rbm
        self.lr = lr
        self.momentum = momentum
        self.l2 = l2
        self.sparsity = sparsity
        self.sparsity_lr = sparsity_lr
        self.vel_W = np.zeros_like(rbm.W)
        self.vel_bv = np.zeros_like(rbm.bv)
        self.vel_bh = np.zeros_like(rbm.bh)

    def train(self, data, epochs=10, batch_size=10, cd_k=1):
        n_samples = data.shape[0]
        for epoch in range(epochs):
            perm = np.random.permutation(n_samples)
            data_shuffled = data[perm]
            for i in range(0, n_samples, batch_size):
                batch = data_shuffled[i:i+batch_size]
                pos_W, pos_bv, pos_bh = self.pos_phase(batch)
                neg_W, neg_bv, neg_bh = self.neg_phase(batch, cd_k)
                dW = (pos_W - neg_W) / batch.shape[0]
                dbv = (pos_bv - neg_bv) / batch.shape[0]
                dbh = (pos_bh - neg_bh) / batch.shape[0]
                dW -= self.l2 * self.rbm.W
                dbv -= self.l2 * self.rbm.bv
                dbh -= self.l2 * self.rbm.bh
                self.vel_W = self.momentum * self.vel_W + self.lr * dW
                self.vel_bv = self.momentum * self.vel_bv + self.lr * dbv
                self.vel_bh = self.momentum * self.vel_bh + self.lr * dbh
                self.rbm.W += self.vel_W
                self.rbm.bv += self.vel_bv
                self.rbm.bh += self.vel_bh
                if self.sparsity > 0:
                    rho_hat = np.mean(self.rbm.hidden_prob(batch), axis=0)
                    sparsity_grad = self.sparsity_lr * (rho_hat - self.sparsity)
                    self.rbm.bh -= self.lr * sparsity_grad

    def pos_phase(self, v):
        ph = self.rbm.hidden_prob(v)
        pos_W = v.T @ ph
        pos_bv = np.sum(v, axis=0)
        pos_bh = np.sum(ph, axis=0)
        return pos_W, pos_bv, pos_bh

    def neg_phase(self, v, k):
        seq = self.rbm.iter_passes(v, k)
        v_neg, h_neg = seq[-1]
        neg_W = v_neg.T @ h_neg
        neg_bv = np.sum(v_neg, axis=0)
        neg_bh = np.sum(h_neg, axis=0)
        return neg_W, neg_bv, neg_bh

class Temporal(RBM):
    def __init__(self, n_visible, n_hidden, order=1, visible_type='binary', seed=None):
        super().__init__(n_visible, n_hidden, visible_type, seed)
        self.order = order
        self.bv_dynamic = np.zeros((order, n_visible))
        self.bh_dynamic = np.zeros((order, n_hidden))

    def visible_activation(self, v, t):
        bias = self.bv + self.bv_dynamic[t % self.order]
        if self.visible_type == 'binary':
            return sigmoid(v + bias)
        else:
            return v + bias

    def hidden_prob(self, v, t):
        bias = self.bh + self.bh_dynamic[t % self.order]
        h_input = v @ self.W + bias
        return sigmoid(h_input)

    def iter_passes(self, v0, k=1):
        seq = []
        v = v0.copy()
        for t in range(k):
            h = self.hidden_sample(v)
            v = self.visible_sample(h)
            seq.append((v, h))
        return seq

class TemporalTrainer(Trainer):
    def __init__(self, rbm, lr=0.01, momentum=0.5, l2=0.0002):
        super().__init__(rbm, lr, momentum, l2)
        self.vel_bv_dyn = np.zeros_like(rbm.bv_dynamic)
        self.vel_bh_dyn = np.zeros_like(rbm.bh_dynamic)

    def neg_phase(self, v, k):
        seq = self.rbm.iter_passes(v, k)
        v_neg, h_neg = seq[-1]
        neg_W = v_neg.T @ h_neg
        neg_bv = np.sum(v_neg, axis=0)
        neg_bh = np.sum(h_neg, axis=0)
        # Dynamic biases gradients (placeholder)
        neg_bv_dyn = np.zeros_like(self.rbm.bv_dynamic)
        neg_bh_dyn = np.zeros_like(self.rbm.bh_dynamic)
        return neg_W, neg_bv, neg_bh, neg_bv_dyn, neg_bh_dyn

    def train(self, data, epochs=10, batch_size=10, cd_k=1):
        n_samples = data.shape[0]
        for epoch in range(epochs):
            perm = np.random.permutation(n_samples)
            data_shuffled = data[perm]
            for i in range(0, n_samples, batch_size):
                batch = data_shuffled[i:i+batch_size]
                pos_W, pos_bv, pos_bh = self.pos_phase(batch)
                neg_W, neg_bv, neg_bh, neg_bv_dyn, neg_bh_dyn = self.neg_phase(batch, cd_k)
                dW = (pos_W - neg_W) / batch.shape[0]
                dbv = (pos_bv - neg_bv) / batch.shape[0]
                dbh = (pos_bh - neg_bh) / batch.shape[0]
                dbv_dyn = (neg_bv_dyn - 0) / batch.shape[0]
                dbh_dyn = (neg_bh_dyn - 0) / batch.shape[0]
                self.vel_W = self.momentum * self.vel_W + self.lr * dW
                self.vel_bv = self.momentum * self.vel_bv + self.lr * dbv
                self.vel_bh = self.momentum * self.vel_bh + self.lr * dbh
                self.vel_bv_dyn = self.momentum * self.vel_bv_dyn + self.lr * dbv_dyn
                self.vel_bh_dyn = self.momentum * self.vel_bh_dyn + self.lr * dbh_dyn
                self.rbm.W += self.vel_W
                self.rbm.bv += self.vel_bv
                self.rbm.bh += self.vel_bh
                self.rbm.bv_dynamic += self.vel_bv_dyn
                self.rbm.bh_dynamic += self.vel_bh_dyn

class Convolutional(RBM):
    def __init__(self, n_visible, n_hidden, filter_shape=(3,3), pool_size=(2,2), seed=None):
        super().__init__(n_visible, n_hidden, visible_type='binary', seed=seed)
        self.filter_shape = filter_shape
        self.pool_size = pool_size
        self.filter = np.random.randn(*filter_shape, n_hidden) * 0.01
        self.n_visible_dim = int(np.sqrt(n_visible))
        self.n_hidden_dim = int(np.sqrt(n_hidden))

    def hidden_prob(self, v):
        v_reshaped = v.reshape(-1, self.n_visible_dim, self.n_visible_dim)
        convs = np.zeros((v.shape[0], self.n_hidden_dim, self.n_visible_dim - self.filter_shape[0] + 1,
                          self.n_visible_dim - self.filter_shape[1] + 1))
        for i in range(self.n_hidden_dim):
            for j in range(v.shape[0]):
                convs[j, i] = convolve2d(v_reshaped[j], self.filter[..., i], mode='valid')
        pooled = convs[:, :, ::self.pool_size[0], ::self.pool_size[1]].sum(axis=(2,3))
        return sigmoid(pooled)

    def visible_prob(self, h):
        h_reshaped = h.reshape(-1, self.n_hidden_dim, h.shape[1] // self.n_hidden_dim)
        recon = np.zeros((h.shape[0], self.n_visible_dim, self.n_visible_dim))
        for i in range(self.n_hidden_dim):
            upsample = np.repeat(np.repeat(h_reshaped[:, i], self.pool_size[0], axis=1),
                                 self.pool_size[1], axis=2)
            conv_full = convolve2d(upsample[0], self.filter[..., i][::-1, ::-1], mode='full')
            recon[0] += conv_full
        return recon.reshape(h.shape[0], -1)

class ConvolutionalTrainer(Trainer):
    def __init__(self, rbm, lr=0.01, momentum=0.5, l2=0.0002):
        super().__init__(rbm, lr, momentum, l2)

    def neg_phase(self, v, k):
        seq = self.rbm.iter_passes(v, k)
        v_neg, h_neg = seq[-1]
        neg_W = v_neg.T @ h_neg
        neg_bv = np.sum(v_neg, axis=0)
        neg_bh = np.sum(h_neg, axis=0)
        return neg_W, neg_bv, neg_bh

class MeanCovariance(RBM):
    def __init__(self, n_visible, n_hidden, seed=None):
        super().__init__(n_visible, n_hidden, visible_type='gaussian', seed=seed)
        self.precision = np.eye(n_visible)

    def hidden_prob(self, v):
        # Placeholder quadratic transformation
        return sigmoid(v @ self.W + self.bh)

    def visible_prob(self, h):
        # Placeholder inversion using precision matrix
        mu = self.bv + self.W @ h
        return mu @ self.precision

class MeanCovarianceTrainer(Trainer):
    def __init__(self, rbm, lr=0.01, momentum=0.5, l2=0.0002):
        super().__init__(rbm, lr, momentum, l2)

    def neg_phase(self, v, k):
        seq = self.rbm.iter_passes(v, k)
        v_neg, h_neg = seq[-1]
        # Placeholder gradients for precision
        neg_W = v_neg.T @ h_neg
        neg_bv = np.sum(v_neg, axis=0)
        neg_bh = np.sum(h_neg, axis=0)
        return neg_W, neg_bv, neg_bh
