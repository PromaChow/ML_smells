import tensorflow as tf
from tensorflow.keras import layers, models, losses

# Weak augmentation: random flip and brightness adjustment
def weak_augment(images: tf.Tensor) -> tf.Tensor:
    images = tf.image.random_flip_left_right(images)
    images = tf.image.random_brightness(images, max_delta=0.1)
    return images

# Strong augmentation: random crop, contrast, color jitter, and grayscale
def strong_augment(images: tf.Tensor) -> tf.Tensor:
    # Random crop
    images = tf.image.resize_with_crop_or_pad(images, 28, 28)
    images = tf.image.random_crop(images, size=tf.shape(images))
    # Contrast
    images = tf.image.random_contrast(images, lower=0.7, upper=1.3)
    # Color jitter
    images = tf.image.random_brightness(images, max_delta=0.2)
    images = tf.image.random_hue(images, max_delta=0.1)
    images = tf.image.random_saturation(images, lower=0.8, upper=1.2)
    # Grayscale
    images = tf.image.random_grayscale(images, prob=0.2)
    return images

def guess_labels(x: tf.Tensor, model: tf.keras.Model, uratio: int) -> tf.Tensor:
    """
    x: Tensor of shape [uratio, batch, height, width, channels]
    Returns: Tensor of shape [batch * uratio, num_classes]
    """
    pseudo = []
    for k in range(uratio):
        logits = model(x[k], training=True)
        probs = tf.nn.softmax(logits, axis=-1)
        pseudo.append(probs)
    pseudo_concat = tf.concat(pseudo, axis=0)
    return tf.stop_gradient(pseudo_concat)

def fixmatch(
    x: tf.Tensor,
    y: tf.Tensor,
    u: tf.Tensor,
    height: int,
    width: int,
    uratio: int,
) -> tuple[tf.Tensor, tf.Tensor, tf.Tensor]:
    """
    x: labeled images, shape [batch, height, width, channels]
    y: labeled labels, shape [batch]
    u: unlabeled images, shape [uratio * batch, height, width, channels]
    Returns:
        x_aug: weakly augmented labeled images, shape [batch, height, width, channels]
        labels_strong: pseudo-labels for strongly augmented unlabeled data, shape [batch * uratio, num_classes]
        u_strong_aug: strongly augmented unlabeled images, shape [batch * uratio, height, width, channels]
    """
    batch = tf.shape(x)[0]
    # Weakly augment labeled data
    x_aug = weak_augment(x)

    # Split unlabeled data into uratio sub-batches
    u = tf.reshape(u, (uratio, batch, height, width, tf.shape(u)[-1]))

    # Weak and strong augmentations
    u_weak_list = []
    u_strong_list = []
    for k in range(uratio):
        u_weak = weak_augment(u[k])
        u_strong = strong_augment(u[k])
        u_weak_list.append(u_weak)
        u_strong_list.append(u_strong)

    u_weak_aug = tf.stack(u_weak_list, axis=0)   # [uratio, batch, H, W, C]
    u_strong_aug = tf.stack(u_strong_list, axis=0)  # [uratio, batch, H, W, C]

    # Flatten strong augmented data for loss computation
    u_strong_flat = tf.reshape(u_strong_aug, (uratio * batch, height, width, tf.shape(u)[-1]))

    return x_aug, u_weak_aug, u_strong_flat

def ssl_loss_fixmatch(
    labels_x: tf.Tensor,
    logits_x: tf.Tensor,
    labels_strong: tf.Tensor,
    logits_strong: tf.Tensor,
    confidence: float = 0.95,
) -> tuple[tf.Tensor, tf.Tensor]:
    """
    labels_x: true integer labels for labeled data, shape [batch]
    logits_x: model logits for labeled data, shape [batch, num_classes]
    labels_strong: pseudo-label probabilities for unlabeled data, shape [batch * uratio, num_classes]
    logits_strong: model logits for strongly augmented unlabeled data, shape [batch * uratio, num_classes]
    Returns:
        loss_x: cross-entropy loss for labeled data
        loss_xeu: cross-entropy loss for unlabeled data (masked by confidence)
    """
    # Labeled loss
    loss_x = tf.reduce_mean(
        losses.sparse_categorical_crossentropy(labels_x, logits_x, from_logits=True)
    )

    # Unlabeled loss
    max_conf = tf.reduce_max(labels_strong, axis=1)
    mask = tf.cast(max_conf > confidence, tf.float32)

    # Compute per-sample loss
    loss_per_sample = tf.keras.losses.categorical_crossentropy(
        labels_strong, logits_strong, from_logits=True
    )
    # Apply mask
    loss_xeu = tf.reduce_mean(loss_per_sample * mask)

    return loss_x, loss_xeu
