import os
import re
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import KFold
from sklearn.svm import SVR
from sklearn.utils import shuffle

import datasetUtils as dsu
import embeddings

# Parameters
EMBEDDING_FILE = "dataset.vec"
TWEET_THRESHOLD = 3
X_SCALE = (-0.5, 1.5)
Y_SCALE = (-0.5, 1.5)
PLOTS_DIR = os.path.join("Data", "PLOTS", "Twitter_models")
os.makedirs(PLOTS_DIR, exist_ok=True)

def savePlot(y_true, y_pred, title, filename):
    plt.figure(figsize=(6, 6))
    plt.scatter(y_true, y_pred, alpha=0.7)
    plt.plot([min(y_true), max(y_true)], [min(y_true), max(y_true)], 'r--')
    plt.xlabel("True")
    plt.ylabel("Predicted")
    plt.title(title)
    plt.xlim(X_SCALE)
    plt.ylim(Y_SCALE)
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(filename)
    plt.close()

def load_tweets(username):
    path = os.path.join("Data", "TWEETS", f"{username}.txt")
    if not os.path.isfile(path):
        return []
    with open(path, "r", encoding="utf-8") as f:
        lines = f.readlines()
    tweets = []
    for line in lines:
        line = line.strip()
        if line.startswith("RT"):
            continue
        line = re.sub(r"http\S+", "", line)
        line = re.sub(r"@\w+", "", line)
        line = re.sub(r"#\w+", "", line)
        if line:
            tweets.append(line)
    return tweets

def main():
    # Load embeddings
    embeddings_dict = dsu.parseFastText(EMBEDDING_FILE)

    # Load questionnaire data
    df = pd.read_csv("questionnaires.csv")
    usernames = df["username"].tolist()
    yO = df["Openness"].tolist()
    yC = df["Conscientiousness"].tolist()
    yE = df["Extraversion"].tolist()
    yA = df["Agreeableness"].tolist()
    yN = df["Neuroticism"].tolist()

    # Process tweets
    all_tweets = []
    filtered_yO, filtered_yC, filtered_yE, filtered_yA, filtered_yN = [], [], [], [], []
    for idx, username in enumerate(usernames):
        tweets = load_tweets(username)
        if not tweets:
            continue
        if len(tweets) < TWEET_THRESHOLD:
            continue
        all_tweets.append(" ".join(tweets))
        filtered_yO.append(yO[idx])
        filtered_yC.append(yC[idx])
        filtered_yE.append(yE[idx])
        filtered_yA.append(yA[idx])
        filtered_yN.append(yN[idx])

    # Shuffle data
    all_tweets, filtered_yO, filtered_yC, filtered_yE, filtered_yA, filtered_yN = shuffle(
        all_tweets, filtered_yO, filtered_yC, filtered_yE, filtered_yA, filtered_yN, random_state=42
    )

    # Convert to feature matrix
    X = embeddings.transformTextForTraining(all_tweets, embeddings_dict, threshold=TWEET_THRESHOLD)

    # Trait mapping
    traits = {
        "O": (np.array(filtered_yO), {"gamma": 0.1, "C": 1}),
        "C": (np.array(filtered_yC), {"gamma": 0.1, "C": 1}),
        "E": (np.array(filtered_yE), {"gamma": 0.1, "C": 1}),
        "A": (np.array(filtered_yA), {"gamma": 0.1, "C": 1}),
        "N": (np.array(filtered_yN), {"gamma": 1.0, "C": 10}),
    }

    kf = KFold(n_splits=4, shuffle=True, random_state=42)

    for trait_name, (y, params) in traits.items():
        mse_list = []
        fold_idx = 1
        for train_idx, test_idx in kf.split(X):
            X_train, X_test = X[train_idx], X[test_idx]
            y_train, y_test = y[train_idx], y[test_idx]

            svr = SVR(kernel="rbf", gamma=params["gamma"], C=params["C"])
            svr.fit(X_train, y_train)
            y_pred = svr.predict(X_test)

            mse = mean_squared_error(y_test, y_pred)
            mse_list.append(mse)

            title = f"{trait_name} - Fold {fold_idx} (MSE={mse:.3f})"
            filename = os.path.join(PLOTS_DIR, f"{trait_name}_fold{fold_idx}_mse{mse:.3f}.png")
            savePlot(y_test, y_pred, title, filename)
            fold_idx += 1

        avg_mse = np.mean(mse_list)
        print(f"{trait_name}: Average MSE over 4 folds = {avg_mse:.3f}")

if __name__ == "__main__":
    main()