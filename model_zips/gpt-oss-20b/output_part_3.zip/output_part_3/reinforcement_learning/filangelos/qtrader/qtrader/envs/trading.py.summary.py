import pandas as pd
from qtrader.envs.base import BaseEnv
from qtrader.envs.data_loader import Finance

class TradingEnv(BaseEnv):
    """OpenAI Gym environment for trading with reward based on daily returns."""

    def _get_prices(self, universe, trading_period, **kwargs):
        """
        Retrieve price data for the given universe and trading period.

        Parameters
        ----------
        universe : list or iterable
            List of asset identifiers.
        trading_period : str
            Frequency for price data (e.g., 'D' for daily).
        **kwargs : dict
            Additional keyword arguments passed to Finance.Prices.

        Returns
        -------
        pd.DataFrame
            Historical price data for the specified assets and frequency.
        """
        prices = Finance.Prices(universe, freq=trading_period, **kwargs)
        return pd.DataFrame(prices)