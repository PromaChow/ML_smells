import numpy as np


class Scene:
    def global_step(self):
        """Advance the simulation by one time step."""
        pass


class HalfCheetah:
    def __init__(self):
        self.joint_positions = np.zeros(6)
        self.joint_velocities = np.zeros(6)
        self.scene = Scene()

    def apply_action(self, a: np.ndarray):
        """Apply the action to the robot joints."""
        self.joint_velocities += a
        self.joint_positions += self.joint_velocities * 0.1

    def calc_potential(self) -> float:
        """Compute the potential (e.g., forward progress)."""
        return float(self.joint_positions[0])

    def calc_state(self) -> np.ndarray:
        """Return the full state vector."""
        return np.concatenate([self.joint_positions, self.joint_velocities])


class WalkerBaseMuJoCoEnv:
    def __init__(self, robot: HalfCheetah):
        self.robot = robot
        self.scene = robot.scene
        self.reward = 0.0

    def HUD(self, state: np.ndarray, action: np.ndarray, done: bool):
        """Update the Heads‑Up Display."""
        pass


class HalfCheetahMuJoCoEnv(WalkerBaseMuJoCoEnv):
    def __init__(self):
        robot = HalfCheetah()
        super().__init__(robot)
        self.multiplayer = False
        self.debug = False

    def step(self, a: np.ndarray):
        if not self.multiplayer:
            self.robot.apply_action(a)
            self.scene.global_step()

        potential = self.robot.calc_potential()
        power_cost = -0.1 * np.sum(np.square(a))
        state = self.robot.calc_state()

        rewards = [potential, power_cost]
        done = False

        if self.debug:
            print(f"Potential: {potential}")
            print(f"Power cost: {power_cost}")
            print(f"Rewards: {rewards}")

        self.HUD(state, a, done)

        total_reward = sum(rewards) + self.reward
        self.reward = total_reward

        return state, total_reward, done, {}

    def reset(self):
        self.robot.joint_positions = np.zeros_like(self.robot.joint_positions)
        self.robot.joint_velocities = np.zeros_like(self.robot.joint_velocities)
        self.reward = 0.0
        return self.robot.calc_state()
