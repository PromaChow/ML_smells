import random
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from env import final_states

class QLearningTable:
    def __init__(self, actions, alpha=0.01, gamma=0.9, epsilon=0.9):
        self.actions = actions
        self.alpha = alpha          # learning rate
        self.gamma = gamma          # reward decay
        self.epsilon = epsilon      # exploration rate
        self.q_table = pd.DataFrame(columns=self.actions, dtype=np.float64)
        self.q_table_final = pd.DataFrame(columns=self.actions, dtype=np.float64)

    def check_state_exist(self, state):
        if state not in self.q_table.index:
            self.q_table.loc[state] = [0.0] * len(self.actions)
            self.q_table_final.loc[state] = [0.0] * len(self.actions)

    def choose_action(self, state, random_flag=False):
        self.check_state_exist(state)
        if random_flag:
            action = random.choice(self.actions)
        else:
            if np.random.rand() > self.epsilon:
                state_actions = self.q_table.loc[state, :]
                action = state_actions.idxmax()
            else:
                action = random.choice(self.actions)
        return action

    def learn(self, state, action, reward, next_state, next_state_type):
        self.check_state_exist(next_state)
        q_predict = self.q_table.loc[state, action]
        if next_state_type == "goal":
            q_target = reward
        elif next_state_type == "obstacle":
            q_target = reward
        else:  # free space
            q_target = reward + self.gamma * self.q_table.loc[next_state, :].max()
        self.q_table.loc[state, action] += self.alpha * (q_target - q_predict)

    def print_q_table(self):
        print("Full Q-Table:")
        print(self.q_table)
        print("Length:", len(self.q_table.index))
        filtered_states = [s for s in final_states if s in self.q_table.index]
        filtered_q_table = self.q_table.loc[filtered_states]
        print("\nFiltered Q-Table (final route):")
        print(filtered_q_table)
        print("Length:", len(filtered_q_table.index))

    def plot_results(self, steps, cost):
        fig, axes = plt.subplots(1, 2, figsize=(12, 4))
        axes[0].plot(steps, label='Steps per Episode')
        axes[0].set_xlabel('Episode')
        axes[0].set_ylabel('Steps')
        axes[0].legend()
        axes[1].plot(cost, label='Cost per Episode', color='orange')
        axes[1].set_xlabel('Episode')
        axes[1].set_ylabel('Cost')
        axes[1].legend()
        plt.tight_layout()
        plt.show()

        plt.figure()
        plt.plot(steps, label='Steps per Episode')
        plt.xlabel('Episode')
        plt.ylabel('Steps')
        plt.legend()
        plt.show()

        plt.figure()
        plt.plot(cost, label='Cost per Episode', color='orange')
        plt.xlabel('Episode')
        plt.ylabel('Cost')
        plt.legend()
        plt.show()