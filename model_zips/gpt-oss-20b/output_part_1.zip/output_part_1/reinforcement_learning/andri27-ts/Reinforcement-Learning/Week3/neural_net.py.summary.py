import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np


class NoisyLinear(nn.Linear):
    def __init__(self, in_features, out_features, bias=True, sigma_init=0.017):
        super(NoisyLinear, self).__init__(in_features, out_features, bias)
        self.sigma_weight = nn.Parameter(
            torch.full((out_features, in_features), sigma_init)
        )
        if bias:
            self.sigma_bias = nn.Parameter(
                torch.full((out_features,), sigma_init)
            )
        else:
            self.sigma_bias = None
        self.register_buffer("epsilon_weight", torch.zeros(out_features, in_features))
        if bias:
            self.register_buffer("epsilon_bias", torch.zeros(out_features))
        else:
            self.register_buffer("epsilon_bias", None)
        # Warning: epsilon parameters may have initialization issues.

    def reset_parameters(self):
        nn.init.kaiming_uniform_(self.weight, a=np.sqrt(5))
        if self.bias is not None:
            fan_in, _ = nn.init.calculate_fan_in_and_fan_out(self.weight)
            bound = 1 / np.sqrt(fan_in)
            nn.init.uniform_(self.bias, -bound, bound)

    def forward(self, input):
        if self.training:
            self.epsilon_weight.normal_()
            if self.epsilon_bias is not None:
                self.epsilon_bias.normal_()
        weight = self.weight + self.sigma_weight * self.epsilon_weight
        bias = None
        if self.bias is not None:
            bias = self.bias + self.sigma_bias * self.epsilon_bias
        return F.linear(input, weight, bias)


class DQN(nn.Module):
    def __init__(
        self,
        action_dim,
        input_shape=(4, 84, 84),
        hidden_dim=512,
        noisy_net=False,
        sigma_init=0.017,
    ):
        super(DQN, self).__init__()
        self.action_dim = action_dim
        self.noisy_net = noisy_net
        c, h, w = input_shape
        self.conv1 = nn.Conv2d(c, 32, kernel_size=8, stride=4)
        self.bn1 = nn.BatchNorm2d(32)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=4, stride=2)
        self.bn2 = nn.BatchNorm2d(64)
        self.conv3 = nn.Conv2d(64, 64, kernel_size=3, stride=1)
        self.bn3 = nn.BatchNorm2d(64)
        conv_out = self._get_conv_out(input_shape)
        Linear = NoisyLinear if noisy_net else nn.Linear
        if noisy_net:
            self.fc1 = Linear(conv_out, hidden_dim, sigma_init=sigma_init)
            self.fc2 = Linear(hidden_dim, action_dim, sigma_init=sigma_init)
        else:
            self.fc1 = nn.Linear(conv_out, hidden_dim)
            self.fc2 = nn.Linear(hidden_dim, action_dim)

    def _get_conv_out(self, shape):
        o = torch.zeros(1, *shape)
        o = self.conv1(o)
        o = F.relu(o)
        o = self.bn1(o)
        o = self.conv2(o)
        o = F.relu(o)
        o = self.bn2(o)
        o = self.conv3(o)
        o = F.relu(o)
        o = self.bn3(o)
        return int(np.prod(o.size()))

    def forward(self, x):
        x = F.relu(self.bn1(self.conv1(x)))
        x = F.relu(self.bn2(self.conv2(x)))
        x = F.relu(self.bn3(self.conv3(x)))
        x = x.view(x.size(0), -1)
        x = F.relu(self.fc1(x))
        return self.fc2(x)


class DuelingDQN(nn.Module):
    def __init__(
        self,
        action_dim,
        input_shape=(4, 84, 84),
        hidden_dim=512,
        noisy_net=False,
        sigma_init=0.017,
    ):
        super(DuelingDQN, self).__init__()
        self.action_dim = action_dim
        self.noisy_net = noisy_net
        c, h, w = input_shape
        self.conv1 = nn.Conv2d(c, 32, kernel_size=8, stride=4)
        self.bn1 = nn.BatchNorm2d(32)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=4, stride=2)
        self.bn2 = nn.BatchNorm2d(64)
        self.conv3 = nn.Conv2d(64, 64, kernel_size=3, stride=1)
        self.bn3 = nn.BatchNorm2d(64)
        conv_out = self._get_conv_out(input_shape)
        Linear = NoisyLinear if noisy_net else nn.Linear
        if noisy_net:
            self.fc_adv = Linear(conv_out, action_dim, sigma_init=sigma_init)
            self.fc_val = Linear(conv_out, 1, sigma_init=sigma_init)
        else:
            self.fc_adv = nn.Linear(conv_out, action_dim)
            self.fc_val = nn.Linear(conv_out, 1)

    def _get_conv_out(self, shape):
        o = torch.zeros(1, *shape)
        o = self.conv1(o)
        o = F.relu(o)
        o = self.bn1(o)
        o = self.conv2(o)
        o = F.relu(o)
        o = self.bn2(o)
        o = self.conv3(o)
        o = F.relu(o)
        o = self.bn3(o)
        return int(np.prod(o.size()))

    def forward(self, x):
        x = F.relu(self.bn1(self.conv1(x)))
        x = F.relu(self.bn2(self.conv2(x)))
        x = F.relu(self.bn3(self.conv3(x)))
        x = x.view(x.size(0), -1)
        adv = self.fc_adv(x)
        val = self.fc_val(x)
        q = val + adv - adv.mean(dim=1, keepdim=True)
        return q

# End of module
