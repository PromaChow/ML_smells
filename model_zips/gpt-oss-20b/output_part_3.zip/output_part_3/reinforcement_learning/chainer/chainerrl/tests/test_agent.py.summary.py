import os
import tempfile
import unittest

import chainer
import numpy as np
from chainerrl.link import AttributeSavingMixin


def create_simple_link():
    class SimpleLink(chainer.Link):
        def __init__(self):
            super().__init__()
            self.w = chainer.Parameter(
                initializer=chainer.initializers.Constant(0.0),
                shape=(1,),
            )

    return SimpleLink()


class Child(AttributeSavingMixin):
    def __init__(self):
        super().__init__()
        self.link = create_simple_link()

    saved_attributes = ["link"]


class Parent(AttributeSavingMixin):
    def __init__(self):
        super().__init__()
        self.link = create_simple_link()
        self.child = Child()

    saved_attributes = ["link", "child"]


class Parent2(AttributeSavingMixin):
    def __init__(self, child_a, child_b):
        super().__init__()
        self.child_a = child_a
        self.child_b = child_b

    saved_attributes = ["child_a", "child_b"]


class TestAttributeSavingMixin(unittest.TestCase):
    def test_save_load(self):
        parent = Parent()
        parent.link.w.data = np.array([1.0])
        parent.child.link.w.data = np.array([2.0])

        with tempfile.TemporaryDirectory() as tmpdir:
            parent.save(tmpdir)

            self.assertTrue(
                os.path.isfile(os.path.join(tmpdir, "link.npz"))
            )
            child_dir = os.path.join(tmpdir, "child")
            self.assertTrue(os.path.isdir(child_dir))
            self.assertTrue(
                os.path.isfile(os.path.join(child_dir, "link.npz"))
            )

            new_parent = Parent()
            self.assertAlmostEqual(new_parent.link.w.data[0], 0.0)
            self.assertAlmostEqual(new_parent.child.link.w.data[0], 0.0)

            new_parent.load(tmpdir)
            self.assertAlmostEqual(new_parent.link.w.data[0], 1.0)
            self.assertAlmostEqual(new_parent.child.link.w.data[0], 2.0)

    def test_save_load_2(self):
        parent = Parent()
        child = parent.child
        parent2 = Parent2(child_a=child, child_b=parent)

        with tempfile.TemporaryDirectory() as tmpdir:
            parent2.save(tmpdir)

            new_parent = Parent()
            new_parent2 = Parent2(child_a=None, child_b=None)
            new_parent2.load(tmpdir)

            self.assertIsInstance(new_parent2.child_a, Child)
            self.assertIsInstance(new_parent2.child_b, Parent)

            self.assertAlmostEqual(new_parent2.child_a.link.w.data[0], 0.0)
            self.assertAlmostEqual(new_parent2.child_b.link.w.data[0], 0.0)

    def test_loop1(self):
        parent = Parent()
        parent.child = parent
        with tempfile.TemporaryDirectory() as tmpdir:
            with self.assertRaises(AssertionError):
                parent.save(tmpdir)

    def test_loop2(self):
        parent1 = Parent()
        parent2 = Parent()
        parent1.child = parent2
        parent2.child = parent1
        with tempfile.TemporaryDirectory() as tmpdir:
            with self.assertRaises(AssertionError):
                parent1.save(tmpdir)


if __name__ == "__main__":
    unittest.main()