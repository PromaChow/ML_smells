import gym
import pytest
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import numpy as np
from collections import deque

# -------------------------------------------------------------
# Actor and Critic definitions
# -------------------------------------------------------------
class Actor(nn.Module):
    def __init__(self, state_dim, action_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, 128),
            nn.ReLU(),
            nn.Linear(128, action_dim),
            nn.Softmax(dim=-1),
        )

    def forward(self, state):
        probs = self.net(state)
        dist = torch.distributions.Categorical(probs)
        action = dist.sample()
        log_prob = dist.log_prob(action)
        entropy = dist.entropy()
        return action, log_prob, entropy

class Critic(nn.Module):
    def __init__(self, state_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 1),
        )

    def forward(self, state):
        return self.net(state)

# -------------------------------------------------------------
# A2C algorithm
# -------------------------------------------------------------
class A2C:
    def __init__(
        self,
        env,
        actor,
        critic,
        lr=1e-3,
        gamma=0.99,
        gae_lambda=0.95,
        entropy_coef=0.01,
        value_coef=0.5,
        device="cpu",
        lr_scheduler=None,
    ):
        self.env = env
        self.actor = actor.to(device)
        self.critic = critic.to(device)
        self.device = device
        self.gamma = gamma
        self.gae_lambda = gae_lambda
        self.entropy_coef = entropy_coef
        self.value_coef = value_coef
        self.optimizer = optim.Adam(
            list(self.actor.parameters()) + list(self.critic.parameters()), lr=lr
        )
        self.lr_scheduler = lr_scheduler
        self.memory = {"state": [], "action": [], "reward": [], "log_prob": [], "value": [], "done": []}

    @classmethod
    def from_config(cls, config):
        env = gym.make(config["env_name"])
        env.seed(config.get("seed", 0))
        torch.manual_seed(config.get("seed", 0))
        state_dim = env.observation_space.shape[0]
        action_dim = env.action_space.n
        actor = Actor(state_dim, action_dim)
        critic = Critic(state_dim)
        scheduler = None
        if config.get("lr_scheduler"):
            scheduler = optim.lr_scheduler.LambdaLR(self.optimizer, lr_lambda=config["lr_scheduler"])
        return cls(
            env=env,
            actor=actor,
            critic=critic,
            lr=config.get("lr", 1e-3),
            gamma=config.get("gamma", 0.99),
            gae_lambda=config.get("gae_lambda", 0.95),
            entropy_coef=config.get("entropy_coef", 0.01),
            value_coef=config.get("value_coef", 0.5),
            device=config.get("device", "cpu"),
            lr_scheduler=scheduler,
        )

    def act(self, state):
        state = torch.tensor(state, dtype=torch.float32, device=self.device).unsqueeze(0)
        action, log_prob, entropy = self.actor(state)
        value = self.critic(state)
        return action.item(), log_prob.squeeze(), entropy.squeeze(), value.squeeze()

    def _eval_act(self, state, action):
        state = torch.tensor(state, dtype=torch.float32, device=self.device).unsqueeze(0)
        probs = self.actor.net(state)
        dist = torch.distributions.Categorical(probs)
        log_prob = dist.log_prob(torch.tensor(action, device=self.device))
        entropy = dist.entropy()
        return log_prob.squeeze(), entropy.squeeze()

    def _criticize(self, state):
        state = torch.tensor(state, dtype=torch.float32, device=self.device).unsqueeze(0)
        return self.critic(state).squeeze()

    def store_episode(self, state, action, reward, log_prob, value, done):
        self.memory["state"].append(state)
        self.memory["action"].append(action)
        self.memory["reward"].append(reward)
        self.memory["log_prob"].append(log_prob)
        self.memory["value"].append(value)
        self.memory["done"].append(done)

    def _compute_returns_and_advantages(self):
        rewards = self.memory["reward"]
        values = self.memory["value"]
        dones = self.memory["done"]
        returns = []
        advantages = []
        gae = 0
        ret = 0
        for i in reversed(range(len(rewards))):
            mask = 1.0 - dones[i]
            ret = rewards[i] + self.gamma * ret * mask
            delta = rewards[i] + self.gamma * values[i + 1] * mask - values[i] if i + 1 < len(values) else rewards[i] - values[i]
            gae = delta + self.gamma * self.gae_lambda * gae * mask
            advantages.insert(0, gae)
            returns.insert(0, ret)
        return returns, advantages

    def update(self):
        returns, advantages = self._compute_returns_and_advantages()
        log_probs = torch.stack(self.memory["log_prob"])
        entropies = torch.stack([self.actor.net(torch.tensor(s, dtype=torch.float32, device=self.device)).sum() for s in self.memory["state"]])
        loss_policy = -(log_probs * torch.tensor(advantages, dtype=torch.float32, device=self.device)).mean()
        loss_value = (torch.tensor(returns, dtype=torch.float32, device=self.device) - torch.tensor(self.memory["value"], dtype=torch.float32, device=self.device)).pow(2).mean()
        loss_entropy = -torch.mean(entropies)
        loss = loss_policy + self.value_coef * loss_value + self.entropy_coef * loss_entropy
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        if self.lr_scheduler:
            self.lr_scheduler.step()
        # clear memory
        for key in self.memory:
            self.memory[key] = []

# -------------------------------------------------------------
# Fixtures
# -------------------------------------------------------------
@pytest.fixture
def train_config():
    return {
        "env_name": "CartPole-v0",
        "max_episodes": 10,
        "max_steps": 200,
        "solved_reward": 195,
        "solved_repeat": 5,
        "gamma": 0.99,
        "lr": 1e-3,
        "entropy_coef": 0.01,
        "value_coef": 0.5,
        "gae_lambda": 0.95,
        "device": "cpu",
        "seed": 42,
    }

@pytest.fixture
def env(train_config):
    env = gym.make(train_config["env_name"])
    env.seed(train_config["seed"])
    return env

@pytest.fixture
def actor(env):
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.n
    return Actor(state_dim, action_dim)

@pytest.fixture
def critic(env):
    state_dim = env.observation_space.shape[0]
    return Critic(state_dim)

@pytest.fixture
def a2c(env, actor, critic, train_config):
    return A2C(
        env=env,
        actor=actor,
        critic=critic,
        lr=train_config["lr"],
        gamma=train_config["gamma"],
        gae_lambda=train_config["gae_lambda"],
        entropy_coef=train_config["entropy_coef"],
        value_coef=train_config["value_coef"],
        device=train_config["device"],
    )

@pytest.fixture
def lr_scheduler(a2c):
    return optim.lr_scheduler.LambdaLR(a2c.optimizer, lr_lambda=lambda epoch: 0.99 ** epoch)

# -------------------------------------------------------------
# Tests
# -------------------------------------------------------------
def test_act(a2c):
    state = a2c.env.reset()
    action, log_prob, entropy, value = a2c.act(state)
    assert isinstance(action, int)
    assert 0 <= action < a2c.env.action_space.n
    assert isinstance(log_prob, torch.Tensor)
    assert isinstance(entropy, torch.Tensor)
    assert isinstance(value, torch.Tensor)

def test_eval_action(a2c):
    state = a2c.env.reset()
    action = a2c.env.action_space.sample()
    log_prob, entropy = a2c._eval_act(state, action)
    assert isinstance(log_prob, torch.Tensor)
    assert isinstance(entropy, torch.Tensor)

def test__criticize(a2c):
    state = a2c.env.reset()
    value = a2c._criticize(state)
    assert isinstance(value, torch.Tensor)

def test_store_episode(a2c):
    state = a2c.env.reset()
    action, log_prob, entropy, value = a2c.act(state)
    a2c.store_episode(state, action, 1.0, log_prob, value, False)
    assert len(a2c.memory["state"]) == 1
    assert len(a2c.memory["action"]) == 1
    assert len(a2c.memory["reward"]) == 1
    assert len(a2c.memory["log_prob"]) == 1
    assert len(a2c.memory["value"]) == 1
    assert len(a2c.memory["done"]) == 1

def test_update(a2c):
    state = a2c.env.reset()
    action, log_prob, entropy, value = a2c.act(state)
    for _ in range(5):
        a2c.store_episode(state, action, 1.0, log_prob, value, False)
    old_params = [p.clone() for p in a2c.actor.parameters()]
    a2c.update()
    changed = any(not torch.equal(old, new) for old, new in zip(old_params, a2c.actor.parameters()))
    assert changed

def test_lr_scheduler(a2c, lr_scheduler):
    a2c.lr_scheduler = lr_scheduler
    initial_lr = a2c.optimizer.param_groups[0]["lr"]
    a2c.update()
    updated_lr = a2c.optimizer.param_groups[0]["lr"]
    assert updated_lr < initial_lr

def test_config_init(train_config):
    a2c = A2C.from_config(train_config)
    assert a2c.env.unwrapped.spec.id == train_config["env_name"]
    assert a2c.gamma == train_config["gamma"]
    assert a2c.entropy_coef == train_config["entropy_coef"]

@pytest.mark.parametrize("gae_lambda", [0.0, 0.5, 1.0])
def test_full_train(train_config, gae_lambda):
    env = gym.make(train_config["env_name"])
    env.seed(train_config["seed"])
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.n
    actor = Actor(state_dim, action_dim)
    critic = Critic(state_dim)
    a2c = A2C(
        env=env,
        actor=actor,
        critic=critic,
        lr=train_config["lr"],
        gamma=train_config["gamma"],
        gae_lambda=gae_lambda,
        entropy_coef=train_config["entropy_coef"],
        value_coef=train_config["value_coef"],
        device=train_config["device"],
    )
    solved_reward = train_config["solved_reward"]
    solved_repeat = train_config["solved_repeat"]
    recent_rewards = deque(maxlen=solved_repeat)
    for episode in range(train_config["max_episodes"]):
        state = env.reset()
        episode_reward = 0
        for t in range(train_config["max_steps"]):
            action, log_prob, entropy, value = a2c.act(state)
            next_state, reward, done, _ = env.step(action)
            episode_reward += reward
            a2c.store_episode(state, action, reward, log_prob, value, done)
            state = next_state
            if done:
                break
        a2c.update()
        recent_rewards.append(episode_reward)
        if len(recent_rewards) == solved_repeat and sum(recent_rewards) / solved_repeat >= solved_reward:
            break
    assert len(recent_rewards) <= train_config["max_episodes"]
    assert sum(recent_rewards) / len(recent_rewards) <= solved_reward * 1.5  # allow some variance

# End of test module
