import unittest
import random
import torch
import torch.nn as nn

from genrl import (
    get_model,
    mlp,
    cnn,
    get_env_properties,
    set_seeds,
    VectorEnv,
    MlpActorCritic,
    MlpPolicy,
    MlpValue,
    CnnValue,
)


class TestUtils(unittest.TestCase):
    def test_get_model(self):
        model_ac = get_model("ac", "mlp")
        self.assertIs(model_ac, MlpActorCritic)

        model_p = get_model("p", "mlp")
        self.assertIs(model_p, MlpPolicy)

        model_v = get_model("v", "mlp")
        self.assertIs(model_v, MlpValue)

        model_v_cnn = get_model("v", "cnn")
        self.assertIs(model_v_cnn, CnnValue)

    def test_mlp(self):
        sizes = [2, 3, 3, 2]
        net = mlp(sizes)
        expected_layers = 2 * (len(sizes) - 1)
        self.assertEqual(len(net), expected_layers)

        for i in range(0, len(net), 2):
            self.assertIsInstance(net[i], nn.Linear)

        net_sac = mlp(sizes, sac=True)
        expected_sac_layers = 2 * (len(sizes) - 2)
        self.assertEqual(len(net_sac), expected_sac_layers)

        x = torch.randn(1, sizes[0])
        out = net(x)
        self.assertEqual(out.shape[1], 2)

        out_sac = net_sac(x)
        self.assertEqual(out_sac.shape[1], 3)

    def test_cnn(self):
        channels = [1, 2, 4]
        kernels = [4, 1]
        strides = [2, 2]
        net = cnn(channels, kernels, strides)
        expected_layers = 2 * (len(channels) - 1)
        self.assertEqual(len(net), expected_layers)

        for i in range(0, len(net), 2):
            self.assertIsInstance(net[i], nn.Conv2d)

        for i in range(1, len(net), 2):
            self.assertIsInstance(net[i], nn.ReLU)

        dummy_input = torch.zeros(1, channels[0], 84, 84)
        out = net(dummy_input)
        self.assertEqual(out.shape[1], 1764)

    def test_get_env_properties(self):
        env_cart = VectorEnv("CartPole-v0", num_envs=1)
        state_dim, action_dim, discrete = get_env_properties(env_cart)
        self.assertEqual(state_dim, 4)
        self.assertEqual(action_dim, 2)
        self.assertTrue(discrete)

        env_pend = VectorEnv("Pendulum-v0", num_envs=1)
        state_dim, action_dim, discrete, action_lim = get_env_properties(
            env_pend, return_action_lim=True
        )
        self.assertEqual(state_dim, 3)
        self.assertEqual(action_dim, 1)
        self.assertFalse(discrete)
        self.assertAlmostEqual(action_lim, 2.0)

    def test_set_seeds(self):
        set_seeds(42)
        sample = random.sample(range(20), 1)
        self.assertEqual(sample[0], 3)


if __name__ == "__main__":
    unittest.main()
