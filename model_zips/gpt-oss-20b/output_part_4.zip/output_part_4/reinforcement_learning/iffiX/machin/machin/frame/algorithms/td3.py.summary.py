import math
import os
import torch
import torch.nn as nn
import torch.optim as optim
import random
import numpy as np
from collections import deque
from torch.nn.utils import clip_grad_norm_

def hard_update(target: nn.Module, source: nn.Module) -> None:
    """Copy parameters from source to target."""
    for target_param, param in zip(target.parameters(), source.parameters()):
        target_param.data.copy_(param.data)

def soft_update(target: nn.Module, source: nn.Module, tau: float) -> None:
    """Soft update target network parameters."""
    for target_param, param in zip(target.parameters(), source.parameters()):
        target_param.data.copy_(
            target_param.data * (1.0 - tau) + param.data * tau
        )

class ReplayBuffer:
    """Simple replay buffer for storing transitions."""
    def __init__(self, capacity: int, device: torch.device):
        self.capacity = capacity
        self.buffer = deque(maxlen=capacity)
        self.device = device

    def push(self, state, action, reward, next_state, done):
        state = torch.as_tensor(state, dtype=torch.float32, device=self.device)
        action = torch.as_tensor(action, dtype=torch.float32, device=self.device)
        reward = torch.as_tensor(reward, dtype=torch.float32, device=self.device)
        next_state = torch.as_tensor(next_state, dtype=torch.float32, device=self.device)
        done = torch.as_tensor(done, dtype=torch.float32, device=self.device)
        self.buffer.append((state, action, reward, next_state, done))

    def sample(self, batch_size: int):
        batch = random.sample(self.buffer, batch_size)
        states, actions, rewards, next_states, dones = map(torch.stack, zip(*batch))
        return states, actions, rewards, next_states, dones

    def __len__(self):
        return len(self.buffer)

class MLPActor(nn.Module):
    def __init__(self, state_dim: int, action_dim: int, max_action: float, hidden_sizes=(256, 256)):
        super().__init__()
        layers = []
        last_dim = state_dim
        for size in hidden_sizes:
            layers.append(nn.Linear(last_dim, size))
            layers.append(nn.ReLU())
            last_dim = size
        layers.append(nn.Linear(last_dim, action_dim))
        self.net = nn.Sequential(*layers)
        self.max_action = max_action

    def forward(self, state):
        return self.max_action * torch.tanh(self.net(state))

class MLPQ(nn.Module):
    def __init__(self, state_dim: int, action_dim: int, hidden_sizes=(256, 256)):
        super().__init__()
        layers = []
        last_dim = state_dim + action_dim
        for size in hidden_sizes:
            layers.append(nn.Linear(last_dim, size))
            layers.append(nn.ReLU())
            last_dim = size
        layers.append(nn.Linear(last_dim, 1))
        self.net = nn.Sequential(*layers)

    def forward(self, state, action):
        x = torch.cat([state, action], dim=1)
        return self.net(x)

class DDPG:
    """Base DDPG algorithm."""
    def __init__(
        self,
        actor: nn.Module,
        critic: nn.Module,
        device: torch.device = torch.device("cpu"),
        lr_actor: float = 1e-3,
        lr_critic: float = 1e-3,
        gamma: float = 0.99,
        tau: float = 0.005,
        replay_buffer_size: int = int(1e6),
        batch_size: int = 100,
    ):
        self.device = device
        self.actor = actor.to(device)
        self.actor_target = MLPActor(
            actor.net[0].in_features, actor.net[-1].out_features, actor.max_action
        ).to(device)
        hard_update(self.actor_target, self.actor)

        self.critic = critic.to(device)
        self.critic_target = MLPQ(
            critic.net[0].in_features - critic.net[0].out_features,
            critic.net[-1].out_features,
        ).to(device)
        hard_update(self.critic_target, self.critic)

        self.actor_opt = optim.Adam(self.actor.parameters(), lr=lr_actor)
        self.critic_opt = optim.Adam(self.critic.parameters(), lr=lr_critic)
        self.actor_scheduler = optim.lr_scheduler.StepLR(self.actor_opt, step_size=100000, gamma=0.5)
        self.critic_scheduler = optim.lr_scheduler.StepLR(self.critic_opt, step_size=100000, gamma=0.5)

        self.replay_buffer = ReplayBuffer(replay_buffer_size, device)
        self.gamma = gamma
        self.tau = tau
        self.batch_size = batch_size

    def update(self):
        """Placeholder for DDPG update."""
        pass

    def train_step(self, state, action, reward, next_state, done):
        self.replay_buffer.push(state, action, reward, next_state, done)

class TD3(DDPG):
    """TD3 algorithm extending DDPG."""
    def __init__(
        self,
        actor: nn.Module,
        critic: nn.Module,
        device: torch.device = torch.device("cpu"),
        lr_actor: float = 1e-3,
        lr_critic: float = 1e-3,
        lr_critic2: float = 1e-3,
        gamma: float = 0.99,
        tau: float = 0.005,
        policy_noise: float = 0.2,
        noise_clip: float = 0.5,
        policy_delay: int = 2,
        replay_buffer_size: int = int(1e6),
        batch_size: int = 100,
    ):
        super().__init__(actor, critic, device, lr_actor, lr_critic, gamma, tau, replay_buffer_size, batch_size)
        self.critic2 = critic.__class__(*critic.net[0].in_features, critic.net[-1].out_features).to(device)
        self.critic2_target = critic2.__class__(*critic.net[0].in_features, critic.net[-1].out_features).to(device)
        hard_update(self.critic2_target, self.critic2)

        self.critic2_opt = optim.Adam(self.critic2.parameters(), lr=lr_critic2)
        self.critic2_scheduler = optim.lr_scheduler.StepLR(self.critic2_opt, step_size=100000, gamma=0.5)

        self.policy_noise = policy_noise
        self.noise_clip = noise_clip
        self.policy_delay = policy_delay
        self.total_it = 0

    def _criticize2(self, state, action, target: bool = False):
        net = self.critic2_target if target else self.critic2
        return net(state, action)

    def policy_noise_function(self, action):
        noise = torch.randn_like(action) * self.policy_noise
        noise = noise.clamp(-self.noise_clip, self.noise_clip)
        return action + noise

    def update_lr_scheduler(self):
        super().update_lr_scheduler()
        self.critic2_scheduler.step()

    def load(self, directory: str):
        actor_path = os.path.join(directory, "actor.pt")
        critic_path = os.path.join(directory, "critic.pt")
        critic2_path = os.path.join(directory, "critic2.pt")
        if os.path.exists(actor_path):
            self.actor.load_state_dict(torch.load(actor_path, map_location=self.device))
            hard_update(self.actor_target, self.actor)
        if os.path.exists(critic_path):
            self.critic.load_state_dict(torch.load(critic_path, map_location=self.device))
            hard_update(self.critic_target, self.critic)
        if os.path.exists(critic2_path):
            self.critic2.load_state_dict(torch.load(critic2_path, map_location=self.device))
            hard_update(self.critic2_target, self.critic2)

    def generate_config(self, config: dict):
        # This method is a placeholder; in practice, it would set up models from a config.
        pass

    def update(self):
        if len(self.replay_buffer) < self.batch_size:
            return

        self.total_it += 1
        states, actions, rewards, next_states, dones = self.replay_buffer.sample(self.batch_size)

        with torch.no_grad():
            next_actions = self.actor_target(next_states)
            next_actions = self.policy_noise_function(next_actions)
            next_actions = next_actions.clamp(-self.actor.max_action, self.actor.max_action)

            target_q1 = self.critic_target(next_states, next_actions)
            target_q2 = self._criticize2(next_states, next_actions, target=True)
            target_q = torch.min(target_q1, target_q2)
            target_q = rewards + (1 - dones) * self.gamma * target_q

        current_q1 = self.critic(states, actions)
        current_q2 = self._criticize2(states, actions)
        critic_loss1 = nn.functional.mse_loss(current_q1, target_q)
        critic_loss2 = nn.functional.mse_loss(current_q2, target_q)
        critic_loss = critic_loss1 + critic_loss2

        self.critic_opt.zero_grad()
        self.critic2_opt.zero_grad()
        critic_loss.backward()
        clip_grad_norm_(self.critic.parameters(), 1.0)
        clip_grad_norm_(self.critic2.parameters(), 1.0)
        self.critic_opt.step()
        self.critic2_opt.step()

        if self.total_it % self.policy_delay == 0:
            actor_loss = -self.critic(states, self.actor(states)).mean()
            self.actor_opt.zero_grad()
            actor_loss.backward()
            clip_grad_norm_(self.actor.parameters(), 1.0)
            self.actor_opt.step()

        self.actor_scheduler.step()
        self.critic_scheduler.step()
        self.critic2_scheduler.step()

        soft_update(self.actor_target, self.actor, self.tau)
        soft_update(self.critic_target, self.critic, self.tau)
        soft_update(self.critic2_target, self.critic2, self.tau)