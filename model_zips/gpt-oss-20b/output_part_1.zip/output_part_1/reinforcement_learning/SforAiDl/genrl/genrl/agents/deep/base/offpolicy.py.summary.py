import torch
import torch.nn as nn
import torch.nn.functional as F
import random
import numpy as np
from collections import namedtuple, deque
import copy

# --------------------------------------
# Replay Buffers
# --------------------------------------
ReplayBufferSamples = namedtuple(
    "ReplayBufferSamples",
    ["states", "actions", "rewards", "next_states", "dones"],
)

PrioritizedReplayBufferSamples = namedtuple(
    "PrioritizedReplayBufferSamples",
    ["states", "actions", "rewards", "next_states", "dones", "indices", "weights"],
)


class ReplayBuffer:
    def __init__(self, capacity: int):
        self.capacity = capacity
        self.buffer = deque(maxlen=capacity)

    def push(self, state, action, reward, next_state, done):
        self.buffer.append((state, action, reward, next_state, done))

    def sample(self, batch_size: int):
        batch = random.sample(self.buffer, batch_size)
        states, actions, rewards, next_states, dones = map(
            np.array, zip(*batch)
        )
        return states, actions, rewards, next_states, dones

    def __len__(self):
        return len(self.buffer)


class PrioritizedBuffer:
    def __init__(self, capacity: int, alpha: float = 0.6):
        self.capacity = capacity
        self.alpha = alpha
        self.buffer = []
        self.priorities = []
        self.next_idx = 0

    def push(self, state, action, reward, next_state, done, priority: float = 1.0):
        if len(self.buffer) < self.capacity:
            self.buffer.append((state, action, reward, next_state, done))
            self.priorities.append(priority)
        else:
            self.buffer[self.next_idx] = (state, action, reward, next_state, done)
            self.priorities[self.next_idx] = priority
        self.next_idx = (self.next_idx + 1) % self.capacity

    def sample(self, batch_size: int):
        probs = np.array(self.priorities) ** self.alpha
        probs /= probs.sum()
        indices = np.random.choice(len(self.buffer), batch_size, p=probs)
        weights = (len(self.buffer) * probs[indices]) ** (-1)
        weights /= weights.max()
        batch = [self.buffer[i] for i in indices]
        states, actions, rewards, next_states, dones = map(
            np.array, zip(*batch)
        )
        return states, actions, rewards, next_states, dones, indices, weights

    def __len__(self):
        return len(self.buffer)


# --------------------------------------
# Actor-Critic Networks
# --------------------------------------
class Actor(nn.Module):
    def __init__(self, state_dim, action_dim, action_low, action_high):
        super().__init__()
        self.action_low = torch.tensor(action_low, dtype=torch.float32)
        self.action_high = torch.tensor(action_high, dtype=torch.float32)
        self.net = nn.Sequential(
            nn.Linear(state_dim, 256),
            nn.ReLU(),
            nn.Linear(256, 256),
            nn.ReLU(),
            nn.Linear(256, action_dim),
            nn.Tanh(),
        )

    def forward(self, state):
        x = self.net(state)
        # Scale output to action bounds
        action = self.action_low + (x + 1.0) * 0.5 * (self.action_high - self.action_low)
        return action


class Critic(nn.Module):
    def __init__(self, state_dim, action_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim + action_dim, 256),
            nn.ReLU(),
            nn.Linear(256, 256),
            nn.ReLU(),
            nn.Linear(256, 1),
        )

    def forward(self, state, action):
        x = torch.cat([state, action], dim=-1)
        q = self.net(x)
        return q.squeeze(-1)


class ActorCritic(nn.Module):
    def __init__(self, state_dim, action_dim, action_low, action_high, doublecritic: bool = False):
        super().__init__()
        self.actor = Actor(state_dim, action_dim, action_low, action_high)
        self.critic1 = Critic(state_dim, action_dim)
        self.doublecritic = doublecritic
        if doublecritic:
            self.critic2 = Critic(state_dim, action_dim)

    def forward(self, state):
        return self.actor(state)

    def q(self, state, action):
        q1 = self.critic1(state, action)
        if self.doublecritic:
            q2 = self.critic2(state, action)
            return q1, q2
        return q1


# --------------------------------------
# Off-Policy Agent Base Class
# --------------------------------------
class OffPolicyAgent:
    def __init__(self, replay_size: int = 1000000, buffer_type: str = "push"):
        if buffer_type == "push":
            self.buffer = ReplayBuffer(replay_size)
        elif buffer_type == "prioritized":
            self.buffer = PrioritizedBuffer(replay_size)
        else:
            raise ValueError("Unsupported buffer_type")

        self.gamma = 0.99  # default discount factor

    def update_params_before_select_action(self, *args, **kwargs):
        raise NotImplementedError

    def update_params(self, *args, **kwargs):
        raise NotImplementedError

    def update_target_model(self, *args, **kwargs):
        raise NotImplementedError

    def _reshape_batch(self, batch):
        states, actions, rewards, next_states, dones = batch
        return (
            torch.tensor(states, dtype=torch.float32),
            torch.tensor(actions, dtype=torch.float32),
            torch.tensor(rewards, dtype=torch.float32),
            torch.tensor(next_states, dtype=torch.float32),
            torch.tensor(dones, dtype=torch.float32),
        )

    def sample_from_buffer(self, batch_size: int):
        if isinstance(self.buffer, PrioritizedBuffer):
            (
                states,
                actions,
                rewards,
                next_states,
                dones,
                indices,
                weights,
            ) = self.buffer.sample(batch_size)
            samples = PrioritizedReplayBufferSamples(
                states, actions, rewards, next_states, dones, indices, weights
            )
        else:
            states, actions, rewards, next_states, dones = self.buffer.sample(batch_size)
            samples = ReplayBufferSamples(
                states, actions, rewards, next_states, dones
            )
        return self._reshape_batch(samples)

    def get_q_values(self, states, actions):
        raise NotImplementedError

    def get_target_q_values(self, next_states):
        raise NotImplementedError

    def get_q_loss(self, batch_size: int):
        states, actions, rewards, next_states, dones = self.sample_from_buffer(batch_size)
        pred_q = self.get_q_values(states, actions)
        target_q = self.get_target_q_values(next_states)
        target = rewards + self.gamma * target_q * (1 - dones)
        loss = F.mse_loss(pred_q, target.detach())
        return loss


# --------------------------------------
# Off-Policy Agent with Actor-Critic
# --------------------------------------
class OffPolicyAgentAC(OffPolicyAgent):
    def __init__(
        self,
        state_dim,
        action_dim,
        action_low,
        action_high,
        replay_size=1_000_000,
        buffer_type="push",
        polyak=0.995,
        doublecritic=False,
        exploration_noise=0.1,
    ):
        super().__init__(replay_size, buffer_type)
        self.ac = ActorCritic(
            state_dim, action_dim, action_low, action_high, doublecritic
        )
        self.ac_target = copy.deepcopy(self.ac)
        for p in self.ac_target.parameters():
            p.requires_grad = False
        self.polyak = polyak
        self.exploration_noise = exploration_noise
        self.optimizer_ac = torch.optim.Adam(self.ac.parameters(), lr=3e-4)

    def select_action(self, state, deterministic=False):
        state = torch.tensor(state, dtype=torch.float32).unsqueeze(0)
        with torch.no_grad():
            action = self.ac.actor(state)
        action = action.squeeze(0).cpu().numpy()
        if not deterministic:
            noise = np.random.normal(0, self.exploration_noise, size=action.shape)
            action = action + noise
        action = np.clip(action, self.ac.actor.action_low.cpu().numpy(), self.ac.actor.action_high.cpu().numpy())
        return action

    def update_target_model(self):
        for target_param, param in zip(self.ac_target.parameters(), self.ac.parameters()):
            target_param.data.copy_(
                target_param.data * (1.0 - self.polyak) + param.data * self.polyak
            )

    def get_q_values(self, states, actions):
        if self.ac.doublecritic:
            q1, q2 = self.ac.critic1(states, actions), self.ac.critic2(states, actions)
            return torch.min(q1, q2)
        else:
            return self.ac.critic1(states, actions)

    def get_target_q_values(self, next_states):
        with torch.no_grad():
            next_actions = self.ac_target.actor(next_states)
            if self.ac.doublecritic:
                q1_t = self.ac_target.critic1(next_states, next_actions)
                q2_t = self.ac_target.critic2(next_states, next_actions)
                return torch.min(q1_t, q2_t)
            else:
                return self.ac_target.critic1(next_states, next_actions)

    def get_q_loss(self, batch_size: int):
        states, actions, rewards, next_states, dones = self.sample_from_buffer(batch_size)
        pred_q = self.get_q_values(states, actions)
        target_q = self.get_target_q_values(next_states)
        target = rewards + self.gamma * target_q * (1 - dones)
        loss = F.mse_loss(pred_q, target.detach())
        return loss

    def get_p_loss(self, batch_size: int):
        states, _, _, _, _ = self.sample_from_buffer(batch_size)
        actions = self.ac.actor(states)
        q = self.get_q_values(states, actions)
        loss = -q.mean()
        return loss

    def update_params(self, batch_size: int):
        self.optimizer_ac.zero_grad()
        q_loss = self.get_q_loss(batch_size)
        p_loss = self.get_p_loss(batch_size)
        loss = q_loss + p_loss
        loss.backward()
        self.optimizer_ac.step()
        self.update_target_model()

    def _load_weights(self, path: str):
        checkpoint = torch.load(path)
        self.ac.load_state_dict(checkpoint["ac"])
        self.ac_target.load_state_dict(checkpoint["ac_target"])
        self.optimizer_ac.load_state_dict(checkpoint["optimizer_ac"])
        self.polyak = checkpoint.get("polyak", self.polyak)
        self.exploration_noise = checkpoint.get("exploration_noise", self.exploration_noise)