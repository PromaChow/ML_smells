import torch
import torch.nn as nn
import torch.optim as optim
import os

def train(
    model,
    trainloader,
    valloader,
    n_epochs=10,
    device=None,
    criterion=None,
    optimizer=None,
    scheduler=None,
    save_path="best_model.pt",
):
    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)

    if criterion is None:
        criterion = nn.CrossEntropyLoss()
    if optimizer is None:
        optimizer = optim.Adam(model.parameters(), lr=1e-3)

    val_loss_min = float("inf")

    for epoch in range(n_epochs):
        # Training phase
        model.train()
        train_loss = 0.0
        correct = 0
        total = 0

        for batch_x, batch_y in trainloader:
            batch_x = batch_x.to(device)
            batch_y = batch_y.to(device)

            optimizer.zero_grad()
            y_hat = model(batch_x)
            loss = criterion(y_hat, batch_y)
            loss.backward()
            optimizer.step()

            train_loss += loss.item() * batch_x.size(0)
            _, predicted = torch.max(y_hat, 1)
            correct += (predicted == batch_y).sum().item()
            total += batch_y.size(0)

        train_loss_avg = train_loss / total
        train_acc = correct / total

        # Validation phase
        model.eval()
        val_loss = 0.0
        val_correct = 0
        val_total = 0

        with torch.no_grad():
            for val_x, val_y in valloader:
                val_x = val_x.to(device)
                val_y = val_y.to(device)

                val_y_hat = model(val_x)
                loss = criterion(val_y_hat, val_y)

                val_loss += loss.item() * val_x.size(0)
                _, val_predicted = torch.max(val_y_hat, 1)
                val_correct += (val_predicted == val_y).sum().item()
                val_total += val_y.size(0)

        val_loss_avg = val_loss / val_total
        val_acc = val_correct / val_total

        # Save best model
        if val_loss_avg < val_loss_min:
            val_loss_min = val_loss_avg
            os.makedirs(os.path.dirname(save_path), exist_ok=True)
            torch.save(model.state_dict(), save_path)

        # Scheduler step
        if scheduler is not None:
            scheduler.step()

        current_lr = optimizer.param_groups[0]["lr"]
        print(
            f"Epoch {epoch+1}/{n_epochs} | "
            f"Train Loss: {train_loss_avg:.4f} | Train Acc: {train_acc:.4f} | "
            f"Val Loss: {val_loss_avg:.4f} | Val Acc: {val_acc:.4f} | LR: {current_lr:.6f}"
        )


def test_evaluate_classifier(model, testloader, device=None, criterion=None):
    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)

    if criterion is None:
        criterion = nn.CrossEntropyLoss()

    model.eval()
    test_loss = 0.0
    correct = 0
    total = 0

    with torch.no_grad():
        for batch_x, batch_y in testloader:
            batch_x = batch_x.to(device)
            batch_y = batch_y.to(device)

            y_hat = model(batch_x)
            loss = criterion(y_hat, batch_y)

            test_loss += loss.item() * batch_x.size(0)
            _, predicted = torch.max(y_hat, 1)
            correct += (predicted == batch_y).sum().item()
            total += batch_y.size(0)

    avg_loss = test_loss / total if total else 0.0
    avg_acc = correct / total if total else 0.0
    return {"test_loss": avg_loss, "test_accuracy": avg_acc}


def test_predict_classifier(model, testloader, device=None):
    if device is None:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)

    model.eval()
    predictions = []

    with torch.no_grad():
        for batch_x, _ in testloader:
            batch_x = batch_x.to(device)

            y_hat = model(batch_x)
            _, predicted = torch.max(y_hat, 1)
            predictions.extend(predicted.cpu().tolist())

    return {"predicted_indices": predictions}