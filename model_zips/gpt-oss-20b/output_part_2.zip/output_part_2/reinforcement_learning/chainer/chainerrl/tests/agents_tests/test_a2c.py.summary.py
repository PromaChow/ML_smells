import os
import tempfile
import pytest
import numpy as np
import gym
import chainer
import chainer.links as L
import chainer.functions as F
import chainerrl
from chainerrl import agents, policies, value_functions, optimizers
from chainerrl import train_agent_batch_with_evaluation, batch_run_evaluation_episodes
from chainerrl.environment import MultiprocessVectorEnv

class SimpleEnv(gym.Env):
    def __init__(self, deterministic=True, continuous=False):
        super().__init__()
        self.deterministic = deterministic
        self.continuous = continuous
        self.observation_space = gym.spaces.Box(
            low=-np.inf, high=np.inf, shape=(2,), dtype=np.float32
        )
        if continuous:
            self.action_space = gym.spaces.Box(
                low=-np.inf, high=np.inf, shape=(1,), dtype=np.float32
            )
        else:
            self.action_space = gym.spaces.Discrete(2)
        self.state = 0
        self.successful_return = 1.0

    def reset(self):
        self.state = 0
        return np.array([self.state, self.state], dtype=np.float32)

    def step(self, action):
        self.state += 1
        reward = 1.0 if self.state >= 10 else 0.0
        done = self.state >= 10
        return (
            np.array([self.state, self.state], dtype=np.float32),
            reward,
            done,
            {},
        )

@pytest.fixture
def tmpdir():
    return tempfile.mkdtemp()

@pytest.mark.parametrize("num_processes", [1, 3])
@pytest.mark.parametrize("use_gae", [True, False])
@pytest.mark.parametrize("discrete", [True, False])
@pytest.mark.parametrize("device", ["cpu", "gpu"])
@pytest.mark.parametrize("load_model", [False, True])
def test_a2c_parameterized(tmpdir, num_processes, use_gae, discrete, device, load_model):
    # Skip GPU tests if CUDA not available
    if device == "gpu" and not chainer.backends.cuda.available:
        pytest.skip("CUDA not available")

    # Environment factory
    def env_factory():
        return SimpleEnv(deterministic=True, continuous=not discrete)

    env = MultiprocessVectorEnv(
        [env_factory for _ in range(num_processes)],
        max_episode_steps=20,
    )

    obs_shape = env.observation_space.shape
    if discrete:
        n_actions = env.action_space.n
    else:
        n_actions = env.action_space.shape[0]

    # Build policy network
    hidden_size = 50
    pi_model = chainer.Sequential(
        L.Linear(obs_shape[0], hidden_size),
        F.relu,
        L.Linear(hidden_size, hidden_size),
        F.relu,
    )
    if discrete:
        pi_policy = policies.FCSoftmaxPolicy(pi_model, n_actions)
    else:
        pi_policy = policies.FCGaussianPolicy(pi_model, n_actions)

    # Build value network
    v_model = chainer.Sequential(
        L.Linear(obs_shape[0], hidden_size),
        F.relu,
        L.Linear(hidden_size, hidden_size),
        F.relu,
    )
    v_func = value_functions.FCVFunction(v_model, 1)

    # Optimizer
    optimizer = optimizers.Adam(alpha=3e-4)
    optimizer.setup(pi_model)
    optimizer.setup(v_model)

    # Move to device if GPU
    if device == "gpu":
        with chainer.backends.cuda.get_device_from_id(0):
            pi_model.to_gpu()
            v_model.to_gpu()
            optimizer.setup(pi_model)
            optimizer.setup(v_model)

    # Create agent
    agent = agents.A2C(
        pi_policy,
        v_func,
        optimizer,
        num_processes=num_processes,
        use_gae=use_gae,
        gamma=0.99,
    )

    steps = 100  # Use small number of steps for quick test
    eval_interval = 20
    eval_n_episodes = 50

    # Train agent
    train_agent_batch_with_evaluation(
        agent,
        env,
        steps=steps,
        eval_interval=eval_interval,
        eval_n_episodes=eval_n_episodes,
        agent_dirname=tmpdir,
    )

    # Optionally load and continue training
    if load_model:
        agent_loaded = agents.A2C(
            pi_policy,
            v_func,
            optimizer,
            num_processes=num_processes,
            use_gae=use_gae,
            gamma=0.99,
        )
        agent_loaded.load_agent(tmpdir)
        train_agent_batch_with_evaluation(
            agent_loaded,
            env,
            steps=steps,
            eval_interval=eval_interval,
            eval_n_episodes=eval_n_episodes,
            agent_dirname=tmpdir,
        )
        agent = agent_loaded

    # Final evaluation
    episode_returns = batch_run_evaluation_episodes(
        agent,
        env,
        n_episodes=100,
    )
    successes = sum(r >= env.successful_return for r in episode_returns)
    success_rate = successes / len(episode_returns)

    assert success_rate >= 0.8, (
        f"Success rate {success_rate:.2f} below threshold for "
        f"num_processes={num_processes}, use_gae={use_gae}, discrete={discrete}, "
        f"device={device}, load_model={load_model}"
    )
    # Save final agent
    agent.save_agent(tmpdir)