import unittest
import numpy as np
import chainer
import chainer.links as L
import chainer.functions as F
import chainer.cuda as cuda
from chainer import Variable
from chainer.links.recurrent.stateless import StatelessRecurrentSequential
from chainer.backends import cuda as cuda_backend


def rand_seq_list(batch_size, maxlen, in_size, seed=None):
    rng = np.random.default_rng(seed)
    seqs = []
    for _ in range(batch_size):
        slen = rng.integers(1, maxlen + 1)
        seq = rng.standard_normal((slen, in_size)).astype(np.float32)
        seqs.append(seq)
    return seqs


def manual_lstm_step(cell, h, c, x):
    W = cell.W.array
    U = cell.U.array
    b = cell.b.array
    gates = (x @ W.T) + (h @ U.T) + b
    i, f, o, g = np.split(gates, 4, axis=1)
    i = 1.0 / (1.0 + np.exp(-i))
    f = 1.0 / (1.0 + np.exp(-f))
    o = 1.0 / (1.0 + np.exp(-o))
    g = np.tanh(g)
    c_next = f * c + i * g
    h_next = o * np.tanh(c_next)
    return h_next, c_next


def manual_rnn_tanh_step(layer, h, x):
    w = layer.W.array
    u = layer.U.array
    b = layer.b.array
    y = x @ w.T + h @ u.T + b
    return np.tanh(y)


def manual_forward(lstm, rnn, seqs):
    maxlen = max(len(s) for s in seqs)
    batch = len(seqs)
    h_lstm = np.zeros((batch, lstm.hiddensize), dtype=np.float32)
    c_lstm = np.zeros((batch, lstm.hiddensize), dtype=np.float32)
    h_rnn = np.zeros((batch, rnn.hiddensize), dtype=np.float32)

    outputs = []
    for t in range(maxlen):
        x_t = np.stack([s[t] if t < len(s) else np.zeros_like(s[0]) for s in seqs], axis=0)
        h_lstm, c_lstm = manual_lstm_step(lstm, h_lstm, c_lstm, x_t)
        h_rnn = manual_rnn_tanh_step(rnn, h_rnn, h_lstm)
        if t < maxlen - 1:
            outputs.append(h_rnn.copy())
    return np.concatenate(outputs, axis=0)


class TestStatelessRecurrentSequential(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.in_size = 10
        cls.hidden_size_lstm = 20
        cls.hidden_size_rnn = 30
        cls.out_size = 5
        cls.batch_size = 4
        cls.maxlen = 6
        cls.linear1 = L.Linear(None, cls.hidden_size_lstm)
        cls.lstm = L.NStepLSTM(1, cls.hidden_size_lstm, cls.hidden_size_lstm, 0.1)
        cls.rnn = L.NStepRNNTanh(cls.hidden_size_lstm, cls.hidden_size_rnn, cls.hidden_size_rnn, 0.1)
        cls.linear2 = L.Linear(None, cls.out_size)
        cls.model = StatelessRecurrentSequential(
            cls.linear1, cls.lstm, cls.rnn, cls.linear2
        )
        cls.use_gpu = cuda_backend.has_cuda

        if cls.use_gpu:
            cuda.get_device_from_id(0).use()
            cls.model.to_gpu()

    def setUp(self):
        self.seqs_x = rand_seq_list(self.batch_size, self.maxlen, self.in_size, seed=42)
        self.seq_vars = [Variable(s) for s in self.seqs_x]

    def test_forward_concat(self):
        outputs = self.model.n_step_forward(self.seq_vars, output_mode='concat')
        self.assertIsInstance(outputs, Variable)
        expected_len = sum(len(s) for s in self.seqs_x)
        self.assertEqual(outputs.shape[0], expected_len)
        self.assertEqual(outputs.shape[1], self.out_size)

    def test_forward_split(self):
        outputs = self.model.n_step_forward(self.seq_vars, output_mode='split')
        self.assertIsInstance(outputs, list)
        self.assertEqual(len(outputs), self.batch_size)
        total = 0
        for out, seq in zip(outputs, self.seqs_x):
            self.assertEqual(out.shape[0], len(seq))
            self.assertEqual(out.shape[1], self.out_size)
            total += len(seq)
        self.assertEqual(total, sum(len(s) for s in self.seqs_x))

    def test_concat_vs_split(self):
        concat_out = self.model.n_step_forward(self.seq_vars, output_mode='concat').array
        split_out = self.model.n_step_forward(self.seq_vars, output_mode='split')
        concat_from_split = np.concatenate([x.array for x in split_out], axis=0)
        np.testing.assert_allclose(concat_out, concat_from_split, atol=1e-5)

    def test_manual_vs_model(self):
        manual_out = manual_forward(self.lstm, self.rnn, self.seqs_x)
        model_out = self.model.n_step_forward(self.seq_vars, output_mode='concat').array
        np.testing.assert_allclose(manual_out, model_out, atol=1e-5)

    def test_gradient_consistency(self):
        # Model gradient
        for p in self.model.params():
            p.cleargrad()
        loss = self.model.n_step_forward(self.seq_vars, output_mode='concat').sum()
        loss.backward()
        grad_model = self.model.linear1.W.grad.copy()

        # Manual gradient
        self.model.to_cpu()
        for p in self.model.params():
            p.cleargrad()
        seqs_cpu = [s.astype(np.float32) for s in self.seqs_x]
        seq_vars_cpu = [Variable(s) for s in seqs_cpu]
        loss_cpu = self.model.n_step_forward(seq_vars_cpu, output_mode='concat').sum()
        loss_cpu.backward()
        grad_manual = self.model.linear1.W.grad.copy()
        np.testing.assert_allclose(grad_model, grad_manual, atol=1e-5)

    def test_tuple_input(self):
        # Input each sample as tuple of two tensors (dummy)
        tuple_seqs = [np.concatenate([s, np.zeros_like(s)], axis=1) for s in self.seqs_x]
        tuple_vars = [Variable(s) for s in tuple_seqs]
        outputs = self.model.n_step_forward(tuple_vars, output_mode='concat')
        self.assertEqual(outputs.shape[1], self.out_size)

    def test_tuple_output_split(self):
        def split_output(x):
            return [x[:, :self.out_size // 2], x[:, self.out_size // 2:]]

        self.model.split_output = split_output
        outputs = self.model.n_step_forward(self.seq_vars, output_mode='split')
        self.assertIsInstance(outputs, list)
        for out in outputs:
            self.assertEqual(out.shape[1], self.out_size // 2)

    def test_masking_states(self):
        # Mask: zero out second time step in all sequences
        mask = np.ones((self.batch_size, self.maxlen), dtype=np.float32)
        mask[:, 1] = 0
        # NStepLSTM expects mask list of 1-D arrays
        mask_list = [mask[i] for i in range(self.batch_size)]
        outputs = self.model.n_step_forward(self.seq_vars, mask=mask_list, output_mode='concat')
        self.assertIsInstance(outputs, Variable)

    def test_multiple_recurrent_layers(self):
        # Build model with two LSTM layers
        lstm2 = L.NStepLSTM(1, self.hidden_size_lstm, self.hidden_size_lstm, 0.1)
        model_multi = StatelessRecurrentSequential(
            self.linear1, self.lstm, lstm2, self.rnn, self.linear2
        )
        if self.use_gpu:
            model_multi.to_gpu()
        outputs = model_multi.n_step_forward(self.seq_vars, output_mode='concat')
        self.assertEqual(outputs.shape[1], self.out_size)

    def test_cpu_gpu_consistency(self):
        # Run on CPU
        cpu_model = StatelessRecurrentSequential(
            self.linear1, self.lstm, self.rnn, self.linear2
        )
        cpu_out = cpu_model.n_step_forward(self.seq_vars, output_mode='concat').array
        # Run on GPU
        gpu_model = StatelessRecurrentSequential(
            self.linear1, self.lstm, self.rnn, self.linear2
        )
        if self.use_gpu:
            gpu_model.to_gpu()
            gpu_vars = [v.to_gpu() for v in self.seq_vars]
            gpu_out = gpu_model.n_step_forward(gpu_vars, output_mode='concat').array
            gpu_out = gpu_out.astype(np.float32)
            np.testing.assert_allclose(cpu_out, gpu_out, atol=1e-5)
        else:
            self.assertTrue(True)


if __name__ == '__main__':
    unittest.main()
