import numpy as np
import pandas as pd

class KMeans:
    def __init__(self, k=4):
        self.k = k
        self.centers = None

    def fit(self, X):
        X = np.asarray(X, dtype=np.float64)
        n_samples, n_features = X.shape
        rng = np.random.default_rng()
        init_idx = rng.choice(n_samples, size=self.k, replace=False)
        self.centers = X[init_idx].copy()

        while True:
            distances = np.linalg.norm(X[:, np.newaxis, :] - self.centers[np.newaxis, :, :], axis=2)
            labels = np.argmin(distances, axis=1)

            new_centers = np.empty_like(self.centers)
            for i in range(self.k):
                cluster_points = X[labels == i]
                if cluster_points.size == 0:
                    new_centers[i] = self.centers[i]
                else:
                    new_centers[i] = cluster_points.mean(axis=0)

            avg_dev = np.mean(np.linalg.norm(new_centers - self.centers, axis=1))
            self.centers = new_centers
            if avg_dev < 1e-10:
                break

    def predict(self, X):
        X = np.asarray(X, dtype=np.float64)
        distances = np.linalg.norm(X[:, np.newaxis, :] - self.centers[np.newaxis, :, :], axis=2)
        return np.argmin(distances, axis=1)

if __name__ == "__main__":
    df = pd.read_csv("data/iris.data.txt", header=None, names=['x1', 'x2', 'x3', 'x4', 'y'])
    mapping = {'Iris-setosa': 0, 'Iris-versicolor': 1, 'Iris-virginica': 2}
    df['y'] = df['y'].map(mapping)
    X = df.drop(columns=['y']).values
    model = KMeans(k=4)
    model.fit(X)
    labels = model.predict(X)
    print(labels.tolist())