import os
import time
import tempfile
from typing import Any, Dict, Iterable, List, Tuple, Union

import numpy as np
import torch
from torch.utils.data import IterableDataset
import pytorch_lightning as pl
from PIL import Image
import imageio


def determine_precision(models: List[pl.LightningModule]) -> torch.dtype:
    """Determine the precision (dtype) used by all models."""
    dtypes = {next(m.parameters()).dtype for m in models}
    if len(dtypes) > 1:
        raise ValueError(f"Multiple precisions detected: {dtypes}")
    return dtypes.pop()


def get_loggers_as_list(module: pl.LightningModule) -> List[Any]:
    """Return a list of loggers from a LightningModule."""
    logger = module.logger
    if isinstance(logger, (list, tuple)):
        return list(logger)
    return [logger] if logger is not None else []


def log_image(module: pl.LightningModule, name: str, image: np.ndarray) -> None:
    """Log a NumPy image array to all loggers that support log_image."""
    loggers = get_loggers_as_list(module)
    pil_img = Image.fromarray(image)
    for logger in loggers:
        log_fn = getattr(logger, "log_image", None)
        if callable(log_fn):
            log_fn(name, image=pil_img)


def create_video(frames: List[np.ndarray], gif_path: str, fps: int = 10) -> None:
    """Create a GIF from a list of NumPy frames."""
    # Convert frames to uint8 if necessary
    frames_uint8 = [
        (frame * 255).astype(np.uint8) if frame.dtype == np.float32 else frame.astype(np.uint8)
        for frame in frames
    ]
    imageio.mimsave(gif_path, frames_uint8, fps=fps)


def log_video(module: pl.LightningModule, name: str, video_frames: List[np.ndarray]) -> None:
    """Log a GIF created from video frames to loggers that support artifacts."""
    loggers = get_loggers_as_list(module)
    with tempfile.NamedTemporaryFile(suffix=".gif", delete=False) as tmp:
        gif_path = tmp.name
    create_video(video_frames, gif_path)

    # Wait until file size stabilizes
    prev_size = -1
    while True:
        size = os.path.getsize(gif_path)
        if size == prev_size:
            break
        prev_size = size
        time.sleep(0.1)

    for logger in loggers:
        log_artifact = getattr(logger, "log_artifact", None)
        if callable(log_artifact):
            log_artifact(gif_path, name=name)

    os.remove(gif_path)


class DatasetResult:
    """Container for observations and scalar logs."""

    def __init__(self) -> None:
        self.observations: List[Dict[str, Any]] = []
        self.logs: Dict[str, Union[float, Tuple[float, float]]] = {}

    def append_observation(self, observation: Dict[str, Any]) -> None:
        self.observations.append(observation)

    def log(self, key: str, value: Union[float, Tuple[float, float]]) -> None:
        self.logs[key] = value

    def __len__(self) -> int:
        return len(self.observations)


class RLDataset(IterableDataset):
    """Placeholder for a reinforcement learning dataset."""

    def __iter__(self) -> "RLDataset":
        return self

    def __next__(self) -> Any:
        raise StopIteration
