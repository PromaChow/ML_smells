import torch
import torch.nn.functional as F
from torchvision import transforms as T
import torchvision.transforms.functional as TF
from PIL import Image


class ReduceChannelwithNormalize(torch.nn.Module):
    def __init__(self, mean, scale, zca=False):
        super().__init__()
        self.mean = torch.tensor(mean, dtype=torch.float32).view(3, 1, 1)
        self.scale = torch.tensor(scale, dtype=torch.float32).view(3, 1, 1)
        self.zca = zca

    def forward(self, img: torch.Tensor) -> torch.Tensor:
        rgb = img[:3]            # (3, H, W)
        alpha = img[3]           # (H, W)
        mask = alpha == 0        # (H, W)
        if self.zca:
            rgb = (rgb - self.mean.to(rgb.device)) / self.scale.to(rgb.device)
        else:
            rgb = TF.normalize(
                rgb,
                mean=self.mean.squeeze().to(rgb.device),
                std=self.scale.squeeze().to(rgb.device),
            )
        rgb[:, mask] = 0
        return rgb


class RGB2RGBA:
    def __call__(self, img: Image.Image) -> Image.Image:
        return img.convert("RGBA")


class GaussianNoise:
    def __init__(self, mean: float = 0.0, std: float = 0.1):
        self.mean = mean
        self.std = std

    def __call__(self, tensor: torch.Tensor) -> torch.Tensor:
        noise = torch.randn_like(tensor) * self.std + self.mean
        return tensor + noise


class Cutout:
    def __init__(self, size: int = 16):
        self.size = size

    def __call__(self, tensor: torch.Tensor) -> torch.Tensor:
        _, h, w = tensor.shape
        if h < self.size or w < self.size:
            return tensor
        top = torch.randint(0, h - self.size + 1, (1,)).item()
        left = torch.randint(0, w - self.size + 1, (1,)).item()
        tensor[:, top : top + self.size, left : left + self.size] = 0
        return tensor


class StrongAugmentation:
    def __init__(
        self,
        img_size: int,
        mean: list,
        scale: list,
        flip: bool = True,
        crop: bool = True,
        alg: str = "fixmatch",
        zca: bool = False,
        cutout: bool = True,
    ):
        padding = img_size // 8
        rand_aug = T.RandAugment(num_layers=2, magnitude=9)
        pipeline = [
            T.ToPILImage(),
            T.RandomHorizontalFlip(p=0.5) if flip else T.Lambda(lambda x: x),
            T.RandomCrop(img_size, padding=padding) if crop else T.Lambda(lambda x: x),
            RGB2RGBA(),
            rand_aug if alg else T.Lambda(lambda x: x),
            T.ToTensor(),
            ReduceChannelwithNormalize(mean, scale, zca),
            Cutout(16) if cutout else T.Lambda(lambda x: x),
        ]
        self.transform = T.Compose(pipeline)

    def __call__(self, img: torch.Tensor) -> torch.Tensor:
        return self.transform(img)


class WeakAugmentation:
    def __init__(
        self,
        img_size: int,
        mean: list,
        scale: list,
        flip: bool = True,
        crop: bool = True,
        noise: bool = False,
        zca: bool = False,
    ):
        padding = img_size // 8
        pipeline = [
            T.ToPILImage(),
            T.RandomHorizontalFlip(p=0.5) if flip else T.Lambda(lambda x: x),
            T.RandomCrop(img_size, padding=padding) if crop else T.Lambda(lambda x: x),
            T.ToTensor(),
            ReduceChannelwithNormalize(mean, scale, zca),
            GaussianNoise(0.0, 0.1) if noise else T.Lambda(lambda x: x),
        ]
        self.transform = T.Compose(pipeline)

    def __call__(self, img: torch.Tensor) -> torch.Tensor:
        return self.transform(img)