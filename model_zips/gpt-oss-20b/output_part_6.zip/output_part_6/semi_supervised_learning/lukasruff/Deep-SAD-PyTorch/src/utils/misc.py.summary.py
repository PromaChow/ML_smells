import torch
from torch.autograd import Variable

def enumerate_discrete(x, y_dim):
    def batch(batch_size, label):
        # Create a tensor filled with the label
        label_tensor = torch.full((batch_size, 1), label, dtype=torch.long, device=x.device)
        # Initialize zero tensor for one-hot encoding
        one_hot = torch.zeros(batch_size, y_dim, dtype=torch.long, device=x.device)
        # Scatter to set the correct column to 1
        one_hot.scatter_(1, label_tensor, 1)
        return one_hot

    batch_size = x.size(0)
    batches = [batch(batch_size, i) for i in range(y_dim)]
    result = torch.cat(batches, dim=0)

    # Ensure the tensor is on the same device as input
    if x.is_cuda:
        result = result.to(x.device)

    # Wrap as Variable with float dtype
    return Variable(result.float(), requires_grad=False)

def log_sum_exp(tensor, dim=-1, sum_op=torch.sum):
    max_vals, _ = torch.max(tensor, dim=dim, keepdim=True)
    adjusted = tensor - max_vals
    exp_adj = torch.exp(adjusted)
    sum_exp = sum_op(exp_adj, dim=dim, keepdim=True) + 1e-8
    log_sum = torch.log(sum_exp)
    result = log_sum + max_vals
    return result.squeeze(dim)

def binary_cross_entropy(x, y):
    eps = 1e-8
    x_clamped = x.clamp(min=eps, max=1 - eps)
    loss = -(y * torch.log(x_clamped) + (1 - y) * torch.log(1 - x_clamped))
    return loss.sum(dim=-1)