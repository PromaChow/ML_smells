import numpy as np
import gymnasium as gym
from gymnasium import spaces
from typing import Callable, List, Tuple, Dict, Any, Optional

class MultiAgentEnv:
    def __init__(
        self,
        world,
        reset_callback: Callable[[Any], None],
        reward_callback: Callable[[Any, List[Any]], float],
        observation_callback: Callable[[Any, Any], np.ndarray],
        info_callback: Callable[[Any, List[Any]], Dict],
        done_callback: Callable[[Any, List[Any]], bool],
        action_type: str = "continuous",  # or "discrete"
        shared_reward: bool = False,
        render_mode: Optional[str] = None,
    ):
        self.world = world
        self.reset_callback = reset_callback
        self.reward_callback = reward_callback
        self.observation_callback = observation_callback
        self.info_callback = info_callback
        self.done_callback = done_callback
        self.shared_reward = shared_reward
        self.render_mode = render_mode

        self.agents = self.world.agents
        self.n_agents = len(self.agents)

        # Determine action space for each agent
        self.action_spaces = []
        for agent in self.agents:
            if action_type == "discrete":
                # Example: movement in 3 directions + communication bits
                moves = 3 if agent.movable else 0
                comms = agent.comm_channels if getattr(agent, "communicative", False) else 0
                self.action_spaces.append(spaces.MultiDiscrete([moves, comms]))
            else:
                moves = 3 if agent.movable else 0
                comms = agent.comm_channels if getattr(agent, "communicative", False) else 0
                low = np.concatenate([np.full(moves, -agent.sensitivity), np.full(comms, -agent.comm_sensitivity)])
                high = np.concatenate([np.full(moves, agent.sensitivity), np.full(comms, agent.comm_sensitivity)])
                self.action_spaces.append(spaces.Box(low=low, high=high, dtype=np.float32))

        # Determine observation space for each agent
        self.observation_spaces = []
        dummy_obs = self.observation_callback(self.world, self.agents[0])
        obs_shape = dummy_obs.shape
        self.observation_spaces = [spaces.Box(low=-np.inf, high=np.inf, shape=obs_shape, dtype=np.float32)
                                   for _ in self.agents]

    def step(self, actions: List[np.ndarray]) -> Tuple[List[np.ndarray], List[float], List[bool], List[Dict]]:
        # Apply actions to world
        for agent, action in zip(self.agents, actions):
            self._set_action(agent, action)

        # Advance the world simulation
        self.world.step()

        # Gather observations, rewards, dones, infos
        observations = []
        rewards = []
        dones = []
        infos = []

        for agent in self.agents:
            observations.append(self._get_obs(agent))
            rewards.append(self._get_reward(agent))
            dones.append(self._get_done(agent))
            infos.append(self._get_info(agent))

        # Aggregate shared reward if enabled
        if self.shared_reward:
            shared = sum(rewards) / len(rewards)
            rewards = [shared for _ in rewards]

        return observations, rewards, dones, infos

    def reset(self) -> List[np.ndarray]:
        self.reset_callback(self.world)
        return [self._get_obs(agent) for agent in self.agents]

    def _set_action(self, agent, action: np.ndarray):
        if isinstance(agent.action_space, spaces.MultiDiscrete):
            # Discrete actions: first component movement, second communication
            move = action[0]
            comm = action[1]
            agent.action_physical = move
            agent.action_comm = comm
        else:
            # Continuous actions: first part movement, second communication
            dim_move = 3 if agent.movable else 0
            dim_comm = agent.comm_channels if getattr(agent, "communicative", False) else 0
            move = action[:dim_move] * agent.sensitivity
            comm = action[dim_move:dim_move+dim_comm] * agent.comm_sensitivity
            agent.action_physical = move
            agent.action_comm = comm

    def _get_obs(self, agent) -> np.ndarray:
        return self.observation_callback(self.world, agent)

    def _get_reward(self, agent) -> float:
        return self.reward_callback(self.world, self.agents)

    def _get_done(self, agent) -> bool:
        return self.done_callback(self.world, self.agents)

    def _get_info(self, agent) -> Dict:
        return self.info_callback(self.world, self.agents)

    def render(self):
        if self.render_mode == "human":
            for agent in self.agents:
                if hasattr(agent, "comm_buffer"):
                    print(f"Agent {agent.id} messages: {agent.comm_buffer}")
        elif self.render_mode == "rgb_array":
            # Placeholder for actual rendering logic
            return np.zeros((self.world.height, self.world.width, 3), dtype=np.uint8)

class BatchMultiAgentEnv:
    def __init__(self, envs: List[MultiAgentEnv]):
        self.envs = envs
        self.n_envs = len(envs)

    def step(self, actions: List[List[np.ndarray]]) -> Tuple[List[List[np.ndarray]], List[List[float]], List[List[bool]], List[List[Dict]]]:
        all_obs, all_rewards, all_dones, all_infos = [], [], [], []
        for env, env_actions in zip(self.envs, actions):
            obs, rew, don, inf = env.step(env_actions)
            all_obs.append(obs)
            all_rewards.append(rew)
            all_dones.append(don)
            all_infos.append(inf)
        return all_obs, all_rewards, all_dones, all_infos

    def reset(self) -> List[List[np.ndarray]]:
        all_obs = []
        for env in self.envs:
            all_obs.append(env.reset())
        return all_obs

    def render(self):
        for env in self.envs:
            env.render()
```