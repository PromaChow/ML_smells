import multiprocessing
import time


class Batch_Loader(multiprocessing.Process):
    def __init__(self, main_queue, queue_for_dataset, batch_size, batch_length, debug=False):
        super().__init__()
        self.main_queue = main_queue
        self.queue_for_dataset = queue_for_dataset
        self.batch_size = batch_size
        self.batch_length = batch_length
        self.debug = debug
        self.batch_dataset = [[] for _ in range(batch_length)]
        self.batch_start_time = None

    def run(self):
        while True:
            dataset = self.queue_for_dataset.get()
            if len(dataset) != self.batch_length:
                continue  # ignore malformed dataset
            if self.batch_start_time is None:
                self.batch_start_time = time.time()
            for i, item in enumerate(dataset):
                self.batch_dataset[i].append(item)
            if len(self.batch_dataset[0]) >= self.batch_size:
                if self.debug:
                    elapsed = time.time() - self.batch_start_time
                    print(f"Batch loaded in {elapsed:.4f} seconds")
                self.main_queue.put(self.batch_dataset)
                self.batch_dataset = [[] for _ in range(self.batch_length)]
                self.batch_start_time = None

# Example usage (optional)
if __name__ == "__main__":
    main_q = multiprocessing.Queue()
    dataset_q = multiprocessing.Queue()
    loader = Batch_Loader(main_q, dataset_q, batch_size=5, batch_length=3, debug=True)
    loader.start()
    # Send dummy data
    for _ in range(15):
        dataset_q.put([f"item{_}-0", f"item{_}-1", f"item{_}-2"])
    # Retrieve batches
    for _ in range(3):
        batch = main_q.get()
        print("Received batch:", batch)
    loader.terminate()
    loader.join()
