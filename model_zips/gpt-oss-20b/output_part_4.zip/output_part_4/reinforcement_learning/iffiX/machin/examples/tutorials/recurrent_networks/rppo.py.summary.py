import gym
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from collections import deque

# Utility function (identity placeholder)
def convert(state):
    return state

# Disable rendering window (placeholder)
def disable_view_window():
    pass

# Actor network with GRU
class RecurrentActor(nn.Module):
    def __init__(self, input_dim, hidden_dim, action_num):
        super(RecurrentActor, self).__init__()
        self.gru = nn.GRU(input_dim, hidden_dim, batch_first=True)
        self.fc1 = nn.Linear(hidden_dim, 256)
        self.fc2 = nn.Linear(256, 256)
        self.out = nn.Linear(256, action_num)
        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x, h):
        # x shape: (batch, seq_len, input_dim)
        out, h = self.gru(x, h)
        out = self.fc1(out)
        out = torch.relu(out)
        out = self.fc2(out)
        out = torch.relu(out)
        logits = self.out(out)
        probs = self.softmax(logits)
        dist = torch.distributions.Categorical(probs)
        log_probs = dist.log_prob(torch.argmax(probs, dim=-1))
        entropy = dist.entropy()
        return log_probs, entropy, h

# Critic network
class Critic(nn.Module):
    def __init__(self, input_dim):
        super(Critic, self).__init__()
        self.fc1 = nn.Linear(input_dim, 128)
        self.fc2 = nn.Linear(128, 256)
        self.fc3 = nn.Linear(256, 256)
        self.out = nn.Linear(256, 1)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = torch.relu(self.fc3(x))
        value = self.out(x)
        return value

# PPO implementation
class PPO:
    def __init__(self, actor, critic, actor_lr=1e-5, critic_lr=1e-4, gamma=0.99, clip_eps=0.2):
        self.actor = actor
        self.critic = critic
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=actor_lr)
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=critic_lr)
        self.gamma = gamma
        self.clip_eps = clip_eps
        self.buffer = []

    def store_episode(self, episode):
        self.buffer.append(episode)

    def compute_returns_and_advantages(self, episode):
        rewards = episode['rewards']
        values = episode['values']
        dones = episode['dones']
        returns = []
        advantages = []
        G = 0
        for r, done in zip(reversed(rewards), reversed(dones)):
            if done:
                G = 0
            G = r + self.gamma * G
            returns.insert(0, G)
        returns = torch.tensor(returns, dtype=torch.float32, device=episode['states'].device)
        values = torch.tensor(values, dtype=torch.float32, device=episode['states'].device)
        advantages = returns - values
        return returns, advantages

    def update(self):
        for episode in self.buffer:
            states = episode['states']
            actions = episode['actions']
            log_probs_old = episode['log_probs']
            values = episode['values']
            rewards = episode['rewards']
            dones = episode['dones']

            returns, advantages = self.compute_returns_and_advantages(episode)

            # Actor loss
            logits, entropy, _ = self.actor(states.unsqueeze(0), episode['hidden_states'])
            dist = torch.distributions.Categorical(logits)
            log_probs_new = dist.log_prob(actions)
            ratio = torch.exp(log_probs_new - log_probs_old)
            surr1 = ratio * advantages
            surr2 = torch.clamp(ratio, 1.0 - self.clip_eps, 1.0 + self.clip_eps) * advantages
            actor_loss = -torch.min(surr1, surr2).mean() - 0.01 * entropy.mean()

            self.actor_optimizer.zero_grad()
            actor_loss.backward()
            self.actor_optimizer.step()

            # Critic loss
            value_pred = self.critic(states).squeeze(-1)
            critic_loss = nn.functional.mse_loss(value_pred, returns)

            self.critic_optimizer.zero_grad()
            critic_loss.backward()
            self.critic_optimizer.step()

        self.buffer = []

# Main training loop
def main():
    env = gym.make("Frostbite-ram-v0")
    disable_view_window()
    action_num = env.action_space.n
    obs_dim = env.observation_space.shape[0]

    actor = RecurrentActor(obs_dim, 256, action_num).cuda()
    critic = Critic(obs_dim).cuda()
    ppo = PPO(actor, critic)

    max_episodes = 20000
    smoothed_reward = 0.0

    for episode_idx in range(1, max_episodes + 1):
        state = env.reset()
        state = convert(state)
        state_tensor = torch.tensor(state, dtype=torch.float32, device='cuda').unsqueeze(0).unsqueeze(0)  # (batch, seq, dim)
        hidden = torch.zeros(1, 1, 256, device='cuda')  # (num_layers, batch, hidden_dim)
        episode_data = {
            'states': [],
            'actions': [],
            'log_probs': [],
            'rewards': [],
            'dones': [],
            'values': [],
            'hidden_states': hidden
        }
        done = False
        episode_reward = 0.0

        while not done:
            with torch.no_grad():
                log_prob, entropy, hidden = actor(state_tensor, hidden)
                action = torch.argmax(log_prob).item()
                value = critic(state_tensor.squeeze(0)).item()

            next_state, reward, done, _ = env.step(action)
            next_state = convert(next_state)
            next_state_tensor = torch.tensor(next_state, dtype=torch.float32, device='cuda').unsqueeze(0).unsqueeze(0)

            episode_data['states'].append(state_tensor.squeeze(0))
            episode_data['actions'].append(torch.tensor(action, dtype=torch.long, device='cuda'))
            episode_data['log_probs'].append(log_prob.squeeze(0))
            episode_data['rewards'].append(reward)
            episode_data['dones'].append(done)
            episode_data['values'].append(value)

            state_tensor = next_state_tensor
            episode_reward += reward

        # Convert lists to tensors
        episode_data['states'] = torch.stack(episode_data['states'])
        episode_data['actions'] = torch.stack(episode_data['actions'])
        episode_data['log_probs'] = torch.stack(episode_data['log_probs'])
        episode_data['values'] = torch.tensor(episode_data['values'], dtype=torch.float32, device='cuda')
        episode_data['rewards'] = episode_data['rewards']
        episode_data['dones'] = episode_data['dones']

        ppo.store_episode(episode_data)
        ppo.update()

        smoothed_reward = 0.9 * smoothed_reward + 0.1 * episode_reward
        print(f"Episode {episode_idx}\tReward: {episode_reward:.2f}\tSmoothed: {smoothed_reward:.2f}")

if __name__ == "__main__":
    main()
