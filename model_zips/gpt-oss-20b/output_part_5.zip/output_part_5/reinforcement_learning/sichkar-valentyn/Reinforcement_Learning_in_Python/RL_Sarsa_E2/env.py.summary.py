import tkinter as tk
import random

class Environment(tk.Tk):
    def __init__(self, env_width=25, env_height=25, pixels=20):
        super().__init__()
        self.title("Grid Environment")
        self.env_width = env_width
        self.env_height = env_height
        self.pixels = pixels
        self.action_space = {0: "up", 1: "down", 2: "left", 3: "right"}

        self.canvas = tk.Canvas(self,
                                width=self.env_width * self.pixels,
                                height=self.env_height * self.pixels,
                                bg="white")
        self.canvas.pack()

        self.base_offset = [self.pixels / 2, self.pixels / 2]
        self.draw_grid()
        self.draw_background()
        self.place_obstacles()
        self.goal_coords = (self.pixels * 20 + self.pixels / 2,
                            self.pixels * 20 + self.pixels / 2)
        self.goal_rect = self.canvas.create_rectangle(
            self.goal_coords[0] - self.pixels / 2, self.goal_coords[1] - self.pixels / 2,
            self.goal_coords[0] + self.pixels / 2, self.goal_coords[1] + self.pixels / 2,
            fill="yellow", outline="black")

        start_x = self.pixels * 12 + self.pixels / 2
        start_y = self.pixels * 12 + self.pixels / 2
        self.agent_coords = (start_x, start_y)
        self.agent = self.canvas.create_oval(
            start_x - self.pixels / 2, start_y - self.pixels / 2,
            start_x + self.pixels / 2, start_y + self.pixels / 2,
            fill="red", outline="black")

        self.d = {}
        self.f = {}
        self.shortest = None
        self.longest = None
        self.step_count = 0

    def draw_grid(self):
        for i in range(self.env_width + 1):
            x = i * self.pixels
            self.canvas.create_line(x, 0, x, self.env_height * self.pixels, fill="grey")
        for i in range(self.env_height + 1):
            y = i * self.pixels
            self.canvas.create_line(0, y, self.env_width * self.pixels, y, fill="grey")

    def draw_background(self):
        # Placeholder: fill background with light blue
        self.canvas.create_rectangle(0, 0, self.env_width * self.pixels,
                                     self.env_height * self.pixels,
                                     fill="lightblue", outline="")

    def place_obstacles(self):
        self.obstacles = []
        # Place 50 obstacles in a pattern; avoid start and goal
        cols = 5
        rows = 10
        for i in range(cols):
            for j in range(rows):
                if len(self.obstacles) >= 50:
                    break
                col = i * 4 + 2
                row = j * 2 + 1
                if (col == 12 and row == 12) or (col == 20 and row == 20):
                    continue
                x = self.base_offset[0] + col * self.pixels
                y = self.base_offset[1] + row * self.pixels
                rect = self.canvas.create_rectangle(
                    x - self.pixels / 2, y - self.pixels / 2,
                    x + self.pixels / 2, y + self.pixels / 2,
                    fill="black")
                self.obstacles.append((x, y))
                setattr(self, f"coords_obstacle{len(self.obstacles)}", (x, y))

    def reset(self):
        self.canvas.delete(self.agent)
        start_x = self.pixels * 12 + self.pixels / 2
        start_y = self.pixels * 12 + self.pixels / 2
        self.agent_coords = (start_x, start_y)
        self.agent = self.canvas.create_oval(
            start_x - self.pixels / 2, start_y - self.pixels / 2,
            start_x + self.pixels / 2, start_y + self.pixels / 2,
            fill="red", outline="black")
        self.d.clear()
        self.f.clear()
        self.step_count = 0
        return self.agent_coords

    def step(self, action):
        dx, dy = 0, 0
        if action == 0:   # up
            dy = -self.pixels
        elif action == 1:  # down
            dy = self.pixels
        elif action == 2:  # left
            dx = -self.pixels
        elif action == 3:  # right
            dx = self.pixels

        new_x = self.agent_coords[0] + dx
        new_y = self.agent_coords[1] + dy

        # boundary check
        if not (self.pixels / 2 <= new_x <= self.env_width * self.pixels - self.pixels / 2 and
                self.pixels / 2 <= new_y <= self.env_height * self.pixels - self.pixels / 2):
            new_x, new_y = self.agent_coords  # no movement if out of bounds

        self.agent_coords = (new_x, new_y)
        self.canvas.move(self.agent,
                         new_x - self.agent_coords[0],
                         new_y - self.agent_coords[1])
        self.step_count += 1
        self.d[self.step_count] = self.agent_coords

        # collision with goal
        if (abs(new_x - self.goal_coords[0]) < self.pixels / 2 and
                abs(new_y - self.goal_coords[1]) < self.pixels / 2):
            reward = 1
            done = True
            observation = self.agent_coords
            self.update_shortest_longest()
            return observation, reward, done, {}

        # collision with obstacles
        for ox, oy in self.obstacles:
            if (abs(new_x - ox) < self.pixels / 2 and
                    abs(new_y - oy) < self.pixels / 2):
                reward = -1
                done = True
                observation = self.agent_coords
                self.update_shortest_longest()
                return observation, reward, done, {}

        reward = 0
        done = False
        observation = self.agent_coords
        return observation, reward, done, {}

    def update_shortest_longest(self):
        if self.shortest is None or len(self.d) < self.shortest:
            self.shortest = len(self.d)
        if self.longest is None or len(self.d) > self.longest:
            self.longest = len(self.d)

    def render(self):
        self.update_idletasks()
        self.update()

    def final(self):
        # Draw shortest path
        for idx, pos in self.d.items():
            self.canvas.create_oval(
                pos[0] - self.pixels / 4, pos[1] - self.pixels / 4,
                pos[0] + self.pixels / 4, pos[1] + self.pixels / 4,
                fill="blue", outline="")

        # Store final path in global dictionary 'a'
        global a
        a = {i: pos for i, pos in self.d.items()}
        self.update_idletasks()
        self.update()

def main():
    env = Environment()
    observation = env.reset()
    done = False
    while not done:
        action = random.choice(list(env.action_space.keys()))
        observation, reward, done, info = env.step(action)
        env.render()
    env.final()
    env.mainloop()

if __name__ == "__main__":
    main()