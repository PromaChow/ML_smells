import argparse
import logging
import os
import sys
import time
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import gym
from collections import deque, namedtuple
from torch.nn.init import lecun_uniform_
from torch.autograd import Variable
from torchviz import make_dot

# --------------------------------------------------------------------------- #
# Utility functions and classes
# --------------------------------------------------------------------------- #

def set_random_seed(seed, device='cpu'):
    np.random.seed(seed)
    torch.manual_seed(seed)
    if device != 'cpu' and torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

def download_model(name):
    # Placeholder: in practice this would download a pretrained model
    raise NotImplementedError("download_model not implemented")

def draw_computational_graph(model, outdir, name):
    dummy_input = torch.zeros(1, *model.input_shape)
    y = model(dummy_input)
    dot = make_dot(y, params=dict(model.named_parameters()))
    dot.format = 'png'
    dot.render(os.path.join(outdir, name), cleanup=True)

class CastObservationToFloat32(gym.ObservationWrapper):
    def observation(self, observation):
        return observation.astype(np.float32)

class Monitor(gym.Wrapper):
    def __init__(self, env, directory=None, force=False, resume=False):
        super().__init__(env)
        self.directory = directory
        self.force = force
        self.resume = resume
        self.episode_rewards = []
        self.episode_lengths = []
        self.reset()

    def reset(self, **kwargs):
        obs = self.env.reset(**kwargs)
        self.current_reward = 0.0
        self.current_length = 0
        return obs

    def step(self, action):
        obs, reward, done, info = self.env.step(action)
        self.current_reward += reward
        self.current_length += 1
        if done:
            self.episode_rewards.append(self.current_reward)
            self.episode_lengths.append(self.current_length)
            # Persist to file
            if self.directory:
                os.makedirs(self.directory, exist_ok=True)
                with open(os.path.join(self.directory, 'monitor.csv'), 'a') as f:
                    f.write(f"{len(self.episode_rewards)},{self.current_reward},{self.current_length}\n")
        return obs, reward, done, info

# Replay buffer
Transition = namedtuple('Transition', ('state', 'action', 'reward', 'next_state', 'done'))

class ReplayBuffer:
    def __init__(self, capacity, state_dim, action_dim):
        self.capacity = capacity
        self.state_buf = np.zeros((capacity, state_dim), dtype=np.float32)
        self.action_buf = np.zeros((capacity, action_dim), dtype=np.float32)
        self.reward_buf = np.zeros((capacity, 1), dtype=np.float32)
        self.next_state_buf = np.zeros((capacity, state_dim), dtype=np.float32)
        self.done_buf = np.zeros((capacity, 1), dtype=np.float32)
        self.ptr = 0
        self.size = 0

    def push(self, transition):
        idx = self.ptr
        self.state_buf[idx] = transition.state
        self.action_buf[idx] = transition.action
        self.reward_buf[idx] = transition.reward
        self.next_state_buf[idx] = transition.next_state
        self.done_buf[idx] = transition.done
        self.ptr = (self.ptr + 1) % self.capacity
        self.size = min(self.size + 1, self.capacity)

    def sample(self, batch_size):
        idxs = np.random.randint(0, self.size, size=batch_size)
        batch = dict(
            state=torch.FloatTensor(self.state_buf[idxs]),
            action=torch.FloatTensor(self.action_buf[idxs]),
            reward=torch.FloatTensor(self.reward_buf[idxs]),
            next_state=torch.FloatTensor(self.next_state_buf[idxs]),
            done=torch.FloatTensor(self.done_buf[idxs]),
        )
        return batch

# --------------------------------------------------------------------------- #
# Neural networks
# --------------------------------------------------------------------------- #

class MLP(nn.Module):
    def __init__(self, input_dim, output_dim, hidden_sizes=(400, 300)):
        super().__init__()
        layers = []
        prev_size = input_dim
        for h in hidden_sizes:
            layers.append(nn.Linear(prev_size, h))
            layers.append(nn.ReLU())
            prev_size = h
        layers.append(nn.Linear(prev_size, output_dim))
        self.model = nn.Sequential(*layers)
        self.input_shape = (input_dim,)
        self._init_weights()

    def _init_weights(self):
        for m in self.model:
            if isinstance(m, nn.Linear):
                scale = 3 ** -0.5
                lecun_uniform_(m.weight, a=scale)
                if m.bias is not None:
                    m.bias.data.zero_()

    def forward(self, x):
        return self.model(x)

# --------------------------------------------------------------------------- #
# TD3 Agent
# --------------------------------------------------------------------------- #

class TD3Agent:
    def __init__(
        self,
        env,
        policy,
        q1,
        q2,
        policy_opt,
        q1_opt,
        q2_opt,
        replay_buffer,
        gamma=0.99,
        tau=5e-3,
        batch_size=100,
        policy_noise=0.2,
        noise_clip=0.5,
        policy_delay=2,
    ):
        self.env = env
        self.policy = policy
        self.q1 = q1
        self.q2 = q2
        self.target_policy = MLP(policy.input_shape[0], policy.model[-1].out_features)
        self.target_q1 = MLP(q1.input_shape[0], q1.model[-1].out_features)
        self.target_q2 = MLP(q2.input_shape[0], q2.model[-1].out_features)
        self._copy_weights(self.target_policy, self.policy)
        self._copy_weights(self.target_q1, self.q1)
        self._copy_weights(self.target_q2, self.q2)
        self.policy_opt = policy_opt
        self.q1_opt = q1_opt
        self.q2_opt = q2_opt
        self.replay_buffer = replay_buffer
        self.gamma = gamma
        self.tau = tau
        self.batch_size = batch_size
        self.policy_noise = policy_noise
        self.noise_clip = noise_clip
        self.policy_delay = policy_delay
        self.total_it = 0

    def _copy_weights(self, target, source):
        for t, s in zip(target.parameters(), source.parameters()):
            t.data.copy_(s.data)

    def select_action(self, state, noise=0.0):
        state = torch.FloatTensor(state).unsqueeze(0)
        action = self.policy(state).detach().cpu().numpy()[0]
        if noise != 0.0:
            noise_vec = np.clip(np.random.randn(*action.shape) * noise, -self.noise_clip, self.noise_clip)
            action = action + noise_vec
        return np.clip(action, -1.0, 1.0)

    def train(self, steps, eval_func=None, eval_interval=1000, eval_n_runs=10):
        state = self.env.reset()
        episode_reward = 0
        episode_step = 0
        all_rewards = []

        for t in range(steps):
            self.total_it += 1
            action = self.select_action(state, noise=0.1)
            next_state, reward, done, _ = self.env.step(action)
            transition = Transition(state, action, reward, next_state, float(done))
            self.replay_buffer.push(transition)

            state = next_state
            episode_reward += reward
            episode_step += 1

            if done:
                all_rewards.append(episode_reward)
                state = self.env.reset()
                episode_reward = 0
                episode_step = 0

            if self.replay_buffer.size >= self.replay_buffer.size:
                self._update_networks()

            if eval_func and (t + 1) % eval_interval == 0:
                eval_returns = eval_func()
                logging.info(f"Eval at step {t+1}: mean={np.mean(eval_returns):.2f} median={np.median(eval_returns):.2f} std={np.std(eval_returns):.2f}")

        return all_rewards

    def _update_networks(self):
        batch = self.replay_buffer.sample(self.batch_size)
        state = batch['state']
        action = batch['action']
        reward = batch['reward']
        next_state = batch['next_state']
        done = batch['done']

        with torch.no_grad():
            noise = (torch.randn_like(action) * self.policy_noise).clamp(-self.noise_clip, self.noise_clip)
            next_action = (self.target_policy(next_state) + noise).clamp(-1.0, 1.0)
            target_q1 = self.target_q1(torch.cat([next_state, next_action], dim=-1))
            target_q2 = self.target_q2(torch.cat([next_state, next_action], dim=-1))
            target_q = torch.min(target_q1, target_q2)
            target_q = reward + (1 - done) * self.gamma * target_q

        current_q1 = self.q1(torch.cat([state, action], dim=-1))
        current_q2 = self.q2(torch.cat([state, action], dim=-1))
        loss_q1 = nn.functional.mse_loss(current_q1, target_q)
        loss_q2 = nn.functional.mse_loss(current_q2, target_q)

        self.q1_opt.zero_grad()
        loss_q1.backward()
        self.q1_opt.step()

        self.q2_opt.zero_grad()
        loss_q2.backward()
        self.q2_opt.step()

        if self.total_it % self.policy_delay == 0:
            policy_loss = -self.q1(torch.cat([state, self.policy(state)], dim=-1)).mean()
            self.policy_opt.zero_grad()
            policy_loss.backward()
            self.policy_opt.step()

            for target_param, param in zip(self.target_q1.parameters(), self.q1.parameters()):
                target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)
            for target_param, param in zip(self.target_q2.parameters(), self.q2.parameters()):
                target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)
            for target_param, param in zip(self.target_policy.parameters(), self.policy.parameters()):
                target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)

# --------------------------------------------------------------------------- #
# Main script
# --------------------------------------------------------------------------- #

def make_env(env_name, seed, test=False, monitor_dir=None, render=False):
    env = gym.make(env_name)
    env.seed(seed)
    env.action_space.seed(seed)
    env = CastObservationToFloat32(env)
    if monitor_dir:
        env = Monitor(env, directory=monitor_dir)
    if render and not test:
        env.render()
    return env

def eval_policy(agent, n_runs, eval_env):
    returns = []
    for _ in range(n_runs):
        state = eval_env.reset()
        done = False
        ep_ret = 0.0
        while not done:
            action = agent.select_action(state, noise=0.0)
            state, reward, done, _ = eval_env.step(action)
            ep_ret += reward
        returns.append(ep_ret)
    return returns

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--outdir', default='results', help='Output directory')
    parser.add_argument('--env', default='HalfCheetah-v2')
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--gpu', default='0')
    parser.add_argument('--steps', type=int, default=1_000_000)
    parser.add_argument('--eval-n-runs', type=int, default=10)
    parser.add_argument('--eval-interval', type=int, default=10_000)
    parser.add_argument('--replay-start-size', type=int, default=10_000)
    parser.add_argument('--batch-size', type=int, default=100)
    parser.add_argument('--render', action='store_true')
    parser.add_argument('--demo', action='store_true')
    parser.add_argument('--load', default=None)
    parser.add_argument('--load-pretrained', action='store_true')
    parser.add_argument('--monitor', action='store_true')
    args = parser.parse_args()

    os.makedirs(args.outdir, exist_ok=True)
    logging.basicConfig(stream=sys.stdout, level=logging.INFO, format='%(asctime)s %(message)s')

    device = torch.device(f'cuda:{args.gpu}' if torch.cuda.is_available() else 'cpu')
    set_random_seed(args.seed, device)

    train_env = make_env(args.env, args.seed, monitor_dir=os.path.join(args.outdir, 'monitor') if args.monitor else None, render=args.render)
    eval_env = make_env(args.env, 2**32 - 1 - args.seed)

    obs_dim = train_env.observation_space.shape[0]
    act_dim = train_env.action_space.shape[0]
    act_low = train_env.action_space.low
    act_high = train_env.action_space.high

    policy = MLP(obs_dim, act_dim).to(device)
    q1 = MLP(obs_dim + act_dim, 1).to(device)
    q2 = MLP(obs_dim + act_dim, 1).to(device)

    policy_opt = optim.Adam(policy.parameters(), lr=3e-4)
    q1_opt = optim.Adam(q1.parameters(), lr=3e-4)
    q2_opt = optim.Adam(q2.parameters(), lr=3e-4)

    replay_buffer = ReplayBuffer(10**6, obs_dim, act_dim)

    agent = TD3Agent(
        env=train_env,
        policy=policy,
        q1=q1,
        q2=q2,
        policy_opt=policy_opt,
        q1_opt=q1_opt,
        q2_opt=q2_opt,
        replay_buffer=replay_buffer,
        gamma=0.99,
        tau=5e-3,
        batch_size=args.batch_size,
    )

    if args.load:
        checkpoint = torch.load(args.load, map_location=device)
        agent.policy.load_state_dict(checkpoint['policy'])
        agent.q1.load_state_dict(checkpoint['q1'])
        agent.q2.load_state_dict(checkpoint['q2'])
        logging.info(f"Loaded agent from {args.load}")

    if args.load_pretrained:
        # Placeholder for pretrained loading logic
        pass

    # Visualize computational graphs
    draw_computational_graph(agent.policy, args.outdir, 'policy')
    draw_computational_graph(agent.q1, args.outdir, 'q1')
    draw_computational_graph(agent.q2, args.outdir, 'q2')

    if args.demo:
        returns = eval_policy(agent, args.eval_n_runs, eval_env)
        logging.info(f"Demo returns: mean={np.mean(returns):.2f} median={np.median(returns):.2f} std={np.std(returns):.2f}")
        np.save(os.path.join(args.outdir, 'demo_returns.npy'), returns)
    else:
        # Burn-in random actions
        state = train_env.reset()
        for _ in range(args.replay_start_size):
            action = train_env.action_space.sample()
            next_state, reward, done, _ = train_env.step(action)
            replay_buffer.push(Transition(state, action, reward, next_state, float(done)))
            state = next_state if not done else train_env.reset()

        agent.train(
            steps=args.steps,
            eval_func=lambda: eval_policy(agent, args.eval_n_runs, eval_env),
            eval_interval=args.eval_interval,
            eval_n_runs=args.eval_n_runs,
        )

        # Save final model
        torch.save({
            'policy': agent.policy.state_dict(),
            'q1': agent.q1.state_dict(),
            'q2': agent.q2.state_dict(),
        }, os.path.join(args.outdir, 'final.pth'))

if __name__ == '__main__':
    main()
