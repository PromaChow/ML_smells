import pandas as pd
import matplotlib.pyplot as plt

# Load dataset
df = pd.read_csv("Hurricanes.csv")

# Extract relevant columns
x = df["Year"]
y = df["Hurricanes"]

# Create bar graph
plt.figure(figsize=(10, 6))
plt.bar(x, y, color="skyblue")

# Add labels and title
plt.xlabel("Year")
plt.ylabel("Hurricanes")
plt.title("Hurricanes vs Year")
plt.grid(axis="y", linestyle="--", alpha=0.7)

# Rotate x-axis tick labels
plt.xticks(rotation=90, ha="right")

# Display plot
plt.tight_layout()
plt.show()