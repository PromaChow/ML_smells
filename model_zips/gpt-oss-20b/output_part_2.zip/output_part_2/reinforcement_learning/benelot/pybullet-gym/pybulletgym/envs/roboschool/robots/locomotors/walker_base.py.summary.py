import math
import random
import numpy as np
import pybullet as p

# Assume XmlBasedRobot is defined elsewhere and provides necessary attributes and methods.
try:
    from robot_base import XmlBasedRobot
except ImportError:
    class XmlBasedRobot:
        """Placeholder base class."""
        def __init__(self, *args, **kwargs):
            self.foot_list = []
            self.joint_indices = []
            self.power_coef = []
            self.scene = None
            self.part_indices = []
            self.torso_index = 0
            self._p = None
        def get_joint_states(self):
            return p.getJointStates(self.body_id, self.joint_indices)
        def get_part_states(self):
            return [p.getLinkState(self.body_id, idx, computeLinkVelocity=1) for idx in self.part_indices]

class WalkerBase(XmlBasedRobot):
    def __init__(self, power=1.0, camera_x=0.0, start_pos=(0.0, 0.0, 0.0),
                 walk_target=(10.0, 0.0), *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.power = power
        self.camera_x = camera_x
        self.start_pos_x, self.start_pos_y, self.start_pos_z = start_pos
        self.walk_target_x, self.walk_target_y = walk_target
        self.body_xyz = np.array([self.start_pos_x, self.start_pos_y, self.start_pos_z])
        self.initial_z = self.start_pos_z
        self.feet_contact = None
        self.joints_at_limit = 0
        self.body_rpy = np.zeros(3)

    def robot_specific_reset(self, physics_client, scene):
        self._p = physics_client
        self.scene = scene
        for idx, joint_index in enumerate(self.joint_indices):
            rand_pos = random.uniform(-0.1, 0.1)
            self._p.resetJointState(self.body_id, joint_index, rand_pos)
        self.feet_contact = np.zeros(len(self.foot_list))
        try:
            scene.actor_introduce(self)
        except AttributeError:
            pass
        self.initial_z = self.body_xyz[2]

    def apply_action(self, a):
        a = np.clip(a, -1.0, 1.0)
        assert np.all(np.isfinite(a)), "Action contains non-finite values"
        for idx, joint_index in enumerate(self.joint_indices):
            torque = a[idx] * self.power * self.power_coef[idx]
            self._p.setJointMotorControl2(
                bodyIndex=self.body_id,
                jointIndex=joint_index,
                controlMode=p.TORQUE_CONTROL,
                force=torque
            )

    def calc_state(self):
        joint_states = self._p.getJointStates(self.body_id, self.joint_indices)
        positions = np.array([state[0] for state in joint_states])
        velocities = np.array([state[1] for state in joint_states])
        self.joints_at_limit = np.sum(
            (np.abs(positions - np.array([self._p.getJointInfo(self.body_id, i)[3] for i in self.joint_indices]))) < 1e-3
        )
        link_states = self._p.getLinkState(self.body_id, self.torso_index, computeLinkVelocity=1)
        torso_pos = np.array(link_states[0])
        self.body_xyz = np.mean([np.array(p.getLinkState(self.body_id, idx, computeLinkVelocity=0)[0]) for idx in self.part_indices], axis=0)
        self.body_xyz[2] = torso_pos[2]
        quat = link_states[1]
        self.body_rpy = np.array(p.getEulerFromQuaternion(quat))
        z_displacement = self.body_xyz[2] - self.initial_z
        target_vec = np.array([self.walk_target_x - self.body_xyz[0], self.walk_target_y - self.body_xyz[1]])
        distance = np.linalg.norm(target_vec)
        angle = math.atan2(target_vec[1], target_vec[0])
        linear_vel, _ = self._p.getBaseVelocity(self.body_id)
        rotation_matrix = np.array([
            [math.cos(-self.body_rpy[2]), -math.sin(-self.body_rpy[2]), 0],
            [math.sin(-self.body_rpy[2]),  math.cos(-self.body_rpy[2]), 0],
            [0, 0, 1]
        ])
        body_frame_vel = rotation_matrix @ np.array(linear_vel)
        contact_forces = np.zeros(len(self.foot_list))
        state = np.concatenate([
            positions, velocities,
            self.body_xyz, self.body_rpy,
            np.array([z_displacement, distance, angle]),
            body_frame_vel, contact_forces,
            np.array([self.joints_at_limit])
        ])
        return np.clip(state, -5.0, 5.0)

    def calc_potential(self):
        target_vec = np.array([self.walk_target_x - self.body_xyz[0], self.walk_target_y - self.body_xyz[1]])
        distance = np.linalg.norm(target_vec)
        dt = getattr(self.scene, 'dt', None)
        if dt is not None:
            return -distance / dt
        return -distance
