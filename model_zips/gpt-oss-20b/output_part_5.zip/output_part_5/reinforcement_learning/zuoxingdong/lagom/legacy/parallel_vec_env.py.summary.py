import multiprocessing as mp
import numpy as np
import gymnasium as gym


def _worker(worker_conn, make_env):
    """
    Worker process function that handles environment interactions.
    """
    worker_conn.close()
    env = make_env()
    try:
        while True:
            cmd, data = worker_conn.recv()
            if cmd == "step":
                action = data
                obs, reward, done, info = env.step(action)
                if done:
                    obs = env.reset()
                worker_conn.send((obs, reward, done, info))
            elif cmd == "reset":
                obs = env.reset()
                worker_conn.send(obs)
            elif cmd == "render":
                frame = env.render(mode="rgb_array")
                worker_conn.send(frame)
            elif cmd == "close":
                env.close()
                worker_conn.close()
                break
            elif cmd == "env_info":
                worker_conn.send(
                    (
                        env.observation_space,
                        env.action_space,
                        env.reward_range,
                        env.spec,
                    )
                )
            elif cmd == "get_env":
                worker_conn.send(env)
            elif cmd == "set_env":
                env = data
                worker_conn.send(None)
            else:
                raise NotImplementedError(f"Unknown command {cmd}")
    except Exception as e:
        worker_conn.send(e)
        worker_conn.close()
        raise


class ParallelVecEnv:
    """
    Parallel vectorized environment using multiprocessing.
    """

    def __init__(self, env_fns):
        """
        Args:
            env_fns (list[callable]): List of callables that create environments.
        """
        self.num_envs = len(env_fns)
        self.parent_conns, self.child_conns = zip(*[mp.Pipe() for _ in range(self.num_envs)])
        self.processes = []
        for idx, (parent, child, make_env) in enumerate(
            zip(self.parent_conns, self.child_conns, env_fns)
        ):
            p = mp.Process(target=_worker, args=(child, make_env))
            p.daemon = True
            p.start()
            child.close()
            self.processes.append(p)

        # Retrieve environment info from the first environment
        self.parent_conns[0].send(("env_info", None))
        (
            self.observation_space,
            self.action_space,
            self.reward_range,
            self.spec,
        ) = self.parent_conns[0].recv()

        # Initial reset
        self._reset_all()

    def _reset_all(self):
        """
        Reset all environments and return the initial observations.
        """
        for parent in self.parent_conns:
            parent.send(("reset", None))
        observations = [parent.recv() for parent in self.parent_conns]
        return np.stack(observations)

    def reset(self):
        """
        Reset all environments and return observations.
        """
        return self._reset_all()

    def step(self, actions):
        """
        Step all environments with the given actions.

        Args:
            actions (array-like): Actions for each environment.

        Returns:
            observations, rewards, dones, infos
        """
        if len(actions) != self.num_envs:
            raise ValueError("Number of actions must match number of environments")
        for parent, action in zip(self.parent_conns, actions):
            parent.send(("step", action))
        results = [parent.recv() for parent in self.parent_conns]
        obs, rew, done, info = zip(*results)
        return (
            np.stack(obs),
            np.array(rew, dtype=np.float32),
            np.array(done, dtype=bool),
            info,
        )

    def render(self):
        """
        Render all environments and return the frames.
        """
        for parent in self.parent_conns:
            parent.send(("render", None))
        frames = [parent.recv() for parent in self.parent_conns]
        return frames

    def close(self):
        """
        Close all environments and terminate worker processes.
        """
        for parent in self.parent_conns:
            parent.send(("close", None))
        for p in self.processes:
            p.join()
        for parent in self.parent_conns:
            parent.close()
        self.processes = []

    def __len__(self):
        return self.num_envs

    def __getitem__(self, idx):
        """
        Retrieve the environment instance at index idx.
        """
        if not 0 <= idx < self.num_envs:
            raise IndexError("Index out of range")
        self.parent_conns[idx].send(("get_env", None))
        return self.parent_conns[idx].recv()

    def __setitem__(self, idx, env):
        """
        Replace the environment at index idx with a new instance.
        """
        if not 0 <= idx < self.num_envs:
            raise IndexError("Index out of range")
        self.parent_conns[idx].send(("set_env", env))
        self.parent_conns[idx].recv()  # acknowledge

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass
```