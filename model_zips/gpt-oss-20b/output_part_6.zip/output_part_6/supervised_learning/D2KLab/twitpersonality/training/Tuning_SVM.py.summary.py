import argparse
import os
import sys
import warnings

import numpy as np
import pandas as pd
from scipy.stats import pearsonr
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import KFold
from sklearn.svm import SVR

# Assume custom modules are available
import datasetUtils as dsu
import embeddings


def pccMean(arr):
    """Compute mean of Pearson correlation coefficients, ignoring NaNs."""
    return np.nanmean(arr)


def parse_arguments():
    parser = argparse.ArgumentParser(description="SVR evaluation on Big Five traits.")
    parser.add_argument("BIG5_trait", type=str, help="Big Five trait (O, C, E, A, N)")
    parser.add_argument("Embeddings_dataset", type=str, help="Embeddings dataset (fasttext or dataset9)")
    parser.add_argument("Dataset_path", type=str, help="Path to dataset file")
    parser.add_argument("Shuffle_data", type=str, help="Shuffle data? (yes/no/True/False)")
    args = parser.parse_args()

    trait = args.BIG5_trait.upper()
    if trait not in {"O", "C", "E", "A", "N"}:
        sys.exit("Error: BIG5_trait must be one of O, C, E, A, N.")

    dataset = args.Embeddings_dataset.lower()
    if dataset not in {"fasttext", "dataset9"}:
        sys.exit("Error: Embeddings_dataset must be 'fasttext' or 'dataset9'.")

    if not os.path.isfile(args.Dataset_path):
        sys.exit("Error: Dataset_path does not exist.")

    shuffle_flag = args.Shuffle_data.lower()
    if shuffle_flag not in {"yes", "no", "true", "false"}:
        sys.exit("Error: Shuffle_data must be yes/no/True/False.")
    shuffle = shuffle_flag in {"yes", "true"}

    return trait, dataset, args.Dataset_path, shuffle


def main():
    trait, dataset, dataset_path, shuffle = parse_arguments()

    post_threshold = 3
    subset_size = 100

    # Load posts and labels
    posts, yO, yC, yE, yA, yN = dsu.readMyPersonality(dataset_path)

    # Load embeddings
    if dataset == "fasttext":
        words, vectors = dsu.parseFastText(dataset_path)
    else:
        words, vectors = dsu.loadEmbeddingsDataset(dataset_path)

    # Shuffle if required
    if shuffle:
        rng = np.random.default_rng()
        indices = np.arange(len(posts))
        rng.shuffle(indices)
        posts = [posts[i] for i in indices]
        yO = yO[indices]
        yC = yC[indices]
        yE = yE[indices]
        yA = yA[indices]
        yN = yN[indices]

    # Subset selection
    posts = posts[:subset_size]
    yO = yO[:subset_size]
    yC = yC[:subset_size]
    yE = yE[:subset_size]
    yA = yA[:subset_size]
    yN = yN[:subset_size]

    # Backup labels
    old_yO, old_yC, old_yE, old_yA, old_yN = yO.copy(), yC.copy(), yE.copy(), yA.copy(), yN.copy()

    # Embedding methods
    methods = ["sum", "max", "min", "avg", "concat"]
    X_dict = {}
    for method in methods:
        X_dict[method] = embeddings.transformTextForTraining(
            posts, words, vectors, method, post_threshold
        )

    # Label selection
    label_map = {"O": yO, "C": yC, "E": yE, "A": yA, "N": yN}
    labels = label_map[trait]

    # File setup
    results_dir = "Results"
    os.makedirs(results_dir, exist_ok=True)
    csv_path = os.path.join(results_dir, f"{trait}_{dataset}.csv")
    pcc_path = os.path.join(results_dir, f"{trait}_{dataset}_pcc.txt")

    for path in (csv_path, pcc_path):
        if os.path.exists(path):
            os.remove(path)

    # Cross-validation
    kf = KFold(n_splits=10, shuffle=False)
    config_list = []

    # SVR configurations
    svr_configs = [
        {"kernel": "linear", "C": 1},
        {"kernel": "poly", "degree": 2, "C": 1},
        {"kernel": "poly", "degree": 2, "C": 10},
        {"kernel": "poly", "degree": 2, "C": 100},
        {"kernel": "poly", "degree": 3, "C": 1},
        {"kernel": "poly", "degree": 3, "C": 10},
        {"kernel": "poly", "degree": 3, "C": 100},
        {"kernel": "rbf", "gamma": 0.01, "C": 1},
        {"kernel": "rbf", "gamma": 0.01, "C": 10},
        {"kernel": "rbf", "gamma": 0.01, "C": 100},
        {"kernel": "rbf", "gamma": 0.1, "C": 1},
        {"kernel": "rbf", "gamma": 0.1, "C": 10},
        {"kernel": "rbf", "gamma": 0.1, "C": 100},
        {"kernel": "rbf", "gamma": 1, "C": 1},
        {"kernel": "rbf", "gamma": 1, "C": 10},
        {"kernel": "rbf", "gamma": 1, "C": 100},
        {"kernel": "rbf", "gamma": 10, "C": 1},
        {"kernel": "rbf", "gamma": 10, "C": 10},
        {"kernel": "rbf", "gamma": 10, "C": 100},
    ]

    per_fold_pcc = {}

    for method in methods:
        X = X_dict[method]
        per_fold_pcc[method] = {}
        for config in svr_configs:
            key = tuple(sorted(config.items()))
            per_fold_pcc[method][key] = []

            mse_list = []
            r2_list = []
            pcc_list = []

            for train_index, test_index in kf.split(X):
                X_train, X_test = X[train_index], X[test_index]
                y_train, y_test = labels[train_index], labels[test_index]

                model = SVR(**config)
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    model.fit(X_train, y_train)
                y_pred = model.predict(X_test)

                mse = mean_squared_error(y_test, y_pred)
                r2 = r2_score(y_test, y_pred)
                try:
                    pcc, _ = pearsonr(y_test, y_pred)
                except Exception:
                    pcc = np.nan

                mse_list.append(mse)
                r2_list.append(r2)
                pcc_list.append(pcc)

            avg_mse = np.mean(mse_list)
            avg_r2 = np.mean(r2_list)
            avg_pcc = np.mean(pcc_list)

            config_dict = {
                "method": method,
                "kernel": config.get("kernel", ""),
                "degree": config.get("degree", ""),
                "gamma": config.get("gamma", ""),
                "C": config.get("C", ""),
                "MSE": avg_mse,
                "R2": avg_r2,
                "PCC": avg_pcc,
            }
            config_list.append(config_dict)

            per_fold_pcc[method][key] = pcc_list

    # Write CSV results
    df = pd.DataFrame(config_list)
    df.to_csv(csv_path, index=False)

    # Write PCC details
    with open(pcc_path, "w") as f:
        for method, configs in per_fold_pcc.items():
            f.write(f"Method: {method}\n")
            for key, pccs in configs.items():
                config_desc = ", ".join(f"{k}={v}" for k, v in key)
                f.write(f"  Config: {config_desc}\n")
                for fold_idx, pcc in enumerate(pccs, start=1):
                    f.write(f"    Fold {fold_idx}: PCC = {pcc}\n")
            f.write("\n")


if __name__ == "__main__":
    main()
