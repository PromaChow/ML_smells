import numpy as np
from tensorflow.keras import layers, models, backend as K
from tensorflow.keras.layers import Layer, Input, Conv2D, BatchNormalization, Activation, Flatten, Dense, Add
from tensorflow.keras.models import Model
from tensorflow.keras.activations import softmax

# Placeholder for flatten_idx if AlphaGo.util is unavailable
try:
    from AlphaGo.util import flatten_idx
except ImportError:
    def flatten_idx(coord, board):
        x, y = coord
        return y * board + x

class Bias(Layer):
    def __init__(self, output_dim, **kwargs):
        super(Bias, self).__init__(**kwargs)
        self.output_dim = output_dim

    def build(self, input_shape):
        self.bias = self.add_weight(name='bias',
                                    shape=(self.output_dim,),
                                    initializer='zeros',
                                    trainable=True)
        super(Bias, self).build(input_shape)

    def call(self, inputs):
        return inputs + self.bias

    def compute_output_shape(self, input_shape):
        return input_shape

class CNNPolicy:
    def __init__(self, **kwargs):
        self.input_dim = kwargs.get('input_dim', 1)
        self.board = kwargs.get('board', 19)
        self.filters_per_layer_K = kwargs.get('filters_per_layer_K', 128)
        self.layers = kwargs.get('layers', 12)
        self.filter_width_K = kwargs.get('filter_width_K', 3)
        self.first_filter_width = kwargs.get('first_filter_width', 5)
        self.network = self.create_network()

    def create_network(self):
        model = models.Sequential()
        # First convolutional layer
        model.add(Conv2D(filters=self.filters_per_layer_K,
                         kernel_size=self.first_filter_width,
                         activation='relu',
                         data_format='channels_first',
                         input_shape=(self.input_dim, self.board, self.board),
                         padding='same'))
        # Subsequent layers
        for _ in range(self.layers - 1):
            model.add(Conv2D(filters=self.filters_per_layer_K,
                             kernel_size=self.filter_width_K,
                             activation='relu',
                             data_format='channels_first',
                             padding='same'))
        # Final convolution to single channel
        model.add(Conv2D(filters=1,
                         kernel_size=1,
                         activation='linear',
                         data_format='channels_first',
                         padding='same'))
        # Flatten and bias
        model.add(Flatten())
        model.add(Bias(self.board * self.board))
        # Softmax activation
        model.add(Activation(softmax))
        return model

    def _preprocess_state(self, state):
        # Assume state is already a numpy array of shape (input_dim, board, board)
        if not isinstance(state, np.ndarray):
            state = np.array(state, dtype=np.float32)
        return state[np.newaxis, ...]  # add batch dimension

    def _select_moves_and_normalize(self, probs, legal_moves):
        indices = [flatten_idx(move, self.board) for move in legal_moves]
        selected = probs[indices]
        total = np.sum(selected)
        if total == 0:
            normalized = np.zeros_like(selected)
        else:
            normalized = selected / total
        return list(zip(legal_moves, normalized))

    def eval_state(self, state, legal_moves=None):
        tensor = self._preprocess_state(state)
        probs = self.network.predict(tensor, verbose=0)[0]
        if legal_moves is not None:
            return self._select_moves_and_normalize(probs, legal_moves)
        else:
            return list(zip([(x // self.board, x % self.board) for x in range(self.board * self.board)], probs))

    def batch_eval_state(self, states, legal_moves_list):
        tensors = np.stack([self._preprocess_state(s) for s in states], axis=0)
        batch_probs = self.network.predict(tensors, verbose=0)
        results = []
        for probs, legal_moves in zip(batch_probs, legal_moves_list):
            results.append(self._select_moves_and_normalize(probs, legal_moves))
        return results

class ResnetPolicy:
    def __init__(self, **kwargs):
        self.input_dim = kwargs.get('input_dim', 1)
        self.board = kwargs.get('board', 19)
        self.filters_per_layer_K = kwargs.get('filters_per_layer_K', 128)
        self.n_skip_K = kwargs.get('n_skip_K', 10)
        self.filter_width_K = kwargs.get('filter_width_K', 3)
        self.first_filter_width = kwargs.get('first_filter_width', 5)
        self.network = self.create_network()

    def create_network(self):
        inputs = Input(shape=(self.input_dim, self.board, self.board), name='input')
        x = Conv2D(filters=self.filters_per_layer_K,
                   kernel_size=self.first_filter_width,
                   activation='linear',
                   data_format='channels_first',
                   padding='same',
                   name='conv_initial')(inputs)

        # Residual blocks
        for i in range(self.n_skip_K):
            y = BatchNormalization(name=f'bn_{i}')(x)
            y = Activation('relu', name=f'relu_{i}')(y)
            y = Conv2D(filters=self.filters_per_layer_K,
                       kernel_size=self.filter_width_K,
                       activation='linear',
                       data_format='channels_first',
                       padding='same',
                       name=f'conv_{i}')(y)
            x = Add(name=f'skip_{i}')([x, y])

        # Final layers
        x = Activation('relu', name='final_relu')(x)
        x = Conv2D(filters=1,
                   kernel_size=1,
                   activation='linear',
                   data_format='channels_first',
                   padding='same',
                   name='conv_final')(x)
        x = Flatten(name='flatten')(x)
        x = Bias(self.board * self.board, name='bias')(x)
        outputs = Activation(softmax, name='softmax')(x)

        model = Model(inputs=inputs, outputs=outputs, name='ResnetPolicy')
        return model

    def _preprocess_state(self, state):
        if not isinstance(state, np.ndarray):
            state = np.array(state, dtype=np.float32)
        return state[np.newaxis, ...]  # add batch dimension

    def _select_moves_and_normalize(self, probs, legal_moves):
        indices = [flatten_idx(move, self.board) for move in legal_moves]
        selected = probs[indices]
        total = np.sum(selected)
        if total == 0:
            normalized = np.zeros_like(selected)
        else:
            normalized = selected / total
        return list(zip(legal_moves, normalized))

    def eval_state(self, state, legal_moves=None):
        tensor = self._preprocess_state(state)
        probs = self.network.predict(tensor, verbose=0)[0]
        if legal_moves is not None:
            return self._select_moves_and_normalize(probs, legal_moves)
        else:
            return list(zip([(x // self.board, x % self.board) for x in range(self.board * self.board)], probs))

    def batch_eval_state(self, states, legal_moves_list):
        tensors = np.stack([self._preprocess_state(s) for s in states], axis=0)
        batch_probs = self.network.predict(tensors, verbose=0)
        results = []
        for probs, legal_moves in zip(batch_probs, legal_moves_list):
            results.append(self._select_moves_and_normalize(probs, legal_moves))
        return results

if __name__ == "__main__":
    # Example usage
    cnn = CNNPolicy()
    resnet = ResnetPolicy()

    dummy_state = np.random.rand(1, 19, 19).astype(np.float32)
    legal_moves = [(x, y) for x in range(19) for y in range(19) if np.random.rand() < 0.1]

    print("CNN eval:", cnn.eval_state(dummy_state, legal_moves))
    print("ResNet eval:", resnet.eval_state(dummy_state, legal_moves))
    print("CNN batch eval:", cnn.batch_eval_state([dummy_state, dummy_state], [legal_moves, legal_moves]))
    print("ResNet batch eval:", resnet.batch_eval_state([dummy_state, dummy_state], [legal_moves, legal_moves]))
