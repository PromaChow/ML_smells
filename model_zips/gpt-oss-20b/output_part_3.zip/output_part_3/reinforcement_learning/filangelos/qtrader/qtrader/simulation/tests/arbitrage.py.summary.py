import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import random


class Test:
    pass


class TradingEnv:
    def __init__(self, tickers, prices, freq):
        self.tickers = tickers
        self.prices = np.array(prices)
        self.freq = freq
        self.max_steps = len(prices) - 1
        self.current_step = None
        self.done = None
        self.observation = None
        self.agents = {}
        self.wealth = {}

    def register_agent(self, agent):
        self.agents[agent.name] = agent
        self.wealth[agent.name] = 1000.0

    def reset(self):
        self.current_step = 0
        self.done = False
        self.observation = self.prices[self.current_step]
        for agent in self.agents:
            self.wealth[agent] = 1000.0
        return self.observation

    def step(self, actions):
        if self.done:
            raise RuntimeError("Environment is done. Call reset() to start again.")
        next_step = self.current_step + 1
        price_change = self.prices[next_step] / self.prices[self.current_step] - 1
        rewards = {}
        for name, action in actions.items():
            # action is dict of weights per ticker
            # compute portfolio return
            portfolio_return = 0.0
            for ticker, weight in action.items():
                portfolio_return += weight * price_change
            new_wealth = self.wealth[name] * (1 + portfolio_return)
            reward = new_wealth - self.wealth[name]
            self.wealth[name] = new_wealth
            rewards[name] = reward
        self.current_step = next_step
        self.observation = self.prices[self.current_step]
        if self.current_step >= self.max_steps:
            self.done = True
        return self.observation, rewards, self.done


class QuadraticAgent:
    def __init__(self, name, window, risk_aversion):
        self.name = name
        self.window = window
        self.risk_aversion = risk_aversion
        self.tickers = []

    def set_tickers(self, tickers):
        self.tickers = tickers

    def act(self, observation):
        # Simple heuristic: use recent returns to compute weights
        # Here we assume a single price series for all tickers
        # Use placeholder returns: random normal
        returns = np.random.randn(self.window)
        mean_ret = np.mean(returns)
        vol = np.std(returns) + 1e-6
        weight = mean_ret / (vol ** 2)
        weights = {ticker: weight for ticker in self.tickers}
        # Normalize
        total = sum(weights.values())
        if total != 0:
            for k in weights:
                weights[k] /= total
        else:
            for k in weights:
                weights[k] = 1.0 / len(weights)
        return weights


class RandomAgent:
    def __init__(self, name):
        self.name = name
        self.tickers = []

    def set_tickers(self, tickers):
        self.tickers = tickers

    def act(self, observation):
        weights = {ticker: random.random() for ticker in self.tickers}
        total = sum(weights.values())
        for k in weights:
            weights[k] /= total
        return weights


class Arbitrage(Test):
    def run(self, df_1, df_2, tickers, freq, window, render=False):
        env = self._test_env(df_1, tickers, freq, window)
        if env is None:
            return False

        tangent_agent = QuadraticAgent(name="tangent_agent", window=window, risk_aversion=0.0)
        tangent_agent.set_tickers(tickers)
        random_agent = RandomAgent(name="random_agent")
        random_agent.set_tickers(tickers)

        env.register_agent(tangent_agent)
        env.register_agent(random_agent)

        env.reset()
        done = False
        tangent_history = []
        random_history = []

        while not done:
            observation = env.observation
            actions = {
                tangent_agent.name: tangent_agent.act(observation),
                random_agent.name: random_agent.act(observation),
            }
            observation, rewards, done = env.step(actions)
            tangent_history.append(env.wealth[tangent_agent.name])
            random_history.append(env.wealth[random_agent.name])

        if render:
            plt.figure(figsize=(10, 6))
            plt.plot(tangent_history, label="Quadratic Agent")
            plt.plot(random_history, label="Random Agent")
            plt.xlabel("Time Step")
            plt.ylabel("Wealth")
            plt.title("Agent Wealth Over Time")
            plt.legend()
            plt.grid(True)
            plt.show()

        return True

    def _test_env(self, df, tickers, freq, window):
        if not isinstance(df, pd.DataFrame):
            return None
        if 'return' not in df.columns:
            return None
        try:
            returns = df['return'].to_numpy()
            prices = 500.0 * np.cumprod(1 + returns)
        except Exception:
            return None
        env = TradingEnv(tickers=tickers, prices=prices, freq=freq)
        return env
