import argparse
import gym
import numpy as np
import random
from copy import deepcopy


class QLearningAgent:
    def __init__(self, env, epsilon=0.1, gamma=0.99, lr=0.5):
        self.state_space = env.observation_space.n
        self.action_space = env.action_space.n
        self.epsilon = epsilon
        self.gamma = gamma
        self.lr = lr
        self.q_table = np.zeros((self.state_space, self.action_space))
        self.result = {}

    def copy(self):
        agent = QLearningAgent(
            env=None,
            epsilon=self.epsilon,
            gamma=self.gamma,
            lr=self.lr,
        )
        agent.q_table = self.q_table.copy()
        agent.result = {}
        return agent

    def choose_action(self, state, explore=True):
        if explore and random.random() < self.epsilon:
            return random.randrange(self.action_space)
        return int(np.argmax(self.q_table[state]))

    def update(self, state, action, reward, next_state, done):
        best_next = np.max(self.q_table[next_state])
        td_target = reward + (0.0 if done else self.gamma * best_next)
        td_error = td_target - self.q_table[state, action]
        self.q_table[state, action] += self.lr * td_error


class Trainer:
    def __init__(
        self,
        agent,
        env,
        mode="dyna",
        model="tabular",
        n_episodes=1000,
        start_steps=50,
    ):
        self.agent = agent
        self.env = env
        self.n_episodes = n_episodes
        self.start_steps = start_steps
        self.rewards = []

    def train(self):
        for _ in range(self.n_episodes):
            state = self.env.reset()
            episode_reward = 0
            done = False
            step = 0
            while not done:
                if step < self.start_steps:
                    action = self.env.action_space.sample()
                else:
                    action = self.agent.choose_action(state)
                next_state, reward, done, _ = self.env.step(action)
                self.agent.update(state, action, reward, next_state, done)
                state = next_state
                episode_reward += reward
                step += 1
            self.rewards.append(episode_reward)
        mean_reward = np.mean(self.rewards)
        self.agent.result["mean_reward"] = mean_reward


class GeneticHyperparamTuner:
    def __init__(self, choices):
        self.choices = choices

    def initialize_population(self, size, generic_agent):
        population = []
        for _ in range(size):
            agent = generic_agent.copy()
            agent.epsilon = random.choice(self.choices["epsilon"])
            agent.gamma = random.choice(self.choices["gamma"])
            agent.lr = random.choice(self.choices["lr"])
            population.append(agent)
        return population

    def grade(self, agents):
        return np.mean([self.fitness(a) for a in agents])

    def evolve(self, agents):
        # Select top 50% as parents
        agents.sort(key=lambda a: self.fitness(a), reverse=True)
        parents = agents[: len(agents) // 2]
        offspring = []
        while len(offspring) + len(parents) < len(agents):
            parent1, parent2 = random.sample(parents, 2)
            child = parent1.copy()
            # Crossover: choose hyperparams from parents
            child.epsilon = random.choice([parent1.epsilon, parent2.epsilon])
            child.gamma = random.choice([parent1.gamma, parent2.gamma])
            child.lr = random.choice([parent1.lr, parent2.lr])
            # Mutation
            if random.random() < 0.1:
                child.epsilon = random.choice(self.choices["epsilon"])
            if random.random() < 0.1:
                child.gamma = random.choice(self.choices["gamma"])
            if random.random() < 0.1:
                child.lr = random.choice(self.choices["lr"])
            offspring.append(child)
        return parents + offspring

    def fitness(self, agent):
        return agent.result.get("mean_reward", 0.0)


class GATuner(GeneticHyperparamTuner):
    pass  # fitness already defined in base class


def train_population(agents, env):
    for agent in agents:
        trainer = Trainer(
            agent=agent,
            env=env,
            mode="dyna",
            model="tabular",
            n_episodes=1000,
            start_steps=50,
        )
        trainer.train()
        del trainer


def generate(
    generations,
    population,
    agent_parameter_choices,
    env,
    generic_agent,
    args,
):
    optimizer = GATuner(agent_parameter_choices)
    agents = optimizer.initialize_population(population, generic_agent)

    for gen in range(1, generations + 1):
        train_population(agents, env)
        avg_reward = optimizer.grade(agents)
        print(f"Generation {gen}: Avg Reward = {avg_reward:.4f}")
        if gen < generations:
            agents = optimizer.evolve(agents)

    # Final sorting
    agents.sort(key=lambda a: a.result.get("mean_reward", 0.0), reverse=True)
    print("\nTop 5 Agents:")
    for i, agent in enumerate(agents[:5], 1):
        print(
            f"{i}. Reward: {agent.result.get('mean_reward', 0.0):.4f}, "
            f"epsilon: {agent.epsilon}, gamma: {agent.gamma}, lr: {agent.lr}"
        )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--population", type=int, default=10, help="Population size")
    parser.add_argument("--generations", type=int, default=10, help="Number of generations")
    args = parser.parse_args()

    env = gym.make("FrozenLake-v0")
    generic_agent = QLearningAgent(env)

    agent_parameter_choices = {
        "epsilon": [0.05, 0.1, 0.2],
        "gamma": [0.9, 0.95, 0.99],
        "lr": [0.1, 0.5, 0.9],
    }

    generate(
        generations=args.generations,
        population=args.population,
        agent_parameter_choices=agent_parameter_choices,
        env=env,
        generic_agent=generic_agent,
        args=args,
    )


if __name__ == "__main__":
    main()
