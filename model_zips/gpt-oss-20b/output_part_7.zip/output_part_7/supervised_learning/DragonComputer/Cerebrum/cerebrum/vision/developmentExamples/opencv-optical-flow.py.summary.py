import argparse
import cv2
import numpy as np
import sys

# Constants
TARGET_HEIGHT = 360
LK_PARAMS = dict(winSize=(15, 15), maxLevel=2, criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 10, 0.03))
ABSDIFF_ANGLE = 20          # degrees
CRAZY_LINE_LIMIT = 50
DELTA_LIMIT_DIVISOR = 1000
CONTOUR_LIMIT = 5
MAX_CORNERS = 1000
CANNY_THRESH = 50
DILATE_ITER = 2
CROP_RATIO = 0.9  # used to ignore borders when selecting points

def parse_arguments():
    parser = argparse.ArgumentParser(description="Optical flow based video analysis")
    parser.add_argument("--video", type=str, default="", help="Path to video file; leave empty for webcam")
    return parser.parse_args()

def init_capture(video_path):
    if video_path:
        cap = cv2.VideoCapture(video_path)
    else:
        cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        sys.exit("Error: Cannot open video source")
    return cap

def resize_frame(frame, target_height=TARGET_HEIGHT):
    h, w = frame.shape[:2]
    scale = target_height / h
    new_w = int(w * scale)
    return cv2.resize(frame, (new_w, target_height))

def get_random_points(frame, max_corners=MAX_CORNERS):
    h, w = frame.shape[:2]
    points = np.random.randint(
        low=0,
        high=min(h, w) - 1,
        size=(max_corners, 2),
        dtype=np.int32
    )
    mask = np.all(points < np.array([h - 1, w - 1]), axis=1)
    return points[mask]

def compute_motion(prev_gray, gray, prev_pts):
    pts, st, err = cv2.calcOpticalFlowPyrLK(prev_gray, gray, prev_pts, None, **LK_PARAMS)
    st = st.reshape(-1)
    valid_prev = prev_pts[st == 1]
    valid_pts = pts[st == 1]
    return valid_prev, valid_pts, st

def analyze_vectors(prev_pts, curr_pts):
    dx = curr_pts[:, 0] - prev_pts[:, 0]
    dy = curr_pts[:, 1] - prev_pts[:, 1]
    dist = np.sqrt(dx**2 + dy**2)
    angle = np.degrees(np.arctan2(dy, dx)) % 360
    return dist, angle

def most_common_angle(angle):
    hist, _ = np.histogram(angle, bins=36, range=(0, 360))
    idx = np.argmax(hist)
    return idx * 10  # each bin represents 10 degrees

def create_mask_delta(frame_shape, prev_pts, angle, common_angle):
    mask = np.zeros(frame_shape[:2], dtype=np.uint8)
    diff = np.abs(angle - common_angle)
    mask[(diff > ABSDIFF_ANGLE) & (prev_pts[:, 0] >= 0) & (prev_pts[:, 1] >= 0)] = 255
    return mask

def process_contours(mask_delta, frame_shape):
    thresh = cv2.threshold(mask_delta, 127, 255, cv2.THRESH_BINARY)[1]
    kernel = np.ones((3, 3), np.uint8)
    dilated = cv2.dilate(thresh, kernel, iterations=DILATE_ITER)
    contours, _ = cv2.findContours(dilated, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None, 0
    areas = [cv2.contourArea(c) for c in contours]
    max_idx = np.argmax(areas)
    largest_area = areas[max_idx]
    mask_biggest = np.zeros(frame_shape[:2], dtype=np.uint8)
    cv2.drawContours(mask_biggest, [contours[max_idx]], -1, 255, -1)
    return mask_biggest, largest_area

def quadrant_analysis(frame, prev_pts, curr_pts, angle, common_angle):
    h, w = frame.shape[:2]
    quadrants = [
        (0, 0, w // 2, h // 2),
        (w // 2, 0, w // 2, h // 2),
        (0, h // 2, w // 2, h // 2),
        (w // 2, h // 2, w // 2, h // 2),
    ]
    masks = []
    for (x, y, qw, qh) in quadrants:
        mask = np.zeros((qh, qw), dtype=np.uint8)
        in_quad = (
            (prev_pts[:, 0] >= x) & (prev_pts[:, 0] < x + qw) &
            (prev_pts[:, 1] >= y) & (prev_pts[:, 1] < y + qh)
        )
        quad_prev = prev_pts[in_quad] - np.array([x, y])
        quad_curr = curr_pts[in_quad] - np.array([x, y])
        _, quad_angle = analyze_vectors(quad_prev, quad_curr)
        quad_common = most_common_angle(quad_angle)
        diff = np.abs(quad_angle - quad_common)
        mask[(diff > ABSDIFF_ANGLE) & (quad_prev[:, 0] >= 0) & (quad_prev[:, 1] >= 0)] = 255
        masks.append(mask)
    return masks

def draw_vectors(frame, prev_pts, curr_pts, color=(0, 255, 0)):
    for (x0, y0), (x1, y1) in zip(prev_pts, curr_pts):
        cv2.arrowedLine(frame, (x0, y0), (x1, y1), color, 1, tipLength=0.3)

def main():
    args = parse_arguments()
    cap = init_capture(args.video)

    ret, frame = cap.read()
    if not ret:
        sys.exit("Error: Cannot read frame")
    frame = resize_frame(frame)
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    prev_pts = get_random_points(gray)
    crazy_lines = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            break
        frame = resize_frame(frame)
        gray_new = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        prev_pts, curr_pts, st = compute_motion(gray, gray_new, prev_pts)
        if len(prev_pts) < 2:
            prev_pts = get_random_points(gray_new)
            gray = gray_new
            continue

        dist, angle = analyze_vectors(prev_pts, curr_pts)
        crazy_lines = np.sum(dist > 10)
        common_angle = most_common_angle(angle)

        mask_delta = create_mask_delta(frame.shape, prev_pts, angle, common_angle)
        mask_biggest, largest_area = process_contours(mask_delta, frame.shape)

        # Scene change detection
        area_threshold = (frame.shape[0] * frame.shape[1]) / DELTA_LIMIT_DIVISOR
        if largest_area > area_threshold or crazy_lines > CRAZY_LINE_LIMIT:
            print("Scene transition detected. Exiting loop.")
            break

        # Quadrant analysis if many large contours
        if len(prev_pts) > CONTOUR_LIMIT:
            quadrant_masks = quadrant_analysis(frame, prev_pts, curr_pts, angle, common_angle)

        # Visualizations
        vis = frame.copy()
        draw_vectors(vis, prev_pts, curr_pts)
        if mask_biggest is not None:
            vis = cv2.bitwise_and(vis, vis, mask=mask_biggest)
        vis = cv2.cvtColor(mask_delta, cv2.COLOR_GRAY2BGR)

        cv2.imshow("Motion Vectors", vis)
        key = cv2.waitKey(1)
        if key == 27:  # ESC
            break

        gray = gray_new

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()