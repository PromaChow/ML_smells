import tensorflow as tf

def mixup(x1, x2, y1, y2, beta, alg):
    """
    Perform mixup or mixmatch data augmentation.

    Args:
        x1: Tensor of shape [batch, ...] (first batch of images).
        x2: Tensor of shape [batch, ...] (second batch of images).
        y1: Tensor of shape [batch, num_classes] (first batch of labels).
        y2: Tensor of shape [batch, num_classes] (second batch of labels).
        beta: Tensor of mixing coefficients. Expected to broadcast to x shapes.
        alg: String specifying algorithm ('mixmatch', 'mixup', or 'vat').

    Returns:
        Tuple (x, y) where x and y are the mixed images and labels.
    """
    beta = tf.maximum(beta, 1.0 - beta)

    if alg == "mixmatch":
        x = beta * x1 + (1.0 - beta) * x2
        y = beta * y1 + (1.0 - beta) * y2
    elif alg in ("mixup", "vat"):
        x = beta * x1 + (1.0 - beta) * x2
        # Extract the first spatial channel for label mixing
        beta_label = beta[..., 0, 0]
        beta_label = tf.expand_dims(beta_label, -1)  # shape [batch, 1]
        y = beta_label * y1 + (1.0 - beta_label) * y2
    else:
        raise ValueError(f"Unknown algorithm: {alg}")

    return x, y


def ssl_loss_mixup(labels_x, logits_x, labels_u, logits_u):
    """
    Compute mean cross-entropy losses for labeled and unlabeled data.

    Args:
        labels_x: Tensor of shape [batch, num_classes] (one-hot labels for labeled data).
        logits_x: Tensor of shape [batch, num_classes] (logits for labeled data).
        labels_u: Tensor of shape [batch, num_classes] (one-hot pseudo-labels for unlabeled data).
        logits_u: Tensor of shape [batch, num_classes] (logits for unlabeled data).

    Returns:
        Tuple (loss_x, loss_u) where each element is a scalar Tensor representing the mean loss.
    """
    loss_x = tf.nn.softmax_cross_entropy_with_logits(labels=labels_x, logits=logits_x)
    loss_x = tf.reduce_mean(loss_x)

    loss_u = tf.nn.softmax_cross_entropy_with_logits(labels=labels_u, logits=logits_u)
    loss_u = tf.reduce_mean(loss_u)

    return loss_x, loss_u

