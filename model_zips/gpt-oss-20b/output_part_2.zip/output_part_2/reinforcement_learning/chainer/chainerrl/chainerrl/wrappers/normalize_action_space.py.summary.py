import gym
import numpy as np

class NormalizeActionSpace:
    def __init__(self, env: gym.Env):
        if not isinstance(env.action_space, gym.spaces.Box):
            raise TypeError("NormalizeActionSpace requires a Box action space.")
        self.env = env
        self.original_low = env.action_space.low
        self.original_high = env.action_space.high
        self.shape = env.action_space.shape
        self.dtype = env.action_space.dtype

        self.action_space = gym.spaces.Box(
            low=np.full(self.shape, -1, dtype=self.dtype),
            high=np.full(self.shape, 1, dtype=self.dtype),
            dtype=self.dtype,
        )

    def action(self, action):
        act = np.asarray(action, dtype=self.dtype).copy()
        act = act + 1
        scale = (self.original_high - self.original_low) / 2
        act = act * scale
        act = act + self.original_low
        return act

    def reset(self, **kwargs):
        return self.env.reset(**kwargs)

    def step(self, action, **kwargs):
        normalized_action = self.action(action)
        return self.env.step(normalized_action, **kwargs)