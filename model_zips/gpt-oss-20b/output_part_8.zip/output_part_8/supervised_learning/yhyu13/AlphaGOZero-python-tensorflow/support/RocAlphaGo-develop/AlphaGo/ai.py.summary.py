import math
import random
from dataclasses import dataclass, field
from typing import List, Dict, Callable, Optional, Any, Tuple

# Basic representation of a move. An "eye" move is marked for filtering.
@dataclass(frozen=True)
class Move:
    x: int
    y: int
    is_eye: bool = False

    def __repr__(self):
        return f"Move({self.x},{self.y})"

# Special pass move
PASS_MOVE = Move(-1, -1, is_eye=False)

# Placeholder for a game state. In a real implementation this would contain board, history, etc.
class GameState:
    def __init__(self, history: Optional[List[Move]] = None):
        self._history = history or []

    def get_move_history(self) -> List[Move]:
        return self._history

    def get_legal_moves(self) -> List[Move]:
        # Dummy implementation: returns a fixed set of moves
        moves = [Move(x, y) for x in range(5) for y in range(5)]
        # Mark some moves as eyes arbitrarily
        for m in moves:
            if (m.x + m.y) % 3 == 0:
                object.__setattr__(m, 'is_eye', True)
        return moves

    def play_move(self, move: Move):
        self._history.append(move)

    def is_pass(self, move: Move) -> bool:
        return move is PASS_MOVE

# Base player interface
class Player:
    def get_move(self, state: GameState) -> Move:
        raise NotImplementedError

# Greedy policy player
class GreedyPolicyPlayer(Player):
    def __init__(self, policy_function: Callable[[GameState, List[Move]], Dict[Move, float]],
                 pass_when_offered: bool = False,
                 move_limit: int = 1000):
        self.policy_function = policy_function
        self.pass_when_offered = pass_when_offered
        self.move_limit = move_limit

    def get_move(self, state: GameState) -> Move:
        history = state.get_move_history()
        # Move limit check
        if len(history) >= self.move_limit:
            return PASS_MOVE
        # Passing condition
        if self.pass_when_offered and len(history) > 100:
            if history and state.is_pass(history[-1]):
                return PASS_MOVE
        # Generate legal moves excluding eyes
        legal_moves = [m for m in state.get_legal_moves() if not m.is_eye]
        if not legal_moves:
            return PASS_MOVE
        probs = self.policy_function(state, legal_moves)
        # Choose move with highest probability
        best_move = max(probs.items(), key=lambda kv: kv[1])[0]
        return best_move

# Probabilistic policy player with temperature and optional greedy switch
class ProbabilisticPolicyPlayer(Player):
    def __init__(self,
                 policy_function: Callable[[GameState, List[Move]], Dict[Move, float]],
                 temperature: float = 1.0,
                 pass_when_offered: bool = False,
                 move_limit: int = 1000,
                 greedy_start: Optional[int] = None):
        self.policy_function = policy_function
        self.temperature = temperature
        self.pass_when_offered = pass_when_offered
        self.move_limit = move_limit
        self.greedy_start = greedy_start

    def _adjust_probs(self, probs: Dict[Move, float]) -> Dict[Move, float]:
        # Apply temperature scaling using log transformation
        if self.temperature <= 0:
            raise ValueError("Temperature must be positive")
        adjusted = {}
        for move, p in probs.items():
            if p <= 0:
                continue
            adjusted[move] = math.exp(math.log(p) / self.temperature)
        total = sum(adjusted.values())
        if total == 0:
            # fallback: uniform distribution
            n = len(adjusted)
            for move in adjusted:
                adjusted[move] = 1.0 / n
        else:
            for move in adjusted:
                adjusted[move] /= total
        return adjusted

    def get_move(self, state: GameState) -> Move:
        history = state.get_move_history()
        if len(history) >= self.move_limit:
            return PASS_MOVE
        if self.pass_when_offered and len(history) > 100:
            if history and state.is_pass(history[-1]):
                return PASS_MOVE
        legal_moves = [m for m in state.get_legal_moves() if not m.is_eye]
        if not legal_moves:
            return PASS_MOVE
        probs = self.policy_function(state, legal_moves)
        if self.greedy_start is not None and len(history) >= self.greedy_start:
            return max(probs.items(), key=lambda kv: kv[1])[0]
        adjusted = self._adjust_probs(probs)
        # Sample move according to adjusted distribution
        r = random.random()
        cumulative = 0.0
        for move, p in adjusted.items():
            cumulative += p
            if r <= cumulative:
                return move
        # Fallback
        return PASS_MOVE

    def get_moves(self, states: List[GameState]) -> List[Move]:
        moves = []
        for state in states:
            moves.append(self.get_move(state))
        return moves

# Simple MCTS node
class MCTSNode:
    def __init__(self, state: GameState, parent: Optional["MCTSNode"] = None, move: Optional[Move] = None):
        self.state = state
        self.parent = parent
        self.move = move
        self.children: Dict[Move, MCTSNode] = {}
        self.visits = 0
        self.total_value = 0.0

    def is_fully_expanded(self) -> bool:
        return len(self.children) == len([m for m in self.state.get_legal_moves() if not m.is_eye])

    def best_child(self, c_puct: float) -> "MCTSNode":
        best_score = -float("inf")
        best_child = None
        for child in self.children.values():
            if child.visits == 0:
                ucb = float("inf")
            else:
                exploitation = child.total_value / child.visits
                exploration = c_puct * math.sqrt(math.log(self.visits) / child.visits)
                ucb = exploitation + exploration
            if ucb > best_score:
                best_score = ucb
                best_child = child
        return best_child

    def expand(self, policy_function: Callable[[GameState, List[Move]], Dict[Move, float]]):
        legal_moves = [m for m in self.state.get_legal_moves() if not m.is_eye]
        for move in legal_moves:
            if move not in self.children:
                new_state = self._simulate_move(self.state, move)
                self.children[move] = MCTSNode(new_state, parent=self, move=move)
                break

    @staticmethod
    def _simulate_move(state: GameState, move: Move) -> GameState:
        new_state = GameState(history=state.get_move_history().copy())
        new_state.play_move(move)
        return new_state

    def backpropagate(self, value: float):
        node = self
        while node is not None:
            node.visits += 1
            node.total_value += value
            node = node.parent

# Simplified MCTS
class MCTS:
    def __init__(self,
                 value_function: Callable[[GameState], float],
                 policy_function: Callable[[GameState, List[Move]], Dict[Move, float]],
                 rollout_function: Callable[[GameState], float],
                 lmbda: float = 0.0,
                 c_puct: float = 1.4,
                 rollout_limit: int = 10,
                 playout_depth: int = 20,
                 n_playout: int = 100):
        self.value_function = value_function
        self.policy_function = policy_function
        self.rollout_function = rollout_function
        self.lmbda = lmbda
        self.c_puct = c_puct
        self.rollout_limit = rollout_limit
        self.playout_depth = playout_depth
        self.n_playout = n_playout

    def best_move(self, root_state: GameState) -> Move:
        root = MCTSNode(root_state)
        for _ in range(self.n_playout):
            node = root
            # Selection
            while node.is_fully_expanded() and node.children:
                node = node.best_child(self.c_puct)
            # Expansion
            if not node.is_fully_expanded():
                node.expand(self.policy_function)
                node = node.best_child(self.c_puct)
            # Simulation
            value = self.rollout(node.state)
            # Backpropagation
            node.backpropagate(value)
        # Return move leading to best child
        best_child = max(root.children.values(), key=lambda n: n.visits)
        return best_child.move

    def rollout(self, state: GameState) -> float:
        for _ in range(self.playout_depth):
            legal_moves = [m for m in state.get_legal_moves() if not m.is_eye]
            if not legal_moves:
                break
            move = random.choice(legal_moves)
            state = MCTSNode._simulate_move(state, move)
        return self.rollout_function(state)

# MCTS player
class MCTSPlayer(Player):
    def __init__(self,
                 value_function: Callable[[GameState], float],
                 policy_function: Callable[[GameState, List[Move]], Dict[Move, float]],
                 rollout_function: Callable[[GameState], float],
                 lmbda: float = 0.0,
                 c_puct: float = 1.4,
                 rollout_limit: int = 10,
                 playout_depth: int = 20,
                 n_playout: int = 100):
        self.mcts = MCTS(value_function, policy_function, rollout_function,
                         lmbda, c_puct, rollout_limit, playout_depth, n_playout)

    def get_move(self, state: GameState) -> Move:
        legal_moves = [m for m in state.get_legal_moves() if not m.is_eye]
        if not legal_moves:
            return PASS_MOVE
        move = self.mcts.best_move(state)
        return move
