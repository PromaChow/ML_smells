import math
import random
import numpy as np
import pyglet
from pyglet import shapes

class TwoJointArmEnv:
    def __init__(self):
        self.length1 = 100.0
        self.length2 = 100.0
        self.base = np.array([200.0, 200.0])
        self.goal_center = np.array([100.0, 100.0])
        self.goal_size = 40.0
        self.dt = 0.1
        self.viewer = None
        self.state = None
        self.reset()

    def reset(self):
        self.state = np.random.uniform(0.0, 2.0 * math.pi, size=2)
        return self.state.copy()

    def step(self, action):
        action = np.clip(action, -1.0, 1.0)
        self.state = (self.state + self.dt * action) % (2.0 * math.pi)

        theta1, theta2 = self.state
        joint1 = self.base + self.length1 * np.array([math.cos(theta1), math.sin(theta1)])
        end = joint1 + self.length2 * np.array([math.cos(theta1 + theta2), math.sin(theta1 + theta2)])

        in_goal = (self.goal_center[0] <= end[0] <= self.goal_center[0] + self.goal_size and
                   self.goal_center[1] <= end[1] <= self.goal_center[1] + self.goal_size)
        reward = 1.0 if in_goal else 0.0
        done = in_goal

        return self.state.copy(), reward, done

    def render(self):
        if self.viewer is None:
            self.viewer = pyglet.window.Window(width=400, height=400, caption="Two Joint Arm")
            self.goal_rect = shapes.Rectangle(
                int(self.goal_center[0]),
                int(self.goal_center[1]),
                int(self.goal_size),
                int(self.goal_size),
                color=(0, 0, 255),
            )
            self.line1 = shapes.Line(
                self.base[0], self.base[1], self.base[0], self.base[1],
                width=5,
                color=(255, 0, 0),
            )
            self.line2 = shapes.Line(
                self.base[0], self.base[1], self.base[0], self.base[1],
                width=5,
                color=(255, 0, 0),
            )

            @self.viewer.event
            def on_draw():
                self.viewer.clear()
                self.goal_rect.draw()

                theta1, theta2 = self.state
                joint1 = self.base + self.length1 * np.array([math.cos(theta1), math.sin(theta1)])
                end = joint1 + self.length2 * np.array([math.cos(theta1 + theta2), math.sin(theta1 + theta2)])

                self.line1.x2 = joint1[0]
                self.line1.y2 = joint1[1]
                self.line2.x1 = joint1[0]
                self.line2.y1 = joint1[1]
                self.line2.x2 = end[0]
                self.line2.y2 = end[1]

                self.line1.draw()
                self.line2.draw()

        # Trigger the window to update
        self.viewer.dispatch_events()
        self.viewer.switch_to()
        self.viewer.dispatch_events()
        pyglet.clock.tick()

    def sample_action(self):
        return np.random.uniform(-0.5, 0.5, size=2)