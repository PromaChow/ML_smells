import tensorflow as tf

flags = tf.compat.v1.app.flags
FLAGS = flags.FLAGS


def flags_to_dict():
    """Convert all TensorFlow flags to a dictionary."""
    return {name: getattr(FLAGS, name) for name in getattr(FLAGS, "__flags__", [])}


def get_config():
    """Initialize all flags for the experiment configuration."""
    if not getattr(FLAGS, "defined", False):
        # Global settings
        flags.DEFINE_string("experimenter", "JSH", "Experimenter name.")
        flags.DEFINE_string("use_gpu", "0", "GPU device to use.")
        flags.DEFINE_integer("seed", 0, "Random seed.")
        flags.DEFINE_integer("number_of_labels", 250, "Number of labels.")

        # Dataset configuration
        flags.DEFINE_integer(
            "number_of_loading_dataset", 10000, "Samples to load from dataset."
        )
        flags.DEFINE_integer("number_of_loader", 1, "Number of loaders.")
        flags.DEFINE_integer(
            "number_of_batch_loader", 2, "Number of batch loaders."
        )
        flags.DEFINE_integer("max_size_of_loader", 2, "Maximum size per loader.")
        flags.DEFINE_integer(
            "max_size_of_batch_loader", 2, "Maximum batch size per loader."
        )
        flags.DEFINE_integer(
            "number_of_labeled_decoder", 1, "Number of labeled decoders."
        )
        flags.DEFINE_integer(
            "max_size_of_labeled_decoder", 16, "Maximum size per labeled decoder."
        )
        flags.DEFINE_integer(
            "number_of_unlabeled_decoder", 32, "Number of unlabeled decoders."
        )
        flags.DEFINE_integer(
            "max_size_of_unlabeled_decoder", 2048, "Maximum size per unlabeled decoder."
        )

        # Training schedule
        flags.DEFINE_float("learning_rate", 0.03, "Initial learning rate.")
        flags.DEFINE_integer("batch_size", 64, "Batch size.")
        flags.DEFINE_integer("logging_interval", 100, "Iterations between logs.")
        flags.DEFINE_integer(
            "validation_interval", 10000, "Iterations between validations."
        )
        flags.DEFINE_integer("max_epochs", 1024, "Maximum training epochs.")
        flags.DEFINE_integer("train_kimgs", 65536, "Training kilo-images.")
        flags.DEFINE_integer(
            "max_iteration", 1048576, "Maximum training iterations."
        )

        # FixMatch-specific training technology
        flags.DEFINE_integer("unlabeled_ratio", 7, "Ratio of unlabeled to labeled data.")
        flags.DEFINE_string("augmentation_weak", "flip_and_crop", "Weak augmentation.")
        flags.DEFINE_string("augmentation_strong", "randaugment", "Strong augmentation.")
        flags.DEFINE_float("ema_decay", 0.999, "EMA decay.")
        flags.DEFINE_float("weight_decay", 0.0005, "Weight decay.")
        flags.DEFINE_float("lambda_u", 1.0, "Unlabeled loss weight.")
        flags.DEFINE_float(
            "confidence_threshold", 0.95, "Threshold for pseudo-label confidence."
        )

        # Testing configuration
        flags.DEFINE_string("ckpt_path", None, "Checkpoint path.")

        FLAGS.defined = True
    return FLAGS


if __name__ == "__main__":
    config = get_config()
    print("use_gpu:", config.use_gpu)
    print("Flags dictionary:")
    print(flags_to_dict())