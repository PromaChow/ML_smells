import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from collections import deque
from typing import List, Tuple, Dict, Any

class OnPolicyMemory:
    def __init__(self, env_num: int, n_steps: int):
        self.env_num = env_num
        self.n_steps = n_steps
        self.memories: List[deque] = [deque(maxlen=n_steps) for _ in range(env_num)]

    def push(self, env_id: int, transition: Tuple[np.ndarray, int, float, np.ndarray, bool]):
        self.memories[env_id].append(transition)

    def get_all(self) -> List[Tuple[np.ndarray, int, float, np.ndarray, bool]]:
        transitions = []
        for mem in self.memories:
            transitions.extend(list(mem))
        return transitions

    def clear(self):
        for mem in self.memories:
            mem.clear()

class A2C(nn.Module):
    def __init__(
        self,
        observation_shape: Tuple[int, ...],
        action_space: int,
        base_model: nn.Module,
        env_num: int,
        n_steps: int,
        lr: float = 3e-3,
        gamma: float = 0.99,
        value_loss_coeff: float = 0.5,
        entropy_loss_coeff: float = 0.01,
        epsilon_start: float = 0.5,
        epsilon_end: float = 0.01,
        epsilon_decay: float = 1e-4,
    ):
        super().__init__()
        self.base = base_model
        self.actor = nn.Linear(self.base.output_dim, action_space)
        self.critic = nn.Linear(self.base.output_dim, 1)
        self.action_space = action_space
        self.env_num = env_num
        self.n_steps = n_steps
        self.gamma = gamma
        self.value_loss_coeff = value_loss_coeff
        self.entropy_loss_coeff = entropy_loss_coeff
        self.optimizer = optim.Adam(self.parameters(), lr=lr)
        self.memory = OnPolicyMemory(env_num, n_steps)
        self.epsilon = epsilon_start
        self.epsilon_start = epsilon_start
        self.epsilon_end = epsilon_end
        self.epsilon_decay = epsilon_decay

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        features = self.base(x)
        logits = self.actor(features)
        value = self.critic(features)
        return logits, value

    def act(self, state: np.ndarray, training: bool = True) -> int:
        state_t = torch.FloatTensor(state).unsqueeze(0)
        logits, _ = self.forward(state_t)
        probs = torch.softmax(logits, dim=-1).detach().cpu().numpy().squeeze()
        if training:
            if np.random.rand() < self.epsilon:
                return np.random.choice(self.action_space)
            else:
                return np.argmax(probs)
        else:
            return np.argmax(probs)

    def compute_loss(
        self,
        logits: torch.Tensor,
        values: torch.Tensor,
        actions: torch.Tensor,
        returns: torch.Tensor,
    ) -> torch.Tensor:
        log_probs = nn.functional.log_softmax(logits, dim=-1)
        action_log_probs = log_probs.gather(1, actions.unsqueeze(1)).squeeze()
        advantages = returns - values.squeeze()
        policy_loss = -(advantages * action_log_probs).mean()
        value_loss = (returns - values.squeeze()).pow(2).mean() * self.value_loss_coeff
        entropy = - (log_probs * torch.exp(log_probs)).sum(-1).mean()
        entropy_loss = -entropy * self.entropy_loss_coeff
        total_loss = policy_loss + value_loss + entropy_loss
        return total_loss

    def update_epsilon(self):
        self.epsilon = max(self.epsilon_end, self.epsilon - self.epsilon_decay)

    def train_step(self):
        transitions = self.memory.get_all()
        if not transitions:
            return
        states, actions, rewards, next_states, dones = zip(*transitions)
        states_t = torch.FloatTensor(states)
        actions_t = torch.LongTensor(actions)
        rewards_t = torch.FloatTensor(rewards)
        next_states_t = torch.FloatTensor(next_states)
        dones_t = torch.FloatTensor(dones)

        with torch.no_grad():
            _, next_values = self.forward(next_states_t)
            next_values = next_values.squeeze()
            returns = torch.zeros_like(rewards_t)
            gae = 0
            for i in reversed(range(len(rewards_t))):
                mask = 1.0 - dones_t[i]
                delta = rewards_t[i] + self.gamma * next_values[i] * mask - values.squeeze()[i]
                gae = delta + self.gamma * 0.95 * mask * gae
                returns[i] = gae + values.squeeze()[i]

        logits, values = self.forward(states_t)
        loss = self.compute_loss(logits, values, actions_t, returns)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        self.memory.clear()
        self.update_epsilon()

    def push(self, env_id: int, transition: Tuple[np.ndarray, int, float, np.ndarray, bool]):
        self.memory.push(env_id, transition)
```