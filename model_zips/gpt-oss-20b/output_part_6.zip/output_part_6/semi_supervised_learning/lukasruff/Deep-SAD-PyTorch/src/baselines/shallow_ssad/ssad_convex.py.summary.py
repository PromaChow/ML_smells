import numpy as np
import cvxopt
from cvxopt import matrix, solvers

PRECISION = 1e-9

class ConvexSemiSupervisedAnomalyDetection:
    def __init__(self, kernel, y, kappa=1.0, Cp=1.0, Cu=1.0, Cn=1.0):
        self.kernel = np.asarray(kernel, dtype=np.float64)
        self.y = np.asarray(y, dtype=np.int32)
        self.kappa = kappa
        self.Cp = Cp
        self.Cu = Cu
        self.Cn = Cn
        self.alphas = None
        self.cy = None
        self.cl = None
        self.cC = None
        self.rho = None
        self._prepare_labels()
        self._solve_qp()

    def _prepare_labels(self):
        self.cy = np.where(self.y == 0, 1, self.y).astype(np.int32)
        self.cl = (self.y != 0).astype(np.int32)
        cC = np.where(self.y == 1, self.Cp, np.where(self.y == -1, self.Cn, self.Cu))
        if np.sum(self.cl) == 0:
            self.kappa = 0.0
        self.cC = cC.astype(np.float64)

    def _solve_qp(self):
        N = self.kernel.shape[0]
        Y = self.cy.reshape(-1, 1) * self.cy.reshape(1, -1)
        P = (Y * self.kernel).astype(np.float64)
        q = np.zeros(N, dtype=np.float64)

        # Inequality constraints Gx <= h
        G_box = -np.eye(N, dtype=np.float64)
        h_box = np.zeros(N, dtype=np.float64)

        G_box2 = np.eye(N, dtype=np.float64)
        h_box2 = self.cC.copy()

        G1 = np.vstack([G_box, G_box2])
        h1 = np.hstack([h_box, h_box2])

        if self.kappa > 0:
            G2 = -self.cl.reshape(1, -1)
            h2 = np.array([-self.kappa], dtype=np.float64)
            G = np.vstack([G1, G2])
            h = np.hstack([h1, h2])
        else:
            G = G1
            h = h1

        A = self.cy.reshape(1, -1)
        b = np.array([1.0], dtype=np.float64)

        P_cvx = matrix(P)
        q_cvx = matrix(q)
        G_cvx = matrix(G)
        h_cvx = matrix(h)
        A_cvx = matrix(A)
        b_cvx = matrix(b)

        solvers.options['show_progress'] = False
        sol = solvers.qp(P_cvx, q_cvx, G_cvx, h_cvx, A_cvx, b_cvx)
        self.alphas = np.asarray(sol['x']).reshape(-1)

        self._post_process()

    def _post_process(self):
        sv = self.alphas >= PRECISION
        # Check constraints
        assert abs(np.sum(self.alphas * self.cy) - 1.0) < 1e-6
        if np.sum(self.cl) > 0:
            assert np.sum(self.alphas[self.cl == 1]) >= self.kappa - 1e-6

        # Threshold estimation
        alpha_cy = self.alphas * self.cy
        # Unlabeled support vectors
        unlabeled_sv = np.where((self.cl == 0) & sv)[0]
        if unlabeled_sv.size > 0:
            f_unlabeled = alpha_cy @ self.kernel[unlabeled_sv, :].T
            t1 = np.max(f_unlabeled)
        else:
            t1 = -np.inf

        # Labeled support vectors
        labeled_sv = np.where((self.cl == 1) & sv)[0]
        if labeled_sv.size > 0:
            f_labeled = alpha_cy @ self.kernel[labeled_sv, :].T
            pos_vals = f_labeled[self.cy[labeled_sv] == 1]
            neg_vals = f_labeled[self.cy[labeled_sv] == -1]
            if pos_vals.size > 0 and neg_vals.size > 0:
                t2 = (pos_vals.max() + neg_vals.min()) / 2.0
            else:
                t2 = -np.inf
        else:
            t2 = -np.inf

        self.rho = max(t1, t2)

    def get_threshold(self):
        return self.rho

    def get_support_dual(self):
        return np.where(self.alphas >= PRECISION)[0]

    def get_alphas(self):
        return self.alphas

    def apply(self, kernel_test):
        kernel_test = np.asarray(kernel_test, dtype=np.float64)
        f = (self.alphas * self.cy) @ kernel_test - self.rho
        return f
