import tensorflow as tf
import gym
import numpy as np

class InGraphBatchEnv:
    def __init__(self, batch_env):
        self.batch_env = batch_env
        self.batch_size = len(batch_env)

        # Parse observation space
        obs_space = batch_env.observation_space
        self._obs_shape = self._parse_shape(obs_space)
        self._obs_dtype = self._parse_dtype(obs_space)

        # Parse action space
        act_space = batch_env.action_space
        self._act_shape = self._parse_shape(act_space)
        self._act_dtype = self._parse_dtype(act_space)

        # Variables to hold state
        self._observ = tf.Variable(
            tf.zeros([self.batch_size] + list(self._obs_shape), dtype=self._obs_dtype),
            trainable=False, name="observ")
        self._action = tf.Variable(
            tf.zeros([self.batch_size] + list(self._act_shape), dtype=self._act_dtype),
            trainable=False, name="action")
        self._reward = tf.Variable(
            tf.zeros([self.batch_size], dtype=tf.float32),
            trainable=False, name="reward")
        self._done = tf.Variable(
            tf.zeros([self.batch_size], dtype=tf.bool),
            trainable=False, name="done")

    def __getattr__(self, name):
        return getattr(self.batch_env, name)

    def __len__(self):
        return self.batch_size

    def __getitem__(self, idx):
        return self.batch_env[idx]

    @property
    def observ(self):
        return self._observ

    @property
    def action(self):
        return self._action

    @property
    def reward(self):
        return self._reward

    @property
    def done(self):
        return self._done

    def simulate(self, actions):
        actions = tf.convert_to_tensor(actions, dtype=self._act_dtype)
        actions = tf.check_numerics(actions, "actions contain NaN or Inf")
        result = tf.compat.v1.py_func(
            self._step_func,
            [actions],
            [self._obs_dtype, tf.float32, tf.bool]
        )
        new_observ, new_reward, new_done = result
        new_observ = tf.ensure_shape(new_observ, [self.batch_size] + list(self._obs_shape))
        new_reward = tf.ensure_shape(new_reward, [self.batch_size])
        new_done = tf.ensure_shape(new_done, [self.batch_size])

        self._observ.assign(new_observ)
        self._action.assign(actions)
        self._reward.assign(new_reward)
        self._done.assign(new_done)

        return new_observ, new_reward, new_done

    def reset(self, indices=None):
        indices_np = None if indices is None else np.array(indices, dtype=np.int64)
        new_observ = tf.compat.v1.py_func(
            self._reset_func,
            [indices_np],
            [self._obs_dtype]
        )
        new_observ = tf.ensure_shape(new_observ, [self.batch_size] + list(self._obs_shape))
        self._observ.assign(new_observ)
        self._reward.assign(tf.zeros([self.batch_size], dtype=tf.float32))
        self._done.assign(tf.zeros([self.batch_size], dtype=tf.bool))

    def close(self):
        self.batch_env.close()

    def _step_func(self, actions_np):
        obs_np, reward_np, done_np = self.batch_env.step(actions_np)
        return obs_np.astype(self._obs_dtype.as_numpy_dtype), reward_np.astype(np.float32), done_np.astype(np.bool_)

    def _reset_func(self, indices_np):
        if indices_np is None:
            obs_np = self.batch_env.reset()
        else:
            obs_np = self.batch_env.reset(indices=indices_np)
        return obs_np.astype(self._obs_dtype.as_numpy_dtype)

    def _parse_shape(self, space):
        if isinstance(space, gym.spaces.Box):
            return space.shape
        elif isinstance(space, gym.spaces.Discrete):
            return (1,)
        else:
            raise ValueError(f"Unsupported space type: {type(space)}")

    def _parse_dtype(self, space):
        if isinstance(space, gym.spaces.Box):
            return tf.as_dtype(space.dtype)
        elif isinstance(space, gym.spaces.Discrete):
            return tf.int32
        else:
            raise ValueError(f"Unsupported space type: {type(space)}")