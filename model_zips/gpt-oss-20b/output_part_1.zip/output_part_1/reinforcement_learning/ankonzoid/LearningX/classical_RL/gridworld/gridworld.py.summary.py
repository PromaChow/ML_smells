import numpy as np
import random

class GridWorld:
    def __init__(self, Ny, Nx):
        self.Ny, self.Nx = Ny, Nx
        self.goal = (Ny - 1, Nx - 1)
        self.actions = {
            0: (-1, 0),  # up
            1: (0, 1),   # right
            2: (1, 0),   # down
            3: (0, -1)   # left
        }

    def allowed_actions(self, state):
        y, x = state
        allowed = []
        for a, (dy, dx) in self.actions.items():
            ny, nx = y + dy, x + dx
            if 0 <= ny < self.Ny and 0 <= nx < self.Nx:
                allowed.append(a)
        return allowed

    def step(self, state, action):
        y, x = state
        dy, dx = self.actions[action]
        ny, nx = y + dy, x + dx
        next_state = (ny, nx)
        done = next_state == self.goal
        reward = -0.1
        if done:
            if (state == (self.Ny - 2, self.Nx - 1)) or (state == (self.Ny - 1, self.Nx - 2)):
                reward = 100.0
        return next_state, reward, done

class QLearningAgent:
    def __init__(self, env, epsilon=1.0, beta=0.99, gamma=0.99, epsilon_decay=0.99, epsilon_min=0.01):
        self.env = env
        self.Q = np.zeros((env.Ny, env.Nx, 4))
        self.epsilon = epsilon
        self.beta = beta
        self.gamma = gamma
        self.epsilon_decay = epsilon_decay
        self.epsilon_min = epsilon_min

    def choose_action(self, state):
        if random.random() < self.epsilon:
            return random.choice(self.env.allowed_actions(state))
        else:
            y, x = state
            allowed = self.env.allowed_actions(state)
            values = [self.Q[y, x, a] for a in allowed]
            max_value = max(values)
            best_actions = [a for a, v in zip(allowed, values) if v == max_value]
            return random.choice(best_actions)

    def learn(self, episodes=500):
        for episode in range(1, episodes + 1):
            state = (0, 0)
            done = False
            steps = 0
            total_reward = 0.0
            while not done:
                action = self.choose_action(state)
                next_state, reward, done = self.env.step(state, action)
                y, x = state
                max_next = np.max(self.Q[next_state[0], next_state[1], :])
                self.Q[y, x, action] += self.beta * (reward + self.gamma * max_next - self.Q[y, x, action])
                state = next_state
                steps += 1
                total_reward += reward
            self.epsilon = max(self.epsilon * self.epsilon_decay, self.epsilon_min)
            if episode % 10 == 0:
                print(f"Episode {episode}: epsilon={self.epsilon:.4f}, steps={steps}, cumulative_reward={total_reward:.2f}")

    def policy_grid(self):
        grid = []
        for y in range(self.env.Ny):
            row = []
            for x in range(self.env.Nx):
                if (y, x) == self.env.goal:
                    row.append(-1)
                else:
                    allowed = self.env.allowed_actions((y, x))
                    values = [self.Q[y, x, a] for a in allowed]
                    max_value = max(values)
                    best_actions = [a for a, v in zip(allowed, values) if v == max_value]
                    row.append(random.choice(best_actions))
            grid.append(row)
        return grid

def main():
    Ny, Nx = 5, 5
    env = GridWorld(Ny, Nx)
    agent = QLearningAgent(env)
    agent.learn(episodes=500)
    policy = agent.policy_grid()
    action_map = {0: 'U', 1: 'R', 2: 'D', 3: 'L', -1: 'G'}
    print("\nLearned Policy Grid (U=up, R=right, D=down, L=left, G=goal):")
    for row in policy:
        print(' '.join(action_map[a] for a in row))

if __name__ == "__main__":
    main()