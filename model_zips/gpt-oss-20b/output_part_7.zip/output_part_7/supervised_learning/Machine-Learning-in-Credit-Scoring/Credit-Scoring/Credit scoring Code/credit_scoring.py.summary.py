import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.metrics import confusion_matrix, accuracy_score

def plot_confusion_matrix(cm, classes, title='Confusion matrix', cmap=plt.cm.Blues):
    plt.figure(figsize=(6, 4))
    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)
    thresh = cm.max() / 2.
    for i, j in np.ndindex(cm.shape):
        plt.text(j, i, format(cm[i, j], 'd'),
                 horizontalalignment="center",
                 color="white" if cm[i, j] > thresh else "black")
    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    # plt.show()  # Plot command is incomplete in the code

if __name__ == "__main__":
    # Load dataset
    df = pd.read_csv('estadistical.csv')

    # Define target and features
    target_col = 'Receive/ Not receive credit '
    y = df[target_col].astype(str).str.strip()
    X = df.drop(columns=[target_col])

    # Encode categorical variables
    label_encoders = {}
    for col in X.select_dtypes(include='object').columns:
        le = LabelEncoder()
        X[col] = le.fit_transform(X[col].astype(str).str.strip())
        label_encoders[col] = le

    # Train-test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, stratify=y, random_state=42
    )

    # K-Nearest Neighbors
    knn = KNeighborsClassifier(n_neighbors=10)
    knn.fit(X_train, y_train)
    knn_acc = knn.score(X_test, y_test)
    print(f'KNN Accuracy: {knn_acc:.4f}')

    # Random Forest
    rf = RandomForestClassifier(max_depth=2, random_state=42)
    rf.fit(X_train, y_train)
    rf_acc = rf.score(X_test, y_test)
    print(f'Random Forest Accuracy: {rf_acc:.4f}')

    # Logistic Regression
    logreg = LogisticRegression(class_weight='balanced', max_iter=1000, random_state=42)
    logreg.fit(X_train, y_train)
    y_pred_logreg = logreg.predict(X_test)
    logreg_acc = accuracy_score(y_test, y_pred_logreg)
    print(f'Logistic Regression Accuracy: {logreg_acc:.4f}')
    cm_logreg = confusion_matrix(y_test, y_pred_logreg)
    plot_confusion_matrix(cm_logreg, classes=np.unique(y))

    # Support Vector Machine
    svm = SVC(gamma='auto', class_weight='balanced', random_state=42)
    svm.fit(X_train, y_train)
    svm_acc = svm.score(X_test, y_test)
    print(f'SVM Accuracy: {svm_acc:.4f}')
