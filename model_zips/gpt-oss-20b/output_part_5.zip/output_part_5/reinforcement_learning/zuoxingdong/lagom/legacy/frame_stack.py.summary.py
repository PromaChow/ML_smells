import numpy as np
import gym
from gym.spaces import Box
from collections import deque
import lz4.block

class LazyFrames:
    def __init__(self, frames, lz4_compress=False):
        self.lz4_compress = lz4_compress
        if lz4_compress:
            # All frames are assumed to have the same shape and dtype
            self.dtype = frames[0].dtype
            self.shape = frames[0].shape
            self.frames = [lz4.block.compress(frame.tobytes()) for frame in frames]
        else:
            self.frames = frames
            self.dtype = frames[0].dtype
            self.shape = frames[0].shape

    def _to_array(self, dtype=None):
        if self.lz4_compress:
            frames = [np.frombuffer(lz4.block.decompress(f), dtype=self.dtype).reshape(self.shape) for f in self.frames]
        else:
            frames = self.frames
        array = np.stack(frames, axis=0)
        if dtype is not None:
            array = array.astype(dtype)
        return array

    def __array__(self, dtype=None):
        return self._to_array(dtype=dtype)

    def __len__(self):
        return len(self._to_array())

    def __getitem__(self, idx):
        return self._to_array()[idx]

    def __repr__(self):
        return f"<LazyFrames len={len(self)}>"


class FrameStack(gym.Wrapper):
    def __init__(self, env, num_stack=4, lz4_compress=False):
        super().__init__(env)
        self.num_stack = num_stack
        self.lz4_compress = lz4_compress
        self.frames = deque(maxlen=num_stack)

        # Adjust the observation space
        obs_space = env.observation_space
        if not isinstance(obs_space, Box):
            raise ValueError("FrameStack only supports Box observation spaces")
        low = np.stack([obs_space.low] * num_stack, axis=0)
        high = np.stack([obs_space.high] * num_stack, axis=0)
        shape = (num_stack,) + obs_space.shape
        self.observation_space = Box(low=low, high=high, dtype=obs_space.dtype, shape=shape)

    def reset(self, **kwargs):
        obs = self.env.reset(**kwargs)
        # Clear the deque and fill with the initial observation
        self.frames.clear()
        for _ in range(self.num_stack):
            self.frames.append(obs)
        return self._get_observation()

    def step(self, action):
        obs, reward, done, info = self.env.step(action)
        self.frames.append(obs)
        return self._get_observation(), reward, done, info

    def _get_observation(self):
        return LazyFrames(list(self.frames), lz4_compress=self.lz4_compress)