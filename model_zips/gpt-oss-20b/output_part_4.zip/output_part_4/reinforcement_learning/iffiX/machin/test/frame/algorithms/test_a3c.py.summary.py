import gym
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.multiprocessing as mp
import torch.distributed as dist
import unittest
import time
from collections import deque
from torch.distributed import rpc

# Simple static_module_wrapper that returns the module unchanged
def static_module_wrapper(module, device='cpu'):
    return module.to(device)


class ActorNetwork(nn.Module):
    def __init__(self, state_dim, action_dim):
        super().__init__()
        self.fc1 = nn.Linear(state_dim, 128)
        self.fc2 = nn.Linear(128, 128)
        self.fc3 = nn.Linear(128, action_dim)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        logits = self.fc3(x)
        probs = F.softmax(logits, dim=-1)
        log_probs = F.log_softmax(logits, dim=-1)
        entropy = -(log_probs * probs).sum(dim=-1)
        return probs, log_probs, entropy


class CriticNetwork(nn.Module):
    def __init__(self, state_dim):
        super().__init__()
        self.fc1 = nn.Linear(state_dim, 128)
        self.fc2 = nn.Linear(128, 128)
        self.fc3 = nn.Linear(128, 1)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        value = self.fc3(x)
        return value


class ReplayBuffer:
    def __init__(self, capacity=10000):
        self.capacity = capacity
        self.buffer = []

    def store(self, transition):
        if len(self.buffer) >= self.capacity:
            self.buffer.pop(0)
        self.buffer.append(transition)

    def sample(self, batch_size):
        indices = torch.randint(0, len(self.buffer), (batch_size,))
        batch = [self.buffer[i] for i in indices]
        return batch

    def clear(self):
        self.buffer = []


class A3C:
    def __init__(self, actor, critic, lr=5e-3, gamma=0.99, buffer_capacity=10000):
        self.actor = actor
        self.critic = critic
        self.gamma = gamma
        self.buffer = ReplayBuffer(buffer_capacity)
        self.actor_optimizer = torch.optim.Adam(self.actor.parameters(), lr=lr)
        self.critic_optimizer = torch.optim.Adam(self.critic.parameters(), lr=lr)

    def act(self, state):
        state = torch.tensor(state, dtype=torch.float32)
        probs, log_probs, entropy = self.actor(state)
        dist = torch.distributions.Categorical(probs)
        action = dist.sample()
        return action.item(), log_probs[action].item(), entropy.item()

    def _eval_act(self, state, action):
        state = torch.tensor(state, dtype=torch.float32)
        probs, log_probs, entropy = self.actor(state)
        return probs, log_probs[action], entropy

    def _criticize(self, state):
        state = torch.tensor(state, dtype=torch.float32)
        value = self.critic(state)
        return value.item()

    def store_episode(self, episode):
        for transition in episode:
            self.buffer.store(transition)

    def update(self, batch_size=32):
        if len(self.buffer.buffer) < batch_size:
            return
        batch = self.buffer.sample(batch_size)
        states, actions, rewards, dones, log_probs, entropies = zip(*batch)

        states = torch.tensor(states, dtype=torch.float32)
        actions = torch.tensor(actions, dtype=torch.int64)
        rewards = torch.tensor(rewards, dtype=torch.float32)
        dones = torch.tensor(dones, dtype=torch.float32)
        log_probs = torch.tensor(log_probs, dtype=torch.float32)
        entropies = torch.tensor(entropies, dtype=torch.float32)

        values = self.critic(states).squeeze()
        next_values = values.clone()
        next_values[-1] = 0  # for terminal state

        returns = rewards + self.gamma * next_values * (1 - dones)
        advantages = returns - values

        # Actor loss
        actor_loss = -(log_probs * advantages.detach() + 0.01 * entropies).mean()
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        self.actor_optimizer.step()

        # Critic loss
        critic_loss = F.mse_loss(values, returns.detach())
        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        self.critic_optimizer.step()

        self.buffer.clear()


class TestA3C(unittest.TestCase):
    def setUp(self):
        self.state_dim = 4
        self.action_dim = 2
        self.actor = static_module_wrapper(ActorNetwork(self.state_dim, self.action_dim))
        self.critic = static_module_wrapper(CriticNetwork(self.state_dim))
        self.agent = A3C(self.actor, self.critic)

    def test_act(self):
        state = [0.0] * self.state_dim
        action, logp, entropy = self.agent.act(state)
        self.assertIn(action, [0, 1])

    def test_eval_action(self):
        state = [0.0] * self.state_dim
        action = 0
        probs, logp, entropy = self.agent._eval_act(state, action)
        self.assertTrue(probs.shape[0] == self.action_dim)

    def test__criticize(self):
        state = [0.0] * self.state_dim
        value = self.agent._criticize(state)
        self.assertIsInstance(value, float)

    def test_update(self):
        dummy_episode = []
        for _ in range(5):
            state = [0.0] * self.state_dim
            action, logp, entropy = self.agent.act(state)
            reward = 0.0
            done = False
            dummy_episode.append((state, action, reward, done, logp, entropy))
        self.agent.store_episode(dummy_episode)
        self.agent.update()

    def test_config_initialization(self):
        config = {
            'actor_cls': ActorNetwork,
            'critic_cls': CriticNetwork,
            'actor_params': {'state_dim': self.state_dim, 'action_dim': self.action_dim},
            'critic_params': {'state_dim': self.state_dim},
            'lr': 5e-3,
            'gamma': 0.99,
            'buffer_capacity': 10000
        }
        actor = static_module_wrapper(config['actor_cls'](**config['actor_params']))
        critic = static_module_wrapper(config['critic_cls'](**config['critic_params']))
        agent = A3C(actor, critic,
                    lr=config['lr'],
                    gamma=config['gamma'],
                    buffer_capacity=config['buffer_capacity'])
        self.assertIsInstance(agent, A3C)


def train_worker(rank, world_size, return_dict):
    dist.init_process_group('gloo', rank=rank, world_size=world_size)
    env = gym.make('CartPole-v0')
    env.seed(42 + rank)
    torch.manual_seed(42 + rank)

    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.n

    actor = static_module_wrapper(ActorNetwork(state_dim, action_dim))
    critic = static_module_wrapper(CriticNetwork(state_dim))
    agent = A3C(actor, critic)

    max_episodes = 50
    max_steps = 200
    reward_threshold = 150
    moving_avg_window = 5
    rewards_window = deque(maxlen=moving_avg_window)

    for episode in range(max_episodes):
        state = env.reset()
        episode_transitions = []
        total_reward = 0.0
        for step in range(max_steps):
            action, logp, entropy = agent.act(state)
            next_state, reward, done, _ = env.step(action)
            total_reward += reward
            episode_transitions.append((state, action, reward, done, logp, entropy))
            state = next_state
            if done:
                break
        agent.store_episode(episode_transitions)
        agent.update()
        rewards_window.append(total_reward)
        if len(rewards_window) == moving_avg_window:
            avg_reward = sum(rewards_window) / moving_avg_window
            if avg_reward >= reward_threshold:
                return_dict['solved'] = True
                break
    dist.destroy_process_group()


if __name__ == '__main__':
    mp.set_start_method('spawn')
    manager = mp.Manager()
    return_dict = manager.dict()
    world_size = 3
    processes = []
    for rank in range(world_size):
        p = mp.Process(target=train_worker, args=(rank, world_size, return_dict))
        p.start()
        processes.append(p)
    for p in processes:
        p.join()
    solved = return_dict.get('solved', False)
    print(f"Training solved: {solved}")
    unittest.main(exit=False)