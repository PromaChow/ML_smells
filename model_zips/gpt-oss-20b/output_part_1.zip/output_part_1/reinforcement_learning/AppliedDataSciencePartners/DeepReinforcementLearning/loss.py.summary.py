import tensorflow as tf

def softmax_cross_entropy_with_logits(y_true: tf.Tensor, y_pred: tf.Tensor) -> tf.Tensor:
    pi = y_true
    p = y_pred
    zero = tf.zeros_like(pi)
    where = tf.equal(pi, 0.0)
    negatives = tf.fill(tf.shape(pi), -100.0)
    p = tf.where(where, negatives, p)
    loss = tf.nn.softmax_cross_entropy_with_logits(labels=pi, logits=p)
    return loss