import argparse
import os
import numpy as np
import gym
import chainer
import chainerrl
from chainerrl import experiments, misc, optimizers, replay_buffers, explorations, links
from chainerrl.wrappers import CastObservationToFloat32, ScaleReward, Monitor, Render
from chainerrl.agents import DDPGAgent
from chainerrl.links import DDPGModel, FCBNLateActionSAQFunction, FCBNDeterministicPolicy, \
    FCSAQFunction, FCDeterministicPolicy


def parse_args():
    parser = argparse.ArgumentParser(description="DDPG Humanoid-v2 training")
    parser.add_argument("--outdir", type=str, default="output", help="Output directory")
    parser.add_argument("--env", type=str, default="Humanoid-v2", help="Gym environment")
    parser.add_argument("--seed", type=int, default=0, help="Random seed")
    parser.add_argument("--gpu", type=int, default=0, help="GPU device ID (negative for CPU)")
    parser.add_argument("--actor-lr", type=float, default=1e-4, help="Actor learning rate")
    parser.add_argument("--critic-lr", type=float, default=1e-3, help="Critic learning rate")
    parser.add_argument("--buffer-size", type=int, default=5 * 10 ** 5, help="Replay buffer capacity")
    parser.add_argument("--reward-scale-factor", type=float, default=1e-2, help="Reward scaling factor")
    parser.add_argument("--monitor", action="store_true", help="Enable monitor wrapper")
    parser.add_argument("--render", action="store_true", help="Render training environment")
    parser.add_argument("--use-bn", action="store_true", help="Use batch normalization in networks")
    parser.add_argument("--n-hidden-channels", type=int, default=300, help="Number of hidden channels")
    parser.add_argument("--n-hidden-layers", type=int, default=3, help="Number of hidden layers")
    parser.add_argument("--gamma", type=float, default=0.995, help="Discount factor")
    parser.add_argument("--minibatch-size", type=int, default=200, help="Minibatch size")
    parser.add_argument("--target-update-interval", type=int, default=1, help="Target update interval")
    parser.add_argument("--target-update-method", type=str, default="soft", help="Target update method")
    parser.add_argument("--soft-update-tau", type=float, default=1e-2, help="Soft update tau")
    parser.add_argument("--replay-start-size", type=int, default=5000, help="Replay start size")
    parser.add_argument("--update-interval", type=int, default=4, help="Update interval")
    parser.add_argument("--n-update-times", type=int, default=1, help="Number of update times")
    parser.add_argument("--steps", type=int, default=10 ** 7, help="Training steps")
    parser.add_argument("--eval-interval", type=int, default=10 ** 5, help="Evaluation interval")
    parser.add_argument("--eval-n-runs", type=int, default=5, help="Number of evaluation episodes")
    parser.add_argument("--demo", action="store_true", help="Run demo instead of training")
    parser.add_argument("--load", type=str, default="", help="Path to pre-trained model")
    return parser.parse_args()


def make_env(seed, is_train, reward_scale, monitor, render):
    env = gym.make(args.env)
    env.seed(seed)
    if is_train:
        env.action_space.seed(seed)
    env = CastObservationToFloat32(env)
    env = ScaleReward(env, reward_scale)
    if monitor and is_train:
        env = Monitor(env, logdir=os.path.join(args.outdir, "monitor"))
    if render and is_train:
        env = Render(env)
    return env


def main():
    global args
    args = parse_args()

    outdir = experiments.prepare_output_dir(args.outdir, exist_ok=True)
    misc.set_random_seed(args.seed)

    train_env = make_env(args.seed, True, args.reward_scale_factor, args.monitor, args.render)
    test_env = make_env(args.seed + 1000000, False, args.reward_scale_factor, False, False)

    obs_dim = train_env.observation_space.shape[0]
    act_dim = train_env.action_space.shape[0]

    if args.use_bn:
        q_func = FCBNLateActionSAQFunction(
            obs_dim, act_dim,
            n_hidden_channels=args.n_hidden_channels,
            n_hidden_layers=args.n_hidden_layers)
        policy = FCBNDeterministicPolicy(
            obs_dim, act_dim,
            n_hidden_channels=args.n_hidden_channels,
            n_hidden_layers=args.n_hidden_layers)
    else:
        q_func = FCSAQFunction(
            obs_dim, act_dim,
            n_hidden_channels=args.n_hidden_channels,
            n_hidden_layers=args.n_hidden_layers)
        policy = FCDeterministicPolicy(
            obs_dim, act_dim,
            n_hidden_channels=args.n_hidden_channels,
            n_hidden_layers=args.n_hidden_layers)

    model = DDPGModel(q_func, policy)

    actor_opt = optimizers.Adam(alpha=args.actor_lr, clip_norm=1.0)
    actor_opt.setup(policy)
    critic_opt = optimizers.Adam(alpha=args.critic_lr, clip_norm=1.0)
    critic_opt.setup(q_func)

    replay_buffer = replay_buffers.ReplayBuffer(capacity=args.buffer_size)

    sigma = 0.2 * (train_env.action_space.high - train_env.action_space.low)
    exploration = explorations.AdditiveOU(sigma, seed=args.seed)

    agent = DDPGAgent(
        model=model,
        q_func_optimizer=critic_opt,
        policy_optimizer=actor_opt,
        replay_buffer=replay_buffer,
        gpu=args.gpu,
        gamma=args.gamma,
        minibatch_size=args.minibatch_size,
        target_update_interval=args.target_update_interval,
        target_update_method=args.target_update_method,
        soft_update_tau=args.soft_update_tau,
        replay_start_size=args.replay_start_size,
        update_interval=args.update_interval,
        n_update_times=args.n_update_times,
        exploration=exploration,
        reward_preprocessing_fn=None)

    if args.load:
        agent.load(args.load)

    if args.demo:
        eval_performance = chainerrl.experiments.eval_performance
        scores = eval_performance(
            agent=agent,
            env=test_env,
            n_eval_episodes=args.eval_n_runs,
            deterministic=True)
        print("Demo scores:", scores)
    else:
        train_agent_with_evaluation = chainerrl.experiments.train_agent_with_evaluation
        train_agent_with_evaluation(
            agent=agent,
            env=train_env,
            eval_env=test_env,
            steps=args.steps,
            eval_interval=args.eval_interval,
            eval_n_episodes=args.eval_n_runs,
            deterministic=True,
            outdir=outdir)


if __name__ == "__main__":
    main()
