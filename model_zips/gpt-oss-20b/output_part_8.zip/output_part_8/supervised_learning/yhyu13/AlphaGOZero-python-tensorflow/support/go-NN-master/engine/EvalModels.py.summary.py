import torch
import torch.nn as nn
import torch.nn.functional as F


class Conv2dPosBias(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride=1, padding=0, N=None):
        super().__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size,
                              stride=stride, padding=padding, bias=False)
        if N is None:
            raise ValueError("N must be provided for position‑dependent bias")
        self.bias = nn.Parameter(torch.zeros(out_channels, N, N))
        self.elu = nn.ELU()

    def forward(self, x):
        out = self.conv(x) + self.bias.unsqueeze(0)
        return self.elu(out)


class Conv5PosDepFC1ELU(nn.Module):
    def __init__(self, N, Nfeat):
        super().__init__()
        self.N = N
        self.Nfeat = Nfeat
        self.training_dir = f"conv5_{N}_{Nfeat}"

        self.conv1 = Conv2dPosBias(Nfeat, 64, kernel_size=5, padding=2, N=N)
        self.convs = nn.ModuleList(
            [Conv2dPosBias(64, 64, kernel_size=3, padding=1, N=N) for _ in range(10)]
        )
        self.fc = nn.Linear(64 * N * N, 256)
        self.out = nn.Linear(256, 1)
        self.tanh = nn.Tanh()

    def forward(self, feature_planes):
        x = self.conv1(feature_planes)
        for conv in self.convs:
            x = conv(x)
        x = x.view(x.size(0), -1)
        x = F.elu(self.fc(x))
        x = self.out(x)
        return self.tanh(x)


class Conv11PosDepFC1ELU(nn.Module):
    def __init__(self, N, Nfeat):
        super().__init__()
        self.N = N
        self.Nfeat = Nfeat
        self.training_dir = f"conv11_{N}_{Nfeat}"

        self.conv1 = Conv2dPosBias(Nfeat, 256, kernel_size=5, padding=2, N=N)
        self.convs = nn.ModuleList(
            [Conv2dPosBias(256, 256, kernel_size=3, padding=1, N=N) for _ in range(10)]
        )
        self.fc = nn.Linear(256 * N * N, 256)
        self.out = nn.Linear(256, 1)
        self.tanh = nn.Tanh()

    def forward(self, feature_planes):
        x = self.conv1(feature_planes)
        for conv in self.convs:
            x = conv(x)
        x = x.view(x.size(0), -1)
        x = F.elu(self.fc(x))
        x = self.out(x)
        return self.tanh(x)


class Linear(nn.Module):
    def __init__(self, N, Nfeat):
        super().__init__()
        self.N = N
        self.Nfeat = Nfeat
        self.training_dir = f"linear_{N}_{Nfeat}"

        in_features = Nfeat * N * N
        self.lin = nn.Linear(in_features, 1)
        nn.init.constant_(self.lin.weight, 0.0)
        nn.init.constant_(self.lin.bias, 0.0)
        self.tanh = nn.Tanh()

    def forward(self, feature_planes):
        x = feature_planes.view(feature_planes.size(0), -1)
        x = self.lin(x)
        return self.tanh(x)


class Zero(nn.Module):
    def __init__(self, N, Nfeat):
        super().__init__()
        self.N = N
        self.Nfeat = Nfeat
        self.training_dir = f"zero_{N}_{Nfeat}"

    def forward(self, feature_planes):
        return torch.zeros(128, device=feature_planes.device)
