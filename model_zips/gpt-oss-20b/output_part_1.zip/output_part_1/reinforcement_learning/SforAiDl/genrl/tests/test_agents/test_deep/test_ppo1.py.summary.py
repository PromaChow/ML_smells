import os
import shutil

import pytest
from genrl.algorithms import PPO1
from genrl.training import OnPolicyTrainer
from genrl.envs import VectorEnv


def create_env(env_name: str, env_type: str | None = None) -> VectorEnv:
    """Create a vectorized environment."""
    if env_type:
        return VectorEnv([env_name], env_type=env_type)
    return VectorEnv([env_name])


@pytest.fixture(autouse=True)
def cleanup_logs():
    """Ensure that the log directory is removed after each test."""
    yield
    if os.path.isdir("./logs"):
        shutil.rmtree("./logs")


def test_ppo1_cartpole_mlp():
    env = create_env("CartPole-v0")
    agent = PPO1(policy_type="mlp", env=env)
    trainer = OnPolicyTrainer(
        agent=agent,
        env=env,
        log_mode="csv",
        log_dir="./logs",
        epochs=1,
    )
    trainer.train()


def test_ppo1_pendulum_mlp_shared():
    env = create_env("Pendulum-v0")
    agent = PPO1(policy_type="mlp", env=env, shared_layers=[32, 32])
    trainer = OnPolicyTrainer(
        agent=agent,
        env=env,
        log_mode="csv",
        log_dir="./logs",
        epochs=1,
    )
    trainer.train()


def test_ppo1_pong_cnn():
    env = create_env("Pong-v0")
    agent = PPO1(policy_type="cnn", env=env)
    trainer = OnPolicyTrainer(
        agent=agent,
        env=env,
        log_mode="csv",
        log_dir="./logs",
        epochs=1,
    )
    trainer.train()


def test_ppo1_atari_pong_cnn():
    env = create_env("PongNoFrameskip-v4", env_type="atari")
    agent = PPO1(policy_type="cnn", env=env)
    trainer = OnPolicyTrainer(
        agent=agent,
        env=env,
        log_mode="csv",
        log_dir="./logs",
        epochs=1,
    )
    trainer.train()
