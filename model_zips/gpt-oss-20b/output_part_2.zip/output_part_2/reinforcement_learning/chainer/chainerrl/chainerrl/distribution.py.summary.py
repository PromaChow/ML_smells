import abc
import numpy as np
import chainer
from chainerrl.math import arctanh, mellowmax


def _wrap_by_variable(x):
    if isinstance(x, chainer.Variable):
        return x
    return chainer.Variable(x)


def _unwrap_variable(x):
    if isinstance(x, chainer.Variable):
        return x.array
    return x


class Distribution(abc.ABC):
    @abc.abstractmethod
    def sample(self):
        pass

    @abc.abstractmethod
    def prob(self, value):
        pass

    @abc.abstractmethod
    def log_prob(self, value):
        pass

    @abc.abstractmethod
    def entropy(self):
        pass

    @abc.abstractmethod
    def kl(self, other):
        pass

    @property
    @abc.abstractmethod
    def params(self):
        pass

    def sample_with_log_prob(self):
        x = self.sample()
        return x, self.log_prob(x)


class CategoricalDistribution(Distribution):
    @abc.abstractmethod
    def all_prob(self):
        pass

    @abc.abstractmethod
    def all_log_prob(self):
        pass

    def entropy(self):
        probs = self.all_prob()
        return -np.sum(probs * self.all_log_prob(), axis=-1)

    def most_probable(self):
        return np.argmax(self.all_prob(), axis=-1)

    def prob(self, value):
        return self.all_prob()[value]

    def log_prob(self, value):
        return self.all_log_prob()[value]

    def kl(self, other):
        return np.sum(self.all_prob() * (self.all_log_prob() - other.all_log_prob()), axis=-1)

    @property
    def params(self):
        return []


class SoftmaxDistribution(CategoricalDistribution):
    def __init__(self, logits, beta=1.0, min_prob=0.0):
        self.logits = np.asarray(logits, dtype=np.float32)
        self.beta = float(beta)
        self.min_prob = float(min_prob)
        self._probs = None

    def _compute_probs(self):
        logits = self.logits / self.beta
        logits -= np.max(logits, axis=-1, keepdims=True)
        exp = np.exp(logits)
        probs = exp / np.sum(exp, axis=-1, keepdims=True)
        if self.min_prob > 0.0:
            probs += self.min_prob
            probs /= np.sum(probs, axis=-1, keepdims=True)
        return probs

    def all_prob(self):
        if self._probs is None:
            self._probs = self._compute_probs()
        return self._probs

    def all_log_prob(self):
        probs = self.all_prob()
        return np.log(probs + 1e-12)

    def copy(self):
        return SoftmaxDistribution(self.logits.copy(), self.beta, self.min_prob)

    def __str__(self):
        return f"SoftmaxDistribution(beta={self.beta}, logits={self.logits})"


class MellowmaxDistribution(CategoricalDistribution):
    def __init__(self, values, beta=1.0):
        self.values = np.asarray(values, dtype=np.float32)
        self.beta = float(beta)
        self._probs = None

    def _compute_probs(self):
        return mellowmax(self.values, self.beta)

    def all_prob(self):
        if self._probs is None:
            self._probs = self._compute_probs()
        return self._probs

    def all_log_prob(self):
        probs = self.all_prob()
        return np.log(probs + 1e-12)

    def copy(self):
        return MellowmaxDistribution(self.values.copy(), self.beta)

    def __str__(self):
        return f"MellowmaxDistribution(beta={self.beta}, values={self.values})"


class GaussianDistribution(Distribution):
    def __init__(self, mean, var):
        self.mean = np.asarray(mean, dtype=np.float32)
        self.var = np.asarray(var, dtype=np.float32)

    def sample(self):
        return self.mean + np.sqrt(self.var) * np.random.randn(*self.mean.shape)

    def log_prob(self, x):
        diff = x - self.mean
        log_2pi = np.log(2.0 * np.pi)
        return -0.5 * (np.sum((diff ** 2) / self.var + np.log(self.var) + log_2pi, axis=-1))

    def entropy(self):
        dim = self.mean.size
        return 0.5 * (dim * np.log(2.0 * np.pi * np.e) + np.sum(np.log(self.var)))

    def kl(self, other):
        if not isinstance(other, GaussianDistribution):
            raise TypeError("KL is defined only between GaussianDistributions")
        diff = self.mean - other.mean
        term1 = np.sum(np.log(other.var / self.var), axis=-1)
        term2 = np.sum((self.var + diff ** 2) / other.var, axis=-1)
        dim = self.mean.size
        return 0.5 * (term1 + term2 - dim)

    @property
    def params(self):
        return [self.mean, self.var]

    def copy(self):
        return GaussianDistribution(self.mean.copy(), self.var.copy())


class SquashedGaussianDistribution(Distribution):
    def __init__(self, mean, var):
        self.base = GaussianDistribution(mean, var)

    def sample(self):
        s = self.base.sample()
        return np.tanh(s)

    def sample_with_log_prob(self):
        s = self.base.sample()
        act = np.tanh(s)
        logp = self.base.log_prob(s)
        # Jacobian adjustment for tanh
        logp += np.sum(np.log(1.0 - act ** 2 + 1e-12), axis=-1)
        return act, logp

    def log_prob(self, act):
        # inverse tanh is arctanh
        s = arctanh(act)
        logp = self.base.log_prob(s)
        logp += np.sum(np.log(1.0 - act ** 2 + 1e-12), axis=-1)
        return logp

    def prob(self, act):
        raise NotImplementedError("Probabilities are not defined for squashed Gaussians")

    def entropy(self):
        raise NotImplementedError("Entropy is not defined for squashed Gaussians")

    def kl(self, other):
        raise NotImplementedError("KL is not defined for squashed Gaussians")

    @property
    def params(self):
        return self.base.params

    def copy(self):
        return SquashedGaussianDistribution(self.base.mean.copy(), self.base.var.copy())


class ContinuousDeterministicDistribution(Distribution):
    def __init__(self, mean):
        self.mean = np.asarray(mean, dtype=np.float32)

    def sample(self):
        return self.mean

    def prob(self, value):
        raise NotImplementedError("Probabilities are not defined for deterministic distribution")

    def log_prob(self, value):
        raise NotImplementedError("Log probabilities are not defined for deterministic distribution")

    def entropy(self):
        raise NotImplementedError("Entropy is not defined for deterministic distribution")

    def kl(self, other):
        raise NotImplementedError("KL is not defined for deterministic distribution")

    @property
    def params(self):
        return [self.mean]
```