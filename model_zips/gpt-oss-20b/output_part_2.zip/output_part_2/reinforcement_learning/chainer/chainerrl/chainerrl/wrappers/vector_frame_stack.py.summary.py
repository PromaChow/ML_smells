import gym
import numpy as np
from collections import deque

class LazyFrames:
    def __init__(self, frames, stack_axis):
        self.frames = frames
        self.stack_axis = stack_axis

    def __array__(self, dtype=None):
        return np.concatenate(self.frames, axis=self.stack_axis)

    def get(self):
        return np.concatenate(self.frames, axis=self.stack_axis)

    def __repr__(self):
        return f"LazyFrames(shape={self.frames[0].shape if self.frames else None})"

    def __len__(self):
        return len(self.frames)

class VectorEnvWrapper:
    def __init__(self, env):
        self.env = env
        self.action_space = env.action_space
        self.observation_space = env.observation_space

    def step(self, actions):
        return self.env.step(actions)

    def reset(self, **kwargs):
        return self.env.reset(**kwargs)

    def render(self, **kwargs):
        return self.env.render(**kwargs)

    def close(self, **kwargs):
        return self.env.close(**kwargs)

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        return getattr(self.env, name)

class VectorFrameStack(VectorEnvWrapper):
    def __init__(self, env, k=4, stack_axis=0):
        super().__init__(env)
        self.k = k
        self.stack_axis = stack_axis
        self.frames = [deque(maxlen=k) for _ in range(self.env.num_envs)]

        obs_space = env.observation_space
        if not isinstance(obs_space, gym.spaces.Box):
            raise ValueError("VectorFrameStack only supports Box observation spaces")

        low = np.repeat(obs_space.low, k, axis=stack_axis)
        high = np.repeat(obs_space.high, k, axis=stack_axis)
        shape = list(obs_space.shape)
        shape[stack_axis] *= k
        self.observation_space = gym.spaces.Box(
            low=low, high=high, dtype=obs_space.dtype
        )

    def reset(self, mask=None, **kwargs):
        obs = self.env.reset(**kwargs)
        if mask is None:
            mask = [False] * self.env.num_envs
        for i in range(self.env.num_envs):
            if not mask[i]:
                self.frames[i].clear()
                for _ in range(self.k):
                    self.frames[i].append(obs[i])
        return self._get_ob()

    def step(self, actions):
        obs, rewards, dones, infos = self.env.step(actions)
        for i in range(self.env.num_envs):
            self.frames[i].append(obs[i])
        return self._get_ob(), rewards, dones, infos

    def _get_ob(self):
        return [
            LazyFrames(list(frames), self.stack_axis) for frames in self.frames
        ]