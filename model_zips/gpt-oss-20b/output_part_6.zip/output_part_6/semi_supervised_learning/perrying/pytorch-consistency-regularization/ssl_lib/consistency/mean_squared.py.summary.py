import torch
import torch.nn as nn
import torch.nn.functional as F

def mean_squared(y: torch.Tensor, target: torch.Tensor, mask: torch.Tensor | None = None) -> torch.Tensor:
    """
    Compute the mean squared error loss between the softmax of `y` and `target`.

    Args:
        y (torch.Tensor): Logits of shape (batch_size, num_classes).
        target (torch.Tensor): Target distribution of the same shape.
        mask (torch.Tensor | None, optional): Binary mask or weighting tensor of shape (batch_size,).

    Returns:
        torch.Tensor: Scalar loss value.
    """
    probs = F.softmax(y, dim=1)
    mse = F.mse_loss(probs, target, reduction="none")  # shape (batch_size, num_classes)
    loss_per_sample = mse.mean(dim=1)  # shape (batch_size,)

    if mask is not None:
        mask = mask.to(dtype=loss_per_sample.dtype, device=loss_per_sample.device)
        loss_per_sample = loss_per_sample * mask

    return loss_per_sample.mean()


class MeanSquared(nn.Module):
    """
    PyTorch module that computes a mean squared error loss with optional masking.
    """

    def __init__(self) -> None:
        super().__init__()

    def forward(
        self, y: torch.Tensor, target: torch.Tensor, mask: torch.Tensor | None = None
    ) -> torch.Tensor:
        """
        Forward pass for the MeanSquared loss.

        Args:
            y (torch.Tensor): Logits of shape (batch_size, num_classes).
            target (torch.Tensor): Target distribution of the same shape.
            mask (torch.Tensor | None, optional): Binary mask or weighting tensor of shape (batch_size,).

        Returns:
            torch.Tensor: Scalar loss value.
        """
        detached_target = target.detach()
        return mean_squared(y, detached_target, mask)
