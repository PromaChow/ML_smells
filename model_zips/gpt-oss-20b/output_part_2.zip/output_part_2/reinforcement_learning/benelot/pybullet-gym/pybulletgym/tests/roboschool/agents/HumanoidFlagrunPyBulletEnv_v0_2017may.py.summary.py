import numpy as np

# Weight and bias matrices (randomly initialized for demonstration purposes)
weights_dense1_w = np.random.randn(128, 768)   # Shape: (128, 768)
weights_dense1_b = np.random.randn(128)        # Shape: (128,)

weights_dense2_w = np.random.randn(128, 128)   # Shape: (128, 128)
weights_dense2_b = np.random.randn(128)        # Shape: (128,)

weights_final_w = np.random.randn(50, 128)     # Shape: (50, 128)
weights_final_b = np.random.randn(50)          # Shape: (50,)

def relu(x: np.ndarray) -> np.ndarray:
    """ReLU activation function."""
    return np.maximum(0, x)

class SimpleNN:
    def __init__(self,
                 w1: np.ndarray,
                 b1: np.ndarray,
                 w2: np.ndarray,
                 b2: np.ndarray,
                 w_final: np.ndarray,
                 b_final: np.ndarray,
                 activation=relu):
        self.w1 = w1
        self.b1 = b1
        self.w2 = w2
        self.b2 = b2
        self.w_final = w_final
        self.b_final = b_final
        self.activation = activation

    def forward(self, x: np.ndarray) -> np.ndarray:
        """
        Perform a forward pass through the network.

        Parameters
        ----------
        x : np.ndarray
            Input data of shape (batch_size, 768).

        Returns
        -------
        np.ndarray
            Output of the network of shape (batch_size, 50).
        """
        # Dense1
        z1 = x @ self.w1.T + self.b1
        a1 = self.activation(z1)

        # Dense2
        z2 = a1 @ self.w2.T + self.b2
        a2 = self.activation(z2)

        # Final dense
        z_final = a2 @ self.w_final.T + self.b_final

        return z_final

if __name__ == "__main__":
    # Example usage
    model = SimpleNN(
        w1=weights_dense1_w,
        b1=weights_dense1_b,
        w2=weights_dense2_w,
        b2=weights_dense2_b,
        w_final=weights_final_w,
        b_final=weights_final_b,
        activation=relu
    )

    # Create a dummy input (batch size of 1)
    dummy_input = np.random.randn(1, 768)

    # Forward pass
    output = model.forward(dummy_input)
    print("Output shape:", output.shape)
    print("Output:", output)