import numpy as np


class SpriteFactors:
    """Render specified sprite attributes as float arrays."""

    VALID_ATTRIBUTES = {"shape", "color", "size"}
    SHAPE_MAP = {"circle": 0, "square": 1, "triangle": 2}
    COLOR_MAP = {"red": 0, "green": 1, "blue": 2}

    def __init__(self, factors: list):
        if not isinstance(factors, list):
            raise TypeError("factors must be a list")
        for f in factors:
            if f not in self.VALID_ATTRIBUTES:
                raise ValueError(f"Invalid factor: {f}")
        self.factors = factors

    def render(self, sprites: list) -> np.ndarray:
        """Convert sprite attributes to a structured NumPy array."""
        result = []
        for sprite in sprites:
            entry = {}
            for f in self.factors:
                val = sprite.get(f)
                if f == "shape":
                    val = float(self.SHAPE_MAP.get(val, 0))
                elif f == "color":
                    val = float(self.COLOR_MAP.get(val, 0))
                else:
                    try:
                        val = float(val)
                    except (TypeError, ValueError):
                        val = 0.0
                entry[f] = val
            result.append(entry)
        return np.array(result, dtype=float)

    def observation_spec(self, num_sprites: int) -> dict:
        """Specification: dict of factor names to float arrays of shape (num_sprites,)."""
        spec = {}
        for f in self.factors:
            spec[f] = np.zeros(num_sprites, dtype=float)
        return spec


class SpritePassthrough:
    """Return sprites unchanged, tracking the count."""

    def __init__(self):
        self.num_sprites = 0

    def render(self, sprites: list) -> list:
        self.num_sprites = len(sprites)
        return sprites

    def observation_spec(self) -> dict:
        """Specification: array of object references for each sprite."""
        return {"sprites": np.zeros(self.num_sprites, dtype=object)}


class Success:
    """Extract a global 'success' boolean flag."""

    def __init__(self):
        pass

    def render(self, sprites: list, global_state: dict) -> bool:
        return bool(global_state.get("success", False))

    def observation_spec(self) -> dict:
        """Specification: single boolean value."""
        return {"success": np.array(False, dtype=bool)}