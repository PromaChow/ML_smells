import abc
import os
import chainer.serializers

def load_npz_no_strict(path, obj, **kwargs):
    try:
        chainer.serializers.load_npz(path, obj, **kwargs)
    except KeyError:
        # Ignore missing keys during load
        pass

class AttributeSavingMixin:
    @property
    @abc.abstractmethod
    def saved_attributes(self):
        """Return an iterable of attribute names to be saved/loaded."""
        raise NotImplementedError

    def __save(self, value, base_path):
        if hasattr(value, "save"):
            value.save(base_path)
        elif isinstance(value, dict):
            for key, val in value.items():
                self.__save(val, f"{base_path}_{key}")
        elif isinstance(value, (list, tuple)):
            for idx, val in enumerate(value):
                self.__save(val, f"{base_path}_{idx}")
        else:
            chainer.serializers.save_npz(base_path, value)

    def save(self, file_path):
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        for name in self.saved_attributes:
            value = getattr(self, name)
            path = f"{file_path}_{name}.npz"
            self.__save(value, path)

    def load(self, file_path):
        for name in self.saved_attributes:
            path = f"{file_path}_{name}.npz"
            if os.path.exists(path):
                value = getattr(self, name)
                load_npz_no_strict(path, value)

class Agent(abc.ABC):
    @abc.abstractmethod
    def act(self, state):
        """Select an action given a state."""
        pass

    @abc.abstractmethod
    def act_and_train(self, state):
        """Select an action and perform training step."""
        pass

    @abc.abstractmethod
    def stop_episode(self):
        """Signal the end of an episode."""
        pass

    @abc.abstractmethod
    def stop_episode_and_train(self):
        """Signal the end of an episode and perform training."""
        pass

    @abc.abstractmethod
    def get_stats(self):
        """Return statistics about the agent."""
        pass

class AsyncAgent(Agent, AttributeSavingMixin):
    @property
    @abc.abstractmethod
    def process_idx(self):
        """Return the process index for async execution."""
        pass

    @property
    @abc.abstractmethod
    def shared_attributes(self):
        """Return attributes that are shared across processes."""
        pass

class BatchAgent(Agent, AttributeSavingMixin):
    @abc.abstractmethod
    def batch_act(self, states):
        """Select actions for a batch of states."""
        pass

    @abc.abstractmethod
    def batch_act_and_train(self, states):
        """Select actions and train on a batch of states."""
        pass

    @abc.abstractmethod
    def batch_observe(self, next_states, rewards, dones):
        """Process a batch of observations."""
        pass

    @abc.abstractmethod
    def batch_observe_and_train(self, next_states, rewards, dones):
        """Process a batch of observations and perform training."""
        pass

# Example concrete implementation
class DummyAgent(BatchAgent):
    def __init__(self):
        self.model = chainer.links.Linear(10, 2)
        self.optimizer = chainer.optimizers.Adam()
        self.optimizer.setup(self.model)

    @property
    def saved_attributes(self):
        return ["model", "optimizer"]

    def act(self, state):
        return self.model(state)

    def act_and_train(self, state):
        return self.act(state)

    def stop_episode(self):
        pass

    def stop_episode_and_train(self):
        pass

    def get_stats(self):
        return {"loss": 0.0}

    def batch_act(self, states):
        return self.model(states)

    def batch_act_and_train(self, states):
        return self.batch_act(states)

    def batch_observe(self, next_states, rewards, dones):
        pass

    def batch_observe_and_train(self, next_states, rewards, dones):
        pass

if __name__ == "__main__":
    agent = DummyAgent()
    agent.save("agent_checkpoint")  # Saves model and optimizer
    agent.load("agent_checkpoint")  # Loads model and optimizer
