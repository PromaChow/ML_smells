import os
import numpy as np
import geopandas as gpd
from pysal.lib import weights
from pysal.examples.datasets import get_path
from spenc import SPENC

SEED = 42
OUTPUT_DIR = "spenc_results"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# 1. Data Preparation
shp_path = get_path("NAT.shp")
df = gpd.read_file(shp_path)
natR = weights.Rook.from_dataframe(df)
col_mask = df.columns.str.contains(r"90|89")
names = df.columns[col_mask].tolist()
X = df[names].values.astype(float)
X = (X - X.mean(axis=0)) / X.std(axis=0)

# 2. Step 1: 10k Nodata Clustering
model_10k_nodata = SPENC(n_clusters=10, random_state=SEED)
labels_10k_nodata = model_10k_nodata.fit(natR.sparse, data=None)
np.save(os.path.join(OUTPUT_DIR, "nat_10k_nodata.ary"), labels_10k_nodata)

# 3. Step 2: 30k Sampling
model_30k_random = SPENC(n_clusters=30, random_state=SEED)
labels_30k_random = model_30k_random.sample(natR.sparse, n_samples=3)
np.save(os.path.join(OUTPUT_DIR, "nat_30k_randoms.ary"), labels_30k_random)

# 4. Step 3: 30k Withdata Clustering
model_30k_withdata = SPENC(n_clusters=30, gamma=0.001, random_state=SEED)
labels_30k_withdata = model_30k_withdata.fit(X, natR.sparse)
np.save(os.path.join(OUTPUT_DIR, "nat_30k_discovered.ary"), labels_30k_withdata)

# 5. Step 4: Infk Sampling
model_infk_random = SPENC(n_clusters=np.inf, random_state=SEED)
labels_infk_random = model_infk_random.sample(natR.sparse, floor=20)
np.save(os.path.join(OUTPUT_DIR, "nat_infk_randoms.ary"), labels_infk_random)

# 6. Step 5: Infk Withdata Clustering
model_infk_withdata = SPENC(n_clusters=np.inf, gamma=0.001, random_state=SEED)
labels_infk_withdata = model_infk_withdata.fit(X, natR.sparse, floor=20)
np.save(os.path.join(OUTPUT_DIR, "nat_infk_discovered.ary"), labels_infk_withdata)