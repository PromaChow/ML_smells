import math
import random
import numpy as np
import pyglet
from pyglet import shapes

class Viewer:
    def __init__(self, arm_length, goal_center, goal_size):
        self.window = pyglet.window.Window(width=300, height=300, caption="Two Link Arm")
        self.arm_length = arm_length
        self.goal_center = goal_center
        self.goal_size = goal_size

        self.goal = shapes.Rectangle(
            goal_center[0] - goal_size / 2,
            goal_center[1] - goal_size / 2,
            goal_size,
            goal_size,
            color=(0, 0, 255)
        )

        self.line1 = shapes.Line(0, 0, 0, 0, width=4, color=(255, 0, 0))
        self.line2 = shapes.Line(0, 0, 0, 0, width=4, color=(255, 0, 0))

        @self.window.event
        def on_draw():
            self.window.clear()
            self.goal.draw()
            self.line1.draw()
            self.line2.draw()

    def update_arm(self, x1, y1, x2, y2):
        self.line1.x1, self.line1.y1 = 0, 0
        self.line1.x2, self.line1.y2 = x1, y1
        self.line2.x1, self.line2.y1 = x1, y1
        self.line2.x2, self.line2.y2 = x2, y2

    def draw(self):
        pyglet.clock.tick()
        self.window.dispatch_events()
        self.window.flip()


class ArmEnv:
    def __init__(self, seed=None):
        self.arm_length = 100.0
        self.dt = 0.1
        self.goal_center = (100.0, 100.0)
        self.goal_size = 40.0
        self.goal_tol = 20.0
        self.max_stay_steps = 50
        self.viewer = None

        self.rng = random.Random(seed)
        self.np_rng = np.random.default_rng(seed)

        self.reset()

    def reset(self):
        self.theta1 = 2 * math.pi * self.rng.random()
        self.theta2 = 2 * math.pi * self.rng.random()
        self.consecutive_goal_steps = 0
        return self._build_state()

    def step(self, action):
        action = np.clip(action, -1, 1)
        self.theta1 = (self.theta1 + action[0] * self.dt) % (2 * math.pi)
        self.theta2 = (self.theta2 + action[1] * self.dt) % (2 * math.pi)

        x1 = self.arm_length * math.cos(self.theta1)
        y1 = self.arm_length * math.sin(self.theta1)
        x2 = x1 + self.arm_length * math.cos(self.theta1 + self.theta2)
        y2 = y1 + self.arm_length * math.sin(self.theta1 + self.theta2)

        if self.viewer:
            self.viewer.update_arm(x1, y1, x2, y2)

        dist_end = math.hypot(x2 - self.goal_center[0], y2 - self.goal_center[1])
        reward = -dist_end
        on_goal = (abs(x2 - self.goal_center[0]) <= self.goal_tol and
                   abs(y2 - self.goal_center[1]) <= self.goal_tol)
        if on_goal:
            reward += 1.0
            self.consecutive_goal_steps += 1
        else:
            self.consecutive_goal_steps = 0

        done = self.consecutive_goal_steps >= self.max_stay_steps
        info = {"on_goal": on_goal, "dist_end": dist_end}
        state = self._build_state()
        return state, reward, done, info

    def _build_state(self):
        x1 = self.arm_length * math.cos(self.theta1)
        y1 = self.arm_length * math.sin(self.theta1)
        x2 = x1 + self.arm_length * math.cos(self.theta1 + self.theta2)
        y2 = y1 + self.arm_length * math.sin(self.theta1 + self.theta2)

        max_pos = 2 * self.arm_length
        a1xy_norm = np.array([x1 / max_pos, y1 / max_pos])
        finger_norm = np.array([x2 / max_pos, y2 / max_pos])

        dist_a1 = math.hypot(x1 - self.goal_center[0], y1 - self.goal_center[1])
        dist_finger = math.hypot(x2 - self.goal_center[0], y2 - self.goal_center[1])
        max_dist = 2 * self.arm_length * math.sqrt(2)
        dist_a1_norm = dist_a1 / max_dist
        dist_finger_norm = dist_finger / max_dist

        on_goal = (abs(x2 - self.goal_center[0]) <= self.goal_tol and
                   abs(y2 - self.goal_center[1]) <= self.goal_tol)
        flag = 1.0 if on_goal else 0.0

        theta1_norm = self.theta1 / (2 * math.pi)
        theta2_norm = self.theta2 / (2 * math.pi)

        state = np.concatenate([
            a1xy_norm,
            finger_norm,
            [dist_a1_norm],
            [dist_finger_norm],
            [flag],
            [theta1_norm],
            [theta2_norm]
        ])
        return state

    def render(self):
        if self.viewer is None:
            self.viewer = Viewer(
                self.arm_length, self.goal_center, self.goal_size
            )
        x1 = self.arm_length * math.cos(self.theta1)
        y1 = self.arm_length * math.sin(self.theta1)
        x2 = x1 + self.arm_length * math.cos(self.theta1 + self.theta2)
        y2 = y1 + self.arm_length * math.sin(self.theta1 + self.theta2)
        self.viewer.update_arm(x1, y1, x2, y2)
        self.viewer.draw()

    def sample_action(self):
        return self.np_rng.uniform(-0.5, 0.5, size=2)
