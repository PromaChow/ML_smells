import numpy as np
from sklearn.base import clone, BaseEstimator, ClassifierMixin
from sklearn.utils import resample
from sklearn.metrics import accuracy_score
from collections import Counter
from itertools import permutations


class Third(BaseEstimator, ClassifierMixin):
    def __init__(self, base_clf, X, y):
        self.base_clf = clone(base_clf)
        self.X = X
        self.y = y
        self.clf = None

    def fit(self, X=None, y=None):
        if X is not None and y is not None:
            self.X = X
            self.y = y
        self.clf = clone(self.base_clf).fit(self.X, self.y)
        return self

    def predict(self, X):
        return self.clf.predict(X)

    def add_samples(self, X_new, y_new):
        self.X = np.vstack((self.X, X_new))
        self.y = np.concatenate((self.y, y_new))
        self.fit()


class TriTraining(BaseEstimator, ClassifierMixin):
    def __init__(self, base_clf, name="TriTraining"):
        self.base_clf = clone(base_clf)
        self.name = name
        self.t1 = None
        self.t2 = None
        self.t3 = None
        self.err_prime = 0.5

    def _error_between(self, t_a, t_b, X, y):
        pred_a = t_a.predict(X)
        pred_b = t_b.predict(X)
        agree = (pred_a == pred_b)
        if not np.any(agree):
            return 1.0
        incorrect_both = np.sum((pred_a != y) & (pred_b != y))
        return incorrect_both / np.sum(agree)

    def _confident_unlabeled(self, t_a, t_b, X_unlabeled):
        pred_a = t_a.predict(X_unlabeled)
        pred_b = t_b.predict(X_unlabeled)
        mask = pred_a == pred_b
        return mask

    def fit(self, X_labeled, y_labeled, X_unlabeled, max_iter=10):
        # bootstrap initial training
        boot_X1, boot_y1 = resample(X_labeled, y_labeled, replace=True, n_samples=len(y_labeled))
        boot_X2, boot_y2 = resample(X_labeled, y_labeled, replace=True, n_samples=len(y_labeled))
        boot_X3, boot_y3 = resample(X_labeled, y_labeled, replace=True, n_samples=len(y_labeled))
        self.t1 = Third(self.base_clf, boot_X1, boot_y1).fit()
        self.t2 = Third(self.base_clf, boot_X2, boot_y2).fit()
        self.t3 = Third(self.base_clf, boot_X3, boot_y3).fit()

        for _ in range(max_iter):
            updated = False
            for active, t_a, t_b in permutations([self.t1, self.t2, self.t3], 3):
                err = self._error_between(t_a, t_b, X_labeled, y_labeled)
                if err < self.err_prime:
                    mask = self._confident_unlabeled(t_a, t_b, X_unlabeled)
                    if np.any(mask):
                        X_new = X_unlabeled[mask]
                        y_new = active.predict(X_new)
                        active.add_samples(X_new, y_new)
                        updated = True
                        self.err_prime = err
            if not updated:
                break
        return self

    def predict(self, X):
        preds = np.vstack([self.t1.predict(X),
                           self.t2.predict(X),
                           self.t3.predict(X)])
        mode_preds = []
        for i in range(X.shape[0]):
            counts = Counter(preds[:, i])
            mode_preds.append(counts.most_common(1)[0][0])
        return np.array(mode_preds)

    def score(self, X, y):
        return accuracy_score(y, self.predict(X))