import torch
import torch.nn as nn
from torch.nn.utils import parameters_to_vector, vector_to_parameters

class CustomModule(nn.Module):
    def __init__(self, **kwargs):
        super().__init__()
        for key, val in kwargs.items():
            self.__setattr__(key, val)

    @property
    def num_params(self) -> int:
        return sum(p.numel() for p in self.parameters())

    @property
    def num_trainable_params(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)

    @property
    def num_untrainable_params(self) -> int:
        return sum(p.numel() for p in self.parameters() if not p.requires_grad)

    def to_vec(self) -> torch.Tensor:
        return parameters_to_vector(self.parameters())

    def from_vec(self, vec: torch.Tensor):
        expected_size = self.num_params
        if vec.numel() != expected_size:
            raise ValueError(f"Vector size {vec.numel()} does not match total number of parameters {expected_size}.")
        vector_to_parameters(vec, self.parameters())

    def save(self, filepath: str):
        torch.save(self.state_dict(), filepath, pickle_protocol=5)

    def load(self, filepath: str):
        state_dict = torch.load(filepath, map_location=self.device if hasattr(self, 'device') else None)
        self.load_state_dict(state_dict)