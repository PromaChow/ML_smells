import subprocess
import sys

# Install required libraries
subprocess.check_call([sys.executable, "-m", "pip", "install", "numpy", "pandas", "matplotlib", "scikit-learn"])

# Import libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn.decomposition import PCA
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis

def main():
    # Load Iris dataset
    iris = datasets.load_iris()
    X = iris.data
    y = iris.target

    # PCA
    pca = PCA(n_components=2)
    X_r = pca.fit_transform(X)
    print("Explained variance ratio of the first two components:", pca.explained_variance_ratio_)

    # LDA
    lda = LinearDiscriminantAnalysis(n_components=2)
    X_r2 = lda.fit_transform(X, y)

    # Visualization
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))

    # PCA plot
    for label in np.unique(y):
        idx = y == label
        axes[0].scatter(X_r[idx, 0], X_r[idx, 1], label=iris.target_names[label])
    axes[0].set_title('PCA')
    axes[0].set_xlabel('PC1')
    axes[0].set_ylabel('PC2')
    axes[0].legend()

    # LDA plot
    for label in np.unique(y):
        idx = y == label
        axes[1].scatter(X_r2[idx, 0], X_r2[idx, 1], label=iris.target_names[label])
    axes[1].set_title('LDA')
    axes[1].set_xlabel('LD1')
    axes[1].set_ylabel('LD2')
    axes[1].legend()

    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()
