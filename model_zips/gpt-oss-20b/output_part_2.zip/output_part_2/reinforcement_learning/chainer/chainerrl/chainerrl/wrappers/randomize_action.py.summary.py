import gym
import numpy as np


class RandomizeAction(gym.ActionWrapper):
    def __init__(self, env, random_fraction=0.0, seed=None):
        super().__init__(env)
        assert isinstance(env.action_space, gym.spaces.Discrete), (
            "RandomizeAction only works with discrete action spaces."
        )
        assert 0.0 <= random_fraction <= 1.0, (
            "random_fraction must be in the range [0, 1]."
        )
        self.random_fraction = random_fraction
        self._np_random = np.random.RandomState(seed)

    def action(self, action):
        if self._np_random.rand() < self.random_fraction:
            return self.env.action_space.sample()
        return action

    def seed(self, seed=None):
        self._np_random.seed(seed)
        return self.env.seed(seed)