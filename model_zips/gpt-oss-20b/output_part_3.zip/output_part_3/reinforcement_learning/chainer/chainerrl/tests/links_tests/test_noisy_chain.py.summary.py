import numpy as np
import chainer
import chainer.links as L
import chainerrl
from chainerrl import to_factorized_noisy
import pytest


def _get_link_names(model):
    """Return sorted list of link names in a Chainer model."""
    return sorted(name for name, _ in model.namedlinks())


def _has_subnames(name, suffixes):
    """Check if name ends with any of the given suffixes."""
    return any(name.endswith(suffix) for suffix in suffixes)


def test_chainlist():
    model = chainer.ChainList(L.Linear(10, 20), L.Linear(20, 30), L.PReLU(30))
    # Initial names
    names = _get_link_names(model)
    assert names == ["/0", "/1", "/2"]

    to_factorized_noisy(model)

    # After transformation
    names = _get_link_names(model)
    expected = ["/0/mu", "/0/sigma", "/1/mu", "/1/sigma", "/2"]
    assert names == expected

    # Ensure non-Linear layers are unchanged
    prelu = model.namedlinks()[4][1]
    assert isinstance(prelu, L.PReLU)


def test_chain():
    class Model(chainer.Chain):
        def __init__(self):
            super().__init__()
            with self.init_scope():
                self.l1 = L.Linear(10, 20)
                self.l2 = L.Linear(20, 30)
                self.l3 = L.PReLU(30)

    model = Model()
    # Initial names
    names = _get_link_names(model)
    assert names == ["/l1", "/l2", "/l3"]

    to_factorized_noisy(model)

    # After transformation
    names = _get_link_names(model)
    expected = ["/l1/mu", "/l1/sigma", "/l2/mu", "/l2/sigma", "/l3"]
    assert names == expected

    # Ensure non-Linear layers are unchanged
    prelu = model.namedlinks()[4][1]
    assert isinstance(prelu, L.PReLU)


def test_sequence():
    seq = chainerrl.links.Sequence(L.Linear(10, 20), L.Linear(20, 30), L.ReLU())
    # Initial names
    names = _get_link_names(seq)
    assert names == ["/0", "/1", "/2"]

    to_factorized_noisy(seq)

    # After transformation
    names = _get_link_names(seq)
    expected = ["/0/mu", "/0/sigma", "/1/mu", "/1/sigma", "/2"]
    assert names == expected

    # Gradient check
    x = chainer.Variable(np.random.randn(1, 10).astype(np.float32))
    y = seq(x)
    loss = y.sum()
    loss.backward()

    for name, param in seq.namedparams():
        if _has_subnames(name, ["/mu", "/sigma"]):
            assert param.grad is not None
            assert param.grad.shape == param.shape


def test_sequential():
    try:
        from chainer import Sequential
    except ImportError:
        pytest.skip("Sequential not available")

    seq = Sequential(
        L.Linear(10, 20),
        L.Linear(20, 30),
        L.ReLU()
    )
    # Initial names
    names = _get_link_names(seq)
    assert names == ["/0", "/1", "/2"]

    to_factorized_noisy(seq)

    # After transformation
    names = _get_link_names(seq)
    expected = ["/0/mu", "/0/sigma", "/1/mu", "/1/sigma", "/2"]
    assert names == expected

    # Gradient check
    x = chainer.Variable(np.random.randn(1, 10).astype(np.float32))
    y = seq(x)
    loss = y.sum()
    loss.backward()

    for name, param in seq.namedparams():
        if _has_subnames(name, ["/mu", "/sigma"]):
            assert param.grad is not None
            assert param.grad.shape == param.shape
