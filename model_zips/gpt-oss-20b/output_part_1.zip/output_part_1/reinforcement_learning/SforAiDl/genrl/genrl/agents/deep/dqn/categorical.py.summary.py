import torch
import torch.nn as nn
from typing import Any

# Assuming the base DQN implementation is available
from dqn_base import DQN

# Utility functions for the categorical distributional approach
from utils import (
    categorical_greedy_action,
    categorical_q_values,
    categorical_q_target,
    categorical_q_loss,
)


class CategoricalDQN(DQN):
    def __init__(
        self,
        num_atoms: int,
        v_min: float,
        v_max: float,
        noisy_layers: Any,
        create_model: bool = True,
        *args,
        **kwargs,
    ) -> None:
        super().__init__(*args, **kwargs)
        self.num_atoms = num_atoms
        self.v_min = v_min
        self.v_max = v_max
        self.noisy_layers = noisy_layers
        self.dqn_type = "categorical"

        if create_model:
            self._create_model(noisy_layers, num_atoms)

    def _create_model(self, noisy_layers: Any, num_atoms: int) -> None:
        # Placeholder: implementation should create a neural network with
        # noisy layers and output distribution over num_atoms atoms
        raise NotImplementedError("Model creation for CategoricalDQN is not implemented.")

    def get_greedy_action(self, state: torch.Tensor) -> int:
        return categorical_greedy_action(
            self.model,
            state,
            self.num_atoms,
            self.v_min,
            self.v_max,
        )

    def get_q_values(
        self,
        states: torch.Tensor,
        actions: torch.Tensor,
    ) -> torch.Tensor:
        return categorical_q_values(
            self.model,
            states,
            actions,
            self.num_atoms,
            self.v_min,
            self.v_max,
        )

    def get_target_q_values(
        self,
        next_states: torch.Tensor,
        rewards: torch.Tensor,
        dones: torch.Tensor,
    ) -> torch.Tensor:
        return categorical_q_target(
            self.target_model,
            next_states,
            rewards,
            dones,
            self.num_atoms,
            self.v_min,
            self.v_max,
            self.gamma,
        )

    def get_q_loss(
        self,
        states: torch.Tensor,
        actions: torch.Tensor,
        rewards: torch.Tensor,
        next_states: torch.Tensor,
        dones: torch.Tensor,
    ) -> torch.Tensor:
        return categorical_q_loss(
            self.model,
            self.target_model,
            states,
            actions,
            rewards,
            next_states,
            dones,
            self.num_atoms,
            self.v_min,
            self.v_max,
            self.gamma,
        )
