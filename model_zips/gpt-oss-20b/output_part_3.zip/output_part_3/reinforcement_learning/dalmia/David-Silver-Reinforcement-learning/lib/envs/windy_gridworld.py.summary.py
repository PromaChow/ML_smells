import numpy as np
from gymnasium.envs.classic_control import discrete


class WindyGridworldEnv(discrete.DiscreteEnv):
    metadata = {"render.modes": ["human", "ansi"]}

    def __init__(self):
        self.rows = 7
        self.cols = 10
        self.nS = self.rows * self.cols
        self.nA = 4  # up, right, down, left
        self.action_dict = {
            0: (-1, 0),  # up
            1: (0, 1),   # right
            2: (1, 0),   # down
            3: (0, -1),  # left
        }

        # Wind strength: columns 3,4,5,8 -> 1; columns 6,7 -> 2
        self.winds = np.zeros((self.rows, self.cols), dtype=int)
        for col in [3, 4, 5, 8]:
            self.winds[:, col] = 1
        for col in [6, 7]:
            self.winds[:, col] = 2

        self.goal_pos = (3, 7)
        self.goal_state = np.ravel_multi_index(self.goal_pos, (self.rows, self.cols))

        # Initial state distribution
        isd = np.zeros(self.nS)
        start_pos = (3, 0)
        start_state = np.ravel_multi_index(start_pos, (self.rows, self.cols))
        isd[start_state] = 1.0

        # Transition table
        P = {s: {a: [] for a in range(self.nA)} for s in range(self.nS)}
        for s in range(self.nS):
            for a in range(self.nA):
                transitions = self._calculate_transition_prob(s, a)
                P[s][a] = transitions

        super().__init__(self.nS, self.nA, P, isd=isd)

    def _limit_coordinates(self, y, x):
        y = max(0, min(self.rows - 1, y))
        x = max(0, min(self.cols - 1, x))
        return y, x

    def _calculate_transition_prob(self, s, a):
        y, x = np.unravel_index(s, (self.rows, self.cols))
        dy, dx = self.action_dict[a]
        new_y, new_x = y + dy, x + dx

        # Apply wind: push upward (decrease row index)
        wind_strength = self.winds[new_y, new_x]
        new_y -= wind_strength

        new_y, new_x = self._limit_coordinates(new_y, new_x)
        next_state = np.ravel_multi_index((new_y, new_x), (self.rows, self.cols))
        reward = -1.0
        done = next_state == self.goal_state
        return [(1.0, next_state, reward, done)]

    def _render(self, mode="human"):
        lines = []
        for y in range(self.rows):
            line = ""
            for x in range(self.cols):
                state_idx = np.ravel_multi_index((y, x), (self.rows, self.cols))
                if state_idx == self.s:
                    ch = "x"
                elif state_idx == self.goal_state:
                    ch = "T"
                else:
                    ch = "o"
                line += ch + " "
            lines.append(line.strip())
        rendered = "\n".join(lines)
        if mode == "human":
            print(rendered)
        return rendered

    def render(self, mode="human"):
        return self._render(mode)