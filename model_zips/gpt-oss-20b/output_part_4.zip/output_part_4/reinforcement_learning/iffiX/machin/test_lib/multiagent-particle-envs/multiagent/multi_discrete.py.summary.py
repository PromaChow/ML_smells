import numpy as np

class MultiDiscrete:
    def __init__(self, array_of_param_array):
        self.low = np.array([arr[0] for arr in array_of_param_array], dtype=int)
        self.high = np.array([arr[1] for arr in array_of_param_array], dtype=int)
        self.num_discrete_space = len(self.low)

    def sample(self):
        rng = np.random.RandomState()
        rand = rng.uniform(0, 1, size=self.num_discrete_space)
        scaled = (self.high - self.low + 1) * rand + self.low
        return np.floor(scaled).astype(int).tolist()

    def contains(self, x):
        if len(x) != self.num_discrete_space:
            return False
        for val, low, high in zip(x, self.low, self.high):
            if val < low or val > high:
                return False
        return True

    @property
    def shape(self):
        return self.num_discrete_space

    def __repr__(self):
        return f"MultiDiscrete(shape={self.shape}, low={self.low.tolist()}, high={self.high.tolist()})"

    def __eq__(self, other):
        if not isinstance(other, MultiDiscrete):
            return False
        return np.array_equal(self.low, other.low) and np.array_equal(self.high, other.high)