import os
import random
import tempfile
import platform
from typing import List, Tuple, Dict, Any, Optional

import pytest
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim.lr_scheduler import LambdaLR
import numpy as np

# Simple dummy environment if multiagent-particle-envs not available
try:
    from multiagent_particle_envs import MultiAgentParticleEnv
except Exception:
    class DummyEnv:
        def __init__(self, n_agents=3, obs_dim=10, action_dim=2):
            self.n_agents = n_agents
            self.observation_space = [np.zeros(obs_dim) for _ in range(n_agents)]
            self.action_space = [np.zeros(action_dim) for _ in range(n_agents)]
            self.reset()
        def reset(self):
            self.state = np.random.randn(self.n_agents, len(self.observation_space[0]))
            return self.state
        def step(self, actions):
            self.state = np.random.randn(self.n_agents, len(self.observation_space[0]))
            rewards = np.random.randn(self.n_agents)
            dones = [False]*self.n_agents
            return self.state, rewards, dones, {}
    MultiAgentParticleEnv = DummyEnv

# ----------------- Network definitions -----------------
class Actor(nn.Module):
    def __init__(self, obs_dim: int, action_dim: int, action_range: Tuple[float, float]):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim, 64), nn.ReLU(),
            nn.Linear(64, 64), nn.ReLU(),
            nn.Linear(64, action_dim)
        )
        self.action_low, self.action_high = action_range
    def forward(self, x: torch.Tensor):
        out = torch.tanh(self.net(x))
        return self.action_low + (self.action_high - self.action_low) * (out + 1) / 2

class ActorDiscrete(nn.Module):
    def __init__(self, obs_dim: int, action_dim: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim, 64), nn.ReLU(),
            nn.Linear(64, 64), nn.ReLU(),
            nn.Linear(64, action_dim)
        )
    def forward(self, x: torch.Tensor):
        logits = self.net(x)
        return F.softmax(logits, dim=-1)

class Critic(nn.Module):
    def __init__(self, obs_dim: int, action_dim: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim + action_dim, 128), nn.ReLU(),
            nn.Linear(128, 64), nn.ReLU(),
            nn.Linear(64, 1)
        )
    def forward(self, obs: torch.Tensor, act: torch.Tensor):
        x = torch.cat([obs, act], dim=-1)
        return self.net(x)

# ----------------- Replay Buffer -----------------
class ReplayBuffer:
    def __init__(self, capacity: int):
        self.capacity = capacity
        self.buffer: List[Tuple] = []
    def push(self, *transition):
        if len(self.buffer) >= self.capacity:
            self.buffer.pop(0)
        self.buffer.append(transition)
    def sample(self, batch_size: int):
        return random.sample(self.buffer, batch_size)
    def __len__(self):
        return len(self.buffer)

# ----------------- MADDPG placeholder -----------------
class MADDPG:
    def __init__(
        self,
        n_agents: int,
        obs_dim: int,
        action_dim: int,
        action_range: Tuple[float, float] = (-1, 1),
        discrete: bool = False,
        device: torch.device = torch.device('cpu'),
        lr: float = 1e-3,
        lr_scheduler: Optional[LambdaLR] = None,
        buffer_capacity: int = 10000,
        batch_size: int = 32,
        actor_kwargs: Optional[Dict[str, Any]] = None,
        critic_kwargs: Optional[Dict[str, Any]] = None,
        visualize: bool = False,
        visual_dir: Optional[str] = None
    ):
        self.n_agents = n_agents
        self.obs_dim = obs_dim
        self.action_dim = action_dim
        self.discrete = discrete
        self.device = device
        self.lr = lr
        self.batch_size = batch_size
        self.lr_scheduler = lr_scheduler
        self.visualize = visualize
        self.visual_dir = visual_dir
        self.buffer = ReplayBuffer(buffer_capacity)

        actor_cls = ActorDiscrete if discrete else Actor
        actor_args = actor_kwargs or {}
        critic_args = critic_kwargs or {}

        self.actors = nn.ModuleList([
            actor_cls(obs_dim, action_dim, action_range).to(device) for _ in range(n_agents)
        ])
        self.target_actors = nn.ModuleList([
            actor_cls(obs_dim, action_dim, action_range).to(device) for _ in range(n_agents)
        ])
        self.critics = nn.ModuleList([
            Critic(obs_dim, action_dim).to(device) for _ in range(n_agents)
        ])
        self.target_critics = nn.ModuleList([
            Critic(obs_dim, action_dim).to(device) for _ in range(n_agents)
        ])

        self.actor_optims = [torch.optim.Adam(a.parameters(), lr=lr) for a in self.actors]
        self.critic_optims = [torch.optim.Adam(c.parameters(), lr=lr) for c in self.critics]

        # Copy weights to target networks
        for tgt, src in zip(self.target_actors, self.actors):
            tgt.load_state_dict(src.state_dict())
        for tgt, src in zip(self.target_critics, self.critics):
            tgt.load_state_dict(src.state_dict())

    @classmethod
    def from_dict(cls, cfg: Dict[str, Any]):
        return cls(**cfg)

    def act(self, obs: torch.Tensor, noise: Optional[torch.Tensor] = None, eps: float = 0.0) -> torch.Tensor:
        actions = []
        for actor, o in zip(self.actors, obs):
            act = actor(o)
            if not self.discrete:
                act = act.detach()
                if noise is not None:
                    act = act + noise
                act = act.clamp(-1, 1)
            else:
                probs = act
                m = torch.distributions.Categorical(probs)
                act = m.sample()
                if noise is not None:
                    act = act + noise
            actions.append(act)
        return torch.stack(actions)

    def criticize(self, obs: torch.Tensor, acts: torch.Tensor, target: bool = False) -> torch.Tensor:
        q_values = []
        for critic, o, a in zip(self.critics if not target else self.target_critics, obs, acts):
            q = critic(o, a)
            q_values.append(q)
        return torch.stack(q_values)

    def store_episode(self, obs, actions, rewards, next_obs, dones, info):
        self.buffer.push(obs, actions, rewards, next_obs, dones, info)

    def update(self):
        if len(self.buffer) < self.batch_size:
            return
        batch = self.buffer.sample(self.batch_size)
        for idx in range(self.n_agents):
            obs_batch = torch.stack([b[0][idx] for b in batch]).to(self.device)
            act_batch = torch.stack([b[1][idx] for b in batch]).to(self.device)
            reward_batch = torch.tensor([b[2][idx] for b in batch], dtype=torch.float32, device=self.device)
            next_obs_batch = torch.stack([b[3][idx] for b in batch]).to(self.device)
            done_batch = torch.tensor([b[4][idx] for b in batch], dtype=torch.float32, device=self.device)

            target_q = self.criticiate(next_obs_batch, act_batch, target=True).squeeze()
            target = reward_batch + (1 - done_batch) * 0.95 * target_q

            current_q = self.criticiate(obs_batch, act_batch, target=False).squeeze()
            critic_loss = F.mse_loss(current_q, target.detach())

            self.critic_optims[idx].zero_grad()
            critic_loss.backward()
            self.critic_optims[idx].step()

            actor_loss = -self.criticiate(obs_batch, self.actors[idx](obs_batch)).mean()

            self.actor_optims[idx].zero_grad()
            actor_loss.backward()
            self.actor_optims[idx].step()

        if self.lr_scheduler:
            self.lr_scheduler.step()

    def save(self, path: str, actor_prefix: str = "actor_", critic_prefix: str = "critic_"):
        for idx, actor in enumerate(self.actors):
            torch.save(actor.state_dict(), os.path.join(path, f"{actor_prefix}{idx}.pt"))
        for idx, critic in enumerate(self.critics):
            torch.save(critic.state_dict(), os.path.join(path, f"{critic_prefix}{idx}.pt"))

    def load(self, path: str, actor_prefix: str = "actor_", critic_prefix: str = "critic_"):
        for idx, actor in enumerate(self.actors):
            actor.load_state_dict(torch.load(os.path.join(path, f"{actor_prefix}{idx}.pt")))
        for idx, critic in enumerate(self.critics):
            critic.load_state_dict(torch.load(os.path.join(path, f"{critic_prefix}{idx}.pt")))

# ----------------- Noise functions -----------------
def uniform_noise(shape, low=-1, high=1):
    return torch.FloatTensor(shape).uniform_(low, high)

def normal_noise(shape, mean=0.0, std=0.1):
    return torch.normal(mean, std, size=shape)

def clipped_normal_noise(shape, mean=0.0, std=0.1, low=-1, high=1):
    noise = torch.normal(mean, std, size=shape)
    return noise.clamp(low, high)

def ou_noise(shape, theta=0.15, sigma=0.2, dt=1e-2):
    noise = torch.randn(shape) * sigma
    return noise * theta * dt

# ----------------- Fixtures -----------------
@pytest.fixture
def train_config():
    cfg = {
        "env_name": "simple_spread",
        "n_agents": 3,
        "obs_dim": 10,
        "action_dim": 2,
        "action_range": (-1.0, 1.0),
        "max_episodes": 50,
        "max_steps": 100,
        "replay_buffer_size": 1000,
        "batch_size": 32,
        "lr": 1e-3,
    }
    env = MultiAgentParticleEnv(n_agents=cfg["n_agents"],
                                obs_dim=cfg["obs_dim"],
                                action_dim=cfg["action_dim"])
    cfg["env"] = env
    return cfg

@pytest.fixture
def maddpg_discrete(train_config):
    cfg = train_config.copy()
    cfg["discrete"] = True
    cfg["action_dim"] = 4
    cfg["obs_dim"] = 8
    return MADDPG.from_dict(cfg)

@pytest.fixture
def maddpg_continuous(train_config):
    cfg = train_config.copy()
    cfg["discrete"] = False
    cfg["action_dim"] = 2
    cfg["obs_dim"] = 10
    return MADDPG.from_dict(cfg)

@pytest.fixture
def maddpg_visual(train_config, tmp_path):
    cfg = train_config.copy()
    cfg["visualize"] = True
    cfg["visual_dir"] = str(tmp_path)
    return MADDPG.from_dict(cfg)

@pytest.fixture
def maddpg_lr_scheduler(train_config):
    cfg = train_config.copy()
    lr_lambda = lambda epoch: 0.95 ** epoch
    scheduler = LambdaLR(torch.optim.Adam([torch.nn.Parameter(torch.randn(1))], lr=cfg["lr"]), lr_lambda)
    cfg["lr_scheduler"] = scheduler
    return MADDPG.from_dict(cfg)

# ----------------- Test cases -----------------
def test_contiguous_act(maddpg_continuous):
    obs = torch.randn(maddpg_continuous.n_agents, maddpg_continuous.obs_dim)
    noise = normal_noise((maddpg_continuous.n_agents, maddpg_continuous.action_dim))
    acts = maddpg_continuous.act(obs, noise=noise)
    assert acts.shape == (maddpg_continuous.n_agents, maddpg_continuous.action_dim)
    assert torch.all(acts >= -1) and torch.all(acts <= 1)

def test_discrete_act(maddpg_discrete):
    obs = torch.randn(maddpg_discrete.n_agents, maddpg_discrete.obs_dim)
    acts = maddpg_discrete.act(obs)
    assert acts.shape == (maddpg_discrete.n_agents,)
    assert torch.all((acts >= 0) & (acts < maddpg_discrete.action_dim))

def test__criticize(maddpg_continuous):
    obs = torch.randn(maddpg_continuous.n_agents, maddpg_continuous.obs_dim)
    acts = maddpg_continuous.act(obs)
    q = maddpg_continuous.criticize(obs, acts)
    assert q.shape == (maddpg_continuous.n_agents, 1)

def test_store_episodes(maddpg_continuous):
    obs = torch.randn(maddpg_continuous.n_agents, maddpg_continuous.obs_dim)
    acts = maddpg_continuous.act(obs)
    rewards = torch.randn(maddpg_continuous.n_agents)
    next_obs = torch.randn(maddpg_continuous.n_agents, maddpg_continuous.obs_dim)
    dones = torch.zeros(maddpg_continuous.n_agents)
    info = {}
    maddpg_continuous.store_episode(obs, acts, rewards, next_obs, dones, info)
    assert len(maddpg_continuous.buffer) == 1

def test_update(maddpg_continuous):
    # Populate buffer
    for _ in range(50):
        obs = torch.randn(maddpg_continuous.n_agents, maddpg_continuous.obs_dim)
        acts = maddpg_continuous.act(obs)
        rewards = torch.randn(maddpg_continuous.n_agents)
        next_obs = torch.randn(maddpg_continuous.n_agents, maddpg_continuous.obs_dim)
        dones = torch.zeros(maddpg_continuous.n_agents)
        info = {}
        maddpg_continuous.store_episode(obs, acts, rewards, next_obs, dones, info)
    initial_weights = [w.clone() for w in maddpg_continuous.actors[0].parameters()]
    maddpg_continuous.update()
    updated_weights = [w for w in maddpg_continuous.actors[0].parameters()]
    assert not all(torch.equal(a, b) for a, b in zip(initial_weights, updated_weights))

def test_vis_update(maddpg_visual):
    # Simple visual update check
    maddpg_visual.update()
    # No assertion needed; if no exception, pass

def test_save_load(maddpg_continuous, tmp_path):
    save_dir = tmp_path / "models"
    save_dir.mkdir()
    maddpg_continuous.save(str(save_dir))
    new_maddpg = MADDPG.from_dict(maddpg_continuous.__dict__)
    new_maddpg.load(str(save_dir))
    # Check that loaded weights match original
    for orig, loaded in zip(maddpg_continuous.actors[0].parameters(), new_maddpg.actors[0].parameters()):
        assert torch.allclose(orig, loaded)

def test_lr_scheduler(maddpg_lr_scheduler):
    # Ensure scheduler steps
    pre_lr = maddpg_lr_scheduler.actor_optims[0].param_groups[0]["lr"]
    maddpg_lr_scheduler.update()
    post_lr = maddpg_lr_scheduler.actor_optims[0].param_groups[0]["lr"]
    assert post_lr <= pre_lr

def test_config_init(train_config):
    cfg = train_config.copy()
    cfg["discrete"] = False
    cfg["action_dim"] = 3
    maddpg = MADDPG.from_dict(cfg)
    assert maddpg.n_agents == cfg["n_agents"]
    assert maddpg.action_dim == cfg["action_dim"]

def test_full_train():
    if platform.system() != "Linux":
        pytest.skip("Full training test is Linux-only")
    env = MultiAgentParticleEnv(n_agents=3, obs_dim=10, action_dim=2)
    maddpg = MADDPG(
        n_agents=3,
        obs_dim=10,
        action_dim=2,
        action_range=(-1, 1),
        device=torch.device('cpu'),
        lr=1e-3,
        batch_size=32,
        replay_buffer_size=1000
    )
    max_episodes = 20
    max_steps = 50
    reward_threshold = 5.0
    for ep in range(max_episodes):
        obs = env.reset()
        ep_reward = 0.0
        for step in range(max_steps):
            obs_tensor = torch.tensor(obs, dtype=torch.float32)
            acts = maddpg.act(obs_tensor)
            next_obs, rewards, dones, _ = env.step(acts.numpy())
            maddpg.store_episode(obs_tensor, acts, torch.tensor(rewards), torch.tensor(next_obs), torch.tensor(dones), {})
            maddpg.update()
            obs = next_obs
            ep_reward += sum(rewards)
            if all(dones):
                break
        if ep_reward >= reward_threshold:
            break
    else:
        pytest.fail("Environment not solved within max episodes")
    assert ep_reward >= reward_threshold
