import argparse

from keras.models import Sequential, Model, Input
from keras.layers import Dense, Flatten, Activation, Concatenate
from keras.optimizers import Adam

from rl.agents import (
    CEMAgent,
    DDPGAgent,
    DQNAgent,
    NAFAgent,
)
from rl.memory import EpisodeParameterMemory, SequentialMemory
from rl.explorations import OrnsteinUhlenbeckProcess, BoltzmannQPolicy
from rl.policy import EpsGreedyQPolicy


def add_opts(parser):
    parser.add_argument(
        "--model-type",
        type=int,
        default=1,
        choices=[1, 2],
        help="Model architecture type: 1 for simple, 2 for deeper.",
    )
    return parser


class TemplateAgent:
    def __init__(self, opts):
        self.opts = opts
        self.agent = None

    def configure(self, env):
        raise NotImplementedError

    def train(self, env, nb_steps=50000, visualize=False, verbosity=1, **kwargs):
        if self.agent is None:
            self.configure(env)
        self.agent.fit(
            env,
            nb_steps=nb_steps,
            visualize=visualize,
            verbose=verbosity,
            **kwargs,
        )

    def test(self, env, nb_episodes=5, visualize=False):
        if self.agent is None:
            self.configure(env)
        self.agent.test(env, nb_episodes=nb_episodes, visualize=visualize)

    def load_weights(self, filepath):
        if self.agent is None:
            raise RuntimeError("Agent not configured")
        self.agent.load_weights(filepath)

    def save_weights(self, filepath, overwrite=True):
        if self.agent is None:
            raise RuntimeError("Agent not configured")
        self.agent.save_weights(filepath, overwrite=overwrite)


class KerasCEMAgent(TemplateAgent):
    def _build_model(self, observation_shape, nb_actions):
        model = Sequential()
        model.add(Flatten(input_shape=(1,) + observation_shape))
        if self.opts.model_type == 1:
            model.add(Dense(32, activation="relu"))
            model.add(Dense(nb_actions, activation="softmax"))
        else:
            model.add(Dense(64, activation="relu"))
            model.add(Dense(64, activation="relu"))
            model.add(Dense(nb_actions, activation="softmax"))
        return model

    def configure(self, env):
        model = self._build_model(
            env.observation_space.shape, env.action_space.n
        )
        memory = EpisodeParameterMemory(
            capacity=50000, nb_steps_warmup=1000
        )
        self.agent = CEMAgent(
            model=model,
            memory=memory,
            nb_steps_warmup=1000,
            elite_frac=0.05,
            gamma=0.95,
            batch_size=64,
            nb_steps_warmup=1000,
            nb_episode_steps=env._max_episode_steps,
        )


class KerasDDPGAgent(TemplateAgent):
    def _build_actor(self, observation_shape, action_shape):
        model = Sequential()
        model.add(Flatten(input_shape=(1,) + observation_shape))
        if self.opts.model_type == 1:
            model.add(Dense(32, activation="relu"))
        else:
            model.add(Dense(64, activation="relu"))
            model.add(Dense(64, activation="relu"))
        model.add(Dense(action_shape[0], activation="tanh"))
        return model

    def _build_critic(self, observation_shape, action_shape):
        obs_input = Input(shape=(1,) + observation_shape, name="observation")
        act_input = Input(shape=action_shape, name="action")
        merged = Concatenate()([Flatten()(obs_input), act_input])
        if self.opts.model_type == 1:
            x = Dense(32, activation="relu")(merged)
        else:
            x = Dense(64, activation="relu")(merged)
            x = Dense(64, activation="relu")(x)
        out = Dense(1, activation="linear")(x)
        model = Model(inputs=[obs_input, act_input], outputs=out)
        return model, act_input

    def configure(self, env):
        actor = self._build_actor(env.observation_space.shape, env.action_space.shape)
        critic, critic_action_input = self._build_critic(
            env.observation_space.shape, env.action_space.shape
        )
        memory = SequentialMemory(limit=50000, window_length=1)
        exploration = OrnsteinUhlenbeckProcess(
            mu=0,
            theta=0.15,
            sigma=0.2,
            size=env.action_space.shape[0],
        )
        self.agent = DDPGAgent(
            actor=actor,
            critic=critic,
            critic_action_input=critic_action_input,
            memory=memory,
            nb_steps_warmup_actor=1000,
            nb_steps_warmup_critic=1000,
            batch_size=64,
            gamma=0.99,
            target_model_update=1e-3,
            exploration=exploration,
            nb_episode_steps=env._max_episode_steps,
        )
        self.agent.compile(Adam(lr=0.001), metrics=["mse"])


class KerasDQNAgent(TemplateAgent):
    def _build_model(self, observation_shape, nb_actions):
        model = Sequential()
        model.add(Flatten(input_shape=(1,) + observation_shape))
        if self.opts.model_type == 1:
            model.add(Dense(32, activation="relu"))
        else:
            model.add(Dense(64, activation="relu"))
            model.add(Dense(64, activation="relu"))
        model.add(Dense(nb_actions, activation="linear"))
        return model

    def configure(self, env, enable_double=False):
        model = self._build_model(
            env.observation_space.shape, env.action_space.n
        )
        memory = SequentialMemory(limit=50000, window_length=1)
        policy = BoltzmannQPolicy()
        self.agent = DQNAgent(
            model=model,
            nb_actions=env.action_space.n,
            memory=memory,
            nb_steps_warmup=1000,
            target_model_update=1e-3,
            gamma=0.95,
            enable_double_dqn=enable_double,
            batch_size=64,
            policy=policy,
        )
        self.agent.compile(Adam(lr=0.001), metrics=["mae"])


class KerasDDQNAgent(KerasDQNAgent):
    def configure(self, env):
        super().configure(env, enable_double=True)


class KerasNAFAgent(TemplateAgent):
    def _build_v_model(self, observation_shape):
        model = Sequential()
        model.add(Flatten(input_shape=(1,) + observation_shape))
        if self.opts.model_type == 1:
            model.add(Dense(32, activation="relu"))
        else:
            model.add(Dense(64, activation="relu"))
            model.add(Dense(64, activation="relu"))
        model.add(Dense(1, activation="linear"))
        return model

    def _build_mu_model(self, observation_shape, action_shape):
        model = Sequential()
        model.add(Flatten(input_shape=(1,) + observation_shape))
        if self.opts.model_type == 1:
            model.add(Dense(32, activation="relu"))
        else:
            model.add(Dense(64, activation="relu"))
            model.add(Dense(64, activation="relu"))
        model.add(Dense(action_shape[0], activation="tanh"))
        return model

    def _build_l_model(self, observation_shape, action_shape):
        model = Sequential()
        model.add(Flatten(input_shape=(1,) + observation_shape))
        if self.opts.model_type == 1:
            model.add(Dense(32, activation="relu"))
        else:
            model.add(Dense(64, activation="relu"))
            model.add(Dense(64, activation="relu"))
        model.add(Dense(action_shape[0] * (action_shape[0] + 1) // 2, activation="linear"))
        return model

    def configure(self, env):
        V_model = self._build_v_model(env.observation_space.shape)
        mu_model = self._build_mu_model(env.observation_space.shape, env.action_space.shape)
        L_model = self._build_l_model(env.observation_space.shape, env.action_space.shape)
        memory = SequentialMemory(limit=50000, window_length=1)
        exploration = OrnsteinUhlenbeckProcess(
            mu=0,
            theta=0.15,
            sigma=0.2,
            size=env.action_space.shape[0],
        )
        self.agent = NAFAgent(
            V_model=V_model,
            mu_model=mu_model,
            L_model=L_model,
            nb_actions=env.action_space.shape[0],
            memory=memory,
            nb_steps_warmup=1000,
            gamma=0.95,
            target_model_update=1e-3,
            batch_size=64,
            exploration=exploration,
            nb_episode_steps=env._max_episode_steps,
        )
        self.agent.compile(Adam(lr=0.001), metrics=["mae"])
```