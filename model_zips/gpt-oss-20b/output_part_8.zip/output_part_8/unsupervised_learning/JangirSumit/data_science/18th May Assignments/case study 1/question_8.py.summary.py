import numpy as np

arr = np.random.random((10, 10))
print(arr)
print(f"Max value: {arr.max()}")
print(f"Min value: {arr.min()}")