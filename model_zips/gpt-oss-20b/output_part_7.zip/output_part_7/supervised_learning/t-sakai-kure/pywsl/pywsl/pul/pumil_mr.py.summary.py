import numpy as np
from scipy.linalg import solve
from pu_risk import calc_risk

class PUMIL_SL:
    def __init__(self, prior: float, degree: int, lam: float, basis: str = "minimax", n_basis: int = 100):
        if not 0.0 <= prior <= 1.0:
            raise ValueError("prior must be between 0 and 1.")
        if basis != "minimax":
            raise ValueError("Unsupported basis; only 'minimax' is implemented.")
        self.prior = prior
        self.degree = degree
        self.lam = lam
        self.basis = basis
        self.n_basis = n_basis
        self._x_c = None
        self.coef_ = None

    def _validate_target(self, y):
        unique = np.unique(y)
        if set(unique) != {0, 1}:
            raise ValueError("Target y must contain only 0 (unlabeled) and 1 (positive).")

    def _to_bags(self, X):
        if isinstance(X, np.ndarray):
            return [np.array(row) for row in X]
        if isinstance(X, list):
            return [np.array(bag) for bag in X]
        raise TypeError("X must be a numpy array or list of arrays.")

    def _select_basis(self, x_u):
        b = min(self.n_basis, len(x_u))
        indices = np.random.choice(len(x_u), size=b, replace=False)
        self._x_c = [x_u[i] for i in indices]

    def _stat(self, bag):
        max_vals = bag.max(axis=0)
        min_vals = bag.min(axis=0)
        return np.concatenate([max_vals, min_vals])

    def _ker(self, bags, centers):
        sx = np.vstack([self._stat(bag) for bag in bags])
        sc = np.vstack([self._stat(center) for center in centers])
        K = (sx @ sc.T + 1) ** self.degree
        return K

    def fit(self, X, y):
        y = np.asarray(y).ravel()
        self._validate_target(y)
        bags = self._to_bags(X)
        if len(bags) != len(y):
            raise ValueError("Number of bags and labels must match.")
        pos_idx = np.where(y == 1)[0]
        unl_idx = np.where(y == 0)[0]
        x_p = [bags[i] for i in pos_idx]
        x_u = [bags[i] for i in unl_idx]
        self._select_basis(x_u)
        k_p = self._ker(x_p, self._x_c)
        k_u = self._ker(x_u, self._x_c)
        n_u = len(k_u)
        H = (k_u.T @ k_u) / n_u
        h = 2 * self.prior * k_p.mean(axis=0) - k_u.mean(axis=0)
        R = self.lam * np.eye(H.shape[0])
        self.coef_ = solve(H + R, h)
        return self

    def predict(self, X):
        if self.coef_ is None:
            raise RuntimeError("Model has not been fitted yet.")
        bags = self._to_bags(X)
        K = self._ker(bags, self._x_c)
        scores = K @ self.coef_
        preds = np.sign(scores + 0.1)
        return preds.astype(int)

    def score(self, X, y):
        if self.coef_ is None:
            raise RuntimeError("Model has not been fitted yet.")
        y = np.asarray(y).ravel()
        self._validate_target(y)
        bags = self._to_bags(X)
        pos_idx = np.where(y == 1)[0]
        unl_idx = np.where(y == 0)[0]
        x_p = [bags[i] for i in pos_idx]
        x_u = [bags[i] for i in unl_idx]
        k_p = self._ker(x_p, self._x_c)
        k_u = self._ker(x_u, self._x_c)
        g_p = k_p @ self.coef_
        g_u = k_u @ self.coef_
        pu_risk = calc_risk(g_p, g_u, self.prior)
        return 1.0 - pu_risk
