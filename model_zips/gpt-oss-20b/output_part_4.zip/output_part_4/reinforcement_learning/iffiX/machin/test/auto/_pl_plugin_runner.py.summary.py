import os
import sys
import pickle

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
import pytorch_lightning as pl
import torch.distributed as dist


class NNModule(nn.Module):
    def __init__(self):
        super().__init__()
        self.linear = nn.Linear(10, 10)

    def forward(self, x):
        return x.sum()


class ParallelModule(pl.LightningModule):
    def __init__(self):
        super().__init__()
        self.nn_model = NNModule()
        self.frame = None

    def train_dataloader(self):
        dataset = TensorDataset(torch.ones(5, 10))
        return DataLoader(dataset, batch_size=1)

    def training_step(self, batch, batch_idx):
        if not dist.is_available():
            raise RuntimeError("Distributed package not available")
        if not dist.is_initialized():
            raise RuntimeError("Distributed world not initialized")
        if not isinstance(self.nn_model, NNModule):
            raise RuntimeError("nn_model is not an instance of NNModule")

        if dist.get_rank() == 0:
            save_path = os.environ.get("TEST_SAVE_PATH")
            if save_path is None:
                raise RuntimeError("TEST_SAVE_PATH environment variable not set")
            data = [isinstance(self.nn_model, NNModule)]
            with open(save_path, "wb") as f:
                pickle.dump(data, f)

        return {"loss": torch.tensor(0.0)}

    def configure_optimizers(self):
        return None


if __name__ == "__main__":
    # Set environment variables for distributed training
    os.environ["WORLD_SIZE"] = "3"
    os.environ["NODE_RANK"] = "0"
    if len(sys.argv) < 3:
        raise RuntimeError("Missing arguments: <accelerator> <local_rank>")
    os.environ["LOCAL_RANK"] = sys.argv[2]

    accelerator = sys.argv[1]
    trainer = pl.Trainer(
        accelerator=accelerator,
        num_nodes=1,
        num_processes=3,
        max_steps=1,
        limit_train_batches=1,
    )

    # Assert the distributed backend matches the input argument
    strategy_name = trainer.strategy.__class__.__name__.lower()
    assert strategy_name.startswith(accelerator), f"Expected {accelerator}, got {strategy_name}"

    model = ParallelModule()
    trainer.fit(model)