import numpy as np
import chainer
import chainer.functions as F
import chainer.links as L
import chainer.initializers as init
from chainer import Variable


def bound_by_tanh(x, min_action, max_action):
    scale = (max_action - min_action) / 2.0
    offset = (max_action + min_action) / 2.0
    return F.tanh(x) * scale + offset


class GaussianDistribution:
    def __init__(self, mean, var):
        self.mean = mean
        self.var = var

    def sample(self, rng=None):
        if rng is None:
            rng = np.random.default_rng()
        mean_np = chainer.to_cpu(self.mean.data)
        var_np = chainer.to_cpu(self.var.data)
        std_np = np.sqrt(var_np)
        return rng.normal(mean_np, std_np)


class FCGaussianPolicy(chainer.Chain):
    def __init__(
        self,
        n_input_channels,
        action_size,
        n_hidden_layers=0,
        n_hidden_channels=None,
        bound_mean=False,
        min_action=None,
        max_action=None,
        var_type="spherical",
        min_var=1e-5,
        nonlinearity=F.relu,
    ):
        super().__init__()
        if n_hidden_layers > 0 and n_hidden_channels is None:
            raise ValueError("n_hidden_channels must be specified when n_hidden_layers > 0")
        self.action_size = action_size
        self.n_hidden_layers = n_hidden_layers
        self.bound_mean = bound_mean
        self.min_action = min_action
        self.max_action = max_action
        self.min_var = min_var
        self.var_type = var_type
        self.nonlinearity = nonlinearity

        var_size = 1 if var_type == "spherical" else action_size

        with self.init_scope():
            if n_hidden_layers > 0:
                self.hidden_layers = L.ChainList()
                in_dim = n_input_channels
                for i in range(n_hidden_layers):
                    self.hidden_layers.append(
                        L.Linear(
                            in_dim,
                            n_hidden_channels,
                            initialW=init.LeCunNormal(),
                        )
                    )
                    in_dim = n_hidden_channels
                mean_in_dim = n_hidden_channels
                var_in_dim = n_hidden_channels
            else:
                mean_in_dim = n_input_channels
                var_in_dim = n_input_channels

            self.mean_layer = L.Linear(
                mean_in_dim,
                action_size,
                initialW=init.LeCunNormal(),
            )
            self.var_layer = L.Linear(
                var_in_dim,
                var_size,
                initialW=init.LeCunNormal(),
            )

    def __call__(self, x):
        h = x
        if self.n_hidden_layers > 0:
            for layer in self.hidden_layers:
                h = self.nonlinearity(layer(h))
        mean = self.mean_layer(h)
        if self.bound_mean:
            if self.min_action is None or self.max_action is None:
                raise ValueError("min_action and max_action must be set when bound_mean is True")
            mean = bound_by_tanh(mean, self.min_action, self.max_action)
        var = F.softplus(self.var_layer(h)) + self.min_var
        return GaussianDistribution(mean, var)


class FCGaussianPolicyWithStateIndependentCovariance(chainer.Chain):
    def __init__(
        self,
        n_input_channels,
        action_size,
        n_hidden_layers=0,
        n_hidden_channels=None,
        bound_mean=False,
        min_action=None,
        max_action=None,
        var_type="spherical",
        var_func=F.softplus,
        var_param_init=0.0,
        nonlinearity=F.relu,
    ):
        super().__init__()
        if n_hidden_layers > 0 and n_hidden_channels is None:
            raise ValueError("n_hidden_channels must be specified when n_hidden_layers > 0")
        self.action_size = action_size
        self.n_hidden_layers = n_hidden_layers
        self.bound_mean = bound_mean
        self.min_action = min_action
        self.max_action = max_action
        self.var_type = var_type
        self.var_func = var_func
        self.var_param_init = var_param_init
        self.nonlinearity = nonlinearity

        var_size = 1 if var_type == "spherical" else action_size

        with self.init_scope():
            if n_hidden_layers > 0:
                self.hidden_layers = L.ChainList()
                in_dim = n_input_channels
                for i in range(n_hidden_layers):
                    self.hidden_layers.append(
                        L.Linear(
                            in_dim,
                            n_hidden_channels,
                            initialW=init.LeCunNormal(),
                        )
                    )
                    in_dim = n_hidden_channels
                mean_in_dim = n_hidden_channels
            else:
                mean_in_dim = n_input_channels

            self.mean_layer = L.Linear(
                mean_in_dim,
                action_size,
                initialW=init.LeCunNormal(),
            )

            self.var_param = chainer.Parameter(
                init.Constant(self.var_param_init, shape=(var_size,))
            )

    def __call__(self, x):
        h = x
        if self.n_hidden_layers > 0:
            for layer in self.hidden_layers:
                h = self.nonlinearity(layer(h))
        mean = self.mean_layer(h)
        if self.bound_mean:
            if self.min_action is None or self.max_action is None:
                raise ValueError("min_action and max_action must be set when bound_mean is True")
            mean = bound_by_tanh(mean, self.min_action, self.max_action)
        var = self.var_func(self.var_param)
        if var.ndim == 0:
            var = F.broadcast_to(var, mean.shape)
        else:
            var = F.broadcast_to(var, mean.shape)
        return GaussianDistribution(mean, var)


class FCGaussianPolicyWithFixedCovariance(chainer.Chain):
    def __init__(
        self,
        n_input_channels,
        action_size,
        n_hidden_layers=0,
        n_hidden_channels=None,
        bound_mean=False,
        min_action=None,
        max_action=None,
        var=None,
        nonlinearity=F.relu,
    ):
        super().__init__()
        if n_hidden_layers > 0 and n_hidden_channels is None:
            raise ValueError("n_hidden_channels must be specified when n_hidden_layers > 0")
        self.action_size = action_size
        self.n_hidden_layers = n_hidden_layers
        self.bound_mean = bound_mean
        self.min_action = min_action
        self.max_action = max_action
        self.nonlinearity = nonlinearity
        if var is None:
            raise ValueError("var must be specified")
        self.fixed_var = Variable(np.array(var, dtype=np.float32))

        with self.init_scope():
            if n_hidden_layers > 0:
                self.hidden_layers = L.ChainList()
                in_dim = n_input_channels
                for i in range(n_hidden_layers):
                    self.hidden_layers.append(
                        L.Linear(
                            in_dim,
                            n_hidden_channels,
                            initialW=init.LeCunNormal(),
                        )
                    )
                    in_dim = n_hidden_channels
                mean_in_dim = n_hidden_channels
            else:
                mean_in_dim = n_input_channels

            self.mean_layer = L.Linear(
                mean_in_dim,
                action_size,
                initialW=init.LeCunNormal(),
            )

    def __call__(self, x):
        h = x
        if self.n_hidden_layers > 0:
            for layer in self.hidden_layers:
                h = self.nonlinearity(layer(h))
        mean = self.mean_layer(h)
        if self.bound_mean:
            if self.min_action is None or self.max_action is None:
                raise ValueError("min_action and max_action must be set when bound_mean is True")
            mean = bound_by_tanh(mean, self.min_action, self.max_action)
        var = F.broadcast_to(self.fixed_var, mean.shape)
        return GaussianDistribution(mean, var)


class GaussianHeadWithStateIndependentCovariance(chainer.Chain):
    def __init__(
        self,
        action_size,
        var_type="spherical",
        var_func=F.softplus,
        var_param_init=0.0,
    ):
        super().__init__()
        self.action_size = action_size
        self.var_type = var_type
        self.var_func = var_func
        self.var_param_init = var_param_init

        var_size = 1 if var_type == "spherical" else action_size

        with self.init_scope():
            self.var_param = chainer.Parameter(
                init.Constant(self.var_param_init, shape=(var_size,))
            )

    def __call__(self, mean):
        var = self.var_func(self.var_param)
        if var.ndim == 0:
            var = F.broadcast_to(var, mean.shape)
        else:
            var = F.broadcast_to(var, mean.shape)
        return GaussianDistribution(mean, var)