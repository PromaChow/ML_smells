import gym
import torch
import torch.nn as nn
import torch.distributed.rpc as rpc
import torch.multiprocessing as mp
from collections import deque
import os

# ------------------------------------------------------------
# Actor network definition
# ------------------------------------------------------------
class ActorDiscrete(nn.Module):
    def __init__(self, observe_dim: int, action_num: int):
        super().__init__()
        self.linear = nn.Linear(observe_dim, action_num, bias=False)

    def forward(self, x):
        return self.linear(x)

# ------------------------------------------------------------
# Server-side RPC functions (only defined on rank 0)
# ------------------------------------------------------------
def _init_server(actor: nn.Module):
    global _actor
    _actor = actor

def _get_params():
    return {k: v.clone() for k, v in _actor.state_dict().items()}

def _set_params(param_dict):
    _actor.load_state_dict(param_dict)
    return True

def _apply_update(update_dict):
    with torch.no_grad():
        for name, param in _actor.named_parameters():
            param.add_(update_dict[name])
    return _get_params()

def _add_reward(r):
    global _reward_list
    _reward_list.append(r)

def _get_and_reset_rewards():
    global _reward_list
    rewards = list(_reward_list)
    _reward_list.clear()
    return rewards

# ------------------------------------------------------------
# ARS algorithm implementation
# ------------------------------------------------------------
class ARS:
    def __init__(self,
                 actor: nn.Module,
                 env: gym.Env,
                 noise_std_dev: float = 0.1,
                 learning_rate: float = 0.1,
                 noise_size: int = 1000000,
                 rollout_num: int = 6,
                 used_rollout_num: int = 6,
                 normalize_state: bool = True):
        self.actor = actor
        self.env = env
        self.noise_std_dev = noise_std_dev
        self.learning_rate = learning_rate
        self.noise_size = noise_size
        self.rollout_num = rollout_num
        self.used_rollout_num = used_rollout_num
        self.normalize_state = normalize_state
        self.rewards = []

    def act(self, state):
        with torch.no_grad():
            logits = self.actor(torch.tensor(state, dtype=torch.float32))
            action = logits.argmax().item()
        return action

    def store_reward(self, reward):
        self.rewards.append(reward)

    def _rollout(self, actor, max_steps):
        state = self.env.reset()
        total_reward = 0.0
        for _ in range(max_steps):
            action = actor(torch.tensor(state, dtype=torch.float32)).argmax().item()
            state, reward, done, _ = self.env.step(action)
            total_reward += reward
            if done:
                break
        return total_reward

    def update(self):
        # Get current parameters from server
        current_params = rpc.rpc_sync('server', _get_params)
        # Set local actor to current parameters
        self.actor.load_state_dict(current_params)

        # Generate a single noise sample for each parameter
        noise_dict = {}
        for name, param in self.actor.named_parameters():
            noise_dict[name] = torch.randn_like(param)

        # Evaluate plus perturbation
        plus_params = {}
        for name, param in current_params.items():
            plus_params[name] = param + self.noise_std_dev * noise_dict[name]
        rpc.rpc_sync('server', _set_params, args=(plus_params,))
        self.actor.load_state_dict(plus_params)
        reward_plus = self._rollout(self.actor, max_steps=200)

        # Evaluate minus perturbation
        minus_params = {}
        for name, param in current_params.items():
            minus_params[name] = param - self.noise_std_dev * noise_dict[name]
        rpc.rpc_sync('server', _set_params, args=(minus_params,))
        self.actor.load_state_dict(minus_params)
        reward_minus = self._rollout(self.actor, max_steps=200)

        # Compute update
        update_dict = {}
        for name in current_params:
            diff = reward_plus - reward_minus
            update_dict[name] = (self.learning_rate / (2.0 * self.noise_std_dev)) * diff * noise_dict[name]

        # Apply update on server
        rpc.rpc_sync('server', _apply_update, args=(update_dict,))

        # Update local actor with new parameters
        new_params = rpc.rpc_sync('server', _get_params)
        self.actor.load_state_dict(new_params)

# ------------------------------------------------------------
# Main training routine
# ------------------------------------------------------------
def main(rank, world_size):
    if rank == 0:
        rpc.init_rpc(name='server', rank=rank, world_size=world_size, backend=rpc.BackendName.GLOO)
    else:
        rpc.init_rpc(name=f'worker{rank}', rank=rank, world_size=world_size, backend=rpc.BackendName.GLOO)

    # Shared reward list on server
    global _reward_list
    _reward_list = deque()

    # Environment parameters
    observe_dim = 4
    action_num = 2
    max_episodes = 2000
    max_steps = 200
    solved_reward = 190
    solved_repeat = 5

    # Create environment
    env = gym.make('CartPole-v0')
    env._max_episode_steps = max_steps

    # Create actor network
    actor = ActorDiscrete(observe_dim, action_num)

    if rank == 0:
        _init_server(actor)

    # Wrap actor for RPC usage
    local_actor = ActorDiscrete(observe_dim, action_num)
    local_actor.load_state_dict(rpc.rpc_sync('server', _get_params))

    ars = ARS(
        actor=local_actor,
        env=env,
        noise_std_dev=0.1,
        learning_rate=0.1,
        noise_size=1000000,
        rollout_num=6,
        used_rollout_num=6,
        normalize_state=True
    )

    smoothed_reward = 0.0
    solved_counter = 0

    for episode in range(max_episodes):
        # Perform rollout using current policy
        total_reward = ars._rollout(ars.actor, max_steps)
        ars.store_reward(total_reward)

        # Update parameters
        ars.update()

        # Update smoothed reward
        smoothed_reward = 0.9 * smoothed_reward + 0.1 * total_reward
        if smoothed_reward >= solved_reward:
            solved_counter += 1
            if solved_counter >= solved_repeat:
                print(f"Rank {rank}: Solved after {episode + 1} episodes with smoothed reward {smoothed_reward:.2f}")
                break
        else:
            solved_counter = 0

    # Shutdown RPC
    rpc.shutdown()

if __name__ == '__main__':
    mp.set_start_method('spawn')
    world_size = 3
    mp.spawn(main, nprocs=world_size, join=True)