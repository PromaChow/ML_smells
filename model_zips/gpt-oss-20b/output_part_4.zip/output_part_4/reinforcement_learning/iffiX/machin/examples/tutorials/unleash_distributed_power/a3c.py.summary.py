import gym
import torch
import torch.nn as nn
import torch.multiprocessing as mp
import torch.distributions as dist
from machin.distributed import World, grad_server_helper
from machin.algorithms import A3C

# Hyperparameters
MAX_EPISODES = 2000
MAX_STEPS_PER_EPISODE = 200
REWARD_THRESHOLD = 190.0
SOLVED_EPISODES = 5
WORLD_SIZE = 3

class Actor(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(4, 16)
        self.fc2 = nn.Linear(16, 16)
        self.fc3 = nn.Linear(16, 2)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        logits = self.fc3(x)
        probs = torch.softmax(logits, dim=-1)
        dist_obj = dist.Categorical(probs)
        log_probs = dist_obj.log_prob
        entropy = dist_obj.entropy()
        return probs, log_probs, entropy

class Critic(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(4, 16)
        self.fc2 = nn.Linear(16, 16)
        self.fc3 = nn.Linear(16, 1)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        value = self.fc3(x)
        return value

def main(rank):
    # Distributed world setup
    world = World(rank=rank, world_size=WORLD_SIZE, backend='gloo')

    # Models
    actor = Actor()
    critic = Critic()

    # Gradient servers
    actor_server = grad_server_helper(actor, lr=5e-3)
    critic_server = grad_server_helper(critic, lr=5e-3)

    # A3C algorithm
    a3c = A3C(
        actor,
        critic,
        actor_server,
        critic_server,
        loss_func=nn.MSELoss(reduction='sum')
    )

    env = gym.make('CartPole-v0')
    smoothed_reward = 0.0
    solved_count = 0

    for episode in range(MAX_EPISODES):
        a3c.manual_sync()

        state = env.reset()
        episode_transitions = []
        total_reward = 0.0
        done = False

        for step in range(MAX_STEPS_PER_EPISODE):
            state_tensor = torch.tensor(state, dtype=torch.float32).unsqueeze(0)
            probs, log_probs, entropy = actor(state_tensor)
            action = torch.multinomial(probs, 1).item()
            next_state, reward, done, _ = env.step(action)

            episode_transitions.append((state, action, next_state, reward, done))

            state = next_state
            total_reward += reward

            if done:
                break

        a3c.store_episode(episode_transitions)
        a3c.update()

        smoothed_reward = 0.9 * smoothed_reward + 0.1 * total_reward
        print(f'Rank {rank} Episode {episode:04d} Reward: {total_reward:.2f} Smoothed: {smoothed_reward:.2f}')

        if smoothed_reward >= REWARD_THRESHOLD:
            solved_count += 1
            if solved_count >= SOLVED_EPISODES:
                print(f'Rank {rank} solved the environment after episode {episode}')
                break
        else:
            solved_count = 0

if __name__ == '__main__':
    mp.set_start_method('spawn')
    mp.spawn(main, nprocs=WORLD_SIZE, join=True)