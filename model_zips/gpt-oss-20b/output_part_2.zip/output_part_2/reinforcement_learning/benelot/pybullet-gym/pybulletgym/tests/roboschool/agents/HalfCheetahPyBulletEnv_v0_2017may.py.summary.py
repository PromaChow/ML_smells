import numpy as np

def linear_layer(inputs: np.ndarray, weights: np.ndarray, bias: np.ndarray) -> np.ndarray:
    return inputs @ weights + bias

def forward(
    inputs: np.ndarray,
    weights_dense1_w: np.ndarray,
    weights_dense1_b: np.ndarray,
    weights_dense2_w: np.ndarray,
    weights_dense2_b: np.ndarray,
    weights_final_w: np.ndarray,
    weights_final_b: np.ndarray,
) -> np.ndarray:
    x = linear_layer(inputs, weights_dense1_w, weights_dense1_b)
    x = linear_layer(x, weights_dense2_w, weights_dense2_b)
    x = linear_layer(x, weights_final_w.T, weights_final_b)
    return x

if __name__ == "__main__":
    batch_size = 32
    inputs = np.random.randn(batch_size, 512)
    weights_dense1_w = np.random.randn(512, 512)
    weights_dense1_b = np.random.randn(512)
    weights_dense2_w = np.random.randn(512, 512)
    weights_dense2_b = np.random.randn(512)
    weights_final_w = np.random.randn(60, 512)
    weights_final_b = np.random.randn(60)
    output = forward(
        inputs,
        weights_dense1_w,
        weights_dense1_b,
        weights_dense2_w,
        weights_dense2_b,
        weights_final_w,
        weights_final_b,
    )
    print(output.shape)  # Expected: (32, 60)