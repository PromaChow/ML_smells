import warnings

import gym
import numpy as np
import pytest
from gym import ObservationWrapper


class ScaledFloatFrame(ObservationWrapper):
    """
    Wrapper that scales image observations to the range [0, 1].
    """

    def __init__(self, env):
        super().__init__(env)
        # Preserve original shape and set dtype to float32
        shape = self.observation_space.shape
        self.observation_space = gym.spaces.Box(
            low=0.0, high=1.0, shape=shape, dtype=np.float32
        )
        warnings.warn(
            "ScaledFloatFrame may interfere with memory optimizations used by DQN. "
            "Use with caution.",
            RuntimeWarning,
        )

    def observation(self, observation):
        return observation.astype(np.float32) / 255.0


@pytest.mark.parametrize(
    "env_id",
    [
        "Pong-v0",
        "SpaceInvaders-v0",
    ],
)
def test_scaled_float_frame(env_id):
    env = gym.make(env_id)
    wrapped_env = ScaledFloatFrame(env)

    # Verify observation space limits
    assert np.allclose(wrapped_env.observation_space.low, 0.0)
    assert np.allclose(wrapped_env.observation_space.high, 1.0)

    # Check initial observation after reset
    obs = wrapped_env.reset()
    assert np.all(obs >= 0.0)
    assert np.all(obs <= 1.0)

    # Take a random action and check resulting observation
    action = wrapped_env.action_space.sample()
    obs, _, _, _ = wrapped_env.step(action)
    assert np.all(obs >= 0.0)
    assert np.all(obs <= 1.0)
    wrapped_env.close()