import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from collections import namedtuple

EpisodeStats = namedtuple('EpisodeStats', ['lengths', 'rewards'])

def plot_cost_to_go_mountain_car(estimator, env, grid_size=100):
    pos_min, vel_min = env.observation_space.low
    pos_max, vel_max = env.observation_space.high
    pos = np.linspace(pos_min, pos_max, grid_size)
    vel = np.linspace(vel_min, vel_max, grid_size)
    X, Y = np.meshgrid(pos, vel)
    states = np.column_stack((X.ravel(), Y.ravel()))
    values = estimator.predict(states)
    Z = -values.reshape(X.shape)
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    surf = ax.plot_surface(X, Y, Z, cmap='viridis')
    ax.set_xlabel('Position')
    ax.set_ylabel('Velocity')
    ax.set_zlabel('Value')
    ax.set_title('Mountain "Cost To Go" Function')
    fig.colorbar(surf, ax=ax, shrink=0.5, aspect=10)
    plt.show()
    return fig

def plot_value_function(V):
    player_sum_min, player_sum_max = 12, 21
    dealer_showing_min, dealer_showing_max = 1, 10
    player_sums = np.arange(player_sum_min, player_sum_max + 1)
    dealer_showings = np.arange(dealer_showing_min, dealer_showing_max + 1)
    X, Y = np.meshgrid(player_sums, dealer_showings)

    def get_value(ps, ds, ace):
        return V.get((ps, ds, ace), np.nan)

    for ace, title in [(True, 'Usable Ace'), (False, 'No Usable Ace')]:
        vectorized_get = np.vectorize(get_value)
        Z = vectorized_get(X, Y, ace)
        fig = plt.figure()
        ax = fig.add_subplot(111, projection='3d')
        surf = ax.plot_surface(X, Y, Z, cmap='coolwarm')
        ax.set_xlabel('Player Sum')
        ax.set_ylabel('Dealer Showing')
        ax.set_zlabel('Value')
        ax.set_title(f'Value Function ({title})')
        fig.colorbar(surf, ax=ax, shrink=0.5, aspect=10)
        plt.show()
    return None

def plot_episode_stats(stats, smoothing_window=50, noshow=False):
    lengths = np.asarray(stats.lengths)
    rewards = np.asarray(stats.rewards)

    fig1 = plt.figure()
    plt.plot(lengths)
    plt.xlabel('Episode')
    plt.ylabel('Episode Length')
    plt.title('Episode Length Over Time')

    smoothed_rewards = pd.Series(rewards).rolling(window=smoothing_window, min_periods=1).mean()
    fig2 = plt.figure()
    plt.plot(smoothed_rewards)
    plt.xlabel('Episode')
    plt.ylabel('Smoothed Reward')
    plt.title('Smoothed Episode Reward')

    cumulative_steps = np.cumsum(lengths)
    fig3 = plt.figure()
    plt.plot(cumulative_steps)
    plt.xlabel('Episode')
    plt.ylabel('Cumulative Time Steps')
    plt.title('Cumulative Time Steps Over Episodes')

    if noshow:
        plt.close('all')
    else:
        plt.show()
    return None

if __name__ == '__main__':
    pass
