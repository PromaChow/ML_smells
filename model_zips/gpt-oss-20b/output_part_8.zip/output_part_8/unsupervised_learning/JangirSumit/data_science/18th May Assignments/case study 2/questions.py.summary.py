import pandas as pd

# Step 1: Reading Data
df_math_scores = pd.read_csv('MathScoreTerm1.csv')
df_ds_scores = pd.read_csv('DSScoreTerm1.csv')
df_physics_scores = pd.read_csv('PhysicsScoreTerm1.csv')

# Step 2: Removing Confidential Columns
for df in (df_math_scores, df_ds_scores, df_physics_scores):
    df.drop(columns=['Name', 'Ethinicity'], inplace=True)

# Step 3: Handling Missing Values
for df in (df_math_scores, df_ds_scores, df_physics_scores):
    df['Score'] = df['Score'].fillna(0)

# Step 4: Merging DataFrames
merged_df = pd.merge(df_math_scores, df_ds_scores, on='ID', suffixes=('_math', '_ds'))
merged_df = pd.merge(merged_df, df_physics_scores, on='ID', suffixes=('_ds', '_physics'))

# Select required columns
merged_df = merged_df[['ID', 'Score_math', 'Score_ds', 'Score_physics', 'Age_math', 'Sex_ds', 'Sex_physics']]

# Rename columns
merged_df.rename(columns={'Score_physics': 'Score', 'Age_math': 'Age'}, inplace=True)

# Step 5: Encoding Gender
merged_df['Sex'] = [1 if sex == 'M' else 2 for sex in merged_df['Sex_ds']]
merged_df.drop(columns=['Sex_ds', 'Sex_physics'], inplace=True)

# Step 6: Saving Output
merged_df.to_csv('ScoreFinal.csv', index=False)