import pygame
import random
import math
import sys

# Define colors
BLACK   = (0, 0, 0)
BLUE    = (0, 0, 255)
GREEN   = (0, 255, 0)
RED     = (255, 0, 0)

# Define creep types
GOOD = "GOOD"
BAD  = "BAD"

class WaterWorld:
    def __init__(self, width=800, height=600, num_creeps=10):
        pygame.init()
        self.width = width
        self.height = height
        self.num_creeps = num_creeps
        self.screen = pygame.display.set_mode((self.width, self.height))
        pygame.display.set_caption("WaterWorld")
        self.clock = pygame.time.Clock()
        self.fps = 30

        # Player properties
        self.player_radius = 15
        self.player_speed = 5
        self.player_color = BLUE
        self.player = {
            "x": self.width // 2,
            "y": self.height // 2,
            "vx": 0,
            "vy": 0,
            "radius": self.player_radius,
            "speed": self.player_speed,
            "color": self.player_color,
        }

        # Creep properties
        self.creep_radius = 10
        self.creep_speed = 2
        self.creep_reward = {"GOOD": 10, "BAD": -5}
        self.creeps = []
        self.total_good = 0
        self.collected_good = 0

        # Score
        self.score = 0

        self.reset()

    def reset(self):
        self.player["x"] = self.width // 2
        self.player["y"] = self.height // 2
        self.player["vx"] = 0
        self.player["vy"] = 0
        self.score = 0
        self.collected_good = 0
        self.creeps = []
        self.total_good = 0
        self.generate_creeps(self.num_creeps)

    def generate_creeps(self, count):
        for _ in range(count):
            creep_type = random.choice([GOOD, BAD])
            if creep_type == GOOD:
                self.total_good += 1
            color = GREEN if creep_type == GOOD else RED
            # Ensure not too close to player
            while True:
                x = random.randint(self.creep_radius, self.width - self.creep_radius)
                y = random.randint(self.creep_radius, self.height - self.creep_radius)
                dist = math.hypot(x - self.player["x"], y - self.player["y"])
                if dist > 100:
                    break
            direction = random.uniform(0, 2 * math.pi)
            dx = math.cos(direction)
            dy = math.sin(direction)
            creep = {
                "x": x,
                "y": y,
                "radius": self.creep_radius,
                "type": creep_type,
                "color": color,
                "speed": self.creep_speed,
                "reward": self.creep_reward[creep_type],
                "dx": dx,
                "dy": dy,
            }
            self.creeps.append(creep)

    def handle_input(self):
        keys = pygame.key.get_pressed()
        vx = vy = 0
        if keys[pygame.K_w]:
            vy = -self.player["speed"]
        if keys[pygame.K_s]:
            vy = self.player["speed"]
        if keys[pygame.K_a]:
            vx = -self.player["speed"]
        if keys[pygame.K_d]:
            vx = self.player["speed"]
        self.player["vx"] = vx
        self.player["vy"] = vy

    def update_player(self):
        self.player["x"] += self.player["vx"]
        self.player["y"] += self.player["vy"]
        # Keep player inside screen
        self.player["x"] = max(self.player["radius"], min(self.width - self.player["radius"], self.player["x"]))
        self.player["y"] = max(self.player["radius"], min(self.height - self.player["radius"], self.player["y"]))

    def update_creeps(self):
        for creep in self.creeps:
            creep["x"] += creep["dx"] * creep["speed"]
            creep["y"] += creep["dy"] * creep["speed"]
            # Bounce off walls
            if creep["x"] <= creep["radius"] or creep["x"] >= self.width - creep["radius"]:
                creep["dx"] *= -1
            if creep["y"] <= creep["radius"] or creep["y"] >= self.height - creep["radius"]:
                creep["dy"] *= -1

    def check_collisions(self):
        removed = []
        for creep in self.creeps:
            dist = math.hypot(self.player["x"] - creep["x"], self.player["y"] - creep["y"])
            if dist <= self.player["radius"] + creep["radius"]:
                self.score += creep["reward"]
                if creep["type"] == GOOD:
                    self.collected_good += 1
                removed.append(creep)
        for creep in removed:
            self.creeps.remove(creep)
            self.generate_creeps(1)

    def game_over(self):
        return self.collected_good >= self.total_good

    def get_state(self):
        distances = []
        for creep in self.creeps:
            d = math.hypot(self.player["x"] - creep["x"], self.player["y"] - creep["y"])
            distances.append(d)
        return {
            "player_pos": (self.player["x"], self.player["y"]),
            "player_vel": (self.player["vx"], self.player["vy"]),
            "distances": distances,
            "score": self.score,
        }

    def draw(self):
        self.screen.fill(BLACK)
        # Draw player
        pygame.draw.circle(self.screen, self.player["color"], (int(self.player["x"]), int(self.player["y"])), self.player["radius"])
        # Draw creeps
        for creep in self.creeps:
            pygame.draw.circle(self.screen, creep["color"], (int(creep["x"]), int(creep["y"])), creep["radius"])
        # Draw score
        font = pygame.font.SysFont(None, 24)
        text = font.render(f"Score: {self.score}", True, (255, 255, 255))
        self.screen.blit(text, (10, 10))
        pygame.display.flip()

    def run(self):
        running = True
        while running:
            self.clock.tick(self.fps)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_r:
                        self.reset()
            self.handle_input()
            self.update_player()
            self.update_creeps()
            self.check_collisions()
            self.score += 1  # reward per tick
            if self.game_over():
                self.score += 50  # win reward
                running = False
            self.draw()
        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    game = WaterWorld()
    game.run()