import argparse
import os
import logging
import random
import math
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import gym
import gym.wrappers
from collections import deque, namedtuple

# ----------------------------------------
# Empirical Normalization
# ----------------------------------------
class EmpiricalNormalization:
    def __init__(self, shape, eps=1e-2):
        self.mean = torch.zeros(shape)
        self.var = torch.ones(shape)
        self.eps = eps
        self.count = 0

    def update(self, x):
        batch_mean = torch.mean(x, dim=0)
        batch_var = torch.var(x, dim=0, unbiased=False)
        batch_count = x.size(0)
        delta = batch_mean - self.mean
        tot_count = self.count + batch_count
        new_mean = self.mean + delta * batch_count / tot_count
        m_a = self.var * self.count
        m_b = batch_var * batch_count
        M2 = m_a + m_b + delta.pow(2) * self.count * batch_count / tot_count
        new_var = M2 / tot_count
        self.mean = new_mean
        self.var = new_var
        self.count = tot_count

    def normalize(self, x):
        std = torch.sqrt(self.var + self.eps)
        return (x - self.mean) / std

# ----------------------------------------
# Policy Networks
# ----------------------------------------
class GaussianPolicy(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden_sizes=(64, 64)):
        super().__init__()
        layers = []
        in_dim = obs_dim
        for h in hidden_sizes:
            layers.append(nn.Linear(in_dim, h))
            layers.append(nn.Tanh())
            in_dim = h
        self.mean_net = nn.Sequential(*layers, nn.Linear(in_dim, act_dim))
        self.log_std = nn.Parameter(torch.zeros(act_dim))
    
    def forward(self, x):
        mean = self.mean_net(x)
        std = self.log_std.exp().expand_as(mean)
        return mean, std

    def sample(self, x):
        mean, std = self.forward(x)
        dist = torch.distributions.Normal(mean, std)
        action = dist.rsample()
        logp = dist.log_prob(action).sum(-1)
        return action, logp

class SoftmaxPolicy(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden_sizes=(64, 64)):
        super().__init__()
        layers = []
        in_dim = obs_dim
        for h in hidden_sizes:
            layers.append(nn.Linear(in_dim, h))
            layers.append(nn.Tanh())
            in_dim = h
        self.logits_net = nn.Sequential(*layers, nn.Linear(in_dim, act_dim))
    
    def forward(self, x):
        logits = self.logits_net(x)
        return logits

    def sample(self, x):
        logits = self.forward(x)
        dist = torch.distributions.Categorical(logits=logits)
        action = dist.sample()
        logp = dist.log_prob(action)
        return action.unsqueeze(-1).float(), logp.unsqueeze(-1)

# ----------------------------------------
# Value Function Network
# ----------------------------------------
class ValueFunction(nn.Module):
    def __init__(self, obs_dim, hidden_sizes=(64, 64)):
        super().__init__()
        layers = []
        in_dim = obs_dim
        for h in hidden_sizes:
            layers.append(nn.Linear(in_dim, h))
            layers.append(nn.Tanh())
            in_dim = h
        layers.append(nn.Linear(in_dim, 1))
        self.net = nn.Sequential(*layers)
    
    def forward(self, x):
        return self.net(x).squeeze(-1)

# ----------------------------------------
# TRPO Agent
# ----------------------------------------
class TRPOAgent:
    def __init__(self, policy, value, device, gamma=0.995, lam=0.97,
                 cg_iters=10, cg_damping=0.1, max_kl=1e-2, vf_epochs=5,
                 entropy_coef=0.0):
        self.policy = policy
        self.value = value
        self.device = device
        self.gamma = gamma
        self.lam = lam
        self.cg_iters = cg_iters
        self.cg_damping = cg_damping
        self.max_kl = max_kl
        self.vf_epochs = vf_epochs
        self.entropy_coef = entropy_coef
        self.vf_optimizer = optim.Adam(self.value.parameters(), lr=1e-3)

    def compute_gae(self, rewards, masks, values, next_value):
        advantages = torch.zeros_like(rewards)
        gae = 0
        for t in reversed(range(len(rewards))):
            delta = rewards[t] + self.gamma * next_value * masks[t] - values[t]
            gae = delta + self.gamma * self.lam * masks[t] * gae
            advantages[t] = gae
            next_value = values[t]
        returns = advantages + values
        return advantages, returns

    def get_action(self, obs):
        obs = torch.tensor(obs, dtype=torch.float32, device=self.device)
        if isinstance(self.policy, GaussianPolicy):
            action, logp = self.policy.sample(obs)
        else:
            action, logp = self.policy.sample(obs)
        return action.cpu().numpy(), logp.cpu().item()

    def surrogate_loss(self, obs, actions, advs, old_logp):
        if isinstance(self.policy, GaussianPolicy):
            mean, std = self.policy(obs)
            dist = torch.distributions.Normal(mean, std)
            logp = dist.log_prob(actions).sum(-1)
        else:
            logits = self.policy(obs)
            dist = torch.distributions.Categorical(logits=logits)
            logp = dist.log_prob(actions.squeeze(-1))
        ratio = torch.exp(logp - old_logp)
        return -(ratio * advs).mean()

    def approx_kl(self, obs, actions, old_logp):
        if isinstance(self.policy, GaussianPolicy):
            mean, std = self.policy(obs)
            dist = torch.distributions.Normal(mean, std)
            logp = dist.log_prob(actions).sum(-1)
        else:
            logits = self.policy(obs)
            dist = torch.distributions.Categorical(logits=logits)
            logp = dist.log_prob(actions.squeeze(-1))
        return (old_logp - logp).mean()

    def hessian_vector_product(self, obs, actions, old_logp, vector):
        self.policy.zero_grad()
        kl = self.approx_kl(obs, actions, old_logp)
        kl_grad = torch.autograd.grad(kl, self.policy.parameters(), create_graph=True)
        flat_grad = torch.cat([g.contiguous().view(-1) for g in kl_grad])
        kl_grad_vector = torch.dot(flat_grad, vector)
        grad2 = torch.autograd.grad(kl_grad_vector, self.policy.parameters())
        flat_grad2 = torch.cat([g.contiguous().view(-1) for g in grad2])
        return flat_grad2 + vector * self.cg_damping

    def conjugate_gradient(self, obs, actions, old_logp, b):
        x = torch.zeros_like(b)
        r = b.clone()
        p = r.clone()
        rsold = torch.dot(r, r)
        for i in range(self.cg_iters):
            Ap = self.hessian_vector_product(obs, actions, old_logp, p)
            alpha = rsold / (torch.dot(p, Ap) + 1e-8)
            x += alpha * p
            r -= alpha * Ap
            rsnew = torch.dot(r, r)
            if torch.sqrt(rsnew) < 1e-10:
                break
            p = r + (rsnew / rsold) * p
            rsold = rsnew
        return x

    def linesearch(self, obs, actions, old_logp, advs, full_step, accept_ratio=0.1):
        step_size = 1.0
        for _ in range(10):
            self.policy.train()
            with torch.no_grad():
                for name, param in self.policy.named_parameters():
                    param.copy_(param + step_size * full_step.view_as(param))
            loss = self.surrogate_loss(obs, actions, advs, old_logp)
            kl = self.approx_kl(obs, actions, old_logp)
            if loss < 0 and kl <= self.max_kl:
                return True
            step_size *= 0.5
        return False

    def update(self, traj):
        obs = torch.tensor(traj.observations, dtype=torch.float32, device=self.device)
        actions = torch.tensor(traj.actions, dtype=torch.float32, device=self.device)
        rewards = torch.tensor(traj.rewards, dtype=torch.float32, device=self.device)
        masks = torch.tensor(traj.masks, dtype=torch.float32, device=self.device)
        old_logp = torch.tensor(traj.logprobs, dtype=torch.float32, device=self.device)

        with torch.no_grad():
            values = self.value(obs)
            next_value = self.value(obs[-1:].clone()).detach()
            advs, returns = self.compute_gae(rewards, masks, values, next_value)

        # Policy update
        loss = self.surrogate_loss(obs, actions, advs, old_logp)
        loss.backward()
        grads = torch.cat([p.grad.contiguous().view(-1) for p in self.policy.parameters()]).detach()
        step_dir = self.conjugate_gradient(obs, actions, old_logp, grads)
        shs = 0.5 * (step_dir * self.hessian_vector_product(obs, actions, old_logp, step_dir)).sum(0)
        lm = torch.sqrt(shs / self.max_kl)
        full_step = step_dir / (lm + 1e-8)

        if not self.linesearch(obs, actions, old_logp, advs, full_step):
            logging.info("Line search failed. Skipping update.")
            return

        # Value function update
        for _ in range(self.vf_epochs):
            vals = self.value(obs)
            vf_loss = ((vals - returns).pow(2)).mean()
            self.vf_optimizer.zero_grad()
            vf_loss.backward()
            self.vf_optimizer.step()

# ----------------------------------------
# Trajectory Storage
# ----------------------------------------
Trajectory = namedtuple('Trajectory',
                        ['observations', 'actions', 'rewards', 'masks', 'logprobs'])

def collect_trajectory(env, agent, batch_size, normalize):
    observations, actions, rewards, masks, logprobs = [], [], [], [], []
    obs = env.reset()
    for _ in range(batch_size):
        if normalize:
            obs_norm = normalize.normalize(torch.tensor(obs, dtype=torch.float32))
        else:
            obs_norm = torch.tensor(obs, dtype=torch.float32)
        if isinstance(agent.policy, GaussianPolicy):
            action, logp = agent.policy.sample(obs_norm.to(agent.device))
        else:
            action, logp = agent.policy.sample(obs_norm.to(agent.device))
        action_np = action.cpu().numpy()
        next_obs, reward, done, _ = env.step(action_np)
        observations.append(obs)
        actions.append(action.cpu().numpy())
        rewards.append(reward)
        masks.append(1 - done)
        logprobs.append(logp.item())
        obs = next_obs
        if done:
            obs = env.reset()
    return Trajectory(
        observations=np.array(observations),
        actions=np.array(actions),
        rewards=np.array(rewards),
        masks=np.array(masks),
        logprobs=np.array(logprobs)
    )

# ----------------------------------------
# Environment Factory
# ----------------------------------------
def make_env(env_id, seed, render=False, monitor=False, output_dir=None):
    def _thunk():
        env = gym.make(env_id)
        env.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        if monitor and output_dir:
            env = gym.wrappers.Monitor(env, os.path.join(output_dir, "monitor"))
        if render:
            env = gym.wrappers.Renderer(env)
        return env
    return _thunk

# ----------------------------------------
# Argument Parsing
# ----------------------------------------
parser = argparse.ArgumentParser()
parser.add_argument("--gpu", type=int, default=-1, help="GPU device id, -1 for CPU")
parser.add_argument("--env", type=str, default="Hopper-v2", help="Gym environment ID")
parser.add_argument("--seed", type=int, default=42, help="Random seed")
parser.add_argument("--output", type=str, default="output", help="Output directory")
parser.add_argument("--steps", type=int, default=1_000_000, help="Total training steps")
parser.add_argument("--eval_interval", type=int, default=10_000, help="Evaluation interval")
parser.add_argument("--trpo_update_interval", type=int, default=5_000, help="TRPO update interval")
parser.add_argument("--eval_n_runs", type=int, default=10, help="Number of evaluation runs")
parser.add_argument("--render", action="store_true", help="Render environment")
parser.add_argument("--demo", action="store_true", help="Demo mode")
parser.add_argument("--load", type=str, default="", help="Path to pre-trained model")
parser.add_argument("--log_level", type=str, default="INFO", help="Logging level")
args = parser.parse_args()

# ----------------------------------------
# Setup
# ----------------------------------------
os.makedirs(args.output, exist_ok=True)
logging.basicConfig(level=getattr(logging, args.log_level.upper()))
device = torch.device(f"cuda:{args.gpu}" if args.gpu >= 0 and torch.cuda.is_available() else "cpu")
torch.manual_seed(args.seed)
np.random.seed(args.seed)
random.seed(args.seed)

# ----------------------------------------
# Environment Creation
# ----------------------------------------
train_env = make_env(args.env, args.seed)( )
test_env = make_env(args.env, args.seed + 1)( )
normalizer = EmpiricalNormalization((train_env.observation_space.shape[0],))
obs_dim = train_env.observation_space.shape[0]
act_dim = train_env.action_space.n if isinstance(train_env.action_space, gym.spaces.Discrete) else train_env.action_space.shape[0]
is_continuous = isinstance(train_env.action_space, gym.spaces.Box)

# ----------------------------------------
# Policy and Value Function
# ----------------------------------------
if is_continuous:
    policy = GaussianPolicy(obs_dim, act_dim).to(device)
else:
    policy = SoftmaxPolicy(obs_dim, act_dim).to(device)
value_func = ValueFunction(obs_dim).to(device)

# ----------------------------------------
# TRPO Agent
# ----------------------------------------
agent = TRPOAgent(policy, value_func, device)

# ----------------------------------------
# Load pretrained model if demo
# ----------------------------------------
if args.demo and args.load:
    checkpoint = torch.load(args.load, map_location=device)
    policy.load_state_dict(checkpoint["policy"])
    value_func.load_state_dict(checkpoint["value"])

# ----------------------------------------
# Evaluation Function
# ----------------------------------------
def evaluate(env, agent, n_runs):
    total_reward = 0.0
    for _ in range(n_runs):
        obs = env.reset()
        done = False
        ep_reward = 0.0
        while not done:
            obs_tensor = torch.tensor(obs, dtype=torch.float32, device=agent.device)
            if isinstance(agent.policy, GaussianPolicy):
                action, _ = agent.policy.sample(obs_tensor)
            else:
                action, _ = agent.policy.sample(obs_tensor)
            action_np = action.cpu().numpy()
            obs, reward, done, _ = env.step(action_np)
            ep_reward += reward
        total_reward += ep_reward
    avg_reward = total_reward / n_runs
    logging.info(f"Avg reward over {n_runs} runs: {avg_reward}")
    return avg_reward

# ----------------------------------------
# Training Loop
# ----------------------------------------
if not args.demo:
    batch_size = 2048
    steps_done = 0
    while steps_done < args.steps:
        traj = collect_trajectory(train_env, agent, batch_size, normalizer)
        normalizer.update(torch.tensor(traj.observations, dtype=torch.float32))
        agent.update(traj)
        steps_done += batch_size
        if steps_done % args.eval_interval == 0:
            evaluate(test_env, agent, args.eval_n_runs)
        if steps_done % args.trpo_update_interval == 0:
            torch.save({
                "policy": policy.state_dict(),
                "value": value_func.state_dict()
            }, os.path.join(args.output, f"model_{steps_done}.pt"))
    torch.save({
        "policy": policy.state_dict(),
        "value": value_func.state_dict()
    }, os.path.join(args.output, "final.pt"))
else:
    evaluate(test_env, agent, args.eval_n_runs)