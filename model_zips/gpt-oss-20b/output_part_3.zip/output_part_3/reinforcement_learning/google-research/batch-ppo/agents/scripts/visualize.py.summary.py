import os
import yaml
import gym
import numpy as np
import tensorflow as tf

def _create_environment(env_id: str, max_length: int = None, outdir: str = None):
    env = gym.make(env_id)
    if max_length is not None:
        env = gym.wrappers.TimeLimit(env, max_episode_steps=max_length)
    if outdir is not None:
        env = gym.wrappers.Monitor(env, outdir, force=True, video_callable=lambda episode_id: True)
    return env

def define_batch_env(logdir: str, num_agents: int, outdir: str, env_id: str, max_length: int = None):
    env_fns = [lambda: _create_environment(env_id, max_length, outdir) for _ in range(num_agents)]
    return gym.vector.AsyncVectorEnv(env_fns)

class SimulationGraph:
    def __init__(self, model_path: str):
        self.sess = tf.compat.v1.Session(
            config=tf.compat.v1.ConfigProto(
                gpu_options=tf.compat.v1.GPUOptions(allow_growth=True),
                allow_soft_placement=True
            )
        )
        tf.compat.v1.keras.backend.set_session(self.sess)
        self.model = tf.keras.models.load_model(model_path)

    def step(self, obs: np.ndarray):
        return self.model.predict(obs, batch_size=None, verbose=0)

class Loop:
    def __init__(self, env, graph: SimulationGraph):
        self.env = env
        self.graph = graph

    def run(self, num_episodes: int):
        obs = self.env.reset()
        for ep in range(num_episodes):
            done = [False] * len(obs)
            while not all(done):
                actions = self.graph.step(obs)
                obs, _, done, _ = self.env.step(actions)
            print(f"Episode {ep + 1} finished.")
        self.env.close()

def visualize(
    logdir: str,
    outdir: str,
    num_agents: int = 1,
    num_episodes: int = 10,
    checkpoint: str = None
):
    config_path = os.path.join(logdir, "config.yaml")
    with open(config_path, "r") as f:
        config = yaml.safe_load(f)

    env_id = config.get("env_id", "CartPole-v1")
    max_length = config.get("max_length", None)

    batch_env = define_batch_env(logdir, num_agents, outdir, env_id, max_length)

    if checkpoint:
        model_path = os.path.join(logdir, checkpoint)
    else:
        model_files = [f for f in os.listdir(logdir) if f.endswith((".h5", ".keras"))]
        if not model_files:
            raise FileNotFoundError("No model file found in logdir.")
        model_path = os.path.join(logdir, sorted(model_files)[-1])

    graph = SimulationGraph(model_path)
    loop = Loop(batch_env, graph)
    loop.run(num_episodes)

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Render videos for Proximal Policy Gradient.")
    parser.add_argument("logdir", type=str, help="Directory containing config and checkpoints.")
    parser.add_argument("outdir", type=str, help="Output directory for rendered videos.")
    parser.add_argument("--num_agents", type=int, default=1, help="Number of parallel environments.")
    parser.add_argument("--num_episodes", type=int, default=10, help="Number of episodes to render.")
    parser.add_argument("--checkpoint", type=str, default=None, help="Specific checkpoint file name.")
    args = parser.parse_args()
    visualize(args.logdir, args.outdir, args.num_agents, args.num_episodes, args.checkpoint)