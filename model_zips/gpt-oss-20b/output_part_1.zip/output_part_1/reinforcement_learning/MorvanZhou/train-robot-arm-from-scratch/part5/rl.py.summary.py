import numpy as np
import tensorflow as tf

tf.compat.v1.disable_eager_execution()


class DDPG:
    def __init__(
        self,
        state_dim,
        action_dim,
        action_low,
        action_high,
        lr_a=0.001,
        lr_c=0.001,
        gamma=0.9,
        tau=0.01,
        memory_capacity=10000,
        batch_size=32,
    ):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.action_low = tf.constant(action_low, dtype=tf.float32)
        self.action_high = tf.constant(action_high, dtype=tf.float32)
        self.action_range = (self.action_high - self.action_low) / 2.0
        self.action_center = (self.action_high + self.action_low) / 2.0
        self.lr_a = lr_a
        self.lr_c = lr_c
        self.gamma = gamma
        self.tau = tau
        self.memory_capacity = memory_capacity
        self.batch_size = batch_size

        # Memory buffer
        self.memory = np.zeros((memory_capacity, state_dim + action_dim + 1 + state_dim), dtype=np.float32)
        self.memory_ptr = 0
        self.memory_size = 0

        # Placeholders
        self.s = tf.compat.v1.placeholder(tf.float32, [None, state_dim], name="s")
        self.s_ = tf.compat.v1.placeholder(tf.float32, [None, state_dim], name="s_")
        self.a = tf.compat.v1.placeholder(tf.float32, [None, action_dim], name="a")
        self.r = tf.compat.v1.placeholder(tf.float32, [None, 1], name="r")

        # Build networks
        self.actor_eval = self.build_actor(self.s, scope="actor_eval")
        self.actor_target = self.build_actor(self.s_, scope="actor_target")

        self.critic_eval = self.build_critic(self.s, self.a, scope="critic_eval")
        self.critic_target = self.build_critic(self.s_, self.actor_target, scope="critic_target")

        # Parameter collections
        self.actor_vars_eval = tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.TRAINABLE_VARIABLES, scope="actor_eval")
        self.actor_vars_target = tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.TRAINABLE_VARIABLES, scope="actor_target")
        self.critic_vars_eval = tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.TRAINABLE_VARIABLES, scope="critic_eval")
        self.critic_vars_target = tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.TRAINABLE_VARIABLES, scope="critic_target")

        # Soft update ops
        self.soft_update_ops = []
        for var_eval, var_target in zip(self.actor_vars_eval, self.actor_vars_target):
            op = var_target.assign(self.tau * var_eval + (1 - self.tau) * var_target)
            self.soft_update_ops.append(op)
        for var_eval, var_target in zip(self.critic_vars_eval, self.critic_vars_target):
            op = var_target.assign(self.tau * var_eval + (1 - self.tau) * var_target)
            self.soft_update_ops.append(op)

        # Losses and optimizers
        q_target = self.r + self.gamma * tf.stop_gradient(self.critic_target)
        self.critic_loss = tf.reduce_mean(tf.square(q_target - self.critic_eval))
        self.critic_optimizer = tf.compat.v1.train.AdamOptimizer(self.lr_c).minimize(self.critic_loss)

        self.actor_loss = -tf.reduce_mean(self.critic_eval)
        self.actor_optimizer = tf.compat.v1.train.AdamOptimizer(self.lr_a).minimize(self.actor_loss)

        # Saver
        self.saver = tf.compat.v1.train.Saver(max_to_keep=10)

        # Session
        self.sess = tf.compat.v1.Session()
        self.sess.run(tf.compat.v1.global_variables_initializer())

    def build_actor(self, s_input, scope):
        with tf.compat.v1.variable_scope(scope):
            hidden = tf.compat.v1.layers.dense(
                s_input, 100, activation=tf.nn.relu, kernel_initializer=tf.random_normal_initializer(stddev=0.1)
            )
            raw_output = tf.compat.v1.layers.dense(
                hidden,
                self.action_dim,
                activation=tf.nn.tanh,
                kernel_initializer=tf.random_normal_initializer(stddev=0.1),
            )
            scaled_output = self.action_center + raw_output * self.action_range
            return scaled_output

    def build_critic(self, s_input, a_input, scope):
        with tf.compat.v1.variable_scope(scope):
            w_s = tf.compat.v1.get_variable("w_s", [self.state_dim, 100], initializer=tf.random_normal_initializer(stddev=0.1))
            b_s = tf.compat.v1.get_variable("b_s", [100], initializer=tf.zeros_initializer())

            w_a = tf.compat.v1.get_variable("w_a", [self.action_dim, 100], initializer=tf.random_normal_initializer(stddev=0.1))
            b_a = tf.compat.v1.get_variable("b_a", [100], initializer=tf.zeros_initializer())

            h_s = tf.matmul(s_input, w_s) + b_s
            h_a = tf.matmul(a_input, w_a) + b_a
            h = tf.nn.relu(h_s + h_a)
            q = tf.compat.v1.layers.dense(
                h, 1, activation=None, kernel_initializer=tf.random_normal_initializer(stddev=0.1)
            )
            return q

    def store_transition(self, s, a, r, s_):
        transition = np.hstack((s, a, [r], s_))
        index = self.memory_ptr % self.memory_capacity
        self.memory[index] = transition
        self.memory_ptr += 1
        if self.memory_size < self.memory_capacity:
            self.memory_size += 1

    def choose_action(self, s):
        s = s[np.newaxis, :]
        action = self.sess.run(self.actor_eval, feed_dict={self.s: s})
        return action[0]

    def learn(self):
        if self.memory_size < self.batch_size:
            return

        indices = np.random.choice(self.memory_size, self.batch_size, replace=False)
        batch = self.memory[indices]
        s_batch = batch[:, : self.state_dim]
        a_batch = batch[:, self.state_dim : self.state_dim + self.action_dim]
        r_batch = batch[:, self.state_dim + self.action_dim : self.state_dim + self.action_dim + 1]
        s_next_batch = batch[:, -self.state_dim :]

        # Soft update target networks
        self.sess.run(self.soft_update_ops)

        # Update critic
        self.sess.run(
            self.critic_optimizer,
            feed_dict={
                self.s: s_batch,
                self.a: a_batch,
                self.r: r_batch,
                self.s_: s_next_batch,
            },
        )

        # Update actor
        self.sess.run(
            self.actor_optimizer,
            feed_dict={self.s: s_batch},
        )

    def save(self, path):
        self.saver.save(self.sess, path)

    def restore(self, path):
        self.saver.restore(self.sess, path)
        return True
