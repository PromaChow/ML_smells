import math
import torch
import torch.nn as nn
import torch.nn.functional as F


class SoftAttention(nn.Module):
    def __init__(self, emb_dim: int, attn_dim: int):
        super().__init__()
        self.W = nn.Linear(emb_dim, attn_dim, bias=False)
        std = 1.0 / math.sqrt(attn_dim)
        self.v = nn.Parameter(torch.empty(attn_dim).uniform_(-std, std))

    def forward(self, values: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """
        values: [batch, seq, emb_dim]
        Returns:
            attn_repr: [batch, emb_dim]
            attn_weights: [batch, seq]
        """
        h = torch.tanh(self.W(values))          # [batch, seq, attn_dim]
        e = torch.matmul(h, self.v)             # [batch, seq]
        attn_weights = F.softmax(e, dim=1)      # [batch, seq]
        weighted_values = values * attn_weights.unsqueeze(-1)  # [batch, seq, emb_dim]
        attn_repr = weighted_values.sum(dim=1)              # [batch, emb_dim]
        return attn_repr, attn_weights


class AdditiveAttention(nn.Module):
    def __init__(self, decoder_dim: int, encoder_dim: int):
        super().__init__()
        self.W1 = nn.Linear(decoder_dim, decoder_dim, bias=False)
        self.W2 = nn.Linear(encoder_dim, decoder_dim, bias=False)
        self.v = nn.Parameter(torch.randn(decoder_dim))

    def forward(self, values: torch.Tensor, query: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """
        values: [batch, seq, encoder_dim]
        query:  [batch, decoder_dim]
        Returns:
            attn_repr: [batch, encoder_dim]
            attn_weights: [batch, seq]
        """
        seq_len = values.size(1)
        query_expanded = query.unsqueeze(1).expand(-1, seq_len, -1)  # [batch, seq, decoder_dim]
        h = torch.tanh(self.W1(query_expanded) + self.W2(values))    # [batch, seq, decoder_dim]
        e = torch.matmul(h, self.v)                                 # [batch, seq]
        attn_weights = F.softmax(e, dim=1)                           # [batch, seq]
        weighted_values = values * attn_weights.unsqueeze(-1)       # [batch, seq, encoder_dim]
        attn_repr = weighted_values.sum(dim=1)                       # [batch, encoder_dim]
        return attn_repr, attn_weights


class MultiplicativeAttention(nn.Module):
    def __init__(self, decoder_dim: int, encoder_dim: int):
        super().__init__()
        self.W = nn.Parameter(torch.randn(decoder_dim, encoder_dim))

    def forward(self, values: torch.Tensor, query: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """
        values: [batch, seq, encoder_dim]
        query:  [batch, decoder_dim]
        Returns:
            attn_repr: [batch, encoder_dim]
            attn_weights: [batch, seq]
        """
        batch_size, seq_len, _ = values.size()
        # query * W => [batch, encoder_dim]
        queryW = torch.matmul(query, self.W)                           # [batch, encoder_dim]
        # batch matmul queryW with values transposed
        scores = torch.bmm(queryW.unsqueeze(1), values.transpose(1, 2))  # [batch, 1, seq]
        scores = scores.squeeze(1)                                      # [batch, seq]
        scores = scores / math.sqrt(query.size(1))                       # scaling
        attn_weights = F.softmax(scores, dim=1)                          # [batch, seq]
        weighted_values = values * attn_weights.unsqueeze(-1)           # [batch, seq, encoder_dim]
        attn_repr = weighted_values.sum(dim=1)                           # [batch, encoder_dim]
        return attn_repr, attn_weights


class DotAttention(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, values: torch.Tensor, query: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """
        values: [batch, seq, dim]
        query:  [batch, dim]
        Returns:
            attn_repr: [batch, dim]
            attn_weights: [batch, seq]
        """
        scores = torch.bmm(values, query.unsqueeze(-1)).squeeze(-1)      # [batch, seq]
        attn_weights = F.softmax(scores, dim=1)                         # [batch, seq]
        weighted = torch.bmm(values.transpose(1, 2), attn_weights.unsqueeze(-1))  # [batch, dim, 1]
        attn_repr = weighted.squeeze(-1)                                 # [batch, dim]
        return attn_repr, attn_weights


# Test cases
if __name__ == "__main__":
    batch, seq, emb_dim, decoder_dim, encoder_dim = 16, 54, 128, 256, 128
    soft_attn = SoftAttention(emb_dim=emb_dim, attn_dim=64)
    dot_attn = DotAttention()
    add_attn = AdditiveAttention(decoder_dim=decoder_dim, encoder_dim=encoder_dim)
    mul_attn = MultiplicativeAttention(decoder_dim=decoder_dim, encoder_dim=encoder_dim)

    values = torch.randn(batch, seq, emb_dim)
    query_dot = torch.randn(batch, emb_dim)
    query_add_mul = torch.randn(batch, decoder_dim)

    # Soft Attention
    attn_repr, attn_weights = soft_attn(values)
    print("Soft:", attn_repr.shape, attn_weights.shape)

    # Dot Attention
    attn_repr, attn_weights = dot_attn(values, query_dot)
    print("Dot:", attn_repr.shape, attn_weights.shape)

    # Additive Attention
    attn_repr, attn_weights = add_attn(values, query_add_mul)
    print("Additive:", attn_repr.shape, attn_weights.shape)

    # Multiplicative Attention
    attn_repr, attn_weights = mul_attn(values, query_add_mul)
    print("Multiplicative:", attn_repr.shape, attn_weights.shape)