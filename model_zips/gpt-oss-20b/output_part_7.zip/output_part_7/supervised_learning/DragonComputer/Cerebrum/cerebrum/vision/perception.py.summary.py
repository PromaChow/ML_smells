import cv2
import numpy as np
import imutils
import multiprocessing
import datetime
import random
import sys
import tkinter as tk

# Constants
STABILIZATION_DETECTION = 10
NON_STATIONARY_PERCENTAGE = 0.05  # 5%
TARGET_HEIGHT = 360
MIN_AREA = 500
NON_ZERO_PERCENTAGE = 0.01  # 1%

# Screen dimensions
root = tk.Tk()
root.withdraw()
SCREEN_WIDTH = root.winfo_screenwidth()
SCREEN_HEIGHT = root.winfo_screenheight()
root.destroy()

# VisionMemoryUtil stub
class VisionMemoryUtil:
    @staticmethod
    def add_memory(thresh_frames, delta_colored_frames, start_ts, end_ts):
        # Placeholder for actual memory storage logic
        print(f"Storing memory from {start_ts} to {end_ts} ({len(thresh_frames)} frames)")

def memory_worker(thresh_frames, delta_colored_frames, start_ts, end_ts):
    VisionMemoryUtil.add_memory(thresh_frames, delta_colored_frames, start_ts, end_ts)

def main(video_input="0"):
    if video_input == "0":
        cap = cv2.VideoCapture(0)
    else:
        cap = cv2.VideoCapture(video_input)

    if not cap.isOpened():
        print("Error: Could not open video source.")
        return

    ret, frame = cap.read()
    if not ret:
        print("Error: Could not read from video source.")
        return

    height, width = frame.shape[:2]
    if abs((width / height) - (16 / 9)) > 0.01:
        raise ValueError("Input video must have a 16:9 aspect ratio.")

    reference_frame = frame.copy()
    reference_frame = cv2.cvtColor(reference_frame, cv2.COLOR_BGR2GRAY)
    reference_frame = cv2.resize(reference_frame, (width, height))
    reference_frame = cv2.bilateralFilter(reference_frame, 9, 75, 75)

    memory_data_thresh = []
    memory_data_frameDeltaColored = []
    delta_value_stack = []
    start_ts = None
    end_ts = None
    vision_perception_stimulated = 0
    frame_count = 0

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        frame = imutils.resize(frame, height=TARGET_HEIGHT)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.bilateralFilter(gray, 9, 75, 75)

        if reference_frame is None:
            reference_frame = gray
            continue

        diff = cv2.absdiff(reference_frame, gray)
        thresh = cv2.threshold(diff, 25, 255, cv2.THRESH_BINARY)[1]
        thresh = cv2.dilate(thresh, None, iterations=2)

        contours, _ = cv2.findContours(thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        delta_value = 0
        for contour in contours:
            if cv2.contourArea(contour) < MIN_AREA:
                continue
            (x, y, w, h) = cv2.boundingRect(contour)
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
            delta_value = max(delta_value, cv2.contourArea(contour))

        frame_area = frame.shape[0] * frame.shape[1]
        if delta_value > NON_STATIONARY_PERCENTAGE * frame_area:
            cv2.putText(frame, "WARNING: Non-stationary camera detected", (10, 20),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)

        non_zero = cv2.countNonZero(thresh)
        if non_zero < NON_ZERO_PERCENTAGE * frame_area:
            cv2.putText(frame, "WARNING: Low motion activity", (10, 40),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 2)

        if delta_value > MIN_AREA:
            if start_ts is None:
                start_ts = datetime.datetime.now()
            end_ts = datetime.datetime.now()
            vision_perception_stimulated = 1
            if random.random() < 0.1:
                memory_data_thresh.append(thresh.copy())
                delta_color = cv2.cvtColor(diff, cv2.COLOR_GRAY2BGR)
                memory_data_frameDeltaColored.append(delta_color)

        delta_value_stack.append(delta_value)
        if len(delta_value_stack) > STABILIZATION_DETECTION:
            delta_value_stack.pop(0)

        if len(delta_value_stack) == STABILIZATION_DETECTION:
            if max(delta_value_stack) - min(delta_value_stack) < 5:
                if memory_data_thresh:
                    p = multiprocessing.Process(target=memory_worker,
                                                args=(memory_data_thresh,
                                                      memory_data_frameDeltaColored,
                                                      start_ts,
                                                      end_ts))
                    p.start()
                    p.join()
                memory_data_thresh.clear()
                memory_data_frameDeltaColored.clear()
                delta_value_stack.clear()
                start_ts = None
                end_ts = None
                vision_perception_stimulated = 0

        cv2.putText(frame, f"Frame: {frame_count}", (10, 60),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        cv2.putText(frame, f"Delta: {delta_value:.2f}", (10, 80),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

        cv2.imshow("Original", frame)
        cv2.imshow("Threshold", thresh)
        cv2.imshow("Delta", diff)
        cv2.imshow("Delta Colored", cv2.cvtColor(diff, cv2.COLOR_GRAY2BGR))

        key = cv2.waitKey(1) & 0xFF
        if key == ord('q') or key == 27:
            break

        frame_count += 1
        reference_frame = gray

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    if len(sys.argv) > 1:
        video_source = sys.argv[1]
    else:
        video_source = "0"
    main(video_source)