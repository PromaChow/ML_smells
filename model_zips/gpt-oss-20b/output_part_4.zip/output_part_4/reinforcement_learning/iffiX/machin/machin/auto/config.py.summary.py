import inspect
import importlib
import os
from typing import Dict, Any, List, Callable

# Default training configuration
DEFAULT_TRAINING_CONFIG = {
    "root_dir": "./results",
    "episode_per_epoch": 100,
    "max_episodes": 10000,
    "early_stopping_patience": 5,
}

def fill_default(default: Dict[str, Any], config: Dict[str, Any]) -> Dict[str, Any]:
    """Merge default configuration with provided config."""
    merged = default.copy()
    merged.update(config)
    return merged

def get_available_algorithms() -> List[str]:
    """Return list of algorithm class names that inherit from TorchFramework."""
    algorithms = []
    module = importlib.import_module("machin.frame.algorithms")
    for name, obj in inspect.getmembers(module, inspect.isclass):
        try:
            from machin.frame.frameworks.torch import TorchFramework
        except Exception:
            # If TorchFramework cannot be imported, skip
            continue
        if issubclass(obj, TorchFramework) and obj is not TorchFramework:
            algorithms.append(name)
    return algorithms

def get_available_environments() -> List[str]:
    """Return list of environment module names that provide launch and generate_env_config."""
    envs = []
    envs_package = importlib.import_module("envs")
    if hasattr(envs_package, "__path__"):
        for finder, name, ispkg in inspect.getmembers(envs_package, lambda m: isinstance(m, (importlib.machinery.ModuleSpec, importlib.machinery.SourceFileLoader))):
            pass
    for finder, name, ispkg in os.walk(os.path.dirname(importlib.import_module("envs").__file__)):
        for file in finder:
            if file.endswith(".py") and file != "__init__.py":
                mod_name = os.path.splitext(file)[0]
                full_mod = f"envs.{mod_name}"
                try:
                    mod = importlib.import_module(full_mod)
                    if hasattr(mod, "launch") and hasattr(mod, "generate_env_config"):
                        envs.append(mod_name)
                except Exception:
                    continue
    return envs

def generate_training_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """Generate training configuration with defaults merged."""
    return fill_default(DEFAULT_TRAINING_CONFIG, config)

def generate_algorithm_config(name: str, config: Dict[str, Any]) -> Dict[str, Any]:
    """Generate algorithm-specific configuration."""
    available = get_available_algorithms()
    assert name in available, f"Algorithm '{name}' not available. Available: {available}"
    module = importlib.import_module("machin.frame.algorithms")
    alg_class = getattr(module, name)
    alg_cfg = getattr(alg_class, "generate_config")(config)
    if getattr(alg_class, "is_distributed", lambda: False)():
        alg_cfg["distributed"] = True
        alg_cfg["num_gpus"] = config.get("num_gpus", 1)
    else:
        alg_cfg["distributed"] = False
    return alg_cfg

def generate_env_config(name: str, config: Dict[str, Any]) -> Dict[str, Any]:
    """Generate environment-specific configuration."""
    available = get_available_environments()
    assert name in available, f"Environment '{name}' not available. Available: {available}"
    mod = importlib.import_module(f"envs.{name}")
    env_cfg = getattr(mod, "generate_env_config")(config)
    env_cfg["env"] = name
    return env_cfg

def init_algorithm_from_config(cfg: Dict[str, Any]):
    """Instantiate algorithm from configuration."""
    assert_algorithm_config_complete(cfg)
    module = importlib.import_module("machin.frame.algorithms")
    alg_class = getattr(module, cfg["frame"])
    return alg_class.init_from_config(cfg["frame_config"])

def is_algorithm_distributed(name: str) -> bool:
    """Check if algorithm is distributed."""
    module = importlib.import_module("machin.frame.algorithms")
    alg_class = getattr(module, name)
    return getattr(alg_class, "is_distributed", lambda: False)()

def assert_training_config_complete(cfg: Dict[str, Any]):
    required = {"root_dir", "episode_per_epoch", "max_episodes", "early_stopping_patience"}
    missing = required - cfg.keys()
    assert not missing, f"Training config missing keys: {missing}"

def assert_algorithm_config_complete(cfg: Dict[str, Any]):
    required = {"frame", "frame_config"}
    missing = required - cfg.keys()
    assert not missing, f"Algorithm config missing keys: {missing}"

def assert_env_config_complete(cfg: Dict[str, Any]):
    required = {"env", "train_env_config", "test_env_config"}
    missing = required - cfg.keys()
    assert not missing, f"Environment config missing keys: {missing}"

def launch(
    training_cfg: Dict[str, Any],
    algorithm_cfg: Dict[str, Any],
    env_cfg: Dict[str, Any],
    callbacks: List[Callable] = None,
):
    """Launch experiment."""
    assert_training_config_complete(training_cfg)
    assert_algorithm_config_complete(algorithm_cfg)
    assert_env_config_complete(env_cfg)

    env_module = importlib.import_module(f"envs.{env_cfg['env']}")
    env_module.launch(
        {
            "training": training_cfg,
            "algorithm": algorithm_cfg,
            "environment": env_cfg,
        },
        callbacks=callbacks,
    )
