import copy
import random
from collections import deque, namedtuple

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F

# ---------- Neural Network Modules ----------

class Actor(nn.Module):
    def __init__(self, state_dim, action_dim, max_action):
        super(Actor, self).__init__()
        self.max_action = max_action
        self.l1 = nn.Linear(state_dim, 400)
        self.l2 = nn.Linear(400, 300)
        self.l3 = nn.Linear(300, action_dim)

    def forward(self, state):
        a = F.relu(self.l1(state))
        a = F.relu(self.l2(a))
        a = torch.tanh(self.l3(a))
        return a * self.max_action


class Critic(nn.Module):
    def __init__(self, state_dim, action_dim):
        super(Critic, self).__init__()
        # Q1 architecture
        self.l1 = nn.Linear(state_dim + action_dim, 400)
        self.l2 = nn.Linear(400, 300)
        self.l3 = nn.Linear(300, 1)
        # Q2 architecture
        self.l4 = nn.Linear(state_dim + action_dim, 400)
        self.l5 = nn.Linear(400, 300)
        self.l6 = nn.Linear(300, 1)

    def forward(self, state, action):
        sa = torch.cat([state, action], 1)
        q1 = F.relu(self.l1(sa))
        q1 = F.relu(self.l2(q1))
        q1 = self.l3(q1)
        q2 = F.relu(self.l4(sa))
        q2 = F.relu(self.l5(q2))
        q2 = self.l6(q2)
        return q1, q2


# ---------- Replay Buffer ----------

Transition = namedtuple('Transition',
                        ('state', 'action', 'reward', 'next_state', 'done'))

class ReplayBuffer:
    def __init__(self, capacity, update_func, batch_size=64,
                 update_interval=1, replay_start_size=1000):
        self.capacity = capacity
        self.buffer = []
        self.position = 0
        self.update_func = update_func
        self.batch_size = batch_size
        self.update_interval = update_interval
        self.replay_start_size = replay_start_size
        self.step_counter = 0

    def push(self, *args):
        if len(self.buffer) < self.capacity:
            self.buffer.append(None)
        self.buffer[self.position] = Transition(*args)
        self.position = (self.position + 1) % self.capacity

    def sample(self):
        return random.sample(self.buffer, self.batch_size)

    def __len__(self):
        return len(self.buffer)

    def update(self):
        if len(self) < self.replay_start_size:
            return
        if self.step_counter % self.update_interval == 0:
            batch = self.sample()
            states = torch.stack([t.state for t in batch]).to(DEVICE)
            actions = torch.stack([t.action for t in batch]).to(DEVICE)
            rewards = torch.tensor([t.reward for t in batch], dtype=torch.float32).unsqueeze(1).to(DEVICE)
            next_states = torch.stack([t.next_state for t in batch]).to(DEVICE)
            dones = torch.tensor([t.done for t in batch], dtype=torch.float32).unsqueeze(1).to(DEVICE)
            self.update_func(states, actions, rewards, next_states, dones)
        self.step_counter += 1


# ---------- Explorer ----------

class GaussianExplorer:
    def __init__(self, action_dim, max_action, noise_scale=0.1, noise_clip=0.5):
        self.action_dim = action_dim
        self.max_action = max_action
        self.noise_scale = noise_scale
        self.noise_clip = noise_clip

    def explore(self, action):
        noise = torch.randn_like(action) * self.noise_scale
        noise = torch.clamp(noise, -self.noise_clip, self.noise_clip)
        action = action + noise
        return torch.clamp(action, -self.max_action, self.max_action)


# ---------- TD3 Agent ----------

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

class TD3Agent:
    def __init__(self,
                 state_dim,
                 action_dim,
                 max_action,
                 gamma=0.99,
                 tau=0.005,
                 policy_noise=0.2,
                 noise_clip=0.5,
                 policy_delay=2,
                 batch_size=128,
                 replay_capacity=1_000_000,
                 replay_start_size=10_000):
        self.actor = Actor(state_dim, action_dim, max_action).to(DEVICE)
        self.actor_target = copy.deepcopy(self.actor).to(DEVICE)
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=3e-4)

        self.critic = Critic(state_dim, action_dim).to(DEVICE)
        self.critic_target = copy.deepcopy(self.critic).to(DEVICE)
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=3e-4)

        self.max_action = max_action
        self.gamma = gamma
        self.tau = tau
        self.policy_noise = policy_noise
        self.noise_clip = noise_clip
        self.policy_delay = policy_delay
        self.batch_size = batch_size

        self.explorer = GaussianExplorer(action_dim, max_action)
        self.replay_buffer = ReplayBuffer(
            capacity=replay_capacity,
            update_func=self.update,
            batch_size=batch_size,
            update_interval=1,
            replay_start_size=replay_start_size
        )

        self.total_it = 0
        self.stats = {
            'q1_losses': deque(maxlen=1000),
            'q2_losses': deque(maxlen=1000),
            'policy_losses': deque(maxlen=1000),
            'q1_vals': deque(maxlen=1000),
            'q2_vals': deque(maxlen=1000)
        }

        self.last_state = None
        self.last_action = None

    # ---------- Action Selection ----------
    def act(self, state):
        state = torch.tensor(state, dtype=torch.float32).unsqueeze(0).to(DEVICE)
        action = self.actor(state).detach().cpu().numpy()[0]
        return action

    def act_and_train(self, state):
        state_tensor = torch.tensor(state, dtype=torch.float32).unsqueeze(0).to(DEVICE)
        action = self.actor(state_tensor).detach()
        action_explored = self.explorer.explore(action)
        action_np = action_explored.cpu().numpy()[0]
        # Store transition after receiving reward and next state
        if self.last_state is not None:
            self.replay_buffer.push(self.last_state, self.last_action, reward, next_state, done)
        self.last_state = torch.tensor(state, dtype=torch.float32).to(DEVICE)
        self.last_action = action_explored
        return action_np

    def stop_episode_and_train(self, reward, next_state, done):
        if self.last_state is not None:
            self.replay_buffer.push(self.last_state, self.last_action, reward, torch.tensor(next_state, dtype=torch.float32).to(DEVICE), done)
        self.last_state = None
        self.last_action = None

    # ---------- Update Function ----------
    def update(self, states, actions, rewards, next_states, dones):
        with torch.no_grad():
            noise = (torch.randn_like(actions) * self.policy_noise).clamp(-self.noise_clip, self.noise_clip)
            next_actions = (self.actor_target(next_states) + noise).clamp(-self.max_action, self.max_action)
            target_Q1, target_Q2 = self.critic_target(next_states, next_actions)
            target_Q = torch.min(target_Q1, target_Q2)
            target_Q = rewards + (1 - dones) * self.gamma * target_Q

        current_Q1, current_Q2 = self.critic(states, actions)
        q1_loss = F.mse_loss(current_Q1, target_Q)
        q2_loss = F.mse_loss(current_Q2, target_Q)

        self.critic_optimizer.zero_grad()
        q1_loss.backward()
        self.critic_optimizer.step()

        self.critic_optimizer.zero_grad()
        q2_loss.backward()
        self.critic_optimizer.step()

        self.stats['q1_losses'].append(q1_loss.item())
        self.stats['q2_losses'].append(q2_loss.item())
        self.stats['q1_vals'].append(current_Q1.mean().item())
        self.stats['q2_vals'].append(current_Q2.mean().item())

        self.total_it += 1

        if self.total_it % self.policy_delay == 0:
            actor_loss = -self.critic.Q1(states, self.actor(states)).mean()
            self.actor_optimizer.zero_grad()
            actor_loss.backward()
            self.actor_optimizer.step()
            self.stats['policy_losses'].append(actor_loss.item())

        # Soft update target networks
        for param, target_param in zip(self.actor.parameters(), self.actor_target.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)

        for param, target_param in zip(self.critic.parameters(), self.critic_target.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)

    # ---------- Training Loop (outside) ----------
    # Example usage (not part of class):
    # agent = TD3Agent(state_dim=..., action_dim=..., max_action=...)
    # for episode in range(num_episodes):
    #     state = env.reset()
    #     for t in range(max_timesteps):
    #         action = agent.act_and_train(state)
    #         next_state, reward, done, _ = env.step(action)
    #         agent.stop_episode_and_train(reward, next_state, done)
    #         state = next_state
    #         if done: break
    #     # logging from agent.stats

    # ---------- Statistics Retrieval ----------
    def get_stats(self):
        return {
            'q1_loss_mean': np.mean(self.stats['q1_losses']),
            'q2_loss_mean': np.mean(self.stats['q2_losses']),
            'policy_loss_mean': np.mean(self.stats['policy_losses']),
            'q1_val_mean': np.mean(self.stats['q1_vals']),
            'q2_val_mean': np.mean(self.stats['q2_vals'])
        }
