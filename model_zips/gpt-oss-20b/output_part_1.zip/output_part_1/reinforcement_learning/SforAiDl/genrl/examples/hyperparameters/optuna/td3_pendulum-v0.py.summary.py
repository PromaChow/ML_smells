import gym
import optuna
import pandas as pd
import pickle
import os

from rlkit.envs.wrappers import NormalizedBoxEnv
from rlkit.torch.networks import MlpPolicy, MlpQFunction
from rlkit.torch.algorithms import TD3
from rlkit.data_management.simple_replay_buffer import ReplayBuffer
from rlkit.core import logger
from rlkit.core import serializable


# Helper to set random seeds
def set_seed(env, seed=42):
    env.seed(seed)
    env.action_space.seed(seed)
    env.observation_space.seed(seed)


# Objective function for Optuna
def objective(trial):
    # Hyperparameter suggestions
    lr_value = trial.suggest_float("lr_value", 1e-6, 1e-1, log=True)
    lr_policy = trial.suggest_float("lr_policy", 1e-6, 1e-1, log=True)
    replay_size = int(trial.suggest_float("replay_size", 1e2, 1e5, log=True))
    max_ep_len = int(trial.suggest_float("max_ep_len", 1e3, 5e4, log=True))

    # Environment setup
    env = NormalizedBoxEnv(gym.make("Pendulum-v0"))
    set_seed(env, 0)

    # Policy and Q-functions
    policy = MlpPolicy(env_spec=env.spec,
                       hidden_sizes=(256, 256),
                       activation='ReLU')
    qf1 = MlpQFunction(env_spec=env.spec,
                       hidden_sizes=(256, 256),
                       activation='ReLU')
    qf2 = MlpQFunction(env_spec=env.spec,
                       hidden_sizes=(256, 256),
                       activation='ReLU')

    # Replay buffer
    replay_buffer = ReplayBuffer(capacity=replay_size, env_spec=env.spec)

    # TD3 agent
    td3 = TD3(env,
              policy,
              qf1,
              qf2,
              replay_buffer=replay_buffer,
              batch_size=256,
              discount=0.99,
              policy_lr=lr_policy,
              qf_lr=lr_value,
              actor_update_interval=2,
              policy_noise=0.2,
              noise_clip=0.5,
              policy_noise=0.2,
              max_path_length=max_ep_len)

    # Train
    td3.train(total_timesteps=16500)

    # Evaluation
    eval_episodes = 10
    total_reward = 0.0
    for _ in range(eval_episodes):
        obs = env.reset()
        episode_reward = 0.0
        done = False
        steps = 0
        while not done and steps < max_ep_len:
            action, _ = td3.policy.get_action(obs)
            obs, reward, done, _ = env.step(action)
            episode_reward += reward
            steps += 1
        total_reward += episode_reward
    avg_reward = total_reward / eval_episodes
    return avg_reward


if __name__ == "__main__":
    storage_path = "sqlite:///td3_optuna.db"
    study_name = "td3_pendulum_optuna"

    if not os.path.exists("td3_optuna.db"):
        os.remove("td3_optuna.db")

    study = optuna.create_study(
        study_name=study_name,
        storage=storage_path,
        direction="maximize",
        load_if_exists=True,
    )

    study.optimize(objective, n_trials=20, timeout=None)

    # Save results to DataFrame and pickle
    df = study.trials_dataframe()
    with open("td3_optuna_results.pkl", "wb") as f:
        pickle.dump(df, f)

    # Print best trial
    best_trial = study.best_trial
    print("Best trial:")
    print(f"  Value: {best_trial.value}")
    print(f"  Params: {best_trial.params}")
    print(f"  Number of evaluations: {len(study.trials)}")
    print(f"  Total trials: {len(study.trials)}")
    print(f"  Duration: {study.trials_dataframe()['datetime_start'].iloc[-1] - study.trials_dataframe()['datetime_start'].iloc[0]}")