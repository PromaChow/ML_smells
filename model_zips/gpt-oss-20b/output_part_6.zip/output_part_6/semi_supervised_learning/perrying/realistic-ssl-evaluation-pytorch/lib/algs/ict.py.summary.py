import torch
import torch.nn as nn
import torch.nn.functional as F


class ICT(nn.Module):
    def __init__(self, alpha: float, model: nn.Module, ema_factor: float):
        super().__init__()
        self.alpha = alpha
        self.model = model  # student model
        self.mean_teacher = model  # reference to mean teacher
        self.ema_factor = ema_factor
        self.global_step = 0
        self.mean_teacher.train()

    def forward(self, x: torch.Tensor, y: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        self.global_step += 1

        # Convert mask to boolean
        mask = mask.bool()
        # Compute teacher predictions
        with torch.no_grad():
            mt_y = self.mean_teacher(x)

        # Split into labeled and unlabeled
        l_x, l_y = x[mask], y[mask]
        u_x, u_y = x[~mask], mt_y[~mask]

        # Mixup for unlabeled data
        lam = torch.distributions.Beta(self.alpha, self.alpha).sample().item()
        idx = torch.randperm(u_x.size(0))
        u_x_perm = u_x[idx]
        u_y_perm = u_y[idx]
        mixed_u_x = lam * u_x + (1 - lam) * u_x_perm
        mixed_u_y = lam * u_y + (1 - lam) * u_y_perm

        # Concatenate labeled and mixed unlabeled data
        x_cat = torch.cat([l_x, mixed_u_x], dim=0)
        y_cat = torch.cat([l_y, mixed_u_y], dim=0)

        # Forward through student model
        y_hat = self.model(x_cat)

        # Loss computation
        pred_soft = F.softmax(y_hat, dim=1)
        target_soft = F.softmax(y_cat, dim=1)
        loss_per_sample = F.mse_loss(pred_soft, target_soft, reduction='none').mean(dim=1)

        unlabeled_loss = loss_per_sample[l_x.size(0):].sum() / x.size(0)

        # EMA update of the mean teacher
        effective_ema = min(self.ema_factor, 1.0 - 1.0 / self.global_step)
        with torch.no_grad():
            for param_s, param_t in zip(self.model.parameters(), self.mean_teacher.parameters()):
                param_t.data.mul_(1.0 - effective_ema).add_(effective_ema * param_s.data)

        return unlabeled_loss

# Example usage:
# model = YourModel()
# trainer = ICT(alpha=0.4, model=model, ema_factor=0.99)
# loss = trainer(inputs, labels, mask)  # mask indicates labeled samples (True) vs unlabeled (False)

