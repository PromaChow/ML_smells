import numpy as np
import pytest
from lagom.transform import (
    interp_curves,
    geometric_cumsum,
    explained_variance,
    LinearSchedule,
    rank_transform,
    PolyakAverage,
    RunningMeanVar,
    SumTree,
    MinTree,
    smooth_filter,
)

# Test interp_curves
def test_interp_curves():
    x1 = np.array([0.0, 1.0, 2.0])
    y1 = np.array([0.0, 1.0, 4.0])
    x2 = np.array([0.0, 0.5, 1.0, 1.5, 2.0])
    y2 = np.array([0.0, 0.25, 1.0, 2.25, 4.0])
    common_x, y1_interp, y2_interp = interp_curves(x1, y1, x2, y2)
    expected_x = x2
    expected_y1 = np.array([0.0, 0.5, 1.0, 2.0, 4.0])
    np.testing.assert_allclose(common_x, expected_x, atol=1e-8)
    np.testing.assert_allclose(y1_interp, expected_y1, atol=1e-8)
    np.testing.assert_allclose(y2_interp, y2, atol=1e-8)
    assert len(common_x) == len(y1_interp) == len(y2_interp)
    assert common_x.min() == 0.0 and common_x.max() == 2.0
    assert y1_interp.min() >= 0.0 and y1_interp.max() <= 4.0

# Test geometric_cumsum
def test_geometric_cumsum():
    y = np.array([1.0, 2.0, 3.0])
    discount = 0.1
    out = geometric_cumsum(y, discount)
    expected = np.array([1.0 + 2.0 * discount + 3.0 * discount**2,
                         2.0 + 3.0 * discount,
                         3.0])
    np.testing.assert_allclose(out, expected, atol=1e-8)
    nested = [[1.0, 2.0], [3.0, 4.0, 5.0]]
    out_nested = geometric_cumsum(nested, discount)
    expected_nested = [
        np.array([1.0 + 2.0 * discount]),
        np.array([3.0 + 4.0 * discount + 5.0 * discount**2,
                  4.0 + 5.0 * discount,
                  5.0])
    ]
    for o, e in zip(out_nested, expected_nested):
        np.testing.assert_allclose(o, e, atol=1e-8)

# Test explained_variance
def test_explained_variance():
    y_true = np.array([3.0, -0.5, 2.0, 7.0])
    y_pred = np.array([2.5, 0.0, 2.0, 8.0])
    ev = explained_variance(y_true, y_pred)
    var_res = np.var(y_true - y_pred, ddof=0)
    var_true = np.var(y_true, ddof=0)
    expected = 1.0 - var_res / var_true
    assert np.isclose(ev, expected, atol=1e-8)
    nested_true = [[3.0, -0.5], [2.0, 7.0]]
    nested_pred = [[2.5, 0.0], [2.0, 8.0]]
    ev_nested = explained_variance(nested_true, nested_pred)
    expected_nested = [
        1.0 - np.var([3.0 - 2.5, -0.5 - 0.0], ddof=0) / np.var([3.0, -0.5], ddof=0),
        1.0 - np.var([2.0 - 2.0, 7.0 - 8.0], ddof=0) / np.var([2.0, 7.0], ddof=0)
    ]
    for e, exp in zip(ev_nested, expected_nested):
        assert np.isclose(e, exp, atol=1e-8)

# Test LinearSchedule
def test_linear_schedule():
    with pytest.raises(AssertionError):
        LinearSchedule(initial=-0.1, target=0.5, steps=10)
    sched_inc = LinearSchedule(initial=0.1, target=0.5, steps=10)
    assert np.isclose(sched_inc(0), 0.1, atol=1e-8)
    assert np.isclose(sched_inc(5), 0.3, atol=1e-8)
    assert np.isclose(sched_inc(10), 0.5, atol=1e-8)
    sched_dec = LinearSchedule(initial=0.5, target=0.1, steps=10)
    assert np.isclose(sched_dec(0), 0.5, atol=1e-8)
    assert np.isclose(sched_dec(5), 0.3, atol=1e-8)
    assert np.isclose(sched_dec(10), 0.1, atol=1e-8)
    warmup = LinearSchedule(initial=0.0, target=1.0, steps=5, warmup_steps=3)
    assert np.isclose(warmup(2), 0.0, atol=1e-8)
    assert np.isclose(warmup(3), 0.5 / 2, atol=1e-8)
    assert np.isclose(warmup(5), 1.0, atol=1e-8)

# Test rank_transform
def test_rank_transform():
    data = [3.0, 1.0, 2.0]
    ranks = rank_transform(data, centered=False)
    expected = np.array([2, 0, 1])
    np.testing.assert_array_equal(ranks, expected)
    centered = rank_transform(data, centered=True)
    expected_centered = expected - np.mean(expected)
    np.testing.assert_array_almost_equal(centered, expected_centered, decimal=6)
    with pytest.raises(AssertionError):
        rank_transform([42])
    with pytest.raises(AssertionError):
        rank_transform(42)

# Test PolyakAverage
def test_polyak_average():
    avg = PolyakAverage(alpha=0.1)
    result1 = avg(1.0)
    assert np.isclose(result1, 1.0, atol=1e-8)
    result2 = avg(2.0)
    expected = 0.1 * 2.0 + 0.9 * 1.0
    assert np.isclose(result2, expected, atol=1e-8)
    avg_list = PolyakAverage(alpha=0.5)
    out1 = avg_list([1.0, 2.0])
    assert np.allclose(out1, [1.0, 2.0], atol=1e-8)
    out2 = avg_list([3.0, 4.0])
    expected_out2 = 0.5 * np.array([3.0, 4.0]) + 0.5 * np.array([1.0, 2.0])
    np.testing.assert_allclose(out2, expected_out2, atol=1e-8)
    with pytest.raises(AssertionError):
        PolyakAverage(alpha=1.5)

# Test RunningMeanVar
def test_running_mean_var():
    rmw = RunningMeanVar()
    rmw.update(1.0)
    mean, var, count = rmw.mean, rmw.var, rmw.count
    assert mean == 1.0
    assert var == 0.0
    assert count == 1
    rmw.update(3.0)
    mean, var, count = rmw.mean, rmw.var, rmw.count
    assert np.isclose(mean, 2.0, atol=1e-8)
    assert np.isclose(var, 1.0, atol=1e-8)
    assert count == 2
    rmw.update([5.0, 7.0])
    mean, var, count = rmw.mean, rmw.var, rmw.count
    assert np.isclose(mean, 4.5, atol=1e-8)
    assert np.isclose(var, 8.0, atol=1e-8)
    assert count == 4

# Test SumTree
def test_sum_tree():
    tree = SumTree(4)
    values = [1.0, 2.0, 3.0, 4.0]
    for idx, val in enumerate(values):
        tree.update(idx, val)
    total = tree.sum(0, len(values))
    assert np.isclose(total, sum(values), atol=1e-8)
    tree.update(1, 5.0)
    total = tree.sum(0, len(values))
    assert np.isclose(total, 1.0 + 5.0 + 3.0 + 4.0, atol=1e-8)
    idx = tree.prefixsum_index(5.0)
    assert idx == 1

# Test MinTree
def test_min_tree():
    tree = MinTree(4)
    values = [4.0, 2.0, 3.0, 1.0]
    for idx, val in enumerate(values):
        tree.update(idx, val)
    mn = tree.min(0, len(values))
    assert mn == 1.0
    tree.update(3, 5.0)
    mn = tree.min(0, len(values))
    assert mn == 2.0

# Test smooth_filter
def test_smooth_filter():
    data = np.random.randn(100)
    smoothed = smooth_filter(data, window=5)
    assert smoothed.shape == data.shape
    assert np.isfinite(smoothed).all()
    with pytest.raises(AssertionError):
        smooth_filter([[1, 2], [3, 4]], window=3)