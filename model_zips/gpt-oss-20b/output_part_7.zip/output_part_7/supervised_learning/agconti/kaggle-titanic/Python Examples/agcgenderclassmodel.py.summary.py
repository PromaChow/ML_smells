import csv
import numpy as np

def load_train(path):
    data = []
    with open(path, newline='', encoding='utf-8') as f:
        reader = csv.reader(f)
        next(reader)  # skip header
        for row in reader:
            survived = int(row[1])
            pclass = int(row[2])
            sex = 0 if row[4].lower() == 'female' else 1
            fare = float(row[9]) if row[9] else 0.0
            data.append([survived, pclass, sex, fare])
    return np.array(data)

def build_survival_table(train_data):
    fares = train_data[:, 3].astype(float)
    fares = np.where(fares > 40, 39, fares)
    edges = np.array([0, 10, 20, 30, 40])
    fare_bins = np.digitize(fares, edges) - 1
    table = np.full((2, 3, 4), np.nan)
    for g in (0, 1):
        for c in (1, 2, 3):
            for b in range(4):
                mask = (train_data[:, 2] == g) & (train_data[:, 1] == c) & (fare_bins == b)
                if np.any(mask):
                    table[g, c - 1, b] = train_data[mask, 0].mean()
    table = np.nan_to_num(table, nan=0.0)
    table = np.where(table < 0.5, 0, 1)
    return table.astype(int)

def load_test_rows(path):
    rows = []
    with open(path, newline='', encoding='utf-8') as f:
        reader = csv.reader(f)
        next(reader)  # skip header
        for row in reader:
            rows.append(row)
    return rows

def predict_test_rows(rows, table):
    edges = np.array([0, 10, 20, 30, 40])
    pred_rows = []
    for row in rows:
        pclass = int(row[2])
        sex = 0 if row[4].lower() == 'female' else 1
        fare_str = row[9]
        if fare_str:
            fare = float(fare_str)
        else:
            fare = 3 if pclass == 1 else 2 if pclass == 2 else 1
        fare = 39 if fare > 40 else fare
        fare_bin = np.digitize([fare], edges)[0] - 1
        pred = int(table[sex, pclass - 1, fare_bin])
        pred_rows.append([str(pred)] + row)
    return pred_rows

def main():
    train_data = load_train('train.csv')
    survival_table = build_survival_table(train_data)
    test_rows = load_test_rows('test.csv')
    predicted_rows = predict_test_rows(test_rows, survival_table)
    with open('genderclasspricebasedmodelpy.csv', 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerows(predicted_rows)

if __name__ == '__main__':
    main()