import torch
import torch.nn as nn
import torch.nn.functional as F
from dataclasses import dataclass

@dataclass
class DiscreteActionValue:
    q_values: torch.Tensor

@dataclass
class DistributionalDiscreteActionValue:
    probs: torch.Tensor
    z_values: torch.Tensor

class DuelingDQN(nn.Module):
    def __init__(self, n_actions: int, n_input_channels: int = 4, activation: nn.Module = nn.ReLU()):
        super().__init__()
        self.activation = activation
        self.conv1 = nn.Conv2d(n_input_channels, 32, kernel_size=8, stride=4, bias=True)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=4, stride=2, bias=True)
        self.conv3 = nn.Conv2d(64, 64, kernel_size=3, stride=1, bias=True)

        # Flattened feature size after conv layers for 84x84 input
        self.feature_dim = 3136  # 64 * 7 * 7

        self.a_stream = nn.Sequential(
            nn.Linear(self.feature_dim, 512),
            nn.ReLU(),
            nn.Linear(512, n_actions)
        )
        self.v_stream = nn.Sequential(
            nn.Linear(self.feature_dim, 512),
            nn.ReLU(),
            nn.Linear(512, 1)
        )

    def forward(self, x: torch.Tensor) -> DiscreteActionValue:
        x = self.activation(self.conv1(x))
        x = self.activation(self.conv2(x))
        x = self.activation(self.conv3(x))
        x = x.view(x.size(0), -1)  # flatten

        ya = self.a_stream(x)  # (batch, n_actions)
        ya = ya - ya.mean(dim=1, keepdim=True)  # center advantages

        ys = self.v_stream(x)  # (batch, 1)

        q_values = ya + ys
        return DiscreteActionValue(q_values=q_values)


class DistributionalDuelingDQN(nn.Module):
    def __init__(
        self,
        n_actions: int,
        n_atoms: int,
        v_min: float,
        v_max: float,
        n_input_channels: int = 4,
        activation: nn.Module = nn.ReLU()
    ):
        super().__init__()
        self.activation = activation
        self.n_actions = n_actions
        self.n_atoms = n_atoms
        self.z_values = torch.linspace(v_min, v_max, steps=n_atoms)

        self.conv1 = nn.Conv2d(n_input_channels, 32, kernel_size=8, stride=4, bias=True)
        self.conv2 = nn.Conv2d(32, 64, kernel_size=4, stride=2, bias=True)
        self.conv3 = nn.Conv2d(64, 64, kernel_size=3, stride=1, bias=True)

        self.feature_dim = 3136  # 64 * 7 * 7

        # Main stream outputs twice the feature dimension to split into advantage and value parts
        self.main_stream = nn.Sequential(
            nn.Linear(self.feature_dim, self.feature_dim * 2),
            nn.ReLU()
        )

        self.a_stream = nn.Linear(self.feature_dim, n_actions * n_atoms)
        self.v_stream = nn.Linear(self.feature_dim, n_atoms)

    def forward(self, x: torch.Tensor) -> DistributionalDiscreteActionValue:
        x = self.activation(self.conv1(x))
        x = self.activation(self.conv2(x))
        x = self.activation(self.conv3(x))
        x = x.view(x.size(0), -1)  # flatten

        main_out = self.main_stream(x)  # (batch, feature_dim * 2)
        h_a, h_v = torch.split(main_out, self.feature_dim, dim=1)

        ya = self.a_stream(h_a)  # (batch, n_actions * n_atoms)
        ya = ya.view(-1, self.n_actions, self.n_atoms)

        ya = ya - ya.mean(dim=1, keepdim=True)  # center advantage distributions

        ys = self.v_stream(h_v)  # (batch, n_atoms)
        ys = ys.unsqueeze(1)  # (batch, 1, n_atoms)

        logits = ya + ys  # broadcast addition
        probs = F.softmax(logits, dim=2)

        # Expected Q-values (optional, can be computed if needed)
        q_values = torch.sum(probs * self.z_values.to(probs.device), dim=2)  # (batch, n_actions)

        return DistributionalDiscreteActionValue(probs=probs, z_values=self.z_values)
