import numpy as np
from typing import Dict, Tuple, Any

class TabularModel:
    def __init__(self, s_dim: int, a_dim: int):
        # store next state as an object array; None indicates unseen transition
        self.s_model: np.ndarray = np.full((s_dim, a_dim), None, dtype=object)
        self.r_model: np.ndarray = np.zeros((s_dim, a_dim), dtype=float)

    def add(self, state: np.ndarray, action: int, reward: float, next_state: np.ndarray):
        """Add a deterministic transition to the model."""
        self.s_model[state, action] = next_state
        self.r_model[state, action] = reward

    def sample(self) -> Tuple[np.ndarray, int]:
        """Randomly sample a visited state and an action that has a defined transition."""
        visited = np.argwhere(self.s_model != None)
        if visited.size == 0:
            raise RuntimeError("No transitions have been added to the model.")
        idx = np.random.choice(len(visited))
        state, action = visited[idx]
        return np.array(state), int(action)

    def step(self, state: np.ndarray, action: int) -> Tuple[float, np.ndarray]:
        """Return the reward and next state for a given state-action pair."""
        if state < 0 or state >= self.s_model.shape[0]:
            raise IndexError("State index out of bounds.")
        if action < 0 or action >= self.s_model.shape[1]:
            raise IndexError("Action index out of bounds.")
        next_state = self.s_model[state, action]
        reward = self.r_model[state, action]
        if next_state is None:
            raise RuntimeError("Transition for the given state-action pair is undefined.")
        return float(reward), next_state

    def is_empty(self) -> bool:
        """Check if the model contains any transitions."""
        has_states = any(x is not None for x in self.s_model.flat)
        has_rewards = np.any(self.r_model != 0)
        return not (has_states or has_rewards)

# Global registry mapping model names to classes
model_registry: Dict[str, Any] = {
    "tabular": TabularModel
}

def get_model_from_name(name: str):
    """Retrieve a model class from the registry by name."""
    if name not in model_registry:
        raise ValueError(f"Model '{name}' not found in registry.")
    return model_registry[name]