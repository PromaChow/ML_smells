import numpy as np
from scipy import stats

class BernoulliBanditEnv:
    def __init__(self, num_contexts, num_actions, probabilities):
        self.num_contexts = num_contexts
        self.num_actions = num_actions
        self.probabilities = np.array(probabilities)

    def step(self, context, action):
        p = self.probabilities[context, action]
        return np.random.binomial(1, p)


class BayesianUCBAgent:
    def __init__(self, env, alpha=1.0, beta=1.0, confidence=1.0):
        self.env = env
        self.alpha = alpha
        self.beta = beta
        self.confidence = confidence
        self.num_contexts = env.num_contexts
        self.num_actions = env.num_actions
        self.a = np.full((self.num_contexts, self.num_actions), alpha)
        self.b = np.full((self.num_contexts, self.num_actions), beta)
        self.counts = np.zeros((self.num_contexts, self.num_actions), dtype=int)
        self.regret_history = []
        self.action_history = []
        self.reward_history = []

    @property
    def quality(self):
        return self.a / (self.a + self.b)

    def select_action(self, context):
        q = self.quality[context]
        std = stats.beta.std(self.a[context], self.b[context])
        ucb = q + self.confidence * std
        return int(np.argmax(ucb))

    def step(self, context):
        action = self.select_action(context)
        reward = self.env.step(context, action)
        self.update(context, action, reward)
        self.action_history.append((context, action))
        self.reward_history.append(reward)
        return action, reward

    def update(self, context, action, reward):
        self.a[context, action] += reward
        self.b[context, action] += 1 - reward
        self.counts[context, action] += 1
        max_q = np.max(self.quality[context])
        regret = max_q - self.quality[context, action]
        self.regret_history.append(regret)


if __name__ == "__main__":
    probabilities = [
        [0.1, 0.4, 0.6, 0.3, 0.5],
        [0.3, 0.2, 0.8, 0.5, 0.1],
        [0.5, 0.6, 0.2, 0.7, 0.4]
    ]
    env = BernoulliBanditEnv(num_contexts=3, num_actions=5, probabilities=probabilities)
    agent = BayesianUCBAgent(env, confidence=1.0)

    for _ in range(1000):
        context = np.random.randint(0, env.num_contexts)
        agent.step(context)

    print("Average regret:", np.mean(agent.regret_history))
    print("Action counts per context:\n", agent.counts)