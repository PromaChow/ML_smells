import gym
import numpy as np
import cv2
from gym import spaces


class AtariRescale42x42(gym.Wrapper):
    def __init__(self, env):
        super().__init__(env)
        # Define observation space: (1, 42, 42) with values in [0.0, 1.0]
        self.observation_space = spaces.Box(
            low=0.0,
            high=1.0,
            shape=(1, 42, 42),
            dtype=np.float32,
        )

    def observation(self, obs):
        # Crop: rows 34 to 193 (inclusive), columns 0 to 159
        cropped = obs[34 : 34 + 160, :160]
        # Resize to 80x80
        resized_80 = cv2.resize(
            cropped,
            (80, 80),
            interpolation=cv2.INTER_LINEAR,
        )
        # Resize to 42x42
        resized_42 = cv2.resize(
            resized_80,
            (42, 42),
            interpolation=cv2.INTER_LINEAR,
        )
        # Grayscale: mean across color channels
        gray = resized_42.mean(axis=2)
        # Normalize to [0,1]
        gray_norm = (gray / 255.0).astype(np.float32)
        # Add channel dimension at first axis
        result = np.expand_dims(gray_norm, axis=0)
        return result


class NormalizedEnv(gym.Wrapper):
    def __init__(self, env, alpha=0.9999, eps=1e-8):
        super().__init__(env)
        self.alpha = alpha
        self.eps = eps
        self.num_steps = 0
        # Initialize running sums for mean and variance computation
        shape = env.observation_space.shape
        self.state_sum = np.zeros(shape, dtype=np.float32)
        self.state_sum_sq = np.zeros(shape, dtype=np.float32)

    def step(self, action):
        obs, reward, done, info = self.env.step(action)
        self._update_running_stats(obs)
        normalized_obs = self._normalize(obs)
        return normalized_obs, reward, done, info

    def reset(self, **kwargs):
        obs = self.env.reset(**kwargs)
        self._update_running_stats(obs)
        return self._normalize(obs)

    def _update_running_stats(self, obs):
        self.num_steps += 1
        self.state_sum = self.alpha * self.state_sum + (1.0 - self.alpha) * obs
        self.state_sum_sq = (
            self.alpha * self.state_sum_sq + (1.0 - self.alpha) * (obs**2)
        )

    def _normalize(self, obs):
        # Compute unbiased mean and std
        factor = 1.0 - self.alpha ** self.num_steps
        unbiased_mean = self.state_sum / factor
        unbiased_var = self.state_sum_sq / factor - unbiased_mean**2
        unbiased_std = np.sqrt(np.maximum(unbiased_var, 0.0))
        # Normalize observation
        normalized = (obs - unbiased_mean) / (unbiased_std + self.eps)
        return normalized


def create_atari_env(env_id: str):
    env = gym.make(env_id)
    env = AtariRescale42x42(env)
    env = NormalizedEnv(env)
    return env

# Example usage (uncomment to test):
# env = create_atari_env("PongNoFrameskip-v4")
# obs = env.reset()
# done = False
# while not done:
#     action = env.action_space.sample()
#     obs, reward, done, info = env.step(action)