import re
import csv
from pathlib import Path
import numpy as np
import joblib

# Custom utilities (assumed to be available in the environment)
import dsu
import embeddings

# Constants
EMBEDDING_FILE = Path("dataset.vec")
TWEET_THRESHOLD = 3
DATA_DIR = Path("Data")
OUTPUT_CSV = Path("personality_predictions1_big.csv")

# Trait identifiers and corresponding model filenames
TRAITS = ["O", "C", "E", "A", "N"]
MODEL_FILES = {
    "O": "svm_O.joblib",
    "C": "svm_C.joblib",
    "E": "svm_E.joblib",
    "A": "svm_A.joblib",
    "N": "svm_N.joblib",
}

def load_models():
    models = {}
    for trait, file in MODEL_FILES.items():
        models[trait] = joblib.load(file)
    return models

def clean_tweet(tweet):
    tweet = tweet.strip()
    if tweet.startswith("RT"):
        return None
    tweet = re.sub(r"http\S+|www.\S+", "", tweet)
    tweet = re.sub(r"@\w+", "", tweet)
    return tweet.strip() or None

def process_user(username, models, word_dict):
    tweet_file = DATA_DIR / f"{username}_tweets.txt"
    if not tweet_file.exists():
        print(f"Tweet file not found for {username}, skipping.")
        return None

    with tweet_file.open("r", encoding="utf-8") as f:
        raw_tweets = f.readlines()

    filtered_tweets = [clean_tweet(t) for t in raw_tweets]
    filtered_tweets = [t for t in filtered_tweets if t]

    if not filtered_tweets:
        print(f"No valid tweets for {username}, skipping.")
        return None

    try:
        embeddings_arr = embeddings.transformTextForTesting(
            filtered_tweets, word_dict, TWEET_THRESHOLD
        )
    except Exception as e:
        print(f"Embedding transformation failed for {username}: {e}")
        return None

    scores = {}
    for trait in TRAITS:
        preds = models[trait].predict(embeddings_arr)
        scores[trait] = round(float(np.mean(preds)), 5)

    jungian = (
        ("E" if scores["E"] > 3 else "I") +
        ("N" if scores["O"] > 3 else "S") +
        ("F" if scores["A"] > 3 else "T") +
        ("J" if scores["C"] > 3 else "P")
    )

    return [username, scores["O"], scores["C"], scores["E"], scores["A"], scores["N"], jungian]

def main():
    user_input = input("Enter a username (starting with @) or a filename: ").strip()
    if user_input.startswith("@"):
        usernames = [user_input[1:]]
    else:
        file_path = Path(user_input)
        if not file_path.exists():
            print(f"File {file_path} does not exist.")
            return
        with file_path.open("r", encoding="utf-8") as f:
            usernames = [line.strip() for line in f if line.strip()]
        if not usernames:
            print("No usernames found in the file.")
            return

    word_dict = dsu.parseFastText(EMBEDDING_FILE)
    models = load_models()

    results = []
    for username in usernames:
        res = process_user(username, models, word_dict)
        if res:
            results.append(res)

    with OUTPUT_CSV.open("w", newline="", encoding="utf-8") as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(["username", "O", "C", "E", "A", "N", "Jungian"])
        writer.writerows(results)

if __name__ == "__main__":
    main()
