import unittest
import numpy as np
from pywsl.pul.chainer.functions.nnpu_risk import PU_Risk

class TestPU_Risk(unittest.TestCase):
    def setUp(self):
        self.n_p = 20
        self.n_u = 80
        self.prior = 0.5

        # target labels: positives first, then unlabeled (treated as negatives)
        self.y = np.concatenate([np.ones(self.n_p, dtype=np.int32),
                                 np.zeros(self.n_u, dtype=np.int32)])

        # predictions: positives get high score, unlabeled get low score
        yh_pos = np.full(self.n_p, 2.0, dtype=np.float32)
        yh_unl = np.full(self.n_u, -1.0, dtype=np.float32)
        self.yh = np.concatenate([yh_pos, yh_unl], dtype=np.float32).reshape(-1, 1)

    def test_standard_pu_risk_negative(self):
        pu_risk = PU_Risk(nnPU=False, prior=self.prior)
        risk_value = pu_risk(self.yh, self.y)
        if isinstance(risk_value, np.ndarray):
            risk_value = risk_value.item()
        self.assertLess(risk_value, 0.0, "Standard PU risk should be negative")

    def test_nnpu_risk_positive(self):
        nnpu_risk = PU_Risk(nnPU=True, prior=self.prior)
        risk_value = nnpu_risk(self.yh, self.y)
        if isinstance(risk_value, np.ndarray):
            risk_value = risk_value.item()
        self.assertGreater(risk_value, 0.0, "nnPU risk should be positive")

if __name__ == "__main__":
    unittest.main()