import torch
import torch.nn.functional as F


class ConsistencyRegularizer:
    def __init__(
        self,
        consistency_type: str = "cross_entropy",
        threshold: float | None = 0.8,
        sharpening: float | None = None,
        temp_softmax: float | None = None,
    ):
        self.consistency_type = consistency_type
        self.threshold = threshold
        self.sharpening = sharpening
        self.temp_softmax = temp_softmax

    def gen_mask(self, tea_logits: torch.Tensor) -> torch.Tensor:
        probs = F.softmax(tea_logits, dim=1)
        max_probs, _ = probs.max(dim=1)
        if self.threshold is None or self.threshold == 0:
            mask = torch.ones_like(max_probs, dtype=torch.bool)
        else:
            mask = max_probs > self.threshold
        return mask

    def adjust_target(self, tea_logits: torch.Tensor) -> torch.Tensor:
        if self.sharpening is not None:
            probs = F.softmax(tea_logits, dim=1)
            sharpened = probs.pow(1.0 / self.sharpening)
            targets = sharpened / sharpened.sum(dim=1, keepdim=True)
        elif self.temp_softmax is not None:
            targets = F.softmax(tea_logits / self.temp_softmax, dim=1)
        else:
            targets = F.softmax(tea_logits, dim=1)
        return targets

    def __call__(
        self, stu_preds: torch.Tensor, tea_logits: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        mask = self.gen_mask(tea_logits)
        targets = self.adjust_target(tea_logits)
        return stu_preds, targets, mask

# Example usage:
# reg = ConsistencyRegularizer(threshold=0.9, sharpening=0.5)
# stu_preds, targets, mask = reg(stu_preds_tensor, tea_logits_tensor)