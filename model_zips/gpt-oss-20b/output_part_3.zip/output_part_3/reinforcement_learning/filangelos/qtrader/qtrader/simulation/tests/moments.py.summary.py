import uuid
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from scipy import stats

eps = np.finfo(float).eps

class Moments:
    @classmethod
    def run(cls, df_1: pd.DataFrame, df_2: pd.DataFrame, log: bool = False, render: bool = False):
        if not isinstance(df_1, pd.DataFrame) or not isinstance(df_2, pd.DataFrame):
            raise TypeError("Both inputs must be pandas DataFrames.")
        if set(df_1.columns) != set(df_2.columns):
            raise ValueError("DataFrames must have identical columns.")

        render_uuid = uuid.uuid4()

        first = cls._first_order(df_1, df_2, log, render, render_uuid)
        second = cls._second_order(df_1, df_2, log, render, render_uuid)
        third = cls._third_order(df_1, df_2, log, render, render_uuid)
        forth = cls._forth_order(df_1, df_2, log, render, render_uuid)

        return {"first": first, "second": second, "third": third, "forth": forth}

    @staticmethod
    def _reldev(val1, val2):
        return abs((val1 + eps) / (val2 + eps) - 1)

    @classmethod
    def _first_order(cls, df_1, df_2, log, render, render_uuid):
        summary = {}
        for col in df_1.columns:
            m1, m2 = df_1[col].mean(), df_2[col].mean()
            md1, md2 = df_1[col].median(), df_2[col].median()
            mode1 = df_1[col].mode().iloc[0]
            mode2 = df_2[col].mode().iloc[0]

            rel_mean = cls._reldev(m1, m2)
            rel_median = cls._reldev(md1, md2)
            rel_mode = cls._reldev(mode1, mode2)

            df = pd.DataFrame({
                "df_1": [m1, md1, mode1],
                "df_2": [m2, md2, mode2],
                "reldev": [rel_mean, rel_median, rel_mode]
            }, index=["mean", "median", "mode"])
            summary[col] = df

            if log:
                print(f"\n--- First-order comparison for column: {col} ---")
                print(df)

        if render:
            assets = np.random.choice(df_1.columns, min(3, len(df_1.columns)), replace=False)
            for asset in assets:
                plt.figure(figsize=(10, 4))
                sns.histplot(df_1[asset], kde=True, color="blue", label="df_1", stat="density")
                sns.histplot(df_2[asset], kde=True, color="red", label="df_2", stat="density")
                plt.axvline(df_1[asset].mean(), color="blue", linestyle="--")
                plt.axvline(df_2[asset].mean(), color="red", linestyle="--")
                plt.axvline(df_1[asset].median(), color="blue", linestyle=":")
                plt.axvline(df_2[asset].median(), color="red", linestyle=":")
                plt.axvline(df_1[asset].mode().iloc[0], color="blue", linestyle="-.")
                plt.axvline(df_2[asset].mode().iloc[0], color="red", linestyle="-.")
                plt.title(f"Distribution of {asset} with mean, median, mode")
                plt.legend()
                plt.tight_layout()
                plt.show()

        return summary

    @classmethod
    def _second_order(cls, df_1, df_2, log, render, render_uuid):
        cov_1 = df_1.cov()
        cov_2 = df_2.cov()
        frob1 = np.linalg.norm(cov_1, ord='fro')
        frob2 = np.linalg.norm(cov_2, ord='fro')
        cov_reldev = np.linalg.norm(cov_1 - cov_2, ord='fro') / (np.sqrt(frob1 * frob2) + eps)

        summary = {}
        for col in df_1.columns:
            std1, std2 = df_1[col].std(), df_2[col].std()
            rel_std = cls._reldev(std1, std2)

            bart_stat, bart_p = stats.bartlett(df_1[col], df_2[col])
            levene_stat, levene_p = stats.levene(df_1[col], df_2[col])
            fligner_stat, fligner_p = stats.fligner(df_1[col], df_2[col])

            df = pd.DataFrame({
                "df_1": [std1],
                "df_2": [std2],
                "reldev": [rel_std],
                "bartlett_stat": [bart_stat],
                "bartlett_p": [bart_p],
                "levene_stat": [levene_stat],
                "levene_p": [levene_p],
                "fligner_stat": [fligner_stat],
                "fligner_p": [fligner_p]
            }, index=["std", "reldev", "bartlett", "levene", "fligner"])
            summary[col] = df

            if log:
                print(f"\n--- Second-order comparison for column: {col} ---")
                print(df)

        if render:
            assets = np.random.choice(df_1.columns, min(3, len(df_1.columns)), replace=False)
            for asset in assets:
                fig, axes = plt.subplots(1, 3, figsize=(15, 4))
                sns.heatmap(cov_1, ax=axes[0], cmap="coolwarm", square=True, cbar=False)
                axes[0].set_title(f"{asset} Covariance df_1")
                sns.heatmap(cov_2, ax=axes[1], cmap="coolwarm", square=True, cbar=False)
                axes[1].set_title(f"{asset} Covariance df_2")
                sns.heatmap(np.abs(cov_1 - cov_2), ax=axes[2], cmap="coolwarm", square=True, cbar=False)
                axes[2].set_title(f"{asset} |Cov1 - Cov2|")
                plt.tight_layout()
                plt.show()

        return summary

    @classmethod
    def _third_order(cls, df_1, df_2, log, render, render_uuid):
        summary = {}
        for col in df_1.columns:
            skew1, skew2 = df_1[col].skew(), df_2[col].skew()
            rel_skew = cls._reldev(skew1, skew2)

            stat, p = stats.skewtest(df_1[col].append(df_2[col]))
            df = pd.DataFrame({
                "df_1": [skew1],
                "df_2": [skew2],
                "reldev": [rel_skew],
                "skewtest_stat": [stat],
                "skewtest_p": [p]
            }, index=["skew", "reldev", "skewtest"])
            summary[col] = df

            if log:
                print(f"\n--- Third-order comparison for column: {col} ---")
                print(df)

        if render:
            assets = np.random.choice(df_1.columns, min(3, len(df_1.columns)), replace=False)
            for asset in assets:
                mean1, std1 = df_1[asset].mean(), df_1[asset].std()
                mean2, std2 = df_2[asset].mean(), df_2[asset].std()
                x = np.linspace(min(df_1[asset].min(), df_2[asset].min()),
                                max(df_1[asset].max(), df_2[asset].max()), 200)
                norm1 = stats.norm.pdf(x, loc=mean1, scale=std1)
                norm2 = stats.norm.pdf(x, loc=mean2, scale=std2)

                plt.figure(figsize=(10, 4))
                sns.histplot(df_1[asset], kde=False, stat="density", label="df_1", color="blue", alpha=0.6)
                sns.histplot(df_2[asset], kde=False, stat="density", label="df_2", color="red", alpha=0.6)
                plt.plot(x, norm1, color="blue", linestyle="--", label="Normal df_1")
                plt.plot(x, norm2, color="red", linestyle="--", label="Normal df_2")
                plt.title(f"Skewness comparison for {asset}")
                plt.legend()
                plt.tight_layout()
                plt.show()

        return summary

    @classmethod
    def _forth_order(cls, df_1, df_2, log, render, render_uuid):
        summary = {}
        for col in df_1.columns:
            kurt1, kurt2 = df_1[col].kurt(), df_2[col].kurt()
            rel_kurt = cls._reldev(kurt1, kurt2)

            stat, p = stats.kurtosistest(df_1[col].append(df_2[col]))
            df = pd.DataFrame({
                "df_1": [kurt1],
                "df_2": [kurt2],
                "reldev": [rel_kurt],
                "kurtosistest_stat": [stat],
                "kurtosistest_p": [p]
            }, index=["kurtosis", "reldev", "kurtosistest"])
            summary[col] = df

            if log:
                print(f"\n--- Fourth-order comparison for column: {col} ---")
                print(df)

        if render:
            assets = np.random.choice(df_1.columns, min(3, len(df_1.columns)), replace=False)
            for asset in assets:
                mean1, std1 = df_1[asset].mean(), df_1[asset].std()
                mean2, std2 = df_2[asset].mean(), df_2[asset].std()
                x = np.linspace(min(df_1[asset].min(), df_2[asset].min()),
                                max(df_1[asset].max(), df_2[asset].max()), 200)
                norm1 = stats.norm.pdf(x, loc=mean1, scale=std1)
                norm2 = stats.norm.pdf(x, loc=mean2, scale=std2)

                plt.figure(figsize=(10, 4))
                sns.histplot(df_1[asset], kde=False, stat="density", label="df_1", color="blue", alpha=0.6)
                sns.histplot(df_2[asset], kde=False, stat="density", label="df_2", color="red", alpha=0.6)
                plt.plot(x, norm1, color="blue", linestyle="--", label="Normal df_1")
                plt.plot(x, norm2, color="red", linestyle="--", label="Normal df_2")
                plt.title(f"Kurtosis comparison for {asset}")
                plt.legend()
                plt.tight_layout()
                plt.show()

        return summary

if __name__ == "__main__":
    # Example usage (replace with real DataFrames)
    df_a = pd.DataFrame({
        "A": np.random.normal(0, 1, 100),
        "B": np.random.normal(1, 2, 100),
        "C": np.random.normal(-1, 0.5, 100)
    })
    df_b = pd.DataFrame({
        "A": np.random.normal(0.1, 1.1, 100),
        "B": np.random.normal(0.9, 1.9, 100),
        "C": np.random.normal(-1.2, 0.6, 100)
    })
    results = Moments.run(df_a, df_b, log=True, render=False)
    print("\nSummary of all tests:")
    print(results)