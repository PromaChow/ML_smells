import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.decomposition import PCA
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

# Load dataset
digits = load_digits()
X = digits.data
y = digits.target

# Visualize a sample image
plt.figure()
plt.imshow(digits.images[0], cmap='gray')
plt.title('Sample Digit Image')
plt.axis('off')
plt.show()

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# Baseline logistic regression
log_reg = LogisticRegression(max_iter=1000, random_state=42)
log_reg.fit(X_train, y_train)
y_pred_baseline = log_reg.predict(X_test)
baseline_accuracy = accuracy_score(y_test, y_pred_baseline)
print(f'Baseline Logistic Regression Accuracy: {baseline_accuracy:.4f}')

# PCA on entire dataset
pca = PCA(n_components=10, random_state=42)
pca.fit(X)
explained_variance = pca.explained_variance_ratio_
cumulative_variance = np.cumsum(explained_variance)
print(f'Explained variance ratios: {explained_variance}')
print(f'Cumulative explained variance: {cumulative_variance}')

# Transform training and testing data
X_train_pca = pca.transform(X_train)
X_test_pca = pca.transform(X_test)

# Logistic regression on PCA-transformed data
log_reg_pca = LogisticRegression(max_iter=1000, random_state=42)
log_reg_pca.fit(X_train_pca, y_train)
y_pred_pca = log_reg_pca.predict(X_test_pca)
pca_accuracy = accuracy_score(y_test, y_pred_pca)
print(f'Logistic Regression Accuracy after PCA: {pca_accuracy:.4f}')

# Confusion matrix and classification report
conf_mat = confusion_matrix(y_test, y_pred_pca)
class_report = classification_report(y_test, y_pred_pca)
print('Confusion Matrix:')
print(conf_mat)
print('Classification Report:')
print(class_report)

# Plot misclassified samples
misclassified_indices = np.where(y_pred_pca != y_test)[0]
num_to_plot = min(5, len(misclassified_indices))
fig, axes = plt.subplots(1, num_to_plot, figsize=(15, 3))
for i, idx in enumerate(misclassified_indices[:num_to_plot]):
    axes[i].imshow(digits.images[idx], cmap='gray')
    axes[i].set_title(f'True: {y_test[idx]}, Pred: {y_pred_pca[idx]}')
    axes[i].axis('off')
plt.tight_layout()
plt.show()