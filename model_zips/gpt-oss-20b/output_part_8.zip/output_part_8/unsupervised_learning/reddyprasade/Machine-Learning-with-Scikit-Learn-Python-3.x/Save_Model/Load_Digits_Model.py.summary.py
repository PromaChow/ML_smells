import joblib
from sklearn.datasets import load_digits

def main():
    filename = 'digits_classifier.joblib.pkl'
    digits = load_digits()
    clf2 = joblib.load(filename)
    score = clf2.score(digits.data, digits.target)
    print(score)

if __name__ == "__main__":
    main()