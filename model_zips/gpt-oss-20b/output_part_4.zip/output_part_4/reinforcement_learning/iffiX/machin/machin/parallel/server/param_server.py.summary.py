import os
import random
import threading
import queue
import time
from dataclasses import dataclass, field
from typing import Dict, Tuple, List

import torch
import torch.nn as nn
import torch.optim as optim
import torch.distributed as dist
import torch.distributed.rpc as rpc


# ----------------------------------
# Ordered server implementation
# ----------------------------------
class OrderedServerBase:
    def push(self, model_name: str, state_dict: Dict[str, torch.Tensor], version: int) -> bool:
        raise NotImplementedError

    def pull(self, model_name: str) -> Tuple[Dict[str, torch.Tensor], int]:
        raise NotImplementedError


class OrderedServerSimpleImpl(OrderedServerBase):
    def __init__(self):
        self._store: Dict[str, Tuple[Dict[str, torch.Tensor], int]] = {}
        self._lock = threading.Lock()

    def push(self, model_name: str, state_dict: Dict[str, torch.Tensor], version: int) -> bool:
        with self._lock:
            current = self._store.get(model_name)
            if current and current[1] >= version:
                return False
            # clone state_dict to avoid external changes
            state_copy = {k: v.clone() for k, v in state_dict.items()}
            self._store[model_name] = (state_copy, version)
            return True

    def pull(self, model_name: str) -> Tuple[Dict[str, torch.Tensor], int]:
        with self._lock:
            return self._store.get(model_name, ({}, -1))


# ----------------------------------
# PushPullModelServer
# ----------------------------------
class PushPullModelServer:
    def __init__(self, model: nn.Module, model_name: str, ordered_server: OrderedServerBase):
        self.model = model
        self.model_name = model_name
        self.ordered_server = ordered_server
        self.pp_version = -1

    def push(self):
        state = {k: v.cpu() for k, v in self.model.state_dict().items()}
        success = self.ordered_server.push(self.model_name, state, self.pp_version + 1)
        if not success:
            pulled_state, pulled_version = self.ordered_server.pull(self.model_name)
            if pulled_version > self.pp_version:
                self.model.load_state_dict(pulled_state, strict=False)
                self.pp_version = pulled_version

    def pull(self):
        pulled_state, pulled_version = self.ordered_server.pull(self.model_name)
        if pulled_version > self.pp_version:
            self.model.load_state_dict(pulled_state, strict=False)
            self.pp_version = pulled_version


# ----------------------------------
# PushPullGradServer
# ----------------------------------
@dataclass
class PushPullGradServerImpl:
    primary_rank: int
    secondary_ranks: List[int]
    model: nn.Module
    optimizer: optim.Optimizer
    ordered_server: OrderedServerBase
    reduce_batch_size: int = 4
    reduce_device: str = "cpu"
    reduce_method: str = "sum"
    max_queue_size: int = 64
    queue_dict: Dict[int, queue.Queue] = field(default_factory=dict)
    master_queue: queue.Queue = field(default_factory=queue.Queue)
    stop_event: threading.Event = field(default_factory=threading.Event)
    thread: threading.Thread = field(init=False)

    def __post_init__(self):
        for r in self.secondary_ranks:
            self.queue_dict[r] = queue.Queue(maxsize=self.max_queue_size)
        self.thread = threading.Thread(target=self._reduction_loop, daemon=True)
        self.thread.start()

    def _reduction_loop(self):
        while not self.stop_event.is_set():
            if self.master_queue.qsize() >= self.reduce_batch_size or any(
                q.qsize() >= self.reduce_batch_size for q in self.queue_dict.values()
            ):
                self._process_batch()
            time.sleep(0.01)

    def _process_batch(self):
        grads_batch = []
        while not self.master_queue.empty() and len(grads_batch) < self.reduce_batch_size:
            grads_batch.append(self.master_queue.get())
        for q in self.queue_dict.values():
            while not q.empty() and len(grads_batch) < self.reduce_batch_size:
                grads_batch.append(q.get())

        if not grads_batch:
            return

        # Reduce gradients
        reduced = {}
        for name, tensor in grads_batch[0].items():
            stacked = torch.stack([g[name] for g in grads_batch])
            if self.reduce_method == "mean":
                reduced[name] = stacked.mean(dim=0).to(self.reduce_device)
            else:
                reduced[name] = stacked.sum(dim=0).to(self.reduce_device)

        # Apply to model
        for name, param in self.model.named_parameters():
            if name in reduced:
                param.grad = reduced[name]
        self.optimizer.step()
        self.optimizer.zero_grad()

        # Push updated model
        state = {k: v.cpu() for k, v in self.model.state_dict().items()}
        self.ordered_server.push(self.model_name, state, self.pp_version + 1)

    def stop(self):
        self.stop_event.set()
        self.thread.join()


class PushPullGradServer:
    def __init__(
        self,
        server_name: str,
        rpc_group: List[int],
        model: nn.Module,
        optimizer: optim.Optimizer,
        ordered_server: OrderedServerBase,
        secondary_reducers: List[int],
        reduce_batch_size: int = 4,
        reduce_device: str = "cpu",
        reduce_method: str = "sum",
    ):
        self.server_name = server_name
        self.rpc_group = rpc_group
        self.model = model
        self.optimizer = optimizer
        self.ordered_server = ordered_server
        self.secondary_reducers = secondary_reducers
        self.reduce_batch_size = reduce_batch_size
        self.reduce_device = reduce_device
        self.reduce_method = reduce_method
        self.pp_version = -1
        self.model_name = server_name

        # Register RPC functions
        rpc.register_rpc_function("push_grad", self.push_grad)
        rpc.register_rpc_function("pull", self.pull)

        # Setup implementation
        self.impl = PushPullGradServerImpl(
            primary_rank=rpc_group[0],
            secondary_ranks=secondary_reducers,
            model=self.model,
            optimizer=self.optimizer,
            ordered_server=self.ordered_server,
            reduce_batch_size=self.reduce_batch_size,
            reduce_device=self.reduce_device,
            reduce_method=self.reduce_method,
        )

    def push_grad(self, gradients: Dict[str, torch.Tensor]):
        # Put gradients into appropriate queue
        rank = dist.get_rank()
        if rank in self.secondary_reducers:
            q = self.impl.queue_dict[rank]
            if not q.full():
                q.put(gradients)
        else:
            # primary receives directly
            if not self.impl.master_queue.full():
                self.impl.master_queue.put(gradients)

    def pull(self) -> Tuple[Dict[str, torch.Tensor], int]:
        state, version = self.ordered_server.pull(self.model_name)
        if version > self.pp_version:
            self.model.load_state_dict(state, strict=False)
            self.pp_version = version
        return state, version

    def stop(self):
        self.impl.stop()


# ----------------------------------
# Example usage (for illustration only)
# ----------------------------------
def run_server(rank: int, world_size: int):
    os.environ["MASTER_ADDR"] = "127.0.0.1"
    os.environ["MASTER_PORT"] = "29500"
    dist.init_process_group(backend="gloo", rank=rank, world_size=world_size)
    rpc.init_rpc(f"node{rank}", rank=rank, world_size=world_size)

    model = nn.Linear(10, 2)
    optimizer = optim.SGD(model.parameters(), lr=0.01)
    ordered_server = OrderedServerSimpleImpl()

    if rank == 0:
        server = PushPullGradServer(
            server_name="grad_server",
            rpc_group=list(range(world_size)),
            model=model,
            optimizer=optimizer,
            ordered_server=ordered_server,
            secondary_reducers=list(range(1, world_size)),
        )
    else:
        # Clients
        pass

    rpc.shutdown()
    dist.destroy_process_group()


if __name__ == "__main__":
    world_size = 4
    processes = []
    for rank in range(world_size):
        p = threading.Thread(target=run_server, args=(rank, world_size))
        p.start()
        processes.append(p)
    for p in processes:
        p.join()
