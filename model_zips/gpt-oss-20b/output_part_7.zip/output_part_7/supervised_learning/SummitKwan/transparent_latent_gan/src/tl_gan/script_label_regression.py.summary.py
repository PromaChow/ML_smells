import os
import h5py
import numpy as np
import pandas as pd
import pickle
import matplotlib.pyplot as plt
from feature_axis import (
    find_feature_axis,
    normalize_feature_axis,
    disentangle_feature_axis_by_idx,
    plot_feature_cos_sim,
)

# Paths
path_z = "sample_z.h5"
path_y = "sample_y.h5"
path_attr_csv = "list_attr_celeba.txt"
path_feature_direction = "feature_directions"
filename = os.path.join(path_feature_direction, "feature_direction.pkl")

# Ensure output directory exists
os.makedirs(path_feature_direction, exist_ok=True)

# 1. Data Loading
with h5py.File(path_z, "r") as f:
    z = f["latent_codes"][:] if "latent_codes" in f else f["z"][:]
with h5py.File(path_y, "r") as f:
    y = f["labels"][:] if "labels" in f else f["y"][:]

# Read attribute names
attr_df = pd.read_csv(path_attr_csv, delim_whitespace=True, header=None)
y_name = attr_df[0].tolist()
len_y = len(y_name)

# 2. Regression Analysis
feature_slope = find_feature_axis(
    z, y, method="tanh"
)

# 3. Normalization
yn_normalize_feature_direction = True
if yn_normalize_feature_direction:
    feature_slope = normalize_feature_axis(feature_slope)

# 4. Saving Results
with open(filename, "wb") as f:
    pickle.dump({"feature_slope": feature_slope, "y_name": y_name}, f)

# 5. Disentanglement of Correlated Features
with open(filename, "rb") as f:
    data = pickle.load(f)
feature_slope_loaded = data["feature_slope"]
y_name_loaded = data["y_name"]

idx_base = list(range(len_y // 4))
feature_slope_disentangled = disentangle_feature_axis_by_idx(
    feature_slope_loaded,
    idx_base=idx_base,
    idx_target=None,
)

# 6. Visualization
plot_feature_cos_sim(
    feature_slope_disentangled,
    feature_name=y_name_loaded,
    title="Cosine Similarity of Disentangled Feature Directions",
)
plt.tight_layout()
plt.show()