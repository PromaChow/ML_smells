import numpy as np
import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn.linear_model import LogisticRegression

def main():
    # Load data
    iris = datasets.load_iris()
    X = iris.data[:, :2]  # sepal length, sepal width
    Y = iris.target

    # Model
    h = 0.02
    clf = LogisticRegression(C=1e5, solver='lbfgs', max_iter=2000)
    clf.fit(X, Y)

    # Mesh grid
    x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
                         np.arange(y_min, y_max, h))
    grid_points = np.c_[xx.ravel(), yy.ravel()]
    Z = clf.predict(grid_points)
    Z = Z.reshape(xx.shape)

    # Plot
    plt.figure(figsize=(8, 6))
    plt.pcolormesh(xx, yy, Z, cmap=plt.cm.coolwarm, shading='auto')
    scatter = plt.scatter(X[:, 0], X[:, 1], c=Y, edgecolor='k', cmap=plt.cm.coolwarm)
    plt.xlabel('Sepal length')
    plt.ylabel('Sepal width')
    plt.xlim(xx.min(), xx.max())
    plt.ylim(yy.min(), yy.max())
    plt.title('Logistic Regression Decision Boundary on Iris Dataset')
    plt.legend(handles=scatter.legend_elements()[0], labels=iris.target_names)
    plt.show()

if __name__ == "__main__":
    main()