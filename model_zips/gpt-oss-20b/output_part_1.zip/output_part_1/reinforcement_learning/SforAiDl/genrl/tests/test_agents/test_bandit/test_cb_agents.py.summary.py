import os
import shutil
import sys
import tempfile
import unittest

from genrl.bandits import CovertypeDataBandit, BernoulliMAB
from genrl.trainers import DCBTrainer
from genrl.agents import (
    LinearPosteriorAgent,
    NeuralGreedyAgent,
    NeuralLinearPosteriorAgent,
    MultiKernelAgent,
    DQNAgent,
    PGAgent,
)

def write_data(file_path: str, data: str) -> None:
    """Write the given data string to the specified file."""
    with open(file_path, "w") as f:
        f.write(data)


class TestAgentTraining(unittest.TestCase):
    """Test framework for evaluating GenRL agents on bandit environments."""

    def _test_fn(self, agent_cls):
        # Setup temporary dataset for CovertypeDataBandit
        with tempfile.TemporaryDirectory() as tmp_dir:
            data_file = os.path.join(tmp_dir, "covtype.data")
            sample_data = (
                "1 2 3 4 5\n"
                "6 7 8 9 10\n"
                "11 12 13 14 15\n"
                "16 17 18 19 20\n"
                "21 22 23 24 25\n"
            )
            write_data(data_file, sample_data)

            # Create CovertypeDataBandit and delete the data file
            covertype_bandit = CovertypeDataBandit(data_file)
            os.remove(data_file)

            # Create BernoulliMAB
            bernoulli_bandit = BernoulliMAB(num_bandits=10, num_arms=10)

            for bandit in (covertype_bandit, bernoulli_bandit):
                # Instantiate the agent with default parameters
                agent = agent_cls()
                # Initialize trainer with stdout logger
                trainer = DCBTrainer(
                    agent=agent,
                    bandit=bandit,
                    logger=sys.stdout,
                )
                # Train for 10 timesteps with specified parameters
                trainer.train(
                    total_timesteps=10,
                    update_interval=2,
                    update_after=5,
                    batch_size=2,
                )

        # Cleanup: remove logs directory if it exists
        logs_path = "./logs"
        if os.path.isdir(logs_path):
            shutil.rmtree(logs_path, ignore_errors=True)

    def test_linear_posterior_agent(self):
        self._test_fn(LinearPosteriorAgent)

    def test_neural_greedy_agent(self):
        self._test_fn(NeuralGreedyAgent)

    def test_neural_linear_posterior_agent(self):
        self._test_fn(NeuralLinearPosteriorAgent)

    def test_multi_kernel_agent(self):
        self._test_fn(MultiKernelAgent)

    def test_dqn_agent(self):
        self._test_fn(DQNAgent)

    def test_pg_agent(self):
        self._test_fn(PGAgent)


if __name__ == "__main__":
    unittest.main()
