import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models


def flatten(x: torch.Tensor) -> torch.Tensor:
    return x.reshape(x.size(0), -1)


def off_diagonal(x: torch.Tensor) -> torch.Tensor:
    n = x.size(0)
    mask = ~torch.eye(n, dtype=torch.bool, device=x.device)
    return x[mask]


class NetWrapper(nn.Module):
    def __init__(self, backbone: nn.Module, latent_id):
        super().__init__()
        self.backbone = backbone
        self.latent_id = latent_id
        self._feature = None
        self._layer = self._find_layer()
        self._register_hook()

    def _find_layer(self):
        if isinstance(self.latent_id, str):
            for name, module in self.backbone.named_modules():
                if name == self.latent_id:
                    return module
        elif isinstance(self.latent_id, int):
            modules = list(self.backbone.modules())
            return modules[self.latent_id]
        raise ValueError(f"latent_id {self.latent_id} not found in backbone")

    def _hook(self, module, input, output):
        self._feature = output.detach()

    def _register_hook(self):
        self._layer.register_forward_hook(self._hook)

    def get_representation(self, x: torch.Tensor) -> torch.Tensor:
        _ = self.backbone(x)
        return self._feature

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.get_representation(x)


class BarlowTwins(nn.Module):
    def __init__(
        self,
        backbone: nn.Module,
        latent_id,
        projection_sizes: list[int],
        lambd: float = 0.005,
        scale_factor: float = 1.0,
    ):
        super().__init__()
        self.backbone = NetWrapper(backbone, latent_id)
        self.lambd = lambd
        self.scale_factor = scale_factor

        # Determine feature dimension by a dummy forward pass
        dummy = torch.randn(1, 3, 224, 224)
        feat = self.backbone.get_representation(dummy)
        feature_dim = flatten(feat).size(1)

        layers = []
        in_dim = feature_dim
        for out_dim in projection_sizes:
            layers.append(nn.Linear(in_dim, out_dim))
            layers.append(nn.BatchNorm1d(out_dim))
            layers.append(nn.ReLU(inplace=True))
            in_dim = out_dim
        layers.pop()  # remove the last ReLU
        self.projector = nn.Sequential(*layers)

        self.norm = nn.BatchNorm1d(projection_sizes[-1])

    def _process(self, x: torch.Tensor) -> torch.Tensor:
        rep = self.backbone(x)
        rep = flatten(rep)
        out = self.projector(rep)
        out = self.norm(out)
        return out

    def forward(self, y1: torch.Tensor, y2: torch.Tensor) -> torch.Tensor:
        z1 = self._process(y1)
        z2 = self._process(y2)

        c = torch.mm(z1.T, z2) / z1.size(0)

        on_diag = torch.diagonal(c).add_(-1).pow_(2).sum()
        off_diag = off_diagonal(c).pow_(2).sum()

        loss = self.scale_factor * (on_diag + self.lambd * off_diag)
        return loss


if __name__ == "__main__":
    backbone = models.resnet18(weights=None, zero_init_residual=True)
    projection_sizes = [512, 512, 512, 512]
    model = BarlowTwins(
        backbone,
        latent_id="avgpool",
        projection_sizes=projection_sizes,
        lambd=0.005,
        scale_factor=1.0,
    )

    y1 = torch.randn(2, 3, 224, 224)
    y2 = torch.randn(2, 3, 224, 224)

    loss = model(y1, y2)
    print("Barlow Twins loss:", loss.item())
