import abc
import numpy as np
import collections
import random

# --- Base Evolution Strategy ---
class BaseES(abc.ABC):
    @abc.abstractmethod
    def ask(self):
        """Sample candidate solutions."""
        pass

    @abc.abstractmethod
    def tell(self, solutions, values):
        """Update parameters based on evaluations."""
        pass

    @abc.abstractmethod
    def result(self):
        """Return optimization results."""
        pass

# --- CMA-ES Implementation ---
try:
    import cma
except ImportError:
    cma = None  # CMA library not available; CMAES will raise if used

class CMAES(BaseES):
    def __init__(self, x0, sigma0, opts=None):
        if cma is None:
            raise RuntimeError("cma library is required for CMAES.")
        self.es = cma.CMAEvolutionStrategy(x0, sigma0, opts or {})

    def ask(self):
        return [x.copy() for x in self.es.ask()]

    def tell(self, solutions, values):
        self.es.tell(solutions, values)

    def result(self):
        return self.es.result

# --- Linear Schedule for Noise ---
class LinearSchedule:
    def __init__(self, start, end, steps):
        self.start = start
        self.end = end
        self.steps = steps

    def get(self, step):
        if step >= self.steps:
            return self.end
        if self.steps == 0:
            return self.end
        return self.start + (self.end - self.start) * (step / self.steps)

# --- CEM Implementation ---
Result = collections.namedtuple(
    "Result",
    [
        "xbest",
        "fbest",
        "iterations",
        "xfavorite",
        "stds",
        "evals_best",
        "evaluations",
    ],
)

class CEM(BaseES):
    def __init__(self, x0, sigma0, opts=None):
        opts = opts or {}
        self.population_size = int(opts.get("population_size", 50))
        elite_ratio = float(opts.get("elite_ratio", 0.2))
        self.elite_size = max(1, int(self.population_size * elite_ratio))
        seed = opts.get("seed")
        if seed is not None:
            np.random.seed(seed)
            random.seed(seed)

        self.x = np.asarray(x0, dtype=float)
        self.sigma = float(sigma0)

        self.noise_start = float(opts.get("noise_start", 0.0))
        self.noise_end = float(opts.get("noise_end", 0.0))
        self.noise_steps = int(opts.get("noise_steps", 0))
        self.noise_schedule = LinearSchedule(
            self.noise_start, self.noise_end, self.noise_steps
        )

        self.iteration = 0
        self.xbest = None
        self.fbest = None

    def ask(self):
        noise_factor = self.noise_schedule.get(self.iteration)
        adjusted_sigma = self.sigma * (1.0 + noise_factor)
        samples = np.random.randn(self.population_size, self.x.size) * adjusted_sigma
        samples += self.x
        return [sample.copy() for sample in samples]

    def tell(self, solutions, values):
        sol_arr = np.asarray(solutions, dtype=float)
        val_arr = np.asarray(values, dtype=float)

        elite_indices = np.argsort(val_arr)[: self.elite_size]
        elite_sols = sol_arr[elite_indices]
        elite_vals = val_arr[elite_indices]

        self.x = elite_sols.mean(axis=0)
        self.sigma = elite_sols.std(ddof=1)

        # Update best found solution
        idx_best = elite_indices[0]
        if (self.fbest is None) or (val_arr[idx_best] < self.fbest):
            self.xbest = sol_arr[idx_best].copy()
            self.fbest = val_arr[idx_best]

        self.iteration += 1

    def result(self):
        return Result(
            xbest=self.xbest,
            fbest=self.fbest,
            iterations=self.iteration,
            xfavorite=self.x.copy(),
            stds=self.sigma,
            evals_best=None,
            evaluations=None,
        )
