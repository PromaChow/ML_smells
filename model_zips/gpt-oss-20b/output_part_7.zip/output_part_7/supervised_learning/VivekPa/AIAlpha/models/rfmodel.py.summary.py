import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier, BaggingClassifier
from sklearn.metrics import log_loss


class RFModel:
    def __init__(self, input_shape):
        self.input_shape = input_shape
        self.model = None

    def make_model(self, n_estimators: int, verbose: int = 0):
        base = RandomForestClassifier(
            n_estimators=1,
            criterion="entropy",
            bootstrap=False,
            class_weight="balanced_subsample",
        )
        self.model = BaggingClassifier(
            base_estimator=base,
            n_estimators=n_estimators,
            max_features=1.0,
            verbose=verbose,
        )

    def train_model(self, x, y, sample_weights=None):
        if self.model is None:
            raise RuntimeError("Model has not been created. Call make_model first.")
        self.model.fit(x, y, sample_weight=sample_weights)

    def test_model(self, x, y):
        if self.model is None:
            raise RuntimeError("Model has not been created. Call make_model first.")

        # Prepare true labels
        label_map = {1: "up", -1: "down", 0: "no_ch"}
        y_labels = y["y_values"].map(label_map)
        y_true = pd.get_dummies(y_labels)
        y_true.columns = ["up", "down", "no_ch"]  # Ensure consistent order

        # Baseline prediction: all no_ch
        base_case = pd.DataFrame(
            0,
            index=y_true.index,
            columns=y_true.columns,
        )
        base_case["no_ch"] = 1

        # Predict probabilities
        y_pred = self.model.predict_proba(x)

        # Compute log loss
        model_loss = log_loss(
            y_true.values,
            y_pred,
            labels=["up", "down", "no_ch"],
            normalize=True,
        )
        baseline_loss = log_loss(
            y_true.values,
            base_case.values,
            labels=["up", "down", "no_ch"],
            normalize=True,
        )

        print(
            f"Model Log Loss: {model_loss:.4f}, Baseline Log Loss: {baseline_loss:.4f}"
        )