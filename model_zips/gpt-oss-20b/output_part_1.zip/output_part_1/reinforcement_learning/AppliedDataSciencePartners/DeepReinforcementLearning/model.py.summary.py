import os
import json
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras import layers, models, optimizers, losses

# Configuration module
class config:
    MOMENTUM = 0.9

# Custom loss for policy head
def softmax_cross_entropy_with_logits(y_true, y_pred):
    return tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(labels=y_true, logits=y_pred))

# Generic model functionality
class Gen_Model:
    def __init__(self, input_dim, output_dim, reg_strength=0.0, learning_rate=0.01, hidden_layers=None):
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.reg_strength = reg_strength
        self.learning_rate = learning_rate
        self.hidden_layers = hidden_layers if hidden_layers else []
        self.version = 1
        self._build_model()

    def _build_model(self):
        raise NotImplementedError("Subclasses should implement this method.")

    def convertToModelInput(self, state):
        return np.reshape(state, self.input_dim)

    def fit(self, *args, **kwargs):
        return self.model.fit(*args, **kwargs)

    def predict(self, *args, **kwargs):
        return self.model.predict(*args, **kwargs)

    def write(self, directory='model_files'):
        if not os.path.exists(directory):
            os.makedirs(directory)
        filename = os.path.join(directory, f"{self.__class__.__name__}_v{self.version}.h5")
        self.model.save(filename)
        meta = {'version': self.version}
        with open(os.path.join(directory, f"{self.__class__.__name__}_meta.json"), 'w') as f:
            json.dump(meta, f)

    def read(self, directory='model_files'):
        meta_path = os.path.join(directory, f"{self.__class__.__name__}_meta.json")
        if not os.path.exists(meta_path):
            raise FileNotFoundError("Metadata file not found.")
        with open(meta_path, 'r') as f:
            meta = json.load(f)
        self.version = meta.get('version', 1)
        filename = os.path.join(directory, f"{self.__class__.__name__}_v{self.version}.h5")
        if not os.path.exists(filename):
            raise FileNotFoundError(f"Model file {filename} not found.")
        self.model = models.load_model(filename, custom_objects={'softmax_cross_entropy_with_logits': softmax_cross_entropy_with_logits})

    def printWeightAverages(self):
        for layer in self.model.layers:
            if hasattr(layer, 'weights'):
                for idx, weight in enumerate(layer.weights):
                    w = weight.numpy()
                    print(f"Layer {layer.name} weight {idx}: mean={w.mean():.4f}, std={w.std():.4f}, min={w.min():.4f}, max={w.max():.4f}")

    def viewLayers(self):
        for layer in self.model.layers:
            if isinstance(layer, layers.Conv2D):
                w = layer.get_weights()[0]
                plt.figure()
                plt.title(f"Weights distribution of {layer.name}")
                plt.hist(w.ravel(), bins=50, color='blue', alpha=0.7)
                plt.xlabel('Weight value')
                plt.ylabel('Frequency')
                plt.show()

# Residual CNN implementation
class Residual_CNN(Gen_Model):
    def _build_model(self):
        inputs = layers.Input(shape=self.input_dim)
        x = inputs
        # First conv layer
        conv_cfg = self.hidden_layers[0]
        conv = layers.Conv2D(conv_cfg['filters'], conv_cfg['kernel_size'], padding='same',
                             kernel_regularizer=losses.l2(self.reg_strength))(x)
        conv = layers.BatchNormalization()(conv)
        conv = layers.LeakyReLU(alpha=0.1)(conv)
        residual = conv
        # Residual blocks
        for cfg in self.hidden_layers[1:]:
            conv = layers.Conv2D(cfg['filters'], cfg['kernel_size'], padding='same',
                                 kernel_regularizer=losses.l2(self.reg_strength))(residual)
            conv = layers.BatchNormalization()(conv)
            conv = layers.LeakyReLU(alpha=0.1)(conv)
            residual = layers.add([residual, conv])
            residual = layers.BatchNormalization()(residual)
            residual = layers.LeakyReLU(alpha=0.1)(residual)
        # Value head
        val = layers.Conv2D(1, (1, 1), padding='same',
                            kernel_regularizer=losses.l2(self.reg_strength))(residual)
        val = layers.BatchNormalization()(val)
        val = layers.Flatten()(val)
        val = layers.Dense(20, activation='relu',
                           kernel_regularizer=losses.l2(self.reg_strength))(val)
        val = layers.Dense(1, activation='tanh',
                           kernel_regularizer=losses.l2(self.reg_strength))(val)
        # Policy head
        pol = layers.Conv2D(2, (1, 1), padding='same',
                            kernel_regularizer=losses.l2(self.reg_strength))(residual)
        pol = layers.BatchNormalization()(pol)
        pol = layers.Flatten()(pol)
        pol = layers.Dense(self.output_dim,
                           kernel_regularizer=losses.l2(self.reg_strength))(pol)
        self.model = models.Model(inputs=inputs, outputs=[val, pol])
        optimizer = optimizers.SGD(learning_rate=self.learning_rate, momentum=config.MOMENTUM)
        self.model.compile(optimizer=optimizer,
                           loss={'dense': 'mse', 'dense_1': softmax_cross_entropy_with_logits},
                           loss_weights={'dense': 0.5, 'dense_1': 0.5})
        self.model.summary()
```