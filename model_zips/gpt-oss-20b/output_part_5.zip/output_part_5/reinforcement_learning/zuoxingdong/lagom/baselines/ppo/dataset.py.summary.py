import numpy as np
import torch
from torch.utils.data import Dataset

class TrajectoryDataset(Dataset):
    def __init__(self, D, logprobs, entropies, Vs, Qs, As):
        """
        D: list of trajectories. Each trajectory is expected to be a dict or an object
           with attributes `observations` (np.ndarray), `actions` (np.ndarray), and `T` (int).
        logprobs, entropies, Vs, Qs, As: 1-D numpy arrays with length equal to the total
           number of samples across all trajectories.
        """
        # Compute total number of samples
        self.total_samples = sum(traj['T'] if isinstance(traj, dict) else getattr(traj, 'T')
                                 for traj in D)

        # Concatenate observations[:-1] from each trajectory
        obs_parts = []
        for traj in D:
            obs = traj['observations'] if isinstance(traj, dict) else getattr(traj, 'observations')
            obs_parts.append(obs[:-1])
        self.observations = np.concatenate(obs_parts, axis=0)

        # Concatenate actions from each trajectory
        act_parts = []
        for traj in D:
            act = traj['actions'] if isinstance(traj, dict) else getattr(traj, 'actions')
            act_parts.append(act)
        self.actions = np.concatenate(act_parts, axis=0)

        # Store policy-related arrays
        self.logprobs = np.asarray(logprobs)
        self.entropies = np.asarray(entropies)
        self.Vs = np.asarray(Vs)
        self.Qs = np.asarray(Qs)
        self.As = np.asarray(As)

        # Validation checks
        if self.observations.shape[0] != self.total_samples:
            raise ValueError(f"Number of observations ({self.observations.shape[0]}) "
                             f"does not match total samples ({self.total_samples}).")
        if self.actions.shape[0] != self.total_samples:
            raise ValueError(f"Number of actions ({self.actions.shape[0]}) "
                             f"does not match total samples ({self.total_samples}).")
        for name, arr in [('logprobs', self.logprobs),
                          ('entropies', self.entropies),
                          ('Vs', self.Vs),
                          ('Qs', self.Qs),
                          ('As', self.As)]:
            if arr.shape[0] != self.total_samples:
                raise ValueError(f"Array '{name}' length ({arr.shape[0]}) does not match total samples ({self.total_samples}).")

    def __len__(self):
        return self.total_samples

    def __getitem__(self, idx):
        observation = torch.tensor(self.observations[idx], dtype=torch.float32)
        action = torch.tensor(self.actions[idx], dtype=torch.float32)
        logprob = torch.tensor(self.logprobs[idx], dtype=torch.float32)
        entropy = torch.tensor(self.entropies[idx], dtype=torch.float32)
        V = torch.tensor(self.Vs[idx], dtype=torch.float32)
        Q = torch.tensor(self.Qs[idx], dtype=torch.float32)
        A = torch.tensor(self.As[idx], dtype=torch.float32)
        return observation, action, logprob, entropy, V, Q, A
