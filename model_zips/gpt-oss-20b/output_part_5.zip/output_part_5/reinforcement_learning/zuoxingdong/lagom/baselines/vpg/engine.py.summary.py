import time
from collections import defaultdict

def describe(values):
    if not values:
        return "[]"
    return f"[min={min(values):.2f}, mean={sum(values)/len(values):.2f}, max={max(values):.2f}]"

class Logger:
    def __init__(self):
        self.records = []

    def log(self, **kwargs):
        self.records.append(kwargs)
        print(kwargs)

class Engine:
    def __init__(self, agent, runner, env, config):
        self.agent = agent
        self.runner = runner
        self.env = env
        self.config = config
        self.logger = Logger()

    def train_iteration(self, n):
        # 1. Training Initialization
        self.agent.train()
        start_time = time.perf_counter()

        # 2. Data Collection
        D = self.runner(self.agent, self.env, self.config['train.timestep_per_iter'])

        # 3. Agent Learning
        out_agent = self.agent.learn(D)

        # 4. Logging Metrics
        elapsed = time.perf_counter() - start_time
        log_dict = {
            "iteration": n + 1,
            "elapsed_time_s": round(elapsed, 1),
        }
        log_dict.update(out_agent)

        # Trajectory statistics
        num_traj = len(D)
        total_timesteps = sum(len(traj.get("steps", [])) for traj in D)
        log_dict.update({
            "num_trajectories": num_traj,
            "total_timesteps": total_timesteps,
            "trained_timesteps": self.agent.total_timestep,
        })

        # Return metrics
        returns = [sum(traj.get("rewards", [])) for traj in D]
        log_dict["return_summary"] = describe(returns)

        # Online Return/Horizon
        online_return = None
        online_horizon = None
        if D:
            last_traj = D[-1]
            online_return = last_traj.get("return")
            online_horizon = last_traj.get("horizon")
        if online_return is not None and online_horizon is not None:
            log_dict["online_return"] = online_return
            log_dict["online_horizon"] = online_horizon

        # Running Return/Horizon from env queues
        if hasattr(self.env, "return_queue") and hasattr(self.env, "horizon_queue"):
            running_returns = list(self.env.return_queue)
            running_horizons = list(self.env.horizon_queue)
            log_dict["running_return_summary"] = describe(running_returns)
            log_dict["running_horizon_summary"] = describe(running_horizons)

        self.logger.log(**log_dict)

    def eval(self):
        pass

# Example minimal agent, runner, and env implementations for context
class DummyAgent:
    def __init__(self):
        self.total_timestep = 0

    def train(self):
        pass

    def learn(self, D):
        self.total_timestep += sum(len(traj.get("steps", [])) for traj in D)
        return {"loss": 0.01, "accuracy": 0.95}

class DummyEnv:
    def __init__(self):
        self.return_queue = []
        self.horizon_queue = []

def dummy_runner(agent, env, timesteps):
    traj = {
        "steps": list(range(timesteps)),
        "rewards": [1.0] * timesteps,
        "return": timesteps * 1.0,
        "horizon": timesteps,
    }
    return [traj] * (timesteps // 10)

# Usage example
if __name__ == "__main__":
    config = {"train.timestep_per_iter": 100}
    engine = Engine(DummyAgent(), dummy_runner, DummyEnv(), config)
    for i in range(3):
        engine.train_iteration(i)