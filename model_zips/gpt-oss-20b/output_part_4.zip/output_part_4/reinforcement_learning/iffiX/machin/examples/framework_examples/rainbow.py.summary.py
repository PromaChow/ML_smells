import gym
import torch
import torch.nn as nn
import torch.optim as optim

from machin.algorithms.rainbow import Rainbow
from machin.logging import Logger

# Configuration
env_name = "CartPole-v0"
env = gym.make(env_name)
obs_dim = env.observation_space.shape[0]
act_dim = env.action_space.n

value_min = 0.0
value_max = 40.0
reward_future_steps = 20
max_episodes = 1000
max_steps = 200
solved_reward = 190.0
smooth_weight = 0.9
solved_consecutive = 5

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
logger = Logger("rainbow_cartpole")

# Q-Network
class QNet(nn.Module):
    def __init__(self, obs_dim, act_dim, atom_num=51, value_min=0.0, value_max=40.0):
        super(QNet, self).__init__()
        self.atom_num = atom_num
        self.value_min = value_min
        self.value_max = value_max
        self.delta_z = (value_max - value_min) / (atom_num - 1)
        self.fc1 = nn.Linear(obs_dim, 128)
        self.fc2 = nn.Linear(128, 128)
        self.fc3 = nn.Linear(128, act_dim * atom_num)
        self.softmax = nn.Softmax(dim=1)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        logits = self.fc3(x)
        logits = logits.view(-1, self.atom_num * act_dim)
        probs = self.softmax(logits)
        probs = probs.view(-1, act_dim, self.atom_num)
        return probs

q_net = QNet(obs_dim, act_dim, atom_num=51, value_min=value_min, value_max=value_max).to(device)
q_net_t = QNet(obs_dim, act_dim, atom_num=51, value_min=value_min, value_max=value_max).to(device)

optimizer = optim.Adam(list(q_net.parameters()) + list(q_net_t.parameters()), lr=1e-4)

rainbow = Rainbow(
    q_network=q_net,
    q_network_target=q_net_t,
    optimizer=optimizer,
    replay_buffer_size=100000,
    batch_size=32,
    gamma=0.99,
    n_step=reward_future_steps,
    value_min=value_min,
    value_max=value_max,
    atom_num=51,
    update_target_every=1000,
    device=device
)

smoothed_reward = 0.0
consecutive_solved = 0

for episode in range(1, max_episodes + 1):
    state = env.reset()
    total_reward = 0.0
    episode_experiences = []

    for step in range(1, max_steps + 1):
        state_tensor = torch.FloatTensor(state).unsqueeze(0).to(device)
        with torch.no_grad():
            action_probs = rainbow.q_network(state_tensor)
        action = action_probs.argmax().item()
        next_state, reward, done, _ = env.step(action)
        total_reward += reward

        exp = {
            "state": state,
            "action": action,
            "reward": reward,
            "next_state": next_state,
            "done": done
        }
        episode_experiences.append(exp)

        if done:
            break
        state = next_state

    rainbow.replay_buffer.add_batch(episode_experiences)

    if episode > 100:
        for _ in range(len(episode_experiences)):
            rainbow.update()

    smoothed_reward = smooth_weight * smoothed_reward + (1 - smooth_weight) * total_reward
    logger.info(f"Episode {episode} | Total Reward: {total_reward:.2f} | Smoothed Reward: {smoothed_reward:.2f}")

    if smoothed_reward >= solved_reward:
        consecutive_solved += 1
    else:
        consecutive_solved = 0

    if consecutive_solved >= solved_consecutive:
        logger.info(f"Environment solved in {episode} episodes.")
        break

env.close()