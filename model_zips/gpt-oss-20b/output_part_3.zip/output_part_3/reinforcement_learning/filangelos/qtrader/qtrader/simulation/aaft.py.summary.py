import numpy as np
import pandas as pd

def AAFT(df, random_state=None, random=None):
    if random_state is not None:
        np.random.seed(random_state)

    random = random or np.random.uniform

    ts = df.values
    if ts.ndim == 1:
        ts = ts.reshape(-1, 1)

    _ts = ts.copy()
    n_samples = _ts.shape[0]

    if n_samples % 2 == 1:
        _ts = _ts[1:, :]
        n_samples -= 1

    ts_gen = np.empty_like(_ts)

    for col_idx in range(_ts.shape[1]):
        signal = _ts[:, col_idx]
        F_tsi = np.fft.rfft(signal)
        phases = np.exp(random(0, np.pi, len(F_tsi)) * 1j)
        F_tsi_mod = F_tsi * phases
        synthetic = np.fft.irfft(F_tsi_mod, n=len(signal))
        ts_gen[:, col_idx] = synthetic

    df_gen = pd.DataFrame(ts_gen, columns=df.columns)
    if n_samples < df.shape[0]:
        df_gen.index = df.index[1:]
    else:
        df_gen.index = df.index

    return df_gen

# Example usage:
# df = pd.DataFrame({'A': np.sin(np.linspace(0, 2*np.pi, 100)),
#                    'B': np.cos(np.linspace(0, 2*np.pi, 100))})
# synthetic_df = AAFT(df, random_state=42)