import pygame
import random
import math

# Constants
SCREEN_WIDTH = 64
SCREEN_HEIGHT = 64
WHITE = (255, 255, 255)
PLAYER_COLOR = (0, 120, 215)
GOOD_COLOR = (0, 255, 0)
BAD_COLOR = (255, 0, 0)
PLAYER_SPEED = 80  # pixels per second
GOOD_SPEED = 40
BAD_SPEED = 60
PLAYER_RADIUS = 3
CREEP_RADIUS = 5
BAD_OUTER_RADIUS = 8

class PuckSprite(pygame.sprite.Sprite):
    def __init__(self, color, radius):
        super().__init__()
        self.image = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
        pygame.draw.circle(self.image, color, (radius, radius), radius)
        self.rect = self.image.get_rect()
        self.radius = radius

class Player(PuckSprite):
    def __init__(self, pos):
        super().__init__(PLAYER_COLOR, PLAYER_RADIUS)
        self.rect.center = pos
        self.dx = 0
        self.dy = 0

    def update(self, dt):
        self.rect.x += self.dx * dt
        self.rect.y += self.dy * dt
        # Keep inside screen
        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.right > SCREEN_WIDTH:
            self.rect.right = SCREEN_WIDTH
        if self.rect.top < 0:
            self.rect.top = 0
        if self.rect.bottom > SCREEN_HEIGHT:
            self.rect.bottom = SCREEN_HEIGHT

class PuckCreep(PuckSprite):
    def __init__(self, color, radius, speed):
        super().__init__(color, radius)
        self.speed = speed
        self.dx = 0
        self.dy = 0

    def update(self, dt):
        self.rect.x += self.dx * dt
        self.rect.y += self.dy * dt
        # Keep inside screen
        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.right > SCREEN_WIDTH:
            self.rect.right = SCREEN_WIDTH
        if self.rect.top < 0:
            self.rect.top = 0
        if self.rect.bottom > SCREEN_HEIGHT:
            self.rect.bottom = SCREEN_HEIGHT

class GoodCreep(PuckCreep):
    def __init__(self):
        super().__init__(GOOD_COLOR, CREEP_RADIUS, GOOD_SPEED)
        self.randomize_position()
        self.randomize_velocity()

    def randomize_position(self):
        x = random.randint(self.radius, SCREEN_WIDTH - self.radius)
        y = random.randint(self.radius, SCREEN_HEIGHT - self.radius)
        self.rect.center = (x, y)

    def randomize_velocity(self):
        angle = random.uniform(0, 2 * math.pi)
        self.dx = self.speed * math.cos(angle)
        self.dy = self.speed * math.sin(angle)

    def update(self, dt):
        super().update(dt)
        # Change direction randomly
        if random.random() < 0.01:
            self.randomize_velocity()

class BadCreep(PuckCreep):
    def __init__(self):
        super().__init__(BAD_COLOR, BAD_OUTER_RADIUS, BAD_SPEED)
        self.rect.center = (SCREEN_WIDTH - self.radius, SCREEN_HEIGHT - self.radius)

    def move_toward(self, target_pos):
        dx = target_pos[0] - self.rect.centerx
        dy = target_pos[1] - self.rect.centery
        dist = math.hypot(dx, dy)
        if dist == 0:
            self.dx, self.dy = 0, 0
        else:
            self.dx = self.speed * dx / dist
            self.dy = self.speed * dy / dist

class PuckWorld:
    def __init__(self, width=SCREEN_WIDTH, height=SCREEN_HEIGHT):
        pygame.init()
        self.screen = pygame.display.set_mode((width, height))
        pygame.display.set_caption("PuckWorld")
        self.clock = pygame.time.Clock()
        self.width = width
        self.height = height
        self.sprite_group = pygame.sprite.Group()
        self.score = 0
        self.ticks = 0
        self.lives = 3
        self.init()

    def init(self):
        self.player = Player((self.width // 2, self.height // 2))
        self.good_creep = GoodCreep()
        self.bad_creep = BadCreep()
        self.sprite_group.empty()
        self.sprite_group.add(self.player, self.good_creep, self.bad_creep)
        self.score = 0
        self.ticks = 0
        self.lives = 3

    def step(self):
        dt = self.clock.tick(60) / 1000.0  # seconds
        self.ticks += 1

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False

        keys = pygame.key.get_pressed()
        self.player.dx = self.player.dy = 0
        if keys[pygame.K_w]:
            self.player.dy = -PLAYER_SPEED
        if keys[pygame.K_s]:
            self.player.dy = PLAYER_SPEED
        if keys[pygame.K_a]:
            self.player.dx = -PLAYER_SPEED
        if keys[pygame.K_d]:
            self.player.dx = PLAYER_SPEED

        # Update entities
        self.player.update(dt)
        self.good_creep.update(dt)
        self.bad_creep.move_toward(self.player.rect.center)
        self.bad_creep.update(dt)

        # Rewards (not used further but calculated)
        dist_to_good = math.hypot(
            self.player.rect.centerx - self.good_creep.rect.centerx,
            self.player.rect.centery - self.good_creep.rect.centery
        )
        reward = -dist_to_good / 10.0

        dist_to_bad = math.hypot(
            self.player.rect.centerx - self.bad_creep.rect.centerx,
            self.player.rect.centery - self.bad_creep.rect.centery
        )
        if dist_to_bad < self.bad_creep.radius:
            reward -= 5.0

        # Respawn good creep every 500 ticks
        if self.ticks % 500 == 0:
            self.good_creep.randomize_position()
            self.good_creep.randomize_velocity()

        # Rendering
        self.screen.fill(WHITE)
        self.sprite_group.draw(self.screen)
        pygame.display.flip()

        return True

    def getGameState(self):
        return {
            "player": {
                "pos": self.player.rect.center,
                "vel": (self.player.dx, self.player.dy)
            },
            "good_creep": {
                "pos": self.good_creep.rect.center,
                "vel": (self.good_creep.dx, self.good_creep.dy)
            },
            "bad_creep": {
                "pos": self.bad_creep.rect.center,
                "vel": (self.bad_creep.dx, self.bad_creep.dy)
            }
        }

    def game_over(self):
        return False

if __name__ == "__main__":
    world = PuckWorld()
    running = True
    while running:
        running = world.step()
    pygame.quit()
