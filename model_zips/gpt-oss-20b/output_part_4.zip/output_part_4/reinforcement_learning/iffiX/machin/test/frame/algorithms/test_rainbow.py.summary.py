import os
import random
import shutil
import tempfile
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path

import gymnasium as gym
import numpy as np
import pytest
import torch
import torch.nn as nn
import torch.optim as optim

# ---------- Simple Q‑Network ----------
class QNet(nn.Module):
    def __init__(self, obs_dim: int, action_dim: int):
        super().__init__()
        self.fc = nn.Sequential(
            nn.Linear(obs_dim, 64),
            nn.ReLU(),
            nn.Linear(64, action_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.fc(x)


# ---------- Simple Replay Buffer ----------
class ReplayBuffer:
    def __init__(self, capacity: int):
        self.capacity = capacity
        self.buffer = deque(maxlen=capacity)

    def add(self, state, action, reward, next_state, done):
        self.buffer.append((state, action, reward, next_state, done))

    def sample(self, batch_size: int):
        batch = random.sample(self.buffer, batch_size)
        states, actions, rewards, next_states, dones = zip(*batch)
        return (
            torch.tensor(states, dtype=torch.float32),
            torch.tensor(actions, dtype=torch.long),
            torch.tensor(rewards, dtype=torch.float32),
            torch.tensor(next_states, dtype=torch.float32),
            torch.tensor(dones, dtype=torch.float32),
        )

    def __len__(self):
        return len(self.buffer)


# ---------- RAINBOW Algorithm ----------
@dataclass
class RAINBOW:
    env: gym.Env
    q_net: nn.Module
    q_net_t: nn.Module
    replay_buffer: ReplayBuffer
    value_range: tuple = (0.0, 40.0)
    optimizer: optim.Optimizer = field(default_factory=lambda: None)
    device: str = "cpu"

    def act_discrete(self, state: np.ndarray) -> int:
        state_t = torch.tensor(state, dtype=torch.float32, device=self.device).unsqueeze(0)
        with torch.no_grad():
            q_values = self.q_net(state_t)
        return int(torch.argmax(q_values, dim=1).item())

    def act_discrete_with_noise(self, state: np.ndarray, noise_std: float = 0.1) -> int:
        state_t = torch.tensor(state, dtype=torch.float32, device=self.device).unsqueeze(0)
        with torch.no_grad():
            q_values = self.q_net(state_t) + torch.randn_like(state_t, device=self.device) * noise_std
        return int(torch.argmax(q_values, dim=1).item())

    def store_episode(self, state, action, reward, next_state, done):
        self.replay_buffer.add(state, action, reward, next_state, done)

    def update(self, num_value_updates: int = 1, num_target_updates: int = 0, batch_size: int = 32):
        if len(self.replay_buffer) < batch_size:
            return
        for _ in range(num_value_updates):
            states, actions, rewards, next_states, dones = self.replay_buffer.sample(batch_size)
            q_values = self.q_net(states).gather(1, actions.unsqueeze(1)).squeeze(1)
            with torch.no_grad():
                next_q_values = self.q_net_t(next_states).max(1)[0]
                target = rewards + (1 - dones) * 0.99 * next_q_values
            loss = nn.functional.mse_loss(q_values, target)
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()
        for _ in range(num_target_updates):
            self.q_net_t.load_state_dict(self.q_net.state_dict())


# ---------- Fixtures ----------
@pytest.fixture
def train_config(tmp_path):
    env = gym.make("CartPole-v0")
    env = env.unwrapped
    config = {
        "env": env,
        "obs_dim": 4,
        "action_dim": 2,
        "reward_range": (0.0, 40.0),
        "future_steps": 20,
        "episodes": 1000,
        "steps_per_episode": 200,
        "replay_buffer_size": 100_000,
        "tmp_dir": tmp_path,
    }
    return config


@pytest.fixture
def rainbow(train_config):
    env = train_config["env"]
    q_net = QNet(train_config["obs_dim"], train_config["action_dim"])
    q_net_t = QNet(train_config["obs_dim"], train_config["action_dim"])
    replay_buffer = ReplayBuffer(train_config["replay_buffer_size"])
    optimizer = optim.Adam(q_net.parameters(), lr=1e-3)
    return RAINBOW(
        env=env,
        q_net=q_net,
        q_net_t=q_net_t,
        replay_buffer=replay_buffer,
        value_range=train_config["reward_range"],
        optimizer=optimizer,
        device="cpu",
    )


@pytest.fixture
def rainbow_vis(rainbow, train_config):
    tmp_dir = train_config["tmp_dir"]
    # In a real implementation, visualization would be set up here.
    rainbow.visualization_dir = tmp_dir
    return rainbow


@pytest.fixture
def rainbow_train(rainbow):
    # Force CPU device for faster testing
    rainbow.device = "cpu"
    return rainbow


# ---------- Tests ----------
def test_act(rainbow_train):
    zero_state = np.zeros(rainbow_train.env.observation_space.shape)
    act = rainbow_train.act_discrete(zero_state)
    act_noise = rainbow_train.act_discrete_with_noise(zero_state)
    assert 0 <= act < rainbow_train.env.action_space.n
    assert 0 <= act_noise < rainbow_train.env.action_space.n


def test_store_episode(rainbow_train):
    state = np.zeros(rainbow_train.env.observation_space.shape)
    next_state = np.zeros(rainbow_train.env.observation_space.shape)
    for _ in range(3):
        rainbow_train.store_episode(state, 0, 0.0, next_state, False)
    assert len(rainbow_train.replay_buffer) == 3


def test_update(rainbow_train):
    state = np.zeros(rainbow_train.env.observation_space.shape)
    next_state = np.zeros(rainbow_train.env.observation_space.shape)
    for _ in range(3):
        rainbow_train.store_episode(state, 0, 0.0, next_state, False)
    # Perform updates
    rainbow_train.update(num_value_updates=2, num_target_updates=1)
    # Repeat with updates disabled
    rainbow_train.update(num_value_updates=0, num_target_updates=0)


def test_config_init(tmp_path):
    # Create a template config
    template = {
        "env_name": "CartPole-v0",
        "obs_dim": 4,
        "action_dim": 2,
        "value_range": (0.0, 40.0),
        "replay_buffer_size": 100_000,
        "device": "cpu",
    }
    # Instantiate environment
    env = gym.make(template["env_name"]).unwrapped
    # Build networks
    q_net = QNet(template["obs_dim"], template["action_dim"])
    q_net_t = QNet(template["obs_dim"], template["action_dim"])
    replay_buffer = ReplayBuffer(template["replay_buffer_size"])
    optimizer = optim.Adam(q_net.parameters(), lr=1e-3)
    rainbow = RAINBOW(
        env=env,
        q_net=q_net,
        q_net_t=q_net_t,
        replay_buffer=replay_buffer,
        value_range=template["value_range"],
        optimizer=optimizer,
        device=template["device"],
    )
    # Test storing and updating
    state = np.zeros(env.observation_space.shape)
    next_state = np.zeros(env.observation_space.shape)
    for _ in range(3):
        rainbow.store_episode(state, 0, 0.0, next_state, False)
    rainbow.update(num_value_updates=1, num_target_updates=1)


@pytest.mark.skipif(os.name != "posix", reason="Linux-only test")
def test_full_train(rainbow_train, train_config):
    env = rainbow_train.env
    env.seed(0)
    total_reward = 0.0
    reward_window = deque(maxlen=5)
    for episode in range(train_config["episodes"]):
        state, _ = env.reset()
        episode_reward = 0.0
        episode_experiences = []
        for step in range(train_config["steps_per_episode"]):
            action = rainbow_train.act_discrete_with_noise(state)
            next_state, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated
            episode_experiences.append((state, action, reward, next_state, done))
            episode_reward += reward
            if done:
                break
            state = next_state
        # Store episode
        for exp in episode_experiences:
            rainbow_train.store_episode(*exp)
        # Update after 100 episodes
        if episode >= 100:
            for _ in range(len(episode_experiences)):
                rainbow_train.update(num_value_updates=1, num_target_updates=1)
        total_reward += episode_reward
        reward_window.append(episode_reward)
        if (episode + 1) % 10 == 0:
            avg_reward = sum(reward_window) / len(reward_window)
            print(f"Episode {episode + 1}: Avg Reward={avg_reward:.2f}")
        if len(reward_window) == 5 and sum(reward_window) / 5 >= 150:
            print("Solved!")
            return
    assert False, "Solved reward not achieved after 1000 episodes"
