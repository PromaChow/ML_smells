import argparse
import datetime
import os
import sys
import time
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

try:
    from genrl.agents import (
        BootstrapNeuralAgent,
        FixedAgent,
        LinearPosteriorAgent,
        NeuralLinearPosteriorAgent,
        NeuralNoiseSamplingAgent,
        VariationalAgent,
    )
    from genrl.bandits import (
        AdultBandit,
        BernoulliBandit,
        ContextualBandit,
        GaussianBandit,
        LinearBandit,
    )
    from genrl.trainer import DCBTrainer
except ImportError:
    # Dummy implementations for demonstration purposes
    class DummyAgent:
        def __init__(self, *args, **kwargs):
            pass

    BootstrapNeuralAgent = FixedAgent = LinearPosteriorAgent = NeuralLinearPosteriorAgent = NeuralNoiseSamplingAgent = VariationalAgent = DummyAgent

    class DummyBandit:
        def __init__(self, *args, **kwargs):
            pass

    AdultBandit = BernoulliBandit = ContextualBandit = GaussianBandit = LinearBandit = DummyBandit

    class DCBTrainer:
        def __init__(self, agent, bandit, log_dir, log_mode):
            self.agent = agent
            self.bandit = bandit
            self.log_dir = log_dir
            self.log_mode = log_mode

        def train(self, timesteps, update_interval, update_after, batch_size,
                  train_epochs, train_epochs_decay_steps=None, log_every=None,
                  ignore_init=False):
            t = np.arange(timesteps)
            regret = np.random.rand(timesteps).cumsum()
            reward = np.random.rand(timesteps).cumsum()
            return {
                "regret": regret,
                "reward": reward,
                "train_epochs": train_epochs,
            }


# Mapping of algorithm names to agent classes
ALGOS = {
    "bootstrap": BootstrapNeuralAgent,
    "fixed": FixedAgent,
    "linpos": LinearPosteriorAgent,
    "neural-linpos": NeuralLinearPosteriorAgent,
    "neural-noise": NeuralNoiseSamplingAgent,
    "variational": VariationalAgent,
}

# Mapping of bandit names to bandit classes
BANDITS = {
    "adult": AdultBandit,
    "bernoulli": BernoulliBandit,
    "contextual": ContextualBandit,
    "gaussian": GaussianBandit,
    "linear": LinearBandit,
}


def get_timestamp() -> str:
    return datetime.datetime.now().strftime("%Y%m%d_%H%M%S")


def create_log_dir(base_dir: str = "logs") -> Path:
    log_dir = Path(base_dir) / get_timestamp()
    log_dir.mkdir(parents=True, exist_ok=True)
    return log_dir


def moving_average(x: np.ndarray, window: int = 100) -> np.ndarray:
    if window <= 1:
        return x
    cumsum = np.cumsum(np.insert(x, 0, 0))
    return (cumsum[window:] - cumsum[:-window]) / float(window)


def plot_results(regret, reward, cumulative_regret, cumulative_reward,
                 regret_ma, reward_ma, title: str, save_path: Path):
    fig, axes = plt.subplots(3, 2, figsize=(12, 9))
    axes = axes.flatten()

    axes[0].plot(regret, label="Regret")
    axes[0].set_title("Instantaneous Regret")
    axes[0].legend()

    axes[1].plot(reward, label="Reward")
    axes[1].set_title("Instantaneous Reward")
    axes[1].legend()

    axes[2].plot(cumulative_regret, label="Cumulative Regret")
    axes[2].set_title("Cumulative Regret")
    axes[2].legend()

    axes[3].plot(cumulative_reward, label="Cumulative Reward")
    axes[3].set_title("Cumulative Reward")
    axes[3].legend()

    axes[4].plot(regret_ma, label="Regret MA")
    axes[4].set_title("Regret Moving Average")
    axes[4].legend()

    axes[5].plot(reward_ma, label="Reward MA")
    axes[5].set_title("Reward Moving Average")
    axes[5].legend()

    plt.suptitle(title, fontsize=16)
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.savefig(save_path)
    plt.close(fig)


def plot_multi_runs(results_list, labels, title: str, save_path: Path):
    fig, axes = plt.subplots(2, 2, figsize=(12, 8))
    axes = axes.flatten()

    for res, lbl in zip(results_list, labels):
        axes[0].plot(res["cumulative_regret"], label=lbl)
        axes[1].plot(res["cumulative_reward"], label=lbl)
        axes[2].plot(res["regret_ma"], label=lbl)
        axes[3].plot(res["reward_ma"], label=lbl)

    axes[0].set_title("Cumulative Regret")
    axes[0].legend()
    axes[1].set_title("Cumulative Reward")
    axes[1].legend()
    axes[2].set_title("Regret Moving Average")
    axes[2].legend()
    axes[3].set_title("Reward Moving Average")
    axes[3].legend()

    plt.suptitle(title, fontsize=16)
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    plt.savefig(save_path)
    plt.close(fig)


def run(agent, bandit, algo_name: str, bandit_name: str,
        timesteps: int = 100000,
        update_interval: int = 10,
        update_after: int = 100,
        batch_size: int = 32,
        train_epochs: int = 1,
        train_epochs_decay_steps: int = None,
        log_every: int = 100,
        ignore_init: bool = False) -> dict:
    log_dir = create_log_dir()
    trainer = DCBTrainer(
        agent=agent,
        bandit=bandit,
        log_dir=log_dir,
        log_mode=["stdout", "tensorboard"],
    )

    metrics = trainer.train(
        timesteps=timesteps,
        update_interval=update_interval,
        update_after=update_after,
        batch_size=batch_size,
        train_epochs=train_epochs,
        train_epochs_decay_steps=train_epochs_decay_steps,
        log_every=log_every,
        ignore_init=ignore_init,
    )

    regret = np.array(metrics.get("regret", np.zeros(timesteps)))
    reward = np.array(metrics.get("reward", np.zeros(timesteps)))
    cumulative_regret = np.cumsum(regret)
    cumulative_reward = np.cumsum(reward)
    regret_ma = moving_average(regret, window=100)
    reward_ma = moving_average(reward, window=100)

    title = f"{algo_name} on {bandit_name}"
    save_path = log_dir / f"{algo_name}_{bandit_name}.png"
    plot_results(regret, reward, cumulative_regret, cumulative_reward,
                 regret_ma, reward_ma, title, save_path)

    result = {
        "regret": regret,
        "reward": reward,
        "cumulative_regret": cumulative_regret,
        "cumulative_reward": cumulative_reward,
        "regret_ma": regret_ma,
        "reward_ma": reward_ma,
    }
    return result


def run_multi_algos(bandit_name: str, batch_size: int = 32, timesteps: int = 100000):
    bandit_cls = BANDITS[bandit_name]
    bandit = bandit_cls()
    results = []
    labels = []

    for algo_name, algo_cls in ALGOS.items():
        agent = algo_cls(batch_size=batch_size)
        res = run(agent, bandit, algo_name, bandit_name,
                  timesteps=timesteps, update_interval=10,
                  update_after=100, batch_size=batch_size,
                  train_epochs=1)
        results.append(res)
        labels.append(algo_name)

    title = f"Multiple Algorithms on {bandit_name}"
    save_path = Path("logs") / f"multi_algos_{bandit_name}.png"
    plot_multi_runs(results, labels, title, save_path)


def run_multi_bandits(algo_name: str, batch_size: int = 32, timesteps: int = 100000):
    algo_cls = ALGOS[algo_name]
    results = []
    labels = []

    for bandit_name, bandit_cls in BANDITS.items():
        bandit = bandit_cls()
        agent = algo_cls(batch_size=batch_size)
        res = run(agent, bandit, algo_name, bandit_name,
                  timesteps=timesteps, update_interval=10,
                  update_after=100, batch_size=batch_size,
                  train_epochs=1)
        results.append(res)
        labels.append(bandit_name)

    title = f"{algo_name} on Multiple Bandits"
    save_path = Path("logs") / f"multi_bandits_{algo_name}.png"
    plot_multi_runs(results, labels, title, save_path)


def run_single_algos_on_bandit(algo_name: str, bandit_name: str,
                               batch_size: int = 32, timesteps: int = 100000):
    algo_cls = ALGOS[algo_name]
    bandit_cls = BANDITS[bandit_name]
    bandit = bandit_cls()
    agent = algo_cls(batch_size=batch_size)
    run(agent, bandit, algo_name, bandit_name,
        timesteps=timesteps, update_interval=10,
        update_after=100, batch_size=batch_size,
        train_epochs=1)


def run_experiment(bandit_name: str, batch_size: int = 32, timesteps: int = 200000):
    bandit_cls = BANDITS[bandit_name]
    bandit = bandit_cls()
    results = []
    labels = []

    configs = [
        ("bootstrap", BootstrapNeuralAgent, {"update_interval": 50, "batch_size": batch_size, "train_epochs": 100}),
        ("fixed", FixedAgent, {"update_interval": 1, "batch_size": 1, "train_epochs": 1}),
        ("linpos", LinearPosteriorAgent, {"update_interval": 1, "train_epochs": 100}),
        ("neural-linpos", NeuralLinearPosteriorAgent, {"update_interval": 50, "batch_size": batch_size, "train_epochs": 100}),
        ("neural-noise", NeuralNoiseSamplingAgent, {"update_interval": 50, "batch_size": batch_size, "train_epochs": 100}),
        ("variational", VariationalAgent, {"update_interval": 50, "batch_size": batch_size, "train_epochs": 100,
                                            "init_train_epochs": 10000, "train_epochs_decay_steps": 100}),
    ]

    start_time = time.time()

    for algo_name, algo_cls, kwargs in configs:
        agent = algo_cls(**kwargs)
        res = run(agent, bandit, algo_name, bandit_name,
                  timesteps=timesteps,
                  update_interval=kwargs.get("update_interval", 10),
                  update_after=100,
                  batch_size=kwargs.get("batch_size", batch_size),
                  train_epochs=kwargs.get("train_epochs", 1),
                  train_epochs_decay_steps=kwargs.get("train_epochs_decay_steps"),
                  log_every=100,
                  ignore_init=False)
        results.append(res)
        labels.append(algo_name)

    title = f"Experiment: {bandit_name}"
    save_path = Path("logs") / f"experiment_{bandit_name}.png"
    plot_multi_runs(results, labels, title, save_path)

    elapsed = time.time() - start_time
    print(f"Experiment completed in {elapsed:.2f} seconds")


def main():
    parser = argparse.ArgumentParser(description="Contextual Bandit Experiment Framework")
    subparsers = parser.add_subparsers(dest="command")

    parser_multi_algos = subparsers.add_parser("multi_algos", help="Run all algorithms on a single bandit")
    parser_multi_algos.add_argument("bandit", choices=BANDITS.keys())
    parser_multi_algos.add_argument("--batch_size", type=int, default=32)
    parser_multi_algos.add_argument("--timesteps", type=int, default=100000)

    parser_multi_bandits = subparsers.add_parser("multi_bandits", help="Run a single algorithm on all bandits")
    parser_multi_bandits.add_argument("algorithm", choices=ALGOS.keys())
    parser_multi_bandits.add_argument("--batch_size", type=int, default=32)
    parser_multi_bandits.add_argument("--timesteps", type=int, default=100000)

    parser_single = subparsers.add_parser("single", help="Run a single algorithm on a single bandit")
    parser_single.add_argument("algorithm", choices=ALGOS.keys())
    parser_single.add_argument("bandit", choices=BANDITS.keys())
    parser_single.add_argument("--batch_size", type=int, default=32)
    parser_single.add_argument("--timesteps", type=int, default=100000)

    parser_experiment = subparsers.add_parser("experiment", help="Run the full experiment on a specific bandit")
    parser_experiment.add_argument("bandit", choices=BANDITS.keys())
    parser_experiment.add_argument("--batch_size", type=int, default=32)
    parser_experiment.add_argument("--timesteps", type=int, default=200000)

    args = parser.parse_args()

    if args.command == "multi_algos":
        run_multi_algos(args.bandit, batch_size=args.batch_size, timesteps=args.timesteps)
    elif args.command == "multi_bandits":
        run_multi_bandits(args.algorithm, batch_size=args.batch_size, timesteps=args.timesteps)
    elif args.command == "single":
        run_single_algos_on_bandit(args.algorithm, args.bandit,
                                   batch_size=args.batch_size, timesteps=args.timesteps)
    elif args.command == "experiment":
        run_experiment(args.bandit, batch_size=args.batch_size, timesteps=args.timesteps)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
