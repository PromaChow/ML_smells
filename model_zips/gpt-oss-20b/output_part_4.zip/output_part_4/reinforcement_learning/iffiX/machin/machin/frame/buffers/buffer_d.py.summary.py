import threading
import torch
from typing import Any, Dict, List, Tuple, Optional


class InMemoryStorage:
    def __init__(self, max_size: int):
        self.max_size = max_size
        self.data: List[Any] = []

    def append(self, transitions: List[Any]) -> None:
        self.data.extend(transitions)
        if len(self.data) > self.max_size:
            self.data = self.data[-self.max_size:]

    def clear(self) -> None:
        self.data.clear()

    def size(self) -> int:
        return len(self.data)

    def sample(self, batch_size: int, method: str = "random_unique") -> List[Any]:
        if method == "random_unique":
            if batch_size > len(self.data):
                batch_size = len(self.data)
            indices = torch.randperm(len(self.data))[:batch_size]
            batch = [self.data[i] for i in indices]
            return batch
        raise ValueError(f"Unknown sampling method: {method}")


class DummyRpcGroup:
    """
    Minimal RPC group stub for local execution. In a real distributed setting,
    these would communicate across processes.
    """
    def __init__(self):
        self.services: Dict[str, Any] = {}

    def register(self, name: str, func) -> None:
        self.services[name] = func

    def call(self, name: str, *args, **kwargs):
        return self.services[name](*args, **kwargs)

    def broadcast(self, name: str, *args, **kwargs) -> None:
        # In real implementation, would send to all members.
        self.call(name, *args, **kwargs)

    def all_gather(self, name: str, *args, **kwargs) -> List[Any]:
        # Return list of local result for demonstration.
        result = self.call(name, *args, **kwargs)
        return [result]

    def size(self) -> int:
        return 1  # Single process for this stub


class DistributedBuffer:
    def __init__(
        self,
        buffer_name: str,
        rpc_group: DummyRpcGroup,
        buffer_size: int = 100000,
        storage: Optional[InMemoryStorage] = None,
    ):
        self.buffer_name = buffer_name
        self.group = rpc_group
        self.buffer_size = buffer_size
        self.storage = storage if storage is not None else InMemoryStorage(buffer_size)
        self.lock = threading.RLock()

        self.group.register(f"{self.buffer_name}_size", self._size_service)
        self.group.register(f"{self.buffer_name}_clear", self._clear_service)
        self.group.register(f"{self.buffer_name}_sample", self._sample_service)

    def store_episode(self, episode: List[Any]) -> None:
        with self.lock:
            self.storage.append(episode)

    def clear(self) -> None:
        with self.lock:
            self.storage.clear()

    def all_clear(self) -> None:
        self.group.broadcast(f"{self.buffer_name}_clear")

    def size(self) -> int:
        return self.storage.size()

    def all_size(self) -> int:
        sizes = self.group.all_gather(f"{self.buffer_name}_size")
        return sum(sizes)

    def sample_batch(
        self,
        batch_size: int,
        concatenate: bool = True,
        sample_attrs: Optional[Dict[str, Any]] = None,
    ) -> Tuple[List[Any], Dict[str, Any]]:
        if sample_attrs is None:
            sample_attrs = {}

        world_size = self.group.size()
        local_batch_size = batch_size // world_size
        results = self.group.all_gather(
            f"{self.buffer_name}_sample",
            local_batch_size,
            concatenate,
            sample_attrs,
        )

        aggregated_batch: List[Any] = []
        aggregated_attrs: Dict[str, Any] = {}
        for size, batch, attrs in results:
            if concatenate:
                aggregated_batch.extend(batch)
            else:
                aggregated_batch.append(batch)
            for key, value in attrs.items():
                if key not in aggregated_attrs:
                    aggregated_attrs[key] = []
                aggregated_attrs[key].append(value)

        # Move tensors to CPU if they are on other devices
        for i, item in enumerate(aggregated_batch):
            if isinstance(item, torch.Tensor):
                aggregated_batch[i] = item.cpu()
        return aggregated_batch, aggregated_attrs

    # ---------------- RPC service implementations ----------------

    def _size_service(self) -> int:
        with self.lock:
            return self.storage.size()

    def _clear_service(self) -> None:
        with self.lock:
            self.storage.clear()

    def _sample_service(
        self,
        local_batch_size: int,
        concatenate: bool,
        sample_attrs: Dict[str, Any],
    ) -> Tuple[int, List[Any], Dict[str, Any]]:
        method = sample_attrs.get("method", "random_unique")
        with self.lock:
            batch = self.storage.sample(local_batch_size, method=method)

        # Ensure tensors are on CPU
        cleaned_batch: List[Any] = []
        for item in batch:
            if isinstance(item, torch.Tensor):
                cleaned_batch.append(item.cpu())
            else:
                cleaned_batch.append(item)

        # Handle custom attributes if any
        attrs = {}
        for key, value in sample_attrs.items():
            if key != "method":
                attrs[key] = value

        return len(cleaned_batch), cleaned_batch, attrs
