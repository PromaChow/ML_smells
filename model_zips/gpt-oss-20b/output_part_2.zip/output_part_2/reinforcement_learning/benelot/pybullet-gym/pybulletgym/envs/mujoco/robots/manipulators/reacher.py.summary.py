import numpy as np
from gym.envs.mujoco.mjcf import MJCFBasedRobot

class Reacher(MJCFBasedRobot):
    def __init__(self):
        super().__init__(mjcf_file='reacher.xml',
                         base_body='body0',
                         action_dim=2,
                         observation_dim=9)
        # Random number generator
        self.np_random = np.random.RandomState()
        # Components
        self.fingertip = self.model.find_geom('fingertip')
        self.target = self.model.find_geom('target')
        self.central_joint = self.model.find_joint('central_joint')
        self.elbow_joint = self.model.find_joint('elbow_joint')
        self.joints = [self.central_joint, self.elbow_joint]
        self.reset()

    def reset(self):
        # Random target position within ±0.27 on x and y
        x = self.np_random.uniform(-0.27, 0.27)
        y = self.np_random.uniform(-0.27, 0.27)
        self.target.initpos[:] = [x, y, 0.0]
        self.target.initvel[:] = [0.0, 0.0, 0.0]
        # Random joint angles between -π and π
        for joint in self.joints:
            angle = self.np_random.uniform(-np.pi, np.pi)
            joint.qpos = angle
            joint.qvel = 0.0
        self.sim.forward()

    def apply_action(self, action):
        clipped = np.clip(action, -1.0, 1.0) * 0.05
        self.set_motor_torque(self.central_joint.name, clipped[0])
        self.set_motor_torque(self.elbow_joint.name, clipped[1])
        self.sim.step()

    def get_state(self):
        joint_angles = [joint.qpos for joint in self.joints]
        joint_vels = [joint.qvel for joint in self.joints]
        fingertip_pos = self.fingertip.xpos
        target_pos = self.target.xpos
        vec = target_pos - fingertip_pos
        state = [
            np.cos(joint_angles[0]), np.sin(joint_angles[0]),
            np.cos(joint_angles[1]), np.sin(joint_angles[1])
        ]
        state += joint_vels[:2]
        state += vec.tolist()
        return np.array(state)

    def calc_potential(self):
        fingertip_pos = self.fingertip.xpos
        target_pos = self.target.xpos
        vec = target_pos - fingertip_pos
        return -100.0 * np.linalg.norm(vec)