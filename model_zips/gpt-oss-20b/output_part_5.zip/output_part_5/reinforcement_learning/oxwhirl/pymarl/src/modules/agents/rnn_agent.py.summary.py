import torch
import torch.nn as nn
import torch.nn.functional as F
from dataclasses import dataclass

@dataclass
class Args:
    input_dim: int
    rnn_hidden_dim: int
    n_actions: int

class Agent(nn.Module):
    def __init__(self, args: Args):
        super().__init__()
        self.hidden_dim = args.rnn_hidden_dim
        self.fc1 = nn.Linear(args.input_dim, self.hidden_dim)
        self.rnn = nn.GRUCell(self.hidden_dim, self.hidden_dim)
        self.fc2 = nn.Linear(self.hidden_dim, args.n_actions)

    def init_hidden(self):
        device = self.fc1.weight.device
        return torch.zeros((1, self.hidden_dim), device=device)

    def forward(self, x: torch.Tensor, h_in: torch.Tensor):
        x = F.relu(self.fc1(x))
        h_in = h_in.view(-1, self.hidden_dim)
        h = self.rnn(x, h_in)
        q = self.fc2(h)
        return q, h

if __name__ == "__main__":
    args = Args(input_dim=10, rnn_hidden_dim=32, n_actions=4)
    agent = Agent(args)
    agent = agent.to('cpu')
    batch_size = 3
    x = torch.randn(batch_size, args.input_dim)
    h = agent.init_hidden().repeat(batch_size, 1)
    q, h_new = agent(x, h)
    print("Q-values:", q)
    print("Updated hidden state shape:", h_new.shape)