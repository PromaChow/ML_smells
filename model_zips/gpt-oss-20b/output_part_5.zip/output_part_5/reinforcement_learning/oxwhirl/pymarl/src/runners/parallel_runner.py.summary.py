import multiprocessing as mp
import cloudpickle
import gym
import numpy as np
import random
import os
import sys

# ---------- Utility ----------------------------------------------------- #
class CloudpickleWrapper:
    def __init__(self, obj):
        self.obj = obj

    def __getstate__(self):
        return cloudpickle.dumps(self.obj)

    def __setstate__(self, state):
        self.obj = cloudpickle.loads(state)

    def __call__(self):
        return self.obj

# ---------- Environment Registry ---------------------------------------- #
env_REGISTRY = {
    "CartPole-v1": lambda: gym.make("CartPole-v1")
}

# ---------- Episode Batch ----------------------------------------------- #
class EpisodeBatch:
    def __init__(self, batch_size, max_steps, obs_shape, action_shape):
        self.batch_size = batch_size
        self.max_steps = max_steps
        self.obs = np.zeros((batch_size, max_steps + 1) + obs_shape, dtype=np.float32)
        self.actions = np.zeros((batch_size, max_steps) + action_shape, dtype=np.int32)
        self.rewards = np.zeros((batch_size, max_steps), dtype=np.float32)
        self.dones = np.zeros((batch_size, max_steps), dtype=bool)
        self.current_step = 0

    def reset(self):
        self.current_step = 0
        self.dones.fill(False)

# ---------- Model / Policy ---------------------------------------------- #
class SimpleMAC:
    def __init__(self, action_space):
        self.action_space = action_space

    def get_actions(self, obs_batch, avail_actions=None):
        return [self.action_space.sample() for _ in obs_batch]

# ---------- Worker Process ---------------------------------------------- #
def worker_process(conn, env_fn):
    env = env_fn()
    env.seed(random.randint(0, 10000))
    while True:
        try:
            cmd, data = conn.recv()
        except EOFError:
            break
        if cmd == "step":
            action = data
            obs, reward, done, info = env.step(action)
            conn.send((obs, reward, done, info))
        elif cmd == "reset":
            obs = env.reset()
            conn.send(obs)
        elif cmd == "close":
            env.close()
            conn.close()
            break
        elif cmd == "get_env_info":
            conn.send((env.observation_space, env.action_space))
        elif cmd == "get_stats":
            # Placeholder for statistics
            conn.send({"episode_return": 0.0})
        else:
            conn.send(None)

# ---------- Parallel Environment Runner --------------------------------- #
class ParallelEnvRunner:
    def __init__(self, env_name, batch_size, max_steps, seed=0):
        self.env_name = env_name
        self.batch_size = batch_size
        self.max_steps = max_steps
        self.seed = seed
        self.env_fn = CloudpickleWrapper(env_REGISTRY[env_name])
        self.parent_conns = []
        self.children = []
        self._init_workers()
        self.env_info = self._get_env_info()
        self.mac = SimpleMAC(self.env_info['action_space'])
        self.batch = EpisodeBatch(
            batch_size,
            max_steps,
            self.env_info['observation_space'].shape,
            (self.env_info['action_space'].n,)
        )
        self.episode_returns = np.zeros(batch_size)
        self.episode_lengths = np.zeros(batch_size)

    def _init_workers(self):
        for _ in range(self.batch_size):
            parent_conn, child_conn = mp.Pipe()
            p = mp.Process(target=worker_process, args=(child_conn, self.env_fn))
            p.daemon = True
            p.start()
            self.parent_conns.append(parent_conn)
            self.children.append(p)

    def _get_env_info(self):
        conn = self.parent_conns[0]
        conn.send(("get_env_info", None))
        obs_space, act_space = conn.recv()
        return {"observation_space": obs_space, "action_space": act_space}

    def reset(self):
        for conn in self.parent_conns:
            conn.send(("reset", None))
        initial_obs = [conn.recv() for conn in self.parent_conns]
        self.batch.obs[:, 0] = np.array(initial_obs)
        self.batch.reset()
        self.episode_returns.fill(0)
        self.episode_lengths.fill(0)

    def run_episodes(self, num_episodes):
        episode_counter = 0
        while episode_counter < num_episodes:
            self.reset()
            done = np.zeros(self.batch_size, dtype=bool)
            while not all(done) and self.batch.current_step < self.max_steps:
                # Gather observations for active envs
                obs_batch = [self.batch.obs[i, self.batch.current_step] for i in range(self.batch_size) if not done[i]]
                actions = self.mac.get_actions(obs_batch)
                # Send step commands
                for i, conn in enumerate(self.parent_conns):
                    if not done[i]:
                        conn.send(("step", actions.pop(0)))
                # Receive results
                for i, conn in enumerate(self.parent_conns):
                    if not done[i]:
                        obs, reward, d, info = conn.recv()
                        self.batch.obs[i, self.batch.current_step + 1] = obs
                        self.batch.rewards[i, self.batch.current_step] = reward
                        self.batch.dones[i, self.batch.current_step] = d
                        self.episode_returns[i] += reward
                        self.episode_lengths[i] += 1
                        if d:
                            done[i] = True
                self.batch.current_step += 1
            episode_counter += 1
            print(f"Episode {episode_counter}: mean return {self.episode_returns.mean():.2f}, mean length {self.episode_lengths.mean():.2f}")
            stats = self.collect_stats()
            print(f"Stats from workers: {stats}")

    def collect_stats(self):
        stats = []
        for conn in self.parent_conns:
            conn.send(("get_stats", None))
            stats.append(conn.recv())
        return stats

    def close(self):
        for conn in self.parent_conns:
            try:
                conn.send(("close", None))
            except BrokenPipeError:
                pass
        for p in self.children:
            p.join()

# ---------- Example Usage ----------------------------------------------- #
if __name__ == "__main__":
    runner = ParallelEnvRunner(env_name="CartPole-v1", batch_size=4, max_steps=200)
    try:
        runner.run_episodes(num_episodes=5)
    finally:
        runner.close()
