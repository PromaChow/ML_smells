import pygame
import random
import math
from typing import List, Dict

# ---------------------------- Utility Wrapper ----------------------------
class PyGameWrapper:
    def __init__(self, width: int, height: int, title: str = "Snake Game"):
        pygame.init()
        self.width = width
        self.height = height
        self.screen = pygame.display.set_mode((width, height))
        pygame.display.set_caption(title)
        self.clock = pygame.time.Clock()
        self.running = True

    def clear(self, color: tuple):
        self.screen.fill(color)

    def update(self):
        pygame.display.flip()
        self.clock.tick(60)

    def quit(self):
        pygame.quit()

# ---------------------------- Sprite Classes ----------------------------
class SnakeSegment(pygame.sprite.Sprite):
    def __init__(self, position: tuple, size: int, color: tuple):
        super().__init__()
        self.image = pygame.Surface((size, size))
        self.image.fill(color)
        self.rect = self.image.get_rect()
        self.rect.topleft = position
        self.size = size

    def draw(self, surface):
        surface.blit(self.image, self.rect)

class Food(pygame.sprite.Sprite):
    def __init__(self, size: int, color: tuple, screen_width: int, screen_height: int, margin: int = 20):
        super().__init__()
        self.size = size
        self.color = color
        self.screen_width = screen_width
        self.screen_height = screen_height
        self.margin = margin
        self.image = pygame.Surface((size, size))
        self.image.fill(color)
        self.rect = self.image.get_rect()
        self.place(None)

    def place(self, snake_segments: List[SnakeSegment]):
        valid = False
        while not valid:
            x = random.randint(self.margin, self.screen_width - self.margin - self.size)
            y = random.randint(self.margin, self.screen_height - self.margin - self.size)
            self.rect.topleft = (x, y)
            valid = True
            if snake_segments:
                for seg in snake_segments:
                    if seg.rect.colliderect(self.rect):
                        valid = False
                        break

    def draw(self, surface):
        surface.blit(self.image, self.rect)

# ---------------------------- Snake Player ----------------------------
class SnakePlayer:
    def __init__(self, initial_pos: tuple, initial_length: int, segment_size: int, color: tuple):
        self.segments: List[SnakeSegment] = []
        self.segment_size = segment_size
        self.color = color
        for i in range(initial_length):
            pos = (initial_pos[0] - i * segment_size, initial_pos[1])
            segment = SnakeSegment(pos, segment_size, color)
            self.segments.append(segment)
        self.direction = pygame.math.Vector2(0, 0)
        self.speed = segment_size
        self.growth_pending = 0

    def set_direction(self, new_dir: pygame.math.Vector2):
        if new_dir.length() == 0:
            return
        if self.direction.dot(new_dir) == -1:
            return
        self.direction = new_dir

    def move(self):
        if self.direction.length() == 0:
            return
        new_head_pos = (self.segments[0].rect.x + self.direction.x * self.speed,
                        self.segments[0].rect.y + self.direction.y * self.speed)
        new_head_rect = pygame.Rect(new_head_pos, (self.segment_size, self.segment_size))
        self.segments[0].rect = new_head_rect
        for i in range(1, len(self.segments)):
            self.segments[i].rect.topleft = self.segments[i - 1].rect.topleft

        if self.growth_pending > 0:
            tail = self.segments[-1]
            new_seg = SnakeSegment(tail.rect.topleft, self.segment_size,
                                   self._adjust_color(self.growth_pending))
            self.segments.append(new_seg)
            self.growth_pending -= 1

    def grow(self, count: int = 1):
        self.growth_pending += count

    def _adjust_color(self, growth_stage: int) -> tuple:
        r = min(255, self.color[0] + growth_stage * 10)
        g = min(255, self.color[1] + growth_stage * 10)
        b = min(255, self.color[2] + growth_stage * 10)
        return (r, g, b)

    def draw(self, surface):
        for seg in self.segments:
            seg.draw(surface)

    def get_head(self) -> SnakeSegment:
        return self.segments[0]

# ---------------------------- Main Snake Game ----------------------------
class Snake:
    def __init__(self):
        self.screen_width = 600
        self.screen_height = 400
        self.bg_color = (0, 0, 0)
        self.wrapper = PyGameWrapper(self.screen_width, self.screen_height)
        self.segment_size = 20
        self.snake_color = (0, 255, 0)
        self.food_color = (255, 0, 0)
        self.score = 0
        self.reset_game()

    def reset_game(self):
        self.score = 0
        init_pos = (self.screen_width // 2, self.screen_height // 2)
        self.snake = SnakePlayer(init_pos, 5, self.segment_size, self.snake_color)
        self.food = Food(self.segment_size, self.food_color,
                         self.screen_width, self.screen_height)
        self.food.place(self.snake.segments)

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.wrapper.running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_w:
                    self.snake.set_direction(pygame.math.Vector2(0, -1))
                elif event.key == pygame.K_s:
                    self.snake.set_direction(pygame.math.Vector2(0, 1))
                elif event.key == pygame.K_a:
                    self.snake.set_direction(pygame.math.Vector2(-1, 0))
                elif event.key == pygame.K_d:
                    self.snake.set_direction(pygame.math.Vector2(1, 0))

    def update_game_state(self):
        self.snake.move()
        head = self.snake.get_head()
        if head.rect.colliderect(self.food.rect):
            self.snake.grow()
            self.score += 10
            self.food.place(self.snake.segments)
        if head.rect.left < 0 or head.rect.right > self.screen_width or \
           head.rect.top < 0 or head.rect.bottom > self.screen_height:
            self.score = max(0, self.score - 5)
            self.reset_game()
            return
        body_hits = pygame.sprite.spritecollide(head, self.snake.segments[1:], False)
        if body_hits:
            self.score = max(0, self.score - 5)
            self.reset_game()
            return
        self.score += 1

    def render(self):
        self.wrapper.clear(self.bg_color)
        self.snake.draw(self.wrapper.screen)
        self.food.draw(self.wrapper.screen)
        pygame.display.set_caption(f"Snake Game - Score: {self.score}")
        self.wrapper.update()

    def step(self):
        self.handle_events()
        self.update_game_state()
        self.render()

    def getGameState(self) -> Dict:
        head_pos = (self.snake.get_head().rect.x, self.snake.get_head().rect.y)
        food_pos = (self.food.rect.x, self.food.rect.y)
        distances = []
        for seg in self.snake.segments[1:]:
            dx = seg.rect.x - self.snake.get_head().rect.x
            dy = seg.rect.y - self.snake.get_head().rect.y
            distances.append(math.hypot(dx, dy))
        return {
            "head_position": head_pos,
            "food_position": food_pos,
            "segment_distances": distances
        }

# ---------------------------- Main Loop ----------------------------
if __name__ == "__main__":
    game = Snake()
    while game.wrapper.running:
        game.step()
    game.wrapper.quit()