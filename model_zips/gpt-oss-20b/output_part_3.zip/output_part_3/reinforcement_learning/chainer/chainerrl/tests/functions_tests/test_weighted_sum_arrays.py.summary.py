import unittest
import numpy as np
from chainer import testing, gradient_check, cuda, Variable
import chainerrl

np.random.seed(0)

@testing.parameterize(*testing.product(
    dict(
        batchsize=[1, 3],
        n=[1, 2, 7],
        shape=[(1,), (1, 1), (2,), (2, 3)]
    )
))
class TestSumArrays(unittest.TestCase):
    def setUp(self):
        # Override batchsize with fixed value
        self.batch_size = 5
        array_shape = (self.batch_size,) + self.shape
        self.xs = [
            np.random.uniform(-1, 1, size=array_shape).astype(np.float32)
            for _ in range(self.n)
        ]
        self.weights = np.random.uniform(0, 1, size=self.n).astype(np.float32)
        self.gy = np.random.uniform(-1, 1, size=array_shape).astype(np.float32)

    def check_forward(self, xs):
        out = chainerrl.functions.weighted_sum_arrays(xs, self.weights)
        # Convert Variable to array if necessary
        if isinstance(out, Variable):
            out = out.data
        if isinstance(out, cuda.ndarray):
            out = cuda.to_cpu(out)
        manual = sum(x * w for x, w in zip(xs, self.weights))
        gradient_check.assert_allclose(out, manual, rtol=1e-5, atol=1e-5)

    def test_forward_cpu(self):
        self.check_forward(self.xs)

    def test_forward_gpu(self):
        xs_gpu = [cuda.to_gpu(x) for x in self.xs]
        self.check_forward(xs_gpu)

    def check_backward(self, xs, gy):
        gradient_check.check_backward(
            lambda x: chainerrl.functions.weighted_sum_arrays(x, self.weights),
            xs,
            gy,
            eps=1e-2,
            rtol=1e-2
        )

    def test_backward_cpu(self):
        self.check_backward(self.xs, self.gy)

    def test_backward_gpu(self):
        xs_gpu = [cuda.to_gpu(x) for x in self.xs]
        gy_gpu = cuda.to_gpu(self.gy)
        self.check_backward(xs_gpu, gy_gpu)


if __name__ == "__main__":
    testing.run_module(__name__, __file__)