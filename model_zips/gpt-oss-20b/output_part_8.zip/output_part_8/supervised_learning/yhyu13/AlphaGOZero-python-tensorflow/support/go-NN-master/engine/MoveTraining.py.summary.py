import tensorflow as tf
import numpy as np
import random

# Symmetry utilities
class Symmetry:
    @staticmethod
    def apply_symmetry_planes(planes, s):
        # Placeholder: identity transformation
        return planes

    @staticmethod
    def apply_symmetry_vertex(vertices, s, N):
        # Placeholder: identity transformation
        return vertices

# Dummy data loader
class Loader:
    def __init__(self, batch_size, N, channels):
        self.batch_size = batch_size
        self.N = N
        self.channels = channels
        self._count = 0

    def next_minibatch(self):
        # Generate synthetic data
        feature_planes = np.random.randn(
            self.batch_size, self.N, self.N, self.channels
        ).astype(np.float32)
        moves = np.random.randint(
            0, self.N, size=(self.batch_size, 2), dtype=np.int32
        )
        return feature_planes, moves

# Normalization
def apply_normalization(feature_planes):
    mean = tf.reduce_mean(feature_planes, axis=[1, 2], keepdims=True)
    std = tf.math.reduce_std(feature_planes, axis=[1, 2], keepdims=True) + 1e-6
    return (feature_planes - mean) / std

# Apply random symmetries
def apply_random_symmetries(feature_planes, move_arrs):
    many_feature_planes = tf.identity(feature_planes)
    many_move_arrs = tf.identity(move_arrs)
    batch_size = tf.shape(feature_planes)[0]
    N = tf.shape(feature_planes)[1]

    def body(i, fp, ma):
        s = tf.random.uniform([], minval=0, maxval=8, dtype=tf.int32)
        fp_i = Symmetry.apply_symmetry_planes(fp[i], s)
        ma_i = Symmetry.apply_symmetry_vertex(ma[i], s, N)
        fp = fp.write(i, fp_i)
        ma = ma.write(i, ma_i)
        return i + 1, fp, ma

    fp_ta = tf.TensorArray(tf.float32, size=batch_size)
    ma_ta = tf.TensorArray(tf.int32, size=batch_size)
    i = tf.constant(0)
    i, fp_ta, ma_ta = tf.while_loop(
        lambda i, *_: i < batch_size,
        body,
        loop_vars=[i, fp_ta, ma_ta]
    )
    many_feature_planes = fp_ta.stack()
    many_move_arrs = ma_ta.stack()
    return many_feature_planes, many_move_arrs

# Build feed dictionary
def build_feed_dict(loader):
    feature_planes, moves = loader.next_minibatch()
    feature_planes_tf = tf.constant(feature_planes)
    moves_tf = tf.constant(moves)
    normalized = apply_normalization(feature_planes_tf)
    sym_feature, sym_moves = apply_random_symmetries(normalized, moves_tf)
    N = tf.shape(sym_feature)[1]
    loaded_move_indices = tf.cast(N * sym_moves[:, 0] + sym_moves[:, 1], tf.int64)
    feed_dict = {
        'feature_planes': sym_feature,
        'move_indices': loaded_move_indices
    }
    return feed_dict

# Loss and accuracy computation
def compute_loss_and_accuracy(logits, move_indices):
    loss_per_example = tf.nn.sparse_softmax_cross_entropy_with_logits(
        labels=move_indices, logits=logits
    )
    cross_entropy_mean = tf.reduce_mean(loss_per_example)
    predictions = tf.argmax(logits, axis=1, output_type=tf.int64)
    correct = tf.cast(tf.equal(predictions, move_indices), tf.float32)
    accuracy = tf.reduce_mean(correct)
    return move_indices, cross_entropy_mean, accuracy

# Example usage
def main():
    batch_size = 32
    N = 8
    channels = 12
    loader = Loader(batch_size, N, channels)

    feed = build_feed_dict(loader)

    logits = tf.placeholder(tf.float32, shape=[batch_size, N * N])

    move_indices, cross_entropy_mean, accuracy = compute_loss_and_accuracy(
        logits, feed['move_indices']
    )

    with tf.Session() as sess:
        feed_vals = {
            logits: np.random.randn(batch_size, N * N).astype(np.float32)
        }
        mi, ce, acc = sess.run(
            [move_indices, cross_entropy_mean, accuracy],
            feed_dict=feed_vals
        )
        print("Move indices:", mi)
        print("Cross entropy mean:", ce)
        print("Accuracy:", acc)

if __name__ == "__main__":
    tf.disable_eager_execution()
    main()