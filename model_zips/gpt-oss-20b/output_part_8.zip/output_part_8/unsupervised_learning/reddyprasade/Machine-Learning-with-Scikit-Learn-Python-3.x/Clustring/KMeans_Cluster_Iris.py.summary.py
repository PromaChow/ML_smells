import numpy as np
import matplotlib.pyplot as plt
from sklearn import datasets
from sklearn.cluster import KMeans
from mpl_toolkits.mplot3d import Axes3D

# Set random seed
np.random.seed(5)

# Load Iris dataset
iris = datasets.load_iris()
X = iris.data
y = iris.target

# Define estimators
k_means_iris_8 = KMeans(n_clusters=8, random_state=5)
k_means_iris_3 = KMeans(n_clusters=3, random_state=5)
k_means_iris_bad_init = KMeans(n_clusters=3, n_init=1, init='random', random_state=5)

# Helper function to plot 3D scatter
def plot_3d_clusters(estimator, title, ax):
    labels = estimator.fit_predict(X)
    ax.scatter(X[:, 3], X[:, 0], X[:, 2], c=labels, cmap='viridis', s=50)
    ax.set_xlabel('Petal width')
    ax.set_ylabel('Sepal length')
    ax.set_zlabel('Petal length')
    ax.set_title(title)

# Plot 8 clusters
fig1 = plt.figure()
ax1 = fig1.add_subplot(111, projection='3d')
plot_3d_clusters(k_means_iris_8, '8 clusters', ax1)
plt.show()

# Plot 3 clusters (default initialization)
fig2 = plt.figure()
ax2 = fig2.add_subplot(111, projection='3d')
plot_3d_clusters(k_means_iris_3, '3 clusters', ax2)
plt.show()

# Plot 3 clusters (bad initialization)
fig3 = plt.figure()
ax3 = fig3.add_subplot(111, projection='3d')
plot_3d_clusters(k_means_iris_bad_init, '3 clusters, bad initialization', ax3)
plt.show()

# Ground truth plot
fig4 = plt.figure()
ax4 = fig4.add_subplot(111, projection='3d')
scatter = ax4.scatter(X[:, 3], X[:, 0], X[:, 2], c=y, cmap='viridis', s=50)
ax4.set_xlabel('Petal width')
ax4.set_ylabel('Sepal length')
ax4.set_zlabel('Petal length')
ax4.set_title('Ground Truth')

# Add text labels at mean coordinates
class_names = ['Setosa', 'Versicolour', 'Virginica']
for i, name in enumerate(class_names):
    idx = np.where(y == i)
    mean_coords = X[idx, :].mean(axis=0)
    ax4.text(mean_coords[3], mean_coords[0], mean_coords[2], name,
             fontsize=12, fontweight='bold')

plt.show()