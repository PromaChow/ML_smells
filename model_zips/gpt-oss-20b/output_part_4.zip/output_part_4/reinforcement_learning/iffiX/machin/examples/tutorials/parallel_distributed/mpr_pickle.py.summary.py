import torch as t
from machin.parallel.pickle import dumps, loads
from machin.parallel.process import Process
from machin.parallel import get_context

# Contexts for different start methods
fork_ctx = get_context('fork')
spawn_ctx = get_context('spawn')

def print_tensor_sub_proc(serialized_tensor):
    """Deserialize tensor and print it."""
    tensor = loads(serialized_tensor)
    print(f"[Sub-process] Tensor: {tensor}")

def exec_sub_proc(serialized_func):
    """Deserialize and execute a function."""
    func = loads(serialized_func)
    func()

# CPU Tensor Handling (Non-Shared Memory)
tensor_cpu = t.ones([10])
serialized_cpu_copy = dumps(tensor_cpu, copy_tensor=True)
print(f"[Main] Serialized CPU tensor (copy=True) length: {len(serialized_cpu_copy)}")

p_cpu_copy = Process(target=print_tensor_sub_proc,
                     args=(serialized_cpu_copy,),
                     ctx=fork_ctx)
p_cpu_copy.start()
p_cpu_copy.join()

# CPU Tensor Handling (Shared Memory)
tensor_cpu.share_memory_()
serialized_cpu_shared = dumps(tensor_cpu, copy_tensor=False)
print(f"[Main] Serialized CPU tensor (copy=False) length: {len(serialized_cpu_shared)}")

p_cpu_shared = Process(target=print_tensor_sub_proc,
                       args=(serialized_cpu_shared,),
                       ctx=fork_ctx)
p_cpu_shared.start()
p_cpu_shared.join()

# GPU Tensor Handling (requires CUDA)
if t.cuda.is_available():
    tensor_gpu = t.ones([10]).to("cuda:0")
    serialized_gpu_copy = dumps(tensor_gpu, copy_tensor=True)
    serialized_gpu_shared = dumps(tensor_gpu, copy_tensor=False)
    print(f"[Main] Serialized GPU tensor (copy=True) length: {len(serialized_gpu_copy)}")
    print(f"[Main] Serialized GPU tensor (copy=False) length: {len(serialized_gpu_shared)}")

    p_gpu = Process(target=print_tensor_sub_proc,
                    args=(serialized_gpu_shared,),
                    ctx=spawn_ctx)
    p_gpu.start()
    p_gpu.join()
else:
    print("[Main] CUDA not available. Skipping GPU tests.")

# Function Serialization with Shared State
global_tensor = t.zeros([5])

def local_func():
    global global_tensor
    global_tensor.fill_(42)

# Serialize the function including its global state
serialized_func = dumps(local_func, recurse=True, copy_tensor=False)
print(f"[Main] Serialized function length: {len(serialized_func)}")

print(f"[Main] global_tensor before: {global_tensor}")
p_func = Process(target=exec_sub_proc,
                 args=(serialized_func,),
                 ctx=spawn_ctx)
p_func.start()
p_func.join()
print(f"[Main] global_tensor after: {global_tensor}")