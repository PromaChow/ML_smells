import os
import pathlib
import urllib.request
import pandas as pd
import torch
import numpy as np


class AdultDataBandit:
    DEFAULT_URL = (
        "https://archive.ics.uci.edu/ml/machine-learning-databases/adult/adult.data"
    )
    DEFAULT_FILENAME = "adult.data"

    def __init__(
        self,
        path: str,
        download: bool = True,
        force_download: bool = False,
        url: str | None = None,
        device: str | torch.device = "cpu",
    ):
        self.path = pathlib.Path(path)
        self.download = download
        self.force_download = force_download
        self.url = url or self.DEFAULT_URL
        self.device = torch.device(device)

        self._prepare_data()
        self._preprocess_data()
        self.n_actions = int(self.df.iloc[:, -1].nunique())
        self.context_dim = self.df.shape[1] - 1
        self.len = self.df.shape[0]
        self.current_index = 0
        self.df = self.df.reset_index(drop=True)

    def _prepare_data(self) -> None:
        if self.download:
            if not self.path.exists():
                self.path.mkdir(parents=True, exist_ok=True)
            file_path = self.path / self.DEFAULT_FILENAME
            if self.force_download or not file_path.exists():
                urllib.request.urlretrieve(self.url, file_path)
            self.file_path = file_path
        else:
            file_path = self.path / self.DEFAULT_FILENAME
            if not file_path.exists():
                raise FileNotFoundError(
                    f"Data file not found at {file_path}. Set download=True to fetch it."
                )
            self.file_path = file_path

        df = pd.read_csv(
            self.file_path,
            header=None,
            sep=",",
            skipinitialspace=True,
            na_values=["?", " ?"],
            keep_default_na=False,
        )
        df.dropna(inplace=True)
        self.df = df

    def _preprocess_data(self) -> None:
        indices = [1, 3, 5, 6, 7, 8, 9, 13, 14]
        indices = [i for i in indices if i < self.df.shape[1]]
        dummy = pd.get_dummies(
            self.df.iloc[:, indices], prefix=self.df.columns[indices], drop_first=False
        )
        self.df = pd.concat(
            [self.df.drop(self.df.columns[indices], axis=1), dummy], axis=1
        )
        # Ensure second-to-last column exists
        if self.df.shape[1] < 2:
            raise ValueError("DataFrame does not contain enough columns after preprocessing.")
        self.df.iloc[:, -2] = self.df.iloc[:, -2] + self.df.iloc[:, -1]
        self.df = self.df.drop(self.df.columns[-1], axis=1)

    def reset(self) -> torch.Tensor:
        self.df = self.df.sample(frac=1).reset_index(drop=True)
        self.current_index = 0
        return self._get_context()

    def _get_context(self) -> torch.Tensor:
        row = self.df.iloc[self.current_index]
        context = torch.tensor(
            row[:-1].values.astype(np.float32), device=self.device
        )
        return context

    def _compute_reward(self, action: int) -> tuple[int, int]:
        true_label = self.df.iloc[self.current_index, -1]
        reward = int(action == true_label)
        self.current_index += 1
        if self.current_index >= self.len:
            self.current_index = self.len - 1
        return reward, 1
