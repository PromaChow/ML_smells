import os
import numpy as np
from sklearn.svm import SVR
import joblib
import datasetUtils as dsu
import embeddings

# Configuration
method = "conc"
post_threshold = 3
dataset_type = "fasttext"
fasttext_path = "../FastText/dataset.vec"

# Data initialization
posts = []
yO = []
yC = []
yE = []
yA = []
yN = []

# Data loading
posts, yO, yC, yE, yA, yN = dsu.readMyPersonality()
wordDictionary = dsu.parseFastText(fasttext_path)

# Shuffle data
indices = np.arange(len(posts))
np.random.shuffle(indices)
posts = [posts[i] for i in indices]
yO = [yO[i] for i in indices]
yC = [yC[i] for i in indices]
yE = [yE[i] for i in indices]
yA = [yA[i] for i in indices]
yN = [yN[i] for i in indices]

# Embedding transformation
conE = embeddings.transformTextForTraining(
    wordDictionary,
    posts,
    yO,
    yC,
    yE,
    yA,
    yN,
    post_threshold,
    method
)

# Ensure model directory exists
model_dir = "Models/SVM"
os.makedirs(model_dir, exist_ok=True)

# Hyperparameters for each trait
trait_params = {
    "O": {"gamma": 1, "C": 1},
    "C": {"gamma": 5, "C": 5},
    "E": {"gamma": 2, "C": 2},
    "A": {"gamma": 3, "C": 3},
    "N": {"gamma": 10, "C": 10},
}

# Train and save models
for trait, params in trait_params.items():
    if trait == "O":
        y = yO
    elif trait == "C":
        y = yC
    elif trait == "E":
        y = yE
    elif trait == "A":
        y = yA
    else:  # trait == "N"
        y = yN

    svr = SVR(kernel="rbf", gamma=params["gamma"], C=params["C"])
    svr.fit(conE, y)
    model_path = os.path.join(model_dir, f"SVM_{trait}.pkl")
    joblib.dump(svr, model_path)