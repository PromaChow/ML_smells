import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans

# 1. Data Loading
data = pd.read_csv("Project_Data_1.csv", index_col=0, decimal=",")

# 2. Missing Value Handling
data = data.dropna()

# 3. Data Preparation for Dimensionality Reduction
data_for_decomposition = data.values

# 4. Principal Component Analysis (PCA)
pca = PCA(n_components=2)
pca_result = pca.fit_transform(data_for_decomposition)
new_data = pd.DataFrame(pca_result, columns=["pca_1", "pca_2"], index=data.index)

# 5. Elbow Method for Cluster Selection
wcss = []
for k in range(1, 11):
    kmeans = KMeans(n_clusters=k, random_state=42)
    kmeans.fit(pca_result)
    wcss.append(kmeans.inertia_)

plt.figure(figsize=(8, 4))
plt.plot(range(1, 11), wcss, marker='o')
plt.title('Elbow Method For Optimal k')
plt.xlabel('Number of clusters')
plt.ylabel('WCSS')
plt.xticks(range(1, 11))
plt.show()

# 6. KMeans Clustering with 3 clusters
kmeans = KMeans(n_clusters=3, random_state=42)
clusters = kmeans.fit_predict(pca_result)
print("Cluster Centers:\n", kmeans.cluster_centers_)

new_data["cluster"] = clusters

# 7. Cluster Visualization
plt.figure(figsize=(8, 6))
sns.scatterplot(data=new_data, x="pca_1", y="pca_2", hue="cluster", palette="Set1", legend="full", s=50)
plt.title("KMeans Clusters (PCA-Reduced Data)")
plt.xlabel("pca_1")
plt.ylabel("pca_2")
plt.legend(title="Cluster")
plt.show()

# 8. Cluster Label Integration into original data
data["cluster"] = clusters

# 9. Data Export
sorted_new_data = new_data.sort_values(by=["cluster", "pca_1", "pca_2"])
sorted_new_data.to_csv("output.csv")

# 10. Specific Country Analysis
for country in ["Sierra Leone", "Monaco"]:
    country_data = data[data["Country"] == country].head(18)
    plt.figure(figsize=(10, 4))
    sns.barplot(x=country_data.index, y=country_data["SomeMetric"], palette="viridis")
    plt.title(f"{country} - First 18 Rows")
    plt.xlabel("Index")
    plt.ylabel("SomeMetric")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()
