import numpy as np
import scipy.optimize as opt
import chainer.functions as F
import chainer

def mellowmax(values, omega=1.0, axis=1):
    """
    Compute the mellowmax of the input values along the specified axis.

    Parameters
    ----------
    values : chainer.Variable or numpy.ndarray
        Input values.
    omega : float, optional
        Parameter omega in the mellowmax formula.
    axis : int, optional
        Axis along which to compute mellowmax.

    Returns
    -------
    chainer.Variable
        The mellowmax values.
    """
    # Ensure values is a Chainer Variable
    if not isinstance(values, chainer.Variable):
        values = chainer.Variable(values)
    n = values.shape[axis]
    logsumexp_vals = F.logsumexp(omega * values, axis=axis)
    loglogsumexp = F.log(logsumexp_vals)
    n_const = F.constant(np.log(n), dtype=values.dtype)
    mellow = (loglogsumexp - n_const) / omega
    return mellow


def max_entropy_mellowmax_policy(values, omega=1.0, axis=1,
                                 beta_min=-1e3, beta_max=1e3):
    """
    Compute a maximum entropy policy distribution based on mellowmax.

    Parameters
    ----------
    values : chainer.Variable or numpy.ndarray
        Input values (e.g., Q-values) of shape (batch, actions, ...).
    omega : float, optional
        Parameter omega for mellowmax.
    axis : int, optional
        Axis along which actions are defined.
    beta_min : float, optional
        Minimum bound for the root-finding of beta.
    beta_max : float, optional
        Maximum bound for the root-finding of beta.

    Returns
    -------
    chainer.Variable
        Policy distribution with maximum entropy.
    """
    # Ensure values is a Chainer Variable
    if not isinstance(values, chainer.Variable):
        values = chainer.Variable(values)

    # Compute mellowmax
    mellow = mellowmax(values, omega=omega, axis=axis)

    # Broadcast mellow to the shape of values
    shape_expand = tuple(
        (-1,) + (1,) * (values.ndim - 1) if i == axis else (-1,)
        for i in range(values.ndim)
    )
    mellow_expanded = mellow.reshape(shape_expand)

    # Advantage
    advantage = values - mellow_expanded

    # Convert advantage to NumPy for root-finding
    advantage_np = np.array(advantage, dtype=np.float64)

    # Determine shape for beta: one value per batch element along axis
    if values.ndim == 2:
        batch_dim = values.shape[0]
    else:
        # For general n-dim, take all axes except action axis
        batch_shape = advantage_np.shape[:axis] + advantage_np.shape[axis+1:]
        batch_dim = np.prod(batch_shape)

    # Flatten batch dimension for iteration
    advantage_flat = advantage_np.reshape((batch_dim, -1))

    betas = np.zeros(batch_dim, dtype=np.float64)

    for idx in range(batch_dim):
        adv = advantage_flat[idx]
        # Define the function f(beta)
        def f(beta, adv_vec=adv):
            return np.sum(np.exp(beta * adv_vec) * adv_vec)

        try:
            beta_root = opt.brentq(f, beta_min, beta_max, xtol=1e-8, maxiter=100)
        except Exception:
            beta_root = 0.0
        betas[idx] = beta_root

    # Reshape betas back to batch shape
    if values.ndim == 2:
        betas_var = chainer.Variable(betas[:, None])
    else:
        betas_shape = advantage_np.shape[:axis] + advantage_np.shape[axis+1:]
        betas_var = chainer.Variable(betas.reshape(betas_shape))

    # Expand beta to match values dimensions
    betas_expanded = betas_var.reshape(shape_expand)

    # Scale values by beta and apply softmax
    scaled = values * betas_expanded
    policy = F.softmax(scaled, axis=axis)
    return policy
