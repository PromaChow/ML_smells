import os
import time
import random
import multiprocessing as mp
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import gym
import cma
from dataclasses import dataclass, field
from functools import partial

# Cloudpickle wrapper for multiprocessing
class CloudpickleWrapper:
    def __init__(self, obj):
        self.obj = obj
    def __getstate__(self):
        import cloudpickle
        return cloudpickle.dumps(self.obj)
    def __setstate__(self, state):
        import pickle
        self.obj = pickle.loads(state)

# Simple TimeStepEnv wrapper to standardize episode termination
class TimeStepEnv(gym.Wrapper):
    def reset(self, **kwargs):
        obs = super().reset(**kwargs)
        self.timestep = 0
        return obs
    def step(self, action):
        obs, reward, done, info = super().step(action)
        self.timestep += 1
        return obs, reward, done, info

# Configuration dataclass
@dataclass
class Config:
    env_ids: list = field(default_factory=lambda: ["Acrobot-v1", "BipedalWalker-v2",
                                                   "Pendulum-v0", "LunarLanderContinuous-v2"])
    layer_sizes: list = field(default_factory=lambda: [64, 64])
    generations: int = 500
    popsize: int = 32
    action_clip: bool = True
    fitness_eps: int = 10
    log_freq: int = 10
    checkpoint_freq: int = 50
    num_workers: int = 12
    use_gpu: bool = False
    log_dir: str = "logs/default"
    checkpoint_dir: str = "checkpoints"

# Simple feedforward policy network
class PolicyNet(nn.Module):
    def __init__(self, obs_dim, act_dim, layer_sizes):
        super().__init__()
        layers = []
        last_dim = obs_dim
        for size in layer_sizes:
            layers.append(nn.Linear(last_dim, size))
            layers.append(nn.ReLU())
            last_dim = size
        layers.append(nn.Linear(last_dim, act_dim))
        self.model = nn.Sequential(*layers)

    def forward(self, x):
        return self.model(x)

# Agent that holds the policy and checkpointing
class Agent:
    def __init__(self, env, config, device):
        self.env = env
        self.config = config
        self.device = device
        obs_dim = env.observation_space.shape[0]
        act_dim = env.action_space.shape[0]
        self.policy = PolicyNet(obs_dim, act_dim, config.layer_sizes).to(device)
        self.optimizer = optim.Adam(self.policy.parameters(), lr=1e-3)

    def act(self, obs):
        obs_tensor = torch.from_numpy(obs).float().to(self.device)
        with torch.no_grad():
            action = self.policy(obs_tensor).cpu().numpy()
        if self.config.action_clip:
            action = np.clip(action, self.env.action_space.low, self.env.action_space.high)
        return action

    def set_params(self, flat_params):
        pointer = 0
        for param in self.policy.parameters():
            numel = param.numel()
            new_val = flat_params[pointer:pointer+numel]
            param.data = torch.from_numpy(new_val.reshape(param.shape)).to(self.device)
            pointer += numel

    def get_params(self):
        return np.concatenate([p.detach().cpu().numpy().ravel() for p in self.policy.parameters()])

    def checkpoint(self, generation, filename):
        os.makedirs(self.config.checkpoint_dir, exist_ok=True)
        path = os.path.join(self.config.checkpoint_dir, filename)
        torch.save(self.policy.state_dict(), path)

# Environment creation
def make_env(env_id, seed, action_clip):
    env = gym.make(env_id)
    env.seed(seed)
    env.action_space.seed(seed)
    env = TimeStepEnv(env)
    env.action_clip = action_clip
    return env

# Fitness evaluation
def fitness(solution, env_id, seed, config):
    env = make_env(env_id, seed, config.action_clip)
    device = torch.device("cpu")
    agent = Agent(env, config, device)
    agent.set_params(solution)
    total_reward = 0.0
    total_steps = 0
    for _ in range(config.fitness_eps):
        obs = env.reset()
        done = False
        episode_reward = 0.0
        episode_steps = 0
        while not done:
            action = agent.act(obs)
            obs, reward, done, _ = env.step(action)
            episode_reward += reward
            episode_steps += 1
        total_reward += episode_reward
        total_steps += episode_steps
    avg_reward = total_reward / config.fitness_eps
    avg_steps = total_steps / config.fitness_eps
    return avg_reward, avg_steps

# Parallel evaluation wrapper
def evaluate_solution(args):
    solution, env_id, seed, config = args
    return fitness(solution, env_id, seed, config)

# Training loop
def run(seed, config):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    os.makedirs(config.log_dir, exist_ok=True)
    log_file = os.path.join(config.log_dir, f"seed_{seed}.log")
    with open(log_file, "w") as log:
        log.write("generation, time, best_reward, avg_reward, avg_horizon\n")
        for env_id in config.env_ids:
            env = make_env(env_id, seed, config.action_clip)
            device = torch.device("cpu")
            agent = Agent(env, config, device)
            mu0 = agent.get_params()
            std0 = 0.1 * np.ones_like(mu0)
            es = cma.CMAEvolutionStrategy(mu0, std0, {'popsize': config.popsize, 'seed': seed})
            pool = mp.Pool(processes=config.num_workers, initializer=None, maxtasksperchild=1)
            start_time = time.time()
            for gen in range(1, config.generations + 1):
                solutions = es.ask()
                args = [(s, env_id, seed, config) for s in solutions]
                results = pool.map(evaluate_solution, args)
                Rs = [r for r, _ in results]
                Hs = [h for _, h in results]
                es.tell(solutions, [-r for r in Rs])
                best_idx = np.argmin(es.fvals)
                best_solution = solutions[best_idx]
                best_reward = Rs[best_idx]
                avg_reward = np.mean(Rs)
                avg_horizon = np.mean(Hs)
                if gen % config.log_freq == 0:
                    elapsed = time.time() - start_time
                    log_line = f"{gen}, {elapsed:.2f}, {best_reward:.4f}, {avg_reward:.4f}, {avg_horizon:.2f}\n"
                    log.write(log_line)
                    log.flush()
                if gen % config.checkpoint_freq == 0:
                    agent.set_params(best_solution)
                    agent.checkpoint(f"{env_id}_seed{seed}_gen{gen}.pt", f"{env_id}_seed{seed}_gen{gen}.pt")
            pool.close()
            pool.join()
    print(f"Training completed for seed {seed}")

# Experiment execution
def run_experiment():
    config = Config()
    seeds = [1770966829, 1500925526, 2054191100]
    for seed in seeds:
        run(seed, config)

if __name__ == "__main__":
    run_experiment()