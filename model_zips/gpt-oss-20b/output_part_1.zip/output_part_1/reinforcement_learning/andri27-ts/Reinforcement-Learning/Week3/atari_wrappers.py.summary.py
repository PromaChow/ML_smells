import gym
import numpy as np
import cv2
from collections import deque
from gym.wrappers.frame_stack import FrameStack, LazyFrames


class MaxAndSkipEnv(gym.Wrapper):
    """Return max of last two observations and skip frames."""

    def __init__(self, env, skip=4):
        super().__init__(env)
        self._skip = skip
        self._obs_buffer = deque(maxlen=2)

    def step(self, action):
        total_reward = 0.0
        done = False
        info = {}
        for _ in range(self._skip):
            obs, reward, done, info = self.env.step(action)
            self._obs_buffer.append(obs)
            total_reward += reward
            if done:
                break
        max_frame = (
            np.maximum(self._obs_buffer[0], self._obs_buffer[1])
            if len(self._obs_buffer) == 2
            else self._obs_buffer[0]
        )
        return max_frame, total_reward, done, info

    def reset(self, **kwargs):
        obs = self.env.reset(**kwargs)
        self._obs_buffer.clear()
        self._obs_buffer.append(obs)
        return obs


class FireResetEnv(gym.Wrapper):
    """Automatically fires twice on reset for environments that need it."""

    def __init__(self, env):
        super().__init__(env)
        action_meanings = env.unwrapped.get_action_meanings()
        self.fire_action = action_meanings.index("FIRE") if "FIRE" in action_meanings else 1

    def reset(self, **kwargs):
        obs = self.env.reset(**kwargs)
        obs, _, done, _ = self.env.step(self.fire_action)
        if done:
            obs = self.env.reset(**kwargs)
        obs, _, done, _ = self.env.step(np.random.randint(self.env.action_space.n))
        if done:
            obs = self.env.reset(**kwargs)
        return obs


class WarpFrame(gym.ObservationWrapper):
    """Resize and convert to grayscale."""

    def __init__(self, env, width=84, height=84):
        super().__init__(env)
        self.width = width
        self.height = height
        self.observation_space = gym.spaces.Box(
            low=0, high=255, shape=(self.height, self.width), dtype=np.uint8
        )

    def observation(self, obs):
        obs = cv2.cvtColor(obs, cv2.COLOR_RGB2GRAY)
        obs = cv2.resize(obs, (self.width, self.height), interpolation=cv2.INTER_AREA)
        return obs


class ImageToPyTorch(gym.ObservationWrapper):
    """Rearrange to (C, H, W)."""

    def __init__(self, env):
        super().__init__(env)
        shape = env.observation_space.shape
        if len(shape) == 3:
            h, w, c = shape
            self.observation_space = gym.spaces.Box(
                low=0, high=255, shape=(c, h, w), dtype=shape[2]
            )
        else:
            h, w = shape
            self.observation_space = gym.spaces.Box(
                low=0, high=255, shape=(1, h, w), dtype=shape[0]
            )

    def observation(self, obs):
        if obs.ndim == 3:
            return obs.transpose((2, 0, 1))
        return obs[None, :, :]


class ScaledFloatFrame(gym.ObservationWrapper):
    """Scale pixel values to [0.0, 1.0] and cast to float32."""

    def __init__(self, env):
        super().__init__(env)
        shape = env.observation_space.shape
        self.observation_space = gym.spaces.Box(
            low=0.0, high=1.0, shape=shape, dtype=np.float32
        )

    def observation(self, obs):
        return obs.astype(np.float32) / 255.0


def make_atari(env_name: str, fire: bool = True) -> gym.Env:
    """Create an Atari environment with standard preprocessing."""
    env = gym.make(env_name)
    env = MaxAndSkipEnv(env, skip=4)
    if fire:
        env = FireResetEnv(env)
    env = WarpFrame(env)
    env = ImageToPyTorch(env)
    env = FrameStack(env, 4, channel_last=False)
    env = ScaledFloatFrame(env)
    return env
