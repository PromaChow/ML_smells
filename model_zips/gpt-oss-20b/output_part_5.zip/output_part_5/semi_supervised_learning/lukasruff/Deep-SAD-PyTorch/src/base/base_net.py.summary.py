import logging
import numpy as np
import torch
import torch.nn as nn


class BaseNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.logger = logging.getLogger(self.__class__.__name__)
        self.rep_dim = None

    def forward(self, *inputs, **kwargs):
        raise NotImplementedError("Subclasses must implement the forward method.")

    def summary(self):
        trainable_params = sum(
            np.prod(p.size()) for p in filter(lambda p: p.requires_grad, self.parameters())
        )
        self.logger.info(f"Trainable parameters: {trainable_params}")
        self.logger.info(str(self))
        return trainable_params
