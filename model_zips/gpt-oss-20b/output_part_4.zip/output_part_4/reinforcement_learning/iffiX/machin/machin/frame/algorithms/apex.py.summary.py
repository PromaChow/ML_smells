import torch
import torch.nn as nn
from torch.nn.parallel import DistributedDataParallel
from typing import Any, Dict

# Assume these classes exist in the respective modules
try:
    from your_rl_lib.dqn import DQNPer
    from your_rl_lib.ddpg import DDPGPer
    from your_rl_lib.prioritized_buffer import DistributedPrioritizedBuffer
    from machin.rpc import PushPullModelServer, RpcGroup
except Exception:
    # Placeholder stubs for demonstration purposes
    class DQNPer:
        def __init__(self, qnet, optimizer, criterion, train_params, **kwargs): pass
        def act_discrete(self, state): pass
        def act_discrete_with_noise(self, state): pass
        def update(self): pass

    class DDPGPer:
        def __init__(self, actor, critic, optimizer, criterion, train_params, **kwargs): pass
        def act(self, state): pass
        def act_with_noise(self, state): pass
        def act_discrete_with_noise(self, state): pass
        def update(self): pass

    class DistributedPrioritizedBuffer:
        def __init__(self, rpc_group, buffer_size, priority_alpha): pass

    class PushPullModelServer:
        def __init__(self, name, rpc_group, model): pass
        def pull(self): return {}
        def push(self, state_dict): pass

    class RpcGroup:
        def __init__(self, name, rank, world_size): pass


def _disable_update(self, *args, **kwargs):
    pass


class DQNApex(DQNPer):
    def __init__(self, qnet: nn.Module, optimizer: Any, criterion: Any,
                 train_params: Dict[str, Any], **kwargs):
        super().__init__(qnet, optimizer, criterion, train_params, **kwargs)
        self.buffer = None
        self.model_server = None
        self.is_syncing = True
        self.is_learner = False

    def act_discrete(self, state):
        self.manual_sync()
        return super().act_discrete(state)

    def act_discrete_with_noise(self, state):
        self.manual_sync()
        return super().act_discrete_with_noise(state)

    def update(self):
        if self.is_learner:
            super().update()
            if self.model_server:
                self.model_server.push(self.qnet.state_dict())

    def manual_sync(self):
        if self.is_syncing and not isinstance(self.qnet, DistributedDataParallel):
            pulled = self.model_server.pull()
            self.qnet.load_state_dict(pulled)

    @staticmethod
    def generate_config(config: Dict[str, Any] = None) -> Dict[str, Any]:
        defaults = {
            "learning_rate": 1e-3,
            "buffer_size": 100000,
            "group_name": "dqn_group",
            "learner_rank": 0,
            "priority_alpha": 0.6,
        }
        if config is None:
            config = {}
        defaults.update(config)
        return defaults

    @classmethod
    def init_from_config(cls, qnet: nn.Module, optimizer: Any, criterion: Any,
                         train_params: Dict[str, Any], user_config: Dict[str, Any] = None):
        config = cls.generate_config(user_config)
        rank = torch.distributed.get_rank() if torch.distributed.is_available() and torch.distributed.is_initialized() else 0
        world_size = torch.distributed.get_world_size() if torch.distributed.is_available() and torch.distributed.is_initialized() else 1
        rpc_group = RpcGroup(name=config["group_name"], rank=rank, world_size=world_size)

        buffer = DistributedPrioritizedBuffer(rpc_group, config["buffer_size"], config["priority_alpha"])
        model_server = PushPullModelServer(name="qnet_server", rpc_group=rpc_group, model=qnet)

        if rank == config["learner_rank"]:
            qnet = DistributedDataParallel(qnet)

        instance = cls(qnet, optimizer, criterion, train_params)
        instance.buffer = buffer
        instance.model_server = model_server
        instance.is_syncing = True
        instance.is_learner = (rank == config["learner_rank"])
        if not instance.is_learner:
            instance.update = _disable_update
        return instance


class DDPGApex(DDPGPer):
    def __init__(self, actor: nn.Module, critic: nn.Module,
                 optimizer: Any, criterion: Any,
                 train_params: Dict[str, Any], **kwargs):
        super().__init__(actor, critic, optimizer, criterion, train_params, **kwargs)
        self.buffer = None
        self.model_server = None
        self.is_syncing = True
        self.is_learner = False

    def act(self, state):
        self.manual_sync()
        return super().act(state)

    def act_with_noise(self, state):
        self.manual_sync()
        return super().act_with_noise(state)

    def act_discrete_with_noise(self, state):
        self.manual_sync()
        return super().act_discrete_with_noise(state)

    def update(self):
        if self.is_learner:
            super().update()
            if self.model_server:
                self.model_server.push(self.actor.state_dict())

    def manual_sync(self):
        if self.is_syncing and not isinstance(self.actor, DistributedDataParallel):
            pulled = self.model_server.pull()
            self.actor.load_state_dict(pulled)

    @staticmethod
    def generate_config(config: Dict[str, Any] = None) -> Dict[str, Any]:
        defaults = {
            "actor_learning_rate": 1e-4,
            "critic_learning_rate": 1e-3,
            "buffer_size": 100000,
            "group_name": "ddpg_group",
            "learner_rank": 0,
            "priority_alpha": 0.6,
        }
        if config is None:
            config = {}
        defaults.update(config)
        return defaults

    @classmethod
    def init_from_config(cls, actor: nn.Module, critic: nn.Module,
                         optimizer: Any, criterion: Any,
                         train_params: Dict[str, Any], user_config: Dict[str, Any] = None):
        config = cls.generate_config(user_config)
        rank = torch.distributed.get_rank() if torch.distributed.is_available() and torch.distributed.is_initialized() else 0
        world_size = torch.distributed.get_world_size() if torch.distributed.is_available() and torch.distributed.is_initialized() else 1
        rpc_group = RpcGroup(name=config["group_name"], rank=rank, world_size=world_size)

        buffer = DistributedPrioritizedBuffer(rpc_group, config["buffer_size"], config["priority_alpha"])
        model_server = PushPullModelServer(name="actor_server", rpc_group=rpc_group, model=actor)

        if rank == config["learner_rank"]:
            actor = DistributedDataParallel(actor)

        instance = cls(actor, critic, optimizer, criterion, train_params)
        instance.buffer = buffer
        instance.model_server = model_server
        instance.is_syncing = True
        instance.is_learner = (rank == config["learner_rank"])
        if not instance.is_learner:
            instance.update = _disable_update
        return instance
