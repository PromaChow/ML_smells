import torch
import torch.nn as nn
import torch.nn.functional as F

def make_rnncell(input_dim, hidden_sizes, cell_type='LSTMCell'):
    """
    Create a sequence of RNN cells.

    Args:
        input_dim (int): Dimensionality of the input features.
        hidden_sizes (list of int): Hidden sizes for each layer.
        cell_type (str): Type of the RNN cell ('LSTMCell', 'GRUCell', 'LayerNormLSTMCell', etc.).

    Returns:
        nn.ModuleList: Module list containing the RNN cells.
    """
    if not isinstance(hidden_sizes, list):
        raise TypeError('hidden_sizes must be a list of integers')

    # Map string names to actual nn modules
    cell_map = {
        'LSTMCell': nn.LSTMCell,
        'GRUCell': nn.GRUCell,
        'LayerNormLSTMCell': None  # placeholder for custom cell
    }

    if cell_type not in cell_map:
        raise ValueError(f'Unsupported cell type: {cell_type}')

    cell_cls = cell_map[cell_type]
    if cell_type == 'LayerNormLSTMCell':
        # Assume LayerNormLSTMCell is defined elsewhere in the namespace
        cell_cls = globals().get('LayerNormLSTMCell')
        if cell_cls is None:
            raise ImportError('LayerNormLSTMCell class must be defined before use')

    # Prepare input sizes for each layer
    input_sizes = [input_dim] + hidden_sizes

    cells = []
    for in_dim, hid_dim in zip(input_sizes[:-1], input_sizes[1:]):
        cells.append(cell_cls(in_dim, hid_dim))

    return nn.ModuleList(cells)

class LayerNormLSTM(nn.Module):
    """
    Layer-normalized LSTM with optional inter-layer dropout.
    """
    def __init__(self, input_dim, hidden_size, num_layers=1, dropout=0.0):
        super().__init__()
        if dropout > 0.0 and num_layers < 2:
            raise ValueError('Dropout can only be applied when there are at least two layers')

        self.input_dim = input_dim
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.dropout = dropout

        hidden_sizes = [hidden_size] * num_layers
        self.ln_cells = make_rnncell(input_dim, hidden_sizes, cell_type='LayerNormLSTMCell')

    def forward(self, x, h=None, c=None):
        """
        Args:
            x (Tensor): Input tensor of shape (seq_len, batch, input_dim).
            h (list of Tensor or None): Initial hidden states per layer, each of shape (batch, hidden_size).
            c (list of Tensor or None): Initial cell states per layer, each of shape (batch, hidden_size).

        Returns:
            Tuple[Tensor, Tuple[list, list]]: Output tensor of shape (seq_len, batch, hidden_size)
                and tuple containing lists of final hidden and cell states.
        """
        seq_len, batch, _ = x.size()

        # Initialize hidden and cell states if not provided
        if h is None:
            h = [torch.zeros(batch, self.hidden_size, device=x.device, dtype=x.dtype)
                 for _ in range(self.num_layers)]
        if c is None:
            c = [torch.zeros(batch, self.hidden_size, device=x.device, dtype=x.dtype)
                 for _ in range(self.num_layers)]

        for layer_idx, cell in enumerate(self.ln_cells):
            layer_h = h[layer_idx]
            layer_c = c[layer_idx]
            outputs = []

            for t in range(seq_len):
                layer_h, layer_c = cell(x[t], (layer_h, layer_c))
                outputs.append(layer_h.unsqueeze(0))

            layer_out = torch.cat(outputs, dim=0)  # (seq_len, batch, hidden_size)

            # Prepare for next layer
            x = layer_out

            # Apply dropout between layers, except after the last layer
            if self.dropout > 0.0 and layer_idx < self.num_layers - 1:
                dropout_mask = torch.bernoulli(
                    torch.full_like(x, 1 - self.dropout),
                    generator=torch.Generator(device=x.device)
                )
                x = x * dropout_mask / (1 - self.dropout)

            # Update hidden and cell states
            h[layer_idx] = layer_h
            c[layer_idx] = layer_c

        return x, (h, c)