import numpy as np

class Pusher(MJCFBasedRobot):
    # Placement constraints
    min_target_placement_radius = 0.05
    max_target_placement_radius = 0.2
    min_object_to_target_distance = 0.05
    max_object_to_target_distance = 0.15

    def __init__(self, *args, **kwargs):
        super().__init__(
            'pusher.xml',
            body='body0',
            action_dim=7,
            obs_dim=55,
            *args,
            **kwargs
        )
        # Cache relevant body parts and joints
        self.fingertip = self.model.get_body('fingertip')
        self.target = self.model.get_body('goal')
        self.object = self.model.get_body('object')
        self.shoulder_joint = self.model.get_joint('shoulder')
        self.elbow_joint = self.model.get_joint('elbow')
        self.wrist_joint = self.model.get_joint('wrist')
        self.joints = [
            self.shoulder_joint,
            self.elbow_joint,
            self.wrist_joint,
            self.model.get_joint('joint4'),
            self.model.get_joint('joint5'),
            self.model.get_joint('joint6'),
            self.model.get_joint('joint7')
        ]
        self.zero_offset = np.array([0.45, 0.55])

    def robot_specific_reset(self):
        # Target position initialization
        target_vec = np.random.uniform(-1, 1, size=2)
        norm = np.linalg.norm(target_vec)
        if norm == 0:
            target_vec = np.array([1.0, 0.0])
            norm = 1.0
        target_vec /= norm
        radius = np.random.uniform(
            self.min_target_placement_radius,
            self.max_target_placement_radius
        )
        target_pos = target_vec * radius
        # Object position initialization
        object_vec = np.random.uniform(-1, 1, size=2)
        norm = np.linalg.norm(object_vec)
        if norm == 0:
            object_vec = np.array([1.0, 0.0])
            norm = 1.0
        object_vec /= norm
        distance = np.random.uniform(
            self.min_object_to_target_distance,
            self.max_object_to_target_distance
        )
        object_pos = target_pos + object_vec * distance
        # Assign positions to sliders
        self.model.get_slider('goal_slidex').set_position(
            target_pos[0] + self.zero_offset[0]
        )
        self.model.get_slider('goal_slidey').set_position(
            target_pos[1] + self.zero_offset[1]
        )
        self.model.get_slider('obj_slidex').set_position(
            object_pos[0] + self.zero_offset[0]
        )
        self.model.get_slider('obj_slidey').set_position(
            object_pos[1] + self.zero_offset[1]
        )
        # Randomize joint angles
        for joint in self.joints:
            joint.set_angle(np.random.uniform(-3.14, 3.14))

    def apply_action(self, action):
        for i, joint in enumerate(self.joints):
            torque = action[i] * 0.05
            torque = np.clip(torque, -1, 1)
            joint.set_torque(torque)

    def calc_state(self):
        qpos = np.array([joint.qpos for joint in self.joints])
        qvel = np.array([joint.qvel for joint in self.joints])
        fingertip_pos = self.fingertip.com
        object_pos = self.object.com
        target_pos = self.target.com
        state = np.concatenate([qpos, qvel, fingertip_pos, object_pos, target_pos])
        # Pad to required observation dimension
        if len(state) < self.obs_dim:
            state = np.pad(state, (0, self.obs_dim - len(state)), 'constant')
        return state[:self.obs_dim]