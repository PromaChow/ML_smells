import pandas as pd

df = pd.read_csv('SalaryGender.csv')
age_phd = df[['Age', 'PhD']]
indices_to_drop = age_phd[age_phd['PhD'] == 0].index
age_phd = age_phd.drop(indices_to_drop)
final_df = age_phd