import torch
import torch.nn as nn
import torch.nn.functional as F

class FashionMNIST_LeNet(nn.Module):
    def __init__(self, rep_dim: int):
        super().__init__()
        self.rep_dim = rep_dim

        # Convolutional layers
        self.conv1 = nn.Conv2d(1, 16, kernel_size=5, padding=2, bias=False)
        self.bn1 = nn.BatchNorm2d(16, eps=1e-04, affine=False)
        self.conv2 = nn.Conv2d(16, 32, kernel_size=5, padding=2, bias=False)
        self.bn2 = nn.BatchNorm2d(32, eps=1e-04, affine=False)

        # Fully connected layers
        self.fc1 = nn.Linear(32 * 7 * 7, 128, bias=False)
        self.bn_fc1 = nn.BatchNorm1d(128, eps=1e-04, affine=False)
        self.fc2 = nn.Linear(128, rep_dim, bias=False)

        self.activation = nn.LeakyReLU(inplace=True)
        self.pool = nn.MaxPool2d(kernel_size=2, stride=2)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x shape: (batch, 784)
        x = x.view(-1, 1, 28, 28)
        x = self.activation(self.bn1(self.conv1(x)))
        x = self.pool(x)
        x = self.activation(self.bn2(self.conv2(x)))
        x = self.pool(x)
        x = x.view(-1, 32 * 7 * 7)
        x = self.activation(self.bn_fc1(self.fc1(x)))
        x = self.fc2(x)
        return x


class FashionMNIST_LeNet_Decoder(nn.Module):
    def __init__(self, rep_dim: int):
        super().__init__()
        self.rep_dim = rep_dim

        self.fc = nn.Linear(rep_dim, 128, bias=False)
        self.bn_fc = nn.BatchNorm1d(128, eps=1e-04, affine=False)

        # Reshape to (batch, 8, 4, 4) after fc
        # Deconvolutional layers
        self.deconv1 = nn.ConvTranspose2d(8, 32, kernel_size=4, stride=2, padding=1, bias=False)
        self.bn_deconv1 = nn.BatchNorm2d(32, eps=1e-04, affine=False)

        self.deconv2 = nn.ConvTranspose2d(32, 16, kernel_size=4, stride=2, padding=1, bias=False)
        self.bn_deconv2 = nn.BatchNorm2d(16, eps=1e-04, affine=False)

        self.deconv3 = nn.ConvTranspose2d(16, 1, kernel_size=4, stride=2, padding=1, bias=False)
        # Final conv to get 28x28
        self.conv_final = nn.Conv2d(1, 1, kernel_size=5, stride=1, padding=2, bias=False)

        self.activation = nn.LeakyReLU(inplace=True)

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        x = self.activation(self.bn_fc(self.fc(z)))
        x = x.view(-1, 8, 4, 4)

        x = self.activation(self.bn_deconv1(self.deconv1(x)))
        x = self.activation(self.bn_deconv2(self.deconv2(x)))
        x = self.activation(self.deconv3(x))
        x = self.conv_final(x)
        x = torch.sigmoid(x)
        return x


class FashionMNIST_LeNet_Autoencoder(nn.Module):
    def __init__(self, rep_dim: int):
        super().__init__()
        self.encoder = FashionMNIST_LeNet(rep_dim)
        self.decoder = FashionMNIST_LeNet_Decoder(rep_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        z = self.encoder(x)
        recon = self.decoder(z)
        recon_flat = recon.view(-1, 28 * 28)
        return recon_flat
