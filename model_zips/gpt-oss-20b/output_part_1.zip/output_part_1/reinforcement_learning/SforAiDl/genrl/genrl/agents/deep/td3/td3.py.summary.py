import copy
import random
import collections
from typing import Tuple, List, Dict, Callable, Optional

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim


# Replay buffer
class ReplayBuffer:
    def __init__(self, capacity: int, state_dim: int, action_dim: int):
        self.capacity = capacity
        self.ptr = 0
        self.size = 0
        self.states = np.zeros((capacity, state_dim), dtype=np.float32)
        self.actions = np.zeros((capacity, action_dim), dtype=np.float32)
        self.rewards = np.zeros((capacity, 1), dtype=np.float32)
        self.next_states = np.zeros((capacity, state_dim), dtype=np.float32)
        self.dones = np.zeros((capacity, 1), dtype=np.float32)

    def add(self, state, action, reward, next_state, done):
        self.states[self.ptr] = state
        self.actions[self.ptr] = action
        self.rewards[self.ptr] = reward
        self.next_states[self.ptr] = next_state
        self.dones[self.ptr] = done
        self.ptr = (self.ptr + 1) % self.capacity
        self.size = min(self.size + 1, self.capacity)

    def sample(self, batch_size: int) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        idxs = np.random.choice(self.size, batch_size, replace=False)
        batch = dict(
            state=self.states[idxs],
            action=self.actions[idxs],
            reward=self.rewards[idxs],
            next_state=self.next_states[idxs],
            done=self.dones[idxs],
        )
        return (
            torch.FloatTensor(batch["state"]),
            torch.FloatTensor(batch["action"]),
            torch.FloatTensor(batch["reward"]),
            torch.FloatTensor(batch["next_state"]),
            torch.FloatTensor(batch["done"]),
        )


# Actor network
class Actor(nn.Module):
    def __init__(self, state_dim: int, action_dim: int, hidden_sizes: List[int], action_limit: float):
        super().__init__()
        layers = []
        last_dim = state_dim
        for h in hidden_sizes:
            layers.append(nn.Linear(last_dim, h))
            layers.append(nn.ReLU())
            last_dim = h
        layers.append(nn.Linear(last_dim, action_dim))
        self.model = nn.Sequential(*layers)
        self.action_limit = action_limit

    def forward(self, state: torch.Tensor) -> torch.Tensor:
        return torch.tanh(self.model(state)) * self.action_limit


# Critic network (Q1 and Q2)
class Critic(nn.Module):
    def __init__(self, state_dim: int, action_dim: int, hidden_sizes: List[int]):
        super().__init__()
        def build_q():
            layers = []
            last_dim = state_dim + action_dim
            for h in hidden_sizes:
                layers.append(nn.Linear(last_dim, h))
                layers.append(nn.ReLU())
                last_dim = h
            layers.append(nn.Linear(last_dim, 1))
            return nn.Sequential(*layers)
        self.q1 = build_q()
        self.q2 = build_q()

    def forward(self, state: torch.Tensor, action: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        sa = torch.cat([state, action], dim=-1)
        return self.q1(sa), self.q2(sa)


# TD3 Agent
class TD3Agent:
    def __init__(
        self,
        env,
        *,
        policy_frequency: int = 2,
        noise_std: float = 0.2,
        noise_clip: float = 0.5,
        policy_lr: float = 1e-3,
        q_lr: float = 1e-3,
        gamma: float = 0.99,
        tau: float = 0.005,
        buffer_capacity: int = 1_000_000,
        batch_size: int = 256,
        hidden_sizes: List[int] = [400, 300],
        network_type: str = "mlp",
        create_model: bool = True,
        device: Optional[str] = None,
        noise: Optional[Callable[[int], np.ndarray]] = None,
    ):
        self.env = env
        self.policy_frequency = policy_frequency
        self.noise_std = noise_std
        self.noise_clip = noise_clip
        self.policy_lr = policy_lr
        self.q_lr = q_lr
        self.gamma = gamma
        self.tau = tau
        self.batch_size = batch_size
        self.hidden_sizes = hidden_sizes
        self.network_type = network_type
        self.create_model = create_model

        self.device = torch.device(device if device else ("cuda" if torch.cuda.is_available() else "cpu"))

        # Environment properties
        obs_space = env.observation_space
        action_space = env.action_space
        if not hasattr(action_space, "shape"):
            raise ValueError("Discrete environments are not supported")
        self.state_dim = obs_space.shape[0]
        self.action_dim = action_space.shape[0]
        self.action_limit = action_space.high[0]  # assume symmetric

        # Noise function
        if noise is None:
            self.noise = lambda size: np.random.normal(0, self.noise_std, size=size)
        else:
            self.noise = noise

        # Replay buffer
        self.buffer = ReplayBuffer(buffer_capacity, self.state_dim, self.action_dim)

        # Hyperparameters dict
        self.hyperparams: Dict[str, any] = {
            "policy_frequency": policy_frequency,
            "noise_std": noise_std,
            "noise_clip": noise_clip,
            "policy_lr": policy_lr,
            "q_lr": q_lr,
            "gamma": gamma,
            "tau": tau,
            "batch_size": batch_size,
            "hidden_sizes": hidden_sizes,
            "network_type": network_type,
        }

        # Initialize models
        if create_model:
            self._create_models()

        # Logging
        self.policy_losses: List[float] = []
        self.value_losses: List[float] = []
        self.total_it = 0

    def _create_models(self):
        self.actor = Actor(self.state_dim, self.action_dim, self.hidden_sizes, self.action_limit).to(self.device)
        self.actor_target = copy.deepcopy(self.actor).to(self.device)
        self.critic = Critic(self.state_dim, self.action_dim, self.hidden_sizes).to(self.device)
        self.critic_target = copy.deepcopy(self.critic).to(self.device)

        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=self.policy_lr)
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=self.q_lr)

        # Ensure target networks start with same weights
        for target_param, param in zip(self.actor_target.parameters(), self.actor.parameters()):
            target_param.data.copy_(param.data)
        for target_param, param in zip(self.critic_target.parameters(), self.critic.parameters()):
            target_param.data.copy_(param.data)

    def select_action(self, state: np.ndarray, noise: bool = True) -> np.ndarray:
        state_t = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        action = self.actor(state_t).cpu().data.numpy().flatten()
        if noise:
            action += self.noise(self.action_dim)
            action = np.clip(action, -self.action_limit, self.action_limit)
        return action

    def train_step(self):
        if self.buffer.size < self.batch_size:
            return

        self.total_it += 1
        states, actions, rewards, next_states, dones = self.buffer.sample(self.batch_size)

        states = states.to(self.device)
        actions = actions.to(self.device)
        rewards = rewards.to(self.device)
        next_states = next_states.to(self.device)
        dones = dones.to(self.device)

        with torch.no_grad():
            next_actions = self.actor_target(next_states)
            noise = (torch.randn_like(next_actions) * self.noise_std).clamp(-self.noise_clip, self.noise_clip)
            next_actions = (next_actions + noise).clamp(-self.action_limit, self.action_limit)
            q1_next, q2_next = self.critic_target(next_states, next_actions)
            q_next = torch.min(q1_next, q2_next)
            q_target = rewards + (1 - dones) * self.gamma * q_next

        q1, q2 = self.critic(states, actions)
        critic_loss = nn.functional.mse_loss(q1, q_target) + nn.functional.mse_loss(q2, q_target)
        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        self.critic_optimizer.step()
        self.value_losses.append(critic_loss.item())

        if self.total_it % self.policy_frequency == 0:
            actor_actions = self.actor(states)
            actor_loss = -self.critic.q1(states, actor_actions).mean()
            self.actor_optimizer.zero_grad()
            actor_loss.backward()
            self.actor_optimizer.step()
            self.policy_losses.append(actor_loss.item())

            # Soft update
            for target_param, param in zip(self.actor_target.parameters(), self.actor.parameters()):
                target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)
            for target_param, param in zip(self.critic_target.parameters(), self.critic.parameters()):
                target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)

    def log_and_reset(self):
        avg_policy_loss = np.mean(self.policy_losses) if self.policy_losses else None
        avg_value_loss = np.mean(self.value_losses) if self.value_losses else None
        print(f"Policy loss: {avg_policy_loss:.6f}, Value loss: {avg_value_loss:.6f}")
        self.policy_losses = []
        self.value_losses = []

    def store_experience(self, state, action, reward, next_state, done):
        self.buffer.add(state, action, reward, next_state, done)

    def save_hyperparams(self, path: str):
        import json
        with open(path, "w") as f:
            json.dump(self.hyperparams, f, indent=4)

    def load_hyperparams(self, path: str):
        import json
        with open(path, "r") as f:
            self.hyperparams = json.load(f)


# Example usage (placeholder, not part of the module)
if __name__ == "__main__":
    import gym

    env = gym.make("Pendulum-v1")
    agent = TD3Agent(env)
    num_steps = 10000
    episode_reward = 0
    state = env.reset()
    for t in range(num_steps):
        action = agent.select_action(state)
        next_state, reward, done, _ = env.step(action)
        agent.store_experience(state, action, reward, next_state, float(done))
        agent.train_step()
        if t % 1000 == 0:
            agent.log_and_reset()
        state = next_state
        episode_reward += reward
        if done:
            print(f"Episode finished with reward {episode_reward}")
            state = env.reset()
            episode_reward = 0
    env.close()
