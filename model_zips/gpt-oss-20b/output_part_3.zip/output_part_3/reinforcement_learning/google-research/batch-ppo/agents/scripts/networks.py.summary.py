import tensorflow as tf
import gym
import numpy as np


class AttrDict(dict):
    def __init__(self, *args, **kwargs):
        super(AttrDict, self).__init__(*args, **kwargs)

    def __getattr__(self, item):
        return self[item]


class CustomKLDiagNormal(tf.contrib.distributions.MultivariateNormalDiag):
    def __init__(self, loc, scale_diag, validate_args=False, allow_nan_stats=True, name="CustomKLDiagNormal"):
        super(CustomKLDiagNormal, self).__init__(loc=loc,
                                                 scale_diag=scale_diag,
                                                 validate_args=validate_args,
                                                 allow_nan_stats=allow_nan_stats,
                                                 name=name)


def _custom_kl(p, q):
    """Empirical KL divergence between two CustomKLDiagNormal distributions."""
    mu_p = p.loc
    sigma_p = p.scale_diag
    mu_q = q.loc
    sigma_q = q.scale_diag
    # Compute element-wise KL
    log_sigma_q_over_sigma_p = tf.math.log(sigma_q / sigma_p)
    term1 = (sigma_p ** 2 + (mu_p - mu_q) ** 2) / (2.0 * sigma_q ** 2)
    kl = tf.reduce_sum(log_sigma_q_over_sigma_p + term1 - 0.5, axis=-1)
    return kl


tf.register_kl_divergence(CustomKLDiagNormal, CustomKLDiagNormal, _custom_kl)


def _flatten_obs(obs):
    """Flatten observations into a 2-D tensor [batch, features]."""
    shape = tf.shape(obs)
    return tf.reshape(obs, [shape[0], -1])


def feed_forward_gaussian_policy(obs, action_space, config, name="ff_gaussian"):
    if not isinstance(action_space, gym.spaces.Box):
        raise ValueError("Action space must be a continuous gym.spaces.Box")
    if len(action_space.shape) != 1:
        raise ValueError("Action space must be 1-D")

    action_dim = action_space.shape[0]
    hidden_size = config.get("hidden_size", 64)
    num_layers = config.get("num_layers", 2)
    log_std_init = config.get("log_std_init", 0.0)

    with tf.variable_scope(name):
        x = _flatten_obs(obs)
        hidden = x
        for i in range(num_layers):
            hidden = tf.layers.dense(hidden,
                                     hidden_size,
                                     activation=tf.nn.relu,
                                     name="hidden_fc{}".format(i))

        mean = tf.layers.dense(hidden,
                               action_dim,
                               activation=tf.nn.tanh,
                               name="mean")
        log_std = tf.get_variable("log_std",
                                  shape=[action_dim],
                                  initializer=tf.constant_initializer(log_std_init))
        std = tf.nn.softplus(log_std, name="std")

        mean = tf.check_numerics(mean, "mean")
        std = tf.check_numerics(std, "std")

        value = tf.layers.dense(hidden,
                                1,
                                activation=None,
                                name="value")
        value = tf.squeeze(value, axis=-1)
        value = tf.check_numerics(value, "value")

        policy = CustomKLDiagNormal(loc=mean,
                                    scale_diag=std,
                                    name="policy_dist")

    return AttrDict(policy=policy, value=value, state=None)


def feed_forward_categorical_policy(obs, action_space, config, name="ff_categorical"):
    if not isinstance(action_space, gym.spaces.Discrete):
        raise ValueError("Action space must be a discrete gym.spaces.Discrete")

    action_dim = action_space.n
    hidden_size = config.get("hidden_size", 64)
    num_layers = config.get("num_layers", 2)

    with tf.variable_scope(name):
        x = _flatten_obs(obs)
        hidden = x
        for i in range(num_layers):
            hidden = tf.layers.dense(hidden,
                                     hidden_size,
                                     activation=tf.nn.relu,
                                     name="hidden_fc{}".format(i))

        logits = tf.layers.dense(hidden,
                                 action_dim,
                                 activation=None,
                                 name="logits")

        policy = tf.contrib.distributions.Categorical(logits=logits,
                                                       name="policy_dist")

        value = tf.layers.dense(hidden,
                                1,
                                activation=None,
                                name="value")
        value = tf.squeeze(value, axis=-1)

    return AttrDict(policy=policy, value=value, state=None)


def recurrent_gaussian_policy(obs, action_space, config, name="rnn_gaussian"):
    if not isinstance(action_space, gym.spaces.Box):
        raise ValueError("Action space must be a continuous gym.spaces.Box")
    if len(action_space.shape) != 1:
        raise ValueError("Action space must be 1-D")

    action_dim = action_space.shape[0]
    hidden_size = config.get("hidden_size", 64)
    num_layers = config.get("num_layers", 2)
    rnn_hidden_size = config.get("rnn_hidden_size", 128)
    log_std_init = config.get("log_std_init", 0.0)

    with tf.variable_scope(name):
        # obs shape: [batch, time, ...]
        obs_shape = tf.shape(obs)
        seq_len = obs_shape[1]
        flat_features = tf.reduce_prod(tf.shape(obs)[2:])
        x = tf.reshape(obs, [obs_shape[0], seq_len, -1])

        hidden = x
        for i in range(num_layers):
            hidden = tf.layers.dense(hidden,
                                     hidden_size,
                                     activation=tf.nn.relu,
                                     name="hidden_fc{}".format(i))

        gru_cell = tf.contrib.rnn.GRUBlockCell(rnn_hidden_size, name="gru")
        rnn_outputs, final_state = tf.nn.dynamic_rnn(gru_cell,
                                                     hidden,
                                                     dtype=tf.float32,
                                                     time_major=False)

        last_output = rnn_outputs[:, -1, :]
        mean = tf.layers.dense(last_output,
                               action_dim,
                               activation=tf.nn.tanh,
                               name="mean")
        log_std = tf.get_variable("log_std",
                                  shape=[action_dim],
                                  initializer=tf.constant_initializer(log_std_init))
        std = tf.nn.softplus(log_std, name="std")

        mean = tf.check_numerics(mean, "mean")
        std = tf.check_numerics(std, "std")

        value = tf.layers.dense(last_output,
                                1,
                                activation=None,
                                name="value")
        value = tf.squeeze(value, axis=-1)
        value = tf.check_numerics(value, "value")

        policy = CustomKLDiagNormal(loc=mean,
                                    scale_diag=std,
                                    name="policy_dist")

    return AttrDict(policy=policy, value=value, state=final_state)