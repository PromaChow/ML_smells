import torch
from torch import nn
from torch.utils.data import Dataset, DataLoader
from dataclasses import dataclass
import pytorch_lightning as pl
import pytest

# 1. Model definition
class QNet(nn.Module):
    def __init__(self, state_dim: int, action_dim: int):
        super().__init__()
        self.fc1 = nn.Linear(state_dim, 64)
        self.fc2 = nn.Linear(64, 64)
        self.fc3 = nn.Linear(64, action_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return self.fc3(x)

# 2. Dataset result container
@dataclass
class DatasetResult:
    state: torch.Tensor
    action: torch.Tensor
    next_state: torch.Tensor
    reward: torch.Tensor
    terminal: torch.Tensor

# 3. Fake dataset
class FakeDataset(Dataset):
    def __len__(self) -> int:
        return 10

    def __getitem__(self, idx: int) -> DatasetResult:
        state = torch.randn(4)
        action = torch.tensor([1 if i == idx % 2 else 0 for i in range(2)], dtype=torch.long)
        next_state = torch.randn(4)
        reward = torch.tensor(1.0)
        terminal = torch.tensor(0.0)
        return DatasetResult(state, action, next_state, reward, terminal)

# 4. Configuration generation
def generate_config():
    return {
        'state_dim': 4,
        'action_dim': 2,
    }

# 5. Dataset creator
def fake_env_dataset_creator():
    return FakeDataset()

# 6. Launcher (PyTorch Lightning module)
class Launcher(pl.LightningModule):
    def __init__(self, config: dict, dataset_creator):
        super().__init__()
        self.config = config
        self.dataset_creator = dataset_creator
        self.model = QNet(config['state_dim'], config['action_dim'])
        self.test_log_value = None

    def on_train_start(self):
        self.backward_fn = lambda x: x.backward()

    def on_test_start(self):
        self.test_backward_fn = lambda x: x.backward()

    def configure_optimizers(self):
        optimizer = torch.optim.Adam(self.parameters())
        return [optimizer], []

    def train_dataloader(self):
        return DataLoader(self.dataset_creator(), batch_size=4)

    def test_dataloader(self):
        return DataLoader(self.dataset_creator(), batch_size=4)

    def training_step(self, batch: DatasetResult, batch_idx: int):
        logits = self.model(batch.state)
        loss = nn.functional.mse_loss(logits, torch.randn_like(logits))
        self.test_log_value = 1
        self.log('test_log', 1)
        return loss

    def test_step(self, batch: DatasetResult, batch_idx: int):
        logits = self.model(batch.state)
        loss = nn.functional.mse_loss(logits, torch.randn_like(logits))
        self.test_log_value = 1
        self.log('test_log', 1)
        return loss

# 7. Fixtures
@pytest.fixture
def launcher():
    cfg = generate_config()
    return Launcher(cfg, fake_env_dataset_creator)

@pytest.fixture
def real_launcher():
    cfg = generate_config()
    return Launcher(cfg, fake_env_dataset_creator)

# 8. Tests
def test_on_train_start(launcher):
    launcher.on_train_start()
    assert hasattr(launcher, 'backward_fn')

def test_on_test_start(launcher):
    launcher.on_test_start()
    assert hasattr(launcher, 'test_backward_fn')

def test_train_dataloader(launcher):
    loader = launcher.train_dataloader()
    batch = next(iter(loader))
    assert isinstance(batch, DatasetResult)
    assert hasattr(batch, 'state')

def test_test_dataloader(launcher):
    loader = launcher.test_dataloader()
    batch = next(iter(loader))
    assert isinstance(batch, DatasetResult)
    assert hasattr(batch, 'state')

def test_training_step(launcher):
    batch = next(iter(launcher.train_dataloader()))
    loss = launcher.training_step(batch, 0)
    assert isinstance(loss, torch.Tensor)
    assert launcher.test_log_value == 1

def test_test_step(launcher):
    batch = next(iter(launcher.test_dataloader()))
    loss = launcher.test_step(batch, 0)
    assert isinstance(loss, torch.Tensor)
    assert launcher.test_log_value == 1

def test_configure_optimizers(launcher):
    optimizers, schedulers = launcher.configure_optimizers()
    assert isinstance(optimizers, list)
    assert len(optimizers) == 1
    assert isinstance(schedulers, list)
    assert len(schedulers) == 0

def test_real(real_launcher):
    trainer = pl.Trainer(max_epochs=1, limit_train_batches=1, limit_val_batches=1, enable_checkpointing=False, enable_progress_bar=False)
    trainer.fit(real_launcher)
    assert trainer.current_epoch == 1
    assert real_launcher.test_log_value == 1
