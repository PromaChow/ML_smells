import unittest
from go import Board, Color


def play_moves(board, moves):
    for color, x, y in moves:
        assert board.is_legal(color, x, y), f"Move {(color, x, y)} should be legal"
        board.play_move(color, x, y)


class TestKo(unittest.TestCase):
    def test_ko(self):
        board = Board(9)
        moves = [
            (Color.BLACK, 2, 0), (Color.WHITE, 1, 0),
            (Color.BLACK, 1, 1), (Color.WHITE, 2, 1),
            (Color.BLACK, 0, 1), (Color.WHITE, 1, 2),
            (Color.BLACK, 0, 2), (Color.WHITE, 2, 2),
            (Color.BLACK, 1, 1), (Color.WHITE, 1, 0),
            (Color.BLACK, 2, 1),  # capture white at (1,0)
        ]
        play_moves(board, moves)
        self.assertEqual(board.prisoners[Color.BLACK], 1)
        self.assertEqual(board.prisoners[Color.WHITE], 0)
        self.assertEqual(board.ko, (2, 1))
        self.assertFalse(board.is_legal(Color.BLACK, 2, 1))
        play_moves(board, [(Color.WHITE, 5, 5), (Color.BLACK, 5, 6)])
        self.assertTrue(board.is_legal(Color.BLACK, 2, 1))


class TestSnapbackIsNotKo(unittest.TestCase):
    def test_snapback(self):
        board = Board(5)
        moves = [
            (Color.WHITE, 1, 0), (Color.BLACK, 0, 0),
            (Color.BLACK, 1, 1), (Color.WHITE, 2, 0),
            (Color.BLACK, 1, 0),  # capture white at (1,0)
        ]
        play_moves(board, moves)
        self.assertIsNone(board.ko)
        self.assertTrue(board.is_legal(Color.WHITE, 2, 0))
        play_moves(board, [(Color.WHITE, 2, 0)])
        self.assertEqual(board.prisoners[Color.BLACK], 2)
        self.assertEqual(board.prisoners[Color.WHITE], 1)


class TestPositionalSuperko(unittest.TestCase):
    def test_superko(self):
        board = Board(9, superko=True)
        moves = [
            (Color.BLACK, 0, 0), (Color.WHITE, 1, 0),
            (Color.BLACK, 0, 1), (Color.WHITE, 1, 1),
            (Color.BLACK, 2, 0), (Color.WHITE, 2, 1),
            (Color.BLACK, 1, 2), (Color.WHITE, 0, 2),
            (Color.BLACK, 1, 1), (Color.WHITE, 1, 0),
            (Color.BLACK, 2, 1), (Color.WHITE, 2, 0),
        ]
        play_moves(board, moves)
        # The board state now repeats a previous position if we play (1,0)
        self.assertFalse(board.is_legal(Color.BLACK, 1, 0))
        # Disable superko
        board_no_superko = Board(9, superko=False)
        play_moves(board_no_superko, moves)
        self.assertTrue(board_no_superko.is_legal(Color.BLACK, 1, 0))


class TestEye(unittest.TestCase):
    def test_simple_eye(self):
        board = Board(9)
        # Black eye at top-left
        black_eye_moves = [
            (Color.BLACK, 0, 1), (Color.BLACK, 1, 0), (Color.BLACK, 1, 1),
        ]
        play_moves(board, black_eye_moves)
        # White eye at bottom-right
        white_eye_moves = [
            (Color.WHITE, 7, 8), (Color.WHITE, 8, 7), (Color.WHITE, 8, 8),
        ]
        play_moves(board, white_eye_moves)
        self.assertTrue(board.is_eyeish((0, 0), Color.BLACK))
        self.assertTrue(board.is_eyeish((8, 8), Color.WHITE))
        self.assertFalse(board.is_eyeish((0, 2), Color.BLACK))

    def test_true_eye(self):
        board = Board(9)
        group_moves = [
            (Color.BLACK, 0, 1), (Color.BLACK, 1, 0), (Color.BLACK, 1, 1),
        ]
        play_moves(board, group_moves)
        self.assertTrue(board.is_eye((0, 0), Color.BLACK))
        self.assertTrue(board.is_eye((1, 1), Color.BLACK))

    def test_checkerboard_eye(self):
        board = Board(4)
        for y in range(4):
            for x in range(4):
                if (x + y) % 2 == 0:
                    board.play_move(Color.BLACK, x, y)
        for y in range(4):
            for x in range(4):
                if (x + y) % 2 == 0:
                    self.assertTrue(board.is_eye((x, y), Color.BLACK))


class TestCacheSets(unittest.TestCase):
    def test_liberty_after_capture(self):
        board = Board(3)
        # Place a 3x3 black group
        for y in range(3):
            for x in range(3):
                board.play_move(Color.BLACK, x, y)
        # Surround with white and capture
        surround_moves = [
            (Color.WHITE, -1, 0), (Color.WHITE, -1, 1), (Color.WHITE, -1, 2),
            (Color.WHITE, 3, 0),  (Color.WHITE, 3, 1),  (Color.WHITE, 3, 2),
            (Color.WHITE, 0, -1), (Color.WHITE, 1, -1), (Color.WHITE, 2, -1),
            (Color.WHITE, 0, 3),  (Color.WHITE, 1, 3),  (Color.WHITE, 2, 3),
        ]
        for color, x, y in surround_moves:
            board.play_move(color, x, y)
        self.assertEqual(board.prisoners[Color.WHITE], 9)

    def test_copy_consistency(self):
        board = Board(5)
        board.play_move(Color.BLACK, 2, 2)
        group = board.get_group((2, 2))
        liberties_before = group.liberties
        board_copy = board.copy()
        group_copy = board_copy.get_group((2, 2))
        self.assertIs(group, group_copy)
        self.assertIs(group.liberties, liberties_before)
        self.assertIs(group_copy.liberties, liberties_before)


if __name__ == "__main__":
    unittest.main()