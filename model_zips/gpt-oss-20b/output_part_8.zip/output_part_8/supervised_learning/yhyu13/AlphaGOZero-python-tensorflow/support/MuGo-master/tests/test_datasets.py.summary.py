import os
import unittest
import tempfile
import numpy as np

# Import functions and classes from the dataset module.
# It is assumed that the following are available:
# - find_sgf_files(directory: str) -> list[str]
# - get_positions_from_sgf(sgf_path: str) -> list[Position]
# - DataSet(positions: list[Position], is_test: bool = False)
# - DataSet.write(file_path: str)
# - DataSet.read(file_path: str) -> DataSet
# - make_onehot(coords: np.ndarray, board_size: int) -> np.ndarray
from dataset import find_sgf_files, get_positions_from_sgf, DataSet, make_onehot

class TestDataSet(unittest.TestCase):
    TEMP_FILE_NAME = None

    @classmethod
    def setUpClass(cls):
        # Create a temporary file for serialization tests.
        temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".dat")
        cls.TEMP_FILE_NAME = temp_file.name
        temp_file.close()

    @classmethod
    def tearDownClass(cls):
        if cls.TEMP_FILE_NAME and os.path.exists(cls.TEMP_FILE_NAME):
            os.remove(cls.TEMP_FILE_NAME)

    def tearDown(self):
        # Ensure temporary file is removed after each test.
        if self.TEMP_FILE_NAME and os.path.exists(self.TEMP_FILE_NAME):
            os.remove(self.TEMP_FILE_NAME)

    def test_dataset_serialization(self):
        # Locate SGF files in the test directory.
        sgf_dir = os.path.join(os.path.dirname(__file__), "data")
        sgf_files = find_sgf_files(sgf_dir)

        # Extract positions from each SGF file.
        all_positions = []
        for sgf_file in sgf_files:
            positions = get_positions_from_sgf(sgf_file)
            all_positions.extend(positions)

        # Create dataset from extracted positions.
        original_dataset = DataSet(all_positions, is_test=False)

        # Serialize dataset to temporary file.
        original_dataset.write(self.TEMP_FILE_NAME)

        # Deserialize dataset from temporary file.
        recovered_dataset = DataSet.read(self.TEMP_FILE_NAME)

        # Validate dataset attributes.
        self.assertEqual(original_dataset.is_test, recovered_dataset.is_test)
        self.assertEqual(original_dataset.data_size, recovered_dataset.data_size)
        self.assertEqual(original_dataset.board_size, recovered_dataset.board_size)
        self.assertEqual(original_dataset.input_planes, recovered_dataset.input_planes)

        # Validate numerical data.
        np.testing.assert_array_equal(original_dataset.pos_features, recovered_dataset.pos_features)
        np.testing.assert_array_equal(original_dataset.next_moves, recovered_dataset.next_moves)

    def test_onehot(self):
        board_size = 9
        coords = np.array([[1, 2],
                           [3, 4]], dtype=int)

        # Expected one-hot encoded array.
        expected = np.zeros((2, board_size * board_size), dtype=int)
        expected[0, 1 * board_size + 2] = 1
        expected[1, 3 * board_size + 4] = 1

        # Actual one-hot from the utility function.
        result = make_onehot(coords, board_size)

        # Compare the results.
        np.testing.assert_array_equal(result, expected)

if __name__ == "__main__":
    unittest.main()