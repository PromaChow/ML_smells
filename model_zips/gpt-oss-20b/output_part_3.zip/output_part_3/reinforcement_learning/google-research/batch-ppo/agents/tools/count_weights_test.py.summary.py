import re
import unittest
import tensorflow as tf

tf.compat.v1.disable_eager_execution()


def count_weights(graph=None, scope=None, exclude=None):
    g = graph or tf.compat.v1.get_default_graph()
    with g.as_default():
        vars_ = tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.TRAINABLE_VARIABLES, scope=scope)
        if exclude:
            pattern = re.compile(exclude)
            vars_ = [v for v in vars_ if not pattern.search(v.op.name)]
        total = 0
        for v in vars_:
            total += tf.size(v).numpy()
        return total


class TestCountWeights(unittest.TestCase):
    def setUp(self):
        tf.compat.v1.reset_default_graph()

    def test_count_trainable_variables(self):
        v1 = tf.compat.v1.Variable(tf.random.uniform([2, 3]), trainable=True)
        v2 = tf.compat.v1.Variable(tf.random.uniform([4]), trainable=True)
        with tf.compat.v1.Session() as sess:
            sess.run(tf.compat.v1.global_variables_initializer())
            expected = tf.size(v1).numpy() + tf.size(v2).numpy()
            self.assertEqual(count_weights(), expected)

    def test_ignore_non_trainable_variables(self):
        v1 = tf.compat.v1.Variable(tf.random.uniform([2, 3]), trainable=False)
        v2 = tf.compat.v1.Variable(tf.random.uniform([4]), trainable=False)
        with tf.compat.v1.Session() as sess:
            sess.run(tf.compat.v1.global_variables_initializer())
            self.assertEqual(count_weights(), 0)

    def test_mixed_trainable_and_non_trainable(self):
        v1 = tf.compat.v1.Variable(tf.random.uniform([2, 3]), trainable=True)
        v2 = tf.compat.v1.Variable(tf.random.uniform([4]), trainable=False)
        v3 = tf.compat.v1.Variable(tf.random.uniform([5]), trainable=True)
        with tf.compat.v1.Session() as sess:
            sess.run(tf.compat.v1.global_variables_initializer())
            expected = tf.size(v1).numpy() + tf.size(v3).numpy()
            self.assertEqual(count_weights(), expected)

    def test_including_variables_in_specific_scopes(self):
        v1 = tf.compat.v1.Variable(tf.random.uniform([2]), trainable=True)
        with tf.compat.v1.variable_scope('foo'):
            v2 = tf.compat.v1.Variable(tf.random.uniform([3]), trainable=True)
        with tf.compat.v1.Session() as sess:
            sess.run(tf.compat.v1.global_variables_initializer())
            expected = tf.size(v1).numpy() + tf.size(v2).numpy()
            self.assertEqual(count_weights(), expected)

    def test_restricting_scope_to_parent(self):
        with tf.compat.v1.variable_scope('foo'):
            v1 = tf.compat.v1.Variable(tf.random.uniform([2]), trainable=True)
            with tf.compat.v1.variable_scope('bar'):
                v2 = tf.compat.v1.Variable(tf.random.uniform([3]), trainable=True)
        with tf.compat.v1.Session() as sess:
            sess.run(tf.compat.v1.global_variables_initializer())
            expected = tf.size(v1).numpy()
            self.assertEqual(count_weights(scope='foo'), expected)

    def test_restricting_scope_to_nested_subscope(self):
        with tf.compat.v1.variable_scope('foo'):
            with tf.compat.v1.variable_scope('bar'):
                v1 = tf.compat.v1.Variable(tf.random.uniform([2]), trainable=True)
                v2 = tf.compat.v1.Variable(tf.random.uniform([3]), trainable=True)
        with tf.compat.v1.Session() as sess:
            sess.run(tf.compat.v1.global_variables_initializer())
            expected = tf.size(v1).numpy() + tf.size(v2).numpy()
            self.assertEqual(count_weights(scope='foo/bar'), expected)

    def test_invalid_scope_restriction(self):
        v1 = tf.compat.v1.Variable(tf.random.uniform([2]), trainable=True)
        with tf.compat.v1.Session() as sess:
            sess.run(tf.compat.v1.global_variables_initializer())
            self.assertEqual(count_weights(scope='nonexistent'), 0)

    def test_excluding_variables_via_regex_patterns(self):
        v1 = tf.compat.v1.Variable(tf.random.uniform([2]), trainable=True)
        with tf.compat.v1.variable_scope('foo'):
            v2 = tf.compat.v1.Variable(tf.random.uniform([3]), trainable=True)
        with tf.compat.v1.variable_scope('bar'):
            v3 = tf.compat.v1.Variable(tf.random.uniform([4]), trainable=True)
        with tf.compat.v1.Session() as sess:
            sess.run(tf.compat.v1.global_variables_initializer())
            expected = tf.size(v1).numpy() + tf.size(v3).numpy()
            self.assertEqual(count_weights(exclude=r'.*foo.*'), expected)

    def test_handling_non_default_graphs(self):
        custom_graph = tf.Graph()
        with custom_graph.as_default():
            v1 = tf.compat.v1.Variable(tf.random.uniform([2]), trainable=True)
            v2 = tf.compat.v1.Variable(tf.random.uniform([3]), trainable=True)
        with tf.compat.v1.Session(graph=custom_graph) as sess:
            sess.run(tf.compat.v1.global_variables_initializer())
            expected = tf.size(v1).numpy() + tf.size(v2).numpy()
            self.assertEqual(count_weights(graph=custom_graph), expected)


if __name__ == "__main__":
    unittest.main()
