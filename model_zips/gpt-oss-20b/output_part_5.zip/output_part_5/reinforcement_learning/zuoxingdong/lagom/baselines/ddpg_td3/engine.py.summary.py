import time
from itertools import count
from typing import Any, Dict, List


class Logger:
    def __init__(self):
        self.data: Dict[str, Any] = {}

    def add(self, key: str, value: Any) -> None:
        self.data[key] = value

    def dump(self) -> None:
        print(self.data)


def color_str(text: str, color: str = "green") -> str:
    return f"\033[32m{text}\033[0m"  # ANSI escape for green


class Trajectory:
    def __init__(self, rewards: List[float], T: int):
        self.rewards = rewards
        self.T = T


class Engine:
    def __init__(
        self,
        agent,
        random_agent,
        replay,
        runner,
        eval_env,
        config: Dict[str, Any],
    ):
        self.agent = agent
        self.random_agent = random_agent
        self.replay = replay
        self.runner = runner
        self.eval_env = eval_env
        self.config = config
        self.train_logs: List[Dict[str, Any]] = []
        self.eval_logs: List[Dict[str, Any]] = []
        self.checkpoint_count = 0

    def train(self) -> None:
        eval_interval = (
            self.config["train.timestep"] // self.config["eval.num"]
            if self.config["eval.num"] > 0
            else 1
        )
        checkpoint_interval = (
            self.config["train.timestep"] // self.config["checkpoint.num"]
            if self.config["checkpoint.num"] > 0
            else 1
        )
        next_eval_timestep = eval_interval
        for iteration in count():
            if self.agent.total_timestep >= self.config["train.timestep"]:
                break

            start_time = time.perf_counter()

            if iteration < self.config["replay.init_trial"]:
                traj = self.random_agent.collect_trajectory(training=False)
            else:
                traj = self.agent.collect_trajectory(training=True)

            self.replay.add(traj)

            out_agent = self.agent.learn(
                D=None, replay=self.replay, T=traj.T
            )

            elapsed = time.perf_counter() - start_time
            episode_return = sum(traj.rewards)
            logger = Logger()
            logger.add("train_iteration", iteration)
            logger.add("num_seconds", round(elapsed, 1))
            for k, v in out_agent.items():
                logger.add(k, v)
            logger.add("episode_return", episode_return)
            logger.add("episode_horizon", traj.T)
            logger.add(
                "accumulated_trained_timesteps",
                self.agent.total_timestep,
            )
            logger.dump()
            self.train_logs.append(logger.data)

            if iteration % self.config["log.freq"] == 0 or iteration == 0:
                self.dump_logs(self.train_logs, "train_logs.txt")

            if iteration % checkpoint_interval == 0:
                self.save_checkpoint()
                self.checkpoint_count += 1

            if (
                self.agent.total_timestep
                >= next_eval_timestep
                and self.agent.total_timestep < self.config["train.timestep"]
            ):
                eval_result = self.eval()
                self.eval_logs.append(eval_result)
                self.dump_logs(self.eval_logs, "eval_logs.txt")
                next_eval_timestep += eval_interval

    def eval(self) -> Dict[str, Any]:
        start_time = time.perf_counter()
        online_returns: List[float] = []
        online_horizons: List[int] = []
        for _ in range(10):
            traj = self.runner.run(self.eval_env, mode="eval")
            online_returns.append(sum(traj.rewards))
            online_horizons.append(traj.T)

        running_returns = self.eval_env.online_queue
        running_horizons = self.eval_env.horizon_queue

        elapsed = time.perf_counter() - start_time
        eval_iteration = len(self.eval_logs)
        logger = Logger()
        logger.add("eval_iteration", eval_iteration)
        logger.add("num_seconds", round(elapsed, 1))
        logger.add(
            "accumulated_trained_timesteps",
            self.agent.total_timestep,
        )
        logger.add(
            "online_return",
            sum(online_returns) / len(online_returns)
            if online_returns
            else 0.0,
        )
        logger.add(
            "online_horizon",
            sum(online_horizons) / len(online_horizons)
            if online_horizons
            else 0,
        )
        logger.add(
            "running_return",
            sum(running_returns) / len(running_returns)
            if running_returns
            else 0.0,
        )
        logger.add(
            "running_horizon",
            sum(running_horizons) / len(running_horizons)
            if running_horizons
            else 0,
        )
        logger.dump()
        print(color_str("+" * 50, color="green"))
        return logger.data

    def save_checkpoint(self) -> None:
        print(f"Checkpoint {self.checkpoint_count} saved at timestep {self.agent.total_timestep}")

    def dump_logs(self, logs: List[Dict[str, Any]], filename: str) -> None:
        with open(filename, "w") as f:
            for log in logs:
                f.write(str(log) + "\n")
```