import pytest
import torch

# Assuming Buffer is defined in the machin framework
# from machin.core import Buffer
# For the purposes of this test suite, we will import Buffer from a hypothetical module
# Replace the following import with the actual path to Buffer in your project.
from machin import Buffer  # noqa: F401


BUFFER_SIZE = 5
SAMPLE_BUFFER_SIZE = 10


@pytest.fixture
def buffer():
    return Buffer(max_size=BUFFER_SIZE)


@pytest.fixture
def const_buffer():
    episodes = []
    for _ in range(SAMPLE_BUFFER_SIZE):
        transition = {
            "state": torch.randn(2),
            "action": torch.randn(1),
            "next_state": torch.randn(2),
            "reward": torch.randn(1).item(),
            "terminal": False,
            "not_concatenable": ("a", "b"),
        }
        episodes.append(transition)
    buf = Buffer(max_size=SAMPLE_BUFFER_SIZE, device="cuda")
    buf.store_episode(episodes)
    return buf


@pytest.mark.parametrize(
    "episode,expected_error",
    [
        # valid single episode as dict
        (
            [
                {
                    "state": torch.randn(2),
                    "action": torch.randn(1),
                    "next_state": torch.randn(2),
                    "reward": 1.0,
                    "terminal": False,
                }
            ],
            None,
        ),
        # empty episode list
        ([], ValueError("Episode must be non-empty")),
        # non-dict element
        (
            [torch.randn(2)],
            ValueError("Transition object must be a dict"),
        ),
        # missing attributes
        (
            [
                {
                    "state": torch.randn(2),
                    "action": torch.randn(1),
                    # missing next_state, reward, terminal
                }
            ],
            ValueError("Transition object missing attributes"),
        ),
    ],
)
def test_store_episode(buffer, episode, expected_error):
    if expected_error is None:
        buffer.store_episode(episode)
        assert buffer.size() == 1
    else:
        with pytest.raises(type(expected_error)) as exc:
            buffer.store_episode(episode)
        assert str(exc.value) == str(expected_error)


def test_size(buffer):
    episode = [
        {
            "state": torch.randn(2),
            "action": torch.randn(1),
            "next_state": torch.randn(2),
            "reward": 0.5,
            "terminal": True,
        }
    ]
    buffer.store_episode(episode)
    assert buffer.size() == 1


def test_clear(buffer):
    episode = [
        {
            "state": torch.randn(2),
            "action": torch.randn(1),
            "next_state": torch.randn(2),
            "reward": 0.5,
            "terminal": True,
        }
    ]
    buffer.store_episode(episode)
    assert buffer.size() == 1
    buffer.clear()
    assert buffer.size() == 0


def test_sample_batch_invalid_method(const_buffer):
    with pytest.raises(RuntimeError) as exc:
        const_buffer.sample_batch(
            batch_size=3,
            concat=True,
            device=None,
            sample_method="some_invalid_method",
            sample_attrs=["state", "action"],
            concat_attrs=["state"],
        )
    assert str(exc.value) == "Cannot find specified sample method"


def test_sample_batch_concat_error(const_buffer):
    with pytest.raises(ValueError) as exc:
        const_buffer.sample_batch(
            batch_size=3,
            concat=True,
            device=None,
            sample_method="random",
            sample_attrs=["state", "not_concatenable"],
            concat_attrs=["not_concatenable"],
        )
    assert str(exc.value) == "Batch not concatenable"


@pytest.mark.parametrize(
    "batch_size,concat,device,sample_method,sample_attrs,concat_attrs,should_be_attrs",
    [
        (0, True, None, "random", ["state", "action"], ["state"], ["state", "action"]),
        (SAMPLE_BUFFER_SIZE // 2, True, "cpu", "random_unique", ["state"], ["state"], ["state"]),
        (SAMPLE_BUFFER_SIZE, False, None, "all", ["state", "action", "reward"], ["state"], ["state", "action", "reward"]),
        (SAMPLE_BUFFER_SIZE * 2, True, "cpu", "random", ["state", "action"], ["state"], ["state", "action"]),
    ],
)
def test_sample_batch_valid(
    const_buffer,
    batch_size,
    concat,
    device,
    sample_method,
    sample_attrs,
    concat_attrs,
    should_be_attrs,
):
    batch = const_buffer.sample_batch(
        batch_size=batch_size,
        concat=concat,
        device=device,
        sample_method=sample_method,
        sample_attrs=sample_attrs,
        concat_attrs=concat_attrs,
    )
    assert set(batch.keys()) == set(should_be_attrs)
    actual_batch_size = (
        batch[concat_attrs[0]].size(0) if concat else len(batch[concat_attrs[0]])
    )
    expected_size = batch_size if batch_size > 0 else const_buffer.size()
    assert actual_batch_size == expected_size
    if concat:
        for attr in concat_attrs:
            assert isinstance(batch[attr], torch.Tensor)
    else:
        for attr in sample_attrs:
            if attr in concat_attrs:
                assert isinstance(batch[attr], torch.Tensor)
            else:
                assert isinstance(batch[attr], list)
    for attr in sample_attrs:
        if attr not in concat_attrs:
            # non-concatenated attributes should be lists of tuples if applicable
            if attr == "not_concatenable":
                assert isinstance(batch[attr], list)
                for item in batch[attr]:
                    assert isinstance(item, tuple)
            else:
                assert isinstance(batch[attr], list)
                for item in batch[attr]:
                    if isinstance(item, torch.Tensor):
                        assert item.ndim >= 1
                    else:
                        assert isinstance(item, (int, float, bool))
```