import statistics

class Logger:
    def __init__(self, names, formats):
        if len(names) != len(formats):
            raise ValueError("names and formats must have the same length")
        self.names = names
        self.log_format = " ".join(formats)
        self.log_dic = {name: [] for name in names}

    def update(self, values):
        if len(values) != len(self.names):
            raise ValueError("values length must match names length")
        for name, value in zip(self.names, values):
            self.log_dic[name].append(value)

    def get_data(self):
        means = []
        for name in self.names:
            values = self.log_dic[name]
            if values:
                means.append(statistics.mean(values))
            else:
                means.append(0)
        return means

    def log(self):
        means = self.get_data()
        return self.log_format.format(*means)

    def clear(self):
        for name in self.names:
            self.log_dic[name] = []