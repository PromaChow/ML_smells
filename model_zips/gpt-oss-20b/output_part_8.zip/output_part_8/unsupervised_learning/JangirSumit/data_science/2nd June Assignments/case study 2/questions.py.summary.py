import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score, classification_report

# Load the dataset
df = pd.read_csv("run_or_walk.csv")
print("First five rows of the dataset:")
print(df.head())

# Define target and full feature matrix
y = df["activity"]
X_full = df.iloc[:, 5:]  # columns from index 5 onward

# Function to train, predict, and report
def train_and_evaluate(X, name):
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=10, stratify=y
    )
    clf = GaussianNB()
    clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    report = classification_report(y_test, y_pred, zero_division=0)
    print(f"\n=== {name} ===")
    print(f"Accuracy: {acc:.4f}")
    print("Classification Report:")
    print(report)
    return acc, report

# 1. Full feature model
acc_full, report_full = train_and_evaluate(X_full, "Full Features")

# 2. Acceleration-only model (columns 5,6,7)
X_acc = df.iloc[:, 5:8]  # indices 5,6,7
acc_acc, report_acc = train_and_evaluate(X_acc, "Acceleration Features")

# 3. Gyro-only model (columns from index 8 onward)
X_gyro = df.iloc[:, 8:]
acc_gyro, report_gyro = train_and_evaluate(X_gyro, "Gyro Features")

# Comparison summary
print("\n=== Accuracy Comparison ===")
print(f"Full Features Accuracy: {acc_full:.4f}")
print(f"Acceleration Features Accuracy: {acc_acc:.4f}")
print(f"Gyro Features Accuracy: {acc_gyro:.4f}")