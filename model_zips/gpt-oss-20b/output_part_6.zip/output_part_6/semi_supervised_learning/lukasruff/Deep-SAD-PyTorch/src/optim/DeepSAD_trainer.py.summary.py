import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torch.optim.lr_scheduler import MultiStepLR
from sklearn.metrics import roc_auc_score


class DeepSADTrainer:
    def __init__(
        self,
        model: nn.Module,
        train_dataset,
        test_dataset,
        c: torch.Tensor | None = None,
        eta: float = 1.0,
        lr: float = 1e-3,
        weight_decay: float = 0.0,
        epochs: int = 100,
        batch_size: int = 32,
        device: str = "cpu",
        epsilon: float = 1e-8,
    ):
        self.model = model
        self.train_dataset = train_dataset
        self.test_dataset = test_dataset
        self.c = c
        self.eta = eta
        self.lr = lr
        self.weight_decay = weight_decay
        self.epochs = epochs
        self.batch_size = batch_size
        self.device = torch.device(device)
        self.epsilon = epsilon
        self.loss_history = []

    def init_center_c(self, loader: DataLoader):
        self.model.eval()
        with torch.no_grad():
            outputs = []
            for inputs, _ in loader:
                inputs = inputs.to(self.device)
                out = self.model(inputs)
                outputs.append(out)
            outputs = torch.cat(outputs, dim=0)
            c = torch.mean(outputs, dim=0)
            abs_c = torch.abs(c)
            mask = abs_c < self.epsilon
            c[mask] = self.epsilon * torch.sign(c[mask])
            if torch.all(mask):
                c[mask] = self.epsilon
        self.c = c.to(self.device)

    def train(self):
        train_loader = DataLoader(
            self.train_dataset,
            batch_size=self.batch_size,
            shuffle=True,
            drop_last=True,
        )
        self.model.to(self.device)
        optimizer = optim.Adam(
            self.model.parameters(),
            lr=self.lr,
            weight_decay=self.weight_decay,
        )
        scheduler = MultiStepLR(optimizer, milestones=[int(0.5 * self.epochs), int(0.75 * self.epochs)], gamma=0.1)

        if self.c is None:
            self.init_center_c(train_loader)

        for epoch in range(1, self.epochs + 1):
            self.model.train()
            epoch_losses = []
            for inputs, labels in train_loader:
                inputs = inputs.to(self.device)
                labels = labels.to(self.device)
                optimizer.zero_grad()
                outputs = self.model(inputs)
                distances = torch.sum((outputs - self.c) ** 2, dim=1)

                mask = labels == 0
                loss_pos = distances[mask]
                loss_neg = self.eta * ((distances[~mask] + self.epsilon) ** labels[~mask].float())

                loss = torch.cat([loss_pos, loss_neg]).mean()
                loss.backward()
                optimizer.step()
                epoch_losses.append(loss.item())

            scheduler.step()
            avg_loss = sum(epoch_losses) / len(epoch_losses)
            self.loss_history.append(avg_loss)
            print(f"Epoch {epoch}/{self.epochs} - Loss: {avg_loss:.4f}")

    def test(self):
        test_loader = DataLoader(
            self.test_dataset,
            batch_size=self.batch_size,
            shuffle=False,
            drop_last=False,
        )
        self.model.eval()
        scores = []
        labels_list = []
        with torch.no_grad():
            for idx, (inputs, labels) in enumerate(test_loader):
                inputs = inputs.to(self.device)
                labels = labels.to(self.device)
                outputs = self.model(inputs)
                distances = torch.sum((outputs - self.c) ** 2, dim=1)
                scores.append(distances.cpu().numpy())
                labels_list.append(labels.cpu().numpy())

        scores = torch.tensor(scores).reshape(-1).numpy()
        labels = torch.tensor(labels_list).reshape(-1).numpy()
        auc = roc_auc_score(labels, scores)
        print(f"AUC: {auc:.4f}")
        return auc

    def run(self):
        self.train()
        return self.test()