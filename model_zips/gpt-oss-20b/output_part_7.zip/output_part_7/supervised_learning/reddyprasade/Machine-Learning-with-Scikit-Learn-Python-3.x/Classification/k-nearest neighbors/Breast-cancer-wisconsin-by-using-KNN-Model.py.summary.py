import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pandas.plotting import scatter_matrix
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn import metrics
from pandas_profiling import ProfileReport

# Load dataset from remote URL
url = "https://raw.githubusercontent.com/jbrownlee/Datasets/master/breast-cancer-wisconsin.data"
column_names = [
    'ID','diagnosis','radius_mean','texture_mean','perimeter_mean','area_mean',
    'smoothness_mean','compactness_mean','concavity_mean','concave points_mean',
    'symmetry_mean','fractal_dimension_mean','radius_se','texture_se',
    'perimeter_se','area_se','smoothness_se','compactness_se','concavity_se',
    'concave points_se','symmetry_se','fractal_dimension_se','radius_worst',
    'texture_worst','perimeter_worst','area_worst','smoothness_worst',
    'compactness_worst','concavity_worst','concave points_worst','symmetry_worst',
    'fractal_dimension_worst'
]
data = pd.read_csv(url, header=None, names=column_names)

# Basic inspection
print(f"Dataset shape: {data.shape}")
print(data.head())
print(data.tail())

# Remove unnamed/ID column
data = data.drop(columns=['ID'])

# Data overview
print(data.info())

# Target variable analysis
diagnosis_counts = data['diagnosis'].value_counts()
print("\nDiagnosis distribution:\n", diagnosis_counts)
sns.countplot(x='diagnosis', data=data)
plt.title('Diagnosis Class Distribution')
plt.xlabel('Diagnosis')
plt.ylabel('Count')
plt.show()

# Feature selection: first 10 mean features
mean_features = [
    'radius_mean','texture_mean','perimeter_mean','area_mean',
    'smoothness_mean','compactness_mean','concavity_mean',
    'concave points_mean','symmetry_mean','fractal_dimension_mean'
]
X = data[mean_features]
y = data['diagnosis']

# Correlation heatmap
corr = X.corr()
sns.heatmap(corr, annot=True, cmap='coolwarm', fmt=".2f")
plt.title('Correlation Matrix of Mean Features')
plt.show()

# Scatter matrix plot
scatter_matrix(X, figsize=(12, 12), diagonal='kde', c=LabelEncoder().fit_transform(y))
plt.suptitle('Scatter Matrix of Mean Features')
plt.show()

# Encode target variable
le = LabelEncoder()
y_encoded = le.fit_transform(y)

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(
    X, y_encoded, test_size=0.2, random_state=42, stratify=y_encoded
)

# Logistic Regression
logreg = LogisticRegression(max_iter=200)
logreg.fit(X_train, y_train)

train_acc_logreg = logreg.score(X_train, y_train)
test_acc_logreg = logreg.score(X_test, y_test)
print(f"\nLogistic Regression training accuracy: {train_acc_logreg:.4f}")
print(f"Logistic Regression test accuracy: {test_acc_logreg:.4f}")

y_pred_logreg = logreg.predict(X_test)
print("\nLogistic Regression Confusion Matrix:")
print(metrics.confusion_matrix(y_test, y_pred_logreg))
print("\nLogistic Regression Classification Report:")
print(metrics.classification_report(y_test, y_pred_logreg))

# K-Nearest Neighbors
knn = KNeighborsClassifier(n_neighbors=10)
knn.fit(X_train, y_train)

train_acc_knn = knn.score(X_train, y_train)
test_acc_knn = knn.score(X_test, y_test)
print(f"\nKNN training accuracy: {train_acc_knn:.4f}")
print(f"KNN test accuracy: {test_acc_knn:.4f}")

y_pred_knn = knn.predict(X_test)
print("\nKNN Confusion Matrix:")
print(metrics.confusion_matrix(y_test, y_pred_knn))
print("\nKNN Classification Report:")
print(metrics.classification_report(y_test, y_pred_knn))

# Predicted probabilities for training set
y_train_probs = knn.predict_proba(X_train)
print("\nKNN predicted probabilities for training set (first 5 samples):")
print(y_train_probs[:5])

# Class labels from KNN
print("\nKNN class labels for training set (first 10 samples):")
print(knn.predict(X_train)[:10])

# Generate pandas profiling report
profile = ProfileReport(data, title="Breast Cancer Dataset Profiling Report")
profile.to_file("breast_cancer_profile.html")