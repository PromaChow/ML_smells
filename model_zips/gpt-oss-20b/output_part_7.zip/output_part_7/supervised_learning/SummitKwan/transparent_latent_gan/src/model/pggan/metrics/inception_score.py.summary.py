import os
import tarfile
import urllib.request
import numpy as np
import tensorflow as tf

tf.compat.v1.disable_eager_execution()

MODEL_URL = "http://download.tensorflow.org/models/inception-2015-12-05.tgz"
MODEL_DIR = "/tmp/imagenet"
MODEL_FILE = os.path.join(MODEL_DIR, "classify_image_graph_def.pb")
TAR_PATH = os.path.join(MODEL_DIR, "inception-2015-12-05.tgz")

def _download_and_extract():
    if not os.path.exists(MODEL_FILE):
        os.makedirs(MODEL_DIR, exist_ok=True)
        urllib.request.urlretrieve(MODEL_URL, TAR_PATH)
        with tarfile.open(TAR_PATH, "r:gz") as tar:
            tar.extractall(path=MODEL_DIR)
        os.remove(TAR_PATH)

def _load_inception():
    _download_and_extract()
    with tf.io.gfile.GFile(MODEL_FILE, "rb") as f:
        graph_def = tf.compat.v1.GraphDef()
        graph_def.ParseFromString(f.read())
    graph = tf.Graph()
    with graph.as_default():
        tf.import_graph_def(graph_def, name="")
    sess = tf.compat.v1.Session(graph=graph)
    logits = graph.get_tensor_by_name("softmax:0")
    return sess, logits

def get_inception_score(images, batch_size=100, splits=10):
    if not isinstance(images, (list, tuple)):
        raise ValueError("images must be a list or tuple of numpy arrays")
    sess, logits = _load_inception()
    probs = []
    for i in range(0, len(images), batch_size):
        batch = images[i:i + batch_size]
        inp = np.stack(batch, axis=0).astype(np.uint8)
        out = sess.run(logits, feed_dict={"DecodeJpeg/contents:0": None, "input:0": inp})
        probs.append(out)
    probs = np.concatenate(probs, axis=0)
    split_scores = []
    for k in range(splits):
        part = probs[k * probs.shape[0] // splits : (k + 1) * probs.shape[0] // splits]
        py = np.mean(part, axis=0)
        kl = part * (np.log(part + 1e-10) - np.log(py + 1e-10))
        kl_sum = np.mean(np.sum(kl, axis=1))
        split_scores.append(np.exp(kl_sum))
    mean = np.mean(split_scores)
    std = np.std(split_scores)
    sess.close()
    return mean, std

class API:
    def __init__(self, batch_size=100, splits=10):
        self.batch_size = batch_size
        self.splits = splits
        self.data = {"warmup": [], "reals": [], "fakes": []}

    def add_images(self, images, mode):
        if mode not in self.data:
            raise ValueError(f"Unknown mode {mode}")
        for img in images:
            if img.dtype != np.uint8:
                img = img.astype(np.uint8)
            self.data[mode].append(img)

    def finalize(self):
        scores = {}
        for mode, imgs in self.data.items():
            if imgs:
                mean, std = get_inception_score(imgs, batch_size=self.batch_size, splits=self.splits)
                scores[mode] = (mean, std)
        return scores
