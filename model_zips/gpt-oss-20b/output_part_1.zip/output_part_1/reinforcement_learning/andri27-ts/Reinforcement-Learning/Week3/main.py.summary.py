import gym
import random
import numpy as np
import collections
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.tensorboard import SummaryWriter
from collections import deque
import os

# Hyperparameters
ENV_NAME = "PongNoFrameskip-v4"
MAX_N_GAMES = 3000
MAX_STEPS_PER_EPISODE = 10000
BATCH_SIZE = 32
REPLAY_BUFFER_CAPACITY = 100000
LEARNING_RATE = 1e-4
GAMMA = 0.99
TARGET_UPDATE_FREQ = 1000  # steps
EPSILON_START = 1.0
EPSILON_FINAL = 0.01
EPSILON_DECAY_STEPS = 1000000
DOUBLE_DQN = True
DUELING = False
N_STEP_RETURN = 3
SAVE_VIDEO = False
SUMMARY_WRITER = True

device = torch.device("cpu")


def make_env(name, seed=0, save_video=False):
    env = gym.make(name)
    env.seed(seed)
    env = gym.wrappers.AtariPreprocessing(env, noop_max=30, frame_skip=1, screen_size=84, terminal_on_life_loss=False, grayscale_obs=True)
    env = gym.wrappers.FrameStack(env, num_stack=4)
    if save_video:
        os.makedirs("videos", exist_ok=True)
        env = gym.wrappers.Monitor(env, "videos", video_callable=lambda episode_id: episode_id % 10 == 0, force=True)
    return env


class ReplayBuffer:
    def __init__(self, capacity):
        self.capacity = capacity
        self.buffer = deque(maxlen=capacity)

    def push(self, transition):
        self.buffer.append(transition)

    def sample(self, batch_size):
        batch = random.sample(self.buffer, batch_size)
        obs, action, reward, next_obs, done = map(np.stack, zip(*batch))
        return obs, action, reward, next_obs, done

    def __len__(self):
        return len(self.buffer)


class DQN(nn.Module):
    def __init__(self, num_inputs, num_actions, dueling=False):
        super(DQN, self).__init__()
        self.dueling = dueling
        self.feature_extractor = nn.Sequential(
            nn.Conv2d(num_inputs, 32, kernel_size=8, stride=4),
            nn.ReLU(),
            nn.Conv2d(32, 64, kernel_size=4, stride=2),
            nn.ReLU(),
            nn.Conv2d(64, 64, kernel_size=3, stride=1),
            nn.ReLU(),
            nn.Flatten()
        )
        if dueling:
            self.value_stream = nn.Sequential(
                nn.Linear(3136, 512),
                nn.ReLU(),
                nn.Linear(512, 1)
            )
            self.advantage_stream = nn.Sequential(
                nn.Linear(3136, 512),
                nn.ReLU(),
                nn.Linear(512, num_actions)
            )
        else:
            self.fc = nn.Sequential(
                nn.Linear(3136, 512),
                nn.ReLU(),
                nn.Linear(512, num_actions)
            )

    def forward(self, x):
        x = x / 255.0
        features = self.feature_extractor(x)
        if self.dueling:
            value = self.value_stream(features)
            advantage = self.advantage_stream(features)
            q_vals = value + advantage - advantage.mean(dim=1, keepdim=True)
        else:
            q_vals = self.fc(features)
        return q_vals


class DQNAgent:
    def __init__(self, env, device, writer=None):
        self.env = env
        self.device = device
        self.writer = writer

        self.n_actions = env.action_space.n
        self.obs_shape = env.observation_space.shape

        self.policy_net = DQN(self.obs_shape[0], self.n_actions, dueling=DUELING).to(device)
        self.target_net = DQN(self.obs_shape[0], self.n_actions, dueling=DUELING).to(device)
        self.target_net.load_state_dict(self.policy_net.state_dict())
        self.target_net.eval()

        self.optimizer = optim.Adam(self.policy_net.parameters(), lr=LEARNING_RATE)
        self.replay_buffer = ReplayBuffer(REPLAY_BUFFER_CAPACITY)

        self.epsilon = EPSILON_START
        self.steps_done = 0
        self.loss = None
        self.rewards = []

    def select_action(self, state):
        sample = random.random()
        self.epsilon = max(EPSILON_FINAL, EPSILON_START - self.steps_done / EPSILON_DECAY_STEPS)
        self.steps_done += 1
        if sample < self.epsilon:
            return torch.tensor([[self.env.action_space.sample()]], device=self.device, dtype=torch.long)
        with torch.no_grad():
            state = torch.FloatTensor(state).unsqueeze(0).to(self.device)
            q_values = self.policy_net(state)
            return q_values.max(1)[1].view(1, 1)

    def store_transition(self, state, action, reward, next_state, done):
        self.replay_buffer.push((state, action, reward, next_state, done))

    def optimize_model(self):
        if len(self.replay_buffer) < BATCH_SIZE:
            return
        states, actions, rewards, next_states, dones = self.replay_buffer.sample(BATCH_SIZE)

        states = torch.FloatTensor(states).to(self.device)
        actions = torch.LongTensor(actions).to(self.device)
        rewards = torch.FloatTensor(rewards).to(self.device)
        next_states = torch.FloatTensor(next_states).to(self.device)
        dones = torch.FloatTensor(dones).to(self.device)

        q_values = self.policy_net(states).gather(1, actions)
        with torch.no_grad():
            if DOUBLE_DQN:
                next_actions = self.policy_net(next_states).max(1)[1].unsqueeze(1)
                next_q_values = self.target_net(next_states).gather(1, next_actions)
            else:
                next_q_values = self.target_net(next_states).max(1)[0].unsqueeze(1)
            expected_q_values = rewards.unsqueeze(1) + (1 - dones.unsqueeze(1)) * GAMMA ** N_STEP_RETURN * next_q_values

        loss = nn.functional.mse_loss(q_values, expected_q_values)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        self.loss = loss.item()

        if self.writer is not None:
            self.writer.add_scalar('Loss', self.loss, self.steps_done)

    def update_target_network(self):
        self.target_net.load_state_dict(self.policy_net.state_dict())

    def reset_stats(self):
        self.rewards = []

    def add_reward(self, reward):
        self.rewards.append(reward)

    def get_avg_reward(self):
        return np.mean(self.rewards) if self.rewards else 0.0


def main():
    env = make_env(ENV_NAME, seed=0, save_video=SAVE_VIDEO)
    writer = SummaryWriter(log_dir="runs") if SUMMARY_WRITER else None
    agent = DQNAgent(env, device, writer=writer)

    total_games = 0
    while total_games < MAX_N_GAMES:
        state = env.reset()
        episode_reward = 0
        for t in range(MAX_STEPS_PER_EPISODE):
            action = agent.select_action(state).item()
            next_state, reward, done, _ = env.step(action)
            agent.store_transition(state, action, reward, next_state, done)
            agent.optimize_model()
            if t % TARGET_UPDATE_FREQ == 0:
                agent.update_target_network()
            state = next_state
            episode_reward += reward
            if done:
                break

        total_games += 1
        agent.add_reward(episode_reward)
        avg_reward = agent.get_avg_reward()
        print(f"Game {total_games}, Episode Reward: {episode_reward:.2f}, Avg Reward: {avg_reward:.2f}, Epsilon: {agent.epsilon:.4f}, Loss: {agent.loss}")
        agent.reset_stats()

    if writer is not None:
        writer.close()
    env.close()


if __name__ == "__main__":
    main()