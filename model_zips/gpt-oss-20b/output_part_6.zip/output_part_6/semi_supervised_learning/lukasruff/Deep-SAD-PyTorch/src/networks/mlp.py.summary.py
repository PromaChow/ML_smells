import torch
import torch.nn as nn


class Linear_BN_leakyReLU(nn.Module):
    def __init__(self, in_features: int, out_features: int, bias: bool = True):
        super().__init__()
        self.linear = nn.Linear(in_features, out_features, bias=bias)
        self.bn = nn.BatchNorm1d(out_features, eps=1e-4, affine=bias)
        self.activation = nn.LeakyReLU(inplace=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.linear(x)
        x = self.bn(x)
        x = self.activation(x)
        return x


class MLP(nn.Module):
    def __init__(self, x_dim: int, h_dims: list[int], rep_dim: int):
        super().__init__()
        neurons = [x_dim] + h_dims
        self.hidden = nn.ModuleList(
            [
                Linear_BN_leakyReLU(neurons[i], neurons[i + 1])
                for i in range(len(neurons) - 1)
            ]
        )
        self.code = nn.Linear(neurons[-1], rep_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x.view(x.size(0), -1)
        for layer in self.hidden:
            x = layer(x)
        return self.code(x)


class MLP_Decoder(nn.Module):
    def __init__(self, x_dim: int, h_dims: list[int], rep_dim: int):
        super().__init__()
        h_dims_rev = list(reversed(h_dims))
        neurons = [rep_dim] + h_dims_rev
        self.hidden = nn.ModuleList(
            [
                Linear_BN_leakyReLU(neurons[i], neurons[i + 1])
                for i in range(len(neurons) - 1)
            ]
        )
        self.reconstruction = nn.Linear(neurons[-1], x_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x.view(x.size(0), -1)
        for layer in self.hidden:
            x = layer(x)
        x = self.reconstruction(x)
        return torch.sigmoid(x)


class MLP_Autoencoder(nn.Module):
    def __init__(self, x_dim: int, h_dims: list[int], rep_dim: int):
        super().__init__()
        self.encoder = MLP(x_dim, h_dims, rep_dim)
        self.decoder = MLP_Decoder(x_dim, h_dims, rep_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        latent = self.encoder(x)
        return self.decoder(latent)