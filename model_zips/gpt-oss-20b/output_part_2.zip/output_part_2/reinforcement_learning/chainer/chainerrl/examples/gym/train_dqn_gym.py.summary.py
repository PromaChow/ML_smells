import argparse
import os
import random
import numpy as np
import torch
import torch.optim as optim
import gym
from garage import wrap_experiment, set_gpu_mode
from garage.envs import GymEnv
from garage.envs import CastObservationToFloat32, Monitor, ScaleReward, Render, ClipActionFilter
from garage.torch.algos.dqn import DQN
from garage.torch.q_functions import FCStateQFunctionWithDiscreteAction, FCQuadraticStateQFunction
from garage.torch.optimizers import Adam
from garage.torch.optimizers import make_optimizer
from garage.torch.optimizers import make_optimizer
from garage.torch.optimizers import Adam
from garage.explorers import LinearDecayEpsilonGreedy, AdditiveOU, Greedy
from garage.replay_buffer import ReplayBuffer, PrioritizedReplayBuffer
from garage.misc import joblib
from garage.misc import set_seed
from garage.misc import numpy_utils

def parse_args():
    parser = argparse.ArgumentParser(description='DQN training script')
    parser.add_argument('--env', type=str, default='Pendulum-v0',
                        help='Gym environment name')
    parser.add_argument('--outdir', type=str, default='results',
                        help='Output directory')
    parser.add_argument('--seed', type=int, default=0, help='Random seed')
    parser.add_argument('--gpu', type=str, default='0', help='GPU device index')
    parser.add_argument('--final-exploration-steps', type=int, default=10**4,
                        help='Number of steps over which epsilon decays')
    parser.add_argument('--start-epsilon', type=float, default=1.0,
                        help='Initial epsilon for epsilon-greedy')
    parser.add_argument('--end-epsilon', type=float, default=0.1,
                        help='Final epsilon for epsilon-greedy')
    parser.add_argument('--prioritized-replay', action='store_true',
                        help='Use prioritized replay buffer')
    parser.add_argument('--replay-start-size', type=int, default=1000,
                        help='Minimum replay buffer size before training')
    parser.add_argument('--n-hidden-channels', type=int, default=100,
                        help='Number of hidden channels in Q-network')
    parser.add_argument('--n-hidden-layers', type=int, default=2,
                        help='Number of hidden layers in Q-network')
    parser.add_argument('--steps', type=int, default=10**5,
                        help='Number of training steps')
    parser.add_argument('--gamma', type=float, default=0.99,
                        help='Discount factor')
    parser.add_argument('--target-update-interval', type=int, default=10**2,
                        help='Steps between target network updates')
    parser.add_argument('--target-update-method', type=str, default='hard',
                        help='Target network update method ("hard" or "soft")')
    parser.add_argument('--minibatch-size', type=int, default=32,
                        help='Mini-batch size for training')
    parser.add_argument('--load', type=str, default=None,
                        help='Path to pretrained model')
    parser.add_argument('--demo', action='store_true',
                        help='Run demo evaluation only')
    parser.add_argument('--eval-n-runs', type=int, default=10,
                        help='Number of evaluation episodes')
    parser.add_argument('--eval-interval', type=int, default=10**4,
                        help='Steps between evaluations')
    parser.add_argument('--monitor', action='store_true',
                        help='Enable Monitor wrapper')
    parser.add_argument('--reward-scale-factor', type=float, default=1e-3,
                        help='Reward scaling factor')
    parser.add_argument('--render-train', action='store_true',
                        help='Render training environment')
    parser.add_argument('--render-eval', action='store_true',
                        help='Render evaluation environment')
    parser.add_argument('--noisy-net-sigma', type=float, default=None,
                        help='Sigma for noisy nets (if set, use noisy nets)')
    return parser.parse_args()

def set_random_seeds(seed, gpu):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if gpu is not None:
        torch.cuda.manual_seed_all(seed)

def make_env(env_name, seed, test=False, monitor=False,
             reward_scale=1.0, render=False):
    env = GymEnv(env_name)
    env.seed(seed)
    env.action_space.seed(seed)
    env.observation_space.seed(seed)
    env = CastObservationToFloat32(env)
    if monitor:
        env = Monitor(env, log_dir=os.path.join(args.outdir, 'monitor'))
    if reward_scale != 1.0:
        env = ScaleReward(env, scale=reward_scale)
    if render:
        env = Render(env)
    env = ClipActionFilter(env)
    return env

def build_q_func(env, args):
    if isinstance(env.action_space, gym.spaces.Discrete):
        q_func = FCStateQFunctionWithDiscreteAction(
            env_spec=env.spec,
            n_hidden_channels=args.n_hidden_channels,
            n_hidden_layers=args.n_hidden_layers)
    else:
        q_func = FCQuadraticStateQFunction(
            env_spec=env.spec,
            n_hidden_channels=args.n_hidden_channels,
            n_hidden_layers=args.n_hidden_layers)
    if args.noisy_net_sigma is not None:
        q_func = q_func.apply_noisy_network(sigma=args.noisy_net_sigma)
    return q_func

def build_explorer(env, args):
    if isinstance(env.action_space, gym.spaces.Discrete):
        explorer = LinearDecayEpsilonGreedy(
            env_spec=env.spec,
            start_epsilon=args.start_epsilon,
            end_epsilon=args.end_epsilon,
            final_exploration_steps=args.final_exploration_steps)
    else:
        sigma = 0.2 * (env.action_space.high - env.action_space.low)
        explorer = AdditiveOU(
            env_spec=env.spec,
            sigma=sigma)
    if args.noisy_net_sigma is not None:
        explorer = Greedy(env_spec=env.spec)
    return explorer

def build_replay_buffer(args):
    capacity = int(5e5)
    if args.prioritized_replay:
        buffer = PrioritizedReplayBuffer(capacity=capacity)
    else:
        buffer = ReplayBuffer(capacity=capacity)
    return buffer

def evaluate(env, agent, n_runs):
    returns = []
    for _ in range(n_runs):
        state = env.reset()
        done = False
        total_reward = 0.0
        while not done:
            action = agent.act(state, deterministic=True)
            state, reward, done, _ = env.step(action)
            total_reward += reward
        returns.append(total_reward)
    arr = np.array(returns)
    return np.mean(arr), np.median(arr), np.std(arr)

def main(args):
    os.makedirs(args.outdir, exist_ok=True)
    set_gpu_mode(args.gpu)
    set_random_seeds(args.seed, args.gpu)

    train_env = make_env(args.env, args.seed, monitor=args.monitor,
                         reward_scale=args.reward_scale_factor,
                         render=args.render_train)
    eval_env = make_env(args.env, args.seed + 1, monitor=False,
                        reward_scale=1.0,
                        render=args.render_eval)

    q_func = build_q_func(train_env, args)
    explorer = build_explorer(train_env, args)
    replay_buffer = build_replay_buffer(args)

    optimizer = Adam(q_func.parameters())

    agent = DQN(
        q_func=q_func,
        opt=optimizer,
        rbuf=replay_buffer,
        gamma=args.gamma,
        explorer=explorer,
        target_update_interval=args.target_update_interval,
        target_update_method=args.target_update_method,
        minibatch_size=args.minibatch_size,
        replay_start_size=args.replay_start_size,
    )

    if args.load is not None:
        agent.restore(args.load)

    if args.demo:
        mean, median, std = evaluate(eval_env, agent, args.eval_n_runs)
        print(f'Demo Evaluation: mean={mean:.3f}, median={median:.3f}, std={std:.3f}')
        return

    state = train_env.reset()
    episode_reward = 0.0
    episode_step = 0
    for step in range(1, args.steps + 1):
        action = agent.act(state)
        next_state, reward, done, _ = train_env.step(action)
        agent.store(state, action, reward, next_state, done)
        state = next_state
        episode_reward += reward
        episode_step += 1

        if done:
            train_env.reset()
            state = train_env.reset()
            episode_reward = 0.0
            episode_step = 0

        if step % args.target_update_interval == 0:
            agent.update_target_network()

        if step % args.eval_interval == 0:
            mean, median, std = evaluate(eval_env, agent, args.eval_n_runs)
            log = {
                'step': step,
                'mean_reward': mean,
                'median_reward': median,
                'std_reward': std
            }
            print(log)
            with open(os.path.join(args.outdir, 'eval_log.txt'), 'a') as f:
                f.write(f'{log}\n')

    # Save final model
    agent.save(os.path.join(args.outdir, 'final_model'))

if __name__ == '__main__':
    args = parse_args()
    main(args)