import random
from dataclasses import dataclass, field
from typing import List, Tuple, Dict, Any, Optional
import numpy as np

# ------------------------------
# Basic game environment
# ------------------------------
class Game:
    def __init__(self):
        self.state = None
        self.done = False
        self.result = 0  # 1 if player1 wins, -1 if player2 wins, 0 draw
        self.turn = 0

    def reset(self):
        self.state = np.zeros((8, 8), dtype=int)  # placeholder state
        self.done = False
        self.result = 0
        self.turn = 0
        return self.state

    def get_legal_actions(self, state):
        # placeholder: return list of integer actions
        return list(range(10))

    def step(self, action):
        # placeholder: random outcome
        self.turn += 1
        if self.turn >= 20:
            self.done = True
            self.result = random.choice([1, -1, 0])
        return self.state, self.done, self.result

    def render(self):
        pass  # placeholder


# ------------------------------
# Neural network placeholder
# ------------------------------
class Residual_CNN:
    def __init__(self):
        self.weights = None

    def load_weights(self, path: str):
        self.weights = path  # placeholder

    def predict(self, state):
        # return policy logits and value
        pi = np.ones(10) / 10
        value = random.uniform(-1, 1)
        return pi, value


# ------------------------------
# Monte Carlo Tree Search
# ------------------------------
class MCTS:
    def __init__(self, network: Residual_CNN):
        self.network = network

    def select_action(self, state, temperature: bool) -> Tuple[int, np.ndarray, float, float]:
        pi, value = self.network.predict(state)
        if temperature:
            probs = pi
            action = int(np.random.choice(len(probs), p=probs))
        else:
            action = int(np.argmax(pi))
        mcts_value = value  # placeholder
        return action, pi, mcts_value, value


# ------------------------------
# Player abstractions
# ------------------------------
@dataclass
class Player:
    name: str

    def act(self, game: Game, mcts: Optional[MCTS], temperature: bool) -> Tuple[int, np.ndarray, float, float]:
        raise NotImplementedError


@dataclass
class User(Player):
    def act(self, game: Game, mcts: Optional[MCTS], temperature: bool):
        legal = game.get_legal_actions(game.state)
        action = random.choice(legal)
        pi = np.zeros(10)
        pi[action] = 1.0
        value = 0.0
        return action, pi, value, value


@dataclass
class Agent(Player):
    version: int
    network: Residual_CNN = field(default_factory=Residual_CNN)
    mcts: MCTS = field(init=False)

    def __post_init__(self):
        self.mcts = MCTS(self.network)

    def act(self, game: Game, mcts: Optional[MCTS], temperature: bool):
        return self.mcts.select_action(game.state, temperature)


# ------------------------------
# Memory buffer
# ------------------------------
@dataclass
class MemoryBuffer:
    moves: List[Dict[str, Any]] = field(default_factory=list)

    def add(self, move: Dict[str, Any]):
        self.moves.append(move)

    def commit(self):
        pass  # placeholder for persistence


# ------------------------------
# Logging placeholder
# ------------------------------
class Logger:
    def log(self, message: str):
        print(message)


logger = Logger()

# ------------------------------
# Core functions
# ------------------------------
def playMatchesBetweenVersions(
    version1: int,
    version2: int,
    EPISODES: int = 10,
    goes_first: Optional[int] = None,
    turns_until_tau0: int = 3,
) -> Tuple[Dict[str, int], List[MemoryBuffer], Dict[str, int], Dict[str, int]]:
    # Initialize players
    if version1 == -1:
        player1 = User(name="Human1")
    else:
        net1 = Residual_CNN()
        if version1 > 0:
            net1.load_weights(f"model_v{version1}.pth")
        player1 = Agent(name="Agent1", version=version1, network=net1)

    if version2 == -1:
        player2 = User(name="Human2")
    else:
        net2 = Residual_CNN()
        if version2 > 0:
            net2.load_weights(f"model_v{version2}.pth")
        player2 = Agent(name="Agent2", version=version2, network=net2)

    return playMatches(
        player1,
        player2,
        EPISODES=EPISODES,
        goes_first=goes_first,
        turns_until_tau0=turns_until_tau0,
    )


def playMatches(
    player1: Player,
    player2: Player,
    EPISODES: int,
    goes_first: Optional[int],
    turns_until_tau0: int,
) -> Tuple[Dict[str, int], List[MemoryBuffer], Dict[str, int], Dict[str, int]]:
    scores = {"win": 0, "draw": 0, "loss": 0}
    sp_scores = {"win": 0, "draw": 0, "loss": 0}
    points = {}
    memories = []

    for ep in range(EPISODES):
        game = Game()
        state = game.reset()
        memory = MemoryBuffer()
        # Determine first player
        if goes_first is None:
            current_player = random.choice([player1, player2])
        else:
            current_player = player1 if goes_first == 0 else player2

        turn = 0
        while not game.done:
            temperature = turn < turns_until_tau0
            action, pi, mcts_val, net_val = current_player.act(game, None, temperature)
            # Log action
            logger.log(
                f"Episode {ep}, Turn {turn}, Player {current_player.name}, Action {action}, "
                f"Pi {pi}, MCTS Val {mcts_val}, Net Val {net_val}"
            )
            memory.add(
                {
                    "state": state,
                    "action": action,
                    "pi": pi,
                    "mcts_val": mcts_val,
                    "net_val": net_val,
                    "player": current_player.name,
                }
            )
            state, done, result = game.step(action)
            # Switch player
            current_player = player2 if current_player == player1 else player1
            turn += 1

        # Assign final value to moves
        if result == 1:
            final_value = 1.0 if current_player == player1 else -1.0
        elif result == -1:
            final_value = -1.0 if current_player == player1 else 1.0
        else:
            final_value = 0.0

        for move in memory.moves:
            if move["player"] == current_player.name:
                move["final_value"] = final_value
            else:
                move["final_value"] = -final_value

        memory.commit()
        memories.append(memory)

        # Update scores
        if result == 1:
            scores["win"] += 1
            sp_scores["win"] += 1
            points[ep] = 1
        elif result == -1:
            scores["loss"] += 1
            sp_scores["loss"] += 1
            points[ep] = -1
        else:
            scores["draw"] += 1
            sp_scores["draw"] += 1
            points[ep] = 0

    return scores, memories, points, sp_scores
