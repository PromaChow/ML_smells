import numpy as np
import random

# --------------------------------------------
# Constants
# --------------------------------------------
BOARD_SIZE = 9  # 9x9 board
POLICY_CUTOFF_DEPTH = int(0.75 * BOARD_SIZE * BOARD_SIZE)
POLICY_FINISH_MOVES = int(0.2 * BOARD_SIZE * BOARD_SIZE)

# --------------------------------------------
# Board representation
# --------------------------------------------
class Board:
    EMPTY = 0
    BLACK = 1
    WHITE = 2

    def __init__(self, size=BOARD_SIZE):
        self.size = size
        self.state = np.full((size, size), self.EMPTY, dtype=int)
        self.turn = self.BLACK
        self.pass_count = 0
        self.move_history = []

    def clone(self):
        new_board = Board(self.size)
        new_board.state = self.state.copy()
        new_board.turn = self.turn
        new_board.pass_count = self.pass_count
        new_board.move_history = self.move_history.copy()
        return new_board

    def is_on_board(self, x, y):
        return 0 <= x < self.size and 0 <= y < self.size

    def is_legal(self, move):
        if move is None:
            return True
        x, y = move
        if not self.is_on_board(x, y):
            return False
        return self.state[y, x] == self.EMPTY

    def play_move(self, move):
        if move is None:
            self.pass_count += 1
        else:
            x, y = move
            self.state[y, x] = self.turn
            self.pass_count = 0
            self.move_history.append((self.turn, move))
        self.turn = self.BLACK if self.turn == self.WHITE else self.WHITE

    def is_game_over(self):
        return self.pass_count >= 2

    def all_coordinates(self):
        return [(x, y) for y in range(self.size) for x in range(self.size)]

    def fills_own_eye(self, move):
        # Placeholder for eye detection logic
        return False

# --------------------------------------------
# Move selection functions
# --------------------------------------------
def sorted_moves(probabilities, board):
    flat_indices = np.argsort(probabilities)[::-1]
    moves = [divmod(idx, board.size) for idx in flat_indices]
    return moves

def is_move_reasonable(move, board):
    return board.is_legal(move) and not board.fills_own_eye(move)

def select_random(board):
    legal_moves = [m for m in board.all_coordinates() if board.is_legal(m)]
    random.shuffle(legal_moves)
    return legal_moves[0] if legal_moves else None

def select_most_likely(probs, board):
    for move in sorted_moves(probs, board):
        if is_move_reasonable(move, board):
            return move
    return None

def select_weighted_random(probs, board):
    sorted_indices = np.argsort(probs)[::-1]
    sorted_probs = probs[sorted_indices]
    cumulative = np.cumsum(sorted_probs)
    total = cumulative[-1]
    if total == 0:
        return None
    r = random.uniform(0, total)
    idx = np.searchsorted(cumulative, r)
    move = divmod(sorted_indices[idx], board.size)
    if is_move_reasonable(move, board):
        return move
    return select_most_likely(probs, board)

# --------------------------------------------
# Policy network placeholder
# --------------------------------------------
class DummyPolicy:
    def __init__(self, size=BOARD_SIZE):
        self.size = size

    def __call__(self, board):
        # Return random probabilities over all positions
        probs = np.random.rand(self.size * self.size)
        return probs

# --------------------------------------------
# Simulation functions
# --------------------------------------------
def simulate_game_random(board):
    while not board.is_game_over():
        move = select_random(board)
        board.play_move(move)
    return board

def simulate_game(board, policy_network):
    moves_played = 0
    while moves_played < POLICY_CUTOFF_DEPTH and not board.is_game_over():
        probs = policy_network(board)
        move = select_weighted_random(probs, board)
        board.play_move(move)
        moves_played += 1
    return simulate_game_random(board)

def simulate_many_games(initial_boards, policy_black, policy_white):
    boards = [b.clone() for b in initial_boards]
    for board in boards:
        moves_played = 0
        current_policy = policy_black if board.turn == board.BLACK else policy_white
        while moves_played < POLICY_CUTOFF_DEPTH + POLICY_FINISH_MOVES and not board.is_game_over():
            probs = current_policy(board)
            move = select_weighted_random(probs, board)
            board.play_move(move)
            moves_played += 1
            current_policy = policy_white if board.turn == board.BLACK else policy_black
    for board in boards:
        simulate_game_random(board)
    return boards

# --------------------------------------------
# Player strategy mixins
# --------------------------------------------
class RandomPlayerMixin:
    def suggest_move(self, board):
        return select_random(board)

class GreedyPolicyPlayerMixin:
    def __init__(self, policy_network):
        self.policy_network = policy_network

    def suggest_move(self, board):
        probs = self.policy_network(board)
        return select_most_likely(probs, board)

class RandomPolicyPlayerMixin:
    def __init__(self, policy_network):
        self.policy_network = policy_network

    def suggest_move(self, board):
        probs = self.policy_network(board)
        return select_weighted_random(probs, board)

# --------------------------------------------
# Example usage
# --------------------------------------------
if __name__ == "__main__":
    # Create two dummy policies
    policy_black = DummyPolicy()
    policy_white = DummyPolicy()

    # Simulate a single game
    board = Board()
    simulate_game(board, policy_black)

    # Simulate many games in parallel
    initial_boards = [Board() for _ in range(5)]
    simulate_many_games(initial_boards, policy_black, policy_white)
