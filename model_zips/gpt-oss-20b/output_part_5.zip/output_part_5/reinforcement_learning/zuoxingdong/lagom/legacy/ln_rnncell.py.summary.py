import torch
import torch.nn as nn

class LayerNormLSTMCell(nn.RNNCellBase):
    def __init__(self, input_size, hidden_size, bias: bool = True, ln_preact: bool = True):
        super().__init__(input_size, hidden_size, bias)
        self.num_chunks = 4
        self.ln_preact = ln_preact
        if ln_preact:
            self.ln_ih = nn.LayerNorm(4 * hidden_size)
            self.ln_hh = nn.LayerNorm(4 * hidden_size)
        self.ln_cell = nn.LayerNorm(hidden_size)

    def forward(self, input: torch.Tensor, hx: torch.Tensor | None = None):
        self.check_forward_input(input)
        batch_size = input.shape[0]
        if hx is None:
            hx = torch.zeros(batch_size, 2 * self.hidden_size, device=input.device, dtype=input.dtype)
        else:
            hx = hx.to(input.device, dtype=input.dtype)
        h = hx[:, :self.hidden_size]
        c = hx[:, self.hidden_size:]
        self.check_forward_hidden(h)
        self.check_forward_hidden(c)

        ih = input @ self.weight_ih.t()
        if self.bias:
            ih += self.bias_ih
        hh = h @ self.weight_hh.t()
        if self.bias:
            hh += self.bias_hh

        if self.ln_preact:
            ih = self.ln_ih(ih)
            hh = self.ln_hh(hh)

        preact = ih + hh
        chunk = self.hidden_size
        f = preact[:, :chunk]
        i = preact[:, chunk:2 * chunk]
        o = preact[:, 2 * chunk:3 * chunk]
        g = preact[:, 3 * chunk:]

        f = torch.sigmoid(f)
        i = torch.sigmoid(i)
        o = torch.sigmoid(o)
        g = torch.tanh(g)

        c = f * c + i * g
        c = self.ln_cell(c)
        h = o * torch.tanh(c)

        return h, c

__all__ = ["LayerNormLSTMCell"]