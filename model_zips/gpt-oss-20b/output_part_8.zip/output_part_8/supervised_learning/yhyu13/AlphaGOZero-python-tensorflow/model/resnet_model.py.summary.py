import collections
import tensorflow as tf

# Hyperparameters
HParams = collections.namedtuple('HParams', [
    'batch_size',
    'num_classes',
    'lrn_rate',
    'num_residual_units',
    'use_bottleneck',
    'weight_decay_rate',
    'leaky_relu',
    'optimizer'
])

hps = HParams(
    batch_size=128,
    num_classes=10,
    lrn_rate=0.01,
    num_residual_units=5,
    use_bottleneck=False,
    weight_decay_rate=0.0005,
    leaky_relu=0.0,
    optimizer='Momentum'  # or 'SGD'
)

class ResNet:
    def __init__(self, images, labels, mode='train'):
        self.images = images
        self.labels = labels
        self.mode = mode
        self.global_step = tf.contrib.framework.get_or_create_global_step()
        self.build_graph()

    def build_graph(self):
        self.logits = self._build_model(self.images, self.global_step)
        self.predictions = tf.nn.softmax(self.logits)
        if self.mode == 'train':
            self._add_train_ops()
        else:
            self._add_eval_ops()

    def _build_model(self, images, global_step):
        net = self._init_conv(images)
        filters_list = [16, 64, 128, 256] if self.hps.use_bottleneck else [16, 16, 32, 64]
        strides = [2, 2, 2, 2]
        for i in range(len(filters_list)):
            net = self._make_residual_block(
                net,
                filters=filters_list[i],
                stride=strides[i],
                num_units=self.hps.num_residual_units,
                activate_before_residual=i == 0
            )
        net = tf.layers.batch_normalization(net, training=self.mode == 'train')
        net = tf.nn.relu(net)
        net = tf.reduce_mean(net, axis=[1, 2], keepdims=False)
        logits = tf.layers.dense(net, self.hps.num_classes, name='fc')
        return logits

    def _init_conv(self, images):
        net = tf.layers.conv2d(
            images,
            filters=16,
            kernel_size=3,
            strides=1,
            padding='SAME',
            use_bias=False,
            name='init_conv'
        )
        net = tf.layers.batch_normalization(net, training=self.mode == 'train')
        net = tf.nn.relu(net)
        return net

    def _make_residual_block(self, inputs, filters, stride, num_units, activate_before_residual):
        net = inputs
        for i in range(num_units):
            net = self._residual_unit(
                net,
                filters,
                stride if i == 0 else 1,
                activate_before_residual if i == 0 else False
            )
        return net

    def _residual_unit(self, inputs, filters, stride, activate_before_residual):
        shortcut = inputs
        if activate_before_residual:
            inputs = tf.layers.batch_normalization(inputs, training=self.mode == 'train')
            inputs = tf.nn.relu(inputs)
        if self.hps.use_bottleneck:
            inputs = self._bottleneck_unit(inputs, filters, stride)
        else:
            inputs = self._standard_unit(inputs, filters, stride)
        if shortcut.shape[-1] != filters or stride != 1:
            shortcut = self._shortcut_layer(shortcut, filters, stride)
        net = tf.add(inputs, shortcut)
        return net

    def _standard_unit(self, inputs, filters, stride):
        net = tf.layers.conv2d(
            inputs,
            filters=filters,
            kernel_size=3,
            strides=stride,
            padding='SAME',
            use_bias=False,
            name='conv1'
        )
        net = tf.layers.batch_normalization(net, training=self.mode == 'train')
        net = tf.nn.relu(net)
        net = tf.layers.conv2d(
            net,
            filters=filters,
            kernel_size=3,
            strides=1,
            padding='SAME',
            use_bias=False,
            name='conv2'
        )
        net = tf.layers.batch_normalization(net, training=self.mode == 'train')
        return net

    def _bottleneck_unit(self, inputs, filters, stride):
        bottleneck_filters = filters // 4
        net = tf.layers.conv2d(
            inputs,
            filters=bottleneck_filters,
            kernel_size=1,
            strides=stride,
            padding='SAME',
            use_bias=False,
            name='conv1'
        )
        net = tf.layers.batch_normalization(net, training=self.mode == 'train')
        net = tf.nn.relu(net)
        net = tf.layers.conv2d(
            net,
            filters=bottleneck_filters,
            kernel_size=3,
            strides=1,
            padding='SAME',
            use_bias=False,
            name='conv2'
        )
        net = tf.layers.batch_normalization(net, training=self.mode == 'train')
        net = tf.nn.relu(net)
        net = tf.layers.conv2d(
            net,
            filters=filters,
            kernel_size=1,
            strides=1,
            padding='SAME',
            use_bias=False,
            name='conv3'
        )
        net = tf.layers.batch_normalization(net, training=self.mode == 'train')
        return net

    def _shortcut_layer(self, inputs, filters, stride):
        if stride != 1:
            inputs = tf.nn.avg_pool2d(
                inputs,
                ksize=1,
                strides=stride,
                padding='SAME',
                name='avg_pool'
            )
        pad = filters - inputs.shape[-1]
        if pad > 0:
            padding = [[0, 0], [0, 0], [0, 0], [0, pad]]
            inputs = tf.pad(inputs, padding, "CONSTANT")
        return inputs

    def _add_train_ops(self):
        loss = self._compute_loss()
        self.loss = loss
        optimizer = self._get_optimizer()
        train_op = optimizer.minimize(loss, global_step=self.global_step)
        update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
        with tf.control_dependencies(update_ops):
            self.train_op = tf.group(train_op)
        self.summaries = tf.summary.merge([
            tf.summary.scalar('loss', loss),
            tf.summary.scalar('learning_rate', self.hps.lrn_rate),
            tf.summary.scalar('accuracy', self._accuracy())
        ])

    def _add_eval_ops(self):
        loss = self._compute_loss()
        self.loss = loss
        accuracy = self._accuracy()
        self.eval_op = tf.no_op(name='eval_op')
        self.summaries = tf.summary.merge([
            tf.summary.scalar('loss', loss),
            tf.summary.scalar('accuracy', accuracy),
            tf.summary.histogram('bn_mean', tf.layers.batch_normalization(self._init_conv(self.images)).moving_mean),
            tf.summary.histogram('bn_variance', tf.layers.batch_normalization(self._init_conv(self.images)).moving_variance)
        ])

    def _compute_loss(self):
        cross_entropy = tf.nn.sparse_softmax_cross_entropy_with_logits(
            logits=self.logits,
            labels=self.labels
        )
        loss = tf.reduce_mean(cross_entropy)
        wd = tf.add_n([tf.nn.l2_loss(v) for v in tf.trainable_variables() if 'DW' in v.name])
        loss += self.hps.weight_decay_rate * wd
        return loss

    def _accuracy(self):
        correct = tf.equal(tf.argmax(self.predictions, axis=1), self.labels)
        return tf.reduce_mean(tf.cast(correct, tf.float32))

    def _get_optimizer(self):
        if self.hps.optimizer == 'Momentum':
            return tf.train.MomentumOptimizer(
                learning_rate=self.hps.lrn_rate,
                momentum=0.9,
                use_nesterov=False
            )
        else:
            return tf.train.GradientDescentOptimizer(learning_rate=self.hps.lrn_rate)

# Example usage:
# images = tf.placeholder(tf.float32, [hps.batch_size, 32, 32, 3])
# labels = tf.placeholder(tf.int32, [hps.batch_size])
# model = ResNet(images, labels, mode='train')
# with tf.Session() as sess:
#     sess.run(tf.global_variables_initializer())
#     # Train loop...
```