import os
import pickle
import numpy as np
import pandas as pd
import quandl
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.metrics import accuracy_score, confusion_matrix
import warnings

warnings.filterwarnings("ignore")

# ----------------- Configuration -----------------
horizon = 30  # days
start_date = "2000-01-01"
end_date = "2014-12-31"
dataset = "WIKI/AAPL"

# Quandl API key (set as environment variable or replace with your key)
quandl.ApiConfig.api_key = os.getenv("QUANDL_API_KEY", "YOUR_API_KEY")

# ----------------- Data Retrieval -----------------
df = quandl.get(dataset, start_date=start_date, end_date=end_date)
df.reset_index(inplace=True)
df = df[['Date', 'Open', 'High', 'Low', 'Close', 'Adj. Open', 'Adj. High', 'Adj. Low', 'Adj. Close', 'Adj. Volume', 'Volume']]
df.drop(columns=['Adj. Open', 'Adj. High', 'Adj. Low', 'Adj. Close', 'Adj. Volume'], inplace=True)
df['Date'] = pd.to_datetime(df['Date'])

# ----------------- Technical Indicators -----------------
# Delta
df['Delta'] = df['Close'].shift(-horizon) / df['Close'] - 1

# Moving Averages
df['MA10'] = df['Close'].rolling(window=10).mean()
df['MA20'] = df['Close'].rolling(window=20).mean()
df['MA100'] = df['Close'].rolling(window=100).mean()

# ROC (Rate of Change)
df['ROC'] = df['Close'].pct_change(periods=14) * 100

# Bollinger Bands
sma20 = df['Close'].rolling(window=20).mean()
std20 = df['Close'].rolling(window=20).std()
df['BB_upper'] = sma20 + (std20 * 2)
df['BB_lower'] = sma20 - (std20 * 2)

# Stochastic Oscillator (%K)
low14 = df['Low'].rolling(window=14).min()
high14 = df['High'].rolling(window=14).max()
df['%K'] = 100 * (df['Close'] - low14) / (high14 - low14)

# MACD
ema12 = df['Close'].ewm(span=12, adjust=False).mean()
ema26 = df['Close'].ewm(span=26, adjust=False).mean()
df['MACD'] = ema12 - ema26
df['MACD_signal'] = df['MACD'].ewm(span=9, adjust=False).mean()

# RSI14
delta = df['Close'].diff()
gain = delta.clip(lower=0)
loss = -delta.clip(upper=0)
avg_gain = gain.rolling(window=14).mean()
avg_loss = loss.rolling(window=14).mean()
rs = avg_gain / avg_loss
df['RSI14'] = 100 - (100 / (1 + rs))

# CCI20
tp = (df['High'] + df['Low'] + df['Close']) / 3
sma_tp = tp.rolling(window=20).mean()
md = tp.rolling(window=20).apply(lambda x: np.mean(np.abs(x - np.mean(x))), raw=True)
df['CCI20'] = (tp - sma_tp) / (0.015 * md)

# ----------------- Target Variable -----------------
df['Class'] = np.where(df['Delta'] >= 0, 1, -1)
df['Class'] = df['Class'].shift(-horizon)

# ----------------- Data Cleaning -----------------
df = df.iloc[100:-horizon]  # remove first 100 and last horizon rows
df.fillna(-99999, inplace=True)

# ----------------- Features and Labels -----------------
X = df.drop(columns=['Date', 'Delta', 'Class'])
y = df['Class']

# Standardize features for SVM and KNN
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# ----------------- Train-Test Split -----------------
X_train, X_test, X_train_scaled, X_test_scaled, y_train, y_test = train_test_split(
    X, X_scaled, y, train_size=0.67, random_state=42, stratify=y
)

# ----------------- Model Training -----------------
svc = SVC(kernel='linear', probability=True, random_state=42)
knn = KNeighborsClassifier(n_neighbors=5)
rf = RandomForestClassifier(n_estimators=1000, random_state=42)

svc.fit(X_train_scaled, y_train)
knn.fit(X_train_scaled, y_train)
rf.fit(X_train, y_train)

voting = VotingClassifier(estimators=[('svc', svc), ('knn', knn), ('rf', rf)], voting='soft')
voting.fit(X_train_scaled, y_train)

# ----------------- Evaluation -----------------
models = {'SVM': svc, 'KNN': knn, 'Random Forest': rf, 'Voting': voting}
for name, model in models.items():
    if name in ['SVM', 'KNN', 'Voting']:
        pred = model.predict(X_test_scaled)
    else:
        pred = model.predict(X_test)
    acc = accuracy_score(y_test, pred)
    print(f"{name} Accuracy: {acc:.4f}")

# ----------------- Random Forest Analysis -----------------
print("\nRandom Forest Feature Importances:")
importances = pd.Series(rf.feature_importances_, index=X.columns).sort_values(ascending=False)
print(importances)

# Confusion Matrix
cm = confusion_matrix(y_test, rf.predict(X_test))
print("\nConfusion Matrix (Actual vs Predicted):")
print(pd.crosstab(y_test, rf.predict(X_test), rownames=['Actual'], colnames=['Predicted']))

# Prediction Details
print("\nPrediction Details (Sample 10):")
pred_probs = rf.predict_proba(X_test)[:, 1]
for idx in range(min(10, len(y_test))):
    print(f"Actual: {y_test.iloc[idx]}, Predicted: {rf.predict(X_test.iloc[idx:idx+1])[0]}, "
          f"Prob(1): {pred_probs[idx]:.4f}")

# ----------------- Model Persistence -----------------
with open('TrainedRFClassifier.pickle', 'wb') as f:
    pickle.dump(rf, f)