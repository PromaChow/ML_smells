import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity

def rmse(pred, actual):
    mask = (pred != 0) & (actual != 0)
    diff = pred[mask] - actual[mask]
    return np.sqrt(np.mean(diff ** 2))

def predict(rating_matrix, similarity_matrix, mode='user'):
    if mode == 'user':
        user_means = np.true_divide(rating_matrix.sum(axis=1), (rating_matrix != 0).sum(axis=1))
        user_means = np.nan_to_num(user_means)
        deviations = rating_matrix - user_means[:, None]
        sim = similarity_matrix.copy()
        np.fill_diagonal(sim, 0.0)
        weighted_devs = sim @ deviations
        denom = np.abs(sim).sum(axis=1)[:, None]
        # avoid division by zero
        denom[denom == 0] = 1
        predictions = user_means[:, None] + weighted_devs / denom
        return predictions
    else:  # item-based
        sim = similarity_matrix.copy()
        np.fill_diagonal(sim, 0.0)
        weighted_ratings = rating_matrix.T @ sim
        denom = np.abs(sim).sum(axis=1)[None, :]
        denom[denom == 0] = 1
        predictions = weighted_ratings / denom
        return predictions.T

# Load data
df = pd.read_csv('BX-Book-Ratings.csv', encoding='latin-1')
df = df.sort_values(['user_id', 'isbn'])
df = df.head(10000).reset_index(drop=True)

# Identify rating column
rating_col = [col for col in df.columns if 'rating' in col.lower()][0]

# Map users and items to indices
unique_users = df['user_id'].unique()
unique_isbns = df['isbn'].unique()
user_to_idx = {user: idx for idx, user in enumerate(unique_users)}
isbn_to_idx = {isbn: idx for idx, isbn in enumerate(unique_isbns)}

n_users = len(unique_users)
n_items = len(unique_isbns)

# Build rating matrix
rating_matrix = np.zeros((n_users, n_items))
for _, row in df.iterrows():
    u = user_to_idx[row['user_id']]
    i = isbn_to_idx[row['isbn']]
    rating_matrix[u, i] = row[rating_col]

# Compute similarities
user_similarity = cosine_similarity(rating_matrix)
item_similarity = cosine_similarity(rating_matrix.T)

# Predictions
user_based_pred = predict(rating_matrix, user_similarity, mode='user')
item_based_pred = predict(rating_matrix, item_similarity, mode='item')

# Evaluation
rmse_user = rmse(user_based_pred, rating_matrix)
rmse_item = rmse(item_based_pred, rating_matrix)

print(f'User-based RMSE: {rmse_user:.4f}')
print(f'Item-based RMSE: {rmse_item:.4f}')