import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import LinearSVC
import matplotlib.pyplot as plt
import seaborn as sns

# Load data
train_df = pd.read_csv('train.csv')
test_df = pd.read_csv('test.csv')
print("Train head:")
print(train_df.head())
print("\nTest head:")
print(test_df.head())

# Encode target variable
le = LabelEncoder()
train_df['species_encoded'] = le.fit_transform(train_df['species'])

# Define features and target
if 'species' in train_df.columns:
    X = train_df.drop(columns=['species', 'species_encoded'])
else:
    X = train_df.iloc[:, 1:]
Y = train_df['species_encoded']

# Split training data
X_train, X_val, y_train, y_val = train_test_split(
    X, Y, test_size=0.20, random_state=5, stratify=Y
)

# Random Forest
rf = RandomForestClassifier(random_state=5)
rf.fit(X_train, y_train)
rf_pred = rf.predict(X_val)
rf_acc = accuracy_score(y_val, rf_pred)
print(f"Random Forest Accuracy: {rf_acc:.4f}")

# Decision Tree
dt = DecisionTreeClassifier(random_state=5)
dt.fit(X_train, y_train)
dt_pred = dt.predict(X_val)
dt_acc = accuracy_score(y_val, dt_pred)
print(f"Decision Tree Accuracy: {dt_acc:.4f}")

# Gaussian Naive Bayes
gnb = GaussianNB()
gnb.fit(X_train, y_train)
gnb_pred = gnb.predict(X_val)
gnb_acc = accuracy_score(y_val, gnb_pred)
print(f"Gaussian Naive Bayes Accuracy: {gnb_acc:.4f}")

# Linear SVM
svc = LinearSVC(random_state=5, max_iter=10000)
svc.fit(X_train, y_train)
svc_pred = svc.predict(X_val)
svc_acc = accuracy_score(y_val, svc_pred)
print(f"Linear SVM Accuracy: {svc_acc:.4f}")

# Predict on test data using the best model (Naive Bayes)
test_features = test_df
if 'species' in test_features.columns:
    test_features = test_features.drop(columns=['species'])
predicted_encoded = gnb.predict(test_features)
predicted_labels = le.inverse_transform(predicted_encoded)

# Add predictions to test dataframe
test_df['species'] = predicted_labels
test_df.to_csv('Output.csv', index=False)
print("\nPredictions saved to Output.csv")