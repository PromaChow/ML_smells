import argparse
import os
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.datasets import make_moons
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim

def gen_ssl_moon_dataset(n_samples, n_labeled, noise=0.2, random_state=0):
    X, y = make_moons(n_samples=n_samples, noise=noise, random_state=random_state)
    # Normalize
    mean = X.mean(axis=0)
    std = X.std(axis=0)
    X = (X - mean) / std
    # Randomly select labeled samples per class
    labeled_indices = []
    unlabeled_indices = []
    for cls in [0, 1]:
        cls_idx = np.where(y == cls)[0]
        np.random.shuffle(cls_idx)
        labeled_cls = cls_idx[:n_labeled // 2]
        unlabeled_cls = cls_idx[n_labeled // 2:]
        labeled_indices.extend(labeled_cls)
        unlabeled_indices.extend(unlabeled_cls)
    np.random.shuffle(labeled_indices)
    np.random.shuffle(unlabeled_indices)
    X_l = X[labeled_indices]
    y_l = y[labeled_indices]
    X_u = X[unlabeled_indices]
    y_u = y[unlabeled_indices]
    return X_l, y_l, X_u, y_u

def gen_model():
    class SimpleNet(nn.Module):
        def __init__(self):
            super().__init__()
            self.fc1 = nn.Linear(2, 128)
            self.fc2 = nn.Linear(128, 256)
            self.fc3 = nn.Linear(256, 2)

        def forward(self, x):
            x = F.relu(self.fc1(x))
            x = F.relu(self.fc2(x))
            return self.fc3(x)
    return SimpleNet()

def weak_augmentation(X, std=0.1):
    noise = torch.randn_like(X) * std
    return X + noise

def gen_consistency():
    return nn.MSELoss()

def scatter_plot(X_l, y_l, X_u, out_dir):
    plt.figure(figsize=(6, 5))
    plt.scatter(X_u[:, 0], X_u[:, 1], color='gray', s=20, label='Unlabeled')
    plt.scatter(X_l[y_l==0, 0], X_l[y_l==0, 1], color='blue', s=20, label='Class 0')
    plt.scatter(X_l[y_l==1, 0], X_l[y_l==1, 1], color='red', s=20, label='Class 1')
    plt.legend()
    plt.title('Dataset')
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, 'scatter.png'))
    plt.close()

def scatter_plot_with_confidence(model, X_l, y_l, X_u, out_dir, device):
    # Create grid
    xmin, xmax = -2.5, 2.5
    ymin, ymax = -2.5, 2.5
    xx, yy = np.meshgrid(np.linspace(xmin, xmax, 200), np.linspace(ymin, ymax, 200))
    grid = np.vstack([xx.ravel(), yy.ravel()]).T
    grid_tensor = torch.tensor(grid, dtype=torch.float32).to(device)
    with torch.no_grad():
        logits = model(grid_tensor)
        probs = F.softmax(logits, dim=1)[:, 1].cpu().numpy()
    probs = probs.reshape(xx.shape)

    plt.figure(figsize=(6,5))
    sns.heatmap(probs, extent=(xmin, xmax, ymin, ymax), origin='lower', cmap='coolwarm', cbar=True)
    plt.scatter(X_u[:, 0], X_u[:, 1], color='white', s=10, label='Unlabeled')
    plt.scatter(X_l[y_l==0, 0], X_l[y_l==0, 1], color='blue', s=10, label='Class 0')
    plt.scatter(X_l[y_l==1, 0], X_l[y_l==1, 1], color='red', s=10, label='Class 1')
    plt.title('Confidence Map (Class 1 Probability)')
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, 'confidence.png'))
    plt.close()

def main():
    parser = argparse.ArgumentParser(description='SSL Two Moons Experiment')
    parser.add_argument('--n_samples', type=int, default=2000, help='Total dataset size')
    parser.add_argument('--n_labeled', type=int, default=200, help='Number of labeled samples')
    parser.add_argument('--lr', type=float, default=1e-3, help='Learning rate')
    parser.add_argument('--coef', type=float, default=0.5, help='Consistency loss coefficient')
    parser.add_argument('--entropy_minimize', action='store_true', help='Enable entropy minimization')
    parser.add_argument('--out_dir', type=str, default='results', help='Output directory')
    parser.add_argument('--vis_data', action='store_true', help='Display visualizations')
    parser.add_argument('--epochs', type=int, default=100, help='Number of epochs')
    args = parser.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)

    X_l_np, y_l_np, X_u_np, y_u_np = gen_ssl_moon_dataset(args.n_samples, args.n_labeled)
    X_l = torch.tensor(X_l_np, dtype=torch.float32)
    y_l = torch.tensor(y_l_np, dtype=torch.long)
    X_u = torch.tensor(X_u_np, dtype=torch.float32)
    y_u = torch.tensor(y_u_np, dtype=torch.long)  # not used but kept

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = gen_model().to(device)
    optimizer = optim.Adam(model.parameters(), lr=args.lr)
    consistency_criterion = gen_consistency()

    for epoch in range(1, args.epochs + 1):
        model.train()
        optimizer.zero_grad()

        # Augment unlabeled data twice
        X_u_aug1 = weak_augmentation(X_u).to(device)
        X_u_aug2 = weak_augmentation(X_u).to(device)
        # Prepare labeled data
        X_l_t = X_l.to(device)
        y_l_t = y_l.to(device)

        # Forward pass
        logits_l = model(X_l_t)
        logits_u1 = model(X_u_aug1)
        logits_u2 = model(X_u_aug2)

        # Labeled loss
        ce_loss = F.cross_entropy(logits_l, y_l_t)

        # Consistency loss
        consistency_loss = consistency_criterion(logits_u1, logits_u2)

        # Entropy minimization
        if args.entropy_minimize:
            probs_u1 = F.softmax(logits_u1, dim=1)
            entropy = -torch.sum(probs_u1 * torch.log(probs_u1 + 1e-6), dim=1).mean()
            entropy_loss = -entropy
        else:
            entropy_loss = 0

        total_loss = ce_loss + args.coef * consistency_loss + entropy_loss
        total_loss.backward()
        optimizer.step()

        if epoch % 10 == 0 or epoch == 1:
            print(f'Epoch {epoch:3d} | CE Loss: {ce_loss.item():.4f} | Consistency: {consistency_loss.item():.4f} | Entropy: {entropy_loss.item():.4f} | Total: {total_loss.item():.4f}')

    # Visualizations
    scatter_plot(X_l_np, y_l_np, X_u_np, args.out_dir)
    scatter_plot_with_confidence(model, X_l_np, y_l_np, X_u_np, args.out_dir, device)

    if args.vis_data:
        import matplotlib.image as mpimg
        img1 = mpimg.imread(os.path.join(args.out_dir, 'scatter.png'))
        img2 = mpimg.imread(os.path.join(args.out_dir, 'confidence.png'))
        plt.figure(figsize=(12,5))
        plt.subplot(1,2,1)
        plt.imshow(img1)
        plt.axis('off')
        plt.subplot(1,2,2)
        plt.imshow(img2)
        plt.axis('off')
        plt.show()

if __name__ == '__main__':
    main()
