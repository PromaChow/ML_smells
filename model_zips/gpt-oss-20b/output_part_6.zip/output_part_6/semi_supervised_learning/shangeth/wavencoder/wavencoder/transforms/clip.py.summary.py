import random
import torch

class Clipping:
    def __init__(self, clip_factors: list[float] = None, p: float = 0.5):
        self.clip_factors = clip_factors if clip_factors is not None else [0.3, 0.4, 0.5]
        self.p = p

    def __call__(self, wav: torch.Tensor) -> torch.Tensor:
        if random.random() < self.p:
            clip_factor = random.choice(self.clip_factors)
            wav_flat = wav.view(-1)
            min_val = torch.min(wav_flat)
            max_val = torch.max(wav_flat)
            lower = clip_factor * min_val
            upper = clip_factor * max_val
            clipped = torch.clamp(wav_flat, min=lower, max=upper)
            return clipped.view(1, -1)
        return wav

    def __repr__(self):
        return f"{self.__class__.__name__}(clip_factors={self.clip_factors})"