import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
from sklearn.datasets import make_classification
from sklearn.metrics import accuracy_score
import numpy as np

class StackedAutoEncoder(nn.Module):
    def __init__(self, input_dim=30, hidden_dims=[64, 32, 2], encoder=None, decoder=None):
        super().__init__()
        if encoder is None:
            layers = []
            dims = [input_dim] + hidden_dims
            for i in range(len(dims)-1):
                layers.append(nn.Linear(dims[i], dims[i+1]))
                layers.append(nn.ReLU())
            layers.pop()  # remove last ReLU
            self.encoder = nn.Sequential(*layers)
        else:
            self.encoder = encoder

        if decoder is None:
            layers = []
            dims = hidden_dims[::-1] + [input_dim]
            for i in range(len(dims)-1):
                layers.append(nn.Linear(dims[i], dims[i+1]))
                layers.append(nn.ReLU())
            layers.pop()  # remove last ReLU
            self.decoder = nn.Sequential(*layers)
        else:
            self.decoder = decoder

    def forward(self, x):
        z = self.encoder(x)
        recon = self.decoder(z)
        return recon

    def encode(self, x):
        return self.encoder(x)

class StackedAutoEncoderClassifier:
    def __init__(self, sae, num_classes, pretrain_epochs=100, finetune_epochs=200,
                 pretrain_lr=0.003, finetune_lr=0.003,
                 pretrain_weight_decay=1e-5, batch_size=64,
                 patience=10, device=None):
        self.sae = sae
        self.num_classes = num_classes
        self.pretrain_epochs = pretrain_epochs
        self.finetune_epochs = finetune_epochs
        self.pretrain_lr = pretrain_lr
        self.finetune_lr = finetune_lr
        self.pretrain_weight_decay = pretrain_weight_decay
        self.batch_size = batch_size
        self.patience = patience
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.sae.to(self.device)

        # classifier layer
        self.classifier = nn.Linear(self.sae.encoder[-1].out_features, num_classes)
        self.classifier.to(self.device)

        self.criterion_recon = nn.MSELoss()
        self.criterion_cls = nn.CrossEntropyLoss()

    def init_parameters(self, m):
        if isinstance(m, nn.Linear):
            if m.weight.size(0) == m.weight.size(1):
                nn.init.orthogonal_(m.weight)
            else:
                nn.init.xavier_uniform_(m.weight)
            nn.init.zeros_(m.bias)

    def pretrain(self, X):
        dataset = TensorDataset(X)
        loader = DataLoader(dataset, batch_size=self.batch_size, shuffle=True)
        optimizer = optim.Adam(self.sae.parameters(), lr=self.pretrain_lr,
                               weight_decay=self.pretrain_weight_decay)
        best_loss = float('inf')
        patience_counter = 0

        for epoch in range(self.pretrain_epochs):
            self.sae.train()
            epoch_loss = 0.0
            for batch in loader:
                data = batch[0].to(self.device)
                optimizer.zero_grad()
                recon = self.sae(data)
                loss = self.criterion_recon(recon, data)
                loss.backward()
                optimizer.step()
                epoch_loss += loss.item() * data.size(0)
            epoch_loss /= len(loader.dataset)
            if epoch_loss < best_loss:
                best_loss = epoch_loss
                patience_counter = 0
            else:
                patience_counter += 1
                if patience_counter >= self.patience:
                    break

    def finetune(self, X, y, X_val, y_val):
        dataset = TensorDataset(X, y)
        loader = DataLoader(dataset, batch_size=self.batch_size, shuffle=True)
        val_loader = DataLoader(TensorDataset(X_val, y_val), batch_size=self.batch_size)
        optimizer = optim.Adam(list(self.sae.parameters()) + list(self.classifier.parameters()),
                               lr=self.finetune_lr)
        best_val_loss = float('inf')
        patience_counter = 0

        for epoch in range(self.finetune_epochs):
            self.sae.train()
            self.classifier.train()
            epoch_loss = 0.0
            for batch in loader:
                data, target = batch[0].to(self.device), batch[1].to(self.device)
                optimizer.zero_grad()
                z = self.sae.encode(data)
                logits = self.classifier(z)
                loss = self.criterion_cls(logits, target)
                loss.backward()
                optimizer.step()
                epoch_loss += loss.item() * data.size(0)
            epoch_loss /= len(loader.dataset)

            # Validation
            self.sae.eval()
            self.classifier.eval()
            val_loss = 0.0
            with torch.no_grad():
                for val_batch in val_loader:
                    val_data, val_target = val_batch[0].to(self.device), val_batch[1].to(self.device)
                    z_val = self.sae.encode(val_data)
                    logits_val = self.classifier(z_val)
                    loss_val = self.criterion_cls(logits_val, val_target)
                    val_loss += loss_val.item() * val_data.size(0)
            val_loss /= len(val_loader.dataset)

            if val_loss < best_val_loss:
                best_val_loss = val_loss
                patience_counter = 0
            else:
                patience_counter += 1
                if patience_counter >= self.patience:
                    break

    def predict(self, X):
        self.sae.eval()
        self.classifier.eval()
        with torch.no_grad():
            data = X.to(self.device)
            z = self.sae.encode(data)
            logits = self.classifier(z)
            preds = torch.argmax(logits, dim=1)
        return preds.cpu()

def get_data():
    X_labeled, y_labeled = make_classification(n_samples=1000, n_features=30,
                                               n_informative=20, n_classes=2,
                                               random_state=42)
    X_unlabeled, y_unlabeled = make_classification(n_samples=500, n_features=30,
                                                   n_informative=20, n_classes=2,
                                                   random_state=24)
    X_test, y_test = make_classification(n_samples=200, n_features=30,
                                         n_informative=20, n_classes=2,
                                         random_state=12)
    X = np.concatenate([X_labeled, X_unlabeled], axis=0)
    y = np.concatenate([y_labeled, y_unlabeled], axis=0)
    X = torch.tensor(X, dtype=torch.float32)
    y = torch.tensor(y, dtype=torch.long)
    X_test = torch.tensor(X_test, dtype=torch.float32)
    y_test = torch.tensor(y_test, dtype=torch.long)
    return X, y, X_test, y_test

def main():
    X, y, X_test, y_test = get_data()

    sae = StackedAutoEncoder(input_dim=30, hidden_dims=[64, 32, 2])
    sae.apply(sae.init_parameters)

    classifier = StackedAutoEncoderClassifier(sae=sae, num_classes=2,
                                              pretrain_epochs=100,
                                              finetune_epochs=200,
                                              pretrain_lr=0.003,
                                              finetune_lr=0.003,
                                              pretrain_weight_decay=1e-5,
                                              batch_size=64,
                                              patience=10)

    classifier.pretrain(X)
    classifier.finetune(X, y, X_test, y_test)
    preds = classifier.predict(X_test)
    acc = accuracy_score(y_test.numpy(), preds.numpy())
    print(f'Accuracy on test set: {acc:.4f}')

if __name__ == "__main__":
    main()