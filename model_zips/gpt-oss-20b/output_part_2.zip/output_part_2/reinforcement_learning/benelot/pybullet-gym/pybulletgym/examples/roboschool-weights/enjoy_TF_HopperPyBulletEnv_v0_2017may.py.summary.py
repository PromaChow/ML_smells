import numpy as np

def relu(x: np.ndarray) -> np.ndarray:
    return np.maximum(0, x)

class SimpleNN:
    def __init__(
        self,
        weights_dense1_w: np.ndarray,
        weights_dense1_b: np.ndarray,
        weights_dense2_w: np.ndarray,
        weights_dense2_b: np.ndarray,
        weights_final_w: np.ndarray,
        weights_final_b: np.ndarray,
    ):
        self.w1 = weights_dense1_w
        self.b1 = weights_dense1_b
        self.w2 = weights_dense2_w
        self.b2 = weights_dense2_b
        self.wf = weights_final_w
        self.bf = weights_final_b

    def forward(self, x: np.ndarray) -> np.ndarray:
        h1 = relu(np.dot(x, self.w1) + self.b1)
        h2 = relu(np.dot(h1, self.w2) + self.b2)
        out = np.dot(h2, self.wf) + self.bf
        return out

if __name__ == "__main__":
    # Example weight initialization (replace with actual values)
    np.random.seed(0)
    weights_dense1_w = np.random.randn(256, 256)
    weights_dense1_b = np.random.randn(256)
    weights_dense2_w = np.random.randn(256, 256)
    weights_dense2_b = np.random.randn(256)
    weights_final_w = np.random.randn(256, 3)
    weights_final_b = np.random.randn(3)

    model = SimpleNN(
        weights_dense1_w,
        weights_dense1_b,
        weights_dense2_w,
        weights_dense2_b,
        weights_final_w,
        weights_final_b,
    )

    # Example input batch of 10 samples with 256 features each
    batch = np.random.randn(10, 256)
    predictions = model.forward(batch)
    print(predictions)