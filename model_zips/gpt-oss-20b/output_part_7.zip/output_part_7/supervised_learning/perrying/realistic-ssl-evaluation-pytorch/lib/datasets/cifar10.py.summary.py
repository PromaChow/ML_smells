import os
import numpy as np
from typing import Tuple, Any


class CIFAR10:
    """
    Simple dataset loader for CIFAR-10 stored as a .npy file containing a dictionary
    with keys 'images' and 'labels'.
    """

    def __init__(self, root: str, split: str = "l_train") -> None:
        """
        Initialize the dataset by loading the .npy file.

        Parameters
        ----------
        root : str
            Root directory containing the 'cifar10' subdirectory.
        split : str, optional
            Dataset split name (default: 'l_train').
        """
        file_path = os.path.join(root, "cifar10", f"{split}.npy")
        data = np.load(file_path, allow_pickle=True)
        # Ensure we get a dictionary even if the file was saved as a single-element array
        if isinstance(data, np.ndarray) and data.size == 1 and data.dtype == object:
            data = data.item()
        if not isinstance(data, dict):
            raise TypeError(f"Loaded data is not a dict: {type(data)}")
        if "images" not in data or "labels" not in data:
            raise KeyError("The loaded dict must contain 'images' and 'labels' keys.")
        self.dataset: dict[str, Any] = data

    def __len__(self) -> int:
        """
        Return the number of images in the dataset.
        """
        return len(self.dataset["images"])

    def __getitem__(self, idx: int) -> Tuple[Any, Any]:
        """
        Retrieve an image and its corresponding label by index.

        Parameters
        ----------
        idx : int
            Index of the desired item.

        Returns
        -------
        tuple
            (image, label)
        """
        if not isinstance(idx, int):
            raise TypeError(f"Index must be an integer, got {type(idx)}")
        n = len(self.dataset["images"])
        if idx < 0:
            idx += n
        if idx < 0 or idx >= n:
            raise IndexError("Index out of bounds")
        image = self.dataset["images"][idx]
        label = self.dataset["labels"][idx]
        return image, label

    def __repr__(self) -> str:
        return f"<CIFAR10 split={len(self.dataset['images'])} images>"