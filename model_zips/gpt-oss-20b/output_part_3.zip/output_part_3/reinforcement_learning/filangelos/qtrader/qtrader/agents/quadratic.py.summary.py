import numpy as np
from collections import deque
import random

class QuadraticOptimizer:
    def __init__(self, risk_aversion):
        self.risk_aversion = risk_aversion

    def solve(self, mu, sigma, prev_weights):
        mu = np.asarray(mu).flatten()
        sigma = np.asarray(sigma)
        M = mu.shape[0]
        try:
            import cvxpy as cp
            w = cp.Variable(M)
            objective = cp.Maximize(mu @ w - 0.5 * self.risk_aversion * cp.quad_form(w, sigma))
            constraints = [cp.sum(w) == 1, w >= 0]
            prob = cp.Problem(objective, constraints)
            prob.solve()
            if w.value is not None:
                w_val = np.asarray(w.value).flatten()
                w_val = w_val / np.sum(w_val)
                return w_val
        except Exception:
            pass
        try:
            inv_sigma = np.linalg.pinv(sigma)
            w_val = inv_sigma @ mu
            w_val = w_val / np.sum(w_val)
            w_val = np.maximum(w_val, 0)
            w_val = w_val / np.sum(w_val)
            return w_val
        except Exception:
            return prev_weights

class Pretrainer:
    @staticmethod
    def get_optimizer(J):
        if J == "risk_aversion":
            risk_lambda = 1.0
        elif J == "sharpe":
            risk_lambda = 0.0
        else:
            risk_lambda = 1.0
        return QuadraticOptimizer(risk_lambda)

    @staticmethod
    def map_objective(J):
        return Pretrainer.get_optimizer(J)

class QuadraticProgrammingAgent:
    def __init__(self, action_space, J, window):
        self.action_space = action_space
        self.J = J
        self.window = window
        self.optimizer = Pretrainer.map_objective(J)
        self.memory = deque(maxlen=window)
        self.w = self._sample_initial_weights()

    def _sample_initial_weights(self):
        samples = [random.uniform(a[0], a[1]) for a in self.action_space]
        total = sum(samples)
        if total == 0:
            return np.array([1.0 / len(samples)] * len(samples))
        return np.array(samples) / total

    def observe(self, observation):
        numeric = np.array(observation, dtype=float)
        self.memory.append(numeric)

    def act(self):
        if not self.memory:
            return self.w
        mem_arr = np.array(self.memory)
        M = mem_arr.shape[1]
        mu = np.mean(mem_arr, axis=0)
        if len(self.memory) < self.window:
            sigma = np.eye(M)
        else:
            sigma = np.cov(mem_arr.T, bias=False)
        new_w = self.optimizer.solve(mu, sigma, self.w)
        self.w = new_w
        return self.w

    def _J(self, J):
        return Pretrainer.map_objective(J)()