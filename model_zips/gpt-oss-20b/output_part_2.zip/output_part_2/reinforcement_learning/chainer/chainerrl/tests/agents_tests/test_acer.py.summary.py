import os
import tempfile
import warnings
import math
import random
import unittest
from collections import deque
from dataclasses import dataclass

import gym
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.multiprocessing as mp
from torch.optim import RMSprop

warnings.filterwarnings("ignore")
torch.manual_seed(0)
np.random.seed(0)
random.seed(0)


# ----------------- Helper Functions ----------------- #
def gaussian_logprob(mean, std, actions):
    var = std.pow(2)
    logp = -0.5 * ((actions - mean) ** 2 / var + torch.log(2 * math.pi * var))
    return logp.sum(-1)


def softmax_logprob(logits, actions):
    logp = F.log_softmax(logits, dim=-1)
    return logp.gather(-1, actions.unsqueeze(-1)).squeeze(-1)


def compute_importance(target_logprob, behavior_logprob, trunc=None):
    ratio = torch.exp(target_logprob - behavior_logprob)
    if trunc is not None:
        ratio = torch.clamp(ratio, max=trunc)
    return ratio


def compute_full_importance(target_logprobs, behavior_logprobs, trunc=None):
    ratio = compute_importance(target_logprobs, behavior_logprobs, trunc)
    return ratio.prod()


def compute_policy_gradient_full_correction(gamma, returns, weights):
    return (returns - weights.mean()) * weights


def compute_policy_gradient_sample_correction(gamma, returns, weights):
    return (returns - weights.mean()) * weights / (weights + 1e-8)


def compute_kl_divergence(p_logits, q_logits):
    p_logp = F.log_softmax(p_logits, dim=-1)
    q_logp = F.log_softmax(q_logits, dim=-1)
    p_p = F.softmax(p_logits, dim=-1)
    kl = (p_p * (p_logp - q_logp)).sum(-1).mean()
    return kl


# ----------------- Neural Network Models ----------------- #
class PolicyNet(nn.Module):
    def __init__(self, obs_dim, act_dim, continuous=False):
        super().__init__()
        self.continuous = continuous
        if continuous:
            self.fc = nn.Sequential(nn.Linear(obs_dim, 64), nn.ReLU(),
                                    nn.Linear(64, 64), nn.ReLU())
            self.mean_head = nn.Linear(64, act_dim)
            self.logstd_head = nn.Parameter(torch.zeros(act_dim))
        else:
            self.fc = nn.Sequential(nn.Linear(obs_dim, 64), nn.ReLU(),
                                    nn.Linear(64, 64), nn.ReLU(),
                                    nn.Linear(64, act_dim))

    def forward(self, x):
        h = self.fc(x)
        if self.continuous:
            mean = self.mean_head(h)
            std = torch.exp(self.logstd_head)
            return mean, std
        else:
            logits = self.fc[-1](h)
            return logits


class ValueNet(nn.Module):
    def __init__(self, obs_dim):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(obs_dim, 64), nn.ReLU(),
                                 nn.Linear(64, 64), nn.ReLU(),
                                 nn.Linear(64, 1))

    def forward(self, x):
        return self.net(x).squeeze(-1)


class QNet(nn.Module):
    def __init__(self, obs_dim, act_dim):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(obs_dim + act_dim, 64), nn.ReLU(),
                                 nn.Linear(64, 64), nn.ReLU(),
                                 nn.Linear(64, 1))

    def forward(self, x, a):
        inp = torch.cat([x, a], dim=-1)
        return self.net(inp).squeeze(-1)


# ----------------- Replay Buffer ----------------- #
@dataclass
class ReplaySample:
    state: torch.Tensor
    action: torch.Tensor
    reward: torch.Tensor
    next_state: torch.Tensor
    done: torch.Tensor
    logprob: torch.Tensor


class ReplayBuffer:
    def __init__(self, capacity):
        self.capacity = capacity
        self.buffer = deque(maxlen=capacity)

    def push(self, sample: ReplaySample):
        self.buffer.append(sample)

    def sample(self, batch_size):
        indices = np.random.choice(len(self.buffer), batch_size, replace=False)
        batch = [self.buffer[i] for i in indices]
        states = torch.stack([b.state for b in batch])
        actions = torch.stack([b.action for b in batch])
        rewards = torch.stack([b.reward for b in batch])
        next_states = torch.stack([b.next_state for b in batch])
        dones = torch.stack([b.done for b in batch])
        logprobs = torch.stack([b.logprob for b in batch])
        return states, actions, rewards, next_states, dones, logprobs

    def __len__(self):
        return len(self.buffer)


# ----------------- ACER Agent ----------------- #
class ACERAgent:
    def __init__(self, env, use_lstm=False, episodic=False, n_times_replay=1,
                 use_trust_region=False, gamma=0.99, beta=0.01, lr=3e-4):
        self.env = env
        self.gamma = gamma
        self.beta = beta
        self.use_lstm = use_lstm
        self.episodic = episodic
        self.n_times_replay = n_times_replay
        self.use_trust_region = use_trust_region

        obs_dim = env.observation_space.shape[0]
        if isinstance(env.action_space, gym.spaces.Discrete):
            act_dim = env.action_space.n
            self.continuous = False
        else:
            act_dim = env.action_space.shape[0]
            self.continuous = True

        self.policy_net = PolicyNet(obs_dim, act_dim, self.continuous)
        self.value_net = ValueNet(obs_dim)
        self.q_net = QNet(obs_dim, act_dim if not self.continuous else 1)

        self.optimizer = RMSprop(
            list(self.policy_net.parameters()) +
            list(self.value_net.parameters()) +
            list(self.q_net.parameters()), lr=lr, alpha=0.99, eps=1e-8)

        self.buffer = ReplayBuffer(capacity=50000)

    def select_action(self, state):
        state = torch.tensor(state, dtype=torch.float32).unsqueeze(0)
        if self.continuous:
            mean, std = self.policy_net(state)
            dist = torch.distributions.Normal(mean, std)
            action = dist.sample()
            logprob = dist.log_prob(action).sum(-1)
            return action.squeeze(0).detach().numpy(), logprob.item()
        else:
            logits = self.policy_net(state)
            probs = F.softmax(logits, dim=-1)
            dist = torch.distributions.Categorical(probs)
            action = dist.sample()
            logprob = dist.log_prob(action)
            return action.item(), logprob.item()

    def compute_returns(self, rewards, dones, next_value):
        R = next_value
        returns = []
        for r, d in zip(reversed(rewards), reversed(dones)):
            R = r + self.gamma * R * (1 - d)
            returns.insert(0, R)
        return returns

    def train_step(self, batch_size=64):
        if len(self.buffer) < batch_size:
            return
        states, actions, rewards, next_states, dones, logprobs = self.buffer.sample(batch_size)

        # Critic update
        values = self.value_net(states)
        next_values = self.value_net(next_states).detach()
        targets = rewards + self.gamma * next_values * (1 - dones)
        value_loss = F.mse_loss(values, targets)

        # Actor update
        if self.continuous:
            mean, std = self.policy_net(states)
            dist = torch.distributions.Normal(mean, std)
            new_logprobs = dist.log_prob(actions).sum(-1)
        else:
            logits = self.policy_net(states)
            probs = F.softmax(logits, dim=-1)
            new_logprobs = torch.log(probs.gather(-1, actions.unsqueeze(-1)).squeeze(-1))

        importance = torch.exp(new_logprobs - logprobs)
        td_errors = targets - values
        surrogate = importance * td_errors
        actor_loss = -surrogate.mean()

        # Trust region penalty
        if self.use_trust_region:
            kl = compute_kl_divergence(logits, logits.detach())
            actor_loss += self.beta * kl

        # Backprop
        self.optimizer.zero_grad()
        loss = value_loss + actor_loss
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.policy_net.parameters(), 0.5)
        torch.nn.utils.clip_grad_norm_(self.value_net.parameters(), 0.5)
        torch.nn.utils.clip_grad_norm_(self.q_net.parameters(), 0.5)
        self.optimizer.step()

    def run_episode(self, render=False, max_steps=200):
        state = self.env.reset()
        episode_reward = 0.0
        for _ in range(max_steps):
            action, logprob = self.select_action(state)
            next_state, reward, done, _ = self.env.step(action)
            sample = ReplaySample(
                state=torch.tensor(state, dtype=torch.float32),
                action=torch.tensor(action, dtype=torch.float32) if self.continuous else torch.tensor([action]),
                reward=torch.tensor(reward, dtype=torch.float32),
                next_state=torch.tensor(next_state, dtype=torch.float32),
                done=torch.tensor(float(done)),
                logprob=torch.tensor(logprob, dtype=torch.float32)
            )
            self.buffer.push(sample)
            state = next_state
            episode_reward += reward
            if render:
                self.env.render()
            if done:
                break
        return episode_reward

    def train(self, steps=2000, batch_size=64):
        for step in range(steps):
            self.run_episode()
            for _ in range(self.n_times_replay):
                self.train_step(batch_size)
            if step % 200 == 0 and step > 0:
                print(f"Step {step} training done.")


# ----------------- Test Classes ----------------- #
class TestDegenerateDistribution(unittest.TestCase):
    def test_gaussian_degeneracy(self):
        mean = torch.zeros(2)
        std = torch.full((2,), 1e-8)
        actions = torch.randn(5, 2) * std + mean
        logp = gaussian_logprob(mean, std, actions)
        self.assertFalse(torch.isnan(logp).any())

    def test_softmax_degeneracy(self):
        logits = torch.full((3, 5), 1e8)
        actions = torch.tensor([0, 1, 2, 0, 1])
        logp = softmax_logprob(logits, actions)
        self.assertFalse(torch.isnan(logp).any())

    def test_importance_ratios(self):
        target_logp = torch.tensor([-0.1, -0.2, -0.3])
        behavior_logp = torch.tensor([-1.0, -1.1, -1.2])
        ratios = compute_importance(target_logp, behavior_logp, trunc=10)
        self.assertTrue((ratios > 0).all())
        self.assertTrue((ratios <= 10).all())


class TestBiasCorrection(unittest.TestCase):
    def setUp(self):
        self.env = gym.make('CartPole-v1')
        self.agent = ACERAgent(self.env, gamma=0.99, n_times_replay=1)

    def test_bias_correction_effects(self):
        # Collect on-policy samples
        for _ in range(5):
            self.agent.run_episode(max_steps=50)
        self.agent.train_step(batch_size=32)
        on_policy_loss = self.agent.optimizer.state_dict()['param_groups'][0]['lr']

        # Collect off-policy samples by using a different policy
        behavior_policy = PolicyNet(self.env.observation_space.shape[0], self.env.action_space.n)
        for _ in range(5):
            state = self.env.reset()
            for _ in range(50):
                logits = behavior_policy(torch.tensor(state, dtype=torch.float32).unsqueeze(0))
                probs = F.softmax(logits, dim=-1)
                action = torch.multinomial(probs, 1).item()
                next_state, reward, done, _ = self.env.step(action)
                self.agent.buffer.push(ReplaySample(
                    state=torch.tensor(state, dtype=torch.float32),
                    action=torch.tensor([action]),
                    reward=torch.tensor(reward, dtype=torch.float32),
                    next_state=torch.tensor(next_state, dtype=torch.float32),
                    done=torch.tensor(float(done)),
                    logprob=torch.tensor(0.0)
                ))
                state = next_state
                if done:
                    break
        # Off-policy loss without importance sampling
        self.agent.train_step(batch_size=32)
        off_policy_loss = self.agent.optimizer.state_dict()['param_groups'][0]['lr']

        self.assertTrue(on_policy_loss < off_policy_loss)


class TestEfficientTRPO(unittest.TestCase):
    def test_kl_constraint(self):
        env = gym.make('CartPole-v1')
        agent = ACERAgent(env, gamma=0.99, use_trust_region=True)
        state = env.reset()
        logits_before = agent.policy_net(torch.tensor(state, dtype=torch.float32).unsqueeze(0))
        agent.run_episode(max_steps=10)
        logits_after = agent.policy_net(torch.tensor(state, dtype=torch.float32).unsqueeze(0))
        kl = compute_kl_divergence(logits_before, logits_after)
        self.assertLess(kl.item(), 1.0)


class TestACER(unittest.TestCase):
    def setUp(self):
        self.env = gym.make('CartPole-v1')
        self.output_dir = tempfile.mkdtemp()
        self.agent = ACERAgent(self.env, gamma=0.99, n_times_replay=1,
                               use_trust_region=False)
        self.agent.env = self.env

    def test_training_and_evaluation(self):
        # Train agent
        self.agent.train(steps=500, batch_size=32)
        # Evaluate
        rewards = []
        for _ in range(5):
            reward = self.agent.run_episode(max_steps=200)
            rewards.append(reward)
        avg_reward = np.mean(rewards)
        self.assertGreater(avg_reward, 50)


if __name__ == "__main__":
    unittest.main(verbosity=2)