import argparse
import os
import numpy as np
import pandas as pd
from sklearn.model_selection import KFold
from sklearn.linear_model import Lasso
from sklearn.metrics import mean_squared_error, r2_score
from scipy.stats import pearsonr
import warnings

warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=RuntimeWarning)

def load_embeddings(path):
    if path.endswith(".vec") or path.endswith(".bin"):
        from gensim.models import KeyedVectors
        return KeyedVectors.load_word2vec_format(path, binary=path.endswith(".bin"))
    else:
        return np.load(path, allow_pickle=True).item()

def compute_word_counts(posts):
    counts = {}
    for post in posts:
        for word in post.split():
            counts[word] = counts.get(word, 0) + 1
    return counts

def transformTextForTraining(posts, embeddings, word_counts, threshold, method):
    if hasattr(embeddings, "vector_size"):
        dim = embeddings.vector_size
    else:
        dim = next(iter(embeddings.values())).shape[0]
    X = []
    for post in posts:
        words = post.split()
        vecs = [embeddings[word] for word in words
                if word in embeddings and word_counts.get(word, 0) >= threshold]
        if not vecs:
            vecs = [np.zeros(dim)]
        vecs = np.array(vecs)
        if method == "sum":
            agg = np.sum(vecs, axis=0)
        elif method == "max":
            agg = np.max(vecs, axis=0)
        elif method == "min":
            agg = np.min(vecs, axis=0)
        elif method == "avg":
            agg = np.mean(vecs, axis=0)
        elif method == "conc":
            sum_vec = np.sum(vecs, axis=0)
            max_vec = np.max(vecs, axis=0)
            min_vec = np.min(vecs, axis=0)
            avg_vec = np.mean(vecs, axis=0)
            agg = np.concatenate([sum_vec, max_vec, min_vec, avg_vec])
        else:
            raise ValueError(f"Unknown method: {method}")
        X.append(agg)
    return np.array(X)

def main():
    parser = argparse.ArgumentParser(description="Lasso regression evaluation on Big Five traits.")
    parser.add_argument("--dataset", type=str, required=True, help="Path to myPersonality CSV file.")
    parser.add_argument("--embeddings", type=str, required=True, help="Path to embeddings file (.vec, .bin, or .npy).")
    parser.add_argument("--shuffle", action="store_true", help="Shuffle dataset before evaluation.")
    parser.add_argument("--threshold", type=int, default=2, help="Minimum word frequency in posts.")
    args = parser.parse_args()

    np.random.seed(42)

    df = pd.read_csv(args.dataset)
    if "post" not in df.columns:
        raise ValueError("Dataset must contain a 'post' column.")
    posts = df["post"].astype(str).tolist()
    traits = ["O", "C", "E", "A", "N"]
    for t in traits:
        if t not in df.columns:
            raise ValueError(f"Dataset must contain '{t}' column.")

    word_counts = compute_word_counts(posts)

    embeddings = load_embeddings(args.embeddings)

    methods = ["sum", "max", "min", "avg", "conc"]
    X_dict = {}
    for method in methods:
        X_dict[method] = transformTextForTraining(posts, embeddings, word_counts, args.threshold, method)

    subset_size = 100
    indices = np.arange(len(df))
    if args.shuffle:
        indices = np.random.permutation(indices)
        np.save("shuffled_indices.npy", indices)
    indices = indices[:subset_size]

    X_subset = {m: X_dict[m][indices] for m in methods}
    Y_subset = {t: df[t].values[indices] for t in traits}

    alpha_lasso = [0.01, 0.1, 1.0, 10.0, 100.0]
    n_folds = 10
    kf = KFold(n_splits=n_folds, shuffle=False, random_state=42)

    results = {}
    pcc_details = {}

    for trait in traits:
        y = Y_subset[trait]
        results[trait] = {}
        pcc_details[trait] = {}
        for method in methods:
            X = X_subset[method]
            results[trait][method] = {}
            pcc_details[trait][method] = {}
            for alpha in alpha_lasso:
                mse_list = []
                r2_list = []
                pcc_list = []
                pval_list = []
                for train_idx, test_idx in kf.split(X):
                    X_train, X_test = X[train_idx], X[test_idx]
                    y_train, y_test = y[train_idx], y[test_idx]
                    model = Lasso(alpha=alpha, max_iter=10000)
                    model.fit(X_train, y_train)
                    y_pred = model.predict(X_test)
                    mse_list.append(mean_squared_error(y_test, y_pred))
                    r2_list.append(r2_score(y_test, y_pred))
                    corr, pval = pearsonr(y_test, y_pred)
                    pcc_list.append(corr)
                    pval_list.append(pval)
                results[trait][method][alpha] = {
                    "mse_mean": np.mean(mse_list),
                    "r2_mean": np.mean(r2_list),
                    "pcc_mean": np.mean(pcc_list)
                }
                pcc_details[trait][method][alpha] = {
                    "fold_pcc": pcc_list,
                    "fold_pval": pval_list
                }

    os.makedirs("Results", exist_ok=True)
    dataset_name = os.path.splitext(os.path.basename(args.dataset))[0]
    shuffle_tag = "shuffle" if args.shuffle else "noShuffle"
    csv_path = f"Results/tuning_LASSO_{dataset_name}_{shuffle_tag}.csv"
    txt_path = f"Results/tuning_LASSO_{dataset_name}_{shuffle_tag}_pcc.txt"

    with open(csv_path, "w") as fcsv:
        fcsv.write("Trait,Method,Alpha,MSE,R2,PCC\n")
        for trait in traits:
            for method in methods:
                for alpha in alpha_lasso:
                    stats = results[trait][method][alpha]
                    fcsv.write(f"{trait},{method},{alpha},{stats['mse_mean']:.6f},{stats['r2_mean']:.6f},{stats['pcc_mean']:.6f}\n")

    with open(txt_path, "w") as ftxt:
        for trait in traits:
            ftxt.write(f"Trait: {trait}\n")
            for method in methods:
                ftxt.write(f"  Method: {method}\n")
                for alpha in alpha_lasso:
                    details = pcc_details[trait][method][alpha]
                    ftxt.write(f"    Alpha: {alpha}\n")
                    for i, (pcc, pval) in enumerate(zip(details["fold_pcc"], details["fold_pval"])):
                        ftxt.write(f"      Fold {i+1}: PCC={pcc:.6f}, p-value={pval:.6e}\n")
                ftxt.write("\n")
            ftxt.write("\n")

if __name__ == "__main__":
    main()
