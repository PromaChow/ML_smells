import numpy as np
from scipy import stats
import nlopt
from sklearn.base import clone
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

class CPLELearningModel:
    def __init__(
        self,
        base_estimator,
        pessimistic=True,
        sample_weight=False,
        unlabeledlambda=1.0,
        max_iter=1000,
        maxnoimprovementsince=5,
        buffersize=20,
        verbose=False,
        predict_from_probabilities=False,
    ):
        self.base_estimator = clone(base_estimator)
        self.pessimistic = pessimistic
        self.sample_weight = sample_weight
        self.unlabeledlambda = unlabeledlambda
        self.max_iter = max_iter
        self.maxnoimprovementsince = maxnoimprovementsince
        self.buffersize = buffersize
        self.verbose = verbose
        self.predict_from_probabilities = predict_from_probabilities

        self.plattlr = None
        self.best_softlabels = None
        self.final_model = None
        self.buffer = []

    def _probability(self, X):
        if hasattr(self.base_estimator, "predict_proba"):
            return self.base_estimator.predict_proba(X)
        else:
            preds = self.base_estimator.predict(X).reshape(-1, 1)
            return self.plattlr.predict_proba(preds)

    def _objective(self, x, grad):
        if grad is not None:
            grad[:] = 0.0
        self.best_softlabels = x.copy()
        probs = self._probability(self.X_unlabeled)
        # Labeled likelihood
        probs_labeled = self._probability(self.X_labeled)
        labeled_likelihood = np.sum(
            np.log(
                probs_labeled[
                    np.arange(len(self.y_labeled)),
                    self.y_labeled,
                ]
            )
        )
        # Unlabeled likelihood
        unlabeled_likelihood = np.sum(
            self.best_softlabels * np.log(probs[:, 0])
            + (1.0 - self.best_softlabels) * np.log(probs[:, 1])
        )
        if self.pessimistic:
            total_likelihood = labeled_likelihood - self.unlabeledlambda * unlabeled_likelihood
        else:
            total_likelihood = labeled_likelihood + self.unlabeledlambda * unlabeled_likelihood
        self.buffer.append(total_likelihood)
        # Convergence check
        if len(self.buffer) >= self.buffersize * 2:
            first_half = self.buffer[-self.buffersize * 2 : -self.buffersize]
            second_half = self.buffer[-self.buffersize :]
            t_stat, p_val = stats.ttest_ind(first_half, second_half, equal_var=False)
            if p_val > 0.05:
                if not hasattr(self, "_no_improve_counter"):
                    self._no_improve_counter = 0
                self._no_improve_counter += 1
                if self._no_improve_counter >= self.maxnoimprovementsince:
                    return -np.inf
            else:
                self._no_improve_counter = 0
        return -total_likelihood  # nlopt minimizes

    def fit(self, X, y):
        X = np.asarray(X)
        y = np.asarray(y)
        labeled_idx = y != -1
        unlabeled_idx = y == -1
        self.X_labeled = X[labeled_idx]
        self.y_labeled = y[labeled_idx]
        self.X_unlabeled = X[unlabeled_idx]
        self.n_unlabeled = len(self.X_unlabeled)

        self.base_estimator.fit(self.X_labeled, self.y_labeled)

        # Platt scaling if needed
        if not hasattr(self.base_estimator, "predict_proba"):
            base_preds = self.base_estimator.predict(self.X_labeled).reshape(-1, 1)
            self.plattlr = LogisticRegression(solver="lbfgs")
            self.plattlr.fit(base_preds, self.y_labeled)

        # Initial soft labels (hard predictions)
        unlabeled_hard = self.base_estimator.predict(self.X_unlabeled)
        soft_init = (unlabeled_hard == 0).astype(float)

        # Optimization
        opt = nlopt.opt(nlopt.GN_DIRECT_L_RAND, self.n_unlabeled)
        opt.set_lower_bounds(np.zeros(self.n_unlabeled))
        opt.set_upper_bounds(np.ones(self.n_unlabeled))
        opt.set_maxeval(self.max_iter)
        opt.set_min_objective(self._objective)
        if self.verbose:
            opt.set_print_level(nlopt.PR_ERR)

        self.best_softlabels = opt.optimize(soft_init)
        self.best_softlabels = np.clip(self.best_softlabels, 0.0, 1.0)

        # Final training on all data
        if self.sample_weight:
            weights_labeled = np.ones(len(self.y_labeled))
            weights_unlabeled = self.best_softlabels
            sample_weights = np.concatenate([weights_labeled, weights_unlabeled])
        else:
            sample_weights = None

        X_all = np.concatenate([self.X_labeled, self.X_unlabeled])
        y_all = np.concatenate([self.y_labeled, np.full(self.n_unlabeled, -1)])

        self.final_model = clone(self.base_estimator)
        self.final_model.fit(X_all, y_all, sample_weight=sample_weights)

        return self

    def predict(self, X):
        X = np.asarray(X)
        if self.predict_from_probabilities:
            probs = self._probability(X)
            return (probs[:, 0] >= 0.5).astype(int)
        else:
            return self.final_model.predict(X)

    def score(self, X, y):
        y_pred = self.predict(X)
        return accuracy_score(y, y_pred)