import os
import tempfile
import shutil
import pytest
import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim.lr_scheduler import LambdaLR
import numpy as np
import gym
from collections import deque

# Simple DQN implementation for testing purposes
class SimpleDQN(nn.Module):
    def __init__(self, input_shape, num_actions, hidden_size=128, mode="vanilla", device="cpu"):
        super().__init__()
        if mode not in {"vanilla", "fixed_target", "double"}:
            raise ValueError(f"Unsupported mode {mode}")
        self.mode = mode
        self.device = device
        self.net = nn.Sequential(
            nn.Flatten(),
            nn.Linear(np.prod(input_shape), hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, num_actions)
        ).to(self.device)
        self.target_net = nn.Linear(hidden_size, num_actions).to(self.device)
        self.optimizer = optim.Adam(self.net.parameters(), lr=1e-3)
        self.replay_buffer = []
        self.lr_scheduler = None

    def act_discrete(self, state):
        state = torch.tensor(state, dtype=torch.float32, device=self.device).unsqueeze(0)
        with torch.no_grad():
            q = self.net(state)
        return int(q.argmax(dim=1).item())

    def act_discrete_with_noise(self, state, epsilon=0.1):
        if np.random.rand() < epsilon:
            return np.random.randint(self.net[-1].out_features)
        return self.act_discrete(state)

    def _criticize(self, states):
        states = torch.tensor(states, dtype=torch.float32, device=self.device)
        with torch.no_grad():
            return self.net(states)

    def store_episode(self, states, actions, rewards, terminals):
        for s, a, r, t in zip(states, actions, rewards, terminals):
            self.replay_buffer.append((s, a, r, t))

    def update(self, batch_size=32, sync_target=True):
        if len(self.replay_buffer) < batch_size:
            return
        batch = np.random.choice(self.replay_buffer, batch_size, replace=False)
        states, actions, rewards, terminals = zip(*batch)
        states = torch.tensor(states, dtype=torch.float32, device=self.device)
        actions = torch.tensor(actions, dtype=torch.long, device=self.device)
        rewards = torch.tensor(rewards, dtype=torch.float32, device=self.device)
        terminals = torch.tensor(terminals, dtype=torch.float32, device=self.device)

        q_values = self.net(states).gather(1, actions.unsqueeze(1)).squeeze(1)
        with torch.no_grad():
            next_q = self.target_net(states).max(1)[0]
        targets = rewards + (1 - terminals) * 0.99 * next_q
        loss = nn.functional.mse_loss(q_values, targets)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        if sync_target:
            self.target_net.load_state_dict(self.net.state_dict())

    def save(self, path):
        torch.save(self.state_dict(), path)

    def load(self, path):
        self.load_state_dict(torch.load(path))

    def update_lr_scheduler(self, scheduler):
        self.lr_scheduler = scheduler

    def step_lr_scheduler(self):
        if self.lr_scheduler is not None:
            self.lr_scheduler.step()

    @classmethod
    def generate_config(cls, **kwargs):
        return dict(kwargs)

    @classmethod
    def init_from_config(cls, config):
        return cls(**config)


# Fixtures
@pytest.fixture
def env():
    env = gym.make("CartPole-v0")
    yield env
    env.close()


@pytest.fixture
def train_config():
    return {
        "env_name": "CartPole-v0",
        "max_episodes": 1000,
        "max_steps_per_episode": 200,
        "replay_buffer_size": 10000,
        "batch_size": 32,
        "reward_threshold": 150,
        "smooth_window": 5,
    }


@pytest.fixture
def dqn(env):
    return SimpleDQN(
        input_shape=env.observation_space.shape,
        num_actions=env.action_space.n,
        hidden_size=64,
        mode="double",
        device="cpu",
    )


@pytest.fixture
def dqn_vis(env):
    with tempfile.TemporaryDirectory() as tmpdir:
        dqn = SimpleDQN(
            input_shape=env.observation_space.shape,
            num_actions=env.action_space.n,
            hidden_size=64,
            mode="double",
            device="cpu",
        )
        dqn.vis_dir = tmpdir
        yield dqn


@pytest.fixture
def dqn_lr(env):
    dqn = SimpleDQN(
        input_shape=env.observation_space.shape,
        num_actions=env.action_space.n,
        hidden_size=64,
        mode="double",
        device="cpu",
    )
    lr_func = lambda epoch: 0.001 * (0.99 ** epoch)
    scheduler = LambdaLR(dqn.optimizer, lr_lambda=lr_func)
    dqn.update_lr_scheduler(scheduler)
    return dqn


@pytest.fixture
def dqn_train(env):
    return SimpleDQN(
        input_shape=env.observation_space.shape,
        num_actions=env.action_space.n,
        hidden_size=64,
        mode="double",
        device="cpu",
    )


# Tests
def test_mode_validation():
    with pytest.raises(ValueError):
        SimpleDQN(
            input_shape=(4,),
            num_actions=2,
            mode="invalid_mode",
            device="cpu",
        )


def test_act_discrete_and_noise(dqn, env):
    state = env.reset()
    action = dqn.act_discrete(state)
    assert isinstance(action, int)
    assert 0 <= action < env.action_space.n
    action_noise = dqn.act_discrete_with_noise(state, epsilon=1.0)
    assert isinstance(action_noise, int)
    assert 0 <= action_noise < env.action_space.n


def test_criticize(dqn, env):
    state = env.reset()
    q_vals = dqn._criticize([state])
    assert q_vals.shape == (1, env.action_space.n)


def test_episode_storage(dqn, env):
    states, actions, rewards, terminals = [], [], [], []
    for _ in range(10):
        s = env.reset()
        a = dqn.act_discrete(s)
        next_s, r, done, _ = env.step(a)
        states.append(s)
        actions.append(a)
        rewards.append(r)
        terminals.append(float(done))
        if done:
            break
    dqn.store_episode(states, actions, rewards, terminals)
    assert len(dqn.replay_buffer) == len(states)


def test_update_mechanism(dqn, env):
    # Fill buffer
    states, actions, rewards, terminals = [], [], [], []
    for _ in range(50):
        s = env.reset()
        a = dqn.act_discrete(s)
        next_s, r, done, _ = env.step(a)
        states.append(s)
        actions.append(a)
        rewards.append(r)
        terminals.append(float(done))
        if done:
            break
    dqn.store_episode(states, actions, rewards, terminals)
    pre_params = [p.clone() for p in dqn.net.parameters()]
    dqn.update(batch_size=16, sync_target=True)
    post_params = [p for p in dqn.net.parameters()]
    assert any(not torch.equal(p, pre) for p, pre in zip(post_params, pre_params))
    # Target net should be synced
    target_params = [p.clone() for p in dqn.target_net.parameters()]
    dqn.update(batch_size=16, sync_target=True)
    assert all(torch.equal(p, tgt) for p, tgt in zip(dqn.target_net.parameters(), target_params))


def test_model_saving_loading(dqn):
    with tempfile.NamedTemporaryFile() as tmpfile:
        dqn.save(tmpfile.name)
        # Modify parameters
        for p in dqn.net.parameters():
            p.data.fill_(0)
        dqn.load(tmpfile.name)
        # Check parameters restored (just check one)
        for p in dqn.net.parameters():
            assert not torch.all(p == 0)


def test_learning_rate_scheduler(dqn_lr):
    init_lr = dqn_lr.optimizer.param_groups[0]["lr"]
    dqn_lr.step_lr_scheduler()
    updated_lr = dqn_lr.optimizer.param_groups[0]["lr"]
    assert updated_lr != init_lr


def test_config_initialization(dqn, env):
    config = SimpleDQN.generate_config(
        input_shape=env.observation_space.shape,
        num_actions=env.action_space.n,
        hidden_size=64,
        mode="double",
        device="cpu",
    )
    new_dqn = SimpleDQN.init_from_config(config)
    assert isinstance(new_dqn, SimpleDQN)
    assert new_dqn.mode == "double"
    assert new_dqn.net[-1].out_features == env.action_space.n


def test_end_to_end_training(dqn_train, env, train_config):
    smoother = deque(maxlen=train_config["smooth_window"])
    solved = False
    for episode in range(train_config["max_episodes"]):
        state = env.reset()
        episode_reward = 0
        for step in range(train_config["max_steps_per_episode"]):
            action = dqn_train.act_discrete_with_noise(state, epsilon=0.1)
            next_state, reward, done, _ = env.step(action)
            dqn_train.store_episode([state], [action], [reward], [float(done)])
            dqn_train.update(batch_size=train_config["batch_size"])
            state = next_state
            episode_reward += reward
            if done:
                break
        smoother.append(episode_reward)
        if len(smoother) == train_config["smooth_window"] and sum(smoother) >= train_config["reward_threshold"]:
            solved = True
            break
    assert solved, f"Did not solve within {train_config['max_episodes']} episodes"
    env.close()
```