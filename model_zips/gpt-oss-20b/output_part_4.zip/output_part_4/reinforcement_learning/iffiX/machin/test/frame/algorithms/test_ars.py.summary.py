import gym
import numpy as np
import pytest
import torch
import torch.nn as nn
import torch.optim as optim
from collections import defaultdict, deque

# ---------- Utility Classes ----------
class Smooth:
    """Running average of last `window` values."""
    def __init__(self, window=100):
        self.window = window
        self.values = deque(maxlen=window)

    def update(self, value):
        self.values.append(value)

    def mean(self):
        return np.mean(self.values) if self.values else 0.0


# ---------- Actor Network ----------
class ActorDiscrete(nn.Module):
    def __init__(self, state_dim, action_dim):
        super().__init__()
        self.linear = nn.Linear(state_dim, action_dim)

    def forward(self, x):
        return self.linear(x)

    def act(self, state):
        logits = self.forward(state)
        return torch.argmax(logits, dim=-1).item()


# ---------- ARS Implementation ----------
class ARS:
    def __init__(
        self,
        actor: nn.Module,
        noise_std_dev: float = 0.1,
        noise_size: int = 1000,
        rollout_num: int = 6,
        learning_rate: float = 0.1,
    ):
        self.actor = actor
        self.noise_std_dev = noise_std_dev
        self.noise_size = noise_size
        self.rollout_num = rollout_num
        self.optimizer = optim.SGD(self.actor.parameters(), lr=learning_rate)
        self.noises = [torch.randn_like(param) * noise_std_dev for _ in range(noise_size)]
        self.rewards = defaultdict(list)

    # ---------- Static Module Wrapper (dummy) ----------
    @staticmethod
    def static_module_wrapper(module: nn.Module) -> nn.Module:
        return module

    # ---------- Learning Rate Generator ----------
    @staticmethod
    def gen_learning_rate_func(schedule):
        def lr_func(step):
            for s, lr in reversed(schedule):
                if step >= s:
                    return lr
            return schedule[0][1]
        return lr_func

    # ---------- Action Methods ----------
    def act(self, state: torch.Tensor, actor_type: str):
        if actor_type not in {"original", "neg"}:
            raise ValueError(f"Unsupported actor_type {actor_type}")
        with torch.no_grad():
            return self.actor.act(state)

    # ---------- Reward Storage ----------
    def store_reward(self, actor_type: str, reward: float):
        if actor_type not in {"original", "neg"}:
            raise ValueError(f"Unsupported actor_type {actor_type}")
        self.rewards[actor_type].append(reward)

    # ---------- Update ----------
    def update(self):
        if not self.rewards:
            return
        # Simple ARS update: use mean reward to weight noise
        mean_rewards = {k: np.mean(v) for k, v in self.rewards.items()}
        # Reset optimizer grads
        self.optimizer.zero_grad()
        # Apply weighted noise update
        for i, noise in enumerate(self.noises):
            weight = 0.0
            for k, mean_r in mean_rewards.items():
                weight += mean_r
            # Scale by learning rate
            for param, n in zip(self.actor.parameters(), noise):
                if param.grad is None:
                    param.grad = torch.zeros_like(param)
                param.grad.data += weight * n
        self.optimizer.step()
        self.rewards.clear()

    # ---------- Configuration ----------
    @staticmethod
    def generate_config(
        env_name="CartPole-v0",
        max_episodes=1000,
        max_steps=200,
        solved_reward=150,
        noise_std_dev=0.1,
        noise_size=1000,
        rollout_num=6,
        learning_rate=0.1,
    ):
        return {
            "env_name": env_name,
            "max_episodes": max_episodes,
            "max_steps": max_steps,
            "solved_reward": solved_reward,
            "noise_std_dev": noise_std_dev,
            "noise_size": noise_size,
            "rollout_num": rollout_num,
            "learning_rate": learning_rate,
        }

    @classmethod
    def from_config(cls, config):
        env = gym.make(config["env_name"])
        state_dim = env.observation_space.shape[0]
        action_dim = env.action_space.n
        actor = ActorDiscrete(state_dim, action_dim)
        return cls(
            actor=actor,
            noise_std_dev=config["noise_std_dev"],
            noise_size=config["noise_size"],
            rollout_num=config["rollout_num"],
            learning_rate=config["learning_rate"],
        )


# ---------- Dummy Parallel Decorators ----------
def run_multi(func):
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)
    return wrapper


def setup_world(func):
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)
    return wrapper


# ---------- Dummy Training Group ----------
class DummyTrainingGroup:
    def barrier(self):
        pass


# ---------- Unit Tests ----------
@pytest.fixture
def ars_instance():
    env = gym.make("CartPole-v0")
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.n
    actor = ActorDiscrete(state_dim, action_dim)
    return ARS(
        actor=actor,
        noise_std_dev=0.1,
        noise_size=10,
        rollout_num=6,
        learning_rate=0.1,
    )


class TestARS:
    @run_multi
    @setup_world
    def test_act(self, ars_instance):
        state = torch.zeros(4)
        for t in ("original", "neg"):
            action = ars_instance.act(state, t)
            assert isinstance(action, int)
            assert 0 <= action < 2
        with pytest.raises(ValueError):
            ars_instance.act(state, "invalid_type")

    @run_multi
    @setup_world
    def test_store_reward(self, ars_instance):
        ars_instance.store_reward("original", 10.0)
        ars_instance.store_reward("neg", -5.0)
        assert len(ars_instance.rewards["original"]) == 1
        assert len(ars_instance.rewards["neg"]) == 1
        with pytest.raises(ValueError):
            ars_instance.store_reward("bad", 1.0)

    @run_multi
    @setup_world
    def test_update(self, ars_instance):
        ars_instance.store_reward("original", 10.0)
        ars_instance.store_reward("neg", 20.0)
        prev_weights = [p.clone() for p in ars_instance.actor.parameters()]
        ars_instance.update()
        for prev, new in zip(prev_weights, ars_instance.actor.parameters()):
            assert not torch.allclose(prev, new)

    @run_multi
    @setup_world
    def test_lr_scheduler(self):
        schedule = [(0, 1e-3), (200000, 3e-4)]
        lr_func = ARS.gen_learning_rate_func(schedule)
        assert lr_func(0) == 1e-3
        assert lr_func(200000) == 3e-4
        assert lr_func(150000) == 1e-3

    @run_multi
    @setup_world
    def test_config_init(self):
        config = ARS.generate_config(
            max_episodes=500,
            max_steps=200,
            solved_reward=150,
            noise_std_dev=0.05,
            noise_size=5,
            rollout_num=4,
            learning_rate=0.05,
        )
        ars = ARS.from_config(config)
        assert isinstance(ars.actor, ActorDiscrete)
        ars.store_reward("original", 10.0)
        ars.update()
        assert len(ars.rewards) == 0

    @run_multi
    @setup_world
    def test_full_train(self):
        config = ARS.generate_config(
            max_episodes=200,
            max_steps=200,
            solved_reward=150,
            noise_std_dev=0.05,
            noise_size=5,
            rollout_num=4,
            learning_rate=0.05,
        )
        ars = ARS.from_config(config)
        env = gym.make(config["env_name"])
        env.seed(0)
        smooth = Smooth(window=50)
        training_group = DummyTrainingGroup()

        for episode in range(config["max_episodes"]):
            obs = env.reset()
            total_reward = 0.0
            for t in range(config["max_steps"]):
                state = torch.tensor(obs, dtype=torch.float32)
                action = ars.act(state, "original")
                obs, reward, done, _ = env.step(action)
                total_reward += reward
                if done:
                    break
            ars.store_reward("original", total_reward)
            ars.update()
            smooth.update(total_reward)
            if smooth.mean() >= config["solved_reward"]:
                break
            training_group.barrier()
        assert smooth.mean() >= config["solved_reward"] or episode == config["max_episodes"] - 1
        env.close()
        ars.actor.cpu()
        torch.cuda.empty_cache()
        assert ars.actor is not None
        pytest.skip("End of test")  # To avoid long training during normal test runs

# The tests can be run using `pytest` in a normal environment.