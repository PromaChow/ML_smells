import numpy as np
import pandas as pd

def clean(df: pd.DataFrame) -> pd.DataFrame:
    """
    Replace infinite values with NaN, then drop any rows or columns that contain NaN.
    Returns a cleaned DataFrame with no missing or infinite entries.
    """
    df = df.copy()
    df.replace([np.inf, -np.inf], np.nan, inplace=True)
    df.dropna(axis=0, how="any", inplace=True)
    df.dropna(axis=1, how="any", inplace=True)
    return df

def align(target: np.ndarray, source: pd.Series | pd.DataFrame) -> pd.Series | pd.DataFrame:
    """
    Align a numpy array with a pandas Series or DataFrame.
    The target array and source must have the same shape.
    Returns a new pandas object with the same structure as the source but containing data from target.
    """
    target_arr = np.asarray(target)
    if isinstance(source, pd.Series):
        if target_arr.size != len(source):
            raise ValueError("Target array size does not match Series length.")
        aligned = pd.Series(target_arr, index=source.index, name=source.name)
    elif isinstance(source, pd.DataFrame):
        if target_arr.shape != source.shape:
            raise ValueError("Target array shape does not match DataFrame shape.")
        aligned = pd.DataFrame(target_arr, index=source.index, columns=source.columns)
    else:
        raise TypeError("Source must be a pandas Series or DataFrame.")
    return aligned

# Example usage (commented out):
# df = pd.DataFrame({'a': [1, np.inf, 3], 'b': [4, 5, np.nan]})
# cleaned_df = clean(df)
# arr = np.array([10, 20, 30])
# aligned_series = align(arr, cleaned_df['a'])
# aligned_df = align(np.array([[10, 20], [30, 40]]), cleaned_df)