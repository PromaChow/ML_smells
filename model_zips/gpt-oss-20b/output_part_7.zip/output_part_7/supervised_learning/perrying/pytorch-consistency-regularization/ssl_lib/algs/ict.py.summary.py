import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions.beta import Beta

class ConsistencyRegularization(nn.Module):
    def __init__(self, consistency: str = "ICT"):
        super().__init__()
        self.consistency = consistency

class ICT(ConsistencyRegularization):
    def __init__(
        self,
        consistency: str = "ICT",
        threshold: float = 0.5,
        sharpen: float = 0.5,
        temp_softmax: float = 1.0,
        alpha: float = 0.4,
    ):
        super().__init__(consistency=consistency)
        self.threshold = threshold
        self.sharpen = sharpen
        self.temp_softmax = temp_softmax
        self.alpha = alpha
        self.tau = None  # tau is not initialized as per specification
        self.student = nn.Identity()  # placeholder for student model

    def gen_mask(self, tea_logits: torch.Tensor) -> torch.Tensor:
        """
        Generate a mask based on the maximum logit probability exceeding the threshold.
        """
        max_logit, _ = tea_logits.max(dim=1)
        mask = (max_logit > self.threshold).float()
        return mask

    def adjust_target(self, tea_logits: torch.Tensor) -> torch.Tensor:
        """
        Apply temperature scaling and sharpening to the teacher logits to produce soft targets.
        """
        probs = F.softmax(tea_logits / self.temp_softmax, dim=1)
        sharpened = probs ** (1.0 / self.sharpen)
        sharpened = sharpened / sharpened.sum(dim=1, keepdim=True)
        return sharpened

    def mixup(
        self,
        data: torch.Tensor,
        targets: torch.Tensor,
        alpha: float,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """
        Apply mixup to data and targets using a beta distribution.
        """
        batch_size = data.size(0)
        perm = torch.randperm(batch_size, device=data.device)
        lam = Beta(alpha, alpha).sample((batch_size,)).to(data.device)
        lam_x = lam.view(-1, *([1] * (data.dim() - 1)))
        lam_y = lam.view(-1, *([1] * (targets.dim() - 1)))
        mixed_x = lam_x * data + (1 - lam_x) * data[perm]
        mixed_targets = lam_y * targets + (1 - lam_y) * targets[perm]
        return mixed_x, mixed_targets

    def stu_forward(self, mixed_x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass through the student model.
        """
        return self.student(mixed_x)

    def __call__(self, w_data: torch.Tensor, tea_logits: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Execute the ICT process: generate mask, adjust targets, apply mixup,
        forward pass, and return outputs.
        """
        mask = self.gen_mask(tea_logits)
        adjusted_targets = self.adjust_target(tea_logits)
        mixed_x, mixed_targets = self.mixup(w_data, adjusted_targets, self.alpha)
        y = self.stu_forward(mixed_x)
        return y, mixed_targets, mask

    def __repr__(self):
        return (
            f"{self.__class__.__name__}(threshold={self.threshold}, "
            f"sharpen={self.sharpen}, tau={self.tau}, alpha={self.alpha})"
        )