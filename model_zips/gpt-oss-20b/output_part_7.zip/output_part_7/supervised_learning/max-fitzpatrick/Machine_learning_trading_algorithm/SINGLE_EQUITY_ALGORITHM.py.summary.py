import pandas as pd
import numpy as np
import yfinance as yf
from sklearn.ensemble import RandomForestClassifier

# Technical indicator functions
def ROC(series, n):
    return series.pct_change(n)

def BBANDS(df, window=20):
    sma = df['Close'].rolling(window).mean()
    std = df['Close'].rolling(window).std()
    upper = sma + (std * 2)
    lower = sma - (std * 2)
    return upper, lower

def STOK(df, window=14):
    low_min = df['Low'].rolling(window).min()
    high_max = df['High'].rolling(window).max()
    percent_k = 100 * (df['Close'] - low_min) / (high_max - low_min)
    return percent_k

def MACD(df, fast=12, slow=26, signal=9):
    exp_fast = df['Close'].ewm(span=fast, adjust=False).mean()
    exp_slow = df['Close'].ewm(span=slow, adjust=False).mean()
    macd_line = exp_fast - exp_slow
    signal_line = macd_line.ewm(span=signal, adjust=False).mean()
    macd_diff = macd_line - signal_line
    return macd_line, signal_line, macd_diff

def RSI14(df, period=14):
    delta = df['Close'].diff()
    up = delta.clip(lower=0)
    down = -1 * delta.clip(upper=0)
    ema_up = up.ewm(com=period-1, adjust=False).mean()
    ema_down = down.ewm(com=period-1, adjust=False).mean()
    rs = ema_up / ema_down
    rsi = 100 - (100/(1 + rs))
    return rsi

def CCI(df, period=20):
    tp = (df['High'] + df['Low'] + df['Close']) / 3
    sma_tp = tp.rolling(period).mean()
    mean_dev = tp.rolling(period).apply(lambda x: np.mean(np.abs(x - np.mean(x))), raw=True)
    cci = (tp - sma_tp) / (0.015 * mean_dev)
    return cci

# Context simulation
class Context:
    def __init__(self):
        self.asset = 'XOM'
        self.benchmark = 'XOM'
        self.h = 30
        self.clf = None
        self.account = type('account', (), {'leverage': 1.0})
        self.y_hat = None

def initialize(context):
    # Training data URL (placeholder)
    url = 'https://drive.google.com/uc?id=YOUR_FILE_ID&export=download'
    df_train = pd.read_csv(url)
    features = ['Delta','MA10','MA20','MA100','ROC','B1','B2','SOk','MACD','MACDsign','MACDdiff','RSI14','CCI']
    X = df_train[features]
    y = df_train['Class']
    clf = RandomForestClassifier(n_estimators=100, random_state=42)
    clf.fit(X, y)
    context.clf = clf

def rebalance(context):
    df = yf.download(context.asset, period='200d', interval='1d')
    df.dropna(inplace=True)
    if len(df) < 100:
        return
    df_recent = df.tail(100).copy()
    df_recent['Delta'] = ROC(df_recent['Close'], context.h)
    df_recent['MA10'] = df_recent['Close'].rolling(10).mean()
    df_recent['MA20'] = df_recent['Close'].rolling(20).mean()
    df_recent['MA100'] = df_recent['Close'].rolling(100).mean()
    df_recent['ROC'] = ROC(df_recent['Close'], context.h)
    b1, b2 = BBANDS(df_recent, 20)
    df_recent['B1'] = b1
    df_recent['B2'] = b2
    df_recent['SOk'] = STOK(df_recent, 14)
    macd, macd_sig, macd_diff = MACD(df_recent, 12, 26, 9)
    df_recent['MACD'] = macd
    df_recent['MACDsign'] = macd_sig
    df_recent['MACDdiff'] = macd_diff
    df_recent['RSI14'] = RSI14(df_recent, 14)
    df_recent['CCI'] = CCI(df_recent, 20)
    latest = df_recent.dropna().tail(1)
    features = ['Delta','MA10','MA20','MA100','ROC','B1','B2','SOk','MACD','MACDsign','MACDdiff','RSI14','CCI']
    X_latest = latest[features]
    y_hat = context.clf.predict(X_latest)[0]
    context.y_hat = y_hat
    proba = context.clf.predict_proba(X_latest)[0]
    long_class_index = list(context.clf.classes_).index('long')
    long_prob = proba[long_class_index]
    weight = 1 if long_prob > 0.5 else -1
    # Placeholder for order execution
    print(f"Order for {context.asset}: weight {weight}, predicted class {y_hat}, long probability {long_prob:.3f}")

def main():
    context = Context()
    initialize(context)
    rebalance(context)
    # Record leverage (placeholder)
    print(f"Leverage: {context.account.leverage}")

if __name__ == "__main__":
    main()