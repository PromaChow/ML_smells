import tensorflow as tf
import tensorflow_addons as tfa

# Global step initialization
global_step = tf.Variable(0, dtype=tf.int64, name="global_step", trainable=False)

# Hyper‑parameters
init_lr = tf.constant(1e-4, dtype=tf.float32)
num_train_steps = 100000
num_warmup_steps = 1000

# Learning‑rate schedule: polynomial decay + optional warm‑up
def learning_rate_fn(step):
    lr = tf.compat.v1.train.polynomial_decay(
        learning_rate=init_lr,
        global_step=step,
        decay_steps=num_train_steps,
        end_learning_rate=0.0,
        power=1.0,
        cycle=False,
    )
    if num_warmup_steps > 0:
        warmup_lr = init_lr * tf.cast(step, tf.float32) / tf.cast(num_warmup_steps, tf.float32)
        lr = tf.where(step < num_warmup_steps, warmup_lr, lr)
    return lr

# Optimizer creation
def create_optimizer():
    lr_schedule = learning_rate_fn(global_step)
    # AdamW with weight decay, excluding LayerNorm and bias
    optimizer = tfa.optimizers.AdamW(
        learning_rate=lr_schedule,
        weight_decay=0.01,
        beta_1=0.9,
        beta_2=0.999,
        epsilon=1e-6,
        exclude_from_weight_decay=["LayerNorm", "layer_norm", "bias"],
    )
    # Wrap in CrossShardOptimizer if TPU is available
    if tf.config.experimental.list_logical_devices('TPU'):
        optimizer = tf.distribute.CrossShardOptimizer(optimizer)
    return optimizer

optimizer = create_optimizer()

# Sample model and loss for demonstration
def sample_model(inputs):
    # Dummy BERT‑like dense layer
    return tf.keras.layers.Dense(768)(inputs)

def loss_fn(inputs, targets):
    logits = sample_model(inputs)
    return tf.reduce_mean(tf.keras.losses.sparse_categorical_crossentropy(targets, logits, from_logits=True))

# Training step
@tf.function
def train_step(inputs, targets):
    with tf.GradientTape() as tape:
        loss = loss_fn(inputs, targets)
    variables = tf.compat.v1.trainable_variables()
    grads = tape.gradient(loss, variables)
    # Gradient clipping by global norm
    clipped_grads, _ = tf.clip_by_global_norm(grads, 1.0)
    optimizer.apply_gradients(zip(clipped_grads, variables))
    # Increment global step manually
    global_step.assign_add(1)
    return loss

# Dummy data for demonstration
batch_size = 32
input_dim = 768
dummy_inputs = tf.random.normal([batch_size, input_dim])
dummy_targets = tf.random.uniform([batch_size], maxval=1000, dtype=tf.int32)

# Execute a few training steps
for _ in range(10):
    loss = train_step(dummy_inputs, dummy_targets)
    print(f"Step {global_step.numpy()}: loss = {loss.numpy():.4f}")