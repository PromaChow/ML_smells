import torch
from .utils import mixup
from .base import ConsistencyRegularization


class ICT(ConsistencyRegularization):
    def __init__(
        self,
        consistency: str,
        threshold: float,
        sharpen: float | None = None,
        temp_softmax: float | None = None,
        alpha: float = 0.5,
    ) -> None:
        super().__init__(consistency=consistency)
        self.threshold = threshold
        self.sharpen = sharpen
        self.temp_softmax = temp_softmax
        self.alpha = alpha

    def __call__(self, w_data: torch.Tensor, tea_logits: torch.Tensor, stu_forward) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """
        Perform ICT consistency training step.

        Args:
            w_data (torch.Tensor): Weakly augmented input data.
            tea_logits (torch.Tensor): Teacher model outputs.
            stu_forward (Callable[[torch.Tensor], torch.Tensor]): Student model forward function.

        Returns:
            tuple: (student predictions on mixed data, mixed targets, mask)
        """
        # 1. Mask generation
        mask = self.gen_mask(tea_logits, threshold=self.threshold)

        # 2. Target adjustment
        targets = self.adjust_target(
            tea_logits,
            sharpen=self.sharpen,
            temp_softmax=self.temp_softmax,
        )

        # 3. Mixup data and targets
        mixed_x, mixed_targets = mixup(w_data, targets, alpha=self.alpha)

        # 4. Student model forward pass
        y = stu_forward(mixed_x)

        return y, mixed_targets, mask

    # The following methods are expected to be inherited:
    # - gen_mask
    # - adjust_target'''