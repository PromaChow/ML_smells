import tensorflow as tf
import numpy as np
import collections

# --- Streaming normalizer for observations and rewards ---------------------------------
class StreamingNormalizer(tf.keras.layers.Layer):
    def __init__(self, shape, epsilon=1e-8):
        super().__init__()
        self.mean = tf.Variable(tf.zeros(shape, dtype=tf.float32), trainable=False)
        self.var = tf.Variable(tf.ones(shape, dtype=tf.float32), trainable=False)
        self.count = tf.Variable(0, dtype=tf.int64, trainable=False)
        self.epsilon = epsilon

    def update(self, x):
        batch_mean, batch_var, batch_count = tf.nn.moments(x, axes=[0])
        delta = batch_mean - self.mean
        tot_count = self.count + batch_count
        new_mean = self.mean + delta * batch_count / tf.cast(tot_count, tf.float32)
        m_a = self.var * tf.cast(self.count, tf.float32)
        m_b = batch_var * tf.cast(batch_count, tf.float32)
        M2 = m_a + m_b + tf.square(delta) * tf.cast(self.count, tf.float32) * tf.cast(batch_count, tf.float32) / tf.cast(tot_count, tf.float32)
        new_var = M2 / tf.cast(tot_count, tf.float32)
        self.mean.assign(new_mean)
        self.var.assign(new_var)
        self.count.assign(tot_count)

    def normalize(self, x):
        return (x - self.mean) / tf.sqrt(self.var + self.epsilon)


# --- Policy network --------------------------------------------------------------------
class PolicyNetwork(tf.keras.Model):
    def __init__(self, observation_dim, action_dim):
        super().__init__()
        self.dense1 = tf.keras.layers.Dense(64, activation='tanh')
        self.dense2 = tf.keras.layers.Dense(64, activation='tanh')
        self.logits = tf.keras.layers.Dense(action_dim, activation=None)

    def call(self, x):
        x = self.dense1(x)
        x = self.dense2(x)
        return self.logits(x)


# --- Value network ----------------------------------------------------------------------
class ValueNetwork(tf.keras.Model):
    def __init__(self, observation_dim):
        super().__init__()
        self.dense1 = tf.keras.layers.Dense(64, activation='tanh')
        self.dense2 = tf.keras.layers.Dense(64, activation='tanh')
        self.value = tf.keras.layers.Dense(1, activation=None)

    def call(self, x):
        x = self.dense1(x)
        x = self.dense2(x)
        return tf.squeeze(self.value(x), axis=-1)


# --- PPO agent -------------------------------------------------------------------------
class PPOAgent:
    def __init__(self,
                 observation_dim,
                 action_dim,
                 gamma=0.99,
                 lam=0.95,
                 epsilon=0.2,
                 clip_range=0.2,
                 entropy_coef=0.0,
                 kl_coef=1.0,
                 kl_target=0.01,
                 update_every=10,
                 learning_rate=3e-4,
                 batch_size=64,
                 num_epochs=10,
                 max_episode_len=200):
        self.observation_dim = observation_dim
        self.action_dim = action_dim
        self.gamma = gamma
        self.lam = lam
        self.epsilon = epsilon
        self.clip_range = clip_range
        self.entropy_coef = entropy_coef
        self.kl_coef = kl_coef
        self.kl_target = kl_target
        self.update_every = update_every
        self.learning_rate = learning_rate
        self.batch_size = batch_size
        self.num_epochs = num_epochs
        self.max_episode_len = max_episode_len

        # Normalizers
        self.obs_norm = StreamingNormalizer(shape=(observation_dim,))
        self.ret_norm = StreamingNormalizer(shape=())

        # Networks
        self.policy = PolicyNetwork(observation_dim, action_dim)
        self.value = ValueNetwork(observation_dim)

        # Optimizer
        self.optimizer = tf.keras.optimizers.Adam(learning_rate=self.learning_rate)

        # Memory
        self._current_episode = {
            'obs': [],
            'acts': [],
            'rews': [],
            'vals': [],
            'logp': []
        }
        self._finished_episodes = []
        self._finished_counter = 0

        # KL penalty coefficient
        self.kl_penalty = self.kl_coef

        # For reuse of policy template
        self.policy_template = tf.make_template('policy', self.policy)

    @tf.function
    def _get_action(self, obs, training=True):
        logits = self.policy_template(obs)
        dist = tfp.distributions.Categorical(logits=logits)
        if training:
            action = dist.sample()
            logp = dist.log_prob(action)
        else:
            action = tf.argmax(logits, axis=-1)
            logp = dist.log_prob(action)
        return action, logp, dist.logits

    def act(self, observation, training=True):
        obs_norm = self.obs_norm.normalize(tf.convert_to_tensor(observation, dtype=tf.float32))
        action, logp, logits = self._get_action(obs_norm, training=training)
        return int(action.numpy()), float(logp.numpy()), logits.numpy()

    def store_transition(self, obs, action, reward, logp, value):
        self._current_episode['obs'].append(obs)
        self._current_episode['acts'].append(action)
        self._current_episode['rews'].append(reward)
        self._current_episode['vals'].append(value)
        self._current_episode['logp'].append(logp)

    def finish_episode(self):
        self._finished_episodes.append(collections.OrderedDict(self._current_episode))
        self._finished_counter += 1
        self._current_episode = {'obs': [], 'acts': [], 'rews': [], 'vals': [], 'logp': []}
        if self._finished_counter >= self.update_every:
            self.train()
            self._finished_episodes.clear()
            self._finished_counter = 0

    @tf.function
    def _compute_returns_and_advantages(self, episode):
        obs = tf.stack(episode['obs'])
        acts = tf.stack(episode['acts'])
        rews = tf.stack(episode['rews'])
        vals = tf.stack(episode['vals'])
        logp_old = tf.stack(episode['logp'])

        # Compute discounted returns
        returns = []
        R = 0.0
        for r in tf.reverse(rews, axis=[0]):
            R = r + self.gamma * R
            returns.append(R)
        returns = tf.reverse(returns, axis=[0])
        returns = tf.stack(returns)

        # GAE
        deltas = rews + self.gamma * tf.concat([vals[1:], tf.zeros([1], dtype=vals.dtype)], axis=0) - vals
        advs = []
        A = 0.0
        for delta in tf.reverse(deltas, axis=[0]):
            A = delta + self.gamma * self.lam * A
            advs.append(A)
        advs = tf.reverse(advs, axis=[0])
        advs = tf.stack(advs)

        # Normalize advantages
        advs = (advs - tf.reduce_mean(advs)) / (tf.math.reduce_std(advs) + 1e-8)

        return obs, acts, logp_old, returns, advs

    def _sample_batch(self, obs, acts, logp_old, returns, advs):
        dataset = tf.data.Dataset.from_tensor_slices((obs, acts, logp_old, returns, advs))
        dataset = dataset.shuffle(buffer_size=obs.shape[0]).batch(self.batch_size, drop_remainder=True)
        return dataset

    def _policy_loss(self, logits, acts, logp_old, advs):
        dist_new = tfp.distributions.Categorical(logits=logits)
        logp_new = dist_new.log_prob(acts)
        ratio = tf.exp(logp_new - logp_old)
        surr1 = ratio * advs
        surr2 = tf.clip_by_value(ratio, 1.0 - self.clip_range, 1.0 + self.clip_range) * advs
        loss = -tf.reduce_mean(tf.minimum(surr1, surr2))
        entropy = tf.reduce_mean(dist_new.entropy())
        loss -= self.entropy_coef * entropy
        return loss, entropy

    def _value_loss(self, values, returns):
        loss = tf.reduce_mean(tf.square(values - returns))
        return loss

    def _kl_divergence(self, logits_old, logits_new):
        dist_old = tfp.distributions.Categorical(logits=logits_old)
        dist_new = tfp.distributions.Categorical(logits=logits_new)
        kl = tf.reduce_mean(dist_old.kl_divergence(dist_new))
        return kl

    def train(self):
        # Gather all episodes into single tensors
        all_obs = []
        all_acts = []
        all_logp_old = []
        all_returns = []
        all_advs = []
        for ep in self._finished_episodes:
            obs, acts, logp_old, returns, advs = self._compute_returns_and_advantages(ep)
            all_obs.append(obs)
            all_acts.append(acts)
            all_logp_old.append(logp_old)
            all_returns.append(returns)
            all_advs.append(advs)

        obs = tf.concat(all_obs, axis=0)
        acts = tf.concat(all_acts, axis=0)
        logp_old = tf.concat(all_logp_old, axis=0)
        returns = tf.concat(all_returns, axis=0)
        advs = tf.concat(all_advs, axis=0)

        dataset = self._sample_batch(obs, acts, logp_old, returns, advs)

        for epoch in range(self.num_epochs):
            for batch_obs, batch_acts, batch_logp_old, batch_returns, batch_advs in dataset:
                with tf.GradientTape() as tape:
                    logits = self.policy(batch_obs)
                    values = self.value(batch_obs)

                    p_loss, entropy = self._policy_loss(logits, batch_acts, batch_logp_old, batch_advs)
                    v_loss = self._value_loss(values, batch_returns)
                    kl = self._kl_divergence(batch_logp_old, logits)

                    total_loss = p_loss + v_loss + self.kl_penalty * kl

                grads = tape.gradient(total_loss, self.policy.trainable_variables + self.value.trainable_variables)
                grads, _ = tf.clip_by_global_norm(grads, 0.5)
                self.optimizer.apply_gradients(zip(grads, self.policy.trainable_variables + self.value.trainable_variables))

        # Adjust KL penalty
        kl_mean = tf.reduce_mean(kl)
        if kl_mean > self.kl_target * 1.5:
            self.kl_penalty *= 2.0
        elif kl_mean < self.kl_target * 0.5:
            self.kl_penalty = max(0.0, self.kl_penalty * 0.5)


# --- Usage example (requires environment and tfp) --------------------------------------
# import tensorflow_probability as tfp
# env = ...  # some gym environment
# agent = PPOAgent(env.observation_space.shape[0], env.action_space.n)
# for episode in range(1000):
#     obs = env.reset()
#     done = False
#     while not done:
#         action, logp, logits = agent.act(obs, training=True)
#         next_obs, reward, done, _ = env.step(action)
#         value = agent.value(agent.obs_norm.normalize(tf.convert_to_tensor(obs, dtype=tf.float32)))
#         agent.store_transition(obs, action, reward, logp, value)
#         obs = next_obs
#     agent.finish_episode()
# -----------------------------------------------------------------------------
