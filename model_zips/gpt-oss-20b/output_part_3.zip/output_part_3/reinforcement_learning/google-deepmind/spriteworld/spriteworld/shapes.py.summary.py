import math
import numpy as np

def _polar2cartesian(r: float, theta: float) -> tuple[float, float]:
    """Convert polar coordinates to Cartesian coordinates."""
    return (r * math.cos(theta), r * math.sin(theta))

def generate_polygon(num_sides: int, theta_0: float = 0.0) -> np.ndarray:
    """
    Generate normalized vertices for a regular polygon.
    """
    if num_sides < 3:
        raise ValueError("Polygon must have at least 3 sides.")
    theta = 2 * math.pi / num_sides
    vertices = []
    for i in range(num_sides):
        angle = theta_0 + i * theta
        vertices.append(_polar2cartesian(1.0, angle))
    area = num_sides * math.sin(theta / 2) * math.cos(theta / 2)
    norm_factor = math.sqrt(area)
    return np.array(vertices) / norm_factor

def generate_star(num_sides: int, point_height: float, theta_0: float = 0.0) -> np.ndarray:
    """
    Generate normalized vertices for a star shape.
    """
    if num_sides < 2:
        raise ValueError("Star must have at least 2 sides.")
    theta = 2 * math.pi / num_sides
    point_to_center = 1.0 + point_height
    vertices = []
    for i in range(num_sides):
        inner_angle = theta_0 + i * theta
        outer_angle = theta_0 + (i + 0.5) * theta
        vertices.append(_polar2cartesian(1.0, inner_angle))
        vertices.append(_polar2cartesian(point_to_center, outer_angle))
    area = point_to_center * num_sides * math.sin(theta / 2)
    norm_factor = math.sqrt(area)
    return np.array(vertices) / norm_factor

def generate_spokes(num_sides: int, spoke_height: float, theta_0: float = 0.0) -> np.ndarray:
    """
    Generate normalized vertices for a spoke pattern.
    """
    if num_sides < 2:
        raise ValueError("Spokes pattern must have at least 2 sides.")
    theta = 2 * math.pi / num_sides
    vertices = []
    for i in range(num_sides):
        angle_base = theta_0 + i * theta
        angle_mid = theta_0 + (i + 0.5) * theta
        angle_next = theta_0 + (i + 1) * theta
        vertices.append(_polar2cartesian(spoke_height, angle_mid))
        vertices.append(_polar2cartesian(1.0, angle_base))
        vertices.append(_polar2cartesian(spoke_height, angle_next))
    area = num_sides * math.sin(theta / 2) * (2 + math.cos(theta / 2))
    norm_factor = math.sqrt(area)
    return np.array(vertices) / norm_factor
