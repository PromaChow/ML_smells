import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Normal, Categorical


class Mlp(nn.Module):
    def __init__(self, in_dim, hidden_dims, out_dim, activation=nn.ReLU):
        super().__init__()
        layers = []
        last_dim = in_dim
        for h in hidden_dims:
            layers.append(nn.Linear(last_dim, h))
            layers.append(activation())
            last_dim = h
        layers.append(nn.Linear(last_dim, out_dim))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)


class MlpPolicy(nn.Module):
    def __init__(self, state_dim, action_dim, hidden_dims=[256, 256], continuous=True):
        super().__init__()
        self.continuous = continuous
        if continuous:
            self.mean_net = Mlp(state_dim, hidden_dims, action_dim)
            self.log_std_net = Mlp(state_dim, hidden_dims, action_dim)
        else:
            self.logits_net = Mlp(state_dim, hidden_dims, action_dim)

    def forward(self, x):
        if self.continuous:
            mean = self.mean_net(x)
            log_std = self.log_std_net(x).clamp(-20, 2)
            return mean, log_std
        else:
            logits = self.logits_net(x)
            return logits


class MlpValue(nn.Module):
    def __init__(self, state_dim, hidden_dims=[256, 256]):
        super().__init__()
        self.value_net = Mlp(state_dim, hidden_dims, 1)

    def forward(self, x):
        return self.value_net(x).squeeze(-1)


class ActorCriticBase(nn.Module):
    def get_action(self, state, deterministic=False):
        raise NotImplementedError

    def get_value(self, state):
        raise NotImplementedError

    def get_params(self):
        actor_params = list(self.actor.parameters())
        critic_params = list(self.critic.parameters())
        return {"actor": actor_params, "critic": critic_params}


class MlpActorCritic(ActorCriticBase):
    def __init__(self, state_dim, action_dim, hidden_dims=[256, 256], continuous=True):
        super().__init__()
        self.continuous = continuous
        self.actor = MlpPolicy(state_dim, action_dim, hidden_dims, continuous)
        self.critic = MlpValue(state_dim, hidden_dims)
        self.action_dim = action_dim

    def get_action(self, state, deterministic=False):
        if self.continuous:
            mean, log_std = self.actor(state)
            std = log_std.exp()
            dist = Normal(mean, std)
            if deterministic:
                action = mean
            else:
                action = dist.rsample()
            logp = dist.log_prob(action).sum(-1)
            # Tanh squashing
            tanh_action = torch.tanh(action)
            logp -= (2 * (torch.log(1 + torch.exp(-2 * action)) + 1e-6)).sum(-1)
            action = tanh_action
        else:
            logits = self.actor(state)
            dist = Categorical(logits=logits)
            if deterministic:
                action = logits.argmax(-1)
            else:
                action = dist.sample()
            logp = dist.log_prob(action)
        return action, logp

    def get_value(self, state):
        return self.critic(state)


class MlpSharedActorCritic(ActorCriticBase):
    def __init__(self, state_dim, action_dim, hidden_dims=[256, 256], continuous=True, shared_dim=128):
        super().__init__()
        self.continuous = continuous
        self.shared = Mlp(state_dim, hidden_dims, shared_dim)
        self.actor = MlpPolicy(shared_dim, action_dim, hidden_dims, continuous)
        self.critic = MlpValue(shared_dim, hidden_dims)
        self.action_dim = action_dim

    def get_features(self, state):
        return self.shared(state)

    def get_action(self, state, deterministic=False):
        features = self.get_features(state)
        if self.continuous:
            mean, log_std = self.actor(features)
            std = log_std.exp()
            dist = Normal(mean, std)
            if deterministic:
                action = mean
            else:
                action = dist.rsample()
            logp = dist.log_prob(action).sum(-1)
            tanh_action = torch.tanh(action)
            logp -= (2 * (torch.log(1 + torch.exp(-2 * action)) + 1e-6)).sum(-1)
            action = tanh_action
        else:
            logits = self.actor(features)
            dist = Categorical(logits=logits)
            if deterministic:
                action = logits.argmax(-1)
            else:
                action = dist.sample()
            logp = dist.log_prob(action)
        return action, logp

    def get_value(self, state):
        features = self.get_features(state)
        return self.critic(features)

    def get_params(self):
        actor_params = list(self.shared.parameters()) + list(self.actor.parameters())
        critic_params = list(self.shared.parameters()) + list(self.critic.parameters())
        return {"actor": actor_params, "critic": critic_params}


class MlpSingleActorTwoCritic(ActorCriticBase):
    def __init__(self, state_dim, action_dim, hidden_dims=[256, 256], continuous=True, action_scale=None, action_bias=None):
        super().__init__()
        self.continuous = continuous
        self.action_scale = action_scale if action_scale is not None else 1.0
        self.action_bias = action_bias if action_bias is not None else 0.0
        self.actor = MlpPolicy(state_dim, action_dim, hidden_dims, continuous)
        self.critic1 = MlpValue(state_dim, hidden_dims)
        self.critic2 = MlpValue(state_dim, hidden_dims)
        self.action_dim = action_dim

    def get_action(self, state, deterministic=False):
        if self.continuous:
            mean, log_std = self.actor(state)
            std = log_std.exp()
            dist = Normal(mean, std)
            if deterministic:
                action = mean
            else:
                action = dist.rsample()
            logp = dist.log_prob(action).sum(-1)
            tanh_action = torch.tanh(action)
            logp -= (2 * (torch.log(1 + torch.exp(-2 * action)) + 1e-6)).sum(-1)
            action = tanh_action
            action = action * self.action_scale + self.action_bias
        else:
            logits = self.actor(state)
            dist = Categorical(logits=logits)
            if deterministic:
                action = logits.argmax(-1)
            else:
                action = dist.sample()
            logp = dist.log_prob(action)
        return action, logp

    def get_value(self, state, mode="both"):
        v1 = self.critic1(state)
        v2 = self.critic2(state)
        if mode == "both":
            return v1, v2
        elif mode == "min":
            return torch.min(v1, v2)
        else:
            return v1

    def get_params(self):
        actor_params = list(self.actor.parameters())
        critic_params = list(self.critic1.parameters()) + list(self.critic2.parameters())
        return {"actor": actor_params, "critic": critic_params}


class MlpSharedSingleActorTwoCritic(ActorCriticBase):
    def __init__(self, state_dim, action_dim, hidden_dims=[256, 256], continuous=True,
                 action_scale=None, action_bias=None, shared_dim=128):
        super().__init__()
        self.continuous = continuous
        self.action_scale = action_scale if action_scale is not None else 1.0
        self.action_bias = action_bias if action_bias is not None else 0.0
        self.shared = Mlp(state_dim, hidden_dims, shared_dim)
        self.actor = MlpPolicy(shared_dim, action_dim, hidden_dims, continuous)
        self.critic1 = MlpValue(shared_dim, hidden_dims)
        self.critic2 = MlpValue(shared_dim, hidden_dims)
        self.action_dim = action_dim

    def get_features(self, state):
        return self.shared(state)

    def get_action(self, state, deterministic=False):
        features = self.get_features(state)
        if self.continuous:
            mean, log_std = self.actor(features)
            std = log_std.exp()
            dist = Normal(mean, std)
            if deterministic:
                action = mean
            else:
                action = dist.rsample()
            logp = dist.log_prob(action).sum(-1)
            tanh_action = torch.tanh(action)
            logp -= (2 * (torch.log(1 + torch.exp(-2 * action)) + 1e-6)).sum(-1)
            action = tanh_action
            action = action * self.action_scale + self.action_bias
        else:
            logits = self.actor(features)
            dist = Categorical(logits=logits)
            if deterministic:
                action = logits.argmax(-1)
            else:
                action = dist.sample()
            logp = dist.log_prob(action)
        return action, logp

    def get_value(self, state, mode="both"):
        features = self.get_features(state)
        v1 = self.critic1(features)
        v2 = self.critic2(features)
        if mode == "both":
            return v1, v2
        elif mode == "min":
            return torch.min(v1, v2)
        else:
            return v1

    def get_params(self):
        actor_params = list(self.shared.parameters()) + list(self.actor.parameters())
        critic_params = list(self.shared.parameters()) + list(self.critic1.parameters()) + list(self.critic2.parameters())
        return {"actor": actor_params, "critic": critic_params}


class CNNActorCritic(ActorCriticBase):
    def __init__(self, input_channels, action_dim, hidden_dims=[256, 256], continuous=True):
        super().__init__()
        self.continuous = continuous
        self.cnn = nn.Sequential(
            nn.Conv2d(input_channels, 32, kernel_size=8, stride=4),
            nn.ReLU(),
            nn.Conv2d(32, 64, kernel_size=4, stride=2),
            nn.ReLU(),
            nn.Conv2d(64, 64, kernel_size=3, stride=1),
            nn.ReLU(),
            nn.Flatten()
        )
        # Compute flatten size by a dummy forward
        with torch.no_grad():
            dummy = torch.zeros(1, input_channels, 84, 84)
            flat_size = self.cnn(dummy).shape[1]
        self.actor = MlpPolicy(flat_size, action_dim, hidden_dims, continuous)
        self.critic = MlpValue(flat_size, hidden_dims)
        self.action_dim = action_dim

    def get_features(self, state):
        return self.cnn(state)

    def get_action(self, state, deterministic=False):
        features = self.get_features(state)
        if self.continuous:
            mean, log_std = self.actor(features)
            std = log_std.exp()
            dist = Normal(mean, std)
            if deterministic:
                action = mean
            else:
                action = dist.rsample()
            logp = dist.log_prob(action).sum(-1)
            tanh_action = torch.tanh(action)
            logp -= (2 * (torch.log(1 + torch.exp(-2 * action)) + 1e-6)).sum(-1)
            action = tanh_action
        else:
            logits = self.actor(features)
            dist = Categorical(logits=logits)
            if deterministic:
                action = logits.argmax(-1)
            else:
                action = dist.sample()
            logp = dist.log_prob(action)
        return action, logp

    def get_value(self, state):
        features = self.get_features(state)
        return self.critic(features)

    def get_params(self):
        actor_params = list(self.cnn.parameters()) + list(self.actor.parameters())
        critic_params = list(self.cnn.parameters()) + list(self.critic.parameters())
        return {"actor": actor_params, "critic": critic_params}


# Registry and factory
actor_critic_registry = {
    "mlp": MlpActorCritic,
    "mlp_shared": MlpSharedActorCritic,
    "mlp_single_actor_two_critic": MlpSingleActorTwoCritic,
    "mlp_shared_single_actor_two_critic": MlpSharedSingleActorTwoCritic,
    "cnn": CNNActorCritic,
}

def get_actor_critic_from_name(name, *args, **kwargs):
    cls = actor_critic_registry.get(name)
    if cls is None:
        raise ValueError(f"ActorCritic name '{name}' not found in registry.")
    return cls(*args, **kwargs)