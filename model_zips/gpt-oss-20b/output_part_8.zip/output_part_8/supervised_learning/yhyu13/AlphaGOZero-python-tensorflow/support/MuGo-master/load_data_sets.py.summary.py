import os
import re
import random
import gzip
import struct
import numpy as np

def find_sgf_files(directories):
    sgf_files = []
    for directory in directories:
        for root, _, files in os.walk(directory):
            for f in files:
                if f.lower().endswith('.sgf'):
                    sgf_files.append(os.path.join(root, f))
    return sgf_files

def replay_sgf(path, board_size=19):
    with open(path, 'r', encoding='utf-8') as f:
        data = f.read()
    moves = re.findall(r'\[([BW])([a-s]?)([a-s]?)\]', data)
    board = np.zeros((board_size, board_size), dtype=int)
    result = None
    for color, x, y in moves:
        if x and y:
            i, j = ord(x) - ord('a'), ord(y) - ord('a')
            board[i, j] = 1 if color == 'B' else -1
            yield board.copy(), (i, j), result
    # Detect result at the end if present
    win_match = re.search(r';RE\[([BWL])\]', data)
    if win_match:
        result = 'black' if win_match.group(1) == 'B' else 'white'
    else:
        result = 'draw'

def get_positions_from_sgf(sgf_files, board_size=19):
    for path in sgf_files:
        for board, move, result in replay_sgf(path, board_size):
            if board is not None:
                yield (board, move, result)

def split_test_training(positions, test_size=100000, chunk_size=4096):
    positions = list(positions)
    total = len(positions)
    if total < 200000:
        test = positions[:total // 3]
        train = positions[total // 3 :]
        return [(test, train)]
    random.shuffle(positions)
    test = positions[:test_size]
    remaining = positions[test_size:]
    chunks = [remaining[i : i + chunk_size] for i in range(0, len(remaining), chunk_size)]
    return [(test, chunk) for chunk in chunks]

def bulk_extract_features(positions):
    features = []
    for board, move, _ in positions:
        black_plane = (board == 1).astype(np.float32)
        white_plane = (board == -1).astype(np.float32)
        feat = np.stack([black_plane, white_plane], axis=0)
        features.append(feat)
    return features

def make_onehot(move, board_size=19):
    vec = np.zeros(board_size * board_size, dtype=np.int8)
    idx = move[0] * board_size + move[1]
    vec[idx] = 1
    return vec

class DataSet:
    def __init__(self, features, labels, results, board_size=19):
        self.features = np.array(features, dtype=np.float32)
        self.labels = np.array(labels, dtype=np.int8)
        self.results = np.array(results, dtype=np.int8)
        self.board_size = board_size
        self.input_planes = self.features.shape[1]

    def shuffle(self):
        idx = np.arange(len(self.features))
        np.random.shuffle(idx)
        self.features = self.features[idx]
        self.labels = self.labels[idx]
        self.results = self.results[idx]

    def batch(self, batch_size):
        total = len(self.features)
        for start in range(0, total, batch_size):
            end = start + batch_size
            yield (self.features[start:end],
                   self.labels[start:end],
                   self.results[start:end])

    def write(self, path, test_flag=False):
        with gzip.open(path, 'wb') as f:
            header = struct.pack(
                '<IHH',
                len(self.features),
                self.board_size,
                self.input_planes
            )
            f.write(header)
            f.write(b'\x01' if test_flag else b'\x00')
            f.write(self.features.tobytes())
            f.write(self.labels.tobytes())
            f.write(self.results.tobytes())

    @classmethod
    def read(cls, path):
        with gzip.open(path, 'rb') as f:
            header = f.read(8)
            total, board_size, input_planes = struct.unpack('<IHH', header)
            test_flag = f.read(1) == b'\x01'
            features_bytes = f.read(total * input_planes * board_size * board_size * 4)
            labels_bytes = f.read(total * board_size * board_size)
            results_bytes = f.read(total)
            features = np.frombuffer(features_bytes, dtype=np.float32).reshape(
                total, input_planes, board_size, board_size)
            labels = np.frombuffer(labels_bytes, dtype=np.int8)
            results = np.frombuffer(results_bytes, dtype=np.int8)
            dataset = cls(features, labels, results, board_size)
            dataset.input_planes = input_planes
            return dataset, test_flag

def parse_data_sets(directories, output_dir, board_size=19):
    sgf_files = find_sgf_files(directories)
    total_estimated = len(sgf_files) * 200
    positions = get_positions_from_sgf(sgf_files, board_size)
    splits = split_test_training(positions)
    for idx, (test_set, train_set) in enumerate(splits):
        train_features = bulk_extract_features(train_set)
        train_labels = [make_onehot(pos[1], board_size) for pos in train_set]
        train_results = [0 if pos[2] == 'black' else 1 if pos[2] == 'white' else 2 for pos in train_set]
        train_ds = DataSet(train_features, train_labels, train_results, board_size)
        test_features = bulk_extract_features(test_set)
        test_labels = [make_onehot(pos[1], board_size) for pos in test_set]
        test_results = [0 if pos[2] == 'black' else 1 if pos[2] == 'white' else 2 for pos in test_set]
        test_ds = DataSet(test_features, test_labels, test_results, board_size)
        train_path = os.path.join(output_dir, f'train_{idx}.bin.gz')
        test_path = os.path.join(output_dir, f'test_{idx}.bin.gz')
        train_ds.write(train_path, test_flag=False)
        test_ds.write(test_path, test_flag=True)

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('directories', nargs='+', help='Directories to search for SGF files')
    parser.add_argument('--output', required=True, help='Output directory for datasets')
    parser.add_argument('--board-size', type=int, default=19, help='Board size')
    args = parser.parse_args()
    os.makedirs(args.output, exist_ok=True)
    parse_data_sets(args.directories, args.output, args.board_size)