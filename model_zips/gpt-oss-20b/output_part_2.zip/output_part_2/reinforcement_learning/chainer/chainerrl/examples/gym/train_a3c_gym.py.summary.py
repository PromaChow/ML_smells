import argparse
import os
import math
import numpy as np
import torch
import torch.nn as nn
import torch.multiprocessing as mp
import torch.optim as optim
import torch.nn.functional as F
import gym
from gym.wrappers import Monitor

# ---------- Environment wrappers ----------
class RewardScaleWrapper(gym.Wrapper):
    def __init__(self, env, scale):
        super().__init__(env)
        self.scale = scale
    def step(self, action):
        obs, reward, done, info = self.env.step(action)
        return obs, reward * self.scale, done, info

class Float32ObsWrapper(gym.ObservationWrapper):
    def observation(self, observation):
        return np.asarray(observation, dtype=np.float32)

# ---------- Network definitions ----------
class FFSoftmax(nn.Module):
    def __init__(self, obs_dim, act_dim):
        super().__init__()
        self.fc1 = nn.Linear(obs_dim, 200)
        self.fc2 = nn.Linear(200, 200)
        self.actor = nn.Linear(200, act_dim)
        self.critic = nn.Linear(200, 1)
    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        logits = self.actor(x)
        value = self.critic(x)
        return logits, value

class FFMellowmax(nn.Module):
    def __init__(self, obs_dim, act_dim):
        super().__init__()
        self.fc1 = nn.Linear(obs_dim, 200)
        self.fc2 = nn.Linear(200, 200)
        self.actor = nn.Linear(200, act_dim)
        self.critic = nn.Linear(200, 1)
    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        logits = self.actor(x)
        value = self.critic(x)
        return logits, value

class LSTMGaussian(nn.Module):
    def __init__(self, obs_dim, act_dim):
        super().__init__()
        self.lstm = nn.LSTMCell(obs_dim, 128)
        self.fc = nn.Linear(128, 200)
        self.mean = nn.Linear(200, act_dim)
        self.log_std = nn.Parameter(torch.zeros(act_dim))
        self.value = nn.Linear(200, 1)
    def forward(self, x, hx, cx):
        hx, cx = self.lstm(x, (hx, cx))
        x = F.relu(self.fc(hx))
        mean = self.mean(x)
        value = self.value(x)
        std = torch.exp(self.log_std)
        return mean, std, value, (hx, cx)

# ---------- Agent ----------
class A3CAgent:
    def __init__(self, model, optimizer, t_max, gamma, beta):
        self.model = model
        self.optimizer = optimizer
        self.t_max = t_max
        self.gamma = gamma
        self.beta = beta
        self.shared_model = model
        self.shared_model.share_memory()
    def compute_loss(self, trajectories, last_value, masks):
        rewards, values, log_probs, entropies = trajectories
        R = last_value
        returns = []
        for i in reversed(range(len(rewards))):
            R = rewards[i] + self.gamma * R * masks[i]
            returns.insert(0, R)
        returns = torch.stack(returns)
        values = torch.stack(values)
        advantage = returns - values
        policy_loss = -(log_probs * advantage.detach()).mean()
        value_loss = advantage.pow(2).mean()
        entropy_loss = torch.stack(entropies).mean()
        total_loss = policy_loss + 0.5 * value_loss - self.beta * entropy_loss
        return total_loss
    def update(self, trajectories, last_value, masks):
        loss = self.compute_loss(trajectories, last_value, masks)
        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.shared_model.parameters(), 40)
        self.optimizer.step()

# ---------- Training worker ----------
def worker(process_id, args, global_step, lock, env_seeds, model, optimizer):
    env = make_env(args.env, env_seeds[process_id], True)
    obs = env.reset()
    hx = torch.zeros(128)
    cx = torch.zeros(128)
    done = False
    episode_reward = 0.0
    while True:
        if global_step.value >= args.steps:
            break
        trajectories = ([], [], [], [])
        last_value = None
        for step in range(args.t_max):
            obs_tensor = torch.from_numpy(obs).unsqueeze(0)
            if args.arch == 'LSTMGaussian':
                logits, _, value, (hx, cx) = model(obs_tensor, hx, cx)
            else:
                logits, value = model(obs_tensor)
                if 'Softmax' in args.arch:
                    probs = F.softmax(logits, dim=-1)
                    log_probs = torch.log(probs + 1e-8)
                else:
                    probs = F.mellowmax(logits)
                    log_probs = torch.log(probs + 1e-8)
            action = probs.multinomial(num_samples=1).detach()
            action_np = action.numpy()[0]
            next_obs, reward, done, info = env.step(action_np)
            episode_reward += reward
            trajectories[0].append(reward)
            trajectories[1].append(value)
            trajectories[2].append(log_probs[0, action_np])
            trajectories[3].append(F.log_softmax(logits, dim=-1)[0, action_np])
            obs = next_obs
            if done:
                obs = env.reset()
                break
        with lock:
            global_step.value += args.t_max
        last_value = torch.zeros(1)
        masks = [1.0]
        agent.update(trajectories, last_value, masks)
    env.close()

# ---------- Environment factory ----------
def make_env(env_name, seed, training):
    env = gym.make(env_name)
    env.seed(seed)
    if training:
        env = RewardScaleWrapper(env, args.reward_scale_factor)
    env = Float32ObsWrapper(env)
    return env

# ---------- Evaluation ----------
def eval_performance(agent, env_name, n_runs, seed):
    env = gym.make(env_name)
    env.seed(seed)
    env = Float32ObsWrapper(env)
    total_reward = 0.0
    for _ in range(n_runs):
        obs = env.reset()
        done = False
        ep_reward = 0.0
        while not done:
            obs_tensor = torch.from_numpy(obs).unsqueeze(0)
            with torch.no_grad():
                if isinstance(agent.model, LSTMGaussian):
                    logits, _, _, _ = agent.model(obs_tensor, torch.zeros(128), torch.zeros(128))
                else:
                    logits, _ = agent.model(obs_tensor)
            probs = F.softmax(logits, dim=-1)
            action = probs.multinomial(num_samples=1).item()
            obs, reward, done, _ = env.step(action)
            ep_reward += reward
        total_reward += ep_reward
    env.close()
    return total_reward / n_runs

# ---------- Main ----------
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--processes', type=int, default=4)
    parser.add_argument('--env', type=str, required=True)
    parser.add_argument('--arch', type=str, choices=['FFSoftmax', 'FFMellowmax', 'LSTMGaussian'], default='FFSoftmax')
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--outdir', type=str, default='results')
    parser.add_argument('--t-max', type=int, default=5)
    parser.add_argument('--beta', type=float, default=1e-2)
    parser.add_argument('--lr', type=float, default=7e-4)
    parser.add_argument('--reward-scale-factor', type=float, default=1e-2)
    parser.add_argument('--rmsprop-epsilon', type=float, default=1e-1)
    parser.add_argument('--steps', type=int, default=8 * 10**7)
    parser.add_argument('--weight-decay', type=float, default=0.0)
    parser.add_argument('--load', type=str, default='')
    parser.add_argument('--demo', action='store_true')
    parser.add_argument('--eval-n-runs', type=int, default=10)
    parser.add_argument('--eval-interval', type=int, default=10**5)
    args = parser.parse_args()

    torch.manual_seed(args.seed)
    np.random.seed(args.seed)

    if not os.path.exists(args.outdir):
        os.makedirs(args.outdir)

    env = gym.make(args.env)
    obs_dim = env.observation_space.shape[0]
    if isinstance(env.action_space, gym.spaces.Discrete):
        act_dim = env.action_space.n
    else:
        act_dim = env.action_space.shape[0]
    env.close()

    if args.arch == 'FFSoftmax':
        model = FFSoftmax(obs_dim, act_dim)
    elif args.arch == 'FFMellowmax':
        model = FFMellowmax(obs_dim, act_dim)
    else:
        model = LSTMGaussian(obs_dim, act_dim)

    if args.load:
        model.load_state_dict(torch.load(args.load))

    optimizer = optim.RMSprop(
        model.parameters(),
        lr=args.lr,
        alpha=0.99,
        eps=args.rmsprop_epsilon,
        weight_decay=args.weight_decay
    )

    agent = A3CAgent(model, optimizer, args.t_max, gamma=0.99, beta=args.beta)

    if args.demo:
        avg_reward = eval_performance(agent, args.env, args.eval_n_runs, args.seed)
        print(f'Demo average reward: {avg_reward}')
    else:
        global_step = mp.Value('i', 0)
        lock = mp.Lock()
        process_seeds = np.arange(args.processes) + args.seed * args.processes
        processes = []
        for pid in range(args.processes):
            p = mp.Process(target=worker, args=(pid, args, global_step, lock, process_seeds, agent.shared_model, agent.optimizer))
            p.start()
            processes.append(p)
        for p in processes:
            p.join()
        torch.save(agent.shared_model.state_dict(), os.path.join(args.outdir, 'final_model.pt'))
        print(f'Training finished, total steps: {global_step.value}')