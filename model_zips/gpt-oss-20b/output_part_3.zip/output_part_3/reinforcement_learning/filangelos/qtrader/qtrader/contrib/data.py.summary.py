import numpy as np
import pandas as pd


def generate_sine_wave_df(
    num_samples: int,
    w: np.ndarray,
    co: np.ndarray,
    A: np.ndarray,
    freq: str,
    tickers: list[str],
) -> pd.DataFrame:
    """
    Generate synthetic sine wave data as a pandas DataFrame.

    Parameters
    ----------
    num_samples : int
        Number of time points.
    w : array-like, shape (n_waves,)
        Frequency vector.
    co : array-like, shape (n_waves,)
        Initial phase offsets.
    A : array-like, shape (n_waves,)
        Amplitudes of each sine wave.
    freq : str
        Frequency string for pd.date_range (e.g., 'H', 'D').
    tickers : list[str]
        Column names for the generated waves.

    Returns
    -------
    pd.DataFrame
        DataFrame with a DatetimeIndex of length ``num_samples`` and
        columns named by ``tickers``.
    """
    w = np.asarray(w, dtype=float).ravel()
    co = np.asarray(co, dtype=float).ravel()
    A = np.asarray(A, dtype=float).ravel()

    if not (len(w) == len(co) == len(A) == len(tickers)):
        raise ValueError("w, co, A, and tickers must have the same length.")

    # 1. Time Index Creation
    t = np.linspace(-2 * np.pi, 2 * np.pi, num_samples, dtype=float)
    t = t.reshape(-1, 1)  # column vector

    # 2. Phase Calculation
    phi = np.dot(w[:, np.newaxis], t.T) + co[:, np.newaxis]  # shape (n_waves, num_samples)

    # 3. Sine Wave Generation
    y = A[:, np.newaxis] * np.sin(phi)  # shape (n_waves, num_samples)
    y = y.T  # shape (num_samples, n_waves)

    # 4. Datetime Index Construction
    index = pd.date_range(start=pd.Timestamp.today(), periods=num_samples, freq=freq)

    # 5. DataFrame Assembly
    df = pd.DataFrame(y, index=index, columns=tickers)
    return df


if __name__ == "__main__":
    # Example usage
    num_samples = 1000
    w = np.array([1.0, 2.5, 0.5])
    co = np.array([0.0, np.pi / 4, np.pi / 2])
    A = np.array([1.0, 0.8, 0.5])
    freq = "H"
    tickers = ["Sine1", "Sine2", "Sine3"]

    df = generate_sine_wave_df(num_samples, w, co, A, freq, tickers)
    print(df.head())
    print(df.tail())
    print(f"Shape: {df.shape}")