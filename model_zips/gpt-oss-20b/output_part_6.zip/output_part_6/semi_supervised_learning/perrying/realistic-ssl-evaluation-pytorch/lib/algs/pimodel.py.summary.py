import torch
import torch.nn as nn
import torch.nn.functional as F


class PiModel(nn.Module):
    """
    PyTorch module that computes a consistency loss between model predictions
    and target labels using a softmax-based MSE loss. Batch statistics of the
    underlying model are temporarily disabled during the first forward pass
    to prevent updating running statistics.
    """

    def __init__(self, model: nn.Module):
        """
        Args:
            model (nn.Module): The underlying model that must provide an
                `update_batch_stats` method to control batch normalization
                statistics updates.
        """
        super().__init__()
        self.model = model

    def forward(
        self,
        x: torch.Tensor,
        y: torch.Tensor,
        mask: torch.Tensor,
    ) -> torch.Tensor:
        """
        Compute the consistency loss.

        Args:
            x (torch.Tensor): Input tensor.
            y (torch.Tensor): Target tensor (logits or one‑hot).
            mask (torch.Tensor): Tensor of the same shape as the per‑sample loss
                used to weight/ignore certain samples.

        Returns:
            torch.Tensor: Scalar loss value.
        """
        # Disable batch statistics update
        self.model.update_batch_stats(False)

        # Generate predictions without updating BN statistics
        y_hat = self.model(x)

        # Re‑enable batch statistics update
        self.model.update_batch_stats(True)

        # Compute softmax probabilities
        softmax_y_hat = F.softmax(y_hat, dim=1)
        softmax_y = F.softmax(y, dim=1).detach()

        # Mean squared error per class
        loss = F.mse_loss(softmax_y_hat, softmax_y, reduction="none")

        # Average over class dimension, apply mask, then average over batch
        loss = loss.mean(dim=1) * mask
        loss = loss.mean()

        return loss

# Example usage:
# model = YourModel()
# pi_model = PiModel(model)
# loss = pi_model(input_tensor, target_tensor, mask_tensor)