import os
import glob
import pickle
import numpy as np
from PIL import Image
import h5py

# Directories
path_gan_sample_pkl = "./pkl_samples"
path_gan_sample_img = "./image_samples"

os.makedirs(path_gan_sample_pkl, exist_ok=True)
os.makedirs(path_gan_sample_img, exist_ok=True)

def get_filename_from_idx(idx: int) -> str:
    return f"sample_{idx:06d}"

# Find all .pkl files
pkl_files = sorted(glob.glob(os.path.join(path_gan_sample_pkl, "*.pkl")))

i_counter = 0
list_z = []

for pkl_file in pkl_files:
    with open(pkl_file, "rb") as f:
        data = pickle.load(f)
    x = data["x"]
    z = data["z"]
    list_z.append(z)
    for i in range(x.shape[0]):
        img_array = x[i]
        # Ensure image is in uint8 format
        if np.issubdtype(img_array.dtype, np.floating):
            img_array = (img_array * 255).clip(0, 255).astype(np.uint8)
        elif np.issubdtype(img_array.dtype, np.integer):
            img_array = img_array.astype(np.uint8)
        else:
            img_array = np.clip(img_array, 0, 255).astype(np.uint8)
        img = Image.fromarray(img_array)
        base_name = get_filename_from_idx(i_counter)
        img_path = os.path.join(path_gan_sample_img, f"{base_name}.jpg")
        img.save(img_path, format="JPEG")
        npy_path = os.path.join(path_gan_sample_img, f"{base_name}.npy")
        np.save(npy_path, z[i])
        i_counter += 1

# Concatenate all latent vectors
z_concat = np.concatenate(list_z, axis=0)
h5_path = os.path.join(path_gan_sample_img, "sample_z.h5")
with h5py.File(h5_path, "w") as h5f:
    h5f.create_dataset("z", data=z_concat)