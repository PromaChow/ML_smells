import numpy as np
import scipy.stats as st
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from pywsl import pnu_mr as pnu
from pywsl import cpe_ene as cpe

sns.set(font_scale=1.2, rc={'lines.linewidth': 2})


def calc_err(f_dec, x_tp, x_tn, prior):
    """Compute weighted error rate given a decision function."""
    y_pred_pos = f_dec(x_tp) >= 0
    y_pred_neg = f_dec(x_tn) < 0
    err_pos = np.mean(~y_pred_pos)
    err_neg = np.mean(~y_pred_neg)
    return prior * err_pos + (1 - prior) * err_neg


def gendata(n_l, prior_l, n_u, prior_u, n_t):
    """Generate synthetic 2D data for labeled, unlabeled, and test sets."""
    # Labeled data
    n_p = int(n_l * prior_l)
    n_n = n_l - n_p
    mu_pos = np.array([1.0, 1.0])
    mu_neg = np.array([-1.0, -1.0])
    cov = np.eye(2)

    x_p_l = np.random.multivariate_normal(mu_pos, cov, n_p)
    x_n_l = np.random.multivariate_normal(mu_neg, cov, n_n)
    x_l = np.vstack([x_p_l, x_n_l])
    y_l = np.hstack([np.ones(n_p), -np.ones(n_n)])

    # Unlabeled data
    n_up = int(n_u * prior_u)
    n_un = n_u - n_up
    x_p_u = np.random.multivariate_normal(mu_pos, cov, n_up)
    x_n_u = np.random.multivariate_normal(mu_neg, cov, n_un)
    x_u = np.vstack([x_p_u, x_n_u])
    # No labels for unlabeled set

    # Test data
    n_tp = int(n_t * prior_u)
    n_tn = n_t - n_tp
    x_tp = np.random.multivariate_normal(mu_pos, cov, n_tp)
    x_tn = np.random.multivariate_normal(mu_neg, cov, n_tn)

    x = np.vstack([x_l, x_u])
    y = np.hstack([y_l, np.full(n_u, np.nan)])
    return x, y, x_tp, x_tn, x_u, x_p_l, x_n_l


def plot_decision_boundary(ax, w, b, color='k', linestyle='-'):
    xx, yy = np.meshgrid(
        np.linspace(-3, 3, 400), np.linspace(-3, 3, 400))
    zz = w[0] * xx + w[1] * yy + b
    ax.contour(xx, yy, zz, levels=[0], colors=color, linestyles=linestyle)


def main():
    # Parameters
    n_l = 10
    n_u = 300
    n_t = 1000
    prior_l = 0.5
    prior_u = 0.3
    eta_list = np.linspace(-0.9, 0.9, 11)
    lambda_list = [0.1]
    n_trial = 20

    errs1 = np.zeros(n_trial)
    errs2 = np.zeros((n_trial, len(eta_list)))
    priors = np.zeros(n_trial)

    best_error = np.inf
    best_w = None
    best_x = None
    best_y = None

    for ite in range(n_trial):
        x, y, x_tp, x_tn, x_u, x_p_l, x_n_l = gendata(
            n_l, prior_l, n_u, prior_u, n_t)

        priorh = cpe.cpe(x_u)

        f_dec, outs, funcs = pnu.PNU_SL_FastCV(
            x, y, priorh, eta_list, lambda_list, basis='lm')

        errs1[ite] = calc_err(f_dec, x_tp, x_tn, prior_u)

        for j, func in enumerate(funcs):
            errs2[ite, j] = calc_err(func, x_tp, x_tn, prior_u)

        priors[ite] = priorh

        if errs1[ite] < best_error:
            best_error = errs1[ite]
            best_w = outs[0] if hasattr(outs, '__len__') and len(outs) > 0 else None
            best_x = x
            best_y = y

    avg_err = np.mean(errs1)
    sem_err = np.std(errs1) / np.sqrt(n_trial)
    avg_prior = np.mean(priors)
    sem_prior = np.std(priors) / np.sqrt(n_trial)

    print(f'Average error: {avg_err:.4f} ± {sem_err:.4f}')
    print(f'Average estimated prior: {avg_prior:.4f} ± {sem_prior:.4f}')

    # Figure 1: data and decision boundaries
    fig1, ax1 = plt.subplots(figsize=(6, 6))
    ax1.scatter(x_u[:, 0], x_u[:, 1], c='k', s=20, label='Unlabeled')
    ax1.scatter(x_p_l[:, 0], x_p_l[:, 1], facecolors='none',
                edgecolors='b', s=80, label='Positive')
    ax1.scatter(x_n_l[:, 0], x_n_l[:, 1], marker='x',
                c='r', s=80, label='Negative')

    mu_pos = np.array([1.0, 1.0])
    mu_neg = np.array([-1.0, -1.0])
    w_analytic = mu_pos - mu_neg
    b_analytic = -0.5 * (
        mu_pos @ mu_pos - mu_neg @ mu_neg) + np.log((1 - prior_u) / prior_u)
    plot_decision_boundary(ax1, w_analytic, b_analytic,
                           color='g', linestyle='-')
    ax1.plot([], [], color='g', linestyle='-',
             label='Analytic boundary')

    if best_w is not None and len(best_w) == 3:
        w_est = best_w[:2]
        b_est = best_w[2]
        plot_decision_boundary(ax1, w_est, b_est,
                               color='m', linestyle='--')
        ax1.plot([], [], color='m', linestyle='--',
                 label='Estimated boundary')

    ax1.set_xlabel('x1')
    ax1.set_ylabel('x2')
    ax1.set_title('Data and Decision Boundaries')
    ax1.legend()
    ax1.grid(True)
    fig1.tight_layout()
    fig1.savefig('data.pdf')

    # Figure 2: error curves
    mean_errs2 = np.mean(errs2, axis=0)
    std_errs2 = np.std(errs2, axis=0)
    fig2, ax2 = plt.subplots(figsize=(6, 4))
    ax2.errorbar(eta_list, mean_errs2, yerr=std_errs2,
                 fmt='o-', capsize=5)
    ax2.set_xlabel('eta')
    ax2.set_ylabel('Weighted error')
    ax2.set_title('Error vs eta')
    ax2.grid(True)
    fig2.tight_layout()
    fig2.savefig('err_curve.pdf')


if __name__ == '__main__':
    main()
