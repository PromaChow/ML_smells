import gym
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from huskarl import A2C, envs, policies, utils

# 1. Environment Setup
env = gym.make('CartPole-v0')
env.unwrapped
dummy_obs = env.reset()
obs_shape = dummy_obs.shape[0]

# 2. Neural Network Construction
model = Sequential([
    Dense(16, activation='relu', input_shape=(obs_shape,)),
    Dense(16, activation='relu'),
    Dense(16, activation='relu')
])

# 3. Multi-Instance Configuration
nb_envs = 16

# 4. Policy Initialization
policy_list = [policies.Greedy()]
eps_values = np.linspace(0, 1, 15)
policy_list += [policies.GaussianEpsGreedy(eps) for eps in eps_values]

# 5. Agent Creation
nb_actions = env.action_space.n
agent = A2C(model, nb_actions, 2, nb_envs, policy_list)

# 6. Reward Visualization Function
def plot_rewards(rewards, steps):
    plt.figure(figsize=(10, 5))
    plt.plot(steps, rewards, marker='o', linestyle='-')
    plt.xlabel('Step')
    plt.ylabel('Cumulative Reward')
    plt.title('Training Rewards')
    plt.grid(True)
    plt.show()

# 7. Training and Testing
sim = utils.Simulation(env, agent)
# Live plot will be handled by Huskarl's built-in functionality
sim.run(5000, live_plot=True)
# Test the trained agent
agent.test(1000, live_plot=False)