import numpy as np


def _FSpecialGauss(size: int, sigma: float) -> np.ndarray:
    """Create a 2‑D Gaussian kernel with the given size and sigma."""
    assert size % 2 == 1, "size must be odd"
    ax = np.arange(-(size // 2), size // 2 + 1, dtype=np.float32)
    xx, yy = np.meshgrid(ax, ax)
    kernel = np.exp(-(xx ** 2 + yy ** 2) / (2.0 * sigma ** 2))
    kernel /= kernel.sum()
    return kernel


def _conv2d_fft(img: np.ndarray, kernel: np.ndarray) -> np.ndarray:
    """
    Convolve a batch of images with a 2‑D kernel using FFT.
    img shape: (batch, height, width, depth)
    kernel shape: (k, k)
    Returns a batch of convolved images with the same shape.
    """
    batch, h, w, c = img.shape
    k = kernel.shape[0]
    # Size for FFT to avoid wrap‑around
    conv_shape = (h + k - 1, w + k - 1)
    img_fft = np.fft.fft2(img.reshape(batch * c, h, w), s=conv_shape)
    kernel_fft = np.fft.fft2(kernel, s=conv_shape)
    conv = np.fft.ifft2(img_fft[:, None, :, :] * kernel_fft, axes=(2, 3)).real
    conv = conv.reshape(batch, c, *conv_shape)
    start_h = (k - 1) // 2
    start_w = (k - 1) // 2
    conv = conv[:, :, start_h : start_h + h, start_w : start_w + w]
    return conv.transpose(0, 2, 3, 1)  # (batch, h, w, c)


def _SSIMForMultiScale(
    img1: np.ndarray,
    img2: np.ndarray,
    filter_size: int = 11,
    sigma: float = 1.5,
    k1: float = 0.01,
    k2: float = 0.03,
    max_val: float = 1.0,
) -> tuple[float, float]:
    """
    Compute SSIM and CS for a single scale.
    Returns the mean SSIM and mean CS over the batch.
    """
    if img1.shape != img2.shape:
        raise ValueError("Input images must have the same shape.")
    if img1.ndim != 4:
        raise ValueError("Input images must have shape (batch, h, w, c).")

    batch, h, w, c = img1.shape

    # Adjust filter size if image is smaller
    fs = min(filter_size, h, w)
    if fs % 2 == 0:
        fs -= 1
    if fs < 3:
        fs = 3

    kernel = _FSpecialGauss(fs, sigma)

    mu1 = _conv2d_fft(img1, kernel)
    mu2 = _conv2d_fft(img2, kernel)

    mu1_sq = mu1 ** 2
    mu2_sq = mu2 ** 2
    mu1_mu2 = mu1 * mu2

    sigma11 = _conv2d_fft(img1 ** 2, kernel) - mu1_sq
    sigma22 = _conv2d_fft(img2 ** 2, kernel) - mu2_sq
    sigma12 = _conv2d_fft(img1 * img2, kernel) - mu1_mu2

    c1 = (k1 * max_val) ** 2
    c2 = (k2 * max_val) ** 2

    numerator = (2 * mu1_mu2 + c1) * (2 * sigma12 + c2)
    denominator = (mu1_sq + mu2_sq + c1) * (sigma11 + sigma22 + c2)

    ssim_map = numerator / denominator
    cs_map = (2 * sigma12 + c2) / (sigma11 + sigma22 + c2)

    ssim = ssim_map.mean()
    cs = cs_map.mean()

    return ssim, cs


def _HoxDownsample(img: np.ndarray) -> np.ndarray:
    """
    Downsample an image by averaging each non‑overlapping 2x2 block.
    """
    batch, h, w, c = img.shape
    h2 = h // 2
    w2 = w // 2
    img = img[:, : h2 * 2, : w2 * 2, :]
    img = img.reshape(batch, h2, 2, w2, 2, c)
    img = img.mean(axis=(2, 4))
    return img


def msssim(
    img1: np.ndarray,
    img2: np.ndarray,
    weights: list[float] | None = None,
    filter_size: int = 11,
    sigma: float = 1.5,
    k1: float = 0.01,
    k2: float = 0.03,
    max_val: float = 1.0,
) -> float:
    """
    Compute Multi‑Scale SSIM between two images.
    """
    if weights is None:
        weights = [0.0448, 0.2856, 0.3001, 0.2363, 0.1333]

    ssim_values = []
    cs_values = []

    for _ in weights[:-1]:
        ssim, cs = _SSIMForMultiScale(img1, img2, filter_size, sigma, k1, k2, max_val)
        ssim_values.append(ssim)
        cs_values.append(cs)
        img1 = _HoxDownsample(img1)
        img2 = _HoxDownsample(img2)

    # Last scale uses SSIM
    ssim, _ = _SSIMForMultiScale(img1, img2, filter_size, sigma, k1, k2, max_val)
    ssim_values.append(ssim)

    msssim_value = 1.0
    for i in range(len(weights)):
        if i < len(weights) - 1:
            msssim_value *= cs_values[i] ** weights[i]
        else:
            msssim_value *= ssim_values[i] ** weights[i]

    return msssim_value


class API:
    """
    API class for batch processing of MS‑SSIM scores.
    """

    def __init__(self, num_images: int, image_shape: tuple[int, int, int], minibatch_size: int):
        self.num_images = num_images
        self.image_shape = image_shape  # (h, w, c)
        self.minibatch_size = minibatch_size
        self.total_score = 0.0
        self.count = 0

    def begin(self, mode: str = None) -> None:
        self.total_score = 0.0
        self.count = 0

    def feed(self, mode: str, minibatch: tuple[np.ndarray, np.ndarray]) -> None:
        """
        minibatch: tuple of (real, fake) arrays each of shape (batch, h, w, c)
        """
        real, fake = minibatch
        batch_score = msssim(real, fake)
        self.total_score += batch_score
        self.count += 1

    def end(self, mode: str) -> float:
        if self.count == 0:
            return 0.0
        return self.total_score / self.count
