import numpy as np

class RunningMeanVar:
    def __init__(self, shape):
        """
        Initialize the RunningMeanVar with the given shape.
        Parameters
        ----------
        shape : tuple
            The shape of the data excluding the batch dimension.
        """
        self.shape = shape
        self.mean = np.zeros(shape, dtype=np.float64)
        self.var = np.ones(shape, dtype=np.float64)
        self.N = 1e-8  # small initial count to avoid division by zero

    def update(self, x):
        """
        Update the running mean and variance with a new batch of data.
        Parameters
        ----------
        x : array_like
            Batch of data with shape (batch_size, *shape).
        """
        x = np.asarray(x, dtype=np.float64)

        if x.ndim != len(self.shape) + 1:
            raise ValueError(
                f"Input array must have {len(self.shape) + 1} dimensions, "
                f"got {x.ndim}."
            )

        batch_mean = np.mean(x, axis=0)
        batch_var = np.var(x, axis=0)
        batch_N = x.shape[0]

        new_N = self.N + batch_N

        delta = batch_mean - self.mean
        new_mean = self.mean + delta * (batch_N / new_N)

        M_A = self.N * self.var
        M_B = batch_N * batch_var
        M_X = M_A + M_B + (delta ** 2) * (self.N * batch_N / new_N)
        new_var = M_X / new_N

        self.mean = new_mean
        self.var = new_var
        self.N = new_N

    @property
    def n(self):
        """Return the total number of samples processed so far."""
        return int(self.N)