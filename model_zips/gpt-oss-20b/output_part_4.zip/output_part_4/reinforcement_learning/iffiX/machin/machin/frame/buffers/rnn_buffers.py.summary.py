import random
import threading
from typing import List, Tuple, Any, Dict

import torch


class Buffer:
    """
    Basic replay buffer that stores episodes.
    Each episode is a list of transition dictionaries.
    """

    def __init__(self):
        self.episodes: List[List[Dict[str, Any]]] = []

    def store_episode(self, episode: List[Dict[str, Any]]) -> None:
        """
        Store a complete episode.
        """
        self.episodes.append(episode)

    def sample_batch(self, batch_size: int):
        """
        Default random batch sampling.
        """
        batch = []
        for _ in range(batch_size):
            ep = random.choice(self.episodes)
            transition = random.choice(ep)
            batch.append(transition)
        return batch

    def get_episodes(self) -> List[List[Dict[str, Any]]]:
        return self.episodes


class DistributedBuffer:
    """
    Placeholder for distributed buffer logic.
    """

    def __init__(self, group_name: str):
        self.group_name = group_name
        self.wr_lock = threading.Lock()

    def _broadcast(self, data):
        # Dummy broadcast implementation
        return data

    def _receive(self):
        # Dummy receive implementation
        return None


class PrioritizedBuffer:
    """
    Simple prioritized buffer using a sum tree for sampling.
    """

    def __init__(self, epsilon: float = 0.01, alpha: float = 0.6):
        self.epsilon = epsilon
        self.alpha = alpha
        self.priorities: List[float] = []

    def _get_priority(self, td_error: float) -> float:
        return (abs(td_error) + self.epsilon) ** self.alpha

    def update_priorities(self, indices: List[int], td_errors: List[float]) -> None:
        for idx, error in zip(indices, td_errors):
            self.priorities[idx] = self._get_priority(error)

    def sample_indices(self, batch_size: int, beta: float) -> Tuple[List[int], List[float]]:
        if not self.priorities:
            raise ValueError("No priorities to sample from.")
        probs = [p / sum(self.priorities) for p in self.priorities]
        indices = random.choices(range(len(self.priorities)), weights=probs, k=batch_size)
        weights = [((1 / (len(self.priorities) * probs[i])) ** beta) for i in indices]
        return indices, weights


class DistributedPrioritizedBuffer(DistributedBuffer, PrioritizedBuffer):
    """
    Combines distributed and prioritized buffer capabilities.
    """

    def __init__(self, group_name: str, epsilon: float = 0.01, alpha: float = 0.6):
        DistributedBuffer.__init__(self, group_name)
        PrioritizedBuffer.__init__(self, epsilon, alpha)


class RNNBuffer(Buffer):
    """
    Buffer specialized for RNN sequence sampling.
    """

    def __init__(self, sample_length: int = 5, sample_dimension: int = 3):
        super().__init__()
        self.sample_length = sample_length
        self.sample_dimension = sample_dimension

    def sample_method_random_unique(self, batch_size: int) -> List[List[Dict[str, Any]]]:
        """
        Sample unique episodes for each batch element.
        """
        valid_eps = [ep for ep in self.episodes if len(ep) >= self.sample_length]
        samples = []
        selected_eps = random.sample(valid_eps, k=min(batch_size, len(valid_eps)))
        for ep in selected_eps:
            start = random.randint(0, len(ep) - self.sample_length)
            seq = ep[start : start + self.sample_length]
            samples.append(seq)
        return samples

    def sample_method_random(self, batch_size: int) -> List[List[Dict[str, Any]]]:
        """
        Sample episodes allowing repeats.
        """
        valid_eps = [ep for ep in self.episodes if len(ep) >= self.sample_length]
        samples = []
        for _ in range(batch_size):
            ep = random.choice(valid_eps)
            start = random.randint(0, len(ep) - self.sample_length)
            seq = ep[start : start + self.sample_length]
            samples.append(seq)
        return samples

    def sample_method_all(self) -> List[List[Dict[str, Any]]]:
        """
        Return all possible sequences from valid episodes.
        """
        all_sequences = []
        for ep in self.episodes:
            if len(ep) >= self.sample_length:
                for start in range(len(ep) - self.sample_length + 1):
                    seq = ep[start : start + self.sample_length]
                    all_sequences.append(seq)
        return all_sequences

    def post_process_attribute(self, tensor: torch.Tensor) -> torch.Tensor:
        """
        Reshape tensor to (batch_size, sample_length, sample_dimension).
        """
        return tensor.view(-1, self.sample_length, self.sample_dimension)


class RNNDistributedBuffer(RNNBuffer, DistributedBuffer):
    """
    Combines RNNBuffer with DistributedBuffer.
    """

    def __init__(self, buffer_name: str, group_name: str, sample_length: int = 5, sample_dimension: int = 3):
        RNNBuffer.__init__(self, sample_length, sample_dimension)
        DistributedBuffer.__init__(self, group_name)
        self.buffer_name = buffer_name

    def store_episode(self, episode: List[Dict[str, Any]]) -> None:
        with self.wr_lock:
            super().store_episode(episode)


class RNNPrioritizedBuffer(RNNBuffer, PrioritizedBuffer):
    """
    RNNBuffer with prioritization logic.
    """

    def __init__(
        self,
        sample_length: int = 5,
        sample_dimension: int = 3,
        epsilon: float = 0.01,
        alpha: float = 0.6,
        beta: float = 0.4,
        beta_increment_per_sampling: float = 0.001,
    ):
        RNNBuffer.__init__(self, sample_length, sample_dimension)
        PrioritizedBuffer.__init__(self, epsilon, alpha)
        self.beta = beta
        self.beta_increment_per_sampling = beta_increment_per_sampling

    def store_episode(self, episode: List[Dict[str, Any]]) -> None:
        super().store_episode(episode)
        # Assign priority only if episode long enough for sequences
        if len(episode) >= self.sample_length:
            # Dummy TD error of 1 for each transition in episode
            td_error = 1.0
            priority = self._get_priority(td_error)
            # Store priority per transition
            for _ in episode:
                self.priorities.append(priority)

    def sample_batch(self, batch_size: int) -> Tuple[List[List[Dict[str, Any]]], List[int], List[float]]:
        indices, weights = self.sample_indices(batch_size, self.beta)
        self.beta = min(1.0, self.beta + self.beta_increment_per_sampling)
        batch = []
        for idx in indices:
            # Map flat index to episode and transition
            ep_idx, trans_idx = 0, idx
            # Find episode containing this transition
            while ep_idx < len(self.episodes):
                ep_len = len(self.episodes[ep_idx])
                if trans_idx < ep_len:
                    break
                trans_idx -= ep_len
                ep_idx += 1
            transition = self.episodes[ep_idx][trans_idx]
            batch.append(transition)
        return batch, indices, weights


class RNNDistributedPrioritizedBuffer(RNNPrioritizedBuffer, DistributedPrioritizedBuffer):
    """
    Combines distributed and prioritized RNN buffer.
    """

    def __init__(
        self,
        buffer_name: str,
        group_name: str,
        sample_length: int = 5,
        sample_dimension: int = 3,
        epsilon: float = 0.01,
        alpha: float = 0.6,
        beta: float = 0.4,
        beta_increment_per_sampling: float = 0.001,
    ):
        RNNPrioritizedBuffer.__init__(
            self,
            sample_length,
            sample_dimension,
            epsilon,
            alpha,
            beta,
            beta_increment_per_sampling,
        )
        DistributedPrioritizedBuffer.__init__(self, group_name, epsilon, alpha)
        self.buffer_name = buffer_name

    def store_episode(self, episode: List[Dict[str, Any]]) -> None:
        with self.wr_lock:
            super().store_episode(episode)

    def _sample_service(self, batch_size: int):
        """
        Distributed sampling service that returns batch, indices, and weights.
        """
        batch, indices, weights = self.sample_batch(batch_size)
        # Simulate versioning info for synchronization
        version = len(self.episodes)
        return batch, indices, weights, version
