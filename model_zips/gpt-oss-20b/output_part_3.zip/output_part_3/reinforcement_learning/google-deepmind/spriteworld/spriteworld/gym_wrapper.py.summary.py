import numpy as np
import gym
from gym import spaces
import dm_env
from dm_env import specs as dm_specs


def _spec_to_space(spec):
    """Convert a dm_env spec to a gym Space."""
    if isinstance(spec, dm_specs.DiscreteArray):
        return spaces.Discrete(spec.num_values)
    if isinstance(spec, dm_specs.BoundedArray):
        return spaces.Box(
            low=spec.minimum,
            high=spec.maximum,
            shape=spec.shape,
            dtype=spec.dtype,
        )
    if isinstance(spec, (list, tuple)):
        return spaces.Tuple(tuple(_spec_to_space(s) for s in spec))
    if isinstance(spec, dict):
        return spaces.Dict({k: _spec_to_space(v) for k, v in spec.items()})
    raise TypeError(f"Unsupported spec type: {type(spec)}")


class GymWrapper(gym.Env):
    def __init__(self, env: dm_env.Environment):
        super().__init__()
        self.env = env
        # Perform an initial reset to populate observation_spec
        initial_ts = self.env.reset()
        self._initial_ts = initial_ts
        self._observation_space = None
        self._action_space = None
        self._last_render = None

    @property
    def observation_space(self):
        if self._observation_space is None:
            obs_spec = self.env.observation_spec()
            # Build a Dict space where each renderer has a Box with inf bounds
            space_dict = {}
            for key, spec in obs_spec.items():
                shape = spec.shape
                dtype = spec.dtype
                space_dict[key] = spaces.Box(
                    low=-np.inf,
                    high=np.inf,
                    shape=shape,
                    dtype=dtype,
                )
            self._observation_space = spaces.Dict(space_dict)
        return self._observation_space

    @property
    def action_space(self):
        if self._action_space is None:
            self._action_space = _spec_to_space(self.env.action_spec())
        return self._action_space

    def _process_obs(self, obs):
        processed = {}
        for key, value in obs.items():
            arr = np.asarray(value, dtype=value.dtype)
            if arr.dtype == np.bool_:
                arr = arr.astype(np.float32)
            processed[key] = arr
            if key == "image":
                self._last_render = arr
        return processed

    def step(self, action):
        ts = self.env.step(action)
        obs = self._process_obs(ts.observation)
        reward = ts.reward if ts.reward is not None else 0.0
        done = ts.last()
        discount = ts.discount if ts.discount is not None else 1.0
        return obs, reward, done, {"discount": discount}

    def reset(self, **kwargs):
        ts = self.env.reset(**kwargs)
        obs = self._process_obs(ts.observation)
        return obs

    def render(self, mode=None):
        return self._last_render

    def close(self):
        pass
