import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
import multiprocessing
import pathlib
from moviepy.editor import ImageSequenceClip


def _normalize_image(arr: np.ndarray) -> np.ndarray:
    if np.issubdtype(arr.dtype, np.integer):
        return arr.astype(np.float32) / 255.0
    elif np.issubdtype(arr.dtype, np.floating):
        return np.clip(arr, 0.0, 1.0)
    else:
        raise ValueError(f"Unsupported dtype {arr.dtype}")


def show_image(
    image: np.ndarray,
    title: str = "Image",
    show_normalized: bool = False,
    pause: float = 0.1,
) -> None:
    """
    Display a numpy image array using matplotlib.
    If show_normalized is True, show both the original and normalized images.
    """
    plt.ion()
    if show_normalized:
        fig, axes = plt.subplots(1, 2, figsize=(8, 4))
        # Original image (dynamic range)
        if np.issubdtype(image.dtype, np.integer):
            orig_display = image
        else:
            orig_display = np.clip(image, 0.0, 1.0)
        axes[0].imshow(orig_display, cmap="gray" if orig_display.ndim == 2 else None)
        axes[0].set_title(f"{title} - Original")
        axes[0].axis("off")

        # Normalized image
        norm_display = _normalize_image(image)
        axes[1].imshow(norm_display, cmap="gray" if norm_display.ndim == 2 else None)
        axes[1].set_title(f"{title} - Normalized")
        axes[1].axis("off")
    else:
        fig, ax = plt.subplots(figsize=(6, 4))
        norm_display = _normalize_image(image)
        ax.imshow(norm_display, cmap="gray" if norm_display.ndim == 2 else None)
        ax.set_title(title)
        ax.axis("off")
    plt.pause(pause)
    plt.ioff()
    plt.close(fig)


def create_video(
    frames,
    fps: int = 30,
    output_dir: str = ".",
    filename: str = "output",
    format: str = "gif",
) -> None:
    """
    Create a video or GIF from a list of numpy array frames.
    """
    processed_frames = []
    for fr in frames:
        fr_norm = _normalize_image(fr)
        fr_uint8 = (fr_norm * 255).astype(np.uint8)
        if fr_uint8.ndim == 2:
            fr_uint8 = np.stack([fr_uint8] * 3, axis=-1)
        elif fr_uint8.shape[-1] == 1:
            fr_uint8 = np.repeat(fr_uint8, 3, axis=-1)
        processed_frames.append(fr_uint8)

    clip = ImageSequenceClip(processed_frames, fps=fps)

    out_dir = pathlib.Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{filename}"

    if format.lower() == "gif" or out_path.suffix.lower() == ".gif":
        clip.write_gif(f"{out_path}.gif", fps=fps)
    else:
        clip.write_videofile(f"{out_path}.mp4", fps=fps, codec="libx264")


def create_video_subproc(
    frames,
    fps: int = 30,
    output_dir: str = ".",
    filename: str = "output",
    format: str = "gif",
    daemon: bool = False,
):
    """
    Launch create_video in a separate process.
    Returns a wait function that blocks until the process finishes.
    """
    p = multiprocessing.Process(
        target=create_video,
        args=(frames, fps, output_dir, filename, format),
        daemon=daemon,
    )
    p.start()

    def wait() -> None:
        p.join()

    return wait


def numpy_array_to_pil_image(arr: np.ndarray) -> Image.Image:
    """
    Convert a numpy array to a PIL Image, handling grayscale and data type conversion.
    """
    arr_norm = _normalize_image(arr)
    arr_uint8 = (arr_norm * 255).astype(np.uint8)

    if arr_uint8.ndim == 2:
        arr_uint8 = np.stack([arr_uint8] * 3, axis=-1)
    elif arr_uint8.shape[-1] == 1:
        arr_uint8 = np.repeat(arr_uint8, 3, axis=-1)
    elif arr_uint8.shape[-1] == 4:
        arr_uint8 = arr_uint8[:, :, :3]

    return Image.fromarray(arr_uint8)


def create_image(
    image: np.ndarray,
    output_dir: str = ".",
    filename: str = "image",
    extension: str = ".png",
) -> None:
    """
    Save a numpy array as an image file.
    """
    img = numpy_array_to_pil_image(image)
    out_dir = pathlib.Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{filename}{extension}"
    img.save(out_path)


def create_image_subproc(
    image: np.ndarray,
    output_dir: str = ".",
    filename: str = "image",
    extension: str = ".png",
    daemon: bool = False,
):
    """
    Launch create_image in a separate process.
    Returns a wait function that blocks until the process finishes.
    """
    p = multiprocessing.Process(
        target=create_image,
        args=(image, output_dir, filename, extension),
        daemon=daemon,
    )
    p.start()

    def wait() -> None:
        p.join()

    return wait

__all__ = [
    "show_image",
    "create_video",
    "create_video_subproc",
    "numpy_array_to_pil_image",
    "create_image",
    "create_image_subproc",
]