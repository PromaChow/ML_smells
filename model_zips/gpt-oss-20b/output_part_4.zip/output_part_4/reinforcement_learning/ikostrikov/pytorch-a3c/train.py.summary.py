import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.multiprocessing as mp
import gym
from torch.distributions import Categorical
import math
import random

def create_atari_env(env_name):
    return gym.make(env_name)

class ActorCritic(nn.Module):
    def __init__(self, num_inputs, num_outputs):
        super(ActorCritic, self).__init__()
        self.fc1 = nn.Linear(num_inputs, 256)
        self.lstm = nn.LSTM(256, 256, batch_first=True)
        self.policy = nn.Linear(256, num_outputs)
        self.value = nn.Linear(256, 1)

    def forward(self, x, hx, cx):
        x = F.relu(self.fc1(x))
        x = x.unsqueeze(1)  # seq_len=1
        out, (hx, cx) = self.lstm(x, (hx, cx))
        out = out.squeeze(1)
        logits = self.policy(out)
        value = self.value(out)
        return value, logits, hx, cx

def ensure_shared_grads(local_model, shared_model):
    for lp, sp in zip(local_model.parameters(), shared_model.parameters()):
        if lp.grad is not None:
            sp._grad = lp.grad

def worker(rank, shared_model, optimizer, counter, lock, env_name):
    torch.manual_seed(123 + rank)
    env = create_atari_env(env_name)
    obs_space = env.observation_space.shape[0] if hasattr(env.observation_space, 'shape') else 4
    action_space = env.action_space.n
    local_model = ActorCritic(obs_space, action_space)
    local_model.to('cpu')
    gamma = 0.99
    gae_lambda = 0.95
    entropy_coef = 0.01
    max_grad_norm = 50.0
    num_steps = 5

    while True:
        state = env.reset()
        state = torch.from_numpy(state).float()
        done = False
        hx = torch.zeros(1, 1, 256)
        cx = torch.zeros(1, 1, 256)

        values = []
        log_probs = []
        rewards = []

        for step in range(num_steps):
            local_model.load_state_dict(shared_model.state_dict())
            if done:
                hx = torch.zeros(1, 1, 256)
                cx = torch.zeros(1, 1, 256)
            else:
                hx = hx.detach()
                cx = cx.detach()

            value, logits, hx, cx = local_model(state.unsqueeze(0), hx, cx)
            probs = F.softmax(logits, dim=-1)
            log_prob = F.log_softmax(logits, dim=-1)
            m = Categorical(probs.squeeze(0))
            action = m.sample()
            logp = log_prob.squeeze(0)[action]
            entropy = m.entropy().mean()

            next_state, reward, done, _ = env.step(action.item())
            reward = max(min(reward, 1.0), -1.0)

            with lock:
                counter.value += 1

            if done:
                counter.value = 0
                next_state = env.reset()

            next_state_tensor = torch.from_numpy(next_state).float()

            values.append(value.squeeze(0))
            log_probs.append(logp)
            rewards.append(reward)

            state = next_state_tensor

        with torch.no_grad():
            _, next_value, _, _ = local_model(state.unsqueeze(0), hx, cx)
            R = next_value.squeeze(0).item()

        values.append(R)
        gae = 0.0
        policy_loss = 0.0
        value_loss = 0.0
        returns = []
        for i in reversed(range(num_steps)):
            R = rewards[i] + gamma * R
            returns.insert(0, R)
            delta = rewards[i] + gamma * values[i + 1] - values[i]
            gae = delta + gamma * gae_lambda * gae
            policy_loss -= log_probs[i] * gae
            value_loss += F.mse_loss(values[i], torch.tensor([R]))

        policy_loss = policy_loss / num_steps
        value_loss = value_loss / num_steps
        total_loss = policy_loss + value_loss

        optimizer.zero_grad()
        total_loss.backward()
        torch.nn.utils.clip_grad_norm_(local_model.parameters(), max_grad_norm)
        ensure_shared_grads(local_model, shared_model)
        optimizer.step()

def main():
    env_name = 'CartPole-v1'
    env = create_atari_env(env_name)
    obs_space = env.observation_space.shape[0] if hasattr(env.observation_space, 'shape') else 4
    action_space = env.action_space.n
    shared_model = ActorCritic(obs_space, action_space)
    shared_model.share_memory()
    optimizer = torch.optim.Adam(shared_model.parameters(), lr=1e-4)
    counter = mp.Value('i', 0)
    lock = mp.Lock()
    processes = []
    num_processes = mp.cpu_count()
    for rank in range(num_processes):
        p = mp.Process(target=worker, args=(rank, shared_model, optimizer, counter, lock, env_name))
        p.start()
        processes.append(p)
    for p in processes:
        p.join()

if __name__ == '__main__':
    mp.set_start_method('spawn')
    main()