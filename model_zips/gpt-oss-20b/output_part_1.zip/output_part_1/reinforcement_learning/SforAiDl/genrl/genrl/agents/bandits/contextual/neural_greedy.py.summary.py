import random
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset

class DataBasedBandit:
    """
    Simple bandit environment that provides context vectors and rewards.
    For demonstration, rewards are random; in practice, replace with domain logic.
    """
    def __init__(self, n_actions: int, context_dim: int):
        self.n_actions = n_actions
        self.context_dim = context_dim

    def get_context(self) -> np.ndarray:
        """Return a random context vector."""
        return np.random.randn(self.context_dim).astype(np.float32)

    def get_reward(self, action: int) -> float:
        """Return a random reward for the chosen action."""
        return random.random()


class NeuralBanditModel(nn.Module):
    def __init__(self, input_dim: int, output_dim: int, hidden_dims: list,
                 lr: float, max_grad_norm: float, dropout_p: float = None):
        super().__init__()
        layers = []
        last_dim = input_dim
        for h in hidden_dims:
            layers.append(nn.Linear(last_dim, h))
            layers.append(nn.ReLU())
            if dropout_p is not None:
                layers.append(nn.Dropout(dropout_p))
            last_dim = h
        layers.append(nn.Linear(last_dim, output_dim))
        self.net = nn.Sequential(*layers)
        self.optimizer = optim.Adam(self.parameters(), lr=lr)
        self.max_grad_norm = max_grad_norm

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)

    def train_model(self, dataset: TensorDataset, train_epochs: int, batch_size: int,
                    device: torch.device):
        loader = DataLoader(dataset, batch_size=batch_size, shuffle=True)
        criterion = nn.MSELoss()
        self.train()
        for _ in range(train_epochs):
            for xb, yb, ab in loader:
                xb, yb, ab = xb.to(device), yb.to(device), ab.to(device)
                self.optimizer.zero_grad()
                preds = self(xb)
                # Gather predictions for taken actions
                pred_actions = preds.gather(1, ab.unsqueeze(1)).squeeze(1)
                loss = criterion(pred_actions, yb)
                loss.backward()
                nn.utils.clip_grad_norm_(self.parameters(), self.max_grad_norm)
                self.optimizer.step()


class TransitionDB:
    """
    Simple in-memory buffer for context-action-reward transitions.
    """
    def __init__(self):
        self.contexts = []
        self.actions = []
        self.rewards = []

    def add_transition(self, context: np.ndarray, action: int, reward: float):
        self.contexts.append(context)
        self.actions.append(action)
        self.rewards.append(reward)

    def to_dataset(self, device: torch.device) -> TensorDataset:
        ctx = torch.tensor(self.contexts, dtype=torch.float32, device=device)
        act = torch.tensor(self.actions, dtype=torch.long, device=device)
        rew = torch.tensor(self.rewards, dtype=torch.float32, device=device)
        return TensorDataset(ctx, rew, act)


class NeuralGreedyAgent:
    def __init__(self,
                 bandit: DataBasedBandit,
                 init_pulls: int = 3,
                 hidden_dims: list = None,
                 init_lr: float = 0.1,
                 lr_decay: float = 0.5,
                 max_grad_norm: float = 0.5,
                 dropout_p: float = None,
                 epsilon: float = 0.0,
                 device: str = "cpu"):
        if hidden_dims is None:
            hidden_dims = [50, 50]
        self.bandit = bandit
        self.init_pulls = init_pulls
        self.hidden_dims = hidden_dims
        self.init_lr = init_lr
        self.lr_decay = lr_decay
        self.max_grad_norm = max_grad_norm
        self.dropout_p = dropout_p
        self.epsilon = epsilon
        self.device = torch.device(device)

        self.model = NeuralBanditModel(
            input_dim=bandit.context_dim,
            output_dim=bandit.n_actions,
            hidden_dims=hidden_dims,
            lr=init_lr,
            max_grad_norm=max_grad_norm,
            dropout_p=dropout_p
        ).to(self.device)

        self.db = TransitionDB()
        self.t = 0
        self.update_count = 0
        self.train_epochs = 20
        self.batch_size = 512

    def select_action(self, context: np.ndarray, eval_with_dropout: bool = False) -> int:
        n_actions = self.bandit.n_actions
        if self.t < self.init_pulls * n_actions:
            action = self.t % n_actions
        else:
            if random.random() < self.epsilon:
                action = random.randint(0, n_actions - 1)
            else:
                ctx_tensor = torch.tensor(context, dtype=torch.float32, device=self.device).unsqueeze(0)
                if eval_with_dropout:
                    self.model.train()
                else:
                    self.model.eval()
                with torch.no_grad():
                    preds = self.model(ctx_tensor)
                action = torch.argmax(preds, dim=1).item()
        self.t += 1
        return action

    def observe(self, context: np.ndarray, action: int, reward: float):
        self.db.add_transition(context, action, reward)
        self.update_model()

    def update_model(self):
        self.update_count += 1
        # Train the model every step; adjust as needed
        dataset = self.db.to_dataset(self.device)
        if len(dataset) == 0:
            return
        self.model.train_model(
            dataset=dataset,
            train_epochs=self.train_epochs,
            batch_size=self.batch_size,
            device=self.device
        )

# Example usage (remove or comment out when integrating into larger system)
if __name__ == "__main__":
    n_actions = 5
    context_dim = 10
    bandit = DataBasedBandit(n_actions=n_actions, context_dim=context_dim)
    agent = NeuralGreedyAgent(bandit=bandit, epsilon=0.1, device="cpu")

    for _ in range(100):
        ctx = bandit.get_context()
        action = agent.select_action(ctx, eval_with_dropout=False)
        reward = bandit.get_reward(action)
        agent.observe(ctx, action, reward)
    print("Training completed.")
