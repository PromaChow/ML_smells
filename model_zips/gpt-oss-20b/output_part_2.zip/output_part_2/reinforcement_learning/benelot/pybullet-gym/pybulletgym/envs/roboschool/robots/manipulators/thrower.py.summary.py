import numpy as np
from dm_control.mjcf import MJCFBasedRobot


class Thrower(MJCFBasedRobot):
    min_target_placement_radius = 0.2
    max_target_placement_radius = 0.4
    min_object_placement_radius = 0.1
    max_object_placement_radius = 0.3

    def __init__(self):
        super().__init__(mjcf_model="thrower.xml")
        self.action_dim = 7
        self.observation_dim = 48

    def robot_specific_reset(self):
        # Identify key parts
        self.fingertip = self.model.find("body", "fingertip")
        self.ball = self.model.find("body", "ball")
        self.goal = self.model.find("body", "goal")

        # Identify joints to control
        joint_names = [
            "shoulder_pan_joint",
            "shoulder_lift_joint",
            "elbow_flex_joint",
            "wrist_flex_joint",
            "wrist_roll_joint",
            "finger_joint",
            "finger_joint_2",
        ]
        self.joints = [self.model.find("joint", name) for name in joint_names]

        # Flags for interactions
        self._object_hit_ground = False
        self._object_hit_location = False

        # Randomly set joint positions
        for joint in self.joints:
            joint.qpos = np.random.uniform(-np.pi, np.pi)

        zero_offset = np.array([0.45, 0.55, 0.0])

        # Random object placement
        obj_dir = np.random.uniform(-1, 1, 3)
        obj_dir /= np.linalg.norm(obj_dir)
        obj_radius = np.random.uniform(
            self.min_object_placement_radius, self.max_object_placement_radius
        )
        obj_pos = zero_offset + obj_dir * obj_radius
        self.ball.set_pose(obj_pos, np.zeros(9))

        # Random target placement
        tgt_dir = np.random.uniform(-1, 1, 3)
        tgt_dir /= np.linalg.norm(tgt_dir)
        tgt_radius = np.random.uniform(
            self.min_target_placement_radius, self.max_target_placement_radius
        )
        tgt_pos = zero_offset + tgt_dir * tgt_radius
        self.goal.set_pose(tgt_pos, np.zeros(9))

    def apply_action(self, action):
        for joint, a in zip(self.joints, action):
            torque = np.clip(a, -1.0, 1.0) * 0.05
            joint.motor.tau = torque

    def calc_state(self):
        joint_positions = [joint.qpos for joint in self.joints]
        joint_velocities = [joint.qvel for joint in self.joints]
        state = np.concatenate([joint_positions, joint_velocities])

        fingertip_pos = self.fingertip.xpos
        object_pos = self.ball.xpos
        target_pos = self.goal.xpos

        to_target_vec = target_pos - object_pos

        observation = np.concatenate(
            [state, to_target_vec, fingertip_pos, object_pos, target_pos]
        )
        return observation
