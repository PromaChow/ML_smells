import os
import shutil
import tempfile
import unittest
import logging
import random

import numpy as np
import torch
import gym
from chainerrl.agents import dqn
from chainerrl.training import train_agent_with_evaluation, train_agent_batch_with_evaluation
from chainerrl.utils import batch_run_evaluation_episodes
from chainerrl.replay_buffer import ReplayBuffer
from chainerrl.env_wrappers import ParallelEnvWrapper
from chainerrl import envs

logging.basicConfig(level=logging.DEBUG)
log = logging.getLogger(__name__)

class BaseAgentTest(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.successful_return = 200  # default success threshold
        random.seed(1)
        np.random.seed(1)
        torch.manual_seed(1)

    def tearDown(self):
        shutil.rmtree(self.tmpdir)

    def make_agent(self, env):
        """Subclasses should override this to return an agent instance."""
        raise NotImplementedError

    def make_env_and_successful_return(self):
        """Subclasses should override this to return (train_env, test_env, success_score)."""
        raise NotImplementedError

    def _train_and_evaluate(
        self,
        steps=5000,
        load_model=False,
        require_success=True,
        gpu=False,
        eval_n_episodes=5,
        eval_interval=200,
    ):
        train_env, test_env, self.successful_return = self.make_env_and_successful_return()
        if gpu and torch.cuda.is_available():
            device = torch.device("cuda")
        else:
            device = torch.device("cpu")

        agent = self.make_agent(train_env)
        if load_model:
            agent.load(os.path.join(self.tmpdir, "agent.pkl"))
            agent.replay_buffer.load(os.path.join(self.tmpdir, "buffer.pkl"))

        train_agent_with_evaluation(
            agent=agent,
            env=train_env,
            steps=steps,
            outdir=self.tmpdir,
            eval_interval=eval_interval,
            eval_n_episodes=eval_n_episodes,
            successful_score=self.successful_return,
        )

        for _ in range(eval_n_episodes):
            obs = test_env.reset()
            done = False
            total_reward = 0.0
            while not done:
                action = agent.act(obs)
                obs, reward, done, _ = test_env.step(action)
                total_reward += reward
            if require_success:
                self.assertAlmostEqual(total_reward, self.successful_return, delta=1.0)

        agent.save(os.path.join(self.tmpdir, "agent.pkl"))
        agent.replay_buffer.save(os.path.join(self.tmpdir, "buffer.pkl"))

    def _batch_train_and_evaluate(
        self,
        steps=5000,
        load_model=False,
        require_success=True,
        gpu=False,
        eval_n_episodes=5,
        eval_interval=200,
    ):
        train_env, test_env, self.successful_return = self.make_env_and_successful_return()
        if gpu and torch.cuda.is_available():
            device = torch.device("cuda")
        else:
            device = torch.device("cpu")

        agent = self.make_agent(train_env)
        if load_model:
            agent.load(os.path.join(self.tmpdir, "agent.pkl"))
            agent.replay_buffer.load(os.path.join(self.tmpdir, "buffer.pkl"))

        env = ParallelEnvWrapper([train_env for _ in range(2)])
        train_agent_batch_with_evaluation(
            agent=agent,
            env=env,
            steps=steps,
            outdir=self.tmpdir,
            eval_interval=eval_interval,
            eval_n_episodes=eval_n_episodes,
            successful_score=self.successful_return,
        )

        successes, total_rewards = batch_run_evaluation_episodes(
            agent, test_env, n=eval_n_episodes
        )
        if require_success:
            self.assertGreaterEqual(successes, eval_n_episodes)
            for r in total_rewards:
                self.assertAlmostEqual(r, self.successful_return, delta=1.0)

        agent.save(os.path.join(self.tmpdir, "agent.pkl"))
        agent.replay_buffer.save(os.path.join(self.tmpdir, "buffer.pkl"))


class CartPoleDQNTest(BaseAgentTest):
    def make_agent(self, env):
        model = torch.nn.Sequential(
            torch.nn.Linear(env.observation_space.shape[0], 128),
            torch.nn.ReLU(),
            torch.nn.Linear(128, env.action_space.n),
        )
        agent = dqn.DQN(
            model,
            env.action_space,
            replay_buffer=ReplayBuffer(capacity=10000),
            optimizer=torch.optim.Adam,
            gamma=0.99,
            epsilon_start=1.0,
            epsilon_end=0.01,
            epsilon_decay_steps=5000,
            batch_size=32,
            target_update_interval=100,
        )
        return agent

    def make_env_and_successful_return(self):
        train_env = gym.make("CartPole-v1")
        test_env = gym.make("CartPole-v1")
        return train_env, test_env, 200

    def test_training_gpu(self):
        if not torch.cuda.is_available():
            self.skipTest("CUDA not available")
        self._train_and_evaluate(steps=100000, gpu=True)

    def test_training_cpu(self):
        self._train_and_evaluate(steps=100000, gpu=False)

    def test_training_gpu_fast(self):
        if not torch.cuda.is_available():
            self.skipTest("CUDA not available")
        self._train_and_evaluate(steps=10, gpu=True, require_success=False)

    def test_training_cpu_fast(self):
        self._train_and_evaluate(steps=10, gpu=False, require_success=False)

    def test_load_model_gpu(self):
        if not torch.cuda.is_available():
            self.skipTest("CUDA not available")
        # Train first
        self._train_and_evaluate(steps=100000, gpu=True)
        # Load and evaluate with 0 steps
        self._train_and_evaluate(steps=0, load_model=True, gpu=True)

    def test_load_model_cpu(self):
        self._train_and_evaluate(steps=100000, gpu=False)
        self._train_and_evaluate(steps=0, load_model=True, gpu=False)

    def test_batch_training_gpu(self):
        if not torch.cuda.is_available():
            self.skipTest("CUDA not available")
        self._batch_train_and_evaluate(steps=100000, gpu=True)

    def test_batch_training_cpu(self):
        self._batch_train_and_evaluate(steps=100000, gpu=False)

    def test_batch_training_gpu_fast(self):
        if not torch.cuda.is_available():
            self.skipTest("CUDA not available")
        self._batch_train_and_evaluate(steps=10, gpu=True, require_success=False)

    def test_batch_training_cpu_fast(self):
        self._batch_train_and_evaluate(steps=10, gpu=False, require_success=False)

    def test_batch_load_model_gpu(self):
        if not torch.cuda.is_available():
            self.skipTest("CUDA not available")
        self._batch_train_and_evaluate(steps=100000, gpu=True)
        self._batch_train_and_evaluate(steps=0, load_model=True, gpu=True)

    def test_batch_load_model_cpu(self):
        self._batch_train_and_evaluate(steps=100000, gpu=False)
        self._batch_train_and_evaluate(steps=0, load_model=True, gpu=False)


if __name__ == "__main__":
    unittest.main()