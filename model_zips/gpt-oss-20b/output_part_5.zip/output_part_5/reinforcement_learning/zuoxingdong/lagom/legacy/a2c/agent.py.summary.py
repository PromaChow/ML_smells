import gym
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Categorical, Normal
from dataclasses import dataclass, field
from typing import Optional, Dict, Any, Tuple


# --------------------------------------------------------------------------- #
# Configuration
# --------------------------------------------------------------------------- #
@dataclass
class A2CConfig:
    obs_dim: int
    action_dim: int
    action_type: str  # 'discrete' or 'continuous'
    hidden_sizes: Tuple[int, ...] = (256, 256)
    lr_policy: float = 2.5e-4
    lr_value: float = 2.5e-4
    gamma: float = 0.99
    gae_lambda: float = 0.95
    value_loss_coef: float = 0.5
    entropy_coef: float = 0.01
    max_grad_norm: float = 0.5
    standardize_returns: bool = True
    standardize_advantages: bool = True
    independent_value: bool = False
    use_lr_scheduler: bool = True
    schedule_start: int = 0
    schedule_end: int = 1_000_000
    device: torch.device = field(default_factory=lambda: torch.device("cpu"))


# --------------------------------------------------------------------------- #
# Utility Functions
# --------------------------------------------------------------------------- #
def orthogonal_init(m: nn.Module):
    if isinstance(m, nn.Linear):
        nn.init.orthogonal_(m.weight, np.sqrt(2))
        if m.bias is not None:
            nn.init.constant_(m.bias, 0.0)


def linear_schedule(start: float, end: float, step: int, max_step: int) -> float:
    progress = min(step / max_step, 1.0)
    return start + (end - start) * (1.0 - progress)


def standardize(x: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
    mean = x.mean()
    std = x.std() + eps
    return (x - mean) / std


def explained_variance(y: torch.Tensor, y_pred: torch.Tensor) -> float:
    var_y = torch.var(y)
    var_error = torch.var(y - y_pred)
    if var_y.item() == 0:
        return 1.0
    return 1.0 - var_error / var_y


# --------------------------------------------------------------------------- #
# Neural Network Modules
# --------------------------------------------------------------------------- #
class MLP(nn.Module):
    def __init__(self, input_dim: int, hidden_sizes: Tuple[int, ...]):
        super().__init__()
        layers = []
        in_dim = input_dim
        for h in hidden_sizes:
            layers.append(nn.Linear(in_dim, h))
            layers.append(nn.LayerNorm(h))
            layers.append(nn.CELU())
            in_dim = h
        self.net = nn.Sequential(*layers)
        self.apply(orthogonal_init)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class StateValueHead(nn.Module):
    def __init__(self, input_dim: int):
        super().__init__()
        self.fc = nn.Linear(input_dim, 1)
        nn.init.orthogonal_(self.fc.weight, 1.0)
        nn.init.constant_(self.fc.bias, 0.0)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.fc(x).squeeze(-1)


class PolicyHead(nn.Module):
    def __init__(self, input_dim: int, action_dim: int, action_type: str):
        super().__init__()
        self.action_type = action_type
        if action_type == 'discrete':
            self.fc = nn.Linear(input_dim, action_dim)
            nn.init.orthogonal_(self.fc.weight, 0.01)
            nn.init.constant_(self.fc.bias, 0.0)
        else:  # continuous
            self.mean_fc = nn.Linear(input_dim, action_dim)
            self.log_std_fc = nn.Linear(input_dim, action_dim)
            nn.init.orthogonal_(self.mean_fc.weight, 0.01)
            nn.init.constant_(self.mean_fc.bias, 0.0)
            nn.init.orthogonal_(self.log_std_fc.weight, 0.01)
            nn.init.constant_(self.log_std_fc.bias, 0.0)

    def forward(self, x: torch.Tensor) -> Any:
        if self.action_type == 'discrete':
            logits = self.fc(x)
            dist = Categorical(logits=logits)
            return dist
        else:
            mean = self.mean_fc(x)
            log_std = self.log_std_fc(x)
            std = torch.exp(log_std)
            dist = Normal(mean, std)
            return dist


# --------------------------------------------------------------------------- #
# Policy and Critic Networks
# --------------------------------------------------------------------------- #
class PolicyNetwork(nn.Module):
    def __init__(self, obs_dim: int, action_dim: int, action_type: str,
                 hidden_sizes: Tuple[int, ...], independent_value: bool):
        super().__init__()
        self.mlp = MLP(obs_dim, hidden_sizes)
        self.action_head = PolicyHead(obs_dim, action_dim, action_type)
        self.independent_value = independent_value
        if independent_value:
            self.value_head = StateValueHead(obs_dim)
        self.apply(orthogonal_init)

    def forward(self, obs: torch.Tensor) -> Tuple[Any, torch.Tensor]:
        features = self.mlp(obs)
        dist = self.action_head(features)
        if self.independent_value:
            value = self.value_head(features)
        else:
            value = None
        return dist, value


class CriticNetwork(nn.Module):
    def __init__(self, obs_dim: int, hidden_sizes: Tuple[int, ...]):
        super().__init__()
        self.mlp = MLP(obs_dim, hidden_sizes)
        self.value_head = StateValueHead(obs_dim)
        self.apply(orthogonal_init)

    def forward(self, obs: torch.Tensor) -> torch.Tensor:
        features = self.mlp(obs)
        value = self.value_head(features)
        return value


# --------------------------------------------------------------------------- #
# Agent
# --------------------------------------------------------------------------- #
class A2CAgent:
    def __init__(self, env: gym.Env, config: A2CConfig):
        self.env = env
        self.config = config
        self.device = config.device

        obs_dim = env.observation_space.shape[0]
        if isinstance(env.action_space, gym.spaces.Discrete):
            action_dim = env.action_space.n
            action_type = 'discrete'
        else:
            action_dim = env.action_space.shape[0]
            action_type = 'continuous'

        # Policy network
        self.policy = PolicyNetwork(obs_dim, action_dim, action_type,
                                    config.hidden_sizes, config.independent_value).to(self.device)
        # Critic network
        if config.independent_value:
            self.critic = CriticNetwork(obs_dim, config.hidden_sizes).to(self.device)
        else:
            self.critic = None

        # Optimizers
        self.optimizer_policy = torch.optim.Adam(self.policy.parameters(),
                                                 lr=config.lr_policy)
        if self.critic is not None:
            self.optimizer_value = torch.optim.Adam(self.critic.parameters(),
                                                    lr=config.lr_value)
        else:
            self.optimizer_value = None

        # Learning rate schedulers
        if config.use_lr_scheduler:
            self.lr_scheduler_policy = torch.optim.lr_scheduler.LambdaLR(
                self.optimizer_policy,
                lr_lambda=lambda step: linear_schedule(config.lr_policy,
                                                       config.lr_policy * 0.1,
                                                       step, config.schedule_end))
            if self.critic is not None:
                self.lr_scheduler_value = torch.optim.lr_scheduler.LambdaLR(
                    self.optimizer_value,
                    lr_lambda=lambda step: linear_schedule(config.lr_value,
                                                           config.lr_value * 0.1,
                                                           step, config.schedule_end))
        else:
            self.lr_scheduler_policy = None
            self.lr_scheduler_value = None

        self.total_timesteps = 0

    def select_action(self, obs: np.ndarray, training: bool = True) -> Tuple[np.ndarray, float, float, float]:
        obs_t = torch.from_numpy(obs).float().unsqueeze(0).to(self.device)
        dist, value = self.policy(obs_t)
        if training:
            action = dist.sample()
            log_prob = dist.log_prob(action).detach().cpu().numpy()[0]
            entropy = dist.entropy().detach().cpu().numpy()[0]
        else:
            action = dist.mode() if hasattr(dist, 'mode') else dist.mean
            log_prob = dist.log_prob(action).detach().cpu().numpy()[0]
            entropy = dist.entropy().detach().cpu().numpy()[0]
        if value is not None:
            value_np = value.detach().cpu().numpy()[0]
        else:
            value_np = self.critic(obs_t).detach().cpu().numpy()[0]
        return action.cpu().numpy(), log_prob, entropy, value_np

    def compute_gae(self,
                    rewards: torch.Tensor,
                    dones: torch.Tensor,
                    values: torch.Tensor,
                    last_value: torch.Tensor,
                    next_done: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        batch_size = rewards.size(0)
        advantages = torch.zeros_like(rewards, device=self.device)
        gae = 0.0
        for step in reversed(range(batch_size)):
            mask = 1.0 - dones[step]
            delta = rewards[step] + self.config.gamma * last_value * mask - values[step]
            gae = delta + self.config.gamma * self.config.gae_lambda * mask * gae
            advantages[step] = gae
            last_value = values[step]
        returns = advantages + values
        if self.config.standardize_advantages:
            advantages = standardize(advantages)
        if self.config.standardize_returns:
            returns = standardize(returns)
        return returns, advantages

    def train_step(self, batch: Dict[str, torch.Tensor]) -> Dict[str, Any]:
        obs = batch['obs'].to(self.device)
        actions = batch['actions'].to(self.device)
        rewards = batch['rewards'].to(self.device)
        dones = batch['dones'].to(self.device)

        dist, policy_value = self.policy(obs)
        if self.critic is not None:
            value = self.critic(obs)
        else:
            value = policy_value

        log_probs = dist.log_prob(actions).unsqueeze(-1)
        entropy = dist.entropy().unsqueeze(-1)

        with torch.no_grad():
            next_obs = batch['next_obs'].to(self.device)
            if self.critic is not None:
                next_value = self.critic(next_obs)
            else:
                next_dist, next_policy_value = self.policy(next_obs)
                next_value = next_policy_value

            next_value = next_value * (1.0 - dones)
            returns, advantages = self.compute_gae(rewards, dones, value, next_value, dones)

        # Losses
        policy_loss = -(log_probs * advantages.detach()).mean()
        value_loss = F.mse_loss(value, returns.detach())
        entropy_loss = -(entropy.mean())

        total_loss = (policy_loss +
                      self.config.value_loss_coef * value_loss +
                      self.config.entropy_coef * entropy_loss)

        # Backprop
        self.optimizer_policy.zero_grad()
        if self.optimizer_value is not None:
            self.optimizer_value.zero_grad()
        total_loss.backward()

        if self.config.max_grad_norm > 0:
            nn.utils.clip_grad_norm_(self.policy.parameters(), self.config.max_grad_norm)
            if self.critic is not None:
                nn.utils.clip_grad_norm_(self.critic.parameters(), self.config.max_grad_norm)

        self.optimizer_policy.step()
        if self.optimizer_value is not None:
            self.optimizer_value.step()

        if self.lr_scheduler_policy is not None:
            self.lr_scheduler_policy.step()
        if self.lr_scheduler_value is not None:
            self.lr_scheduler_value.step()

        self.total_timesteps += rewards.numel()

        metrics = {
            'policy_loss': policy_loss.item(),
            'value_loss': value_loss.item(),
            'entropy_loss': entropy_loss.item(),
            'total_loss': total_loss.item(),
            'policy_entropy': entropy.mean().item(),
            'explained_variance': explained_variance(returns, value).item(),
            'lr_policy': self.optimizer_policy.param_groups[0]['lr'],
            'lr_value': self.optimizer_value.param_groups[0]['lr'] if self.optimizer_value else None,
            'total_timesteps': self.total_timesteps
        }
        return metrics

# --------------------------------------------------------------------------- #
# Example training loop (placeholder)
# --------------------------------------------------------------------------- #
def main():
    env = gym.make("CartPole-v1")
    obs_dim = env.observation_space.shape[0]
    if isinstance(env.action_space, gym.spaces.Discrete):
        action_dim = env.action_space.n
    else:
        action_dim = env.action_space.shape[0]
    config = A2CConfig(
        obs_dim=obs_dim,
        action_dim=action_dim,
        action_type='discrete' if isinstance(env.action_space, gym.spaces.Discrete) else 'continuous',
        device=torch.device("cpu")
    )
    agent = A2CAgent(env, config)

    # Placeholder loop
    num_iterations = 10
    for _ in range(num_iterations):
        obs = env.reset()
        done = False
        batch = {'obs': [], 'actions': [], 'rewards': [], 'dones': [], 'next_obs': []}
        while not done:
            action, logp, entropy, value = agent.select_action(obs, training=True)
            next_obs, reward, done, _ = env.step(action)
            batch['obs'].append(obs)
            batch['actions'].append(action)
            batch['rewards'].append(reward)
            batch['dones'].append(float(done))
            batch['next_obs'].append(next_obs)
            obs = next_obs
        # Convert to tensors
        batch_tensors = {
            'obs': torch.tensor(batch['obs'], dtype=torch.float32),
            'actions': torch.tensor(batch['actions'], dtype=torch.long if config.action_type == 'discrete' else torch.float32),
            'rewards': torch.tensor(batch['rewards'], dtype=torch.float32),
            'dones': torch.tensor(batch['dones'], dtype=torch.float32),
            'next_obs': torch.tensor(batch['next_obs'], dtype=torch.float32)
        }
        metrics = agent.train_step(batch_tensors)
        print(metrics)

if __name__ == "__main__":
    main()