import numpy as np
from typing import Any

# Placeholder imports for the base classes.
# Replace `some_module` with the actual module path where WalkerBase and MJCFBasedRobot are defined.
from some_module import WalkerBase, MJCFBasedRobot


class Hopper(WalkerBase, MJCFBasedRobot):
    """MuJoCo-based hopper robot for locomotion experiments."""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        """
        Initialize the Hopper robot.

        Parameters
        ----------
        *args, **kwargs
            Additional arguments forwarded to the base classes.
        """
        # Initialize WalkerBase with a specific motor power.
        WalkerBase.__init__(self, power=0.75, *args, **kwargs)

        # Initialize MJCFBasedRobot with the hopper model file and configuration.
        MJCFBasedRobot.__init__(
            self,
            model_file="hopper.xml",
            reference_body="torso",
            action_dim=3,
            obs_dim=11,
            add_ignored_joints=True,
            *args,
            **kwargs,
        )

        # Track the horizontal position of the hopper for potential calculation.
        self.pos_after: float = 0.0

    def calc_state(self) -> np.ndarray:
        """
        Compute the current observation state of the hopper.

        Returns
        -------
        np.ndarray
            Concatenated array of joint positions (excluding the root) and clipped joint velocities.
        """
        # Extract joint positions and velocities from ordered_joints.
        qpos = np.array([joint.qpos for joint in self.ordered_joints])
        qvel = np.array([joint.qvel for joint in self.ordered_joints])

        # Clip velocities to the range [-10, 10].
        qvel_clipped = np.clip(qvel, -10.0, 10.0)

        # Concatenate positions (excluding the first root element) and velocities.
        state = np.concatenate([qpos.flat[1:], qvel_clipped.flat])

        return state

    def calc_potential(self) -> float:
        """
        Calculate the hopper's potential based on horizontal progress.

        Returns
        -------
        float
            The potential value computed as the normalized horizontal displacement per time step.
        """
        # Store the previous horizontal position.
        pos_before = self.pos_after

        # Retrieve the current x-coordinate of the torso.
        torso_pose = self.robot_body.get_pose()
        self.pos_after = torso_pose[0]  # assuming the first element is the x-coordinate

        # Compute potential as horizontal displacement per simulation time step.
        potential = (self.pos_after - pos_before) / self.scene.dt

        # Debug mode (commented out):
        # if self.debug:
        #     print(f"dt: {self.scene.dt}, frame_skip: {self.scene.frame_skip}")

        return potential
