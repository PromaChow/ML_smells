import copy
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.utils import clip_grad_norm_
from typing import Any, Dict, Optional


class QLearner:
    def __init__(self, mac: Any, scheme: Any, logger: Optional[Any], args: Any) -> None:
        self.mac = mac
        self.scheme = scheme
        self.logger = logger
        self.args = args

        # Assume MAC has a mixer attribute if using QTranBase
        self.mixer = getattr(mac, "mixer", None)
        self.target_mixer = copy.deepcopy(self.mixer) if self.mixer is not None else None
        self.target_mac = copy.deepcopy(mac)

        params = list(self.mac.parameters())
        if self.mixer is not None:
            params += list(self.mixer.parameters())
        self.optimizer = torch.optim.RMSprop(
            params,
            lr=args.lr,
            alpha=args.alpha,
            eps=args.eps,
            weight_decay=args.weight_decay,
        )

        self.step = 0
        self.last_target_update = 0

    def train(self, batch: Dict[str, torch.Tensor]) -> float:
        device = next(self.mac.parameters()).device

        rewards = batch["rewards"].to(device)          # [B, T]
        actions = batch["actions"].to(device)          # [B, T, N]
        terminated = batch["terminated"].to(device)    # [B, T]
        avail_actions = batch["avail_actions"].to(device)  # [B, T, N, A]
        mask = batch["mask"].to(device)                # [B, T]

        batch_size = batch["batch_size"]
        seq_len = rewards.size(1)
        n_agents = actions.size(-1)

        # ---- Current Q-values ----
        hidden = self.mac.init_hidden(batch_size)
        q_all = []
        for t in range(seq_len):
            q, hidden = self.mac(batch, t, hidden)
            q_all.append(q)
        q_all = torch.stack(q_all, dim=1)  # [B, T, N, A]

        # Mask unavailable actions
        q_all_masked = q_all.clone()
        q_all_masked[~avail_actions] = -9999999

        q_max_actions = q_all_masked.argmax(dim=-1)  # [B, T, N]

        # ---- Target Q-values ----
        hidden_t = self.target_mac.init_hidden(batch_size)
        q_target_all = []
        for t in range(seq_len):
            q_t, hidden_t = self.target_mac(batch, t, hidden_t)
            q_target_all.append(q_t)
        q_target_all = torch.stack(q_target_all, dim=1)  # [B, T, N, A]

        q_target_all_masked = q_target_all.clone()
        q_target_all_masked[~avail_actions] = -9999999

        q_target_max_actions = q_target_all_masked.argmax(dim=-1)  # [B, T, N]

        # Gather selected Q-values
        q_selected = q_all.gather(-1, actions.unsqueeze(-1)).squeeze(-1)          # [B, T, N]
        q_target_selected = q_target_all.gather(-1, q_target_max_actions.unsqueeze(-1)).squeeze(-1)  # [B, T, N]

        # Joint Q-values via mixer
        if self.mixer is not None:
            joint_q_current, vs = self.mixer(q_selected, avail_actions)
            joint_q_target, _ = self.target_mixer(q_target_selected, avail_actions)
        else:
            joint_q_current = q_selected.sum(-1)
            joint_q_target = q_target_selected.sum(-1)
            vs = torch.zeros_like(joint_q_current)

        # ---- Losses ----
        gamma = self.args.gamma
        terminated_mask = 1.0 - terminated.float()
        td_target = rewards + gamma * terminated_mask * joint_q_target
        td_error = joint_q_current - td_target

        mask_valid = mask * terminated_mask  # [B, T]
        mask_valid = mask_valid.unsqueeze(-1)  # [B, T, 1] for broadcasting

        loss_td = (td_error.pow(2) * mask_valid).sum() / mask_valid.sum()

        # Opt loss
        max_q_each = q_all_masked.max(dim=-1).values  # [B, T, N]
        sum_max_q = max_q_each.sum(dim=-1)  # [B, T]
        q_selected_max = q_all.gather(-1, q_max_actions.unsqueeze(-1)).squeeze(-1)  # [B, T, N]
        joint_q_max, vs_opt = self.mixer(q_selected_max, avail_actions)
        error_opt = sum_max_q - joint_q_max + vs_opt
        loss_opt = (error_opt.pow(2) * mask_valid.squeeze(-1)).sum() / mask_valid.sum()

        # Nopt loss
        sum_chosen_q = q_selected.sum(dim=-1)  # [B, T]
        error_nopt = sum_chosen_q - joint_q_current + vs
        error_nopt_clamped = torch.clamp(error_nopt, min=0.0)
        loss_nopt = (error_nopt_clamped.pow(2) * mask_valid.squeeze(-1)).sum() / mask_valid.sum()

        total_loss = (
            loss_td
            + self.args.opt_loss * loss_opt
            + self.args.nopt_min_loss * loss_nopt
        )

        # ---- Optimization ----
        self.optimizer.zero_grad()
        total_loss.backward()
        clip_grad_norm_(self.mac.parameters(), self.args.grad_clip)
        if self.mixer is not None:
            clip_grad_norm_(self.mixer.parameters(), self.args.grad_clip)
        self.optimizer.step()

        # ---- Target network update ----
        self.step += 1
        if self.step % self.args.target_update_interval == 0:
            self.target_mac = copy.deepcopy(self.mac)
            self.target_mixer = copy.deepcopy(self.mixer)
            self.last_target_update = self.step

        # ---- Logging ----
        if self.logger is not None:
            grad_norm = torch.sqrt(
                sum(p.grad.data.norm() ** 2 for p in self.mac.parameters() if p.grad is not None)
            )
            self.logger.info(
                f"Step: {self.step}, Total Loss: {total_loss.item():.4f}, "
                f"TD Loss: {loss_td.item():.4f}, Opt Loss: {loss_opt.item():.4f}, "
                f"Nopt Loss: {loss_nopt.item():.4f}, Grad Norm: {grad_norm.item():.4f}"
            )

        return total_loss.item()
