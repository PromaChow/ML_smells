import numpy as np
from typing import Iterable, Tuple, List

def interp_curves(curves: Iterable[Tuple[np.ndarray, np.ndarray]]) -> Tuple[np.ndarray, np.ndarray]:
    """
    Interpolates a batch of discrete (x, y) curves onto a shared x-axis.

    Parameters
    ----------
    curves : iterable of (x, y) tuples
        Each tuple contains two 1-D numpy arrays of equal length representing the
        x and y coordinates of a curve. The x arrays are expected to be sorted
        in ascending order.

    Returns
    -------
    new_x : np.ndarray
        1-D array of sorted unique x-values common to all curves.
    ys : np.ndarray
        2-D array where each row corresponds to the interpolated y-values of a
        curve evaluated at the points in `new_x`. The shape is
        (len(curves), len(new_x)).
    """
    # Extract all x-values from the curves and create a sorted unique array
    all_x = np.hstack([x for x, _ in curves])
    new_x = np.unique(all_x)

    # Interpolate each curve onto the new_x axis
    interpolated: List[np.ndarray] = []
    for x, y in curves:
        if x.ndim != 1 or y.ndim != 1:
            raise ValueError("x and y must be 1-D arrays.")
        if x.size != y.size:
            raise ValueError("x and y must have the same length.")
        # Ensure x is sorted (np.interp requires sorted x)
        if not np.all(np.diff(x) >= 0):
            sort_idx = np.argsort(x)
            x_sorted = x[sort_idx]
            y_sorted = y[sort_idx]
        else:
            x_sorted, y_sorted = x, y
        y_interp = np.interp(new_x, x_sorted, y_sorted)
        interpolated.append(y_interp)

    ys = np.vstack(interpolated)
    return new_x, ys

# Example usage:
# curves = [
#     (np.array([0, 1, 2]), np.array([0, 1, 0])),
#     (np.array([0.5, 1.5, 2.5]), np.array([1, 0, 1]))
# ]
# new_x, ys = interp_curves(curves)