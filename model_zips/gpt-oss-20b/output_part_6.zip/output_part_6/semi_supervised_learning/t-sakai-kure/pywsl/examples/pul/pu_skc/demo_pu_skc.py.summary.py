import numpy as np
from pumil.datasets import gen_twonorm_pumil
from pumil import PUMIL_SL
from pumil.metrics import bin_clf_err
from sklearn.model_selection import GridSearchCV

# Data Generation
n_p = 30
n_u = 200
prior_u = 0.5
n_t = 100
x, y, x_t, y_t = gen_twonorm_pumil(n_p=n_p, n_u=n_u, prior_u=prior_u, n_t=n_t, random_state=42)

# Parameter Configuration
param_grid = {
    'prior': [0.5],
    'lam': np.logspace(-3, 1, 5),
    'basis': ['minimax']
}

# Model Training
estimator = PUMIL_SL()
grid = GridSearchCV(estimator, param_grid, cv=5, n_jobs=-1)
grid.fit(x, y)

# Prediction and Evaluation
y_pred = grid.best_estimator_.predict(x_t)
error_rate = bin_clf_err(y_t, y_pred, prior=0.5) * 100
print(f"Classification error rate: {error_rate:.2f}%")