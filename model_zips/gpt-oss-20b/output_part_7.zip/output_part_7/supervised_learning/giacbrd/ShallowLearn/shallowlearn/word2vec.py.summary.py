import numpy as np
import random
import collections
from typing import List, Dict, Tuple

def custom_hash(word: str, bucket: int) -> int:
    return hash(word) % bucket

class HuffmanNode:
    def __init__(self, freq: int, index: int = None, left=None, right=None):
        self.freq = freq
        self.index = index  # None for internal nodes
        self.left = left
        self.right = right
        self.parent = None
        self.code = []

class LabeledWord2Vec:
    def __init__(
        self,
        size: int = 100,
        window: int = 5,
        min_count: int = 5,
        negative: int = 5,
        hs: int = 0,
        bucket: int = 0,
        alpha: float = 0.025,
        min_alpha: float = 0.0001,
        iter: int = 5,
        seed: int = 1,
        loss: str = "softmax",
    ):
        self.size = size
        self.window = window
        self.min_count = min_count
        self.negative = negative
        self.hs = hs
        self.bucket = bucket
        self.alpha = alpha
        self.min_alpha = min_alpha
        self.iter = iter
        self.seed = seed
        self.loss = loss
        self.sg = 0  # CBOW

        # vocabularies
        self.wv: Dict[str, int] = {}
        self.wv_counts: Dict[str, int] = {}
        self.wv_index2word: List[str] = []
        self.lvocab: Dict[str, int] = {}
        self.lvocab_counts: Dict[str, int] = {}
        self.lvocab_index2label: List[str] = []

        # weights
        self.input_weights: np.ndarray = None  # vocab_size x size
        self.output_weights: np.ndarray = None  # vocab_size x size for softmax
        self.label_output_weights: np.ndarray = None  # label_size x size for softmax

        # hierarchical softmax structures
        self.tree_nodes: List[HuffmanNode] = []
        self.label_codes: Dict[int, List[int]] = {}
        self.label_points: Dict[int, List[int]] = {}

        # negative sampling table
        self.neg_sampling_table: np.ndarray = None

    def build_vocab(self, sentences: List[List[str]]):
        word_counts = collections.Counter()
        for sent in sentences:
            for word in sent:
                word_counts[word] += 1
        # Apply min_count
        word_counts = {
            w: c for w, c in word_counts.items() if c >= self.min_count
        }
        # Hashing if bucket > 0
        if self.bucket > 0:
            hashed_counts = collections.Counter()
            for w, c in word_counts.items():
                h = custom_hash(w, self.bucket)
                hashed_counts[h] += c
            word_counts = hashed_counts
        # Build vocab dict
        self.wv = {}
        self.wv_counts = {}
        self.wv_index2word = []
        for idx, (word, count) in enumerate(word_counts.items()):
            self.wv[word] = idx
            self.wv_counts[word] = count
            self.wv_index2word.append(word)

    def build_lvocab(self, labels: List[List[str]]):
        label_counts = collections.Counter()
        for label_list in labels:
            for label in label_list:
                label_counts[label] += 1
        # Apply min_count to labels as well
        label_counts = {
            l: c for l, c in label_counts.items() if c >= self.min_count
        }
        self.lvocab = {}
        self.lvocab_counts = {}
        self.lvocab_index2label = []
        for idx, (label, count) in enumerate(label_counts.items()):
            self.lvocab[label] = idx
            self.lvocab_counts[label] = count
            self.lvocab_index2label.append(label)

    def finalize_vocab(self):
        vocab_size = len(self.wv_index2word)
        self.input_weights = np.random.uniform(
            low=-0.5 / self.size,
            high=0.5 / self.size,
            size=(vocab_size, self.size),
        )
        if self.loss == "softmax":
            self.output_weights = np.random.uniform(
                low=-0.5 / self.size,
                high=0.5 / self.size,
                size=(vocab_size, self.size),
            )
        elif self.loss == "hs":
            self._build_huffman_tree()
        if self.loss in ("softmax", "hs"):
            label_size = len(self.lvocab_index2label)
            self.label_output_weights = np.random.uniform(
                low=-0.5 / self.size,
                high=0.5 / self.size,
                size=(label_size, self.size),
            )
        if self.loss == "ns":
            self._build_neg_sampling_table()

    def _build_neg_sampling_table(self):
        vocab_size = len(self.wv_index2word)
        pow_counts = np.array(
            [self.wv_counts[w] ** 0.75 for w in self.wv_index2word]
        )
        vocab_sum = np.sum(pow_counts)
        prob_table = pow_counts / vocab_sum
        table_size = int(1e8)
        table = np.zeros(table_size, dtype=np.int32)
        p = 0.0
        cumulative = prob_table[0]
        for i in range(table_size):
            while p > cumulative:
                p += prob_table[0]
                cumulative += prob_table[0]
            table[i] = i
        self.neg_sampling_table = table

    def _build_huffman_tree(self):
        vocab_size = len(self.wv_index2word)
        frequencies = [self.wv_counts[w] for w in self.wv_index2word]
        nodes = [HuffmanNode(freq=f) for f in frequencies]
        internal_idx = vocab_size
        while len(nodes) > 1:
            nodes.sort(key=lambda x: x.freq)
            left = nodes.pop(0)
            right = nodes.pop(0)
            parent = HuffmanNode(freq=left.freq + right.freq, left=left, right=right)
            left.parent = parent
            right.parent = parent
            nodes.append(parent)
        self.tree_nodes = nodes
        # assign codes
        for idx, node in enumerate(self.tree_nodes[0].left, 0):
            pass
        # For simplicity, we skip full code assignment

    def reset_weights(self):
        self.finalize_vocab()

    def update_weights(self, new_words: List[str], new_labels: List[str]):
        # Not fully implemented; placeholder
        pass

    def train(self, sentences: List[List[str]], labels: List[List[str]]):
        self.train_batch_labeled_cbow(sentences, labels)

    def train_batch_labeled_cbow(self, sentences: List[List[str]], labels: List[List[str]]):
        alpha = self.alpha
        for epoch in range(self.iter):
            for sent, label_list in zip(sentences, labels):
                sent_indices = [self.wv.get(w, None) for w in sent]
                sent_indices = [i for i in sent_indices if i is not None]
                label_indices = [self.lvocab.get(l, None) for l in label_list]
                label_indices = [i for i in label_indices if i is not None]
                for pos in range(len(sent_indices)):
                    window_start = max(0, pos - self.window)
                    window_end = min(len(sent_indices), pos + self.window + 1)
                    context = [
                        sent_indices[i]
                        for i in range(window_start, window_end)
                        if i != pos
                    ]
                    if not context:
                        continue
                    hidden = np.mean(self.input_weights[context], axis=0)
                    for label_idx in label_indices:
                        if self.loss == "softmax":
                            output = self.label_output_weights[label_idx]
                            pred = np.dot(hidden, output)
                            exp_pred = np.exp(pred)
                            denom = np.sum(np.exp(self.label_output_weights @ hidden))
                            grad = (exp_pred / denom - 1.0) * hidden
                            self.label_output_weights[label_idx] -= alpha * grad
                            for ctx_idx in context:
                                self.input_weights[ctx_idx] -= alpha * grad
                        elif self.loss == "ns":
                            # positive
                            output = self.label_output_weights[label_idx]
                            pred = np.dot(hidden, output)
                            sigmoid_pos = 1.0 / (1.0 + np.exp(-pred))
                            grad_pos = (sigmoid_pos - 1.0) * hidden
                            self.label_output_weights[label_idx] -= alpha * grad_pos
                            for ctx_idx in context:
                                self.input_weights[ctx_idx] -= alpha * grad_pos
                            # negatives
                            for _ in range(self.negative):
                                neg_word_idx = self.neg_sampling_table[
                                    random.randint(0, len(self.neg_sampling_table) - 1)
                                ]
                                neg_output = self.input_weights[neg_word_idx]
                                pred_neg = np.dot(hidden, neg_output)
                                sigmoid_neg = 1.0 / (1.0 + np.exp(-pred_neg))
                                grad_neg = sigmoid_neg * hidden
                                self.input_weights[neg_word_idx] -= alpha * grad_neg
                                for ctx_idx in context:
                                    self.input_weights[ctx_idx] -= alpha * grad_neg
            # decay learning rate
            alpha = max(self.min_alpha, alpha * 0.9)

    def score_document_labeled_cbow(self, sentence: List[str]) -> Dict[str, float]:
        sent_indices = [self.wv.get(w, None) for w in sentence]
        sent_indices = [i for i in sent_indices if i is not None]
        if not sent_indices:
            return {}
        hidden = np.mean(self.input_weights[sent_indices], axis=0)
        scores = {}
        for idx, label in enumerate(self.lvocab_index2label):
            output = self.label_output_weights[idx]
            scores[label] = np.exp(np.dot(hidden, output))
        total = sum(scores.values())
        for k in scores:
            scores[k] /= total
        return scores

    def load_from(self, other: "LabeledWord2Vec"):
        self.size = other.size
        self.window = other.window
        self.min_count = other.min_count
        self.negative = other.negative
        self.hs = other.hs
        self.bucket = other.bucket
        self.alpha = other.alpha
        self.min_alpha = other.min_alpha
        self.iter = other.iter
        self.seed = other.seed
        self.loss = other.loss
        self.wv = other.wv.copy()
        self.wv_counts = other.wv_counts.copy()
        self.wv_index2word = other.wv_index2word.copy()
        self.lvocab = other.lvocab.copy()
        self.lvocab_counts = other.lvocab_counts.copy()
        self.lvocab_index2label = other.lvocab_index2label.copy()
        self.input_weights = np.copy(other.input_weights)
        self.output_weights = np.copy(other.output_weights) if other.output_weights is not None else None
        self.label_output_weights = np.copy(other.label_output_weights)
        self.tree_nodes = other.tree_nodes.copy()
        self.label_codes = other.label_codes.copy()
        self.label_points = other.label_points.copy()
        self.neg_sampling_table = np.copy(other.neg_sampling_table) if other.neg_sampling_table is not None else None

    def score_cbow_labeled_pair(self, sentence: List[str], label: str) -> float:
        if label not in self.lvocab:
            return 0.0
        sent_indices = [self.wv.get(w, None) for w in sentence]
        sent_indices = [i for i in sent_indices if i is not None]
        if not sent_indices:
            return 0.0
        hidden = np.mean(self.input_weights[sent_indices], axis=0)
        idx = self.lvocab[label]
        output = self.label_output_weights[idx]
        return np.exp(np.dot(hidden, output))  # unnormalized probability

if __name__ == "__main__":
    # Example usage
    sentences = [["the", "cat", "sat"], ["the", "dog", "barked"]]
    labels = [["animal"], ["animal"]]
    model = LabeledWord2Vec(size=50, window=2, min_count=1, loss="softmax")
    model.build_vocab(sentences)
    model.build_lvocab(labels)
    model.finalize_vocab()
    model.train(sentences, labels)
    print(model.score_document_labeled_cbow(["the", "cat"]))
    print(model.score_cbow_labeled_pair(["the", "cat"], "animal"))