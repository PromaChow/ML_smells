import random
import numpy as np


class ValueIterator:
    def __init__(self, env, epsilon=0.1, gamma=0.9):
        """
        Parameters
        ----------
        env : gym.Env
            Environment implementing an MDP with transition dictionary `P`.
        epsilon : float
            Exploration coefficient for epsilon-greedy action selection.
        gamma : float
            Discount factor.
        """
        self.env = env
        self.epsilon = epsilon
        self.gamma = gamma

        # Dynamically determine number of states and actions
        self.dynamics_model = env.P
        self.n_states = len(self.dynamics_model)
        # Assume all states have the same number of actions
        first_state = next(iter(self.dynamics_model))
        self.n_actions = len(self.dynamics_model[first_state])

        # Initialize value function to zero
        self.V = np.zeros(self.n_states)

    def _lookahead(self, s):
        """
        Compute Q-values for all actions in state s using the Bellman equation.

        Parameters
        ----------
        s : int
            Current state index.

        Returns
        -------
        np.ndarray
            Q-values for each action in state s.
        """
        Q_values = np.zeros(self.n_actions)
        for a in range(self.n_actions):
            for prob, next_state, reward, done in self.dynamics_model[s][a]:
                Q_values[a] += prob * (reward + self.gamma * self.V[next_state])
        return Q_values

    def get_action(self, s, explore=True):
        """
        Select an action for state s using epsilon-greedy exploration.

        Parameters
        ----------
        s : int
            Current state index.
        explore : bool
            If True, use epsilon-greedy policy; otherwise use greedy policy.

        Returns
        -------
        int
            Selected action index.
        """
        if explore and random.random() < self.epsilon:
            return random.randrange(self.n_actions)

        Q_values = self._lookahead(s)
        return int(np.argmax(Q_values))

    def update(self):
        """
        Perform one full Value Iteration update over all states.
        """
        for s in range(self.n_states):
            Q_values = self._lookahead(s)
            self.V[s] = np.max(Q_values)

    def get_policy(self):
        """
        Extract the greedy policy from the current value function.

        Returns
        -------
        np.ndarray
            Array of actions, one per state.
        """
        policy = np.zeros(self.n_states, dtype=int)
        for s in range(self.n_states):
            Q_values = self._lookahead(s)
            policy[s] = int(np.argmax(Q_values))
        return policy

    def train(self, max_iterations=1000, tolerance=1e-6):
        """
        Run Value Iteration until convergence or until a maximum number of iterations.

        Parameters
        ----------
        max_iterations : int
            Maximum number of iterations to perform.
        tolerance : float
            Convergence threshold based on maximum change in V.
        """
        for _ in range(max_iterations):
            V_prev = self.V.copy()
            self.update()
            delta = np.max(np.abs(self.V - V_prev))
            if delta < tolerance:
                break
        return self.get_policy()
