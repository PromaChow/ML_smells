import numpy as np

def _mu_p(w: np.ndarray, r: np.ndarray) -> float:
    w = np.asarray(w).flatten()
    r = np.asarray(r).flatten()
    assert w.shape == r.shape, "Weights and returns must have the same shape."
    return float(np.dot(w, r))

def _sigma_p(w: np.ndarray, Sigma: np.ndarray) -> float:
    w = np.asarray(w).flatten()
    Sigma = np.asarray(Sigma)
    n = w.shape[0]
    assert Sigma.shape == (n, n), "Covariance matrix must be square with matching dimension."
    return float(np.dot(w, Sigma @ w))

def _trans_costs(w: np.ndarray, w0: np.ndarray, coef: float) -> float:
    w = np.asarray(w).flatten()
    w0 = np.asarray(w0).flatten()
    assert w.shape == w0.shape, "Current and initial weights must have the same shape."
    return float(np.sum(np.abs(w - w0)) * coef)

def risk_aversion(
    w: np.ndarray,
    mu: np.ndarray,
    Sigma: np.ndarray,
    w0: np.ndarray,
    alpha: float,
    beta: float,
) -> float:
    w = np.asarray(w).flatten()
    mu = np.asarray(mu).flatten()
    w0 = np.asarray(w0).flatten()
    assert w.shape == mu.shape == w0.shape, "Weights, returns, and initial weights must have the same dimension."
    n = w.shape[0]
    assert Sigma.shape == (n, n), "Covariance matrix must be square with matching dimension."
    mean = _mu_p(w, mu)
    var = _sigma_p(w, Sigma)
    tc = _trans_costs(w, w0, beta)
    return -(mean - alpha * var - tc)

def sharpe_ratio(
    w: np.ndarray,
    mu: np.ndarray,
    Sigma: np.ndarray,
    w0: np.ndarray,
    beta: float,
    eps: float = 1e-8,
) -> float:
    w = np.asarray(w).flatten()
    mu = np.asarray(mu).flatten()
    w0 = np.asarray(w0).flatten()
    assert w.shape == mu.shape == w0.shape, "Weights, returns, and initial weights must have the same dimension."
    n = w.shape[0]
    assert Sigma.shape == (n, n), "Covariance matrix must be square with matching dimension."
    numerator = _mu_p(w, mu) - _trans_costs(w, w0, beta)
    denominator = _sigma_p(w, Sigma) + eps
    return -(numerator / denominator)