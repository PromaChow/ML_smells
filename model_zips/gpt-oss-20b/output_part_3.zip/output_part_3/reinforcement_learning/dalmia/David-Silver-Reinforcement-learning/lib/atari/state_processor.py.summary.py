import tensorflow as tf

class StateProcessor:
    def __init__(self):
        tf.compat.v1.disable_eager_execution()
        self.raw_placeholder = tf.compat.v1.placeholder(
            dtype=tf.uint8,
            shape=[210, 160, 3],
            name='raw_state'
        )

        gray = tf.image.rgb_to_grayscale(self.raw_placeholder)
        cropped = tf.image.crop_to_bounding_box(
            image=gray,
            offset_height=34,
            offset_width=0,
            target_height=160,
            target_width=160
        )
        resized = tf.compat.v1.image.resize_images(
            images=cropped,
            size=[84, 84],
            method=tf.image.ResizeMethod.NEAREST_NEIGHBOR
        )
        self.processed = tf.squeeze(resized, name='processed')

        self.sess = tf.compat.v1.Session()
        self.sess.run(tf.compat.v1.global_variables_initializer())

    def process(self, raw_state):
        return self.sess.run(
            self.processed,
            feed_dict={self.raw_placeholder: raw_state}
        )