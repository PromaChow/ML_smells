import gym
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from collections import deque
from machin.algorithms.dqn import DQNPer
from machin.utils.logging import logger
from machin.utils.general import disable_view_window

# Environment and configuration setup
env = gym.make("Frostbite-ram-v0")
action_num = env.action_space.n
max_episodes = 20000
history_depth = 4
disable_view_window()

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


# Utility functions
def convert(state):
    return torch.tensor(state, dtype=torch.float32, device=device)


class History:
    def __init__(self, depth):
        self.depth = depth
        self.states = deque(maxlen=depth)

    def add(self, state):
        self.states.append(state)

    def to_tensor(self):
        if len(self.states) < self.depth:
            # Pad with zeros if history is incomplete
            pad = [torch.zeros_like(next(iter(self.states))) for _ in range(self.depth - len(self.states))]
            return torch.stack(pad + list(self.states))
        return torch.stack(self.states)

    def copy(self):
        new_hist = History(self.depth)
        new_hist.states = deque(self.states, maxlen=self.depth)
        return new_hist


# Model definition
class RecurrentQNet(nn.Module):
    def __init__(self, action_num):
        super(RecurrentQNet, self).__init__()
        self.gru = nn.GRU(input_size=128, hidden_size=256, batch_first=True)
        self.fc1 = nn.Linear(256, 256)
        self.fc2 = nn.Linear(256, action_num)

    def forward(self, x, hidden=None, mode="update"):
        if mode == "sample":
            # x: [1, 128]
            x = x.unsqueeze(0).unsqueeze(0)  # [1,1,128]
            out, h = self.gru(x, hidden)  # out: [1,1,256]
            out = out.squeeze(0).squeeze(0)
            out = self.fc1(out)
            out = self.fc2(out)
            return out, h
        elif mode == "update":
            # x: [batch, seq_len, 128]
            out, h = self.gru(x, hidden)  # out: [batch, seq_len, 256]
            out = out[:, -1, :]  # last time step
            out = self.fc1(out)
            out = self.fc2(out)
            return out, h
        else:
            raise ValueError("Invalid mode")


# Training initialization
q_net = RecurrentQNet(action_num).to(device)
target_net = RecurrentQNet(action_num).to(device)
optimizer = optim.Adam(q_net.parameters(), lr=5e-4)
loss_fn = nn.MSELoss(reduction="sum")

drqn = DQNPer(
    q_network=q_net,
    target_network=target_net,
    optimizer=optimizer,
    loss=loss_fn,
    gamma=0.99,
    replay_size=50000,
    batch_size=32,
    update_interval=4,
    target_update_interval=1000,
    device=device,
)

# Epsilon-greedy parameters
epsilon_start = 1.0
epsilon_end = 0.1
epsilon_decay = 50000
global_step = 0
smoothed_reward = 0.0

for episode in range(1, max_episodes + 1):
    state_np = env.reset()
    state = convert(state_np)
    hist = History(history_depth)
    hist.add(state)
    total_reward = 0.0
    done = False
    step = 0

    while not done:
        # Epsilon schedule
        epsilon = epsilon_end + (epsilon_start - epsilon_end) * np.exp(-1.0 * global_step / epsilon_decay)
        # Sample action
        q_values, hidden = q_net.forward(state, mode="sample")
        if np.random.rand() < epsilon:
            action = env.action_space.sample()
        else:
            action = torch.argmax(q_values).item()

        next_state_np, reward, done, _ = env.step(action)
        next_state = convert(next_state_np)
        next_hist = hist.copy()
        next_hist.add(next_state)

        # Store transition
        drqn.update(
            state=hist.to_tensor().unsqueeze(0),
            action=torch.tensor([action], device=device),
            reward=torch.tensor([reward], device=device),
            next_state=next_hist.to_tensor().unsqueeze(0),
            terminal=torch.tensor([float(done)], device=device),
        )

        hist = next_hist
        state = next_state
        total_reward += reward
        global_step += 1
        step += 1

    # DRQN update after episode
    if episode > 20:
        updates = step // 10
        for _ in range(updates):
            drqn.update()

    # Reward smoothing and logging
    smoothed_reward = 0.9 * smoothed_reward + 0.1 * total_reward
    logger.info(f"Episode {episode} | Total Reward: {total_reward:.2f} | Smoothed: {smoothed_reward:.2f}")
