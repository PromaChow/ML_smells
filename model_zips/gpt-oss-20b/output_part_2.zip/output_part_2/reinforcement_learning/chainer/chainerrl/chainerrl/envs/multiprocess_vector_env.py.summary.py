import multiprocessing
import signal
import warnings
import functools

import numpy as np


def worker(remote, env_fn):
    """Worker process that runs an environment and communicates via a pipe."""
    signal.signal(signal.SIGINT, signal.SIG_IGN)
    env = env_fn()
    try:
        while True:
            cmd, data = remote.recv()
            if cmd == "step":
                obs, reward, done, info = env.step(data)
                remote.send((obs, reward, done, info))
            elif cmd == "reset":
                obs = env.reset()
                remote.send(obs)
            elif cmd == "seed":
                seed = data
                env.seed(seed)
                remote.send(seed)
            elif cmd == "spec":
                remote.send(env.spec)
            elif cmd == "get_spaces":
                remote.send((env.observation_space, env.action_space))
            elif cmd == "close":
                env.close()
                remote.close()
                break
            else:
                raise NotImplementedError(f"Unknown command: {cmd}")
    finally:
        env.close()
        remote.close()


class MultiprocessVectorEnv:
    """Multiprocessing vectorized environment for parallel RL environments."""

    def __init__(self, env_fns):
        """Create a vectorized environment.

        Args:
            env_fns (list[callable]): List of environment factory functions.
        """
        self._check_numpy_version()
        self.env_fns = env_fns
        self.n_envs = len(env_fns)
        self.remotes, self.work_remotes, self.processes = [], [], []

        for env_fn in env_fns:
            parent_remote, child_remote = multiprocessing.Pipe()
            self.remotes.append(parent_remote)
            self.work_remotes.append(child_remote)

            p = multiprocessing.Process(
                target=worker, args=(child_remote, env_fn)
            )
            p.daemon = True
            p.start()
            self.processes.append(p)
            child_remote.close()  # Close the child end in the main process

        # Retrieve spaces from the first environment
        self.remotes[0].send(("get_spaces", None))
        obs_space, act_space = self.remotes[0].recv()
        self.observation_space = obs_space
        self.action_space = act_space

        self.closed = False

    @staticmethod
    def _check_numpy_version():
        if np.__version__ == "1.16.0":
            warnings.warn(
                "NumPy 1.16.0 detected. This may cause memory leaks."
            )

    def _assert_not_closed(self):
        if self.closed:
            raise AssertionError("MultiprocessVectorEnv has been closed.")

    def step(self, actions):
        """Step all environments.

        Args:
            actions (list): Actions for each environment.

        Returns:
            Tuple[np.ndarray, np.ndarray, np.ndarray, list]: Observations, rewards,
            dones, and infos from all environments.
        """
        self._assert_not_closed()
        assert len(actions) == self.n_envs, "Number of actions must match number of environments."

        for remote, action in zip(self.remotes, actions):
            remote.send(("step", action))

        results = [remote.recv() for remote in self.remotes]
        obs, rew, dones, infos = zip(*results)

        return (
            np.array(obs),
            np.array(rew),
            np.array(dones),
            list(infos),
        )

    def reset(self, mask=None):
        """Reset selected environments.

        Args:
            mask (list[bool], optional): If False, the corresponding environment
                will be reset. If None, all environments are reset.

        Returns:
            np.ndarray: Observations from the reset environments.
        """
        self._assert_not_closed()
        if mask is None:
            mask = [True] * self.n_envs

        obs_list = []
        for i, remote in enumerate(self.remotes):
            if not mask[i]:
                remote.send(("reset", None))
                obs_list.append(remote.recv())
        return np.array(obs_list)

    def close(self):
        """Close all environments."""
        if self.closed:
            return
        for remote in self.remotes:
            remote.send(("close", None))
        for p in self.processes:
            p.join()
        self.closed = True

    def seed(self, seeds=None):
        """Seed all environments.

        Args:
            seeds (list[int], optional): Seeds for each environment. If None,
                random seeds will be generated.

        Returns:
            list[int]: Seeds used by each environment.
        """
        self._assert_not_closed()
        if seeds is None:
            seeds = np.random.randint(0, 2**31 - 1, size=self.n_envs)
        else:
            seeds = list(seeds)
            assert len(seeds) == self.n_envs, "Seeds length must match number of environments."

        for remote, seed in zip(self.remotes, seeds):
            remote.send(("seed", seed))
        return [remote.recv() for remote in self.remotes]

    @property
    @functools.lru_cache(maxsize=1)
    def spec(self):
        """Return the specification of the first environment."""
        self._assert_not_closed()
        self.remotes[0].send(("spec", None))
        return self.remotes[0].recv()

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass
```