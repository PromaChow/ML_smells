import numpy as np
import matplotlib.pyplot as plt
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error

# Import the custom data utilities module (assumed to be available in the environment)
import dsu

# Configuration parameters
method = "conc"          # concatenation of embeddings
post_threshold = 3       # minimum word frequency
x_scale = 10             # x‑axis plot limit
y_scale = 10             # y‑axis plot limit
shuffle = "yes"          # shuffle data
subsetSize = 1000        # number of samples to use

# Paths and dataset identifiers
dataset = "fasttext"
dataset_path = "fasttext.vec"  # path to the FastText embeddings file

# --------------------------------------------------------------------------- #
# 1. Data Loading
# --------------------------------------------------------------------------- #
posts, yO, yC, yE, yA, yN = dsu.readMyPersonality()
embeddings = dsu.parseFastText(dataset_path)

# --------------------------------------------------------------------------- #
# 2. Data Shuffling
# --------------------------------------------------------------------------- #
if shuffle.lower() == "yes":
    indices = np.arange(len(posts))
    np.random.shuffle(indices)
    posts = posts[indices]
    yO = yO[indices]
    yC = yC[indices]
    yE = yE[indices]
    yA = yA[indices]
    yN = yN[indices]

# --------------------------------------------------------------------------- #
# 3. Data Subsetting
# --------------------------------------------------------------------------- #
subsetSize = min(subsetSize, len(posts))
posts = posts[:subsetSize]
yO = yO[:subsetSize]
yC = yC[:subsetSize]
yE = yE[:subsetSize]
yA = yA[:subsetSize]
yN = yN[:subsetSize]

# --------------------------------------------------------------------------- #
# 4. Text to Embeddings Transformation
# --------------------------------------------------------------------------- #
conE = embeddings.transformTextForTraining(
    posts,
    method=method,
    post_threshold=post_threshold
)

# --------------------------------------------------------------------------- #
# 5. Train-Test Split
# --------------------------------------------------------------------------- #
split_index = round(len(conE) * 0.85)
data_train = conE[:split_index]
data_test = conE[split_index:]

yO_train = yO[:split_index]
yC_train = yC[:split_index]
yE_train = yE[:split_index]
yA_train = yA[:split_index]
yN_train = yN[:split_index]

yO_test = yO[split_index:]
yC_test = yC[split_index:]
yE_test = yE[split_index:]
yA_test = yA[split_index:]
yN_test = yN[split_index:]

# --------------------------------------------------------------------------- #
# 6. Model Training and Evaluation
# --------------------------------------------------------------------------- #
traits = {
    "O": (yO_train, yO_test),
    "C": (yC_train, yC_test),
    "E": (yE_train, yE_test),
    "A": (yA_train, yA_test),
    "N": (yN_train, yN_test)
}

for trait_name, (y_train, y_test) in traits.items():
    svr = SVR(kernel="rbf", gamma=10, C=1)
    svr.fit(data_train, y_train)
    predictions = svr.predict(data_test)
    mse = mean_squared_error(y_test, predictions)

    # ----------------------------------------------------------------------- #
    # 7. Visualization
    # ----------------------------------------------------------------------- #
    plt.figure(figsize=(6, 4))
    plt.scatter(y_test, predictions, alpha=0.6, edgecolors="k")
    plt.plot([0, max(y_scale, max(predictions))], [0, max(y_scale, max(predictions))],
             color="red", linestyle="--", label="Ideal")
    plt.xlim(0, x_scale)
    plt.ylim(0, y_scale)
    plt.xlabel("Actual")
    plt.ylabel("Predicted")
    plt.title(f"{trait_name} - {method} - SVR(rbf) γ=10, C=1 - MSE={mse:.3f}")
    plt.grid(True)
    plt.legend()
    plt.show()  # Display inline; to save uncomment the next line
    # plt.savefig(f"{trait_name}_{method}_SVR_MSE_{mse:.3f}.png")