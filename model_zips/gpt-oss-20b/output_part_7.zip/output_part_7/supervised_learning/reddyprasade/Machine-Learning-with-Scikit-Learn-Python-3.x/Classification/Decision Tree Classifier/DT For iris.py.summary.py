import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, plot_tree

# Load the Iris dataset
url = "https://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data"
column_names = ["sepal_length", "sepal_width", "petal_length", "petal_width", "species"]
df = pd.read_csv(url, header=None, names=column_names)

# Display first and last five rows
print("First five rows:")
print(df.head())
print("\nLast five rows:")
print(df.tail())

# Split into features and target
X = df[["sepal_length", "sepal_width", "petal_length", "petal_width"]]
Y = df["species"]

# Train-test split
x_train, x_test, y_train, y_test = train_test_split(X, Y)

# Initialize and train Decision Tree Classifier
clf = DecisionTreeClassifier()
clf.fit(x_train, y_train)

# Make predictions
yhat = clf.predict(x_test)

# Evaluate feature importance
importances = clf.feature_importances_
for idx, importance in enumerate(importances):
    print(f"Feature {idx} importance: {importance}")

# Visualize feature importance
plt.figure(figsize=(8, 4))
plt.bar(range(len(importances)), importances, tick_label=["sepal_length", "sepal_width", "petal_length", "petal_width"])
plt.title("Feature Importances")
plt.xlabel("Feature")
plt.ylabel("Importance")
plt.tight_layout()
plt.show()

# Plot decision tree structure (default)
plt.figure(figsize=(12, 8))
plot_tree(clf, feature_names=["sepal_length", "sepal_width", "petal_length", "petal_width"], class_names=clf.classes_, filled=False)
plt.title("Decision Tree (default)")
plt.show()

# Plot decision tree structure (filled)
plt.figure(figsize=(12, 8))
plot_tree(clf, feature_names=["sepal_length", "sepal_width", "petal_length", "petal_width"], class_names=clf.classes_, filled=True)
plt.title("Decision Tree (filled)")
plt.show()