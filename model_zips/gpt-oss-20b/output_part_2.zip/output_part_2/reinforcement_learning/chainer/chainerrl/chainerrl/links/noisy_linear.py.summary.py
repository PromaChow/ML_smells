import math
import torch
import torch.nn as nn
import torch.nn.functional as F


class FactorizedNoisyLinear(nn.Module):
    def __init__(self, mu_link: nn.Linear, sigma_scale: float = 0.4):
        super().__init__()
        # Extract input and output sizes from the provided linear layer
        self.in_size = mu_link.weight.shape[1]
        self.out_size = mu_link.weight.shape[0]
        self.has_bias = mu_link.bias is not None

        # Initialize the mean (mu) sub-layer
        self.mu = nn.Linear(self.in_size, self.out_size, bias=self.has_bias)
        # LeCun uniform initialization for mu weights
        nn.init.kaiming_uniform_(self.mu.weight, a=0, mode="fan_in", nonlinearity="linear")
        if self.has_bias:
            nn.init.zeros_(self.mu.bias)

        # Initialize the sigma sub-layer
        self.sigma = nn.Linear(self.in_size, self.out_size, bias=self.has_bias)
        sigma_init = sigma_scale / math.sqrt(self.in_size)
        nn.init.constant_(self.sigma.weight, sigma_init)
        if self.has_bias:
            nn.init.constant_(self.sigma.bias, sigma_init)

        # Ensure both sub-layers are on the same device as mu_link
        device = mu_link.weight.device
        if device.type != "cpu":
            self.mu.to(device)
            self.sigma.to(device)

    def _eps(self, size):
        """Generate factorized noise using the transformation f(z) = sign(z) * sqrt(|z|)."""
        noise = torch.randn(size, device=self.mu.weight.device)
        return torch.sign(noise) * torch.sqrt(torch.abs(noise))

    def forward(self, x):
        # Generate noise for input and output dimensions
        eps_x = self._eps(self.in_size)
        eps_y = self._eps(self.out_size)

        # Compute noisy weights: mu + sigma * (outer product of eps_y and eps_x)
        weight_noise = torch.ger(eps_y, eps_x)
        W = self.mu.weight + self.sigma.weight * weight_noise

        # Compute noisy bias if present
        if self.has_bias:
            b = self.mu.bias + self.sigma.bias * eps_y
        else:
            b = None

        return F.linear(x, W, b)