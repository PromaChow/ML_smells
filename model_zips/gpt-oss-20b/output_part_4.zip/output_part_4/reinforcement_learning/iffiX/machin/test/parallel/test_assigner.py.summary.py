import pytest
import torch
import numpy as np
import psutil
import GPUtil
from machin.parallel.assigner import ModelSizeEstimator, ModelAssigner

# ------------------------------------------------------------------
# Mock nn.Module with diverse parameter and buffer types
# ------------------------------------------------------------------
class MockModule(torch.nn.Module):
    def __init__(self):
        super().__init__()
        # Parameters of various data types
        self.param_int8 = torch.nn.Parameter(torch.randn(10, dtype=torch.int8))
        self.param_int16 = torch.nn.Parameter(torch.randn(10, dtype=torch.int16))
        self.param_int32 = torch.nn.Parameter(torch.randn(10, dtype=torch.int32))
        self.param_double = torch.nn.Parameter(torch.randn(10, dtype=torch.double))
        # Buffers of various data types
        self.register_buffer('buffer_float', torch.randn(10, dtype=torch.float32))
        self.register_buffer('buffer_int8', torch.randn(10, dtype=torch.int8))

# ------------------------------------------------------------------
# Helper functions for size calculations
# ------------------------------------------------------------------
def tensor_size_in_bytes(tensor):
    return tensor.element_size() * tensor.nelement()

def to_mb(size_in_bytes):
    return size_in_bytes / (1024 ** 2)

# ------------------------------------------------------------------
# Tests for ModelSizeEstimator
# ------------------------------------------------------------------
def test_model_size_estimator():
    model = MockModule()
    estimator = ModelSizeEstimator(model, multiplier=1)

    # Expected buffer sizes
    buffer_float_size = tensor_size_in_bytes(model.buffer_float)
    buffer_int8_size = tensor_size_in_bytes(model.buffer_int8)
    expected_buffer_size_mb = to_mb(buffer_float_size + buffer_int8_size)

    # Expected parameter sizes
    param_sizes = sum(
        tensor_size_in_bytes(p)
        for p in [model.param_int8, model.param_int16, model.param_int32, model.param_double]
    )
    expected_param_size_mb = to_mb(param_sizes)

    assert pytest.approx(estimator.get_buffer_sizes(), rel=1e-3) == expected_buffer_size_mb
    assert pytest.approx(estimator.get_parameter_sizes(), rel=1e-3) == expected_param_size_mb
    assert pytest.approx(estimator.estimate_size(), rel=1e-3) == expected_buffer_size_mb + expected_param_size_mb

# ------------------------------------------------------------------
# Mock GPU and CPU memory utilities
# ------------------------------------------------------------------
class MockGPU:
    def __init__(self, memory_total, memory_free):
        self.memoryTotal = memory_total  # in MB
        self.memoryFree = memory_free    # in MB

def mock_getGPUs(return_list):
    return return_list

def mock_virtual_memory(total, available):
    class MockVmem:
        def __init__(self, total, available):
            self.total = total
            self.available = available
    return MockVmem(total, available)

# ------------------------------------------------------------------
# Parameterized tests for ModelAssigner
# ------------------------------------------------------------------
@pytest.mark.parametrize(
    "gpu_configs, cpu_mem_mb, model_size_mb, device_list, expected_assignment, expect_error",
    [
        # Two GPUs, enough memory
        (
            [MockGPU(8192, 8192), MockGPU(8192, 8192)],
            4096,
            512,
            ["cuda:0", "cuda:1", "cpu"],
            ["cuda:0", "cuda:1"],
            False,
        ),
        # Two GPUs, not enough memory for both
        (
            [MockGPU(512, 512), MockGPU(512, 512)],
            4096,
            1024,
            ["cuda:0", "cuda:1", "cpu"],
            None,
            True,
        ),
        # Only CPU available
        (
            [],
            4096,
            200,
            ["cpu"],
            ["cpu"],
            False,
        ),
        # No GPUs, insufficient CPU memory
        (
            [],
            128,
            200,
            ["cpu"],
            None,
            True,
        ),
        # GPU free memory equals model size
        (
            [MockGPU(1024, 1024)],
            2048,
            1024,
            ["cuda:0", "cpu"],
            ["cuda:0"],
            False,
        ),
    ],
)
def test_model_assigner(
    gpu_configs,
    cpu_mem_mb,
    model_size_mb,
    device_list,
    expected_assignment,
    expect_error,
    monkeypatch,
):
    # Patch GPUtil.getGPUs
    monkeypatch.setattr(GPUtil, "getGPUs", lambda: gpu_configs)

    # Patch psutil.virtual_memory
    monkeypatch.setattr(psutil, "virtual_memory", lambda: mock_virtual_memory(cpu_mem_mb * 1024 * 1024, cpu_mem_mb * 1024 * 1024))

    # Mock ModelSizeEstimator to return a fixed size
    class MockEstimator:
        def __init__(self, model, multiplier=1):
            self.size_mb = model_size_mb

        def estimate_size(self):
            return self.size_mb

    monkeypatch.setattr(
        "machin.parallel.assigner.ModelSizeEstimator", MockEstimator
    )

    if expect_error:
        with pytest.raises(RuntimeError) as exc_info:
            assigner = ModelAssigner(
                device_list=device_list,
                memory_multiplier=1.0,
                gpu_memory_limit=cpu_mem_mb * 1024 * 1024,  # bytes
                cpu_memory_limit=cpu_mem_mb * 1024 * 1024,  # bytes
                model_size=MockEstimator(None).estimate_size() * 1024 * 1024,
            )
        assert "insufficient" in str(exc_info.value).lower()
    else:
        assigner = ModelAssigner(
            device_list=device_list,
            memory_multiplier=1.0,
            gpu_memory_limit=cpu_mem_mb * 1024 * 1024,
            cpu_memory_limit=cpu_mem_mb * 1024 * 1024,
            model_size=MockEstimator(None).estimate_size() * 1024 * 1024,
        )
        assert assigner.assignment == expected_assignment
        # Verify that GPU memory usage does not exceed limits
        for dev in assigner.assignment:
            if dev.startswith("cuda"):
                idx = int(dev.split(":")[1])
                assert gpu_configs[idx].memoryFree >= model_size_mb
        # Verify CPU usage if any
        if "cpu" in assigner.assignment:
            assert cpu_mem_mb >= model_size_mb

# ------------------------------------------------------------------
# Edge case: No GPUs, large model requiring more CPU memory
# ------------------------------------------------------------------
def test_no_gpus_large_model(monkeypatch):
    monkeypatch.setattr(GPUtil, "getGPUs", lambda: [])
    monkeypatch.setattr(psutil, "virtual_memory", lambda: mock_virtual_memory(1024 * 1024 * 1024, 512 * 1024 * 1024))

    class MockEstimator:
        def __init__(self, model, multiplier=1):
            self.size_mb = 600

        def estimate_size(self):
            return self.size_mb

    monkeypatch.setattr(
        "machin.parallel.assigner.ModelSizeEstimator", MockEstimator
    )

    with pytest.raises(RuntimeError):
        ModelAssigner(
            device_list=["cpu"],
            memory_multiplier=1.0,
            gpu_memory_limit=0,
            cpu_memory_limit=512 * 1024 * 1024,
            model_size=MockEstimator(None).estimate_size() * 1024 * 1024,
        )