import argparse
import json
import logging
import os
import random
import sys
import time
from collections import deque

import gym
import numpy as np
import requests
from chainer import cuda, optimizers, serializers, Variable, Function
import chainer.links as L
import chainer.functions as F
import chainer
from chainer.links import Chain, Linear, Convolution2D
from chainer import init
from chainer.training import extensions
from chainercv.utils import read_image, save_image
from chainercv.visualizations import plot_something

import chainer_rl
from chainer_rl.agent import IQN
from chainer_rl.exploration import LinearDecayEpsilonGreedy
from chainer_rl.envs import atari
from chainer_rl.envs.atari import wrap_deepmind
from chainer_rl.envs.monitor import Monitor
from chainer_rl.datasets import ReplayBuffer
from chainer_rl.misc import set_random_seed

# --------------------------
# 1. Argument Parsing
# --------------------------
def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--env', default='BreakoutNoFrameskip-v4', help='Gym environment id')
    parser.add_argument('--output-dir', default='output', help='Output directory')
    parser.add_argument('--seed', type=int, default=42, help='Random seed')
    parser.add_argument('--gpu', type=int, default=-1, help='GPU id')
    parser.add_argument('--final-epsilon', type=float, default=0.01, help='Final epsilon for exploration')
    parser.add_argument('--exploration-frames', type=int, default=10_000_000, help='Frames over which epsilon decays')
    parser.add_argument('--steps', type=int, default=50_000_000, help='Training steps')
    parser.add_argument('--replay-buffer-size', type=int, default=1_000_000, help='Replay buffer size')
    parser.add_argument('--target-update-interval', type=int, default=10_000, help='Target network update interval')
    parser.add_argument('--eval-interval', type=int, default=250_000, help='Evaluation interval')
    parser.add_argument('--eval-n-steps', type=int, default=125_000, help='Evaluation steps')
    parser.add_argument('--n-best-episodes', type=int, default=200, help='Number of episodes for final evaluation')
    parser.add_argument('--quantiles', type=int, default=64, help='N, N\'')
    parser.add_argument('--k', type=int, default=32, help='K')
    parser.add_argument('--log-level', default='INFO', help='Logging level')
    parser.add_argument('--load-pretrained', choices=['best', 'final'], help='Load pretrained model')
    parser.add_argument('--load', help='Path to custom model')
    parser.add_argument('--demo', action='store_true', help='Run demo')
    args = parser.parse_args()
    return args

# --------------------------
# 2. Logging and Seed Setup
# --------------------------
def setup_logging(log_level):
    numeric_level = getattr(logging, log_level.upper(), None)
    logging.basicConfig(level=numeric_level, format='%(asctime)s %(levelname)s: %(message)s')

def set_seeds(seed, eval_seed=None):
    np.random.seed(seed)
    random.seed(seed)
    if eval_seed is None:
        eval_seed = seed + 1
    set_random_seed(seed)
    set_random_seed(eval_seed)

# --------------------------
# 3. Environment Creation
# --------------------------
def make_env(env_name, seed, render=False, monitor=False, monitor_dir=None, epsilon=0.0):
    env = gym.make(env_name)
    env.seed(seed)
    env.action_space.seed(seed)
    env = wrap_deepmind(env, frame_stack=4, episode_life=True, clip_rewards=True)
    if render:
        env = gym.wrappers.RenderToVideo(env, path=monitor_dir)
    if monitor:
        env = Monitor(env, monitor_dir, mode='eval')
    if epsilon > 0:
        def epsilon_greedy_policy(agent, obs):
            if np.random.rand() < epsilon:
                return agent.env.action_space.sample()
            return agent.act(obs)
        env = chainer_rl.envs.episodic.EpisodicEnv(env, max_episode_length=10000)
    return env

# --------------------------
# 4. Q-Function Network Definition
# --------------------------
class IQNLink(Chain):
    def __init__(self, n_actions, quantiles, k, embedding_dim=64):
        super().__init__()
        self.n_actions = n_actions
        self.quantiles = quantiles
        self.k = k
        self.embedding_dim = embedding_dim
        with self.init_scope():
            self.conv1 = Convolution2D(4, 32, 8, stride=4, nobias=True)
            self.conv2 = Convolution2D(32, 64, 4, stride=2, nobias=True)
            self.conv3 = Convolution2D(64, 64, 3, stride=1, nobias=True)
            self.fc1 = Linear(3136, 512)
            self.tau_embedding = Linear(quantiles, embedding_dim)
            self.tau_fc = Linear(embedding_dim, 512)
            self.head = Linear(512, n_actions)

    def __call__(self, x, taus):
        # x: [batch, channels, height, width]
        # taus: [batch, quantiles]
        batch_size = x.shape[0]
        x = F.relu(self.conv1(x))
        x = F.relu(self.conv2(x))
        x = F.relu(self.conv3(x))
        x = F.reshape(x, (batch_size, -1))
        x = F.relu(self.fc1(x))
        # Embed taus
        taus = F.reshape(taus, (batch_size, self.quantiles, 1))
        tau_embedding = F.tanh(self.tau_embedding(taus))
        tau_embedding = F.reshape(tau_embedding, (batch_size, self.quantiles, self.embedding_dim))
        tau_fc = F.relu(self.tau_fc(tau_embedding))
        tau_fc = F.reshape(tau_fc, (batch_size, self.quantiles, 512))
        # Multiply x and taus
        x = F.expand_dims(x, 1)  # [batch,1,512]
        x = x * tau_fc  # broadcasting
        x = F.reshape(x, (batch_size * self.quantiles, 512))
        q = self.head(x)
        q = F.reshape(q, (batch_size, self.quantiles, self.n_actions))
        return q

def visualize_network(output_dir, n_actions, quantiles, k):
    dummy_input = Variable(np.zeros((1, 4, 84, 84), dtype=np.float32))
    dummy_taus = Variable(np.linspace(0, 1, quantiles).reshape(1, quantiles).astype(np.float32))
    net = IQNLink(n_actions, quantiles, k)
    q = net(dummy_input, dummy_taus)
    try:
        import graphviz
        dot = graphviz.Digraph(comment='IQN Network')
        dot.node('Input', 'Input')
        dot.node('Conv1', 'Conv2D')
        dot.node('Conv2', 'Conv2D')
        dot.node('Conv3', 'Conv2D')
        dot.node('FC1', 'Linear')
        dot.node('TauEmbedding', 'Linear')
        dot.node('TauFC', 'Linear')
        dot.node('Head', 'Linear')
        dot.node('Output', 'Output')
        dot.edge('Input', 'Conv1')
        dot.edge('Conv1', 'Conv2')
        dot.edge('Conv2', 'Conv3')
        dot.edge('Conv3', 'FC1')
        dot.edge('FC1', 'Head')
        dot.edge('TauEmbedding', 'TauFC')
        dot.edge('TauFC', 'Head')
        dot.edge('Head', 'Output')
        dot.render(os.path.join(output_dir, 'iqn_network'), format='pdf', cleanup=True)
    except Exception:
        pass  # graphviz may not be available

# --------------------------
# 5. Optimizer and Replay Buffer
# --------------------------
def create_optimizer(net):
    optimizer = optimizers.Adam(alpha=5e-5, eps=1e-4)
    optimizer.setup(net)
    return optimizer

def create_replay_buffer(size):
    return ReplayBuffer(capacity=size)

# --------------------------
# 6. Explorer Setup
# --------------------------
def create_explorer(env, final_epsilon, exploration_frames):
    return LinearDecayEpsilonGreedy(env, final_epsilon=final_epsilon, decay_frames=exploration_frames)

# --------------------------
# 7. Agent Initialization
# --------------------------
def create_agent(q_func, optimizer, replay_buffer, gpu, gamma=0.99, batch_size=32,
                 batch_accumulator='mean', n_quantiles=64, k=32):
    agent = IQN(q_func, optimizer, replay_buffer, device=gpu,
                gamma=gamma, batch_size=batch_size,
                batch_accumulator=batch_accumulator,
                n_quantiles=n_quantiles, k=k)
    return agent

# --------------------------
# 8. Model Loading
# --------------------------
def load_pretrained(agent, output_dir, variant):
    path = os.path.join(output_dir, f'{variant}.npz')
    if os.path.isfile(path):
        serializers.load_npz(path, agent)
    else:
        logging.warning(f'Pretrained model {variant} not found at {path}')

def load_custom(agent, path):
    if os.path.isfile(path):
        serializers.load_npz(path, agent)
    else:
        logging.error(f'Custom model file not found: {path}')
        sys.exit(1)

# --------------------------
# 9. Training or Evaluation
# --------------------------
def evaluate_agent(agent, env, n_steps, render=False):
    total_reward = 0.0
    steps = 0
    while steps < n_steps:
        obs = env.reset()
        done = False
        while not done and steps < n_steps:
            if render:
                env.render()
            action = agent.act(obs)
            obs, reward, done, _ = env.step(action)
            total_reward += reward
            steps += 1
    return total_reward / (steps / env._max_episode_steps)

def evaluate_episodes(agent, env, n_episodes):
    rewards = []
    for _ in range(n_episodes):
        obs = env.reset()
        done = False
        ep_reward = 0.0
        while not done:
            action = agent.act(obs)
            obs, reward, done, _ = env.step(action)
            ep_reward += reward
        rewards.append(ep_reward)
    stats = {
        'mean': float(np.mean(rewards)),
        'median': float(np.median(rewards)),
        'std': float(np.std(rewards))
    }
    return stats, rewards

def train(agent, env, eval_env, args):
    best_mean = -float('inf')
    best_model_path = os.path.join(args.output_dir, 'best.npz')
    for step in range(1, args.steps + 1):
        obs = env.reset()
        done = False
        while not done:
            action = agent.act(obs)
            next_obs, reward, done, _ = env.step(action)
            agent.observe(obs, action, reward, next_obs, done)
            obs = next_obs
            if step % args.target_update_interval == 0:
                agent.update()
            if step % args.eval_interval == 0:
                mean_reward = evaluate_agent(agent, eval_env, args.eval_n_steps)
                logging.info(f'Step {step}: Eval mean reward {mean_reward:.2f}')
                if mean_reward > best_mean:
                    best_mean = mean_reward
                    serializers.save_npz(best_model_path, agent)
        if step % 1000 == 0:
            logging.info(f'Training step {step}')
    # Load best and evaluate
    serializers.load_npz(best_model_path, agent)
    stats, rewards = evaluate_episodes(agent, eval_env, args.n_best_episodes)
    logging.info(f'Best model evaluation over {args.n_best_episodes} episodes: {stats}')
    json_path = os.path.join(args.output_dir, 'bestscores.json')
    with open(json_path, 'w') as f:
        json.dump({'stats': stats, 'rewards': rewards}, f, indent=2)

def demo(agent, eval_env, args):
    stats, rewards = evaluate_episodes(agent, eval_env, args.n_best_episodes)
    logging.info(f'Demo evaluation over {args.n_best_episodes} episodes: {stats}')
    json_path = os.path.join(args.output_dir, 'demo_scores.json')
    with open(json_path, 'w') as f:
        json.dump({'stats': stats, 'rewards': rewards}, f, indent=2)

# --------------------------
# 10. Main
# --------------------------
def main():
    args = parse_args()
    os.makedirs(args.output_dir, exist_ok=True)
    setup_logging(args.log_level)

    set_seeds(args.seed)

    # Create environments
    train_env = make_env(args.env, seed=args.seed, render=False, monitor=False)
    eval_env = make_env(args.env, seed=args.seed + 1, render=False, monitor=True, monitor_dir=args.output_dir)

    n_actions = train_env.action_space.n

    # Build Q-function
    q_func = IQNLink(n_actions, quantiles=args.quantiles, k=args.k)
    visualize_network(args.output_dir, n_actions, args.quantiles, args.k)

    # Optimizer and Replay Buffer
    optimizer = create_optimizer(q_func)
    replay_buffer = create_replay_buffer(args.replay_buffer_size)

    # Explorer
    explorer = create_explorer(train_env, args.final_epsilon, args.exploration_frames)

    # Agent
    agent = create_agent(q_func, optimizer, replay_buffer, gpu=args.gpu,
                         gamma=0.99, batch_size=32, batch_accumulator='mean',
                         n_quantiles=args.quantiles, k=args.k)

    # Load models if specified
    if args.load_pretrained:
        load_pretrained(agent, args.output_dir, args.load_pretrained)
    if args.load:
        load_custom(agent, args.load)

    # Train or Demo
    if args.demo:
        demo(agent, eval_env, args)
    else:
        train(agent, train_env, eval_env, args)

if __name__ == '__main__':
    main()
