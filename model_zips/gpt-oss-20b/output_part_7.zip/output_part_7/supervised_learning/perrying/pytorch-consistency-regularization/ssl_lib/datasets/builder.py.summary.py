import random
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader, Sampler
import torchvision.transforms as T
from collections import namedtuple

import utils  # assumes utility functions are provided in utils module


class InfiniteSampler(Sampler):
    def __init__(self, dataset, seed=0):
        self.dataset = dataset
        self.indices = list(range(len(dataset)))
        random.seed(seed)
        random.shuffle(self.indices)

    def __iter__(self):
        while True:
            for idx in self.indices:
                yield idx

    def __len__(self):
        return len(self.dataset)


class LabeledDataset(Dataset):
    def __init__(self, dataset, transform=None):
        self.dataset = dataset
        self.transform = transform

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, idx):
        img, label = self.dataset[idx]
        if self.transform:
            img = self.transform(img)
        return img, label


class UnlabeledDataset(Dataset):
    def __init__(self, dataset, transform=None):
        self.dataset = dataset
        self.transform = transform

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, idx):
        img = self.dataset[idx]
        if self.transform:
            img = self.transform(img)
        return img


def get_dataloaders(dataset_name, cfg, ul_data=None, logger=None):
    # 1. Dataset Loading
    if dataset_name == "svhn":
        train_ds, test_ds = utils.get_svhn(train=True), utils.get_svhn(train=False)
        n_classes, img_size = 10, 32
    elif dataset_name == "stl10":
        train_ds, test_ds = utils.get_stl10(train=True), utils.get_stl10(train=False)
        n_classes, img_size = 10, 96
    elif dataset_name == "cifar10":
        train_ds, test_ds = utils.get_cifar10(train=True), utils.get_cifar10(train=False)
        n_classes, img_size = 10, 32
    elif dataset_name == "cifar100":
        train_ds, test_ds = utils.get_cifar100(train=True), utils.get_cifar100(train=False)
        n_classes, img_size = 100, 32
    else:
        raise ValueError(f"Unsupported dataset: {dataset_name}")

    # 2. Data Splitting
    rng = np.random.RandomState(cfg.seed)
    indices = np.arange(len(train_ds))
    rng.shuffle(indices)

    if cfg.validation_split:
        val_size = int(cfg.val_ratio * len(train_ds))
        val_idx = indices[:val_size]
        remaining_idx = indices[val_size:]
        val_ds = torch.utils.data.Subset(train_ds, val_idx)
    else:
        val_ds = None
        remaining_idx = indices

    labeled_idx, unlabeled_idx = utils.dataset_split(
        remaining_idx, cfg.num_labels, rng=rng
    )
    labeled_ds = torch.utils.data.Subset(train_ds, labeled_idx)
    unlabeled_ds = torch.utils.data.Subset(train_ds, unlabeled_idx)

    if ul_data is not None:
        unlabeled_ds = torch.utils.data.ConcatDataset([unlabeled_ds, ul_data])

    # 3. Normalization Parameters
    if cfg.whiten:
        data_loader = DataLoader(train_ds, batch_size=1024, shuffle=False, num_workers=4)
        all_imgs = torch.cat([x[0] for x in data_loader], dim=0)
        mean = all_imgs.mean(dim=[0, 2, 3], keepdim=True)
        std = all_imgs.std(dim=[0, 2, 3], keepdim=True)
        normalize = T.Normalize(mean.squeeze().tolist(), std.squeeze().tolist())
    elif cfg.zca:
        params = utils.get_zca_normalization_param(train_ds, cfg)
        zca_transform = T.Lambda(lambda x: params.apply(x))
        normalize = zca_transform
    else:
        normalize = T.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])

    # 4. Augmentation Setup
    if cfg.wa:
        weak_aug = utils.gen_weak_augmentation(cfg.flags, cfg.randauglist)
    else:
        weak_aug = None

    if cfg.labeled_aug:
        strong_aug = utils.gen_strong_augmentation(cfg.flags, cfg.randauglist)
    else:
        strong_aug = None

    if cfg.unlabeled_aug:
        unlabeled_aug = utils.gen_strong_augmentation(cfg.flags, cfg.randauglist)
    else:
        unlabeled_aug = None

    # Compose transforms
    def compose(transforms_list):
        transforms_list = [t for t in transforms_list if t is not None]
        return T.Compose(transforms_list)

    labeled_transform = compose([strong_aug, weak_aug, normalize])
    unlabeled_transform = compose([unlabeled_aug, weak_aug, normalize])
    test_transform = compose([normalize])

    # 5. DataLoader Creation
    labeled_dataset = LabeledDataset(labeled_ds, transform=labeled_transform)
    unlabeled_dataset = UnlabeledDataset(unlabeled_ds, transform=unlabeled_transform)
    test_dataset = LabeledDataset(test_ds, transform=test_transform)

    labeled_loader = DataLoader(
        labeled_dataset,
        batch_size=cfg.batch_size,
        sampler=InfiniteSampler(labeled_dataset, seed=cfg.seed),
        num_workers=4,
        pin_memory=True,
    )
    unlabeled_loader = DataLoader(
        unlabeled_dataset,
        batch_size=cfg.batch_size,
        sampler=InfiniteSampler(unlabeled_dataset, seed=cfg.seed),
        num_workers=4,
        pin_memory=True,
    )
    test_loader = DataLoader(
        test_dataset,
        batch_size=cfg.batch_size,
        shuffle=False,
        num_workers=4,
        pin_memory=True,
    )

    if val_ds is not None:
        val_dataset = LabeledDataset(val_ds, transform=test_transform)
        val_loader = DataLoader(
            val_dataset,
            batch_size=cfg.batch_size,
            shuffle=False,
            num_workers=4,
            pin_memory=True,
        )
    else:
        val_loader = None

    # 6. Logging
    if logger:
        logger.info(f"Training samples: {len(train_ds)}")
        logger.info(f"Labeled samples: {len(labeled_ds)}")
        logger.info(f"Unlabeled samples: {len(unlabeled_ds)}")
        if val_loader:
            logger.info(f"Validation samples: {len(val_ds)}")
        logger.info(f"Test samples: {len(test_ds)}")
        logger.info(f"Applied augmentations: labeled={strong_aug is not None}, "
                    f"unlabeled={unlabeled_aug is not None}, weak={weak_aug is not None}")

    return labeled_loader, unlabeled_loader, test_loader, val_loader, n_classes, img_size
