import torch
import torch.nn as nn
import torch.nn.functional as F


class QMixer(nn.Module):
    def __init__(self, args):
        super(QMixer, self).__init__()
        self.n_agents = args.n_agents
        self.state_dim = args.state_dim
        self.embed_dim = args.embed_dim
        self.hypernet_layers = args.hypernet_layers

        # Hypernetwork for first layer weights
        self.hyper_w_1 = self._build_hypernet(
            self.state_dim, self.n_agents * self.embed_dim, self.hypernet_layers
        )
        # Hypernetwork for final layer weights
        self.hyper_w_final = self._build_hypernet(
            self.state_dim, self.embed_dim, self.hypernet_layers
        )
        # Hypernetwork for first layer bias
        self.hyper_b_1 = nn.Linear(self.state_dim, self.embed_dim)

        # Value network for global bias
        self.V = nn.Sequential(
            nn.Linear(self.state_dim, self.embed_dim),
            nn.ReLU(),
            nn.Linear(self.embed_dim, 1),
        )

    def _build_hypernet(self, in_dim, out_dim, layers):
        if layers == 1:
            return nn.Linear(in_dim, out_dim)
        elif layers == 2:
            return nn.Sequential(
                nn.Linear(in_dim, in_dim),
                nn.ReLU(),
                nn.Linear(in_dim, out_dim),
            )
        else:
            raise ValueError("hypernet_layers must be 1 or 2")

    def forward(self, agent_qs, states):
        """
        agent_qs: Tensor of shape (batch, episodes, n_agents)
        states:   Tensor of shape (batch, episodes, state_dim)
        """
        bs, ep, _ = agent_qs.shape
        # Flatten batch and episodes
        agent_qs = agent_qs.reshape(bs * ep, 1, self.n_agents)
        states = states.reshape(bs * ep, self.state_dim)

        # First layer weights and bias
        w1 = self.hyper_w_1(states)
        w1 = torch.abs(w1).reshape(-1, self.n_agents, self.embed_dim)
        b1 = self.hyper_b_1(states)
        b1 = b1.reshape(-1, 1, self.embed_dim)

        # Hidden layer
        hidden = F.elu(torch.bmm(agent_qs, w1) + b1)

        # Final layer weights
        w_final = self.hyper_w_final(states)
        w_final = torch.abs(w_final).reshape(-1, self.embed_dim, 1)

        # Global bias
        v = self.V(states).reshape(-1, 1, 1)

        # Total Q-value
        q_tot = torch.bmm(hidden, w_final) + v
        q_tot = q_tot.reshape(bs, ep, 1)

        return q_tot

# Example usage:
# class Args:
#     n_agents = 4
#     state_dim = 30
#     embed_dim = 64
#     hypernet_layers = 2
#
# args = Args()
# mixer = QMixer(args)
# agent_qs = torch.randn(8, 10, args.n_agents)  # batch=8, episodes=10
# states = torch.randn(8, 10, args.state_dim)
# q_tot = mixer(agent_qs, states)
# print(q_tot.shape)  # should be (8, 10, 1)