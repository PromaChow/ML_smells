import gym
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim


def get_model(model_type, arch_type, input_dim, action_dim):
    if model_type != "ac" or arch_type != "mlp":
        raise NotImplementedError("Only 'ac' model with 'mlp' architecture is supported.")
    # Simple shared MLP with actor and critic heads
    shared = nn.Sequential(
        nn.Linear(input_dim, 128),
        nn.ReLU(),
        nn.Linear(128, 128),
        nn.ReLU(),
    )
    actor = nn.Linear(128, action_dim)
    critic = nn.Linear(128, 1)
    return ActorCritic(shared, actor, critic)


class ActorCritic(nn.Module):
    def __init__(self, shared, actor_head, critic_head):
        super().__init__()
        self.shared = shared
        self.actor_head = actor_head
        self.critic_head = critic_head

    def forward(self, x):
        x = self.shared(x)
        logits = self.actor_head(x)
        value = self.critic_head(x)
        return logits, value.squeeze(-1)


class A2CAgent:
    def __init__(
        self,
        env,
        *,
        gamma=0.99,
        lam=0.95,
        actor_lr=3e-4,
        critic_lr=1e-3,
        value_coeff=0.5,
        entropy_coeff=0.01,
        clip_grad_norm=0.5,
        create_model=True,
        arch_type="mlp",
        deterministic=False,
    ):
        self.env = env
        self.gamma = gamma
        self.lam = lam
        self.value_coeff = value_coeff
        self.entropy_coeff = entropy_coeff
        self.clip_grad_norm = clip_grad_norm
        self.deterministic = deterministic

        obs_dim = env.observation_space.shape[0]
        if isinstance(env.action_space, gym.spaces.Discrete):
            action_dim = env.action_space.n
        else:
            raise NotImplementedError("Only discrete action spaces are supported.")

        if create_model:
            self.model = get_model("ac", arch_type, obs_dim, action_dim)
        else:
            self.model = None

        self.optimizer_actor = optim.Adam(self.model.actor_head.parameters(), lr=actor_lr)
        self.optimizer_critic = optim.Adam(self.model.critic_head.parameters(), lr=critic_lr)

        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model.to(self.device)

    def select_action(self, state):
        state = torch.tensor(state, dtype=torch.float32).unsqueeze(0).to(self.device)
        logits, value = self.model(state)
        if self.deterministic:
            action = torch.argmax(logits, dim=-1).item()
            log_prob = torch.log_softmax(logits, dim=-1)[0, action]
        else:
            probs = torch.softmax(logits, dim=-1)
            m = torch.distributions.Categorical(probs)
            action = m.sample().item()
            log_prob = m.log_prob(torch.tensor(action))
        return action, log_prob.detach().cpu().numpy(), value.detach().cpu().numpy()

    def collect_trajectories(self, num_steps):
        states, actions, rewards, dones, log_probs, values = [], [], [], [], [], []
        state = self.env.reset()
        for _ in range(num_steps):
            action, log_prob, value = self.select_action(state)
            next_state, reward, done, _ = self.env.step(action)
            states.append(state)
            actions.append(action)
            rewards.append(reward)
            dones.append(done)
            log_probs.append(log_prob)
            values.append(value)
            state = next_state
            if done:
                state = self.env.reset()
        return {
            "states": torch.tensor(states, dtype=torch.float32, device=self.device),
            "actions": torch.tensor(actions, dtype=torch.long, device=self.device),
            "rewards": torch.tensor(rewards, dtype=torch.float32, device=self.device),
            "dones": torch.tensor(dones, dtype=torch.float32, device=self.device),
            "log_probs": torch.tensor(log_probs, dtype=torch.float32, device=self.device),
            "values": torch.tensor(values, dtype=torch.float32, device=self.device),
        }

    def compute_returns_and_advantage(self, rewards, values, dones):
        returns = torch.zeros_like(rewards, device=self.device)
        advantages = torch.zeros_like(rewards, device=self.device)
        gae = 0.0
        next_value = 0.0
        for step in reversed(range(len(rewards))):
            delta = rewards[step] + self.gamma * next_value * (1 - dones[step]) - values[step]
            gae = delta + self.gamma * self.lam * (1 - dones[step]) * gae
            advantages[step] = gae
            next_value = values[step]
            returns[step] = advantages[step] + values[step]
        return returns, advantages

    def evaluate_actions(self, states, actions):
        logits, values = self.model(states)
        probs = torch.softmax(logits, dim=-1)
        m = torch.distributions.Categorical(probs)
        log_probs = m.log_prob(actions)
        entropy = m.entropy()
        return values, log_probs, entropy

    def get_traj_loss(self, trajectory):
        states = trajectory["states"]
        actions = trajectory["actions"]
        rewards = trajectory["rewards"]
        dones = trajectory["dones"]
        log_probs_old = trajectory["log_probs"]
        values_old = trajectory["values"]

        returns, advantages = self.compute_returns_and_advantage(rewards, values_old, dones)

        values, log_probs_new, entropy = self.evaluate_actions(states, actions)

        policy_loss = -torch.mean(advantages.detach() * log_probs_new)
        value_loss = self.value_coeff * torch.mean((returns - values).pow(2))
        entropy_loss = -self.entropy_coeff * torch.mean(entropy)

        total_loss = policy_loss + value_loss + entropy_loss
        return total_loss, policy_loss.item(), value_loss.item(), entropy.item()

    def update_parameters(self, loss, policy_loss, value_loss, entropy):
        self.optimizer_actor.zero_grad()
        self.optimizer_critic.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(self.model.parameters(), self.clip_grad_norm)
        self.optimizer_actor.step()
        self.optimizer_critic.step()
        return policy_loss, value_loss, entropy

    def train(self, total_steps, batch_size=128, log_interval=10):
        steps_done = 0
        while steps_done < total_steps:
            trajectory = self.collect_trajectories(batch_size)
            loss, p_loss, v_loss, ent = self.get_traj_loss(trajectory)
            self.update_parameters(loss, p_loss, v_loss, ent)
            steps_done += batch_size
            if steps_done % log_interval == 0:
                print(
                    f"Steps: {steps_done}, Policy Loss: {p_loss:.4f}, "
                    f"Value Loss: {v_loss:.4f}, Entropy: {ent:.4f}"
                )


if __name__ == "__main__":
    env = gym.make("CartPole-v1")
    agent = A2CAgent(env)
    agent.train(total_steps=10000, batch_size=64, log_interval=1000)