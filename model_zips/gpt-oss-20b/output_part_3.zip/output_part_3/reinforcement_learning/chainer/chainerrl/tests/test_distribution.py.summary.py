import pytest
import numpy as np
from scipy.stats import multivariate_normal
import chainer
from chainer import cuda
from chainer import Variable
from chainerrl import distributions
from chainerrl.distributions import (
    SoftmaxDistribution,
    MellowmaxDistribution,
    GaussianDistribution,
    SquashedGaussianDistribution,
    ContinuousDeterministicDistribution,
    sample_discrete_actions,
)

# Utility to get array module (numpy or cupy)
def get_module(x):
    return cuda.get_array_module(x)

# Utility to move tensor to gpu if available
def maybe_to_gpu(x, device):
    if device == 'gpu':
        return cuda.to_gpu(x)
    return x

# Check for cuda availability
has_cuda = cuda.available


@pytest.mark.parametrize("device", ['cpu'] + (['gpu'] if has_cuda else []))
def test_sample_discrete_actions(device):
    probs_cpu = np.array([[0.2, 0.3, 0.5],
                          [0.1, 0.6, 0.3],
                          [0.4, 0.4, 0.2]], dtype=np.float32)
    probs = maybe_to_gpu(probs_cpu, device)
    n_iter = 1000
    rng = chainer.get_random_state()
    counts = rng.randint(0, probs.shape[1], size=(n_iter, probs.shape[0]))
    for _ in range(n_iter):
        samples = sample_discrete_actions(probs, rng)
        samples_np = get_module(samples).get(samples).numpy()
        counts += samples_np
    empirical = counts / n_iter
    np.testing.assert_allclose(empirical, probs_cpu, rtol=0.05, atol=0.05)


@pytest.mark.parametrize("batch_size", [1, 3, 5])
@pytest.mark.parametrize("n", [2, 4, 8])
@pytest.mark.parametrize("wrapped", [False, True])
@pytest.mark.parametrize("beta", [0.1, 1.0, 5.0])
@pytest.mark.parametrize("min_prob", [0.0, 0.01, 0.05])
def test_softmax_distribution(batch_size, n, wrapped, beta, min_prob):
    logits_np = np.random.randn(batch_size, n).astype(np.float32)
    logits = Variable(logits_np) if wrapped else logits_np
    dist = SoftmaxDistribution(logits, beta=beta, min_prob=min_prob)
    rng = chainer.get_random_state()

    # Sampling
    samples = dist.sample(rng)
    assert samples.shape == (batch_size,)
    assert np.all((0 <= samples) & (samples < n))

    # Probabilities
    probs = dist.probs
    probs_np = probs.get() if isinstance(probs, Variable) else probs
    assert probs_np.shape == (batch_size, n)
    np.testing.assert_allclose(probs_np.sum(axis=1), 1.0, rtol=1e-5)

    # Log probabilities
    log_probs = dist.log_probs
    log_probs_np = log_probs.get() if isinstance(log_probs, Variable) else log_probs
    np.testing.assert_allclose(
        log_probs_np, np.log(probs_np + 1e-20), rtol=1e-5
    )

    # KL divergence
    kl = dist.kl(dist)
    np.testing.assert_allclose(kl, 0.0, atol=1e-6)

    # Copying
    copy_dist = dist.copy()
    assert copy_dist is not dist
    assert copy_dist.logits is dist.logits
    assert copy_dist.beta == dist.beta
    assert copy_dist.min_prob == dist.min_prob


@pytest.mark.parametrize("batch_size", [1, 3, 5])
@pytest.mark.parametrize("n", [2, 4, 8])
@pytest.mark.parametrize("wrapped", [False, True])
@pytest.mark.parametrize("beta", [0.1, 1.0, 5.0])
@pytest.mark.parametrize("min_prob", [0.0, 0.01, 0.05])
def test_mellowmax_distribution(batch_size, n, wrapped, beta, min_prob):
    logits_np = np.random.randn(batch_size, n).astype(np.float32)
    logits = Variable(logits_np) if wrapped else logits_np
    dist = MellowmaxDistribution(logits, beta=beta, min_prob=min_prob)
    rng = chainer.get_random_state()

    # Sampling
    samples = dist.sample(rng)
    assert samples.shape == (batch_size,)
    assert np.all((0 <= samples) & (samples < n))

    # Probabilities
    probs = dist.probs
    probs_np = probs.get() if isinstance(probs, Variable) else probs
    assert probs_np.shape == (batch_size, n)
    np.testing.assert_allclose(probs_np.sum(axis=1), 1.0, rtol=1e-5)

    # Log probabilities
    log_probs = dist.log_probs
    log_probs_np = log_probs.get() if isinstance(log_probs, Variable) else log_probs
    np.testing.assert_allclose(
        log_probs_np, np.log(probs_np + 1e-20), rtol=1e-5
    )

    # KL divergence
    kl = dist.kl(dist)
    np.testing.assert_allclose(kl, 0.0, atol=1e-6)

    # Copying
    copy_dist = dist.copy()
    assert copy_dist is not dist
    assert copy_dist.logits is dist.logits
    assert copy_dist.beta == dist.beta
    assert copy_dist.min_prob == dist.min_prob


@pytest.mark.parametrize("batch_size", [1, 2])
@pytest.mark.parametrize("dim", [1, 3])
def test_gaussian_distribution(batch_size, dim):
    mean_np = np.random.randn(batch_size, dim).astype(np.float32)
    var_np = np.abs(np.random.randn(batch_size, dim).astype(np.float32)) + 0.1
    mean = Variable(mean_np)
    var = Variable(var_np)
    dist = GaussianDistribution(mean, var)
    rng = chainer.get_random_state()

    # Sampling
    samples = dist.sample(rng)
    assert samples.shape == (batch_size, dim)

    # Most probable
    most_probable = dist.most_probable
    np.testing.assert_allclose(most_probable, mean_np, rtol=1e-5)

    # Probability / Log probability
    probs = dist.prob(samples)
    log_probs = dist.log_prob(samples)
    # Compare with scipy
    for i in range(batch_size):
        rv = multivariate_normal(mean=mean_np[i], cov=np.diag(var_np[i]))
        scipy_probs = rv.pdf(samples[i].get().numpy())
        scipy_log_probs = rv.logpdf(samples[i].get().numpy())
        np.testing.assert_allclose(probs[i].get().numpy(), scipy_probs, rtol=1e-4)
        np.testing.assert_allclose(log_probs[i].get().numpy(), scipy_log_probs, rtol=1e-4)

    # Entropy
    entropies = dist.entropy()
    for i in range(batch_size):
        k = dim
        theo = 0.5 * (k * (1 + np.log(2 * np.pi)) + np.log(np.prod(var_np[i])))
        np.testing.assert_allclose(entropies[i].get().numpy(), theo, rtol=1e-4)

    # KL divergence
    kl = dist.kl(dist)
    np.testing.assert_allclose(kl, 0.0, atol=1e-6)

    # Copying
    copy_dist = dist.copy()
    assert copy_dist is not dist
    assert copy_dist.mean is dist.mean
    assert copy_dist.var is dist.var


@pytest.mark.parametrize("batch_size", [1, 2])
@pytest.mark.parametrize("dim", [1, 3])
def test_squashed_gaussian_distribution(batch_size, dim):
    mean_np = np.random.randn(batch_size, dim).astype(np.float32)
    var_np = np.abs(np.random.randn(batch_size, dim).astype(np.float32)) + 0.1
    mean = Variable(mean_np)
    var = Variable(var_np)
    dist = SquashedGaussianDistribution(mean, var)
    rng = chainer.get_random_state()

    # Sampling
    samples = dist.sample(rng)
    samples_np = samples.get().numpy()
    assert samples_np.shape == (batch_size, dim)
    assert np.all(samples_np >= -1.0 - 1e-6)
    assert np.all(samples_np <= 1.0 + 1e-6)

    # Most probable
    most_probable = dist.most_probable
    expected = np.tanh(mean_np)
    np.testing.assert_allclose(most_probable.get().numpy(), expected, rtol=1e-4)

    # Sampling with log probability
    log_probs = dist.log_prob(samples)
    # Consistency check: log_prob of sample should equal log_prob computed directly
    # (No strict numerical equality but check shapes)
    assert log_probs.shape == (batch_size,)

    # Copying
    copy_dist = dist.copy()
    assert copy_dist is not dist
    assert copy_dist.mean is dist.mean
    assert copy_dist.var is dist.var

    # Methods not implemented
    with pytest.raises(NotImplementedError):
        dist.entropy()
    with pytest.raises(NotImplementedError):
        dist.kl(copy_dist)


@pytest.mark.parametrize("batch_size", [1, 2])
@pytest.mark.parametrize("dim", [1, 3])
def test_continuous_deterministic_distribution(batch_size, dim):
    values_np = np.random.randn(batch_size, dim).astype(np.float32)
    values = Variable(values_np)
    dist = ContinuousDeterministicDistribution(values)
    rng = chainer.get_random_state()

    # Sampling
    samples = dist.sample(rng)
    np.testing.assert_allclose(samples.get().numpy(), values_np, rtol=1e-6)

    # Most probable
    most_probable = dist.most_probable
    np.testing.assert_allclose(most_probable.get().numpy(), values_np, rtol=1e-6)

    # Copying
    copy_dist = dist.copy()
    assert copy_dist is not dist
    assert copy_dist.values is dist.values
