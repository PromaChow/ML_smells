import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import matplotlib.pyplot as plt

# Data preparation
t = np.linspace(0, 2 * np.pi, 20)
i1_1 = np.sin(t)
i1_2 = np.sin(t)
i2_1 = 2 * np.sin(t)
i2_2 = 2 * np.sin(t)

X_seq = np.concatenate([i1_1, i1_2, i2_1, i2_2])
t1 = np.ones(20)
t2 = np.full(20, 2.0)
Y_seq = np.concatenate([t1, t1, t2, t2])

X_tensor = torch.tensor(X_seq, dtype=torch.float32).unsqueeze(0).unsqueeze(2)  # (1, 80, 1)
Y_tensor = torch.tensor(Y_seq, dtype=torch.float32).unsqueeze(0).unsqueeze(2)  # (1, 80, 1)

# Network definition
class ElmanRNN(nn.Module):
    def __init__(self, input_size=1, hidden_size=10, output_size=1):
        super().__init__()
        self.rnn = nn.RNN(input_size, hidden_size, nonlinearity='tanh', batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        out, _ = self.rnn(x)
        out = self.fc(out)
        return out

model = ElmanRNN()
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.01)

# Training
max_epochs = 500
mse_history = []
for epoch in range(1, max_epochs + 1):
    model.train()
    optimizer.zero_grad()
    outputs = model(X_tensor)
    loss = criterion(outputs, Y_tensor)
    loss.backward()
    optimizer.step()
    mse = loss.item()
    mse_history.append(mse)
    if epoch % 100 == 0:
        print(f'Epoch {epoch}, MSE: {mse:.4f}')
    if mse < 0.01:
        print(f'MSE goal reached at epoch {epoch}')
        break

# Simulation
model.eval()
with torch.no_grad():
    predicted = model(X_tensor)

# Visualization
fig, axes = plt.subplots(2, 1, figsize=(10, 8))

axes[0].plot(mse_history, label='Training MSE')
axes[0].set_title('Training Error over Epochs')
axes[0].set_xlabel('Epoch')
axes[0].set_ylabel('MSE')
axes[0].legend()

x_axis = np.arange(80)
axes[1].plot(x_axis, Y_seq, label='Target', marker='o')
axes[1].plot(x_axis, predicted.squeeze().cpu().numpy(), label='Predicted', marker='x')
axes[1].set_title('Target vs Predicted Outputs')
axes[1].set_xlabel('Sample Index')
axes[1].set_ylabel('Amplitude')
axes[1].legend()

plt.tight_layout()
plt.show()