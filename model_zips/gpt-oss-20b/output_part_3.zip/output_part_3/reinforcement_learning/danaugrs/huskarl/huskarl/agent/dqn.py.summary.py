import numpy as np
import random
import tensorflow as tf
from collections import deque, namedtuple

Transition = namedtuple('Transition', ['state', 'action', 'reward', 'next_state', 'done'])

class PrioritizedExperienceReplay:
    def __init__(self, capacity, alpha=0.6, nsteps=1, gamma=0.99):
        self.capacity = capacity
        self.alpha = alpha
        self.nsteps = nsteps
        self.gamma = gamma
        self.buffer = []
        self.priorities = np.zeros((capacity,), dtype=np.float32)
        self.position = 0
        self.size = 0
        self.n_step_buffer = deque(maxlen=nsteps)

    def push(self, *args):
        transition = Transition(*args)
        self.n_step_buffer.append(transition)
        if len(self.n_step_buffer) == self.nsteps:
            state, action = self.n_step_buffer[0].state, self.n_step_buffer[0].action
            reward, next_state, done = self._get_n_step_info()
            idx = self.position
            if idx >= self.capacity:
                self.buffer[idx % self.capacity] = (state, action, reward, next_state, done)
            else:
                self.buffer.append((state, action, reward, next_state, done))
            max_prio = self.priorities.max() if self.size > 0 else 1.0
            self.priorities[idx] = max_prio
            self.position = (self.position + 1) % self.capacity
            self.size = min(self.size + 1, self.capacity)

    def _get_n_step_info(self):
        reward, next_state, done = 0.0, self.n_step_buffer[-1].next_state, self.n_step_buffer[-1].done
        for idx, trans in enumerate(self.n_step_buffer):
            reward += (self.gamma ** idx) * trans.reward
        return reward, next_state, done

    def sample(self, batch_size, beta=0.4):
        if self.size == 0:
            return [], [], [], [], [], []
        probs = self.priorities[:self.size] ** self.alpha
        probs /= probs.sum()
        indices = np.random.choice(self.size, batch_size, p=probs)
        samples = [self.buffer[idx] for idx in indices]
        weights = (self.size * probs[indices]) ** (-beta)
        weights /= weights.max()
        batch = Transition(*zip(*samples))
        return batch.state, batch.action, batch.reward, batch.next_state, batch.done, indices, weights

    def update_priorities(self, indices, priorities):
        for idx, prio in zip(indices, priorities):
            self.priorities[idx] = prio + 1e-6

class DQNAgent:
    def __init__(
        self,
        model,
        action_size,
        optimizer=None,
        policy=None,
        memory_capacity=100000,
        nsteps=1,
        gamma=0.99,
        dueling=False,
        dueling_type='max',
        target_update=0.001,
        double_dqn=False,
        epsilon=0.1,
        epsilon_decay=0.995,
        epsilon_min=0.01,
    ):
        self.model = model
        self.action_size = action_size
        self.optimizer = optimizer or tf.keras.optimizers.Adam()
        self.policy = policy
        self.gamma = gamma
        self.dueling = dueling
        self.dueling_type = dueling_type
        self.target_update = target_update
        self.double_dqn = double_dqn
        self.epsilon = epsilon
        self.epsilon_decay = epsilon_decay
        self.epsilon_min = epsilon_min
        self.memory = PrioritizedExperienceReplay(memory_capacity, nsteps, gamma)
        self.update_target_network(hard=True)

    def build_dueling_model(self):
        last_layer = self.model.layers[-1]
        x = tf.keras.layers.Dense(self.action_size + 1, activation='linear')(last_layer.output)
        def dueling_combination(x):
            value = x[..., :1]
            adv = x[..., 1:]
            if self.dueling_type == 'average':
                adv_mean = tf.reduce_mean(adv, axis=-1, keepdims=True)
                return value + adv - adv_mean
            elif self.dueling_type == 'max':
                adv_max = tf.reduce_max(adv, axis=-1, keepdims=True)
                return value + adv - adv_max
            else:  # naive
                return value + adv
        q_values = tf.keras.layers.Lambda(dueling_combination)(x)
        new_model = tf.keras.Model(inputs=self.model.input, outputs=q_values)
        new_model.compile(optimizer=self.optimizer, loss=self.loss_function)
        self.model = new_model

    def loss_function(self, y_true, y_pred):
        q_values = tf.reduce_sum(y_true * y_pred, axis=1)
        target_q = tf.reduce_sum(y_true * y_pred, axis=1)
        mse = tf.reduce_mean(tf.square(q_values - target_q))
        return mse

    def update_target_network(self, hard=True):
        if hard:
            self.target_model = tf.keras.models.clone_model(self.model)
            self.target_model.set_weights(self.model.get_weights())
        else:
            if not hasattr(self, 'target_model'):
                self.target_model = tf.keras.models.clone_model(self.model)
                self.target_model.set_weights(self.model.get_weights())
            for target_w, online_w in zip(self.target_model.weights, self.model.weights):
                target_w.assign(self.target_update * online_w + (1 - self.target_update) * target_w)

    def train_step(self, batch_size, beta=0.4):
        states, actions, rewards, next_states, dones, indices, weights = self.memory.sample(batch_size, beta)
        states = np.array(states)
        next_states = np.array(next_states)
        actions = np.array(actions)
        rewards = np.array(rewards, dtype=np.float32)
        dones = np.array(dones, dtype=np.float32)
        weights = np.array(weights, dtype=np.float32)

        next_q = self.target_model.predict(next_states, verbose=0)
        if self.double_dqn:
            online_next_q = self.model.predict(next_states, verbose=0)
            next_actions = np.argmax(online_next_q, axis=1)
            target_q = rewards + self.gamma * next_q[np.arange(batch_size), next_actions] * (1 - dones)
        else:
            target_q = rewards + self.gamma * np.max(next_q, axis=1) * (1 - dones)

        target_q = tf.convert_to_tensor(target_q, dtype=tf.float32)
        target_q = tf.expand_dims(target_q, axis=-1)
        mask = tf.one_hot(actions, self.action_size)

        with tf.GradientTape() as tape:
            q_pred = self.model(states, training=True)
            q_values = tf.reduce_sum(mask * q_pred, axis=1)
            td_errors = target_q - q_values
            loss = tf.reduce_mean(tf.square(td_errors) * weights)
        grads = tape.gradient(loss, self.model.trainable_variables)
        self.optimizer.apply_gradients(zip(grads, self.model.trainable_variables))

        new_priorities = np.abs(td_errors.numpy()) + 1e-6
        self.memory.update_priorities(indices, new_priorities)

        if np.random.rand() < self.target_update:
            self.update_target_network(hard=self.target_update >= 1)

    def act(self, state, training=True):
        if training and np.random.rand() < self.epsilon:
            return random.randrange(self.action_size)
        q_values = self.model.predict(np.array([state]), verbose=0)
        return np.argmax(q_values[0])

    def store_transition(self, state, action, reward, next_state, done):
        self.memory.push(state, action, reward, next_state, done)

    def decay_epsilon(self):
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay
        self.epsilon = max(self.epsilon, self.epsilon_min)
```