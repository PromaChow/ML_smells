import warnings

import numpy as np
import pandas as pd
import geopandas as gpd
from shapely.geometry import Polygon
from scipy.sparse import csc_matrix, csgraph


def check_weights(W, X=None):
    """
    Validates the weight matrix W and optionally checks compatibility with data matrix X.

    Parameters
    ----------
    W : array-like or sparse matrix
        Weight matrix with shape (n_samples, n_samples).
    X : array-like or None, optional
        Data matrix with shape (n_samples, n_features). If provided, the number of
        rows in X must match the number of rows in W.

    Returns
    -------
    W_csc : scipy.sparse.csc_matrix
        Sparse CSC matrix representation of W with zero entries removed.
    n_components : int
        Number of connected components in the graph defined by W.
    """
    # Convert to sparse CSC
    if not hasattr(W, "tocsc"):
        W_csc = csc_matrix(W)
    else:
        W_csc = W.tocsc(copy=False)

    # Ensure zero entries are not stored
    W_csc.eliminate_zeros()

    # Compatibility check with X
    if X is not None:
        if W_csc.shape[0] != X.shape[0]:
            raise ValueError("Number of rows in W must match number of rows in X.")

    # Compute connected components
    n_components, labels = csgraph.connected_components(W_csc, directed=False, connection='strong')
    if n_components > 1:
        warnings.warn(
            f"The weight graph is disconnected with {n_components} components. "
            "Downstream computations may be affected.",
            RuntimeWarning,
        )

    return W_csc, n_components


def lattice(x, y):
    """
    Creates a GeoDataFrame of unit squares arranged in a grid of size x by y.

    Parameters
    ----------
    x : int
        Number of squares along the x-axis.
    y : int
        Number of squares along the y-axis.

    Returns
    -------
    gdf : geopandas.GeoDataFrame
        GeoDataFrame where each row corresponds to a unit square polygon.
    """
    polygons = []
    ids = []
    for i in range(x):
        for j in range(y):
            # Coordinates of the square corners
            corners = [(i, j), (i + 1, j), (i + 1, j + 1), (i, j + 1)]
            polygons.append(Polygon(corners))
            ids.append(f"sq_{i}_{j}")

    gdf = gpd.GeoDataFrame({"id": ids, "geometry": polygons})
    return gdf


def p_connected(Y, n_rep=None):
    """
    Calculates the pairwise probability that any two observations are clustered together
    across multiple replications of labelings.

    Parameters
    ----------
    Y : array-like of shape (n_rep, n_obs)
        Replicated labelings. Each row corresponds to a replication; each column to an observation.
    n_rep : int or None, optional
        Number of replications. If None, inferred from the shape of Y.

    Returns
    -------
    prob_matrix : np.ndarray of shape (n_obs, n_obs)
        Probability matrix where entry (i, j) is the fraction of replications in which
        observations i and j share the same label.
    """
    Y = np.asarray(Y)
    if Y.ndim != 2:
        raise ValueError("Y must be a 2D array with shape (n_rep, n_obs).")

    n_rep, n_obs = Y.shape
    if n_rep == 0 or n_obs == 0:
        raise ValueError("Y must contain at least one replication and one observation.")

    # Broadcast to compute equality across all pairs for each replication
    # Y_expanded: (n_rep, n_obs, 1)
    Y_expanded = Y[:, :, np.newaxis]
    # Y_t_expanded: (n_rep, 1, n_obs)
    Y_t_expanded = Y[:, np.newaxis, :]
    equal_matrix = (Y_expanded == Y_t_expanded).astype(float)  # shape (n_rep, n_obs, n_obs)

    # Sum across replications
    sum_matrix = np.sum(equal_matrix, axis=0)  # shape (n_obs, n_obs)

    # Normalize by number of replications to get probability
    prob_matrix = sum_matrix / n_rep

    return prob_matrix

__all__ = ["check_weights", "lattice", "p_connected"]