import numpy as np

class Walker2D(WalkerBase, MJCFBasedRobot):
    def __init__(self):
        WalkerBase.__init__(self, power=0.4)
        MJCFBasedRobot.__init__(
            self,
            xml_file="walker2d.xml",
            reference="torso",
            action_dim=6,
            obs_dim=17,
            ignored_joints=True,
        )
        self.pos_before = 0.0

    def calc_state(self):
        qpos = self.qpos
        qvel = self.qvel
        clipped_qvel = np.clip(qvel, -10.0, 10.0)
        state = np.concatenate([qpos[1:], clipped_qvel])
        return state

    def calc_potential(self):
        pos_before = self.pos_before
        pos_after = self.pos_after
        dt = self.scene.dt
        potential = (pos_after - pos_before) / dt
        self.pos_before = pos_after
        return potential

    def robot_specific_reset(self):
        self.joint_power["foot_joint"] = 30.0
        self.joint_power["foot_left_joint"] = 30.0
        super().robot_specific_reset() if hasattr(super(), "robot_specific_reset") else None