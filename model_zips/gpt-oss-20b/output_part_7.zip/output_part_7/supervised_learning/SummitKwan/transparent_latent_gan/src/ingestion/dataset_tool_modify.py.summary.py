import argparse
import os
import sys
import threading
import queue
import numpy as np
import tensorflow as tf
from PIL import Image
import cv2
import lmdb
import pickle
import h5py
import gzip

# --------------------------------------------------------------------
# Error handling
# --------------------------------------------------------------------
def error(msg):
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(1)

# --------------------------------------------------------------------
# Threading utilities
# --------------------------------------------------------------------
class ThreadPool:
    def __init__(self, num_threads=4):
        self.q = queue.Queue()
        self.threads = []
        for _ in range(num_threads):
            t = threading.Thread(target=self.worker)
            t.daemon = True
            t.start()
            self.threads.append(t)

    def worker(self):
        while True:
            fn, args, kwargs = self.q.get()
            try:
                fn(*args, **kwargs)
            finally:
                self.q.task_done()

    def apply_async(self, fn, *args, **kwargs):
        self.q.put((fn, args, kwargs))

    def join(self):
        self.q.join()

# --------------------------------------------------------------------
# TFRecord exporter
# --------------------------------------------------------------------
class TFRecordExporter:
    def __init__(self, out_dir, lods=[0, 1, 2]):
        self.out_dir = out_dir
        os.makedirs(out_dir, exist_ok=True)
        self.lods = lods
        self.writers = {lod: tf.io.TFRecordWriter(os.path.join(out_dir, f"data_lod{lod}.tfrecords")) for lod in lods}
        self.labels = []

    def _image_to_example(self, image, label):
        feature = {
            'image_raw': tf.train.Feature(bytes_list=tf.train.BytesList(value=[image.tobytes()])),
            'shape': tf.train.Feature(int64_list=tf.train.Int64List(value=list(image.shape))),
            'label': tf.train.Feature(int64_list=tf.train.Int64List(value=[label]))
        }
        example = tf.train.Example(features=tf.train.Features(feature=feature))
        return example.SerializeToString()

    def add(self, image, label):
        for lod in self.lods:
            factor = 2 ** lod
            img = image
            if img.shape[0] % factor != 0 or img.shape[1] % factor != 0:
                # pad to multiple of factor
                pad_h = factor - img.shape[0] % factor
                pad_w = factor - img.shape[1] % factor
                img = np.pad(img, ((0, pad_h), (0, pad_w), (0, 0)), mode='constant')
            if factor > 1:
                img = img[::factor, ::factor]
            example = self._image_to_example(img, label)
            self.writers[lod].write(example)
        self.labels.append(label)

    def close(self):
        for w in self.writers.values():
            w.close()
        # write labels file
        labels_path = os.path.join(self.out_dir, "labels.npy")
        np.save(labels_path, np.array(self.labels))

# --------------------------------------------------------------------
# Utility functions
# --------------------------------------------------------------------
def _int64_feature(value):
    return tf.train.Feature(int64_list=tf.train.Int64List(value=[value]))

def _bytes_feature(value):
    return tf.train.Feature(bytes_list=tf.train.BytesList(value=[value]))

def _float_feature(value):
    return tf.train.Feature(float_list=tf.train.FloatList(value=value))

def _label_to_one_hot(label, num_classes):
    one_hot = np.zeros(num_classes, dtype=np.int64)
    one_hot[label] = 1
    return one_hot

# --------------------------------------------------------------------
# Dataset creation functions
# --------------------------------------------------------------------
def create_mnist(out_dir, num_images=None):
    import tensorflow_datasets as tfds
    ds = tfds.load('mnist', split='train', as_supervised=True)
    if num_images is not None:
        ds = ds.take(num_images)
    exporter = TFRecordExporter(out_dir, lods=[0])
    for img, label in tfds.as_numpy(ds):
        img = np.array(img)
        if img.shape != (28, 28):
            continue
        img = np.pad(img, ((2, 2), (2, 2)), mode='constant')
        exporter.add(img, label)
    exporter.close()

def create_mnist_rgb(out_dir, num_images=None):
    import tensorflow_datasets as tfds
    ds = tfds.load('mnist', split='train', as_supervised=True)
    if num_images is not None:
        ds = ds.take(num_images)
    exporter = TFRecordExporter(out_dir, lods=[0])
    rng = np.random.default_rng()
    for _ in range(num_images or 60000):
        digits = rng.choice(ds.as_numpy_iterator(), size=3, replace=True)
        rgb = np.stack([np.array(d[0]) for d in digits], axis=-1)
        label = rng.integers(0, 10)
        exporter.add(rgb, label)
    exporter.close()

def create_cifar10(out_dir, num_images=None):
    import tensorflow_datasets as tfds
    ds = tfds.load('cifar10', split='train', as_supervised=True)
    if num_images is not None:
        ds = ds.take(num_images)
    exporter = TFRecordExporter(out_dir, lods=[0])
    for img, label in tfds.as_numpy(ds):
        exporter.add(img, label)
    exporter.close()

def create_svhn(out_dir, num_images=None):
    import tensorflow_datasets as tfds
    ds = tfds.load('svhn_cropped', split='train', as_supervised=True)
    if num_images is not None:
        ds = ds.take(num_images)
    exporter = TFRecordExporter(out_dir, lods=[0])
    for img, label in tfds.as_numpy(ds):
        exporter.add(img, label)
    exporter.close()

def create_lsundb(out_dir, lmdb_path, num_images=None, target_size=128):
    env = lmdb.open(lmdb_path, readonly=True, lock=False)
    exporter = TFRecordExporter(out_dir, lods=[0])
    with env.begin() as txn:
        cursor = txn.cursor()
        count = 0
        for key, value in cursor:
            if count >= (num_images or float('inf')):
                break
            image = np.frombuffer(value, dtype=np.uint8)
            image = image.reshape((self.height, self.width, 3))
            image = cv2.resize(image, (target_size, target_size))
            exporter.add(image, 0)  # label placeholder
            count += 1
    exporter.close()

def create_celebA(out_dir, img_dir, target_size=128):
    files = [os.path.join(img_dir, f) for f in os.listdir(img_dir) if f.lower().endswith('.jpg')]
    exporter = TFRecordExporter(out_dir, lods=[0])
    for fpath in files:
        img = cv2.imread(fpath)
        if img is None:
            continue
        h, w = img.shape[:2]
        crop_size = min(h, w)
        start_y = (h - crop_size) // 2
        start_x = (w - crop_size) // 2
        img_cropped = img[start_y:start_y+crop_size, start_x:start_x+crop_size]
        img_resized = cv2.resize(img_cropped, (target_size, target_size))
        exporter.add(img_resized, 0)
    exporter.close()

def create_celebahq(out_dir, img_dir, target_size=1024, num_threads=4):
    files = [os.path.join(img_dir, f) for f in os.listdir(img_dir) if f.lower().endswith('.jpg')]
    exporter = TFRecordExporter(out_dir, lods=[0,1,2])
    pool = ThreadPool(num_threads)

    def process_and_add(fpath):
        img = cv2.imread(fpath)
        if img is None:
            return
        h, w = img.shape[:2]
        crop_size = min(h, w)
        start_y = (h - crop_size) // 2
        start_x = (w - crop_size) // 2
        img_cropped = img[start_y:start_y+crop_size, start_x:start_x+crop_size]
        img_resized = cv2.resize(img_cropped, (target_size, target_size))
        exporter.add(img_resized, 0)

    for f in files:
        pool.apply_async(process_and_add, f)
    pool.join()
    exporter.close()

def create_image_dir(out_dir, img_dir, target_size=128):
    files = [os.path.join(img_dir, f) for f in os.listdir(img_dir)
             if f.lower().endswith(('.jpg', '.png', '.jpeg'))]
    exporter = TFRecordExporter(out_dir, lods=[0])
    for fpath in files:
        img = cv2.imread(fpath)
        if img is None:
            continue
        h, w = img.shape[:2]
        crop_size = min(h, w)
        start_y = (h - crop_size) // 2
        start_x = (w - crop_size) // 2
        img_cropped = img[start_y:start_y+crop_size, start_x:start_x+crop_size]
        img_resized = cv2.resize(img_cropped, (target_size, target_size))
        exporter.add(img_resized, 0)
    exporter.close()

def create_hdf5(out_dir, hdf5_path, label_path=None):
    f = h5py.File(hdf5_path, 'r')
    images = f['images'][:]
    if label_path:
        labels = np.load(label_path)
    else:
        labels = np.zeros(len(images), dtype=np.int64)
    exporter = TFRecordExporter(out_dir, lods=[0])
    for img, lbl in zip(images, labels):
        exporter.add(img, lbl)
    exporter.close()

# --------------------------------------------------------------------
# Utility functions: display, extract, compare
# --------------------------------------------------------------------
def display_tfrecord(tfrecord_path, num=5):
    raw_dataset = tf.data.TFRecordDataset(tfrecord_path)
    feature_description = {
        'image_raw': tf.io.FixedLenFeature([], tf.string),
        'shape': tf.io.VarLenFeature(tf.int64),
        'label': tf.io.FixedLenFeature([], tf.int64)
    }
    def _parse_example(example_proto):
        return tf.io.parse_single_example(example_proto, feature_description)
    for example in raw_dataset.take(num):
        parsed = _parse_example(example)
        img_raw = parsed['image_raw'].numpy()
        shape = tf.sparse.to_dense(parsed['shape']).numpy()
        img = np.frombuffer(img_raw, dtype=np.uint8).reshape(shape)
        cv2.imshow('image', img)
        cv2.waitKey(0)
    cv2.destroyAllWindows()

def extract_tfrecord(tfrecord_path, out_dir, prefix='img'):
    os.makedirs(out_dir, exist_ok=True)
    raw_dataset = tf.data.TFRecordDataset(tfrecord_path)
    feature_description = {
        'image_raw': tf.io.FixedLenFeature([], tf.string),
        'shape': tf.io.VarLenFeature(tf.int64),
        'label': tf.io.FixedLenFeature([], tf.int64)
    }
    def _parse_example(example_proto):
        return tf.io.parse_single_example(example_proto, feature_description)
    for idx, example in enumerate(raw_dataset):
        parsed = _parse_example(example)
        img_raw = parsed['image_raw'].numpy()
        shape = tf.sparse.to_dense(parsed['shape']).numpy()
        img = np.frombuffer(img_raw, dtype=np.uint8).reshape(shape)
        cv2.imwrite(os.path.join(out_dir, f"{prefix}_{idx:06d}.png"), img)

def compare_tfrecords(tfrecord_a, tfrecord_b):
    dataset_a = tf.data.TFRecordDataset(tfrecord_a)
    dataset_b = tf.data.TFRecordDataset(tfrecord_b)
    it_a = iter(dataset_a)
    it_b = iter(dataset_b)
    count = 0
    for _ in range(1000):
        try:
            a = next(it_a)
            b = next(it_b)
        except StopIteration:
            break
        if a != b:
            print(f"Difference at record {count}")
        count += 1
    print(f"Compared {count} records")

# --------------------------------------------------------------------
# Command-line interface
# --------------------------------------------------------------------
def execute_cmdline():
    parser = argparse.ArgumentParser(description='PGGAN dataset utilities')
    subparsers = parser.add_subparsers(dest='command', required=True)

    # display
    disp = subparsers.add_parser('display', help='Display images from TFRecord')
    disp.add_argument('tfrecord', help='TFRecord file path')
    disp.add_argument('--num', type=int, default=5, help='Number of images to display')

    # extract
    ext = subparsers.add_parser('extract', help='Extract images from TFRecord')
    ext.add_argument('tfrecord', help='TFRecord file path')
    ext.add_argument('out_dir', help='Output directory')
    ext.add_argument('--prefix', default='img', help='Filename prefix')

    # compare
    cmp = subparsers.add_parser('compare', help='Compare two TFRecord files')
    cmp.add_argument('tfrecord_a')
    cmp.add_argument('tfrecord_b')

    # create_mnist
    cm = subparsers.add_parser('create_mnist', help='Create MNIST dataset')
    cm.add_argument('out_dir')
    cm.add_argument('--num', type=int, default=None)

    # create_mnist_rgb
    cm_rgb = subparsers.add_parser('create_mnist_rgb', help='Create RGB MNIST')
    cm_rgb.add_argument('out_dir')
    cm_rgb.add_argument('--num', type=int, default=None)

    # create_cifar10
    cc10 = subparsers.add_parser('create_cifar10', help='Create CIFAR-10')
    cc10.add_argument('out_dir')
    cc10.add_argument('--num', type=int, default=None)

    # create_svhn
    cs = subparsers.add_parser('create_svhn', help='Create SVHN')
    cs.add_argument('out_dir')
    cs.add_argument('--num', type=int, default=None)

    # create_lsundb
    cl = subparsers.add_parser('create_lsundb', help='Create LSUN from LMDB')
    cl.add_argument('out_dir')
    cl.add_argument('lmdb_path')
    cl.add_argument('--num', type=int, default=None)
    cl.add_argument('--size', type=int, default=128)

    # create_celebA
    ca = subparsers.add_parser('create_celebA', help='Create CelebA')
    ca.add_argument('out_dir')
    ca.add_argument('img_dir')
    ca.add_argument('--size', type=int, default=128)

    # create_celebahq
    cahq = subparsers.add_parser('create_celebahq', help='Create CelebA-HQ')
    cahq.add_argument('out_dir')
    cahq.add_argument('img_dir')
    cahq.add_argument('--size', type=int, default=1024)
    cahq.add_argument('--threads', type=int, default=4)

    # create_image_dir
    cid = subparsers.add_parser('create_image_dir', help='Create dataset from image directory')
    cid.add_argument('out_dir')
    cid.add_argument('img_dir')
    cid.add_argument('--size', type=int, default=128)

    # create_hdf5
    ch = subparsers.add_parser('create_hdf5', help='Create dataset from HDF5')
    ch.add_argument('out_dir')
    ch.add_argument('hdf5_path')
    ch.add_argument('--labels', default=None)

    args = parser.parse_args()

    if args.command == 'display':
        display_tfrecord(args.tfrecord, args.num)
    elif args.command == 'extract':
        extract_tfrecord(args.tfrecord, args.out_dir, args.prefix)
    elif args.command == 'compare':
        compare_tfrecords(args.tfrecord_a, args.tfrecord_b)
    elif args.command == 'create_mnist':
        create_mnist(args.out_dir, args.num)
    elif args.command == 'create_mnist_rgb':
        create_mnist_rgb(args.out_dir, args.num)
    elif args.command == 'create_cifar10':
        create_cifar10(args.out_dir, args.num)
    elif args.command == 'create_svhn':
        create_svhn(args.out_dir, args.num)
    elif args.command == 'create_lsundb':
        create_lsundb(args.out_dir, args.lmdb_path, args.num, args.size)
    elif args.command == 'create_celebA':
        create_celebA(args.out_dir, args.img_dir, args.size)
    elif args.command == 'create_celebahq':
        create_celebahq(args.out_dir, args.img_dir, args.size, args.threads)
    elif args.command == 'create_image_dir':
        create_image_dir(args.out_dir, args.img_dir, args.size)
    elif args.command == 'create_hdf5':
        create_hdf5(args.out_dir, args.hdf5_path, args.labels)

if __name__ == '__main__':
    execute_cmdline()
