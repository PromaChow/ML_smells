import numpy as np

arr = np.arange(0, 10)
modified = [x * -1 if 3 < x < 9 else x for x in arr]
print(modified)