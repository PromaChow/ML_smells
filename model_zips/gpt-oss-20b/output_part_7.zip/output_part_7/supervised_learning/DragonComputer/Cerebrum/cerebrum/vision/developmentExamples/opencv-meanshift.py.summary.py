import argparse
import cv2
import numpy as np
import datetime
import os

def main():
    parser = argparse.ArgumentParser(description="MeanShift object tracking")
    parser.add_argument('video', nargs='?', default=None, help='Path to video file')
    args = parser.parse_args()

    cap = cv2.VideoCapture(args.video if args.video else 0)
    if not cap.isOpened():
        print("Error: Could not open video source.")
        return

    ret, frame = cap.read()
    if not ret:
        print("Error: Could not read the first frame.")
        cap.release()
        return

    c, r, w, h = 400, 250, 125, 90
    track_window = (c, r, w, h)

    roi = frame[r:r+h, c:c+w]
    hsv_roi = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv_roi, np.array([0, 60, 32]), np.array([180, 255, 255]))
    hist = cv2.calcHist([hsv_roi], [0], mask, [180], [0, 180])
    cv2.normalize(hist, hist, 0, 255, cv2.NORM_MINMAX)

    term_crit = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 10, 1)

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        back_proj = cv2.calcBackProject([hsv], [0], hist, [0, 180], 1)

        ret, track_window = cv2.meanShift(back_proj, track_window, term_crit)
        x, y, w, h = track_window
        tracked_frame = frame.copy()
        cv2.rectangle(tracked_frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

        cv2.imshow('img2', tracked_frame)
        key = cv2.waitKey(1) & 0xFF
        if key == 27:  # ESC key
            break
        elif key == ord('s'):
            filename = f"frame_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg"
            cv2.imwrite(filename, tracked_frame)
            print(f"Saved {filename}")

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()