import os
import tempfile

import numpy as np
import chainer
from chainer import Variable

import chainerrl
from chainerrl import misc
from chainerrl import distributions


def _assert_eq_var_list(actual, expected, msg=''):
    assert len(actual) == len(expected), f'{msg} length mismatch: {actual} vs {expected}'
    for act, exp in zip(actual, expected):
        assert isinstance(act, Variable), f'{msg} element {act} is not Variable'
        assert act is exp, f'{msg} element {act} not same as expected {exp}'


class TestCollectVariables:
    @staticmethod
    def _make_var(arr):
        return Variable(np.array(arr, dtype=np.float32))

    @staticmethod
    def _make_dav():
        return chainerrl.DiscreteActionValue(3)

    @staticmethod
    def _make_qav():
        return chainerrl.QuadraticActionValue(3)

    @staticmethod
    def _make_sdis():
        return distributions.SoftmaxDistribution(np.array([0.1, 0.2, 0.3]))

    @staticmethod
    def _make_gdis():
        return distributions.GaussianDistribution(np.zeros(2), np.ones(2))

    @pytest.mark.parametrize(
        "obj,expected",
        [
            (_make_var([1, 2, 3]), [_make_var([1, 2, 3])]),
            ([_make_var([1, 2])], [_make_var([1, 2])]),
            ((_make_var([1]),), [_make_var([1])]),
            ([], []),
            ([ _make_var([1]), [_make_var([2])] ], [_make_var([1]), _make_var([2])]),
            ([_make_var([1]), _make_dav(), _make_qav()], [_make_var([1])]),
            (_make_sdis(), []),
            (_make_gdis(), []),
            ([ _make_sdis(), _make_gdis() ], []),
            ([_make_var([1]), (_make_var([2]), _make_var([3]))], [_make_var([1]), _make_var([2]), _make_var([3])]),
        ]
    )
    def test_collect_variables(self, obj, expected):
        actual = misc.collect_variables(obj)
        _assert_eq_var_list(actual, expected)


class TestDrawComputationalGraph:
    def test_draw_computational_graph(self):
        x = Variable(np.array([1.0, 2.0, 3.0]))
        y = x ** 2 + Variable(np.ones(5))
        tmpdir = tempfile.mkdtemp()
        try:
            gv_path = os.path.join(tmpdir, 'graph.gv')
            png_path = os.path.join(tmpdir, 'graph.png')
            misc.draw_computational_graph(y, gv_path)
            assert os.path.isfile(gv_path), 'Graphviz .gv file was not created'
            if misc.is_graphviz_available():
                assert os.path.isfile(png_path), 'Graphviz .png file was not created'
        finally:
            # Clean up temporary directory
            for f in os.listdir(tmpdir):
                os.remove(os.path.join(tmpdir, f))
            os.rmdir(tmpdir)