import pandas as pd

# Read the original text file into a DataFrame
df = pd.read_csv("data_file.txt")

# Export the DataFrame to a new CSV file, preserving the original data
df.to_csv("data_file.csv", index=False)