import numpy as np

def numpify(x):
    return np.asarray(x, dtype=np.float32)

def td0_error(gamma, Rs, Vs, last_V, reach_terminal):
    """Compute TD(0) error: δ = r + γ * V_{t+1} - V_t.
    For terminal states V_{t+1} = 0, otherwise V_{t+1} = last_V.
    """
    next_v = (1.0 - reach_terminal) * last_V
    return Rs + gamma * next_v - Vs

def clip_rho(rhos, clip=1.0):
    """Clip importance sampling ratios."""
    return np.minimum(rhos, clip)

def clip_pg_rho(rhos, clip=1.0):
    """Clip policy gradient importance sampling ratios."""
    return np.minimum(rhos, clip)

def vtrace(behavior_logprobs, target_logprobs, Rs, Vs, last_V, reach_terminal, gamma):
    # 1. Input conversion
    behavior_logprobs = numpify(behavior_logprobs)
    target_logprobs   = numpify(target_logprobs)
    Rs                = numpify(Rs)
    Vs                = numpify(Vs)
    last_V            = numpify(last_V)
    reach_terminal    = numpify(reach_terminal)

    # 2. Validation
    for arr in (behavior_logprobs, target_logprobs, Rs, Vs, reach_terminal):
        assert arr.ndim == 1, "Input tensors must be 1D"
    assert np.isscalar(gamma), "Gamma must be a scalar"

    length = len(behavior_logprobs)
    assert all(len(arr) == length for arr in (target_logprobs, Rs, Vs, reach_terminal)), "Mismatched input lengths"

    # 3. Ratio calculation
    rhos = np.exp(target_logprobs - behavior_logprobs)

    # 4. Clipping
    clipped_rhos = clip_rho(rhos)
    cs = np.minimum(rhos, 1.0)

    # 5. Delta calculation
    deltas = clipped_rhos * td0_error(gamma, Rs, Vs, last_V, reach_terminal)

    # 6. Backward pass
    vs_minus_V = np.empty_like(deltas)
    total = 0.0
    for t in reversed(range(length)):
        total = deltas[t] + gamma * cs[t] * total
        vs_minus_V[t] = total

    # 7. Value estimation
    vs = vs_minus_V + Vs

    # 8. Next-step values
    if length > 1:
        vs_next = np.concatenate([vs[1:], np.array([(1.0 - reach_terminal[-1]) * last_V], dtype=np.float32)])
    else:
        vs_next = np.array([(1.0 - reach_terminal[0]) * last_V], dtype=np.float32)

    # 9. Policy gradient clipping
    clipped_pg_rhos = clip_pg_rho(rhos)

    # 10. Advantage calculation
    As = clipped_pg_rhos * (Rs + gamma * vs_next - Vs)

    # 11. Output
    return vs, As

# Example usage (replace with real data)
if __name__ == "__main__":
    # Dummy data
    N = 5
    behavior_logprobs = np.random.randn(N)
    target_logprobs   = np.random.randn(N)
    Rs                = np.random.randn(N)
    Vs                = np.random.randn(N)
    last_V            = np.random.randn()
    reach_terminal    = np.zeros(N, dtype=np.float32)
    gamma             = 0.99

    vs, As = vtrace(behavior_logprobs, target_logprobs, Rs, Vs, last_V, reach_terminal, gamma)
    print("vs:", vs)
    print("As:", As)