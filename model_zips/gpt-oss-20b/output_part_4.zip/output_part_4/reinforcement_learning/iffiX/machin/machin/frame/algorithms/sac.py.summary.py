import os
import yaml
import math
import random
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.distributions import Normal, Independent, Normal, Uniform
from torch.utils.data import Dataset, DataLoader
from dataclasses import dataclass, field
from typing import Any, Dict, List, Tuple, Optional

try:
    from torchviz import make_dot
except ImportError:
    make_dot = None


# -------------------- Configuration --------------------
@dataclass
class SACConfig:
    state_dim: int
    action_dim: int
    hidden_sizes: Tuple[int, int] = (256, 256)
    actor_lr: float = 3e-4
    critic_lr: float = 3e-4
    alpha_lr: float = 3e-4
    target_entropy: Optional[float] = None
    gamma: float = 0.99
    tau: float = 0.005
    batch_size: int = 256
    replay_buffer_capacity: int = 1000000
    use_gpu: bool = False
    device: str = "cpu"
    update_steps: int = 1
    log_interval: int = 100
    max_action: float = 1.0
    visualize: bool = False
    visualize_dir: str = "./visuals"


# -------------------- Replay Buffer --------------------
class ReplayBuffer:
    def __init__(self, capacity: int):
        self.capacity = capacity
        self.buffer: List[Dict[str, torch.Tensor]] = []
        self.position = 0

    def push(self, transition: Dict[str, torch.Tensor]):
        if len(self.buffer) < self.capacity:
            self.buffer.append(transition)
        else:
            self.buffer[self.position] = transition
        self.position = (self.position + 1) % self.capacity

    def sample(self, batch_size: int):
        batch = random.sample(self.buffer, batch_size)
        state = torch.stack([item["state"] for item in batch])
        action = torch.stack([item["action"] for item in batch])
        reward = torch.stack([item["reward"] for item in batch]).unsqueeze(-1)
        next_state = torch.stack([item["next_state"] for item in batch])
        done = torch.stack([item["done"] for item in batch]).unsqueeze(-1)
        return state, action, reward, next_state, done

    def __len__(self):
        return len(self.buffer)


# -------------------- Network Definitions --------------------
class MLP(nn.Module):
    def __init__(self, input_dim: int, output_dim: int, hidden_sizes: Tuple[int, ...]):
        super().__init__()
        layers = []
        last_dim = input_dim
        for size in hidden_sizes:
            layers.append(nn.Linear(last_dim, size))
            layers.append(nn.ReLU())
            last_dim = size
        layers.append(nn.Linear(last_dim, output_dim))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)


class Actor(nn.Module):
    def __init__(self, state_dim: int, action_dim: int, hidden_sizes: Tuple[int, ...], max_action: float):
        super().__init__()
        self.mean_net = MLP(state_dim, action_dim, hidden_sizes)
        self.log_std_net = MLP(state_dim, action_dim, hidden_sizes)
        self.action_scale = max_action
        self.action_bias = 0.0

    def forward(self, state):
        mean = self.mean_net(state)
        log_std = self.log_std_net(state).clamp(-20, 2)
        std = log_std.exp()
        normal = Normal(mean, std)
        z = normal.rsample()
        action = torch.tanh(z) * self.action_scale + self.action_bias
        log_prob = normal.log_prob(z).sum(-1, keepdim=True)
        log_prob -= torch.log(1 - action.pow(2) + 1e-6).sum(-1, keepdim=True)
        return action, log_prob


class Critic(nn.Module):
    def __init__(self, state_dim: int, action_dim: int, hidden_sizes: Tuple[int, ...]):
        super().__init__()
        self.q_net = MLP(state_dim + action_dim, 1, hidden_sizes)

    def forward(self, state, action):
        sa = torch.cat([state, action], dim=-1)
        return self.q_net(sa)


# -------------------- SAC Agent --------------------
class SAC:
    def __init__(self, config: SACConfig):
        self.device = torch.device("cuda" if config.use_gpu and torch.cuda.is_available() else "cpu")
        config.device = str(self.device)

        self.state_dim = config.state_dim
        self.action_dim = config.action_dim
        self.max_action = config.max_action
        self.gamma = config.gamma
        self.tau = config.tau
        self.batch_size = config.batch_size
        self.target_entropy = config.target_entropy if config.target_entropy is not None else -float(self.action_dim)

        self.actor = Actor(self.state_dim, self.action_dim, config.hidden_sizes, self.max_action).to(self.device)
        self.critic1 = Critic(self.state_dim, self.action_dim, config.hidden_sizes).to(self.device)
        self.critic2 = Critic(self.state_dim, self.action_dim, config.hidden_sizes).to(self.device)
        self.critic1_target = Critic(self.state_dim, self.action_dim, config.hidden_sizes).to(self.device)
        self.critic2_target = Critic(self.state_dim, self.action_dim, config.hidden_sizes).to(self.device)

        self.critic1_target.load_state_dict(self.critic1.state_dict())
        self.critic2_target.load_state_dict(self.critic2.state_dict())

        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=config.actor_lr)
        self.critic_optimizer = optim.Adam(list(self.critic1.parameters()) + list(self.critic2.parameters()), lr=config.critic_lr)
        self.log_alpha = torch.zeros(1, requires_grad=True, device=self.device)
        self.alpha_optimizer = optim.Adam([self.log_alpha], lr=config.alpha_lr)

        self.replay_buffer = ReplayBuffer(config.replay_buffer_capacity)
        self.update_steps = config.update_steps
        self.visualize = config.visualize
        if self.visualize and make_dot:
            os.makedirs(config.visualize_dir, exist_ok=True)
            self.visualize_networks()

    # -------------------- Action Selection --------------------
    def select_action(self, state: np.ndarray, deterministic: bool = False) -> np.ndarray:
        state_t = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        if deterministic:
            with torch.no_grad():
                mean = self.actor.mean_net(state_t)
                action = torch.tanh(mean) * self.max_action
                return action.cpu().numpy().squeeze()
        else:
            with torch.no_grad():
                action, _ = self.actor(state_t)
                return action.cpu().numpy().squeeze()

    # -------------------- Experience Storage --------------------
    def store_episode(self, episode: List[Tuple[np.ndarray, np.ndarray, float, np.ndarray, bool]]):
        for transition in episode:
            state, action, reward, next_state, done = transition
            self.replay_buffer.push({
                "state": torch.FloatTensor(state).to(self.device),
                "action": torch.FloatTensor(action).to(self.device),
                "reward": torch.FloatTensor([reward]).to(self.device),
                "next_state": torch.FloatTensor(next_state).to(self.device),
                "done": torch.FloatTensor([float(done)]).to(self.device)
            })

    # -------------------- Training Update --------------------
    def update_parameters(self, update_value: bool = True, update_policy: bool = True, update_entropy_alpha: bool = True):
        if len(self.replay_buffer) < self.batch_size:
            return

        state, action, reward, next_state, done = self.replay_buffer.sample(self.batch_size)
        with torch.no_grad():
            next_action, next_log_prob = self.actor(next_state)
            target_q1 = self.critic1_target(next_state, next_action)
            target_q2 = self.critic2_target(next_state, next_action)
            target_q_min = torch.min(target_q1, target_q2)
            target_q = reward + (1 - done) * self.gamma * (target_q_min - torch.exp(self.log_alpha) * next_log_prob)

        if update_value:
            current_q1 = self.critic1(state, action)
            current_q2 = self.critic2(state, action)
            loss_q1 = F.mse_loss(current_q1, target_q)
            loss_q2 = F.mse_loss(current_q2, target_q)
            critic_loss = loss_q1 + loss_q2
            self.critic_optimizer.zero_grad()
            critic_loss.backward()
            self.critic_optimizer.step()

        if update_policy:
            new_action, log_prob = self.actor(state)
            q1_new = self.critic1(state, new_action)
            q2_new = self.critic2(state, new_action)
            q_new = torch.min(q1_new, q2_new)
            actor_loss = (torch.exp(self.log_alpha) * log_prob - q_new).mean()
            self.actor_optimizer.zero_grad()
            actor_loss.backward()
            self.actor_optimizer.step()

        if update_entropy_alpha:
            alpha_loss = -(self.log_alpha * (log_prob + self.target_entropy).detach()).mean()
            self.alpha_optimizer.zero_grad()
            alpha_loss.backward()
            self.alpha_optimizer.step()

        self.soft_update(self.critic1, self.critic1_target)
        self.soft_update(self.critic2, self.critic2_target)

    def soft_update(self, source: nn.Module, target: nn.Module, tau: Optional[float] = None):
        tau = tau if tau is not None else self.tau
        for param_src, param_tgt in zip(source.parameters(), target.parameters()):
            param_tgt.data.copy_(tau * param_src.data + (1 - tau) * param_tgt.data)

    # -------------------- Evaluation Mode --------------------
    def eval(self):
        self.actor.eval()
        self.critic1.eval()
        self.critic2.eval()
        self.critic1_target.eval()
        self.critic2_target.eval()

    def train(self):
        self.actor.train()
        self.critic1.train()
        self.critic2.train()
        self.critic1_target.train()
        self.critic2_target.train()

    # -------------------- Checkpointing --------------------
    def save_checkpoint(self, path: str):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        torch.save({
            "actor": self.actor.state_dict(),
            "critic1": self.critic1.state_dict(),
            "critic2": self.critic2.state_dict(),
            "critic1_target": self.critic1_target.state_dict(),
            "critic2_target": self.critic2_target.state_dict(),
            "actor_opt": self.actor_optimizer.state_dict(),
            "critic_opt": self.critic_optimizer.state_dict(),
            "alpha_opt": self.alpha_optimizer.state_dict(),
            "log_alpha": self.log_alpha.detach(),
            "replay_buffer": self.replay_buffer,
        }, path)

    def load_checkpoint(self, path: str):
        checkpoint = torch.load(path, map_location=self.device)
        self.actor.load_state_dict(checkpoint["actor"])
        self.critic1.load_state_dict(checkpoint["critic1"])
        self.critic2.load_state_dict(checkpoint["critic2"])
        self.critic1_target.load_state_dict(checkpoint["critic1_target"])
        self.critic2_target.load_state_dict(checkpoint["critic2_target"])
        self.actor_optimizer.load_state_dict(checkpoint["actor_opt"])
        self.critic_optimizer.load_state_dict(checkpoint["critic_opt"])
        self.alpha_optimizer.load_state_dict(checkpoint["alpha_opt"])
        self.log_alpha = torch.tensor(checkpoint["log_alpha"], device=self.device, requires_grad=True)
        self.replay_buffer = checkpoint["replay_buffer"]
        self.sync_target_networks()

    def sync_target_networks(self):
        self.critic1_target.load_state_dict(self.critic1.state_dict())
        self.critic2_target.load_state_dict(self.critic2.state_dict())

    # -------------------- Visualization --------------------
    def visualize_networks(self):
        dummy_state = torch.zeros(1, self.state_dim).to(self.device)
        dummy_action = torch.zeros(1, self.action_dim).to(self.device)
        with torch.no_grad():
            actor_graph = make_dot(self.actor(dummy_state), params=dict(self.actor.named_parameters()))
            actor_graph.view(filename=os.path.join(self.visualize_dir, "actor"), cleanup=True)
            q1_graph = make_dot(self.critic1(dummy_state, dummy_action), params=dict(self.critic1.named_parameters()))
            q1_graph.view(filename=os.path.join(self.visualize_dir, "critic1"), cleanup=True)
            q2_graph = make_dot(self.critic2(dummy_state, dummy_action), params=dict(self.critic2.named_parameters()))
            q2_graph.view(filename=os.path.join(self.visualize_dir, "critic2"), cleanup=True)

    # -------------------- Configuration Loading --------------------
    @staticmethod
    def load_config(path: str) -> SACConfig:
        with open(path, "r") as f:
            cfg_dict = yaml.safe_load(f)
        return SACConfig(**cfg_dict)

    @staticmethod
    def default_config() -> SACConfig:
        return SACConfig(
            state_dim=24,
            action_dim=4,
            hidden_sizes=(256, 256),
            actor_lr=3e-4,
            critic_lr=3e-4,
            alpha_lr=3e-4,
            target_entropy=-4.0,
            gamma=0.99,
            tau=0.005,
            batch_size=256,
            replay_buffer_capacity=1000000,
            use_gpu=True,
            update_steps=1,
            max_action=1.0,
            visualize=True,
            visualize_dir="./visuals"
        )
```