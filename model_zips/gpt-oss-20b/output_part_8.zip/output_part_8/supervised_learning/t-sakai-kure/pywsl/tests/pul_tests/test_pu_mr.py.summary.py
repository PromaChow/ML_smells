import unittest
import numpy as np
from sklearn.model_selection import GridSearchCV
from pywsl.pul import PU_SL, gen_twonorm_pu, bin_clf_err


class TestPU_SL(unittest.TestCase):
    def setUp(self):
        self.n_p = 30
        self.n_u = 200
        self.prior_u = 0.5
        self.n_t = 100
        # Generate training and test data
        self.x, self.y, self.x_t, self.y_t = gen_twonorm_pu(
            n_p=self.n_p,
            n_u=self.n_u,
            prior_u=self.prior_u,
            n_t=self.n_t
        )

    def test_fit(self):
        model = PU_SL(prior=0.5, basis='lm')
        model.fit(self.x, self.y)
        y_pred = model.predict(self.x_t)
        error = bin_clf_err(y_pred, self.y_t, self.prior_u)
        self.assertLess(error, 0.2)

    def test_cv(self):
        param_grid = {
            'lam': np.logspace(-3, 1, 5)
        }
        base_estimator = PU_SL(prior=0.5, basis='lm')
        grid = GridSearchCV(
            estimator=base_estimator,
            param_grid=param_grid,
            cv=5
        )
        grid.fit(self.x, self.y)
        best_model = grid.best_estimator_
        y_pred = best_model.predict(self.x_t)
        error = bin_clf_err(y_pred, self.y_t, self.prior_u)
        self.assertLess(error, 0.2)


if __name__ == '__main__':
    unittest.main()