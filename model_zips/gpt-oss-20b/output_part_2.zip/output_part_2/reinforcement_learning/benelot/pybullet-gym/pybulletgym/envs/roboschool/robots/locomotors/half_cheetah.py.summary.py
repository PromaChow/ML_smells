import numpy as np
from some_library import WalkerBase, MJCFBasedRobot


class HalfCheetah(WalkerBase, MJCFBasedRobot):
    """Robotic locomotion model of a HalfCheetah."""

    # List of body parts used to track ground contact
    foot_list = ["ffoot", "fshin", "fthigh", "bfoot", "bshin", "bthigh"]

    def __init__(self):
        # Initialize locomotion control
        WalkerBase.__init__(self, power=0.90)
        # Initialize MJCF physics model
        MJCFBasedRobot.__init__(
            self,
            xml_file="half_cheetah.xml",
            root_body="torso",
            action_dim=6,
            obs_dim=26,
        )

    def alive_bonus(self) -> int:
        """Return +1 if the robot is considered alive, otherwise -1."""
        pitch = self.get_pitch()
        if not (-1.0 <= pitch <= 1.0):
            return -1

        # Ensure no knee joints are in contact with the ground
        for joint in ["fshin", "fthigh", "bshin", "bthigh"]:
            if self.is_in_contact(joint):
                return -1

        return 1

    def robot_specific_reset(self):
        """Reset the robot and set joint power coefficients."""
        super().robot_specific_reset()

        power_coeffs = {
            "bthigh": 120.0,
            "bshin": 90.0,
            "bfoot": 60.0,
            "fthigh": 140.0,
            "fshin": 60.0,
            "ffoot": 30.0,
        }

        for joint, coeff in power_coeffs.items():
            self.set_joint_power(joint, coeff)

    # Helper methods assumed to be provided by the base classes

    def get_pitch(self) -> float:
        """Retrieve the current pitch angle of the torso."""
        return self.get_body_state("torso")["pitch"]

    def is_in_contact(self, joint_name: str) -> bool:
        """Check if a specific joint is in contact with the ground."""
        return self.is_contact(joint_name)

    def set_joint_power(self, joint_name: str, power: float):
        """Set the power coefficient for a joint."""
        self.set_joint_power_coeff(joint_name, power)