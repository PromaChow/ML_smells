import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Normal


class BayesianLinear(nn.Module):
    def __init__(self, in_features, out_features, bias=True):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.bias_flag = bias

        self.w_mu = nn.Parameter(torch.empty(out_features, in_features).normal_(0, 0.1))
        self.w_sigma = nn.Parameter(torch.empty(out_features, in_features).normal_(0, 0.1).abs())

        if self.bias_flag:
            self.b_mu = nn.Parameter(torch.empty(out_features).normal_(0, 0.1))
            self.b_sigma = nn.Parameter(torch.empty(out_features).normal_(0, 0.1).abs())
        else:
            self.register_parameter("b_mu", None)
            self.register_parameter("b_sigma", None)

        self.prior_mu = torch.tensor(0.0)
        self.prior_sigma = torch.tensor(0.1)

    def forward(self, x, kl=True, frozen=False):
        if frozen:
            w = self.w_mu
            b = self.b_mu if self.bias_flag else None
        else:
            w_dist = Normal(self.w_mu, self.w_sigma)
            w = w_dist.rsample()
            b = None
            if self.bias_flag:
                b_dist = Normal(self.b_mu, self.b_sigma)
                b = b_dist.rsample()

        out = F.linear(x, w, b)

        kl_div = 0.0
        if kl and not frozen:
            w_kl = self._kl_divergence(self.w_mu, self.w_sigma, self.prior_mu, self.prior_sigma)
            kl_div = w_kl
            if self.bias_flag:
                b_kl = self._kl_divergence(self.b_mu, self.b_sigma, self.prior_mu, self.prior_sigma)
                kl_div = kl_div + b_kl

        return out, kl_div

    @staticmethod
    def _kl_divergence(mu_q, sigma_q, mu_p, sigma_p):
        var_q = sigma_q ** 2
        var_p = sigma_p ** 2
        return torch.sum(
            torch.log(sigma_p / sigma_q)
            + (var_q + (mu_q - mu_p) ** 2) / (2 * var_p)
            - 0.5
        )


class BayesianNNBanditModel(nn.Module):
    def __init__(self, layer_sizes, dropout_p=0.0):
        super().__init__()
        self.layers = nn.ModuleList()
        self.dropout_p = dropout_p
        for i in range(len(layer_sizes) - 1):
            self.layers.append(BayesianLinear(layer_sizes[i], layer_sizes[i + 1]))
        self.dropout = nn.Dropout(dropout_p) if dropout_p > 0.0 else None

    def forward(self, x, kl=True, frozen=False):
        kl_total = 0.0
        out = x
        for i, layer in enumerate(self.layers):
            out, kl_layer = layer(out, kl=kl, frozen=frozen)
            kl_total = kl_total + kl_layer
            if i < len(self.layers) - 1:
                out = F.relu(out)
                if self.dropout is not None:
                    out = self.dropout(out)
        pred_rewards = out
        return {"pred_rewards": pred_rewards, "kl_div": kl_total}


def bnn_bandit_loss(output_dict, rewards, db_size, noise_std=0.1):
    pred = output_dict["pred_rewards"]
    kl = output_dict["kl_div"]
    batch_size = pred.size(0)
    dist = Normal(pred, noise_std)
    log_likelihood = dist.log_prob(rewards).sum()
    loss = (-log_likelihood + kl) / batch_size * (1.0 / db_size)
    return loss


# Example usage (placeholders for demonstration purposes)
if __name__ == "__main__":
    # Dummy database placeholder
    class DB:
        db_size = 10000

    db = DB()
    model = BayesianNNBanditModel([10, 20, 1], dropout_p=0.1)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

    # Dummy data
    contexts = torch.randn(32, 10)
    rewards = torch.randn(32, 1)

    optimizer.zero_grad()
    output = model(contexts, kl=True, frozen=False)
    loss = bnn_bandit_loss(output, rewards, db.db_size, noise_std=0.1)
    loss.backward()
    optimizer.step()
