import torch
import torch.nn.functional as F


class VATLoss(torch.nn.Module):
    def __init__(self, eps: float = 2.0, xi: float = 1e-6, n_iteration: int = 1):
        super().__init__()
        self.eps = eps
        self.xi = xi
        self.n_iteration = n_iteration

    def kld(self, q_logit: torch.Tensor, p_logit: torch.Tensor) -> torch.Tensor:
        """
        Compute KL divergence per sample: KL(q || p) where
        q = softmax(q_logit), p = softmax(p_logit)
        """
        q = torch.softmax(q_logit, dim=1)
        logp = self.__logsoftmax(p_logit)
        logq = self.__logsoftmax(q_logit)
        kl = q * (logq - logp)
        # Sum over class dimension to get per-sample KL
        return kl.sum(dim=1)

    def normalize(self, v: torch.Tensor) -> torch.Tensor:
        """
        Normalize perturbation vector v:
        1. Scale by its maximum absolute value (across all dims except batch)
        2. L2 normalize to unit norm
        """
        # Scale by max absolute value
        max_abs = self.__reduce_max(v, dim=tuple(range(1, v.dim())))
        v = v / (max_abs + 1e-12)

        # L2 normalize
        norm = v.norm(p=2, dim=tuple(range(1, v.dim())), keepdim=True)
        v = v / (norm + 1e-12)

        return v

    def __reduce_max(self, v: torch.Tensor, dim: tuple) -> torch.Tensor:
        return torch.max(v.abs(), dim=dim, keepdim=True)[0]

    def __logsoftmax(self, x: torch.Tensor) -> torch.Tensor:
        # Numerically stable log-softmax
        shiftx = x - x.max(dim=1, keepdim=True)[0]
        return shiftx - torch.log(torch.exp(shiftx).sum(dim=1, keepdim=True))

    def forward(
        self,
        model: torch.nn.Module,
        x: torch.Tensor,
        y: torch.Tensor = None,
        mask: torch.Tensor = None,
    ) -> torch.Tensor:
        """
        Compute VAT loss for input x and optional mask.
        `y` can be None; if provided, it is used as the target distribution.
        """
        # Disable BN updates
        if hasattr(model, "update_batch_stats"):
            model.update_batch_stats(False)

        # Original prediction
        with torch.no_grad():
            y_orig = model(x)

        # Initial random perturbation
        d = torch.randn_like(x)
        d = self.normalize(d)

        for _ in range(self.n_iteration):
            d.requires_grad_()
            x_hat = x + self.xi * d
            y_hat = model(x_hat)
            loss = self.kld(y_orig, y_hat).mean()
            grad = torch.autograd.grad(loss, d)[0]
            d = d.detach() + self.xi * grad
            d = self.normalize(d)

        # Final adversarial perturbation
        x_adv = x + self.eps * d
        y_adv = model(x_adv)

        kl_per_sample = self.kld(y_adv, y_orig)
        if mask is not None:
            kl_per_sample = kl_per_sample * mask
            loss = kl_per_sample.mean()
        else:
            loss = kl_per_sample.mean()

        # Re-enable BN updates
        if hasattr(model, "update_batch_stats"):
            model.update_batch_stats(True)

        return loss
