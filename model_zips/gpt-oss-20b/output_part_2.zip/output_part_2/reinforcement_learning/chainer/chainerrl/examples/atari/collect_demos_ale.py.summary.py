import argparse
import logging
import os
import sys

import gym
import torch
import torch.nn as nn
import torchviz

from atari_wrappers import make_atari, wrap_deepmind
from wrappers import RandomizeAction, Monitor, Render
from misc import set_random_seed
from experiments import prepare_output_dir, collect_demonstrations
from links import Sequence, NatureDQNHead, DiscreteActionValue
from optimizer import RMSpropGraves
from replay import ReplayBuffer
from agents.dqn import DQNAgent


def parse_args():
    parser = argparse.ArgumentParser(description="DQN Demonstration Collector")
    parser.add_argument("--env", type=str, default="BreakoutNoFrameskip-v4",
                        help="Environment name")
    parser.add_argument("--output_dir", type=str, default="results",
                        help="Output directory")
    parser.add_argument("--seed", type=int, default=0,
                        help="Random seed")
    parser.add_argument("--gpu", type=str, default="0",
                        help="GPU device id")
    parser.add_argument("--load", type=str, required=True,
                        help="Path to pre-trained model")
    parser.add_argument("--log_level", type=str, default="INFO",
                        help="Logging level")
    parser.add_argument("--render", action="store_true",
                        help="Render environment")
    parser.add_argument("--monitor", action="store_true",
                        help="Save monitoring data")
    parser.add_argument("--steps", type=int, default=50000000,
                        help="Total demonstration steps")
    return parser.parse_args()


def setup_logging(level_str):
    numeric_level = getattr(logging, level_str.upper(), logging.INFO)
    logging.basicConfig(level=numeric_level,
                        format="%(asctime)s - %(levelname)s - %(message)s")
    logging.getLogger().setLevel(numeric_level)


def make_env(env_name, seed, monitor, render):
    env = make_atari(env_name, episode_life=False, clip_rewards=False)
    env = wrap_deepmind(env, episode_life=False, clip_rewards=False)
    env.seed(seed)
    env = RandomizeAction(env, prob=0.01)
    if monitor:
        env = Monitor(env)
    if render:
        env = Render(env)
    return env


def build_q_network(action_dim, output_dir):
    seq = Sequence(
        NatureDQNHead(),
        nn.Linear(512, action_dim),
        DiscreteActionValue()
    )
    # Save computational graph
    dummy_input = torch.zeros(1, 4, 84, 84)
    dot = torchviz.make_dot(seq(dummy_input), params=dict(seq.named_parameters()))
    dot.format = "png"
    dot.render(os.path.join(output_dir, "q_network"), cleanup=True)
    return seq


def main():
    args = parse_args()
    setup_logging(args.log_level)

    # Set random seed
    set_random_seed(args.seed)

    # GPU device
    device = torch.device(f"cuda:{args.gpu}" if torch.cuda.is_available() else "cpu")

    # Prepare output directory
    output_dir = prepare_output_dir(args.output_dir)
    logging.info(f"Output directory: {output_dir}")

    # Environment
    env = make_env(args.env, args.seed, args.monitor, args.render)
    action_dim = env.action_space.n

    # Q-function
    q_func = build_q_network(action_dim, output_dir).to(device)

    # Optimizer
    optimizer = RMSpropGraves(params=q_func.parameters())

    # Replay buffer
    replay_buffer = ReplayBuffer(capacity=1)

    # Preprocessing function
    def phi(x):
        return x / 255.0

    # Agent
    agent = DQNAgent(
        q_func=q_func,
        optimizer=optimizer,
        replay_buffer=replay_buffer,
        device=device,
        gamma=0.99,
        explorer=None,
        replay_start_size=1,
        minibatch_size=1,
        target_update_interval=None,
        clip_delta=True,
        update_interval=4,
        phi=phi
    )

    # Load model
    agent.load(args.load)

    # Collect demonstrations
    demos_path = os.path.join(output_dir, "demos.pickle")
    collect_demonstrations(
        agent=agent,
        env=env,
        steps=args.steps,
        output_path=demos_path
    )
    logging.info(f"Demonstrations saved to {demos_path}")


if __name__ == "__main__":
    main()
