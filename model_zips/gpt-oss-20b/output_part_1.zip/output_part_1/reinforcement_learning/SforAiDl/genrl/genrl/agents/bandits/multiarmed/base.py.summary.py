import numpy as np
from abc import ABC, abstractmethod
from typing import Union, List, Tuple

from bandit_agent import BanditAgent
from bandit import MultiArmedBandit


class MABAgent(ABC, BanditAgent):
    def __init__(self, bandit: MultiArmedBandit):
        super().__init__(bandit)
        if bandit.context_type != "int":
            raise ValueError("Bandit context type must be 'int'")
        self._regret: float = 0.0
        self._regret_hist: List[float] = []
        self._action_hist: List[Tuple[int, int]] = []
        self._reward_hist: List[Union[int, float]] = []
        self._counts = np.zeros((bandit.num_bandits, bandit.num_arms), dtype=int)

    @property
    def action_hist(self) -> List[Tuple[int, int]]:
        return self._action_hist

    @property
    def regret(self) -> float:
        return self._regret

    @property
    def regret_hist(self) -> List[float]:
        return self._regret_hist

    @property
    def reward_hist(self) -> List[Union[int, float]]:
        return self._reward_hist

    @property
    def counts(self) -> np.ndarray:
        return self._counts

    @abstractmethod
    def select_action(self, context: int) -> int:
        """Choose an action given the context."""
        pass

    @abstractmethod
    def update_params(self, context: int, action: int, reward: Union[int, float]) -> None:
        """Update policy parameters after observing a reward."""
        pass