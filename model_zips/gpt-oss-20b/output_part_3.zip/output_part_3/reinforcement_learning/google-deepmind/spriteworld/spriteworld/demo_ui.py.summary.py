import gym
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np
from matplotlib.widgets import Button
from matplotlib.backend_bases import KeyEvent, MouseEvent
from matplotlib import collections as mc
from typing import Optional, Tuple, Dict, Any

class SpriteworldUI:
    def __init__(self, env: gym.Env, agent: "BaseAgent"):
        self.env = env
        self.agent = agent
        self.fig, (self.ax_img, self.ax_reward) = plt.subplots(1, 2, figsize=(10, 4))
        self.ax_img.set_title("Environment")
        self.ax_reward.set_title("Rewards")
        self.reward_history = []
        self.done = False

        # Disable default Matplotlib shortcuts
        for key in ["backspace", "delete", "escape", "home", "end", "pageup", "pagedown"]:
            plt.rcParams[f"keymap.{key}"] = []

        self.fig.canvas.mpl_connect("key_press_event", self._on_key)
        self.fig.canvas.mpl_connect("button_press_event", self._on_click)

        self.agent.register_callbacks(self)

        # Initialize first frame
        obs = self.env.reset()
        self._draw_observation(obs, action=None)
        plt.tight_layout()
        plt.show(block=False)

    def _on_key(self, event: KeyEvent):
        if event.key == "escape":
            self.done = True
            plt.close(self.fig)

    def _on_click(self, event: MouseEvent):
        self.agent.handle_click(event)

    def _draw_observation(self, observation: np.ndarray, action: Optional[Any]):
        self.ax_img.cla()
        self.ax_img.imshow(observation, origin="lower")
        if action is not None:
            if isinstance(action, tuple) and len(action) == 2:
                src, tgt = action
                src_pos = self.env.unwrapped.grid.get_obj_position(src)
                tgt_pos = self.env.unwrapped.grid.get_obj_position(tgt)
                self.ax_img.arrow(src_pos[0], src_pos[1], tgt_pos[0] - src_pos[0],
                                  tgt_pos[1] - src_pos[1], head_width=0.3, head_length=0.3, fc='r', ec='r')
        self.ax_img.set_xticks([])
        self.ax_img.set_yticks([])
        self.ax_img.set_title("Environment")

    def _draw_rewards(self):
        self.ax_reward.cla()
        if self.reward_history:
            indices = np.arange(len(self.reward_history))
            self.ax_reward.stem(indices, self.reward_history, basefmt=" ")
            self.ax_reward.set_xlim(-1, len(self.reward_history) + 1)
            ymin = min(self.reward_history) - 1
            ymax = max(self.reward_history) + 1
            self.ax_reward.set_ylim(ymin, ymax)
        self.ax_reward.set_title("Rewards")
        self.ax_reward.set_xlabel("Step")
        self.ax_reward.set_ylabel("Reward")

    def update(self, observation: np.ndarray, reward: float):
        self.reward_history.append(reward)
        self._draw_observation(observation, action=None)
        self._draw_rewards()
        self.fig.canvas.draw_idle()

class BaseAgent:
    def register_callbacks(self, ui: SpriteworldUI):
        raise NotImplementedError

    def handle_click(self, event: MouseEvent):
        pass

    def get_action(self) -> Optional[Any]:
        raise NotImplementedError

class DragAndDropAgent(BaseAgent):
    def __init__(self, env: gym.Env):
        self.env = env
        self.clicks: list[Tuple[int, int]] = []

    def register_callbacks(self, ui: SpriteworldUI):
        self.ui = ui

    def handle_click(self, event: MouseEvent):
        if event.inaxes == self.ui.ax_img:
            x, y = int(event.xdata + 0.5), int(event.ydata + 0.5)
            self.clicks.append((x, y))
            if len(self.clicks) == 2:
                src = self._pos_to_obj_id(self.clicks[0])
                tgt = self._pos_to_obj_id(self.clicks[1])
                if src is not None and tgt is not None:
                    action = (src, tgt)
                    if self.env.action_space.contains(action):
                        self.ui._draw_observation(self.env.render(), action=action)
                        self.ui.agent = self  # dummy to update UI
                self.clicks = []

    def _pos_to_obj_id(self, pos: Tuple[int, int]) -> Optional[int]:
        grid = self.env.unwrapped.grid
        return grid.get_obj_id_at_pos(pos[0], pos[1])

    def get_action(self) -> Optional[Any]:
        # Action is produced on click, handled elsewhere
        return None

class EmbodiedAgent(BaseAgent):
    def __init__(self, env: gym.Env):
        self.env = env
        self.move_map = {
            "w": (-1, 0),
            "a": (0, -1),
            "s": (1, 0),
            "d": (0, 1),
            "up": (-1, 0),
            "left": (0, -1),
            "down": (1, 0),
            "right": (0, 1),
        }
        self.carry = False
        self.current_action: Optional[Dict[str, Any]] = None

    def register_callbacks(self, ui: SpriteworldUI):
        self.ui = ui
        self.ui.fig.canvas.mpl_connect("key_press_event", self._on_key_press)
        self.ui.fig.canvas.mpl_connect("key_release_event", self._on_key_release)

    def _on_key_press(self, event: KeyEvent):
        if event.key in self.move_map:
            dx, dy = self.move_map[event.key]
            self.current_action = {"move": (dx, dy), "carry": self.carry}
        elif event.key == "space":
            self.carry = not self.carry
            if self.current_action:
                self.current_action["carry"] = self.carry

    def _on_key_release(self, event: KeyEvent):
        if event.key in self.move_map:
            self.current_action = None

    def get_action(self) -> Optional[Any]:
        if self.current_action and self.env.action_space.contains(self.current_action):
            return self.current_action
        return None

def setup_run_ui(action_space_type: str, env_name: str = "spriteworld:basic"):
    env = gym.make(env_name, render_mode="rgb_array")
    if action_space_type.lower() == "draganddrop":
        agent = DragAndDropAgent(env)
    elif action_space_type.lower() == "embodied":
        agent = EmbodiedAgent(env)
    else:
        raise ValueError("Unsupported action space type")

    ui = SpriteworldUI(env, agent)
    obs = env.reset()
    ui.update(obs, 0.0)
    step = 0
    done = False
    while not ui.done and not done:
        action = agent.get_action()
        if action is not None:
            obs, reward, done, _ = env.step(action)
            ui.update(obs, reward)
            step += 1
    env.close()

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--type", choices=["draganddrop", "embodied"], default="embodied")
    args = parser.parse_args()
    setup_run_ui(args.type)