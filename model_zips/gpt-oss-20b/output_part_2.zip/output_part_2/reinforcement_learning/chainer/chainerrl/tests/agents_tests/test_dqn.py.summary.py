import unittest
import numpy as np
import chainerrl
import chainerrl.testing as testing
from chainerrl.agents.dqn import DQN, compute_value_loss, compute_weighted_value_loss
from chainerrl.replays.buffer import ReplayBuffer
from chainerrl.q_functions import MLPQFunction
from chainerrl.optimizers import Adam
from chainerrl.explorations import Greedy, Boltzmann
from basetest_dqn_like import _TestBatchTrainingMixin, base

# ----------------------------------------------------------------------
# Test classes for various DQN configurations
# ----------------------------------------------------------------------
class TestDQNOnDiscreteABC(_TestBatchTrainingMixin):
    def make_dqn_agent(self, env):
        q_func = MLPQFunction(env.observation_shape, env.action_spec, hidden_sizes=(64, 64))
        replay_buffer = ReplayBuffer(capacity=20000)
        agent = DQN(
            q_func,
            env,
            Adam(learning_rate=1e-3),
            replay_buffer,
            replay_start_size=1000,
            batch_size=32,
            gamma=0.99,
        )
        return agent

class TestDQNOnContinuousABC(_TestBatchTrainingMixin):
    def make_dqn_agent(self, env):
        q_func = MLPQFunction(env.observation_shape, env.action_spec, hidden_sizes=(64, 64))
        replay_buffer = ReplayBuffer(capacity=20000)
        agent = DQN(
            q_func,
            env,
            Adam(learning_rate=1e-3),
            replay_buffer,
            replay_start_size=1000,
            batch_size=32,
            gamma=0.99,
        )
        return agent

class TestDQNOnDiscretePOABC(_TestBatchTrainingMixin):
    def make_dqn_agent(self, env):
        q_func = MLPQFunction(env.observation_shape, env.action_spec, hidden_sizes=(64, 64))
        replay_buffer = ReplayBuffer(capacity=20000)
        agent = DQN(
            q_func,
            env,
            Adam(learning_rate=1e-3),
            replay_buffer,
            replay_start_size=1000,
            batch_size=32,
            gamma=0.99,
            recurrent=True,
        )
        return agent

class TestDQNOnDiscreteABCBoltzmann(_TestBatchTrainingMixin):
    def make_dqn_agent(self, env):
        q_func = MLPQFunction(env.observation_shape, env.action_spec, hidden_sizes=(64, 64))
        replay_buffer = ReplayBuffer(capacity=20000)
        agent = DQN(
            q_func,
            env,
            Adam(learning_rate=1e-3),
            replay_buffer,
            replay_start_size=1000,
            batch_size=32,
            gamma=0.99,
            exploration=Boltzmann(temperature=0.5),
        )
        return agent

class TestNStepDQNOnDiscreteABC(_TestBatchTrainingMixin):
    def make_dqn_agent(self, env):
        q_func = MLPQFunction(env.observation_shape, env.action_spec, hidden_sizes=(64, 64))
        replay_buffer = ReplayBuffer(capacity=20000)
        agent = DQN(
            q_func,
            env,
            Adam(learning_rate=1e-3),
            replay_buffer,
            replay_start_size=1000,
            batch_size=32,
            gamma=0.99,
            n_step=3,
        )
        return agent

# ----------------------------------------------------------------------
# Replay buffer capacity validation
# ----------------------------------------------------------------------
class TestReplayCapacity(unittest.TestCase):
    def test_replay_capacity_checked(self):
        env = base.make_env()
        q_func = MLPQFunction(env.observation_shape, env.action_spec, hidden_sizes=(64, 64))
        replay_buffer = ReplayBuffer(capacity=50)
        with self.assertRaises(ValueError):
            DQN(
                q_func,
                env,
                Adam(learning_rate=1e-3),
                replay_buffer,
                replay_start_size=100,
                batch_size=32,
                gamma=0.99,
            )

# ----------------------------------------------------------------------
# Loss function parameterized tests
# ----------------------------------------------------------------------
def _huber_loss_1(y, t, clip_delta):
    delta = y - t
    abs_delta = np.abs(delta)
    if clip_delta:
        loss = np.where(abs_delta <= 1.0, 0.5 * delta ** 2, 1.0 * (abs_delta - 0.5))
    else:
        loss = np.where(abs_delta <= 1.0, 0.5 * delta ** 2, abs_delta)
    return loss

@testing.parameterize(
    {"batch_accumulator": "mean", "clip_delta": True},
    {"batch_accumulator": "mean", "clip_delta": False},
    {"batch_accumulator": "sum", "clip_delta": True},
    {"batch_accumulator": "sum", "clip_delta": False},
)
class TestComputeValueLoss(unittest.TestCase):
    def setUp(self):
        self.y = np.array([0.5, 1.0, -0.2, 2.3])
        self.t = np.array([0.3, 0.8, 0.1, 1.9])

    def _expected_loss(self, clip_delta):
        loss = _huber_loss_1(self.y, self.t, clip_delta)
        if self.batch_accumulator == "mean":
            return loss.mean()
        else:
            return loss.sum()

    def test_not_weighted(self):
        loss = compute_value_loss(
            self.y,
            self.t,
            batch_accumulator=self.batch_accumulator,
            clip_delta=self.clip_delta,
        )
        np.testing.assert_allclose(loss, self._expected_loss(self.clip_delta), rtol=1e-6)

    def test_uniformly_weighted(self):
        weights = np.ones_like(self.y)
        loss = compute_weighted_value_loss(
            self.y,
            self.t,
            weights,
            batch_accumulator=self.batch_accumulator,
            clip_delta=self.clip_delta,
        )
        np.testing.assert_allclose(loss, self._expected_loss(self.clip_delta), rtol=1e-6)

    def test_randomly_weighted(self):
        rng = np.random.default_rng(0)
        weights = rng.random(self.y.shape)
        loss = compute_weighted_value_loss(
            self.y,
            self.t,
            weights,
            batch_accumulator=self.batch_accumulator,
            clip_delta=self.clip_delta,
        )
        loss_expected = (
            _huber_loss_1(self.y, self.t, self.clip_delta) * weights
        )
        if self.batch_accumulator == "mean":
            loss_expected = loss_expected.mean()
        else:
            loss_expected = loss_expected.sum()
        np.testing.assert_allclose(loss, loss_expected, rtol=1e-6)

if __name__ == "__main__":
    unittest.main()
