import math
import numpy as np

class Node:
    def __init__(self, state, player, node_id):
        self.state = state          # game state object
        self.player = player        # player to move at this node
        self.id = node_id           # unique identifier
        self.edges = []             # outgoing edges

    def is_leaf(self):
        return len(self.edges) == 0

    def add_edge(self, edge):
        self.edges.append(edge)


class Edge:
    def __init__(self, in_node, out_node, action, prior):
        self.in_node = in_node
        self.out_node = out_node
        self.action = action
        self.N = 0          # visit count
        self.W = 0.0        # cumulative value
        self.Q = 0.0        # average value
        self.P = prior      # prior probability
        self.noise = 0.0    # Dirichlet noise (used only at root)


class MCTS:
    def __init__(self, root, cpuct=1.0):
        self.root = root
        self.cpuct = cpuct
        self.tree = {root.id: root}

    def add_node(self, node):
        self.tree[node.id] = node

    def move_to_leaf(self, config):
        node = self.root
        breadcrumbs = []

        # Apply Dirichlet noise at the root
        if config.EPSILON > 0:
            noise = np.random.dirichlet([config.ALPHA] * len(node.edges))
            for edge, n in zip(node.edges, noise):
                edge.noise = n
        else:
            for edge in node.edges:
                edge.noise = 0.0

        while not node.is_leaf():
            total_visits = sum(edge.N for edge in node.edges)
            best_ucb = -float('inf')
            best_edge = None
            for edge in node.edges:
                u = self.cpuct * (edge.P + edge.noise) * math.sqrt(total_visits) / (1 + edge.N)
                ucb = edge.Q + u
                if ucb > best_ucb:
                    best_ucb = ucb
                    best_edge = edge
            breadcrumbs.append(best_edge)
            node = best_edge.out_node

        state = node.state
        done = state.is_terminal()
        value = state.get_value() if done else 0.0
        return node, value, done, breadcrumbs

    def backfill(self, breadcrumbs, value, root_player):
        # value is from the perspective of the player at the leaf
        for edge in reversed(breadcrumbs):
            edge.N += 1
            sign = 1 if edge.in_node.player == root_player else -1
            edge.W += value * sign
            edge.Q = edge.W / edge.N


# Simple Tic-Tac-Toe implementation for demonstration
class TicTacToeState:
    def __init__(self, board=None, player=1):
        self.board = board if board is not None else [0] * 9
        self.player = player  # 1 or -1

    def clone(self):
        return TicTacToeState(self.board[:], self.player)

    def get_valid_actions(self):
        return [i for i, v in enumerate(self.board) if v == 0]

    def apply_action(self, action):
        new_state = self.clone()
        new_state.board[action] = self.player
        new_state.player = -self.player
        return new_state

    def is_terminal(self):
        lines = [
            (0, 1, 2), (3, 4, 5), (6, 7, 8),
            (0, 3, 6), (1, 4, 7), (2, 5, 8),
            (0, 4, 8), (2, 4, 6)
        ]
        for a, b, c in lines:
            if self.board[a] != 0 and self.board[a] == self.board[b] == self.board[c]:
                return True
        return all(v != 0 for v in self.board)

    def get_value(self):
        lines = [
            (0, 1, 2), (3, 4, 5), (6, 7, 8),
            (0, 3, 6), (1, 4, 7), (2, 5, 8),
            (0, 4, 8), (2, 4, 6)
        ]
        for a, b, c in lines:
            if self.board[a] != 0 and self.board[a] == self.board[b] == self.board[c]:
                return 1.0 if self.board[a] == 1 else -1.0
        return 0.0


class Config:
    EPSILON = 0.25
    ALPHA = 0.03


def uniform_policy(state, actions):
    prob = 1.0 / len(actions)
    return [prob] * len(actions)


def expand_node(mcts, node):
    actions = node.state.get_valid_actions()
    if not actions:
        return
    priors = uniform_policy(node.state, actions)
    for action, prior in zip(actions, priors):
        next_state = node.state.apply_action(action)
        child_id = node.id * 10 + action
        child_node = Node(next_state, next_state.player, child_id)
        edge = Edge(node, child_node, action, prior)
        node.add_edge(edge)
        mcts.add_node(child_node)


def run_mcts(root_state, cpuct=1.0, simulations=1000):
    root_node = Node(root_state, root_state.player, 1)
    mcts = MCTS(root_node, cpuct)
    expand_node(mcts, root_node)

    for _ in range(simulations):
        leaf, value, done, path = mcts.move_to_leaf(Config)
        if not done:
            expand_node(mcts, leaf)
            value = 0.0
        mcts.backfill(path, value, root_node.player)

    best_edge = max(root_node.edges, key=lambda e: e.N)
    return best_edge.action


# Example usage
if __name__ == "__main__":
    initial_state = TicTacToeState()
    action = run_mcts(initial_state, simulations=200)
    print(f"Recommended action: {action}")
