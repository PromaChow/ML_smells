import numpy as np

class SimpleNN:
    def __init__(self):
        # Layer 1
        self.weights_dense1_w = np.random.randn(512, 128)
        self.weights_dense1_b = np.random.randn(128)
        # Layer 2
        self.weights_dense2_w = np.random.randn(128, 128)
        self.weights_dense2_b = np.random.randn(128)
        # Final layer
        self.weights_final_w = np.random.randn(128, 17)
        self.weights_final_b = np.random.randn(17)

    def forward(self, x):
        # x shape: (batch_size, 512)
        dense1_output = x @ self.weights_dense1_w + self.weights_dense1_b
        dense2_output = dense1_output @ self.weights_dense2_w + self.weights_dense2_b
        final_output = dense2_output @ self.weights_final_w + self.weights_final_b
        return final_output

def main():
    model = SimpleNN()
    # Dummy input: batch of 4 samples, each with 512 features
    input_data = np.random.randn(4, 512)
    output = model.forward(input_data)
    print("Output shape:", output.shape)
    print("Output tensor:", output)

if __name__ == "__main__":
    main()