import numpy as np
import random

class Entity:
    def __init__(self, name, dim_p, dim_c):
        self.name = name
        self.collide = True
        self.movable = True
        self.dim_p = dim_p
        self.dim_c = dim_c
        self.pos = np.zeros(dim_p)
        self.vel = np.zeros(dim_p)
        self.color = np.zeros(3)
        self.c = np.zeros(dim_c)

class Agent(Entity):
    def __init__(self, name, dim_p, dim_c):
        super().__init__(name, dim_p, dim_c)
        self.collide = False
        self.goal_a = None  # target agent
        self.goal_b = None  # target landmark

class Landmark(Entity):
    def __init__(self, name, dim_p, dim_c):
        super().__init__(name, dim_p, dim_c)
        self.collide = False
        self.movable = False

class World:
    def __init__(self, dim_p=2, dim_c=10):
        self.dim_p = dim_p
        self.dim_c = dim_c
        self.collaborative = True
        self.agents = []
        self.landmarks = []

    def add_agent(self, agent):
        self.agents.append(agent)

    def add_landmark(self, landmark):
        self.landmarks.append(landmark)

    def reset(self):
        # Initialize agents
        for i in range(2):
            agent = Agent(f'agent {i}', self.dim_p, self.dim_c)
            self.add_agent(agent)
        # Initialize landmarks
        landmark_colors = [
            np.array([0.75, 0.25, 0.25]),
            np.array([0.25, 0.75, 0.25]),
            np.array([0.25, 0.25, 0.75]),
        ]
        for i in range(3):
            landmark = Landmark(f'landmark {i}', self.dim_p, self.dim_c)
            landmark.color = landmark_colors[i]
            self.add_landmark(landmark)

        # Random goal assignments
        landmark_indices = list(range(len(self.landmarks)))
        random.shuffle(landmark_indices)
        self.agents[0].goal_a = self.agents[1]
        self.agents[0].goal_b = self.landmarks[landmark_indices[0]]
        self.agents[1].goal_a = self.agents[0]
        self.agents[1].goal_b = self.landmarks[landmark_indices[1]]

        # Colors
        for agent in self.agents:
            agent.color = np.array([0.25, 0.25, 0.25])
        for agent in self.agents:
            if agent.goal_b is not None:
                agent.goal_b.color = agent.goal_a.color

        # Random positions within [-1, 1]
        for entity in self.agents + self.landmarks:
            entity.pos = np.random.uniform(-1.0, 1.0, self.dim_p)
            entity.vel = np.zeros(self.dim_p)
            entity.c = np.zeros(self.dim_c)

    def reward(self, agent):
        if agent.goal_a is None or agent.goal_b is None:
            return 0.0
        diff = agent.goal_a.pos - agent.goal_b.pos
        return -np.dot(diff, diff)

    def observation(self, agent):
        # Own velocity
        obs = [agent.vel]
        # Relative positions of all landmarks
        for lm in self.landmarks:
            obs.append(lm.pos - agent.pos)
        # Color of goal landmark
        if agent.goal_b is not None:
            obs.append(agent.goal_b.color)
        else:
            obs.append(np.zeros(3))
        # Communication states of other agents
        for other in self.agents:
            if other is not agent:
                obs.append(other.c)
        return np.concatenate(obs)

# Example usage
if __name__ == "__main__":
    world = World()
    world.reset()
    for agent in world.agents:
        print(f"{agent.name} reward: {world.reward(agent)}")
        print(f"{agent.name} observation shape: {world.observation(agent).shape}")