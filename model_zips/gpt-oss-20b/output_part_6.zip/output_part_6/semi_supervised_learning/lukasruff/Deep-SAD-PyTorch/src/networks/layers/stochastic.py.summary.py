import torch
import torch.nn as nn
import torch.nn.functional as F

class Stochastic:
    def reparametrize(self, mu: torch.Tensor, log_var: torch.Tensor) -> torch.Tensor:
        epsilon = torch.randn_like(log_var)
        std = torch.exp(0.5 * log_var)
        z = torch.addcmul(mu, epsilon, std, value=1)
        return z

class GaussianSample(nn.Module, Stochastic):
    def __init__(self, input_dim: int, output_dim: int):
        super().__init__()
        self.mu = nn.Linear(input_dim, output_dim)
        self.log_var = nn.Linear(input_dim, output_dim)

    def forward(self, x: torch.Tensor):
        mu = self.mu(x)
        log_var = F.softplus(self.log_var(x))
        z = self.reparametrize(mu, log_var)
        return z, mu, log_var

if __name__ == "__main__":
    # Example usage
    batch_size, input_dim, output_dim = 4, 10, 5
    x = torch.randn(batch_size, input_dim)
    model = GaussianSample(input_dim, output_dim)
    z, mu, log_var = model(x)
    print("Sampled z:", z)
    print("Mean mu:", mu)
    print("Log variance log_var:", log_var)