import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.distributions as dist
import torch.optim as optim
from torch.optim.lr_scheduler import LinearLR
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence, PackedSequence
import pytest

# --------------------------------------------------------------------------- #
# Utility functions and classes
# --------------------------------------------------------------------------- #

def make_fc(layers, input_dim):
    if isinstance(layers, int):
        layers = [layers]
    if not isinstance(layers, list):
        raise TypeError("layers must be int or list of ints")
    for l in layers:
        if not isinstance(l, int):
            raise TypeError("each layer size must be int")
    modules = nn.ModuleList()
    in_dim = input_dim
    for out_dim in layers:
        modules.append(nn.Linear(in_dim, out_dim))
        in_dim = out_dim
    return modules

def make_cnn(in_channels, out_channels, kernel_sizes, strides, paddings, groups=None):
    if groups is None:
        groups = [1] * len(out_channels)
    if not (len(out_channels) == len(kernel_sizes) == len(strides) == len(paddings) == len(groups)):
        raise ValueError("All parameter lists must have the same length")
    modules = nn.ModuleList()
    in_ch = in_channels
    for out_ch, k, s, p, g in zip(out_channels, kernel_sizes, strides, paddings, groups):
        modules.append(nn.Conv2d(in_ch, out_ch, kernel_size=k, stride=s, padding=p, groups=g))
        in_ch = out_ch
    return modules

def make_transposed_cnn(in_channels, out_channels, kernel_sizes, strides, paddings, output_paddings, groups=None):
    if groups is None:
        groups = [1] * len(out_channels)
    if not (len(out_channels) == len(kernel_sizes) == len(strides) == len(paddings) == len(output_paddings) == len(groups)):
        raise ValueError("All parameter lists must have the same length")
    modules = nn.ModuleList()
    in_ch = in_channels
    for out_ch, k, s, p, op, g in zip(out_channels, kernel_sizes, strides, paddings, output_paddings, groups):
        modules.append(nn.ConvTranspose2d(in_ch, out_ch, kernel_size=k, stride=s, padding=p,
                                          output_padding=op, groups=g))
        in_ch = out_ch
    return modules

def make_lnlstm(input_size, hidden_size, batch_size, seq_len, seq_lengths=None, bidirectional=False):
    lstm = nn.LSTM(input_size, hidden_size, batch_first=True, bidirectional=bidirectional)
    lstm.eval()
    if seq_lengths is None:
        seq_lengths = [seq_len] * batch_size
    x = torch.randn(batch_size, seq_len, input_size)
    packed = pack_padded_sequence(x, seq_lengths, batch_first=True, enforce_sorted=False)
    packed_out, _ = lstm(packed)
    out, _ = pad_packed_sequence(packed_out, batch_first=True)
    return out, packed_out

def ortho_init(module, gain=1.0, nonlinearity='linear'):
    for name, param in module.named_parameters():
        if param.ndimension() > 1:
            nn.init.orthogonal_(param.data, gain=gain)
        else:
            nn.init.zeros_(param.data)

class CategoricalHead(nn.Module):
    def __init__(self, feature_dim, num_actions):
        super().__init__()
        self.linear = nn.Linear(feature_dim, num_actions)

    def forward(self, x):
        logits = self.linear(x)
        return dist.Categorical(logits=logits)

class DiagGaussianHead(nn.Module):
    def __init__(self, feature_dim, action_dim, init_std=0.1):
        super().__init__()
        self.mean_linear = nn.Linear(feature_dim, action_dim)
        self.log_std = nn.Parameter(torch.full((action_dim,), torch.log(torch.tensor(init_std))))

    def forward(self, x):
        mean = self.mean_linear(x)
        std = torch.exp(self.log_std)
        return dist.Normal(mean, std).independent(1)

# --------------------------------------------------------------------------- #
# Tests
# --------------------------------------------------------------------------- #

class TestMakeBlocks:
    def test_make_fc(self):
        modules = make_fc([64, 32], 128)
        assert isinstance(modules, nn.ModuleList)
        assert len(modules) == 2
        assert modules[0].weight.shape == torch.Size([64, 128])
        assert modules[1].weight.shape == torch.Size([32, 64])

        modules_single = make_fc(64, 128)
        assert len(modules_single) == 1
        assert modules_single[0].weight.shape == torch.Size([64, 128])

        with pytest.raises(TypeError):
            make_fc("64", 128)

    def test_make_cnn(self):
        modules = make_cnn(
            in_channels=3,
            out_channels=[16, 32],
            kernel_sizes=[3, 3],
            strides=[1, 1],
            paddings=[1, 1]
        )
        assert isinstance(modules, nn.ModuleList)
        assert len(modules) == 2
        assert modules[0].weight.shape == torch.Size([16, 3, 3, 3])
        assert modules[1].weight.shape == torch.Size([32, 16, 3, 3])

        with pytest.raises(ValueError):
            make_cnn(
                in_channels=3,
                out_channels=[16],
                kernel_sizes=[3, 3],
                strides=[1, 1],
                paddings=[1, 1]
            )

    def test_make_transposed_cnn(self):
        modules = make_transposed_cnn(
            in_channels=3,
            out_channels=[16, 32],
            kernel_sizes=[3, 3],
            strides=[2, 2],
            paddings=[1, 1],
            output_paddings=[0, 0]
        )
        assert isinstance(modules, nn.ModuleList)
        assert len(modules) == 2
        assert modules[0].weight.shape == torch.Size([16, 3, 3, 3])
        assert modules[1].weight.shape == torch.Size([32, 16, 3, 3])

        with pytest.raises(ValueError):
            make_transposed_cnn(
                in_channels=3,
                out_channels=[16],
                kernel_sizes=[3, 3],
                strides=[2, 2],
                paddings=[1, 1],
                output_paddings=[0, 0]
            )

    @pytest.mark.parametrize(
        "input_size,hidden_size,batch_size,seq_len",
        [(4, 8, 2, 5), (3, 6, 3, 10)]
    )
    def test_make_lnlstm(self, input_size, hidden_size, batch_size, seq_len):
        out, packed = make_lnlstm(input_size, hidden_size, batch_size, seq_len)
        assert out.shape == (batch_size, seq_len, hidden_size)
        assert isinstance(packed, PackedSequence)

        # Test with packed sequence
        seq_lengths = [seq_len, seq_len - 1]
        x = torch.randn(batch_size, seq_len, input_size)
        packed_input = pack_padded_sequence(x, seq_lengths, batch_first=True, enforce_sorted=False)
        lstm = nn.LSTM(input_size, hidden_size, batch_first=True)
        packed_out, _ = lstm(packed_input)
        out2, _ = pad_packed_sequence(packed_out, batch_first=True)
        assert out2.shape == (batch_size, seq_len, hidden_size)

class TestInit:
    def test_ortho_init(self):
        linear = nn.Linear(10, 5)
        conv = nn.Conv2d(3, 6, 3)
        lstm = nn.LSTM(4, 7)
        lstm_cell = nn.LSTMCell(4, 7)

        ortho_init(linear, gain=0.8, nonlinearity='relu')
        ortho_init(conv, gain=0.8, nonlinearity='relu')
        ortho_init(lstm, gain=0.8, nonlinearity='relu')
        ortho_init(lstm_cell, gain=0.8, nonlinearity='relu')

        assert linear.weight.shape == torch.Size([5, 10])
        assert conv.weight.shape == torch.Size([6, 3, 3, 3])
        assert lstm.weight_ih_l0.shape[0] == 7 * 4
        assert lstm.weight_hh_l0.shape[0] == 7 * 7
        assert lstm_cell.weight_ih.shape[0] == 7 * 4

@pytest.mark.parametrize(
    "optimizer_cls, lr, steps",
    [
        (optim.Adam, 1e-3, 5),
        (optim.RMSprop, 5e-4, 10),
        (optim.Adamax, 2e-3, 7),
    ]
)
def test_linear_lr_scheduler(optimizer_cls, lr, steps):
    model = nn.Linear(10, 10)
    optimizer = optimizer_cls(model.parameters(), lr=lr)
    scheduler = LinearLR(optimizer, start_factor=1.0, end_factor=0.1, total_iters=steps)
    init_lr = optimizer.param_groups[0]['lr']
    for _ in range(steps):
        scheduler.step()
    final_lr = optimizer.param_groups[0]['lr']
    assert pytest.approx(final_lr, rel=1e-2) == lr * 0.1

def test_categorical_head():
    feature_dim = 32
    num_actions = 5
    batch_size = 4
    head = CategoricalHead(feature_dim, num_actions)
    x = torch.randn(batch_size, feature_dim)
    dist_out = head(x)
    assert isinstance(dist_out, dist.Categorical)
    assert dist_out.probs.shape == (batch_size, num_actions)
    samples = dist_out.sample()
    assert samples.shape == (batch_size,)

def test_diag_gaussian_head():
    feature_dim = 32
    action_dim = 6
    init_std = 0.05
    batch_size = 3
    head = DiagGaussianHead(feature_dim, action_dim, init_std=init_std)
    x = torch.randn(batch_size, feature_dim)
    dist_out = head(x)
    assert isinstance(dist_out, dist.Normal)
    assert dist_out.mean.shape == (batch_size, action_dim)
    assert torch.allclose(dist_out.stddev, torch.full((action_dim,), init_std))
    samples = dist_out.sample()
    assert samples.shape == (batch_size, action_dim)