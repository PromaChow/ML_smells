import numpy as np
from typing import Callable, Iterable, List, Optional, Tuple, Union
from PIL import Image
import time

class PLE:
    NOOP = 0

    def __init__(
        self,
        game: object,
        fps: int = 60,
        frame_skip: int = 4,
        num_steps: int = 1,
        force_fps: bool = False,
        add_noop_action: bool = True,
        display_screen: bool = True,
        seed: Optional[int] = None,
        reward_values: Optional[dict] = None,
        state_preprocessor: Optional[Callable[[object], np.ndarray]] = None,
    ):
        self.game = game
        self.fps = fps
        self.frame_skip = frame_skip
        self.num_steps = num_steps
        self.force_fps = force_fps
        self.add_noop_action = add_noop_action
        self.display_screen = display_screen
        self.state_preprocessor = state_preprocessor

        if reward_values is not None:
            if hasattr(self.game, "setRewardValues"):
                self.game.setRewardValues(reward_values)

        self.rng = np.random.RandomState(seed)

        # Initialise the game environment
        if hasattr(self.game, "_setup"):
            self.game._setup()
        if hasattr(self.game, "init"):
            self.game.init()

        # Validate FPS
        if hasattr(self.game, "getFps"):
            game_fps = self.game.getFps()
            if game_fps != self.fps:
                raise ValueError(f"Game FPS {game_fps} does not match requested FPS {self.fps}")

        # Determine state dimensions
        raw_state = self.getGameState()
        if self.state_preprocessor is not None:
            processed_state = self.state_preprocessor(raw_state)
            self.state_dim = processed_state.shape
        else:
            self.state_dim = None

        self.prev_score = self.game.getScore() if hasattr(self.game, "getScore") else 0
        self.current_action = self.NOOP
        self.frame_count = 0
        self.total_reward = 0

    def _tick(self) -> float:
        if self.force_fps:
            return 1000.0 / self.fps
        if hasattr(self.game, "tick"):
            return self.game.tick()
        return 0.0

    def init(self) -> None:
        if hasattr(self.game, "_setup"):
            self.game._setup()
        if hasattr(self.game, "init"):
            self.game.init()

    def getActionSet(self) -> List[int]:
        actions = []
        if hasattr(self.game, "getActionSet"):
            actions = list(self.game.getActionSet())
        if self.add_noop_action:
            if self.NOOP not in actions:
                actions.append(self.NOOP)
        return actions

    def act(self, action: int) -> float:
        cumulative_reward = 0.0
        for _ in range(self.frame_skip):
            reward = self._oneStepAct(action)
            cumulative_reward += reward
        self.total_reward += cumulative_reward
        return cumulative_reward

    def _oneStepAct(self, action: int) -> float:
        if not hasattr(self.game, "getActionSet"):
            valid_actions = []
        else:
            valid_actions = list(self.game.getActionSet())

        if action not in valid_actions:
            action = self.NOOP

        self._setAction(action)

        if hasattr(self.game, "isGameOver") and self.game.isGameOver():
            return 0.0

        for _ in range(self.num_steps):
            if hasattr(self.game, "tick"):
                self.game.tick()
            if hasattr(self.game, "isGameOver") and self.game.isGameOver():
                break

        reward = self._getReward()
        return reward

    def _setAction(self, action: int) -> None:
        self.current_action = action
        if hasattr(self.game, "setAction"):
            self.game.setAction(action)

    def getGameState(self) -> object:
        if hasattr(self.game, "getGameState"):
            raw_state = self.game.getGameState()
            if self.state_preprocessor is not None:
                return self.state_preprocessor(raw_state)
            return raw_state
        return None

    def _getReward(self) -> float:
        if hasattr(self.game, "getScore"):
            current_score = self.game.getScore()
            reward = current_score - self.prev_score
            self.prev_score = current_score
            return reward
        return 0.0

    def getScreenRGB(self) -> np.ndarray:
        if hasattr(self.game, "getScreenRGB"):
            return self.game.getScreenRGB()
        return np.array([])

    def getScreenGrayscale(self) -> np.ndarray:
        rgb = self.getScreenRGB()
        if rgb.size == 0:
            return rgb
        return np.dot(rgb[...,:3], [0.2989, 0.5870, 0.1140])

    def saveScreen(self, filename: str) -> None:
        rgb = self.getScreenRGB()
        if rgb.size == 0:
            return
        img = Image.fromarray(rgb)
        img.save(filename)

    def getScreenDims(self) -> Tuple[int, int]:
        if hasattr(self.game, "getScreenDims"):
            return self.game.getScreenDims()
        return (0, 0)

    def _draw_frame(self) -> None:
        if self.display_screen and hasattr(self.game, "draw"):
            self.game.draw()

    def reset_game(self) -> None:
        if hasattr(self.game, "reset"):
            self.game.reset()
        self.current_action = self.NOOP
        self.frame_count = 0
        self.total_reward = 0
        if hasattr(self.game, "getScore"):
            self.prev_score = self.game.getScore()

    def game_over(self) -> bool:
        if hasattr(self.game, "isGameOver"):
            return self.game.isGameOver()
        return False

    def score(self) -> Union[int, float]:
        if hasattr(self.game, "getScore"):
            return self.game.getScore()
        return 0

    def lives(self) -> Union[int, float]:
        if hasattr(self.game, "getLives"):
            return self.game.getLives()
        return 0
