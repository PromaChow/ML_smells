import torch
import torch.nn as nn
import numpy as np
import pytest

class Branched(nn.Module):
    def __init__(self, *links: nn.Module):
        super().__init__()
        self.links = nn.ModuleList(links)

    def forward(self, x: torch.Tensor):
        return tuple(link(x) for link in self.links)

@pytest.mark.parametrize("batch_size", [1, 2])
def test_branched_forward(batch_size):
    # Sub-link initialization
    link1 = nn.Linear(2, 3)
    link2 = nn.Linear(2, 5)
    link3 = nn.Sequential(nn.Linear(2, 7), nn.Tanh())

    # Branched link construction
    branched = Branched(link1, link2, link3)

    # Input preparation
    x = torch.zeros(batch_size, 2, dtype=torch.float32)

    # Forward pass
    pout = branched(x)

    # Output validation
    assert isinstance(pout, tuple)
    assert len(pout) == 3

    expected_outputs = (link1(x), link2(x), link3(x))
    for out, exp in zip(pout, expected_outputs):
        np.testing.assert_allclose(out.detach().numpy(), exp.detach().numpy(), rtol=1e-5, atol=1e-8)