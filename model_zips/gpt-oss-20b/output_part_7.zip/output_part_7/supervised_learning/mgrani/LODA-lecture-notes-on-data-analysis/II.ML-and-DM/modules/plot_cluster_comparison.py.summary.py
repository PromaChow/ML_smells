import numpy as np
import matplotlib.pyplot as plt
import time
from sklearn import datasets
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import (
    MeanShift,
    MiniBatchKMeans,
    AgglomerativeClustering,
    SpectralClustering,
    DBSCAN,
    AffinityPropagation,
)
from sklearn.neighbors import kneighbors_graph
from sklearn.metrics.pairwise import euclidean_distances
from sklearn import cluster

np.random.seed(0)

# 1. Data generation
datasets_list = []

X_circles, _ = datasets.make_circles(
    n_samples=1500, factor=0.5, noise=0.05, random_state=0
)
datasets_list.append(("Noisy Circles", X_circles))

X_moons, _ = datasets.make_moons(n_samples=1500, noise=0.05, random_state=0)
datasets_list.append(("Noisy Moons", X_moons))

X_blobs, _ = datasets.make_blobs(
    n_samples=1500, centers=3, cluster_std=0.6, random_state=8
)
datasets_list.append(("Blobs", X_blobs))

X_random = np.random.rand(1500, 2)
datasets_list.append(("No Structure", X_random))

# 2. Clustering algorithm names
alg_names = [
    "MeanShift",
    "MiniBatchKMeans",
    "AgglomerativeWard",
    "Spectral",
    "DBSCAN",
    "AffinityPropagation",
    "AgglomerativeAvg",
]

# 3. Prepare figure
n_rows = len(datasets_list)
n_cols = len(alg_names)
fig, axes = plt.subplots(n_rows, n_cols, figsize=(4 * n_cols, 3 * n_rows))
if n_rows == 1:
    axes = np.expand_dims(axes, axis=0)
if n_cols == 1:
    axes = np.expand_dims(axes, axis=1)

# 4. Colors
colors = plt.cm.tab10(np.arange(10))

# 5. Process each dataset
for i, (name, X) in enumerate(datasets_list):
    X_norm = StandardScaler().fit_transform(X)

    # Parameter estimation
    bandwidth = cluster.estimate_bandwidth(X_norm, quantile=0.3, n_samples=500)
    connectivity = kneighbors_graph(
        X_norm, n_neighbors=10, mode="connectivity", include_self=False
    ).toarray()
    connectivity = 0.5 * (connectivity + connectivity.T)
    distances = euclidean_distances(X_norm)  # not used

    # Instantiate algorithms
    clusts = [
        MeanShift(bandwidth=bandwidth, bin_seeding=True),
        MiniBatchKMeans(n_clusters=2, random_state=0),
        AgglomerativeClustering(
            n_clusters=2, linkage="ward", connectivity=connectivity
        ),
        SpectralClustering(
            n_clusters=2,
            eigen_solver="arpack",
            affinity="nearest_neighbors",
            random_state=0,
        ),
        DBSCAN(eps=0.2),
        AffinityPropagation(damping=0.9, preference=-200, random_state=0),
        AgglomerativeClustering(
            n_clusters=2, linkage="average", affinity="cityblock", connectivity=connectivity
        ),
    ]

    # Run and plot
    for j, (alg_name, clust) in enumerate(zip(alg_names, clusts)):
        ax = axes[i, j]
        t0 = time.time()
        if hasattr(clust, "fit_predict"):
            y_pred = clust.fit_predict(X_norm)
        else:
            clust.fit(X_norm)
            y_pred = clust.labels_
        t1 = time.time()

        # Scatter plot
        ax.scatter(
            X_norm[:, 0],
            X_norm[:, 1],
            c=colors[y_pred % len(colors)],
            s=15,
            cmap="viridis",
        )

        # Plot cluster centers if available
        if hasattr(clust, "cluster_centers_"):
            ax.scatter(
                clust.cluster_centers_[:, 0],
                clust.cluster_centers_[:, 1],
                s=200,
                c="red",
                marker="X",
            )

        ax.set_title(f"{alg_name}\n{t1 - t0:.2f}s")
        ax.set_xlabel("x1")
        ax.set_ylabel("x2")
        ax.set_xlim(X_norm[:, 0].min() - 0.5, X_norm[:, 0].max() + 0.5)
        ax.set_ylim(X_norm[:, 1].min() - 0.5, X_norm[:, 1].max() + 0.5)
        ax.set_xticks([])
        ax.set_yticks([])

# 6. Adjust layout and display
plt.subplots_adjust(hspace=0.5, wspace=0.3)
plt.show()
