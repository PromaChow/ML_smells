import argparse

from genrl.agents import SAC, A2C, PPO1, DDPG, TD3, VPG, DQN
from genrl.trainers import OnPolicyTrainer, OffPolicyTrainer
from genrl.envs import VectorEnv


ALGOS = {
    "SAC": SAC,
    "A2C": A2C,
    "PPO1": PPO1,
    "DDPG": DDPG,
    "TD3": TD3,
    "VPG": VPG,
    "DQN": DQN,
}


def parse_log_destinations(log_arg: str):
    if not log_arg:
        return []
    destinations = [dest.strip() for dest in log_arg.split(",") if dest.strip()]
    return destinations


def main():
    parser = argparse.ArgumentParser(description="Reproducible RL training framework.")
    parser.add_argument("--algo", type=str, default="ppo", help="Algorithm selection")
    parser.add_argument("--env", type=str, default="CartPole-v0", help="Environment ID")
    parser.add_argument("--env-type", type=str, default="gym", help="Environment type")
    parser.add_argument("--n-envs", type=int, default=2, help="Number of vectorized environments")
    parser.add_argument("--serial", action="store_true", default=True, help="Run environments serially")
    parser.add_argument("--epochs", type=int, default=100, help="Training epochs")
    parser.add_argument("--render", action="store_true", default=False, help="Render environment")
    parser.add_argument("--log", type=str, default="stdout", help="Comma separated log destinations")
    parser.add_argument("--arch", type=str, default="mlp", help="Neural network architecture")
    parser.add_argument("--rollout-size", type=int, default=2048, help="Rollout size for on-policy")
    parser.add_argument("--warmup-steps", type=int, default=10000, help="Warmup steps for off-policy")
    parser.add_argument("--replay-size", type=int, default=1000, help="Replay buffer size for off-policy")
    parser.add_argument("--batch-size", type=int, default=128, help="Batch size for off-policy")

    args = parser.parse_args()

    # Resolve algorithm class
    algo_key = args.algo.upper()
    if algo_key not in ALGOS:
        raise ValueError(f"Unsupported algorithm '{args.algo}'. Supported: {list(ALGOS.keys())}")
    algo_cls = ALGOS[algo_key]

    # Initialize vectorized environment
    env = VectorEnv(
        env_id=args.env,
        n_envs=args.n_envs,
        env_type=args.env_type,
        serial=args.serial,
    )

    # Prepare logger destinations
    logger_destinations = parse_log_destinations(args.log)

    # Determine policy type
    on_policy_algs = {"PPO1", "VPG", "A2C"}
    off_policy_algs = {"SAC", "DDPG", "TD3", "DQN"}

    if algo_key in on_policy_algs:
        agent = algo_cls(arch=args.arch, env=env, rollout_size=args.rollout_size)
        trainer = OnPolicyTrainer(
            env=env,
            agent=agent,
            logger=logger_destinations,
            epochs=args.epochs,
            render=args.render,
            log_interval=10,
        )
    elif algo_key in off_policy_algs:
        agent = algo_cls(
            arch=args.arch,
            env=env,
            replay_size=args.replay_size,
            batch_size=args.batch_size,
        )
        trainer = OffPolicyTrainer(
            env=env,
            agent=agent,
            logger=logger_destinations,
            epochs=args.epochs,
            render=args.render,
            warmup_steps=args.warmup_steps,
            log_interval=10,
        )
    else:
        raise RuntimeError(f"Algorithm '{algo_key}' not recognized as on/off-policy.")

    trainer.train()
    trainer.evaluate()


if __name__ == "__main__":
    main()
