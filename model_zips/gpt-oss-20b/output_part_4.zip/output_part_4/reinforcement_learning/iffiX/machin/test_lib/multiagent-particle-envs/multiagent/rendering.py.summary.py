import sys
import math
import ctypes
from collections import namedtuple

try:
    import pyglet
except ImportError as e:
    raise ImportError("Pyglet is required. Install via: pip install pyglet") from e

try:
    from pyglet.gl import *
except Exception as e:
    raise ImportError("OpenGL bindings via pyglet are required. Install via: pip install pyglet") from e

# Platform specific configuration
if sys.platform == "darwin":
    pyglet.options["window"] = "ns"

# Basic data structures
Transform = namedtuple("Transform", ["position", "rotation", "scale"])
Color = namedtuple("Color", ["r", "g", "b", "a"])

class Geom:
    def __init__(self, vertices, color=Color(1.0, 1.0, 1.0, 1.0), line_width=1.0, filled=True):
        self.vertices = vertices  # list of (x, y)
        self.color = color
        self.line_width = line_width
        self.filled = filled

    def apply_transform(self, transform):
        # Simple affine transform: scale, rotate, translate
        cos_r = math.cos(math.radians(transform.rotation))
        sin_r = math.sin(math.radians(transform.rotation))
        sx, sy = transform.scale
        tx, ty = transform.position
        transformed = []
        for x, y in self.vertices:
            # Scale
            x *= sx
            y *= sy
            # Rotate
            xr = x * cos_r - y * sin_r
            yr = x * sin_r + y * cos_r
            # Translate
            transformed.append((xr + tx, yr + ty))
        return transformed

    def draw(self, transform):
        glColor4f(*self.color)
        glLineWidth(self.line_width)
        verts = self.apply_transform(transform)
        if self.filled:
            glBegin(GL_POLYGON)
        else:
            glBegin(GL_LINE_LOOP)
        for vx, vy in verts:
            glVertex2f(vx, vy)
        glEnd()

class CompoundGeom:
    def __init__(self, parts):
        self.parts = parts  # list of Geom

    def draw(self, transform):
        for part in self.parts:
            part.draw(transform)

def make_circle(center, radius, color=Color(1.0, 1.0, 1.0, 1.0), filled=True, line_width=1.0, segments=32):
    cx, cy = center
    vertices = []
    for i in range(segments):
        angle = 2 * math.pi * i / segments
        x = cx + radius * math.cos(angle)
        y = cy + radius * math.sin(angle)
        vertices.append((x, y))
    return Geom(vertices, color=color, line_width=line_width, filled=filled)

def make_polygon(points, color=Color(1.0, 1.0, 1.0, 1.0), filled=True, line_width=1.0):
    return Geom(points, color=color, line_width=line_width, filled=filled)

class SimpleImageViewer:
    def __init__(self, width, height, image_data=None):
        self.width = width
        self.height = height
        if image_data is None:
            self.image_data = pyglet.image.ImageData(width, height, "RGB", bytes([0]*width*height*3))
        else:
            self.image_data = pyglet.image.ImageData(width, height, "RGB", image_data)
        self.sprite = pyglet.sprite.Sprite(self.image_data)

    def update(self, image_data):
        self.image_data = pyglet.image.ImageData(self.width, self.height, "RGB", image_data)
        self.sprite.texture = self.image_data.get_texture()

    def draw(self):
        self.sprite.draw()

class Viewer:
    def __init__(self, width=800, height=600, title="2D Renderer"):
        self.width = width
        self.height = height
        config = pyglet.gl.Config(double_buffer=True, samples=4)
        self.window = pyglet.window.Window(width=width, height=height, caption=title, config=config)
        self.window.push_handlers(self)
        self.geometries = []
        self.transform = Transform((0, 0), 0, (1, 1))
        self._setup_gl()

    def _setup_gl(self):
        glClearColor(0.0, 0.0, 0.0, 1.0)
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)
        glEnable(GL_LINE_SMOOTH)
        glEnable(GL_MULTISAMPLE)
        glViewport(0, 0, self.width, self.height)
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        gluOrtho2D(0, self.width, 0, self.height)
        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()

    def add_geom(self, geom):
        self.geometries.append(geom)

    def clear(self):
        self.geometries.clear()

    def on_draw(self):
        self.window.clear()
        glLoadIdentity()
        for geom in self.geometries:
            geom.draw(self.transform)

    def on_close(self):
        self.close()

    def close(self):
        self.window.close()

    def render_to_array(self):
        buffer = (GLubyte * (self.width * self.height * 3))()
        glPixelStorei(GL_PACK_ALIGNMENT, 1)
        glReadPixels(0, 0, self.width, self.height, GL_RGB, GL_UNSIGNED_BYTE, buffer)
        # Convert to numpy array if available, else bytes
        try:
            import numpy as np
            arr = np.frombuffer(buffer, dtype=np.uint8).reshape((self.height, self.width, 3))
            arr = np.flipud(arr)
            return arr
        except ImportError:
            return buffer

# Example usage
if __name__ == "__main__":
    viewer = Viewer(400, 300, "Demo")
    circle = make_circle((200, 150), 80, color=Color(0.0, 0.5, 1.0, 1.0), filled=True)
    polygon = make_polygon([(100, 100), (150, 200), (50, 200)], color=Color(1.0, 0.0, 0.0, 1.0), filled=False, line_width=3.0)
    viewer.add_geom(circle)
    viewer.add_geom(polygon)
    pyglet.app.run()