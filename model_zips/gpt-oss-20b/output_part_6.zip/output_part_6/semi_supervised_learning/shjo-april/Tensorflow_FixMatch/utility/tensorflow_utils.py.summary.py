import random
import numpy as np
import tensorflow as tf

tf.compat.v1.disable_eager_execution()


def set_seed(seed: int = 42):
    random.seed(seed)
    np.random.seed(seed)
    tf.compat.v1.set_random_seed(seed)


def get_model_vars(scope: str):
    return tf.compat.v1.get_collection(tf.compat.v1.GraphKeys.TRAINABLE_VARIABLES, scope=scope)


def get_getter(ema: tf.train.ExponentialMovingAverage):
    def ema_getter(getter, name, *args, **kwargs):
        return ema.average(getter(name, *args, **kwargs))
    return ema_getter


def load_graph(file_path: str, graph: tf.Graph = None):
    if graph is None:
        graph = tf.Graph()
    with graph.as_default():
        with tf.io.gfile.GFile(file_path, "rb") as f:
            graph_def = tf.compat.v1.GraphDef()
            graph_def.ParseFromString(f.read())
            tf.import_graph_def(graph_def, name="")
    return graph


def calculate_FLOPs(graph: tf.Graph, input_graph_def: tf.compat.v1.GraphDef):
    with graph.as_default():
        opts = tf.compat.v1.profiler.ProfileOptionBuilder.float_operation()
        flops = tf.compat.v1.profiler.profile(graph=graph, run_meta=None, cmd="op", options=opts)
        if flops is None or flops.total_float_ops is None:
            return "N/A"
        ops = flops.total_float_ops
        if ops >= 1e9:
            return f"{ops / 1e9:.2f} GFLOPs"
        elif ops >= 1e6:
            return f"{ops / 1e6:.2f} MFLOPs"
        else:
            return f"{ops} FLOPs"


def model_summary(file_path: str, scope: str = ""):
    vars = get_model_vars(scope)
    with tf.compat.v1.Session() as sess:
        total_params = 0
        lines = []
        for v in vars:
            shape = v.shape.as_list()
            count = np.prod(shape)
            total_params += count
            lines.append(f"{v.name} {shape} {count:,}")
        flops = calculate_FLOPs(sess.graph, sess.graph.as_graph_def())
        lines.append(f"Total parameters: {total_params:,}")
        lines.append(f"FLOPs: {flops}")
        with open(file_path, "w") as f:
            f.write("\n".join(lines))


def KL_Divergence_with_logits(logits_p, logits_q):
    p = tf.nn.softmax(logits_p)
    log_p = tf.nn.log_softmax(logits_p)
    log_q = tf.nn.log_softmax(logits_q)
    kl = tf.reduce_sum(p * (log_p - log_q), axis=-1)
    return kl


def interleave(x, batch_dim=0):
    shape = tf.shape(x)
    batch_size = shape[batch_dim]
    num_groups = 2
    reshaped = tf.reshape(x, tf.concat([shape[:batch_dim], [num_groups, batch_size // num_groups], shape[batch_dim + 1:]], axis=0))
    transposed = tf.transpose(reshaped, perm=[batch_dim, batch_dim + 1] + list(range(batch_dim)) + list(range(batch_dim + 2, len(shape))))
    final_shape = tf.concat([shape[:batch_dim], [batch_size], shape[batch_dim + 1:]], axis=0)
    return tf.reshape(transposed, final_shape)


def de_interleave(x, batch_dim=0):
    shape = tf.shape(x)
    batch_size = shape[batch_dim]
    num_groups = 2
    reshaped = tf.reshape(x, tf.concat([shape[:batch_dim], [batch_size // num_groups, num_groups], shape[batch_dim + 1:]], axis=0))
    transposed = tf.transpose(reshaped, perm=[batch_dim, batch_dim + 1] + list(range(batch_dim)) + list(range(batch_dim + 2, len(shape))))
    final_shape = tf.concat([shape[:batch_dim], [batch_size], shape[batch_dim + 1:]], axis=0)
    return tf.reshape(transposed, final_shape)


if __name__ == "__main__":
    set_seed(123)
    logits_p = tf.constant([[2.0, 0.5, 1.2], [0.1, 0.3, 0.6]])
    logits_q = tf.constant([[1.0, 0.8, 1.5], [0.2, 0.4, 0.7]])
    kl = KL_Divergence_with_logits(logits_p, logits_q)
    with tf.compat.v1.Session() as sess:
        kl_val = sess.run(kl)
        print("KL divergence:", kl_val)