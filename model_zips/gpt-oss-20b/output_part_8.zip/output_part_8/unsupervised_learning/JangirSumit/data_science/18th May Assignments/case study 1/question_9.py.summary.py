import numpy as np
import random

np_array = np.random.random(30)
x = 0
y = 0

while x * y != 30:
    x = random.randint(1, 31)
    y = random.randint(1, 31)

reshaped_arr = np_array.reshape((x, y))
print(reshaped_arr)
print(reshaped_arr.mean())