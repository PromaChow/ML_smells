import unittest
import numpy as np
from cpe_ene import cpe
from gen_twonorm_ssl import gen_twonorm_ssl

class TestCpe_Ene(unittest.TestCase):
    def setUp(self):
        # Generate synthetic data once for both tests
        self.n_l = 100
        self.n_u = 300
        self.prior_l = 0.5
        self.prior_u = 0.3
        self.n_t = 100
        # Assume gen_twonorm_ssl returns (X, y)
        self.X, self.y = gen_twonorm_ssl(
            n_l=self.n_l,
            n_u=self.n_u,
            prior_l=self.prior_l,
            prior_u=self.prior_u,
            n_t=self.n_t
        )
        # Separate labeled and unlabeled data
        self.x_l = self.X[self.y != 0]
        self.y_l = self.y[self.y != 0]
        self.x_u = self.X[self.y == 0]

    def test_alpha_one(self):
        priorh = cpe(self.x_l, self.y_l, self.x_u)
        self.assertTrue(0.2 <= priorh <= 0.4, f"Expected priorh within [0.2, 0.4], got {priorh}")

    def test_alpha_half(self):
        priorh = cpe(self.x_l, self.y_l, self.x_u, alpha=0.5)
        print(f"Estimated prior (alpha=0.5): {priorh}")

if __name__ == "__main__":
    unittest.main()