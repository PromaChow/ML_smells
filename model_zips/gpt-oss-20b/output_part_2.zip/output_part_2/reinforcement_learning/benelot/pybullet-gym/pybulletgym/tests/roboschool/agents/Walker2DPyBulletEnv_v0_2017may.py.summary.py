import numpy as np

# Define weights and biases for the dense layers
weights_dense1_w = np.random.randn(64, 128).astype(np.float32)
weights_dense1_b = np.random.randn(128).astype(np.float32)

weights_dense2_w = np.random.randn(128, 64).astype(np.float32)
weights_dense2_b = np.random.randn(64).astype(np.float32)

weights_final_w = np.random.randn(64, 6).astype(np.float32)
weights_final_b = np.random.randn(6).astype(np.float32)

def relu(x: np.ndarray) -> np.ndarray:
    return np.maximum(0, x)

def dense_layer(x: np.ndarray, w: np.ndarray, b: np.ndarray) -> np.ndarray:
    return x @ w + b

def preprocess_input(raw_input: np.ndarray) -> np.ndarray:
    """
    Convert input from shape (100, 100, 64) to (100, 64) by averaging over the 100x64 matrix.
    """
    return raw_input.mean(axis=1)

def model_predict(raw_input: np.ndarray) -> np.ndarray:
    x = preprocess_input(raw_input)
    x = dense_layer(x, weights_dense1_w, weights_dense1_b)
    x = relu(x)
    x = dense_layer(x, weights_dense2_w, weights_dense2_b)
    x = relu(x)
    x = dense_layer(x, weights_final_w, weights_final_b)
    return x

# Example usage
if __name__ == "__main__":
    # Generate dummy input data: 100 samples of 100x64 matrices
    input_data = np.random.randn(100, 100, 64).astype(np.float32)
    predictions = model_predict(input_data)
    print("Predictions shape:", predictions.shape)
    print(predictions)