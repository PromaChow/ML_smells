import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib.cm as cm
import matplotlib.colors as colors
import matplotlib.patches as mpatches
from matplotlib.colors import ListedColormap, BoundaryNorm
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import export_graphviz
import graphviz

def plot_feature_importances(clf, feature_names):
    """
    Plot horizontal bar chart of feature importances.

    Parameters
    ----------
    clf : estimator with `feature_importances_` attribute
    feature_names : list of str
        Names of the features corresponding to the importances.
    """
    importances = getattr(clf, "feature_importances_", None)
    if importances is None:
        raise AttributeError("Classifier has no 'feature_importances_' attribute.")
    indices = np.argsort(importances)
    sorted_importances = importances[indices]
    sorted_features = np.array(feature_names)[indices]

    plt.figure(figsize=(8, len(feature_names) * 0.4))
    plt.barh(range(len(sorted_features)), sorted_importances, color="steelblue")
    plt.yticks(range(len(sorted_features)), sorted_features)
    plt.xlabel("Feature importance")
    plt.ylabel("Features")
    plt.title("Feature Importances")
    plt.tight_layout()
    plt.show()

def plot_labelled_scatter(X, y, class_labels, figsize=(8, 6)):
    """
    Scatter plot of 2D data with labels.

    Parameters
    ----------
    X : array-like, shape (n_samples, 2)
        Two-dimensional data points.
    y : array-like, shape (n_samples,)
        Integer class labels for each point.
    class_labels : list of str
        Human readable names for each class.
    figsize : tuple
        Size of the figure.
    """
    X = np.asarray(X)
    y = np.asarray(y)
    if X.shape[1] != 2:
        raise ValueError("X must have exactly 2 features for a 2D scatter plot.")

    n_classes = len(class_labels)
    cmap = ListedColormap(sns.color_palette(n_colors=n_classes))
    bounds = np.arange(n_classes + 1) - 0.5
    norm = BoundaryNorm(bounds, cmap.N)

    plt.figure(figsize=figsize)
    scatter = plt.scatter(X[:, 0], X[:, 1], c=y, cmap=cmap, norm=norm, edgecolor='k', s=50)
    plt.xlim(X[:, 0].min() - 1, X[:, 0].max() + 1)
    plt.ylim(X[:, 1].min() - 1, X[:, 1].max() + 1)

    patches = [mpatches.Patch(color=cmap(i), label=class_labels[i]) for i in range(n_classes)]
    plt.legend(handles=patches, title="Classes")
    plt.title("Scatter Plot by Class")
    plt.xlabel("Feature 1")
    plt.ylabel("Feature 2")
    plt.tight_layout()
    plt.show()

def plot_class_regions_for_classifier_subplot(
    clf,
    X,
    y,
    X_test,
    y_test,
    ax,
    title="Decision Regions",
    cmap_light=["#E0E0E0", "#D0D0D0", "#C0C0C0"],
    cmap_bold=["#1f77b4", "#ff7f0e", "#2ca02c"],
    markers=["o", "s", "^"],
):
    """
    Plot decision regions of a classifier on a given Axes object.

    Parameters
    ----------
    clf : estimator
        Trained classifier with a `predict` method.
    X : array-like, shape (n_samples, 2)
        Training feature matrix.
    y : array-like, shape (n_samples,)
        Training labels.
    X_test : array-like, shape (n_test_samples, 2)
        Test feature matrix. Can be None.
    y_test : array-like, shape (n_test_samples,)
        Test labels. Can be None.
    ax : matplotlib.axes.Axes
        Axes to plot on.
    title : str
        Base title of the plot.
    cmap_light : list of str
        Colors for the decision background.
    cmap_bold : list of str
        Colors for data points.
    markers : list of str
        Markers for each class.
    """
    X = np.asarray(X)
    y = np.asarray(y)
    if X_test is not None:
        X_test = np.asarray(X_test)
        y_test = np.asarray(y_test)
    if X.shape[1] != 2:
        raise ValueError("X must have exactly 2 features for decision region plot.")

    # Determine meshgrid bounds
    x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx, yy = np.meshgrid(
        np.arange(x_min, x_max, 0.01), np.arange(y_min, y_max, 0.01)
    )
    grid = np.c_[xx.ravel(), yy.ravel()]
    Z = clf.predict(grid).reshape(xx.shape)

    # Plot background decision regions
    ax.contourf(xx, yy, Z, alpha=0.3, colors=cmap_light[:len(np.unique(y))])

    # Plot training data
    for idx, class_val in enumerate(np.unique(y)):
        idxs = y == class_val
        ax.scatter(
            X[idxs, 0],
            X[idxs, 1],
            c=cmap_bold[idx % len(cmap_bold)],
            marker=markers[idx % len(markers)],
            edgecolor="k",
            label=f"Train class {class_val}",
            s=50,
        )

    # Plot test data if provided
    if X_test is not None and y_test is not None:
        for idx, class_val in enumerate(np.unique(y_test)):
            idxs = y_test == class_val
            ax.scatter(
                X_test[idxs, 0],
                X_test[idxs, 1],
                c=cmap_bold[idx % len(cmap_bold)],
                marker=markers[idx % len(markers)],
                edgecolor="k",
                label=f"Test class {class_val}",
                s=80,
                facecolors="none",
            )

    # Train/test accuracy
    train_acc = clf.score(X, y)
    if X_test is not None and y_test is not None:
        test_acc = clf.score(X_test, y_test)
        ax.set_title(f"{title}\nTrain acc: {train_acc:.2f}, Test acc: {test_acc:.2f}")
    else:
        ax.set_title(f"{title}\nTrain acc: {train_acc:.2f}")

    ax.set_xlim(xx.min(), xx.max())
    ax.set_ylim(yy.min(), yy.max())
    ax.set_xlabel("Feature 1")
    ax.set_ylabel("Feature 2")
    ax.legend(loc="upper right")

def plot_class_regions_for_classifier(
    clf,
    X,
    y,
    X_test=None,
    y_test=None,
    title="Decision Regions",
    cmap_light=["#E0E0E0", "#D0D0D0", "#C0C0C0"],
    cmap_bold=["#1f77b4", "#ff7f0e", "#2ca02c"],
    markers=["o", "s", "^"],
):
    """
    Plot decision regions of a classifier in a standalone figure.

    Parameters
    ----------
    clf : estimator
        Trained classifier with a `predict` method.
    X : array-like, shape (n_samples, 2)
        Training feature matrix.
    y : array-like, shape (n_samples,)
        Training labels.
    X_test : array-like, shape (n_test_samples, 2), optional
        Test feature matrix.
    y_test : array-like, shape (n_test_samples,), optional
        Test labels.
    title : str
        Base title of the plot.
    cmap_light : list of str
        Colors for the decision background.
    cmap_bold : list of str
        Colors for data points.
    markers : list of str
        Markers for each class.
    """
    fig, ax = plt.subplots(figsize=(8, 6))
    plot_class_regions_for_classifier_subplot(
        clf,
        X,
        y,
        X_test,
        y_test,
        ax,
        title=title,
        cmap_light=cmap_light,
        cmap_bold=cmap_bold,
        markers=markers,
    )
    plt.tight_layout()
    plt.show()

def plot_decision_tree_to_graphviz(clf, feature_names, class_names, out_file=None):
    """
    Export a decision tree classifier to a Graphviz source and optionally render to file.

    Parameters
    ----------
    clf : DecisionTreeClassifier
        Trained decision tree.
    feature_names : list of str
        Feature names.
    class_names : list of str
        Class names.
    out_file : str, optional
        Path to save the dot file. If None, only return Graphviz source.

    Returns
    -------
    graphviz.Source
    """
    if not hasattr(clf, "tree_"):
        raise AttributeError("Classifier is not a decision tree.")
    dot_data = export_graphviz(
        clf,
        out_file=None,
        feature_names=feature_names,
        class_names=class_names,
        filled=True,
        rounded=True,
        special_characters=True,
    )
    src = graphviz.Source(dot_data)
    if out_file is not None:
        src.render(out_file, format="pdf", cleanup=True)
    return src

# Example usage (commented out)
# if __name__ == "__main__":
#     from sklearn.datasets import load_iris
#     from sklearn.model_selection import train_test_split
#     from sklearn.tree import DecisionTreeClassifier
#
#     iris = load_iris()
#     X_train, X_test, y_train, y_test = train_test_split(
#         iris.data[:, :2], iris.target, test_size=0.3, random_state=42
#     )
#
#     clf = DecisionTreeClassifier(max_depth=3, random_state=42)
#     clf.fit(X_train, y_train)
#
#     plot_feature_importances(clf, iris.feature_names[:2])
#     plot_labelled_scatter(X_train, y_train, iris.target_names)
#     plot_class_regions_for_classifier(clf, X_train, y_train, X_test, y_test)
#     src = plot_decision_tree_to_graphviz(clf, iris.feature_names, iris.target_names)
#     src.view()
