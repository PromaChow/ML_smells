import torch
import torch.nn.functional as F
import torch.optim as optim
import GPUtil
import psutil
from typing import List, Dict, Tuple, Optional


class ModelSizeEstimator:
    def __init__(self, model: torch.nn.Module, size_multiplier: float = 2.0) -> None:
        self.model = model
        self.size_multiplier = size_multiplier

    @staticmethod
    def _tensor_size_bytes(tensor: torch.Tensor) -> int:
        return tensor.nelement() * tensor.element_size()

    def _size(self, tensors: List[torch.Tensor]) -> float:
        total_bytes = sum(self._tensor_size_bytes(t) for t in tensors)
        return total_bytes / (1024 ** 2)  # MB

    def parameter_size_mb(self) -> float:
        params = list(self.model.parameters())
        return self._size(params)

    def buffer_size_mb(self) -> float:
        buffers = list(self.model.buffers())
        return self._size(buffers)

    def total_memory_mb(self) -> float:
        param_mb = self.parameter_size_mb()
        buf_mb = self.buffer_size_mb()
        return (param_mb + buf_mb) * self.size_multiplier


class ModelAssigner:
    def __init__(
        self,
        models: List[torch.nn.Module],
        devices: Optional[List[int]] = None,
        model_size_multiplier: float = 1.0,
        max_mem_ratio: float = 0.8,
        cpu_weight: float = 0.0,
        cpu_gpu_distance: float = 5.0,
        gpu_gpu_distance: float = 1.0,
        connection_weight: float = 1.0,
        size_match_weight: float = 1.0,
        complexity_match_weight: float = 1.0,
        entropy_weight: float = 0.1,
        move_models: bool = False,
        iterations: int = 200,
        lr: float = 0.01,
        connection_dict: Optional[Dict[Tuple[int, int], float]] = None,
    ) -> None:
        self.models = models
        self.num_models = len(models)
        self.model_size_multiplier = model_size_multiplier
        self.max_mem_ratio = max_mem_ratio
        self.cpu_weight = cpu_weight
        self.cpu_gpu_distance = cpu_gpu_distance
        self.gpu_gpu_distance = gpu_gpu_distance
        self.connection_weight = connection_weight
        self.size_match_weight = size_match_weight
        self.complexity_match_weight = complexity_match_weight
        self.entropy_weight = entropy_weight
        self.move_models = move_models
        self.iterations = iterations
        self.lr = lr
        self.connection_dict = connection_dict or {}

        # Device handling
        self.available_gpus = GPUtil.getAvailable()
        if devices is None:
            if self.available_gpus:
                self.devices = self.available_gpus
            else:
                self.devices = []  # CPU only
        else:
            self.devices = [d for d in devices if d in self.available_gpus]

        # Include CPU if any GPU not present or explicitly requested
        if not self.devices:
            self.devices = []

        # Build device list including CPU as index 0
        self.device_list = ["cpu"] + [f"cuda:{idx}" for idx in self.devices]
        self.num_devices = len(self.device_list)

        # Compute device capacities
        self.device_mem_cap = torch.zeros(self.num_devices, dtype=torch.float32)
        self.device_comp_cap = torch.zeros(self.num_devices, dtype=torch.float32)

        for i, dev in enumerate(self.device_list):
            if dev == "cpu":
                mem = psutil.virtual_memory()
                self.device_mem_cap[i] = (mem.available / (1024 ** 2)) * self.max_mem_ratio
                self.device_comp_cap[i] = self.cpu_weight
            else:
                gpu_idx = int(dev.split(":")[1])
                gpu = GPUtil.getGPUs()[gpu_idx]
                free_mem = gpu.memoryFree * self.max_mem_ratio
                self.device_mem_cap[i] = free_mem
                load = gpu.load
                self.device_comp_cap[i] = 1.0 - load

        # Model sizes and complexities
        self.model_sizes = torch.tensor(
            [
                ModelSizeEstimator(m, size_multiplier=self.model_size_multiplier).total_memory_mb()
                for m in self.models
            ],
            dtype=torch.float32,
        )
        self.model_complexities = self.model_sizes.clone()

        # Connection adjacency matrix
        self.connection_matrix = torch.zeros((self.num_models, self.num_models), dtype=torch.float32)
        for (i, j), w in self.connection_dict.items():
            self.connection_matrix[i, j] = w
            self.connection_matrix[j, i] = w  # symmetric

        # Device distance matrix
        self.device_distance = torch.zeros((self.num_devices, self.num_devices), dtype=torch.float32)
        for i in range(self.num_devices):
            for j in range(self.num_devices):
                if i == j:
                    continue
                if self.device_list[i] == "cpu" or self.device_list[j] == "cpu":
                    self.device_distance[i, j] = self.cpu_gpu_distance
                else:
                    self.device_distance[i, j] = self.gpu_gpu_distance

        # Placement probabilities
        self.placement = torch.nn.Parameter(
            torch.randn(self.num_models, self.num_devices, requires_grad=True)
        )
        self.optimizer = optim.Adam([self.placement], lr=self.lr)

    def _softmax(self) -> torch.Tensor:
        return F.softmax(self.placement, dim=1)

    def _connection_cost(self, probs: torch.Tensor) -> torch.Tensor:
        # probs: [num_models, num_devices]
        # Expected device distance weighted by connections
        term = torch.einsum("md,mi,ij,jn,mn->", probs, self.connection_matrix, self.device_distance, probs, self.connection_matrix)
        return term

    def _size_match_cost(self, probs: torch.Tensor) -> torch.Tensor:
        assigned_size = probs.t() @ self.model_sizes  # [num_devices]
        deficit = F.relu(assigned_size - self.device_mem_cap)
        return deficit.sum()

    def _complexity_match_cost(self, probs: torch.Tensor) -> torch.Tensor:
        assigned_complexity = probs.t() @ self.model_complexities
        ratio = assigned_complexity / (self.device_comp_cap + 1e-8)
        overload = F.relu(ratio - 1.0)
        return overload.sum()

    def _entropy_cost(self, probs: torch.Tensor) -> torch.Tensor:
        eps = 1e-12
        ent = -(probs * (probs + eps).log()).sum()
        return ent

    def optimize(self) -> None:
        for _ in range(self.iterations):
            probs = self._softmax()
            conn = self._connection_cost(probs)
            size = self._size_match_cost(probs)
            comp = self._complexity_match_cost(probs)
            ent = self._entropy_cost(probs)

            loss = (
                self.connection_weight * conn
                + self.size_match_weight * size
                + self.complexity_match_weight * comp
                + self.entropy_weight * ent
            )
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()

    def assign(self) -> List[int]:
        probs = self._softmax().detach()
        assignment = probs.argmax(dim=1).tolist()
        if self.move_models:
            for idx, device_idx in enumerate(assignment):
                device_str = self.device_list[device_idx]
                if device_str == "cpu":
                    self.models[idx] = self.models[idx].to(torch.device("cpu"))
                else:
                    self.models[idx] = self.models[idx].to(torch.device(device_str))
        # Final capacity check
        probs = self._softmax().detach()
        assigned_size = probs.t() @ self.model_sizes
        if (assigned_size > self.device_mem_cap + 1e-6).any():
            raise RuntimeError("Model assignment exceeds device memory capacities.")
        return assignment
