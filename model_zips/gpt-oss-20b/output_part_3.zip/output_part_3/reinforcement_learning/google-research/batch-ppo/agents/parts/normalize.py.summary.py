import torch
from torch import Tensor
from typing import Optional, Tuple, Dict, Union


class StreamingNormalizer:
    def __init__(
        self,
        template: Tensor,
        center: bool = True,
        scale: bool = True,
        clip: Optional[float] = None,
    ) -> None:
        """
        Args:
            template: A tensor used to infer shape and dtype of statistics.
            center: Whether to subtract the running mean.
            scale: Whether to divide by the running standard deviation.
            clip: If set, values will be clipped to [-clip, clip].
        """
        self.center = center
        self.scale = scale
        self.clip = clip

        self.count: int = 0
        self.mean: Tensor = torch.zeros_like(template)
        self.var_sum: Tensor = torch.zeros_like(template)

    def _ensure_batch(self, x: Tensor) -> Tuple[Tensor, bool]:
        """Ensure a batch dimension and return whether it was added."""
        added = False
        if x.ndim == self.mean.ndim:
            x = x.unsqueeze(0)
            added = True
        return x, added

    def _remove_batch(self, x: Tensor, added: bool) -> Tensor:
        """Remove batch dimension if it was added."""
        if added:
            return x.squeeze(0)
        return x

    def transform(self, x: Tensor) -> Tensor:
        """Normalize the input tensor using the current statistics."""
        x, added = self._ensure_batch(x)

        if self.center:
            x = x - self.mean

        if self.scale and self.count > 1:
            std = torch.sqrt(self.var_sum / (self.count - 1) + 1e-4)
            x = x / (std + 1e-8)
        else:
            x = x / 1.0

        if self.clip is not None:
            x = torch.clamp(x, min=-self.clip, max=self.clip)

        return self._remove_batch(x)

    def update(self, x: Tensor) -> None:
        """Update running mean and variance with a new batch of data."""
        x, added = self._ensure_batch(x)

        batch_size = x.shape[0]
        self.count += batch_size

        if self.count <= 1:
            # First sample: set mean directly
            self.mean.copy_(x.squeeze(0))
            self.var_sum.zero_()
            return

        # Compute new mean
        diff = x - self.mean
        sum_diff = diff.sum(dim=0)
        new_mean = self.mean + sum_diff / self.count

        # Update variance sum
        diff_new = x - new_mean
        self.var_sum += (diff * diff_new).sum(dim=0)

        self.mean.copy_(new_mean)

    def reset(self, template: Tensor) -> None:
        """Reset all statistics."""
        self.count = 0
        self.mean = torch.zeros_like(template)
        self.var_sum = torch.zeros_like(template)

    def summary(self) -> Dict[str, Union[Tensor, Dict[str, Tensor]]]:
        """Return summaries of mean and standard deviation."""
        summaries: Dict[str, Union[Tensor, Dict[str, Tensor]]] = {}

        if self.count > 0:
            if self.mean.ndim == 0:
                summaries["mean"] = self.mean.clone()
            else:
                summaries["mean"] = {
                    "hist": self.mean.clone()
                }

        if self.count > 1:
            std = torch.sqrt(self.var_sum / (self.count - 1) + 1e-4)
            if std.ndim == 0:
                summaries["std"] = std.clone()
            else:
                summaries["std"] = {"hist": std.clone()}

        return summaries
```