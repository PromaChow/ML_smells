import os
import time
import random
import numpy as np
import cv2
import threading
import queue
import tensorflow as tf
from dataclasses import dataclass

# -------------------------------------------------------------
# Environment and configuration
# -------------------------------------------------------------
os.environ['DISPLAY'] = ':0'

@dataclass
class Config:
    weak_augmentation: str = 'flip_and_crop'
    strong_augmentation: str = 'randaugment'
    batch_size: int = 64
    unlabeled_ratio: int = 4
    number_of_loading_dataset: int = 10000
    number_of_loader_cpu: int = 2
    number_of_decoder_cpu: int = 2
    number_of_batch_cpu: int = 1
    number_of_prefetch_queue: int = 5

def get_config() -> Config:
    return Config()

flags = get_config()

# -------------------------------------------------------------
# Dataset loading (mocked)
# -------------------------------------------------------------
def get_dataset_cifar10(number_of_labels: int):
    # Create dummy data for demonstration
    labeled_data = np.random.randint(0, 256, (flags.number_of_loading_dataset, 32, 32, 3), dtype=np.uint8)
    labeled_labels = np.eye(10)[np.random.randint(0, 10, flags.number_of_loading_dataset)]
    unlabeled_data = np.random.randint(0, 256, (flags.number_of_loading_dataset * flags.unlabeled_ratio, 32, 32, 3), dtype=np.uint8)
    unlabeled_labels = None  # Unlabeled
    valid_data = np.random.randint(0, 256, (1000, 32, 32, 3), dtype=np.uint8)
    valid_labels = np.eye(10)[np.random.randint(0, 10, 1000)]
    test_data = np.random.randint(0, 256, (1000, 32, 32, 3), dtype=np.uint8)
    test_labels = np.eye(10)[np.random.randint(0, 10, 1000)]
    return labeled_data, labeled_labels, unlabeled_data, unlabeled_labels, valid_data, valid_labels, test_data, test_labels

number_of_labels = 250  # Unused in this mock
labeled_dataset, labeled_labels, unlabeled_dataset, unlabeled_labels, valid_dataset, valid_labels, test_dataset, test_labels = get_dataset_cifar10(number_of_labels)

# -------------------------------------------------------------
# Augmentation functions
# -------------------------------------------------------------
class Flip_and_Crop:
    def __init__(self, crop_size=(32, 32)):
        self.crop_size = crop_size

    def __call__(self, img):
        # Random horizontal flip
        if random.random() < 0.5:
            img = cv2.flip(img, 1)
        # Random crop (here just center crop for simplicity)
        return img

class RandAugmentation:
    def __call__(self, img):
        # Random rotation between -15 and 15 degrees
        angle = random.uniform(-15, 15)
        h, w = img.shape[:2]
        M = cv2.getRotationMatrix2D((w / 2, h / 2), angle, 1)
        return cv2.warpAffine(img, M, (w, h))

# -------------------------------------------------------------
# Weak and strong augmentation functions
# -------------------------------------------------------------
weakly_augment_func = None
strongly_augment_func = None

if flags.weak_augmentation == 'flip_and_crop':
    weakly_augment_func = Flip_and_Crop((32, 32))

if flags.strong_augmentation == 'randaugment':
    weak_aug = Flip_and_Crop((32, 32))
    strong_aug = RandAugmentation()
    def strong_aug_wrapper(img):
        return strong_aug(weak_aug(img))
    strongly_augment_func = strong_aug_wrapper

# -------------------------------------------------------------
# Loader, Decoder, BatchLoader
# -------------------------------------------------------------
class Loader:
    def __init__(self, data, labels, shuffle=True):
        self.data = data
        self.labels = labels
        self.shuffle = shuffle
        self.idx = 0
        if self.shuffle:
            self.indices = np.random.permutation(len(data))
        else:
            self.indices = np.arange(len(data))

    def __iter__(self):
        self.idx = 0
        if self.shuffle:
            self.indices = np.random.permutation(len(self.data))
        return self

    def __next__(self):
        if self.idx >= len(self.data):
            raise StopIteration
        i = self.indices[self.idx]
        item = (self.data[i], self.labels[i]) if self.labels is not None else (self.data[i], None)
        self.idx += 1
        return item

class Decoder:
    def __init__(self, augment_func=None, strong_func=None):
        self.augment_func = augment_func
        self.strong_func = strong_func

    def decode(self, batch):
        images, labels = zip(*batch)
        images = [self.augment_func(img) if self.augment_func else img for img in images]
        if self.strong_func:
            images = [self.strong_func(img) for img in images]
        return np.stack(images, axis=0), np.stack(labels, axis=0) if labels[0] is not None else (np.stack(images, axis=0), None)

class BatchLoader:
    def __init__(self, batch_size, batch_length=1):
        self.batch_size = batch_size
        self.batch_length = batch_length
        self.buffer = []

    def add(self, item):
        self.buffer.append(item)
        if len(self.buffer) >= self.batch_size:
            batch = self.buffer[:self.batch_size]
            self.buffer = self.buffer[self.batch_size:]
            return batch
        return None

# -------------------------------------------------------------
# Prefetching pipeline
# -------------------------------------------------------------
class Prefetch_using_queue:
    def __init__(self, loader, decoder, batch_loader, cpu_cores, queue_size):
        self.loader = loader
        self.decoder = decoder
        self.batch_loader = batch_loader
        self.cpu_cores = cpu_cores
        self.queue = queue.Queue(maxsize=queue_size)
        self.thread = threading.Thread(target=self._run, daemon=True)

    def start(self):
        self.thread.start()

    def _run(self):
        batch = []
        for item in self.loader:
            batch.append(item)
            if len(batch) >= self.batch_loader.batch_size:
                decoded, _ = self.decoder.decode(batch)
                self.queue.put(decoded)
                batch = []

    def get(self):
        return self.queue.get()

# -------------------------------------------------------------
# Labeled pipeline
# -------------------------------------------------------------
labeled_loader = Loader(labeled_dataset, labeled_labels, shuffle=True)
labeled_decoder = Decoder(augment_func=weakly_augment_func)
labeled_batch_loader = BatchLoader(flags.batch_size, batch_length=2)
labeled_prefetch = Prefetch_using_queue(
    labeled_loader,
    labeled_decoder,
    labeled_batch_loader,
    flags.number_of_loader_cpu,
    flags.number_of_prefetch_queue
)
labeled_prefetch.start()

# -------------------------------------------------------------
# Unlabeled pipeline
# -------------------------------------------------------------
unlabeled_loader = Loader(unlabeled_dataset, unlabeled_labels, shuffle=True)
unlabeled_decoder = Decoder(augment_func=weakly_augment_func, strong_func=strongly_augment_func)
unlabeled_batch_loader = BatchLoader(flags.batch_size * flags.unlabeled_ratio, batch_length=1)
unlabeled_prefetch = Prefetch_using_queue(
    unlabeled_loader,
    unlabeled_decoder,
    unlabeled_batch_loader,
    flags.number_of_loader_cpu,
    flags.number_of_prefetch_queue
)
unlabeled_prefetch.start()

# -------------------------------------------------------------
# TensorFlow placeholders
# -------------------------------------------------------------
tf.compat.v1.disable_eager_execution()
x_image_var = tf.compat.v1.placeholder(tf.uint8, shape=[flags.batch_size, 32, 32, 3], name='x_image')
x_label_var = tf.compat.v1.placeholder(tf.float32, shape=[flags.batch_size, 10], name='x_label')
u_image_var = tf.compat.v1.placeholder(tf.uint8, shape=[flags.batch_size * flags.unlabeled_ratio, 2, 32, 32, 3], name='u_image')

# -------------------------------------------------------------
# Generator combining pipelines
# -------------------------------------------------------------
def data_generator():
    while True:
        # Get labeled batch
        labeled_images, labeled_labels = labeled_prefetch.get()
        # Get unlabeled batch
        unlabeled_images, _ = unlabeled_prefetch.get()
        # Stack weak and strong augmentations
        # For simplicity, assume unlabeled_images is already stacked [weak, strong]
        yield {
            'x_image': labeled_images,
            'x_label': labeled_labels,
            'u_image': unlabeled_images
        }

# -------------------------------------------------------------
# Session and training loop
# -------------------------------------------------------------
sess = tf.compat.v1.Session()
coord = tf.train.Coordinator()

# Dummy training operation just to fetch data
train_op = tf.group(
    tf.identity(x_image_var),
    tf.identity(x_label_var),
    tf.identity(u_image_var)
)

generator = data_generator()

try:
    while True:
        start_time = time.time()
        data = next(generator)
        feed_dict = {
            x_image_var: data['x_image'],
            x_label_var: data['x_label'],
            u_image_var: data['u_image']
        }
        _, _, _ = sess.run(train_op, feed_dict=feed_dict)
        batch_time = time.time() - start_time
        print(f'Batch processed in {batch_time:.3f}s')

        # Display images for debugging
        cv2.imshow('Labeled Image', data['x_image'][0])
        cv2.imshow('Weak Unlabeled', data['u_image'][0,0])
        cv2.imshow('Strong Unlabeled', data['u_image'][0,1])
        cv2.waitKey(1)

except KeyboardInterrupt:
    print('Interrupted by user')
finally:
    coord.request_stop()
    sess.close()
    cv2.destroyAllWindows()
