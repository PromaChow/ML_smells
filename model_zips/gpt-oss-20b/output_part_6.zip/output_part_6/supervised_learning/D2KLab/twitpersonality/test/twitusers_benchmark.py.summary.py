import numpy as np
from sklearn.metrics import mean_squared_error
from pathlib import Path
import embeddings
import sys
import os

# File paths
questionnaires_file = Path("questionnaires.csv")
predictions_file = Path("personality_predictions1.csv")
output_file = Path("twitusers_predictions_benchmark.csv")

# Load true values
O, C, E, A, N = [], [], [], [], []

with questionnaires_file.open("r", encoding="utf-8") as f:
    for line in f:
        parts = line.strip().split(";")
        if len(parts) < 10:
            continue
        O.append(float(parts[-10].replace(",", ".")))
        C.append(float(parts[-9].replace(",", ".")))
        E.append(float(parts[-8].replace(",", ".")))
        A.append(float(parts[-7].replace(",", ".")))
        N.append(float(parts[-6].replace(",", ".")))

# Load predicted values
O1, C1, E1, A1, N1 = [], [], [], [], []

with predictions_file.open("r", encoding="utf-8") as f:
    for line in f:
        parts = line.strip().split(",")
        if len(parts) < 6:
            continue
        O1.append(float(parts[1].replace(",", ".")))
        C1.append(float(parts[2].replace(",", ".")))
        E1.append(float(parts[3].replace(",", ".")))
        A1.append(float(parts[4].replace(",", ".")))
        N1.append(float(parts[5].replace(",", ".")))

# Compute MSE for each trait
mse_O = mean_squared_error(O, O1)
mse_C = mean_squared_error(C, C1)
mse_E = mean_squared_error(E, E1)
mse_A = mean_squared_error(A, A1)
mse_N = mean_squared_error(N, N1)

# Write results
with output_file.open("w", encoding="utf-8") as f:
    f.write(f"mse,O,1,{mse_O}\n")
    f.write(f"mse,C,1,{mse_C}\n")
    f.write(f"mse,E,1,{mse_E}\n")
    f.write(f"mse,A,1,{mse_A}\n")
    f.write(f"mse,N,1,{mse_N}\n")