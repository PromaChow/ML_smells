import numpy as np

def one_step_lookahead(environment, state, V, discount_factor):
    """
    Computes the expected value of each action in the given state using the current value function V.
    """
    action_values = np.zeros(environment.nA)
    for action in range(environment.nA):
        for prob, next_state, reward, _ in environment.P[state][action]:
            action_values[action] += prob * (reward + discount_factor * V[next_state])
    return action_values

def policy_evaluation(environment, policy, discount_factor=0.99, theta=1e-5, max_iterations=1000):
    """
    Evaluates the value function V for a given policy using the Bellman Expectation Equation.
    """
    V = np.zeros(environment.nS)
    for _ in range(max_iterations):
        delta = 0
        new_V = np.copy(V)
        for state in range(environment.nS):
            v = 0
            for action in range(environment.nA):
                action_prob = policy[state, action]
                if action_prob == 0:
                    continue
                for prob, next_state, reward, _ in environment.P[state][action]:
                    v += action_prob * prob * (reward + discount_factor * V[next_state])
            delta = max(delta, abs(v - V[state]))
            new_V[state] = v
        V = new_V
        if delta < theta:
            break
    return V

def policy_iteration(environment, discount_factor=0.99, theta=1e-5, max_iterations=1000):
    """
    Finds the optimal policy and value function using policy iteration.
    """
    policy = np.ones((environment.nS, environment.nA)) / environment.nA
    for _ in range(max_iterations):
        V = policy_evaluation(environment, policy, discount_factor, theta, max_iterations)
        stable_policy = True
        for state in range(environment.nS):
            old_action = np.argmax(policy[state])
            action_values = one_step_lookahead(environment, state, V, discount_factor)
            best_action = np.argmax(action_values)
            if old_action != best_action:
                stable_policy = False
            policy[state] = np.eye(environment.nA)[best_action]
        if stable_policy:
            break
    return policy, V

def value_iteration(environment, discount_factor=0.99, theta=1e-5, max_iterations=1000):
    """
    Computes the optimal policy and value function using value iteration.
    """
    V = np.zeros(environment.nS)
    for _ in range(max_iterations):
        delta = 0
        new_V = np.copy(V)
        for state in range(environment.nS):
            action_values = one_step_lookahead(environment, state, V, discount_factor)
            best_value = np.max(action_values)
            delta = max(delta, abs(best_value - V[state]))
            new_V[state] = best_value
        V = new_V
        if delta < theta:
            break
    # Construct the optimal policy
    policy = np.zeros((environment.nS, environment.nA))
    for state in range(environment.nS):
        action_values = one_step_lookahead(environment, state, V, discount_factor)
        best_action = np.argmax(action_values)
        policy[state, best_action] = 1.0
    return policy, V
