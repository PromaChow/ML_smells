import os
import subprocess
from pathlib import Path
import urllib.request
import pandas as pd
import torch


def download_data(url: str, dest: Path) -> Path:
    dest.parent.mkdir(parents=True, exist_ok=True)
    urllib.request.urlretrieve(url, dest)
    return dest


def uncompress(z_fpath: Path) -> Path:
    subprocess.run(["uncompress", "-f", str(z_fpath)], check=True)
    return z_fpath.with_suffix("")


def fetch_data_without_header(file_path: Path) -> pd.DataFrame:
    return pd.read_csv(file_path, header=None, delim_whitespace=True)


class ShuttleBandit:
    def __init__(
        self,
        path: str = "./data/Statlog/",
        download: bool = False,
        force_download: bool = False,
        url: str = "http://archive.ics.uci.edu/ml/machine-learning-databases/statlog/shuttle/trn.Z",
        device: str = "cpu",
    ):
        self.path = Path(path)
        self.download = download
        self.force_download = force_download
        self.url = url
        self.device = device

        self.trn_fpath = self.path / "shuttle.trn"
        self.z_fpath = self.path / "shuttle.trn.Z"

        if self.download:
            if self.force_download or not self.trn_fpath.exists():
                download_data(self.url, self.z_fpath)
                uncompress(self.z_fpath)
        if self.trn_fpath.exists():
            self.df = pd.read_csv(self.trn_fpath, header=None, delim_whitespace=True)
        else:
            self.df = fetch_data_without_header(self.trn_fpath)

        self.num_actions = self.df.iloc[:, -1].nunique()
        self.context_dim = self.df.shape[1] - 1
        self.length = len(self.df)

        self._current_row = None
        self._shuffle_and_reset()

    def _shuffle_and_reset(self):
        self.df = self.df.sample(frac=1, random_state=42).reset_index(drop=True)
        self._current_row = 0

    def reset(self) -> torch.Tensor:
        self._shuffle_and_reset()
        return self._get_context()

    def step(self, action: int) -> tuple[torch.Tensor, int, bool]:
        reward = self._compute_reward(action)
        done = self._current_row >= self.length - 1
        self._current_row += 1
        context = self._get_context() if not done else torch.zeros(self.context_dim, device=self.device)
        return context, reward, done

    def _compute_reward(self, action: int) -> int:
        true_label = self.df.iloc[self._current_row, -1]
        return int(action == true_label)

    def _get_context(self) -> torch.Tensor:
        if self._current_row >= self.length:
            return torch.zeros(self.context_dim, device=self.device)
        row = self.df.iloc[self._current_row, : self.context_dim]
        return torch.tensor(row.values, dtype=torch.float32, device=self.device)