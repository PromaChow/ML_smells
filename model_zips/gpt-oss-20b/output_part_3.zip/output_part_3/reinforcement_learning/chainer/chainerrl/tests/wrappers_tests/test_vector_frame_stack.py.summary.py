import unittest
import numpy as np
import gymnasium as gym
from collections import deque
from stable_baselines3.common.vec_env import DummyVecEnv, SubprocVecEnv, VecFrameStack
from typing import List, Callable, Any, Tuple


class MockAtariEnv(gym.Env):
    metadata = {"render_modes": ["rgb_array"]}

    def __init__(self):
        super().__init__()
        self.observation_space = gym.spaces.Box(
            low=0, high=255, shape=(1, 84, 84), dtype=np.uint8
        )
        self.action_space = gym.spaces.Discrete(4)
        self.step_count = 0
        self.max_steps = 10

    def reset(self, seed=None, options=None):
        self.step_count = 0
        return np.random.randint(0, 256, size=self.observation_space.shape, dtype=np.uint8)

    def step(self, action):
        self.step_count += 1
        obs = np.random.randint(0, 256, size=self.observation_space.shape, dtype=np.uint8)
        reward = 0.0
        done = self.step_count >= self.max_steps
        info = {}
        return obs, reward, done, info


class SerialVectorEnv:
    def __init__(self, env_fns: List[Callable[[], gym.Env]]):
        self.envs = [fn() for fn in env_fns]
        self.env = self
        self.unwrapped = self
        self.action_space = self.envs[0].action_space
        self.observation_space = self.envs[0].observation_space

    def reset(self, seed=None, options=None):
        return [env.reset(seed, options) for env in self.envs]

    def step(self, actions: List[Any]) -> Tuple[List[np.ndarray], List[float], List[bool], List[dict]]:
        obs, rewards, dones, infos = zip(*(env.step(a) for env, a in zip(self.envs, actions)))
        return list(obs), list(rewards), list(dones), list(infos)


class VectorEnvWrapper:
    def __init__(self, env: SerialVectorEnv):
        self.env = env
        self.unwrapped = env
        self.action_space = env.action_space
        self.observation_space = env.observation_space

    def reset(self, seed=None, options=None):
        return self.env.reset(seed, options)

    def step(self, actions: List[Any]):
        return self.env.step(actions)


class LazyFrames:
    def __init__(self, frames: List[np.ndarray]):
        self.frames = frames

    def __array__(self, dtype=None):
        return np.concatenate([np.array(f, dtype=dtype) for f in self.frames], axis=0)

    def __len__(self):
        return len(self.frames)

    def __getitem__(self, idx):
        return self.frames[idx]


class FrameStack:
    def __init__(self, env: gym.Env, k: int, channel_order: str = "chw"):
        self.env = env
        self.k = k
        self.channel_order = channel_order
        self.frames = [deque(maxlen=k) for _ in range(1)]  # single env
        shape = self.env.observation_space.shape
        if channel_order == "chw":
            new_shape = (k, *shape[1:])
        else:
            new_shape = (*shape[:-1], k)
        self.observation_space = gym.spaces.Box(
            low=0, high=255, shape=new_shape, dtype=np.uint8
        )
        self.action_space = self.env.action_space

    def reset(self, seed=None, options=None):
        obs = self.env.reset(seed, options)
        for _ in range(self.k):
            self.frames[0].append(obs)
        return [LazyFrames(list(self.frames[0]))]

    def step(self, actions: List[Any]):
        obs, rewards, dones, infos = self.env.step(actions[0])
        self.frames[0].append(obs)
        return [LazyFrames(list(self.frames[0]))], rewards, dones, infos


class VectorFrameStack:
    def __init__(self, env: SerialVectorEnv, k: int, stack_axis: int = 0):
        self.env = env
        self.k = k
        self.stack_axis = stack_axis
        self.frames = [deque(maxlen=k) for _ in range(len(self.env.reset()))]
        shape = self.env.observation_space.shape
        new_shape = list(shape)
        new_shape[stack_axis] = k * shape[stack_axis]
        self.observation_space = gym.spaces.Box(
            low=0, high=255, shape=tuple(new_shape), dtype=np.uint8
        )
        self.action_space = self.env.action_space

    def reset(self, seed=None, options=None):
        obs = self.env.reset(seed, options)
        for i, o in enumerate(obs):
            for _ in range(self.k):
                self.frames[i].append(o)
        return [LazyFrames(list(f)) for f in self.frames]

    def step(self, actions: List[Any]):
        obs, rewards, dones, infos = self.env.step(actions)
        for i, o in enumerate(obs):
            self.frames[i].append(o)
        return [LazyFrames(list(f)) for f in self.frames], rewards, dones, infos


class TestVectorEnvWrappers(unittest.TestCase):
    def test_vector_env_wrapper(self):
        env_fns = [lambda: MockAtariEnv() for _ in range(3)]
        serial_env = SerialVectorEnv(env_fns)
        wrapped_env = VectorEnvWrapper(serial_env)

        self.assertIs(wrapped_env.env, serial_env)
        self.assertIs(wrapped_env.unwrapped, serial_env)
        self.assertIs(wrapped_env.action_space, serial_env.action_space)
        self.assertIs(wrapped_env.observation_space, serial_env.observation_space)

    def test_vector_frame_stack(self):
        param_sets = [(3, 4), (2, 2)]
        for num_envs, k in param_sets:
            env_fns = [lambda: MockAtariEnv() for _ in range(num_envs)]

            # fs_env: each env wrapped in FrameStack
            fs_env_fns = [lambda: FrameStack(MockAtariEnv(), k, channel_order="chw") for _ in range(num_envs)]
            fs_env = SubprocVecEnv(fs_env_fns)
            fs_env = VecFrameStack(fs_env, n_stack=k, channels_first=True)

            # vfs_env: vector env wrapped in VectorFrameStack
            vfs_env = SubprocVecEnv(env_fns)
            vfs_env = VectorFrameStack(vfs_env, k, stack_axis=0)

            # Check spaces
            self.assertEqual(fs_env.action_space, vfs_env.action_space)
            self.assertEqual(fs_env.observation_space.shape, vfs_env.observation_space.shape)

            # Initial reset
            fs_obs = fs_env.reset()
            vfs_obs = vfs_env.reset()
            for fo, vo in zip(fs_obs, vfs_obs):
                self.assertIsInstance(fo, LazyFrames)
                self.assertIsInstance(vo, LazyFrames)
                np.testing.assert_array_equal(np.array(fo), np.array(vo))

            # Step with zeros
            zero_actions = [0 for _ in range(num_envs)]
            fs_obs, fs_rewards, fs_dones, fs_infos = fs_env.step(zero_actions)
            vfs_obs, vfs_rewards, vfs_dones, vfs_infos = vfs_env.step(zero_actions)

            for fo, vo in zip(fs_obs, vfs_obs):
                self.assertIsInstance(fo, LazyFrames)
                self.assertIsInstance(vo, LazyFrames)
                np.testing.assert_array_equal(np.array(fo), np.array(vo))
            np.testing.assert_array_equal(fs_rewards, vfs_rewards)
            np.testing.assert_array_equal(fs_dones, vfs_dones)

            # Repeat steps
            steps = 9
            for _ in range(steps):
                fs_obs, fs_rewards, fs_dones, fs_infos = fs_env.step(zero_actions)
                vfs_obs, vfs_rewards, vfs_dones, vfs_infos = vfs_env.step(zero_actions)
                for fo, vo in zip(fs_obs, vfs_obs):
                    self.assertIsInstance(fo, LazyFrames)
                    self.assertIsInstance(vo, LazyFrames)
                    np.testing.assert_array_equal(np.array(fo), np.array(vo))
                np.testing.assert_array_equal(fs_rewards, vfs_rewards)
                np.testing.assert_array_equal(fs_dones, vfs_dones)


if __name__ == "__main__":
    unittest.main()
