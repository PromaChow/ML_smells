import sys
import numpy as np

try:
    from gymnasium.envs.toy_text.discrete import DiscreteEnv
except ImportError:
    from gym.envs.toy_text.discrete import DiscreteEnv

# Action definitions
UP, RIGHT, DOWN, LEFT = 0, 1, 2, 3
ACTION_VECTORS = {
    UP:    (-1,  0),
    RIGHT: ( 0,  1),
    DOWN:  ( 1,  0),
    LEFT:  ( 0, -1),
}

class WindyGridworldEnv(DiscreteEnv):
    metadata = {"render.modes": ["human", "ansi"]}

    def __init__(self):
        self.rows, self.cols = 7, 10
        self.nS = self.rows * self.cols
        self.nA = 4

        # Wind strengths per column
        self.winds = np.array([0, 0, 0, 1, 1, 1, 2, 2, 1, 0])

        # Transition probability dictionary
        P = {}
        for s in range(self.nS):
            P[s] = {}
            for a in range(self.nA):
                prob, ns, rew, done = self._calculate_transition_prob(s, a)
                P[s][a] = [(prob, ns, rew, done)]

        # Initial state distribution: start at (3,0)
        isd = np.zeros(self.nS, dtype=np.float32)
        start_state = self._coord_to_state(3, 0)
        isd[start_state] = 1.0

        super().__init__(self.nS, self.nA, P, isd)

    def _coord_to_state(self, row, col):
        return np.ravel_multi_index((row, col), (self.rows, self.cols))

    def _state_to_coord(self, state):
        return np.unravel_index(state, (self.rows, self.cols))

    def _limit_coordinates(self, row, col):
        row = max(0, min(self.rows - 1, row))
        col = max(0, min(self.cols - 1, col))
        return row, col

    def _calculate_transition_prob(self, s, a):
        row, col = self._state_to_coord(s)
        move_row, move_col = ACTION_VECTORS[a]
        wind = self.winds[col]

        new_row = row + move_row + wind
        new_col = col + move_col

        new_row, new_col = self._limit_coordinates(new_row, new_col)
        ns = self._coord_to_state(new_row, new_col)

        goal_row, goal_col = 3, 7
        done = (new_row == goal_row) and (new_col == goal_col)
        return 1.0, ns, -1.0, done

    def render(self, mode="human"):
        if mode not in self.metadata["render.modes"]:
            raise ValueError(f"Unsupported render mode: {mode}")

        lines = []
        for r in range(self.rows):
            line = ""
            for c in range(self.cols):
                state = self._coord_to_state(r, c)
                if state == self.s:
                    cell = " x "
                elif r == 3 and c == 7:
                    cell = " T "
                else:
                    cell = " o "
                line += cell
            lines.append(line)

        output = "\n".join(lines) + "\n"

        if mode == "human":
            sys.stdout.write(output)
        else:  # ansi
            return output

    def close(self):
        pass

if __name__ == "__main__":
    env = WindyGridworldEnv()
    env.render()
    print("Done.")