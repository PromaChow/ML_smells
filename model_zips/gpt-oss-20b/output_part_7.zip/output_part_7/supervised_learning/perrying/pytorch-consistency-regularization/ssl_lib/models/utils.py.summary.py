import math
import torch
import torch.nn as nn
import torch.nn.functional as F

# Custom components
def conv3x3(in_channels, out_channels, stride=1, bias=False):
    return nn.Conv2d(
        in_channels, out_channels, kernel_size=3, stride=stride, padding=1, bias=bias
    )

def leaky_relu():
    return nn.LeakyReLU(0.1, inplace=True)

class BatchNorm2d(nn.BatchNorm2d):
    def __init__(self, num_features, eps=1e-5, momentum=0.1, affine=True, track_running_stats=True):
        super().__init__(num_features, eps, momentum, affine, track_running_stats)
        self.update_batch_stats = True

    def forward(self, input):
        if self.update_batch_stats or self.training:
            return super().forward(input)
        else:
            return F.batch_norm(
                input,
                self.running_mean,
                self.running_var,
                self.weight,
                self.bias,
                training=False,
                momentum=0,
                eps=self.eps,
            )

# Base model class
class BaseModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.feature_extractor = None
        self.classifier = None

    def forward(self, x):
        features = self.feature_extractor(x)
        pooled = features.mean(dim=[2, 3])
        logits = self.classifier(pooled)
        return logits

    def logits_with_feature(self, x):
        features = self.feature_extractor(x)
        pooled = features.mean(dim=[2, 3])
        logits = self.classifier(pooled)
        return logits, features

    def update_batch_stats(self):
        for module in self.modules():
            if isinstance(module, BatchNorm2d):
                module.update_batch_stats = True

# Training utilities
def apply_weight_decay(model, decay_rate):
    for m in model.modules():
        if isinstance(m, (nn.Conv2d, nn.Linear)):
            m.weight.data.mul_(decay_rate)

def param_init(model):
    def init_weights(m):
        if isinstance(m, nn.Conv2d):
            std = math.sqrt(2.0 / (m.kernel_size[0] * m.kernel_size[1] * m.in_channels))
            nn.init.normal_(m.weight, 0, std)
            if m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.Linear):
            nn.init.xavier_uniform_(m.weight)
            if m.bias is not None:
                nn.init.constant_(m.bias, 0)
    model.apply(init_weights)

def __ema(a, b, factor):
    return a * (1.0 - factor) + b * factor

def __param_update(model, ema_model, factor):
    for p, p_ema in zip(model.parameters(), ema_model.parameters()):
        if p_ema.grad is not None:
            p_ema.grad.zero_()
        p_ema.copy_(__ema(p_ema.data, p.data, factor))

def __buffer_update(model, ema_model, factor):
    for buf, buf_ema in zip(model.buffers(), ema_model.buffers()):
        buf_ema.copy_(__ema(buf_ema.data, buf.data, factor))

def ema_update(
    model,
    ema_model,
    global_step=None,
    init_factor=0.9999,
    weight_decay_factor=None,
):
    if global_step is not None:
        factor = min(init_factor, 1.0 - 1.0 / (global_step + 1))
    else:
        factor = init_factor
    __param_update(model, ema_model, factor)
    __buffer_update(model, ema_model, factor)
    if weight_decay_factor is not None:
        apply_weight_decay(ema_model, weight_decay_factor)