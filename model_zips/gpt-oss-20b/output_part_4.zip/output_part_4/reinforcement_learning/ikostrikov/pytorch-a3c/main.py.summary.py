import argparse
import os
import math
import gym
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.multiprocessing as mp
import torch.optim as optim

def create_atari_env(env_name: str):
    env = gym.make(env_name)
    return env

class ActorCritic(nn.Module):
    def __init__(self, obs_space: gym.spaces.Space, action_space: gym.spaces.Space):
        super().__init__()
        if len(obs_space.shape) == 3:
            n_input_channels = obs_space.shape[2]
        else:
            n_input_channels = 1
        self.features = nn.Sequential(
            nn.Conv2d(n_input_channels, 16, kernel_size=8, stride=4),
            nn.ReLU(),
            nn.Conv2d(16, 32, kernel_size=4, stride=2),
            nn.ReLU(),
            nn.Flatten(),
            nn.Linear(32 * 9 * 9, 256),
            nn.ReLU(),
        )
        self.policy = nn.Linear(256, action_space.n)
        self.value = nn.Linear(256, 1)

    def forward(self, x: torch.Tensor):
        x = x / 255.0
        x = x.permute(0, 3, 1, 2)
        features = self.features(x)
        logits = self.policy(features)
        value = self.value(features)
        return logits, value

def compute_returns(rewards, gamma):
    returns = []
    R = 0
    for r in reversed(rewards):
        R = r + gamma * R
        returns.insert(0, R)
    return returns

def train(rank, args, model, counter, lock, optimizer):
    env = create_atari_env(args.env_name)
    torch.manual_seed(args.seed + rank)
    while True:
        state = env.reset()
        done = False
        episode_reward = 0
        log_probs = []
        values = []
        rewards = []
        while not done:
            state_tensor = torch.from_numpy(state).unsqueeze(0).float()
            logits, value = model(state_tensor)
            probs = F.softmax(logits, dim=1)
            m = torch.distributions.Categorical(probs)
            action = m.sample()
            log_prob = m.log_prob(action)
            next_state, reward, done, _ = env.step(action.item())
            episode_reward += reward
            log_probs.append(log_prob)
            values.append(value.squeeze(0))
            rewards.append(reward)
            state = next_state
            if done:
                with lock:
                    counter.value += 1
                    if counter.value >= args.max_steps:
                        env.close()
                        return
                returns = compute_returns(rewards, args.gamma)
                returns = torch.tensor(returns)
                log_probs = torch.stack(log_probs)
                values = torch.stack(values).squeeze()
                advantage = returns - values
                actor_loss = -(log_probs * advantage.detach()).mean()
                critic_loss = advantage.pow(2).mean()
                entropy = -(probs * probs.log()).sum(1).mean()
                loss = actor_loss + 0.5 * critic_loss - args.entropy_coef * entropy
                optimizer.zero_grad()
                loss.backward()
                for p in model.parameters():
                    p.grad.data.clamp_(-1, 1)
                optimizer.step()
                log_probs = []
                values = []
                rewards = []
    env.close()

def test(args, model, counter):
    env = create_atari_env(args.env_name)
    torch.manual_seed(args.seed + 999)
    while True:
        with counter.get_lock():
            if counter.value >= args.max_steps:
                break
        state = env.reset()
        done = False
        total_reward = 0
        while not done:
            state_tensor = torch.from_numpy(state).unsqueeze(0).float()
            with torch.no_grad():
                logits, _ = model(state_tensor)
                probs = F.softmax(logits, dim=1)
                action = torch.argmax(probs, dim=1).item()
            next_state, reward, done, _ = env.step(action)
            total_reward += reward
            state = next_state
        print(f"Test Episode Reward: {total_reward}")
    env.close()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--lr', type=float, default=1e-4)
    parser.add_argument('--gamma', type=float, default=0.99)
    parser.add_argument('--entropy-coef', type=float, default=0.01)
    parser.add_argument('--env-name', type=str, default='PongDeterministic-v4')
    parser.add_argument('--num-processes', type=int, default=4)
    parser.add_argument('--max-steps', type=int, default=100000)
    parser.add_argument('--seed', type=int, default=123)
    parser.add_argument('--no-shared', action='store_true')
    args = parser.parse_args()

    os.environ['OMP_NUM_THREADS'] = '1'
    os.environ['CUDA_VISIBLE_DEVICES'] = ''
    torch.manual_seed(args.seed)
    mp.set_start_method('spawn', force=True)

    env = create_atari_env(args.env_name)
    model = ActorCritic(env.observation_space, env.action_space)
    model.share_memory()

    optimizer = None
    if not args.no_shared:
        optimizer = optim.Adam(model.parameters(), lr=args.lr)
        optimizer.share_memory()

    counter = mp.Value('i', 0)
    lock = mp.Lock()

    processes = []

    test_process = mp.Process(target=test, args=(args, model, counter))
    test_process.start()
    processes.append(test_process)

    for rank in range(args.num_processes):
        p = mp.Process(target=train, args=(rank, args, model, counter, lock, optimizer))
        p.start()
        processes.append(p)

    for p in processes:
        p.join()

if __name__ == '__main__':
    main()