import tensorflow as tf
import numpy as np
from typing import List, Tuple

# Assume external modules exist
import Features
import Normalization


class TFPolicy:
    """
    Policy based on a TensorFlow model that suggests moves for a board game.
    """

    def __init__(self, model, prob_threshold: float = 0.95, softmax_temp: float = 1.0):
        """
        Initializes the policy.

        Parameters
        ----------
        model
            Pre-trained TensorFlow model with attributes:
                - board_size: int
                - n_feat: int
                - inference(input_placeholder) -> logits tensor
        prob_threshold : float
            Threshold for cumulative probability when selecting moves.
        softmax_temp : float
            Temperature parameter for softmax.
        """
        self.model = model
        self.prob_threshold = prob_threshold
        self.softmax_temp = softmax_temp

        self.graph = tf.Graph()
        with self.graph.as_default():
            with tf.device("/CPU:0"):
                self.input_placeholder = tf.placeholder(
                    tf.float32,
                    shape=[None, self.model.board_size, self.model.board_size, self.model.n_feat],
                    name="input",
                )
                logits = self.model.inference(self.input_placeholder)
                self.logits_tensor = logits

        self.sess = tf.Session(graph=self.graph)
        self.sess.run(tf.global_variables_initializer())

    def __del__(self):
        try:
            self.sess.close()
        except Exception:
            pass

    def get_moves(self, board) -> List[Tuple[int, int]]:
        """
        Generates a list of suggested moves for the given board.

        Parameters
        ----------
        board
            Board object providing:
                - size: int
                - play_is_legal(x, y) -> bool
        Returns
        -------
        List[Tuple[int, int]]
            List of (x, y) coordinates for selected moves.
        """
        # Feature plane generation
        feature_planes = Features.make_feature_planes_stones_4liberties_4history_ko_4captures(board)

        # Normalization
        normalized = Normalization.apply_featurewise_normalization_C(feature_planes)

        # Add batch dimension
        input_batch = np.expand_dims(normalized.astype(np.float32), axis=0)

        # Model inference
        logits = self.sess.run(self.logits_tensor, feed_dict={self.input_placeholder: input_batch})[0]
        board_size = board.size

        # Illegal move filtering
        for idx in range(board_size * board_size):
            x, y = divmod(idx, board_size)
            if not board.play_is_legal(x, y):
                logits[idx] = -1e99

        # Softmax with temperature
        logits = logits / self.softmax_temp
        max_logit = np.max(logits)
        exp_vals = np.exp(logits - max_logit)
        probs = exp_vals / np.sum(exp_vals)

        # Renormalization
        total = probs.sum()
        if total <= 0:
            return []

        probs = probs / total

        # Greedy selection up to probability threshold
        selected_moves: List[Tuple[int, int]] = []
        cumulative = 0.0
        while cumulative < self.prob_threshold and np.any(probs > 0):
            idx = int(np.argmax(probs))
            prob = probs[idx]
            cumulative += prob
            x, y = divmod(idx, board_size)
            selected_moves.append((x, y))
            probs[idx] = 0.0  # remove from consideration

        return selected_moves

# Example usage (requires actual model and board implementations):
# model = YourPretrainedModel()
# policy = TFPolicy(model)
# moves = policy.get_moves(current_board)
# print(moves)