import pandas as pd
import numpy as np
from textblob import TextBlob

pd.options.mode.chained_assignment = None

df = pd.read_csv("twitter.csv")

df["New sentiment"] = np.random.rand(len(df))

sum_sentiment = 0.0
n = 0

for i, row in df.iterrows():
    text = row.iloc[2]
    polarity = TextBlob(text).sentiment.polarity
    df.loc[i, "New sentiment"] = polarity
    sum_sentiment += float(row["sentiment"])
    n += 1

df.to_csv("twitter.csv", index=False)

average = sum_sentiment / n if n else 0
print(average)