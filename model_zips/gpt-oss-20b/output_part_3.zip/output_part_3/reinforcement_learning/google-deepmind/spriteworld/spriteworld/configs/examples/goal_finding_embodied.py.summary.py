import random
import math
import colorsys
from PIL import Image, ImageDraw

# Basic sprite representation
class Sprite:
    def __init__(self, x, y, shape, scale, c0, c1, c2):
        self.x = x          # position in [0,1]
        self.y = y
        self.shape = shape  # 'square', 'triangle', 'circle'
        self.scale = scale  # size relative to canvas
        self.c0 = c0        # hue
        self.c1 = c1        # saturation
        self.c2 = c2        # value

# Utility random generators
def rand_cont(low, high):
    return random.uniform(low, high)

def rand_choice(seq):
    return random.choice(seq)

# Shared factors for sprites
def shared_factors():
    x = rand_cont(0.1, 0.9)
    y = rand_cont(0.1, 0.9)
    shape = rand_choice(['square', 'triangle', 'circle'])
    scale = 0.13
    c1 = rand_cont(0.3, 1.0)
    c2 = rand_cont(0.9, 1.0)
    return x, y, shape, scale, c1, c2

# Generate target or distractor sprites
def generate_sprites(is_target=True):
    hue_low, hue_high = (0.0, 0.4) if is_target else (0.5, 0.9)
    count = random.randint(1, 3)
    sprites = []
    for _ in range(count):
        x, y, shape, scale, c1, c2 = shared_factors()
        c0 = rand_cont(hue_low, hue_high)
        sprites.append(Sprite(x, y, shape, scale, c0, c1, c2))
    return sprites

# Generate all sprites for an episode
def init_sprites():
    target_sprites = generate_sprites(is_target=True)
    distractor_sprites = generate_sprites(is_target=False)
    all_sprites = target_sprites + distractor_sprites
    random.shuffle(all_sprites)

    # Agent body
    agent = Sprite(
        x=rand_cont(0.1, 0.9),
        y=rand_cont(0.1, 0.9),
        shape='circle',
        scale=0.07,
        c0=1.0,
        c1=0.0,
        c2=1.0
    )
    all_sprites.append(agent)
    return all_sprites

# Simple renderer using PIL
class PILRenderer:
    def __init__(self, width=64, height=64, aa_factor=5):
        self.width = width
        self.height = height
        self.aa_factor = aa_factor

    def _scale(self, val):
        return int(val * self.width)

    def _hsv_to_rgb(self, c0, c1, c2):
        r, g, b = colorsys.hsv_to_rgb(c0, c1, c2)
        return (int(r * 255), int(g * 255), int(b * 255))

    def render(self, sprites):
        img = Image.new('RGB', (self.width, self.height), 'black')
        draw = ImageDraw.Draw(img)
        for s in sprites:
            x = self._scale(s.x)
            y = self._scale(s.y)
            size = self._scale(s.scale)
            color = self._hsv_to_rgb(s.c0, s.c1, s.c2)
            if s.shape == 'circle':
                bbox = [x - size, y - size, x + size, y + size]
                draw.ellipse(bbox, fill=color)
            elif s.shape == 'square':
                bbox = [x - size, y - size, x + size, y + size]
                draw.rectangle(bbox, fill=color)
            elif s.shape == 'triangle':
                pts = [
                    (x, y - size),
                    (x - size, y + size),
                    (x + size, y + size)
                ]
                draw.polygon(pts, fill=color)
        return img

# Task logic
class FindGoalPosition:
    TERMINATE_DISTANCE = 0.075
    def __init__(self, target_hue_range=(0.0, 0.4)):
        self.target_hue_low, self.target_hue_high = target_hue_range

    def is_target(self, sprite):
        return self.target_hue_low <= sprite.c0 <= self.target_hue_high

    def should_terminate(self, sprites):
        goal_x, goal_y = 0.5, 0.5
        for s in sprites:
            if self.is_target(s):
                dist = math.hypot(s.x - goal_x, s.y - goal_y)
                if dist <= self.TERMINATE_DISTANCE:
                    return True
        return False

# Simple action space representation
class Embodied:
    def __init__(self, step_size=0.05):
        self.step_size = step_size

# Environment assembly
class GoalFindingEnv:
    def __init__(self):
        self.task = FindGoalPosition()
        self.action_space = Embodied(step_size=0.05)
        self.renderer = PILRenderer(width=64, height=64, aa_factor=5)
        self.max_episode_length = 50
        self.metadata = {'task_name': 'FindGoalPosition'}

    def reset(self):
        self.sprites = init_sprites()
        self.step_count = 0
        return self.renderer.render(self.sprites)

    def step(self, action):
        # Simplified action: move all sprites uniformly
        dx = dy = 0
        if action == 'up': dy = -self.action_space.step_size
        elif action == 'down': dy = self.action_space.step_size
        elif action == 'left': dx = -self.action_space.step_size
        elif action == 'right': dx = self.action_space.step_size
        for s in self.sprites:
            s.x = min(max(s.x + dx, 0.0), 1.0)
            s.y = min(max(s.y + dy, 0.0), 1.0)
        self.step_count += 1
        done = self.task.should_terminate(self.sprites) or self.step_count >= self.max_episode_length
        return self.renderer.render(self.sprites), done

# Example usage
if __name__ == "__main__":
    env = GoalFindingEnv()
    frame = env.reset()
    frame.show()
    actions = ['up', 'down', 'left', 'right']
    for _ in range(10):
        action = rand_choice(actions)
        frame, done = env.step(action)
        frame.show()
        if done:
            break
    print(env.metadata)