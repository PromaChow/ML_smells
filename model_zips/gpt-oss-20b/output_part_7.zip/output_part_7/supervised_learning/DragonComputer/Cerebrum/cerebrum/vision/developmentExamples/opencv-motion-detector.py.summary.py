import argparse
import datetime
import os
import pathlib
import subprocess
import sys

import cv2

STABILIZATION_DETECTION = 5


def main():
    parser = argparse.ArgumentParser(description="Motion detection recorder.")
    parser.add_argument(
        "--video",
        type=str,
        default=None,
        help="Path to video file. If omitted, webcam will be used.",
    )
    parser.add_argument(
        "--min_area",
        type=int,
        default=5000,
        help="Minimum contour area to be considered motion.",
    )
    args = parser.parse_args()

    memory_dir = pathlib.Path("memory")
    memory_dir.mkdir(parents=True, exist_ok=True)

    today_str = datetime.date.today().strftime("%Y%m%d")

    base_filenames = {
        "orig": f"{today_str}.avi",
        "thresh": f"{today_str}_thresh.avi",
        "delta": f"{today_str}_delta.avi",
        "delta_colored": f"{today_str}_delta_colored.avi",
    }

    temp_filenames = {
        key: f"{today_str}_TEMP{suffix}"
        for key, suffix in base_filenames.items()
    }

    files_to_use = {}
    for key, base in base_filenames.items():
        base_path = memory_dir / base
        temp_path = memory_dir / temp_filenames[key]
        if base_path.exists():
            files_to_use[key] = temp_path
        else:
            files_to_use[key] = base_path

    fourcc = cv2.VideoWriter_fourcc(*"XVID")
    fps = 25
    frame_size = (640, 360)

    writers = {
        key: cv2.VideoWriter(str(path), fourcc, fps, frame_size)
        for key, path in files_to_use.items()
    }

    if args.video:
        cap = cv2.VideoCapture(args.video)
    else:
        cap = cv2.VideoCapture(0)

    ret, frame = cap.read()
    if not ret:
        print("Failed to read from video source.")
        sys.exit(1)

    h, w = frame.shape[:2]
    if abs(w / h - 16 / 9) > 0.1:
        raise ValueError("Input frame does not have a 16:9 aspect ratio.")

    frame_resized = cv2.resize(frame, frame_size)
    reference = cv2.cvtColor(frame_resized, cv2.COLOR_BGR2GRAY)
    reference = cv2.bilateralFilter(reference, 9, 75, 75)

    delta_value_stack = []

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        frame_resized = cv2.resize(frame, frame_size)
        gray = cv2.cvtColor(frame_resized, cv2.COLOR_BGR2GRAY)
        gray = cv2.bilateralFilter(gray, 9, 75, 75)

        if reference is None:
            reference = gray
            continue

        frame_delta = cv2.absdiff(reference, gray)
        _, thresh = cv2.threshold(frame_delta, 25, 255, cv2.THRESH_BINARY)
        thresh = cv2.dilate(thresh, None, iterations=2)
        delta_colored = cv2.bitwise_and(frame_resized, frame_resized, mask=thresh)

        contours, _ = cv2.findContours(
            thresh.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )
        max_area = max((cv2.contourArea(c) for c in contours), default=0)
        on_delta_situation = 1 if max_area > args.min_area else 0

        if on_delta_situation:
            writers["orig"].write(frame_resized)
            writers["thresh"].write(cv2.cvtColor(thresh, cv2.COLOR_GRAY2BGR))
            writers["delta"].write(cv2.cvtColor(frame_delta, cv2.COLOR_GRAY2BGR))
            writers["delta_colored"].write(delta_colored)

            delta_value_stack.append(max_area)
            if len(delta_value_stack) > STABILIZATION_DETECTION:
                delta_value_stack.pop(0)

            if len(delta_value_stack) == STABILIZATION_DETECTION:
                mean_val = sum(delta_value_stack) / STABILIZATION_DETECTION
                if max(delta_value_stack) - min(delta_value_stack) <= args.min_area:
                    reference = None
                    delta_value_stack.clear()

        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        disp_frame = frame_resized.copy()
        cv2.putText(
            disp_frame,
            f"Delta: {max_area}",
            (10, 20),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (0, 255, 0),
            2,
        )
        cv2.putText(
            disp_frame,
            f"Min Area: {args.min_area}",
            (10, 40),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (0, 255, 0),
            2,
        )
        cv2.putText(
            disp_frame,
            f"Frame: {int(cap.get(cv2.CAP_PROP_POS_FRAMES))}",
            (10, 60),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (0, 255, 0),
            2,
        )
        cv2.putText(
            disp_frame,
            f"Stabilization: {'Yes' if reference is None else 'No'}",
            (10, 80),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (0, 255, 0),
            2,
        )
        cv2.putText(
            disp_frame,
            timestamp,
            (10, 100),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (0, 255, 0),
            2,
        )

        cv2.imshow("Original", disp_frame)
        cv2.imshow(
            "Threshold", cv2.cvtColor(thresh, cv2.COLOR_GRAY2BGR)
        )
        cv2.imshow(
            "Delta", cv2.cvtColor(frame_delta, cv2.COLOR_GRAY2BGR)
        )
        cv2.imshow("Delta Color", delta_colored)

        key = cv2.waitKey(1) & 0xFF
        if key == ord("q") or key == 27:
            break

    for writer in writers.values():
        writer.release()
    cap.release()

    temp_files = list(memory_dir.glob("*_TEMP*.avi"))
    if temp_files:
        for key, suffix in base_filenames.items():
            orig_path = memory_dir / suffix
            temp_path = memory_dir / temp_filenames[key]
            list_path = memory_dir / f"concat_{key}.txt"
            with open(list_path, "w") as f:
                f.write(f"file '{orig_path.resolve()}'\n")
                f.write(f"file '{temp_path.resolve()}'\n")
            output_path = orig_path
            subprocess.run(
                [
                    "ffmpeg",
                    "-y",
                    "-f",
                    "concat",
                    "-safe",
                    "0",
                    "-i",
                    str(list_path),
                    "-c",
                    "copy",
                    str(output_path),
                ],
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            temp_path.unlink()
            list_path.unlink()

    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
