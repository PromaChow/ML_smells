import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models, callbacks, utils, optimizers
from sklearn.model_selection import train_test_split


class PseudoCallback(callbacks.Callback):
    def __init__(
        self,
        alpha_var,
        warm_up_epoch=5,
        stable_epoch=15,
        warm_up_weight=0.1,
        stable_weight=1.0,
    ):
        super().__init__()
        self.alpha_var = alpha_var
        self.warm_up_epoch = warm_up_epoch
        self.stable_epoch = stable_epoch
        self.warm_up_weight = warm_up_weight
        self.stable_weight = stable_weight

    def on_epoch_end(self, epoch, logs=None):
        if epoch < self.warm_up_epoch:
            new_alpha = self.warm_up_weight
        elif epoch >= self.stable_epoch:
            new_alpha = self.stable_weight
        else:
            progress = (epoch - self.warm_up_epoch + 1) / (
                self.stable_epoch - self.warm_up_epoch
            )
            new_alpha = self.warm_up_weight + progress * (self.stable_weight - self.warm_up_weight)
        tf.keras.backend.set_value(self.alpha_var, new_alpha)


class PseudoLabelNeuralNetworkClassifier:
    def __init__(
        self,
        hidden_units=(64,),
        epochs_pretrain=10,
        epochs_finetune=20,
        batch_size=32,
        warm_up_epoch=5,
        stable_epoch=15,
        warm_up_weight=0.1,
        stable_weight=1.0,
        verbose=1,
    ):
        self.hidden_units = hidden_units
        self.epochs_pretrain = epochs_pretrain
        self.epochs_finetune = epochs_finetune
        self.batch_size = batch_size
        self.warm_up_epoch = warm_up_epoch
        self.stable_epoch = stable_epoch
        self.warm_up_weight = warm_up_weight
        self.stable_weight = stable_weight
        self.verbose = verbose
        self.model = None
        self.alpha_var = tf.Variable(0.0, trainable=False, dtype=tf.float32)
        self.num_classes = None
        self.input_dim = None

    def _one_hot_encode(self, y):
        return utils.to_categorical(y, num_classes=self.num_classes)

    def _build_model(self):
        inputs = layers.Input(shape=(self.input_dim,))
        x = inputs
        for units in self.hidden_units:
            x = layers.Dense(units, activation="relu")(x)
        outputs = layers.Dense(self.num_classes, activation="softmax")(x)
        model = models.Model(inputs=inputs, outputs=outputs)
        return model

    def _make_loss(self):
        def loss(y_true, y_pred):
            labels = y_true[:, : self.num_classes]
            flags = y_true[:, -1]
            ce = tf.keras.losses.categorical_crossentropy(labels, y_pred, from_logits=False)
            weight = tf.where(tf.equal(flags, 0.0), 1.0, self.alpha_var)
            weighted_ce = ce * weight
            return tf.reduce_mean(weighted_ce)

        return loss

    def fit(
        self,
        X,
        y,
        X_val=None,
        y_val=None,
        test_size=0.2,
        random_state=42,
    ):
        X = np.asarray(X)
        y = np.asarray(y)

        unlabeled_mask = y == -1
        labeled_mask = ~unlabeled_mask

        labeled_X = X[labeled_mask]
        labeled_y = y[labeled_mask]
        unlabeled_X = X[unlabeled_mask]

        self.num_classes = np.unique(labeled_y).shape[0]
        self.input_dim = X.shape[1]

        labeled_y_onehot = self._one_hot_encode(labeled_y)
        flags_labeled = np.zeros((labeled_y_onehot.shape[0], 1), dtype=np.float32)
        y_labeled = np.concatenate([labeled_y_onehot, flags_labeled], axis=1)

        if X_val is None or y_val is None:
            X_train, X_val, y_train, y_val = train_test_split(
                labeled_X,
                y_labeled,
                test_size=test_size,
                random_state=random_state,
                stratify=labeled_y,
            )
        else:
            X_train, X_val = labeled_X, X_val
            y_train, y_val = y_labeled, y_val

        self.model = self._build_model()
        self.model.compile(
            optimizer=optimizers.Adam(),
            loss=self._make_loss(),
            metrics=["accuracy"],
        )

        es = callbacks.EarlyStopping(
            monitor="val_accuracy", patience=3, restore_best_weights=True, verbose=self.verbose
        )
        mc = callbacks.ModelCheckpoint(
            "best_model.h5", monitor="val_accuracy", save_best_only=True, verbose=self.verbose
        )
        pretrain_cb = PseudoCallback(
            alpha_var=self.alpha_var,
            warm_up_epoch=0,
            stable_epoch=0,
            warm_up_weight=1.0,
            stable_weight=1.0,
        )

        self.model.fit(
            X_train,
            y_train,
            epochs=self.epochs_pretrain,
            batch_size=self.batch_size,
            validation_data=(X_val, y_val),
            callbacks=[pretrain_cb, es, mc],
            verbose=self.verbose,
        )

        if unlabeled_X.shape[0] == 0:
            return

        pseudo_probs = self.model.predict(unlabeled_X, batch_size=self.batch_size, verbose=0)
        pseudo_labels = np.argmax(pseudo_probs, axis=1)
        pseudo_onehot = self._one_hot_encode(pseudo_labels)
        flags_pseudo = np.ones((pseudo_onehot.shape[0], 1), dtype=np.float32)
        y_pseudo = np.concatenate([pseudo_onehot, flags_pseudo], axis=1)

        X_merged = np.concatenate([labeled_X, unlabeled_X], axis=0)
        y_merged = np.concatenate([labeled_y_onehot, pseudo_onehot], axis=0)
        flags_merged = np.concatenate([flags_labeled, flags_pseudo], axis=0)
        y_combined = np.concatenate([y_merged, flags_merged], axis=1)

        if X_val is None or y_val is None:
            X_train_fine, X_val_fine, y_train_fine, y_val_fine = train_test_split(
                X_merged,
                y_combined,
                test_size=test_size,
                random_state=random_state,
                stratify=np.argmax(y_merged, axis=1),
            )
        else:
            X_train_fine, X_val_fine = X_merged, X_val
            y_train_fine, y_val_fine = y_combined, y_val

        finetune_cb = PseudoCallback(
            alpha_var=self.alpha_var,
            warm_up_epoch=self.warm_up_epoch,
            stable_epoch=self.stable_epoch,
            warm_up_weight=self.warm_up_weight,
            stable_weight=self.stable_weight,
        )

        self.model.compile(
            optimizer=optimizers.Adam(),
            loss=self._make_loss(),
            metrics=["accuracy"],
        )

        self.model.fit(
            X_train_fine,
            y_train_fine,
            epochs=self.epochs_finetune,
            batch_size=self.batch_size,
            validation_data=(X_val_fine, y_val_fine),
            callbacks=[finetune_cb, es, mc],
            verbose=self.verbose,
        )

    def evaluate_model(self, X_test, y_test, batch_size=32):
        y_test_onehot = self._one_hot_encode(y_test)
        flags_test = np.zeros((y_test_onehot.shape[0], 1), dtype=np.float32)
        y_test_combined = np.concatenate([y_test_onehot, flags_test], axis=1)
        return self.model.evaluate(X_test, y_test_combined, batch_size=batch_size, verbose=0)

    def predict_proba(self, X, batch_size=32):
        return self.model.predict(X, batch_size=batch_size, verbose=0)

    def predict(self, X, batch_size=32):
        probs = self.predict_proba(X, batch_size=batch_size)
        return np.argmax(probs, axis=1)
