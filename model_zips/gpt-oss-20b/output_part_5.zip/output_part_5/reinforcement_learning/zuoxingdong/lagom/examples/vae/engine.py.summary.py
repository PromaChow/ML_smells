import os
import time
from time import perf_counter
from pathlib import Path

import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from torchvision.utils import save_image

class Logger:
    def __init__(self, name: str):
        self.name = name
        self.records = []

    def log(self, **kwargs):
        self.records.append(kwargs)

    def dump(self, filepath: str):
        with open(filepath, "w") as f:
            f.write("-" * 50 + "\n")
            for record in self.records:
                f.write(str(record) + "\n")
            f.write("-" * 50 + "\n")
        self.records.clear()


def vae_loss(re_x: torch.Tensor, x: torch.Tensor,
             mu: torch.Tensor, logvar: torch.Tensor,
             loss_type: str = "BCE"):
    if loss_type == "BCE":
        re_loss = F.binary_cross_entropy(re_x, x, reduction="sum")
    else:
        raise ValueError("Unsupported loss type")
    kl_loss = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
    total_loss = re_loss + kl_loss
    return total_loss, re_loss, kl_loss


class Engine:
    def __init__(self,
                 model: torch.nn.Module,
                 train_loader: DataLoader,
                 test_loader: DataLoader,
                 optimizer: torch.optim.Optimizer,
                 config: dict,
                 logdir: str):
        self.model = model
        self.train_loader = train_loader
        self.test_loader = test_loader
        self.optimizer = optimizer
        self.config = config
        self.logdir = Path(logdir)
        self.logdir.mkdir(parents=True, exist_ok=True)

    def train(self, n: int):
        self.model.train()
        train_logger = Logger(f"train_epoch_{n}")

        for i, (data, _) in enumerate(self.train_loader):
            start_time = perf_counter()

            data = data.to(self.model.device)
            self.optimizer.zero_grad()

            re_x, mu, logvar = self.model(data)
            loss, re_loss, kl_loss = vae_loss(
                re_x, data, mu, logvar, loss_type="BCE"
            )
            loss.backward()
            self.optimizer.step()

            elapsed = perf_counter() - start_time
            train_logger.log(
                epoch=n,
                iter=self.model.total_iter,
                batch=i,
                train_loss=loss.item(),
                reconstruction_loss=re_loss.item(),
                kl_loss=kl_loss.item(),
                batch_time=elapsed
            )

            if (i + 1) % self.config.get("log.freq", 100) == 0:
                logfile = self.logdir / f"train_epoch_{n}_iter_{i+1}.txt"
                train_logger.dump(str(logfile))

        # Post-Training Sampling
        with torch.no_grad():
            z = torch.randn(64, self.config["nn.z_dim"],
                            device=self.model.device)
            sample_re = self.model.decode(z)
            sample_path = self.logdir / f"sample_{n}.png"
            save_image(sample_re, sample_path, nrow=8, normalize=True)

        return train_logger

    def eval(self, n: int):
        self.model.eval()
        eval_logger = Logger(f"eval_epoch_{n}")

        with torch.no_grad():
            for i, (data, _) in enumerate(self.test_loader):
                data = data.to(self.model.device)
                re_x, mu, logvar = self.model(data)
                loss, _, _ = vae_loss(re_x, data, mu, logvar, loss_type="BCE")
                eval_logger.log(
                    epoch=n,
                    batch=i,
                    eval_loss=loss.item()
                )

        # Post-Evaluation Reconstruction
        first_batch = next(iter(self.test_loader))
        data, _ = first_batch
        data = data.to(self.model.device)
        num_samples = min(data.size(0), 8)
        with torch.no_grad():
            re_x, _, _ = self.model(data[:num_samples])
        recon_path = self.logdir / f"reconstruction_{n}.png"
        comparison = torch.cat([data[:num_samples], re_x], dim=0)
        save_image(comparison, recon_path, nrow=num_samples, normalize=True)

        return eval_logger
