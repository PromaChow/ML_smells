import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.tsa.stattools import adfuller, acf, pacf
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from statsmodels.tsa.arima.model import ARIMA
from sklearn.metrics import mean_squared_error, mean_absolute_error

def test_stationarity(timeseries, title='Stationarity Test'):
    rolling_mean = timeseries.rolling(window=12).mean()
    rolling_std = timeseries.rolling(window=12).std()
    plt.figure(figsize=(12, 6))
    plt.plot(timeseries, color='blue', label='Original')
    plt.plot(rolling_mean, color='red', label='Rolling Mean')
    plt.plot(rolling_std, color='black', label='Rolling Std')
    plt.title(title)
    plt.legend()
    plt.show()
    adf_result = adfuller(timeseries.dropna())
    print(f'ADF Statistic: {adf_result[0]}')
    print(f'p-value: {adf_result[1]}')
    for key, value in adf_result[4].items():
        print(f'Critical Value {key}: {value}')

def main():
    df = pd.read_csv('SeaPlaneTravel.csv')
    df['Month'] = pd.to_datetime(df['Month'])
    df.set_index('Month', inplace=True)
    ts = df['#Passengers']

    plt.figure(figsize=(12, 4))
    plt.plot(ts, label='Passengers')
    plt.title('Monthly Sea Plane Passengers')
    plt.xlabel('Month')
    plt.ylabel('#Passengers')
    plt.legend()
    plt.show()

    print('Testing stationarity of original series:')
    test_stationarity(ts, title='Original Series')

    ts_log = np.log(ts)
    ts_log_diff = ts_log.diff().dropna()

    print('Testing stationarity of differenced log series:')
    test_stationarity(ts_log_diff, title='Differenced Log Series')

    fig, axes = plt.subplots(1, 2, figsize=(14, 4))
    plot_acf(ts_log_diff, ax=axes[0], lags=20)
    plot_pacf(ts_log_diff, ax=axes[1], lags=20)
    plt.show()

    model = ARIMA(ts_log, order=(2, 1, 1))
    results = model.fit()
    print(results.summary())

    fitted_vals = results.fittedvalues
    rss = np.sum(results.resid ** 2)
    print(f'Residual Sum of Squares: {rss}')

    plt.figure(figsize=(12, 4))
    plt.plot(ts_log_diff, label='Differenced Log', color='blue')
    plt.plot(fitted_vals, label='Fitted Values', color='red')
    plt.title('Fitted vs Differenced Log Series')
    plt.legend()
    plt.show()

    sns.kdeplot(results.resid, bw_adjust=0.5)
    plt.title('Residuals Kernel Density Estimate')
    plt.show()

    last_index = ts_log.index[-1]
    forecast_steps = 15
    forecast = results.get_forecast(steps=forecast_steps)
    forecast_values = np.exp(forecast.predicted_mean)
    forecast_ci = np.exp(forecast.conf_int())
    actual = ts[-forecast_steps:]

    plt.figure(figsize=(12, 4))
    plt.plot(ts, label='Actual')
    plt.plot(pd.date_range(last_index, periods=forecast_steps+1, freq='M')[1:], forecast_values, label='Forecast', color='red')
    plt.fill_between(pd.date_range(last_index, periods=forecast_steps+1, freq='M')[1:],
                     forecast_ci['lower #Passengers'],
                     forecast_ci['upper #Passengers'],
                     color='pink', alpha=0.3)
    plt.title('Actual vs Forecast')
    plt.legend()
    plt.show()

    rmse = mean_squared_error(actual, forecast_values, squared=False)
    print(f'RMSE of forecast: {rmse}')

    train_size = len(ts) - forecast_steps
    train, test = ts_log.iloc[:train_size], ts_log.iloc[train_size:]

    history = [x for x in train]
    predictions = []

    for t in range(len(test)):
        model = ARIMA(history, order=(2, 1, 1))
        model_fit = model.fit()
        yhat = model_fit.forecast()[0]
        predictions.append(yhat)
        history.append(test.iloc[t])

    predictions_exp = np.exp(predictions)
    test_exp = np.exp(test)

    mse = mean_squared_error(test_exp, predictions_exp)
    print(f'Rolling Forecast MSE: {mse}')

    plt.figure(figsize=(12, 4))
    plt.plot(test_exp.index, test_exp, label='Actual')
    plt.plot(test_exp.index, predictions_exp, label='Predicted', color='red')
    plt.title('Rolling Forecast: Actual vs Predicted')
    plt.legend()
    plt.show()

if __name__ == "__main__":
    main()