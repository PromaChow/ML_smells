import numpy as np
import gym


class SarsaLambda:
    def __init__(self, env: gym.Env, epsilon: float = 0.1, gamma: float = 0.99, lr: float = 0.1, lam: float = 0.9):
        self.env = env
        self.epsilon = epsilon
        self.gamma = gamma
        self.lr = lr
        self.lam = lam

        n_states = env.observation_space.n
        n_actions = env.action_space.n

        self.Q = np.zeros((n_states, n_actions))
        self.e_trace = np.zeros((n_states, n_actions))

    def get_action(self, state: int) -> int:
        if np.random.rand() < (1 - self.epsilon):
            return np.random.choice(self.env.action_space.n)
        else:
            return int(np.argmax(self.Q[state]))

    def update(self, state: int, action: int, reward: float, next_state: int):
        next_action = self.get_action(next_state)
        delta = reward + self.gamma * (self.Q[next_state, next_action] - self.Q[state, action])
        self.e_trace[state, action] += 1

        for s in range(self.Q.shape[0]):
            for a in range(self.Q.shape[1]):
                self.Q[s, a] += self.lr * (delta * self.e_trace[s, a])
                self.e_trace[s, a] = self.gamma * (self.lam * self.e_trace[s, a])