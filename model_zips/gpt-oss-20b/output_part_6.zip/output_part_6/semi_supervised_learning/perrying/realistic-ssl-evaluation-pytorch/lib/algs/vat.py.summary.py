import torch
import torch.nn.functional as F


class VAT:
    def __init__(self, eps: float = 1.0, xi: float = 1e-6, n_iteration: int = 1):
        self.eps = eps
        self.xi = xi
        self.n_iteration = n_iteration

    @staticmethod
    def kld(q_logit: torch.Tensor, p_logit: torch.Tensor) -> torch.Tensor:
        """
        KL divergence per sample: KL(q || p)
        """
        q = F.softmax(q_logit, dim=-1)
        log_q = F.log_softmax(q_logit, dim=-1)
        log_p = F.log_softmax(p_logit, dim=-1)
        qlogq = torch.sum(q * log_q, dim=-1)
        qlogp = torch.sum(q * log_p, dim=-1)
        return qlogq - qlogp

    @staticmethod
    def normalize(v: torch.Tensor) -> torch.Tensor:
        """
        Normalizes tensor v:
        1. Divide by max absolute value across all dims except batch.
        2. Divide by L2 norm across spatial dims (1, 2, 3).
        """
        # max absolute value across all dims except batch
        max_abs = v.abs().view(v.size(0), -1).max(dim=1, keepdim=True)[0].view(v.size(0), 1, 1, 1)
        v = v / (max_abs + 1e-12)

        # L2 norm across spatial dims
        l2_norm = torch.sqrt((v ** 2).sum(dim=(1, 2, 3), keepdim=True))
        v = v / (l2_norm + 1e-12)
        return v

    def __call__(self, model, x: torch.Tensor, y: torch.Tensor, mask: torch.Tensor = None) -> torch.Tensor:
        """
        Computes VAT loss for a batch.
        Args:
            model: Neural network with a method `update_batch_stats(bool)` if available.
            x: Input tensor [batch, channels, H, W].
            y: Original logits [batch, num_classes].
            mask: Optional mask [batch] or [batch, 1] to weight the loss.
        Returns:
            Scalar VAT loss.
        """
        device = x.device

        # Disable batch norm statistics if possible
        if hasattr(model, "update_batch_stats"):
            model.update_batch_stats(False)

        # Initial random perturbation
        d = torch.randn_like(x, device=device)
        d = self.normalize(d)

        # Iteratively refine perturbation
        for _ in range(self.n_iteration):
            d.requires_grad_(True)
            x_hat = x + self.xi * d
            y_hat = model(x_hat)

            # KL divergence per sample (detach original logits)
            kl = self.kld(y.detach(), y_hat)
            kl_mean = kl.mean()
            kl_mean.backward()
            grad = d.grad
            d = d + grad
            d = self.normalize(d)

        # Final perturbation
        x_hat = x + self.eps * d.detach()
        y_hat = model(x_hat)

        # VAT loss
        vat_loss_per_sample = self.kld(y.detach(), y_hat)
        if mask is not None:
            vat_loss_per_sample = vat_loss_per_sample * mask
        vat_loss = vat_loss_per_sample.mean()

        # Re-enable batch norm statistics if possible
        if hasattr(model, "update_batch_stats"):
            model.update_batch_stats(True)

        return vat_loss

# Example usage (requires a PyTorch model with update_batch_stats):
# vat = VAT(eps=1.0, xi=1e-6, n_iteration=1)
# loss = vat(model, inputs, logits, mask)
