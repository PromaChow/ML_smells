import torch
import torch.nn as nn
import torch.nn.functional as F

class MNIST_LeNet(nn.Module):
    def __init__(self, rep_dim: int):
        super().__init__()
        self.rep_dim = rep_dim
        self.conv1 = nn.Conv2d(
            in_channels=1, out_channels=8, kernel_size=5, bias=False, padding=2
        )
        self.bn1 = nn.BatchNorm2d(num_features=8, eps=1e-4, affine=False)
        self.conv2 = nn.Conv2d(
            in_channels=8, out_channels=4, kernel_size=5, bias=False, padding=2
        )
        self.bn2 = nn.BatchNorm2d(num_features=4, eps=1e-4, affine=False)
        self.leaky_relu = nn.LeakyReLU(inplace=True)
        self.maxpool = nn.MaxPool2d(kernel_size=2, stride=2)
        self.flatten = nn.Flatten()
        self.fc = nn.Linear(in_features=4 * 7 * 7, out_features=rep_dim, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x.view(-1, 1, 28, 28)
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.leaky_relu(x)
        x = self.maxpool(x)
        x = self.conv2(x)
        x = self.bn2(x)
        x = self.leaky_relu(x)
        x = self.maxpool(x)
        x = self.flatten(x)
        x = self.fc(x)
        return x

class MNIST_LeNet_Decoder(nn.Module):
    def __init__(self, rep_dim: int):
        super().__init__()
        self.rep_dim = rep_dim
        self.feature_map = rep_dim // 16
        self.deconv1 = nn.ConvTranspose2d(
            in_channels=self.feature_map, out_channels=4, kernel_size=5, bias=False, padding=2
        )
        self.bn3 = nn.BatchNorm2d(num_features=4, eps=1e-4, affine=False)
        self.deconv2 = nn.ConvTranspose2d(
            in_channels=4, out_channels=8, kernel_size=5, bias=False, padding=3
        )
        self.bn4 = nn.BatchNorm2d(num_features=8, eps=1e-4, affine=False)
        self.deconv3 = nn.ConvTranspose2d(
            in_channels=8, out_channels=1, kernel_size=5, bias=False, padding=2
        )
        self.leaky_relu = nn.LeakyReLU(inplace=True)

    def forward(self, z: torch.Tensor) -> torch.Tensor:
        z = z.view(-1, self.feature_map, 4, 4)
        z = F.interpolate(z, scale_factor=2, mode="bilinear", align_corners=False)
        z = self.deconv1(z)
        z = self.bn3(z)
        z = self.leaky_relu(z)
        z = F.interpolate(z, scale_factor=2, mode="bilinear", align_corners=False)
        z = self.deconv2(z)
        z = self.bn4(z)
        z = self.leaky_relu(z)
        z = F.interpolate(z, scale_factor=2, mode="bilinear", align_corners=False)
        z = self.deconv3(z)
        z = torch.sigmoid(z)
        return z

class MNIST_LeNet_Autoencoder(nn.Module):
    def __init__(self, rep_dim: int):
        super().__init__()
        self.encoder = MNIST_LeNet(rep_dim)
        self.decoder = MNIST_LeNet_Decoder(rep_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        z = self.encoder(x)
        recon = self.decoder(z)
        return recon
