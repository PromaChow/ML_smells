import numpy as np
import gym
from gym.spaces import Box
from typing import Any, Union

# Define a type alias for environments that support action_space attribute
EnvLike = Union[gym.Env, gym.vector.VectorEnv]


class ClipAction:
    """Wrapper that clips actions to the environment's action space bounds."""

    def __init__(self, env: EnvLike):
        if not isinstance(env.action_space, Box):
            raise TypeError("ClipAction requires a Box action space")
        self.env = env
        self.env_low = env.action_space.low
        self.env_high = env.action_space.high

    def action(self, action: np.ndarray) -> np.ndarray:
        """Clip the given action to the bounds of the environment."""
        return np.clip(action, self.env_low, self.env_high)


class RescaleAction:
    """Wrapper that rescales actions from a new [low, high] range to the environment's range."""

    def __init__(self, env: EnvLike, low: int, high: int):
        if not isinstance(env.action_space, Box):
            raise TypeError("RescaleAction requires a Box action space")
        if high <= low:
            raise ValueError("high must be greater than low")
        self.env = env
        self.env_low = env.action_space.low
        self.env_high = env.action_space.high

        # Broadcast low and high to match the action space shape and dtype
        self.low = np.full(env.action_space.shape, low, dtype=env.action_space.dtype)
        self.high = np.full(env.action_space.shape, high, dtype=env.action_space.dtype)

        # Define a new Box action space for the wrapper
        self.action_space = Box(low=self.low, high=self.high, dtype=env.action_space.dtype)

    def action(self, action: np.ndarray) -> np.ndarray:
        """Rescale and clip the given action to the environment's action space."""
        if np.any(action < self.low) or np.any(action > self.high):
            raise ValueError("Input action is outside the wrapper's action space bounds")
        # Linear interpolation from [low, high] to [env_low, env_high]
        scale = (self.env_high - self.env_low) * ((action - self.low) / (self.high - self.low))
        rescaled = self.env_low + scale
        # Ensure the rescaled action is within the original bounds
        return np.clip(rescaled, self.env_low, self.env_high)