import gymnasium
import numpy as np
import optuna
from stable_baselines3 import A2C
from stable_baselines3.common.vec_env import DummyVecEnv

def make_env():
    return gymnasium.make("CartPole-v0")

# Vectorized environment for training
vec_env = DummyVecEnv([lambda: make_env() for _ in range(4)])

class OnPolicyTrainer:
    def __init__(self, agent, env, log_interval=10, epochs=100, evaluate_episodes=10):
        self.agent = agent
        self.env = env
        self.log_interval = log_interval
        self.epochs = epochs
        self.evaluate_episodes = evaluate_episodes

    def train(self):
        for epoch in range(self.epochs):
            self.agent.learn(total_timesteps=self.log_interval * self.env.num_envs)
            if (epoch + 1) % self.log_interval == 0:
                print(f"Epoch {epoch + 1}/{self.epochs} completed.")

    def evaluate(self):
        eval_env = gymnasium.make("CartPole-v0")
        episode_rewards = []
        for _ in range(self.evaluate_episodes):
            obs, _ = eval_env.reset()
            done = False
            total_reward = 0.0
            while not done:
                action, _ = self.agent.predict(obs, deterministic=True)
                obs, reward, terminated, truncated, _ = eval_env.step(action)
                done = terminated or truncated
                total_reward += reward
            episode_rewards.append(total_reward)
        eval_env.close()
        return episode_rewards

def tune_A2C(trial):
    lr_value = trial.suggest_loguniform("lr_value", 1e-5, 1e-2)
    lr_policy = trial.suggest_loguniform("lr_policy", 1e-5, 1e-2)
    rollout_size = trial.suggest_int("rollout_size", 100, 10000)
    entropy_coeff = trial.suggest_loguniform("entropy_coeff", 5e-4, 2e-1)

    agent = A2C(
        "MlpPolicy",
        vec_env,
        learning_rate=lr_value,
        n_steps=rollout_size,
        entropy_coef=entropy_coeff,
        verbose=0,
    )

    trainer = OnPolicyTrainer(
        agent,
        vec_env,
        log_interval=10,
        epochs=100,
        evaluate_episodes=10,
    )

    trainer.train()
    episode_rewards = trainer.evaluate()
    mean_reward = np.mean(episode_rewards)
    std_reward = np.std(episode_rewards)
    print(f"Mean reward: {mean_reward:.2f} ± {std_reward:.2f}")
    return mean_reward

if __name__ == "__main__":
    study = optuna.create_study(
        study_name="A2C-3",
        storage="sqlite:///A2C-3.db",
        direction="maximize",
        load_if_exists=True,
    )
    study.optimize(tune_A2C, n_trials=20)

    print("\nBest trial:")
    trial = study.best_trial
    print(f"  Value: {trial.value}")
    print("  Params:")
    for key, value in trial.params.items():
        print(f"    {key}: {value}")