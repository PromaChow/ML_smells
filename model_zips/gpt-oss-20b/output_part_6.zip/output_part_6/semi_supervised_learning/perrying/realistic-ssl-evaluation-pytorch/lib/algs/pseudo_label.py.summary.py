import torch
import torch.nn as nn
import torch.nn.functional as F


class PL(nn.Module):
    def __init__(self, th: float = 0.5):
        super().__init__()
        self.th = th

    @staticmethod
    def __make_one_hot(indices: torch.Tensor, num_classes: int) -> torch.Tensor:
        return F.one_hot(indices, num_classes).float()

    def forward(
        self,
        model: nn.Module,
        x: torch.Tensor,
        y: torch.Tensor,
        mask: torch.Tensor,
    ) -> torch.Tensor:
        # Step 2: Convert logits to probabilities
        y_probs = F.softmax(y, dim=1)

        # Step 3: Ground truth mask construction
        pred_indices = y_probs.argmax(dim=1)
        num_classes = y_probs.size(1)
        one_hot = self.__make_one_hot(pred_indices, num_classes)

        gt_mask = (y_probs > self.th).max(dim=1)[0].float()
        lt_mask = 1.0 - gt_mask

        # Step 4: Target construction
        p_target = (
            gt_mask.unsqueeze(1) * (one_hot * 10.0)
            + lt_mask.unsqueeze(1) * y_probs
        )

        # Step 5: Model inference with batch stats disabled
        if hasattr(model, "update_batch_stats"):
            model.update_batch_stats(False)
        output = model(x)

        # Step 6: Loss calculation
        log_probs = F.log_softmax(output, dim=1)
        nll = -(p_target.detach() * log_probs).sum(dim=1)
        loss = (nll * mask).mean()

        # Step 7: Re-enable batch statistics
        if hasattr(model, "update_batch_stats"):
            model.update_batch_stats(True)

        return loss

# Example usage (requires a model with update_batch_stats method):
# model = MyModel()
# pl_loss = PL(th=0.7)
# loss = pl_loss(model, inputs, logits, sample_mask)