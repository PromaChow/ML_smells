import argparse
import os
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import gym
import chainerrl
from chainerrl import experiments
from chainerrl import wrappers
from chainerrl import optimizers

# --- Neural network components ------------------------------------------------

class ConvHead(nn.Module):
    def __init__(self, in_channels):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(in_channels, 32, kernel_size=8, stride=4),
            nn.ReLU(),
            nn.Conv2d(32, 64, kernel_size=4, stride=2),
            nn.ReLU(),
            nn.Conv2d(64, 64, kernel_size=3, stride=1),
            nn.ReLU(),
        )
        dummy = torch.zeros(1, in_channels, 84, 84)
        out = self.conv(dummy)
        self.out_size = out.view(1, -1).size(1)

    def forward(self, x):
        return self.conv(x).view(x.size(0), -1)

class FCSoftmaxPolicy(nn.Module):
    def __init__(self, input_size, n_actions):
        super().__init__()
        self.fc = nn.Linear(input_size, 256)
        self.logits = nn.Linear(256, n_actions)

    def forward(self, x):
        h = F.relu(self.fc(x))
        return self.logits(h)

    def act(self, x, stochastic=True):
        logits = self.forward(x)
        probs = F.softmax(logits, dim=-1)
        if stochastic:
            return probs.multinomial(num_samples=1).squeeze(-1)
        else:
            return torch.argmax(probs, dim=-1)

class FCValueFunction(nn.Module):
    def __init__(self, input_size):
        super().__init__()
        self.fc = nn.Linear(input_size, 256)
        self.v = nn.Linear(256, 1)

    def forward(self, x):
        h = F.relu(self.fc(x))
        return self.v(h).squeeze(-1)

# --- Models ----------------------------------------------------------------

class A3CFF(nn.Module):
    def __init__(self, obs_shape, n_actions):
        super().__init__()
        self.head = ConvHead(obs_shape[0])
        self.policy = FCSoftmaxPolicy(self.head.out_size, n_actions)
        self.value = FCValueFunction(self.head.out_size)

    def act(self, state, stochastic=True):
        features = self.head(state)
        return self.policy.act(features, stochastic)

    def value(self, state):
        features = self.head(state)
        return self.value(features)

class A3CLSTM(nn.Module):
    def __init__(self, obs_shape, n_actions, hidden_size=256):
        super().__init__()
        self.head = ConvHead(obs_shape[0])
        self.lstm = nn.LSTM(self.head.out_size, hidden_size, batch_first=True)
        self.policy = FCSoftmaxPolicy(hidden_size, n_actions)
        self.value = FCValueFunction(hidden_size)

    def init_hidden(self, batch_size):
        h0 = torch.zeros(1, batch_size, self.lstm.hidden_size, device=self.lstm.weight_ih.device)
        c0 = torch.zeros(1, batch_size, self.lstm.hidden_size, device=self.lstm.weight_ih.device)
        return (h0, c0)

    def act(self, state, hidden, stochastic=True):
        features = self.head(state).unsqueeze(1)
        out, hidden = self.lstm(features, hidden)
        out = out.squeeze(1)
        return self.policy.act(out, stochastic), hidden

    def value(self, state, hidden):
        features = self.head(state).unsqueeze(1)
        out, hidden = self.lstm(features, hidden)
        out = out.squeeze(1)
        return self.value(out), hidden

# --- Environment wrapper -----------------------------------------------------

def make_env(seed, rank, eval_env=False, use_monitor=False, render=False):
    env = gym.make(args.env)
    env.seed(seed + rank)
    env = wrappers.wrap_deepmind(env, frame_stack=True, clip_rewards=True, episode_life=True)
    if use_monitor:
        env = wrappers.Monitor(env, os.path.join(args.outdir, f'monitor_{rank}'), force=True)
    if render and not eval_env:
        env = wrappers.Render(env)
    return env

# --- Main -------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--processes', type=int, default=4)
    parser.add_argument('--env', type=str, default='BreakoutNoFrameskip-v4')
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--outdir', type=str, default='out')
    parser.add_argument('--t-max', type=int, default=5, dest='t_max')
    parser.add_argument('--lr', type=float, default=7e-4)
    parser.add_argument('--gamma', type=float, default=0.99)
    parser.add_argument('--beta', type=float, default=0.01)
    parser.add_argument('--steps', type=int, default=10**7)
    parser.add_argument('--use-lstm', action='store_true')
    parser.add_argument('--demo', action='store_true')
    parser.add_argument('--eval-interval', type=int, default=100000, dest='eval_interval')
    parser.add_argument('--eval-n-runs', type=int, default=10, dest='eval_n_runs')
    parser.add_argument('--render', action='store_true')
    parser.add_argument('--monitor', action='store_true')
    parser.add_argument('--load', type=str, default='')
    parser.add_argument('--weight-decay', type=float, default=0.0)
    args = parser.parse_args()

    os.makedirs(args.outdir, exist_ok=True)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)

    # Observation shape
    dummy_env = gym.make(args.env)
    n_actions = dummy_env.action_space.n
    obs_shape = dummy_env.observation_space.shape
    dummy_env.close()

    phi = lambda x: x / 255.0

    if args.use_lstm:
        model = A3CLSTM(obs_shape, n_actions)
    else:
        model = A3CFF(obs_shape, n_actions)

    optimizer = optimizers.RMSprop(
        model.parameters(),
        lr=args.lr,
        alpha=0.99,
        eps=1e-1,
        grad_clipping=40
    )
    if args.weight_decay > 0:
        optimizer.add_hook(optimizers.NonbiasWeightDecay(args.weight_decay))

    agent = chainerrl.agents.A3C(
        model,
        optimizer,
        t_max=args.t_max,
        gamma=args.gamma,
        beta=args.beta,
        phi=phi,
        seed=args.seed
    )

    if args.load:
        agent.load(args.load)

    if args.demo:
        env = make_env(args.seed, 0, eval_env=True, use_monitor=args.monitor)
        rewards = []
        for _ in range(args.eval_n_runs):
            obs = env.reset()
            done = False
            total_reward = 0.0
            while not done:
                obs = phi(obs)
                action = agent.act(obs)
                obs, reward, done, _ = env.step(action)
                total_reward += reward
            rewards.append(total_reward)
        print(f'Demo: mean={np.mean(rewards):.2f} median={np.median(rewards):.2f} std={np.std(rewards):.2f}')
        return

    envs = [make_env(args.seed, i, use_monitor=args.monitor) for i in range(args.processes)]
    eval_env = make_env(args.seed, 0, eval_env=True, use_monitor=args.monitor)

    experiments.train_agent_async(
        agent,
        envs,
        nsteps=args.steps,
        hooks=[experiments.LinearInterpolationHook(args.lr, 0, args.steps)],
        eval_every=args.eval_interval,
        eval_n_steps=args.eval_interval,
        eval_n_runs=args.eval_n_runs,
        eval_env=eval_env,
        outdir=args.outdir,
        seed=args.seed,
        render=args.render,
        monitor=args.monitor
    )

if __name__ == '__main__':
    main()
