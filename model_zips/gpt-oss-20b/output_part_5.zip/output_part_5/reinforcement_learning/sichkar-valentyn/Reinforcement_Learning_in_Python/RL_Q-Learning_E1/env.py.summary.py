import tkinter as tk

# Global dictionary to store the shortest route for external use
a = {}

class Environment(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Grid World Environment")
        self.grid_size = 9
        self.cell_size = 40
        self.width = self.grid_size * self.cell_size
        self.height = self.grid_size * self.cell_size
        self.canvas = tk.Canvas(self, width=self.width, height=self.height, bg="white")
        self.canvas.pack()
        self.draw_grid()

        # Action space
        self.actions = ['up', 'down', 'left', 'right']

        # Predefined obstacle positions (grid coordinates)
        self.obstacle_coords = [
            (2, 3), (4, 5), (6, 2), (3, 7), (7, 1)
        ]

        # Place obstacles on the canvas
        self.obstacle_items = {}
        for pos in self.obstacle_coords:
            x, y = pos
            item = self.canvas.create_rectangle(
                x * self.cell_size,
                y * self.cell_size,
                (x + 1) * self.cell_size,
                (y + 1) * self.cell_size,
                fill="grey"
            )
            self.obstacle_items[pos] = item

        # Goal position
        self.goal_pos = (6, 6)
        self.goal_item = self.canvas.create_rectangle(
            self.goal_pos[0] * self.cell_size,
            self.goal_pos[1] * self.cell_size,
            (self.goal_pos[0] + 1) * self.cell_size,
            (self.goal_pos[1] + 1) * self.cell_size,
            fill="gold"
        )

        # Agent initialization
        self.agent_pos = (0, 0)
        self.agent_item = self.canvas.create_rectangle(
            0, 0,
            self.cell_size, self.cell_size,
            fill="blue"
        )

        # Path tracking
        self.d = {}  # current episode path
        self.f = []  # shortest path found
        self.shortest_len = None
        self.longest_len = None

    def draw_grid(self):
        for i in range(self.grid_size + 1):
            self.canvas.create_line(
                i * self.cell_size, 0,
                i * self.cell_size, self.height,
                fill="black"
            )
            self.canvas.create_line(
                0, i * self.cell_size,
                self.width, i * self.cell_size,
                fill="black"
            )

    def reset(self):
        # Remove old agent
        self.canvas.delete(self.agent_item)
        # Create new agent at (0,0)
        self.agent_pos = (0, 0)
        self.agent_item = self.canvas.create_rectangle(
            0, 0,
            self.cell_size, self.cell_size,
            fill="blue"
        )
        self.d.clear()
        self.d[0] = self.agent_pos
        return self.agent_pos

    def step(self, action):
        x, y = self.agent_pos
        if action == 'up' and y > 0:
            y -= 1
        elif action == 'down' and y < self.grid_size - 1:
            y += 1
        elif action == 'left' and x > 0:
            x -= 1
        elif action == 'right' and x < self.grid_size - 1:
            x += 1
        else:
            # Invalid move, stay in place
            pass

        self.agent_pos = (x, y)
        # Move agent on canvas
        self.canvas.coords(
            self.agent_item,
            x * self.cell_size,
            y * self.cell_size,
            (x + 1) * self.cell_size,
            (y + 1) * self.cell_size
        )

        # Path tracking
        step_index = len(self.d)
        self.d[step_index] = self.agent_pos

        # Collision detection
        done = False
        reward = 0

        if self.agent_pos == self.goal_pos:
            reward = 1
            done = True
            path_len = len(self.d)
            if self.shortest_len is None or path_len < self.shortest_len:
                self.shortest_len = path_len
                self.f = [self.d[i] for i in range(len(self.d))]
            if self.longest_len is None or path_len > self.longest_len:
                self.longest_len = path_len
            a.clear()
            for i in range(len(self.f)):
                a[i] = self.f[i]
        elif self.agent_pos in self.obstacle_coords:
            reward = -1
            done = True
            self.d.clear()

        return self.agent_pos, reward, done, {}

    def render(self):
        self.update_idletasks()
        self.update()

    def final(self):
        # Draw shortest route in blue
        if self.f:
            for pos in self.f:
                x, y = pos
                self.canvas.create_oval(
                    x * self.cell_size + 10,
                    y * self.cell_size + 10,
                    (x + 1) * self.cell_size - 10,
                    (y + 1) * self.cell_size - 10,
                    outline="blue", width=3
                )
            # Mark starting point
            start_x, start_y = self.f[0]
            self.canvas.create_text(
                start_x * self.cell_size + self.cell_size / 2,
                start_y * self.cell_size + self.cell_size / 2,
                text="S", fill="green", font=("Arial", 16, "bold")
            )

if __name__ == "__main__":
    env = Environment()
    env.mainloop()
