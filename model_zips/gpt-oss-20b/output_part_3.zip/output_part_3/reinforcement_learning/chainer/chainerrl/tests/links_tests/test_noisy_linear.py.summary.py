import unittest
import numpy as np
import cupy
from chainer import links as L
from chainer.backends import cuda
from chainer.links.noise import FactorizedNoisyLinear
from chainer.testing.testing_tools import parameterized
from chainer.testing import condition

class TestFactorizedNoisyLinear(unittest.TestCase):
    @staticmethod
    def _make_linear(size_args, nobias):
        if size_args is None:
            mu = L.Linear(None, nobias=nobias)
        else:
            mu = L.Linear(size_args, nobias=nobias)
        return FactorizedNoisyLinear(mu)

    @parameterized.expand([
        (None, False),
        (None, True),
        ((10, 5), False),
        ((10, 5), True),
    ])
    def test_calls_cpu(self, size_args, nobias):
        linear = self._make_linear(size_args, nobias)
        shapes = [(1, 10), (5, 10)]
        dtypes = [np.float32, np.float64]
        for shape in shapes:
            for dtype in dtypes:
                x = np.random.randn(*shape).astype(dtype)
                y = linear(x)
                self.assertEqual(y.shape[0], shape[0])
                if size_args is not None:
                    self.assertEqual(y.shape[1], size_args[0])
                else:
                    self.assertEqual(y.shape[1], shape[1])
                self.assertEqual(y.dtype, dtype)

    @parameterized.expand([
        (None, False),
        (None, True),
        ((10, 5), False),
        ((10, 5), True),
    ])
    def test_calls_gpu(self, size_args, nobias):
        linear = self._make_linear(size_args, nobias)
        linear.to_gpu(0)
        shapes = [(1, 10), (5, 10)]
        dtypes = [cupy.float32, cupy.float64]
        for shape in shapes:
            for dtype in dtypes:
                x = cupy.random.randn(*shape).astype(dtype)
                y = linear(x)
                self.assertEqual(y.shape[0], shape[0])
                if size_args is not None:
                    self.assertEqual(y.shape[1], size_args[0])
                else:
                    self.assertEqual(y.shape[1], shape[1])
                self.assertEqual(y.dtype, dtype)

    @parameterized.expand([
        (None, False),
        (None, True),
        ((10, 5), False),
        ((10, 5), True),
    ])
    def test_calls_gpu_after_to_gpu(self, size_args, nobias):
        linear = self._make_linear(size_args, nobias)
        # Move only the internal mu parameter to GPU
        linear.mu.to_gpu(0)
        linear.to_gpu(0)
        shapes = [(1, 10), (5, 10)]
        dtypes = [cupy.float32, cupy.float64]
        for shape in shapes:
            for dtype in dtypes:
                x = cupy.random.randn(*shape).astype(dtype)
                y = linear(x)
                self.assertEqual(y.shape[0], shape[0])
                if size_args is not None:
                    self.assertEqual(y.shape[1], size_args[0])
                else:
                    self.assertEqual(y.shape[1], shape[1])
                self.assertEqual(y.dtype, dtype)

    @condition.retry(3)
    @parameterized.expand([
        (None, False),
        (None, True),
        ((10, 5), False),
        ((10, 5), True),
    ])
    def test_randomness_cpu(self, size_args, nobias):
        linear = self._make_linear(size_args, nobias)
        shape = (3, 10)
        x = np.random.randn(*shape).astype(np.float32)
        y1 = linear(x)
        y2 = linear(x)
        diff = (y1 - y2).astype(np.float64)
        sq_diff = np.sum(diff ** 2)
        outsize = y1.shape[1]
        sigma_scale = 0.4
        threshold = 2 * sigma_scale ** 2 * outsize
        self.assertGreaterEqual(sq_diff, threshold)

    @condition.retry(3)
    @parameterized.expand([
        (None, False),
        (None, True),
        ((10, 5), False),
        ((10, 5), True),
    ])
    def test_randomness_gpu(self, size_args, nobias):
        linear = self._make_linear(size_args, nobias)
        linear.to_gpu(0)
        shape = (3, 10)
        x = cupy.random.randn(*shape).astype(cupy.float32)
        y1 = linear(x)
        y2 = linear(x)
        diff = (y1 - y2).astype(cupy.float64)
        sq_diff = cupy.sum(diff ** 2).get()
        outsize = y1.shape[1]
        sigma_scale = 0.4
        threshold = 2 * sigma_scale ** 2 * outsize
        self.assertGreaterEqual(sq_diff, threshold)

    @parameterized.expand([
        (None, False),
        (None, True),
        ((10, 5), False),
        ((10, 5), True),
    ])
    def test_non_randomness_cpu(self, size_args, nobias):
        linear = self._make_linear(size_args, nobias)
        shape = (5, 10)
        x = np.ones(shape, dtype=np.float32)
        y = linear(x)
        y2 = linear(x)
        self.assertTrue(np.allclose(y, y2))

    @parameterized.expand([
        (None, False),
        (None, True),
        ((10, 5), False),
        ((10, 5), True),
    ])
    def test_non_randomness_gpu(self, size_args, nobias):
        linear = self._make_linear(size_args, nobias)
        linear.to_gpu(0)
        shape = (5, 10)
        x = cupy.ones(shape, dtype=cupy.float32)
        y = linear(x)
        y2 = linear(x)
        self.assertTrue(cupy.allclose(y, y2))

if __name__ == "__main__":
    unittest.main()
