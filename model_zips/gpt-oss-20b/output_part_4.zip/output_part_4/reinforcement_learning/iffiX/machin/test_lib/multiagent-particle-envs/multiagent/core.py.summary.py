import numpy as np
from typing import List, Callable, Optional, Tuple

# ---------- Core Data Structures ----------

class EntityState:
    def __init__(self,
                 position: Optional[np.ndarray] = None,
                 velocity: Optional[np.ndarray] = None,
                 mass: float = 1.0,
                 radius: float = 0.05,
                 color: Tuple[float, float, float] = (0.0, 0.0, 0.0)):
        self.position = np.array(position if position is not None else [0.0, 0.0, 0.0], dtype=float)
        self.velocity = np.array(velocity if velocity is not None else [0.0, 0.0, 0.0], dtype=float)
        self.mass = mass
        self.radius = radius
        self.color = color
        self.force = np.zeros(3, dtype=float)

class Action:
    def __init__(self, accel: np.ndarray, comm: np.ndarray):
        self.accel = np.array(accel, dtype=float)
        self.comm = np.array(comm, dtype=float)

# ---------- Entity Classes ----------

class Entity:
    def __init__(self,
                 movable: bool = True,
                 controllable: bool = False,
                 color: Tuple[float, float, float] = (0.5, 0.5, 0.5),
                 size: float = 0.05,
                 mass: float = 1.0):
        self.state = EntityState(
            position=np.zeros(3, dtype=float),
            velocity=np.zeros(3, dtype=float),
            mass=mass,
            radius=size,
            color=color
        )
        self.movable = movable
        self.controllable = controllable

class Agent(Entity):
    def __init__(self,
                 name: str,
                 dim_c: int,
                 dim_p: int,
                 max_speed: float = 2.0,
                 silent: bool = False,
                 action_noise: float = 0.0,
                 comm_noise: float = 0.0):
        super().__init__(movable=True, controllable=True)
        self.name = name
        self.dim_c = dim_c
        self.dim_p = dim_p
        self.max_speed = max_speed
        self.silent = silent
        self.action_noise = action_noise
        self.comm_noise = comm_noise
        self.action_callback: Optional[Callable[['Agent'], Action]] = None
        self.communication = np.zeros(dim_c, dtype=float)

    def set_action_callback(self, callback: Callable[['Agent'], Action]):
        self.action_callback = callback

    def take_action(self):
        if self.action_callback is None:
            accel = np.zeros(3, dtype=float)
            comm = np.zeros(self.dim_c, dtype=float)
        else:
            action = self.action_callback(self)
            accel = action.accel
            comm = action.comm
        if self.action_noise > 0.0:
            accel += np.random.randn(3) * self.action_noise
        if not self.silent:
            if self.comm_noise > 0.0:
                comm += np.random.randn(self.dim_c) * self.comm_noise
            self.communication = comm
        return accel

class Landmark(Entity):
    def __init__(self,
                 size: float = 0.05,
                 color: Tuple[float, float, float] = (1.0, 1.0, 1.0)):
        super().__init__(movable=False, controllable=False, color=color, size=size, mass=1e6)

# ---------- World Class ----------

class World:
    def __init__(self,
                 agents: List[Agent],
                 landmarks: List[Landmark],
                 dim_c: int = 2,
                 dim_p: int = 3,
                 dt: float = 0.01,
                 damping: float = 0.05,
                 collision_k: float = 1000.0,
                 collision_damping: float = 0.5,
                 noise_std: float = 0.0):
        self.agents = agents
        self.landmarks = landmarks
        self.entities: List[Entity] = agents + landmarks
        self.dim_c = dim_c
        self.dim_p = dim_p
        self.dt = dt
        self.damping = damping
        self.collision_k = collision_k
        self.collision_damping = collision_damping
        self.noise_std = noise_std
        self.time = 0.0

    def step(self):
        self._assign_actions()
        forces = self._compute_forces()
        self._integrate(forces)
        self.time += self.dt

    def _assign_actions(self):
        for agent in self.agents:
            agent.accel = agent.take_action()

    def _compute_forces(self) -> List[float]:
        for e in self.entities:
            e.force.fill(0.0)

        for agent in self.agents:
            if agent.movable:
                agent.state.force += agent.state.mass * agent.accel

        for i, e1 in enumerate(self.entities):
            for e2 in self.entities[i+1:]:
                self._apply_collision(e1, e2)

        return [e.state.force for e in self.entities]

    def _apply_collision(self, e1: Entity, e2: Entity):
        delta = e2.state.position - e1.state.position
        dist = np.linalg.norm(delta)
        min_dist = e1.state.radius + e2.state.radius
        if dist < min_dist and dist > 1e-8:
            penetration = min_dist - dist
            normal = delta / dist
            rel_vel = e2.state.velocity - e1.state.velocity
            rel_speed = np.dot(rel_vel, normal)
            force_mag = self.collision_k * penetration - self.collision_damping * rel_speed
            force = force_mag * normal
            if e1.movable:
                e1.state.force -= force
            if e2.movable:
                e2.state.force += force

    def _integrate(self, forces: List[np.ndarray]):
        for agent in self.agents:
            if agent.movable:
                agent.state.velocity += self.dt * agent.state.force / agent.state.mass
                agent.state.velocity *= (1 - self.damping)
                speed = np.linalg.norm(agent.state.velocity)
                if speed > agent.max_speed:
                    agent.state.velocity = agent.state.velocity / speed * agent.max_speed
                agent.state.position += self.dt * agent.state.velocity

        for landmark in self.landmarks:
            if landmark.movable:
                landmark.state.velocity += self.dt * landmark.state.force / landmark.state.mass
                landmark.state.velocity *= (1 - self.damping)
                landmark.state.position += self.dt * landmark.state.velocity

# ---------- Example Usage (Optional) ----------

if __name__ == "__main__":
    # Create two agents and one landmark
    a1 = Agent(name="A1", dim_c=2, dim_p=3, max_speed=1.5)
    a2 = Agent(name="A2", dim_c=2, dim_p=3, max_speed=1.5)
    l1 = Landmark(size=0.1)

    # Set random initial positions
    for e in [a1, a2, l1]:
        e.state.position = np.random.randn(3) * 0.5

    # Simple action callbacks: move towards origin
    def move_towards_origin(agent: Agent):
        direction = -agent.state.position
        if np.linalg.norm(direction) > 0:
            direction = direction / np.linalg.norm(direction) * 0.5
        return Action(accel=direction, comm=np.zeros(agent.dim_c))

    a1.set_action_callback(move_towards_origin)
    a2.set_action_callback(move_towards_origin)

    world = World(agents=[a1, a2], landmarks=[l1], dt=0.01)

    # Run 100 steps
    for _ in range(100):
        world.step()
        # Print positions
        print(f"Time {world.time:.2f}")
        for agent in world.agents:
            print(f"  {agent.name} pos {agent.state.position}")
        print(f"  Landmark pos {l1.state.position}")