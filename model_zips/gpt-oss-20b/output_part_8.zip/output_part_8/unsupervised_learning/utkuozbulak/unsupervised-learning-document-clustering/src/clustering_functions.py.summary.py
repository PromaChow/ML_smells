import numpy as np
from sklearn.cluster import KMeans, DBSCAN
from sklearn.manifold import MDS, TSNE
from sklearn.decomposition import PCA


def get_cluster_kmeans(tfidf_matrix: np.ndarray, n_clusters: int) -> list[int]:
    """
    Cluster the TF-IDF matrix using KMeans.

    Parameters
    ----------
    tfidf_matrix : np.ndarray
        TF-IDF representation of the data.
    n_clusters : int
        Number of clusters.

    Returns
    -------
    list[int]
        Cluster labels for each sample.
    """
    model = KMeans(n_clusters=n_clusters, random_state=42)
    model.fit(tfidf_matrix)
    return model.labels_.tolist()


def get_dbscan_cluster(tfidf_matrix: np.ndarray, eps: float) -> np.ndarray:
    """
    Cluster the TF-IDF matrix using DBSCAN.

    Parameters
    ----------
    tfidf_matrix : np.ndarray
        TF-IDF representation of the data.
    eps : float
        Neighborhood radius.

    Returns
    -------
    np.ndarray
        Cluster labels for each sample (noise labeled as -1).
    """
    model = DBSCAN(eps=eps, min_samples=3)
    model.fit(tfidf_matrix)
    return model.labels_


def multidim_scaling(similarity_matrix: np.ndarray, n_components: int = 2) -> tuple[np.ndarray, np.ndarray]:
    """
    Perform Multidimensional Scaling (MDS) on a similarity matrix.

    Parameters
    ----------
    similarity_matrix : np.ndarray
        Symmetric similarity matrix.
    n_components : int, default 2
        Number of dimensions to embed into.

    Returns
    -------
    tuple[np.ndarray, np.ndarray]
        x and y coordinates of the embedded points.
    """
    dissimilarity = 1.0 - similarity_matrix
    mds = MDS(n_components=n_components, dissimilarity="precomputed", random_state=4)
    coords = mds.fit_transform(dissimilarity)
    return coords[:, 0], coords[:, 1]


def pca_reduction(similarity_matrix: np.ndarray, n_components: int = 2) -> tuple[np.ndarray, np.ndarray]:
    """
    Perform PCA on a similarity matrix (converted to dissimilarity).

    Parameters
    ----------
    similarity_matrix : np.ndarray
        Symmetric similarity matrix.
    n_components : int, default 2
        Ignored; always reduces to 10 components then takes first two coordinates.

    Returns
    -------
    tuple[np.ndarray, np.ndarray]
        x and y coordinates of the embedded points.
    """
    dissimilarity = 1.0 - similarity_matrix
    pca = PCA(n_components=10, random_state=42)
    transformed = pca.fit_transform(dissimilarity)
    return transformed[:, 0], transformed[:, 1]


def tsne_reduction(similarity_matrix: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """
    Perform t-SNE on a similarity matrix (converted to dissimilarity).

    Parameters
    ----------
    similarity_matrix : np.ndarray
        Symmetric similarity matrix.

    Returns
    -------
    tuple[np.ndarray, np.ndarray]
        x and y coordinates of the embedded points.
    """
    dissimilarity = 1.0 - similarity_matrix
    tsne = TSNE(learning_rate=1000, metric="precomputed", random_state=42)
    coords = tsne.fit_transform(dissimilarity)
    return coords[:, 0], coords[:, 1]