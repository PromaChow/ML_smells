import pandas as pd
import numpy as np
import yfinance as yf
import requests
import io
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from datetime import datetime, timedelta

# ---------- Technical Indicator Functions ----------
def rate_of_change(series, period=14):
    return series.pct_change(periods=period) * 100

def bollinger_bands(series, window=20, num_std=2):
    ma = series.rolling(window=window).mean()
    std = series.rolling(window=window).std()
    upper = ma + num_std * std
    lower = ma - num_std * std
    return upper, lower

def stochastic_k(high, low, close, window=14):
    lowest_low = low.rolling(window=window).min()
    highest_high = high.rolling(window=window).max()
    k = 100 * (close - lowest_low) / (highest_high - lowest_low)
    return k

def macd(close, fast=12, slow=26, signal=9):
    ema_fast = close.ewm(span=fast, adjust=False).mean()
    ema_slow = close.ewm(span=slow, adjust=False).mean()
    macd_line = ema_fast - ema_slow
    signal_line = macd_line.ewm(span=signal, adjust=False).mean()
    diff = macd_line - signal_line
    return macd_line, signal_line, diff

def cci(high, low, close, window=20, constant=0.015):
    tp = (high + low + close) / 3
    ma = tp.rolling(window=window).mean()
    mean_dev = tp.rolling(window=window).apply(lambda x: np.mean(np.abs(x - np.mean(x))))
    cci = (tp - ma) / (constant * mean_dev)
    return cci

def rsi(series, period=14):
    delta = series.diff()
    up = delta.clip(lower=0)
    down = -1 * delta.clip(upper=0)
    ma_up = up.rolling(window=period).mean()
    ma_down = down.rolling(window=period).mean()
    rsi = 100 - (100 / (1 + ma_up / ma_down))
    return rsi

def compute_indicators(df):
    df = df.copy()
    df['ROC'] = rate_of_change(df['Close'], period=14)
    upper, lower = bollinger_bands(df['Close'])
    df['BB_UP'] = upper
    df['BB_LOW'] = lower
    df['%K'] = stochastic_k(df['High'], df['Low'], df['Close'])
    macd_line, signal_line, diff = macd(df['Close'])
    df['MACD'] = macd_line
    df['MACD_SIG'] = signal_line
    df['MACD_DIFF'] = diff
    df['CCI'] = cci(df['High'], df['Low'], df['Close'])
    df['RSI'] = rsi(df['Close'])
    df = df.dropna()
    return df

# ---------- Load Training Data ----------
def load_training_data(url):
    r = requests.get(url)
    csv = io.StringIO(r.text)
    train_df = pd.read_csv(csv, index_col=0, parse_dates=True)
    return train_df

# ---------- Train Classifiers ----------
def train_classifiers(universe, train_df):
    clf_dict = {}
    scaler_dict = {}
    features = ['Delta', 'MA10', 'MA20', 'MA100', 'ROC', 'BB_UP', 'BB_LOW',
                '%K', 'MACD', 'MACD_SIG', 'MACD_DIFF', 'CCI', 'RSI']
    for sym in universe:
        df_sym = train_df[train_df['Symbol'] == sym].copy()
        X = df_sym[features]
        y = df_sym['Class']
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        clf = RandomForestClassifier(n_estimators=200, random_state=42)
        clf.fit(X_scaled, y)
        clf_dict[sym] = clf
        scaler_dict[sym] = scaler
    return clf_dict, scaler_dict

# ---------- Prediction ----------
def predict_with_confidence(df_sym, clf, scaler):
    features = ['Delta', 'MA10', 'MA20', 'MA100', 'ROC', 'BB_UP', 'BB_LOW',
                '%K', 'MACD', 'MACD_SIG', 'MACD_DIFF', 'CCI', 'RSI']
    X = df_sym[features]
    X_scaled = scaler.transform(X)
    probs = clf.predict_proba(X_scaled)
    idx = X.index[-1]
    prob_long = probs[-1][clf.classes_ == 1][0]
    return idx, prob_long

# ---------- Rebalancing Loop ----------
def run_strategy(universe, train_url, start_date, end_date):
    train_df = load_training_data(train_url)
    clf_dict, scaler_dict = train_classifiers(universe, train_df)
    current_date = start_date
    rebalance_interval = timedelta(days=30)
    results = []

    while current_date <= end_date:
        # Fetch OHLC for all symbols
        df_dict = {}
        for sym in universe:
            data = yf.download(sym, start=current_date - timedelta(days=120), end=current_date)
            if data.empty:
                continue
            data = compute_indicators(data)
            # Compute additional features needed for prediction
            data['Delta'] = data['Close'].diff()
            data['MA10'] = data['Close'].rolling(window=10).mean()
            data['MA20'] = data['Close'].rolling(window=20).mean()
            data['MA100'] = data['Close'].rolling(window=100).mean()
            df_dict[sym] = data

        # Prediction
        long_candidates = []
        short_candidates = []

        for sym, df_sym in df_dict.items():
            if sym not in clf_dict:
                continue
            idx, prob_long = predict_with_confidence(df_sym, clf_dict[sym], scaler_dict[sym])
            if prob_long >= 0.925:
                long_candidates.append((sym, prob_long))
            elif prob_long <= 0.075:
                short_candidates.append((sym, prob_long))

        # Sort and assign weights
        long_candidates.sort(key=lambda x: x[1], reverse=True)
        short_candidates.sort(key=lambda x: x[1])

        long_count = len(long_candidates)
        short_count = len(short_candidates)
        total_positions = long_count + short_count

        if total_positions == 0:
            current_date += rebalance_interval
            continue

        weight_long = 1.0 / long_count if long_count else 0
        weight_short = 1.0 / short_count if short_count else 0

        orders = {}
        for sym, _ in long_candidates:
            orders[sym] = weight_long
        for sym, _ in short_candidates:
            orders[sym] = -weight_short

        # Record performance metrics
        leverage = sum(np.abs(list(orders.values())))
        diversification = {'long': long_count, 'short': short_count}

        results.append({
            'date': current_date,
            'orders': orders,
            'leverage': leverage,
            'diversification': diversification
        })

        current_date += rebalance_interval

    return results

# ---------- Main Execution ----------
if __name__ == "__main__":
    universe = ["AAPL", "MSFT", "GOOG", "AMZN", "FB", "TSLA", "NVDA", "JPM", "BAC", "WFC"]
    train_url = "https://www.dropbox.com/s/xxxxxx/training_data.csv?raw=1"
    start_date = datetime(2021, 1, 1)
    end_date = datetime(2021, 12, 31)
    performance = run_strategy(universe, train_url, start_date, end_date)
    for entry in performance:
        print(f"Date: {entry['date'].date()}, Orders: {entry['orders']}, "
              f"Leverage: {entry['leverage']:.2f}, "
              f"Diversification: {entry['diversification']}")
