import glob
import os
import re

import numpy as np
import pandas as pd


def process_motion_sense_accelerometer_files(input_path):
    """
    Process accelerometer CSV files in the MotionSense dataset.

    Parameters
    ----------
    input_path : str
        Path to the folder containing trial subfolders.

    Returns
    -------
    dict
        Dictionary where keys are user IDs (as strings) and values are lists of
        tuples (sensor_values, activity_labels). Each tuple corresponds to one
        trial.
    """
    user_datasets = {}

    # Identify all trial folders
    trial_folders = sorted(
        glob.glob(os.path.join(input_path, "*")),
        key=lambda x: os.path.basename(x).lower(),
    )
    trial_folders = [f for f in trial_folders if os.path.isdir(f)]

    # Regex pattern to extract user ID from filename
    user_id_pattern = re.compile(r"user_(\d+)\.csv", re.IGNORECASE)

    for trial_folder in trial_folders:
        trial_name = os.path.basename(trial_folder)
        trial_label = trial_name.split("_")[0]

        # Find all CSV files in the trial folder
        csv_files = sorted(
            glob.glob(os.path.join(trial_folder, "*.csv")),
            key=lambda x: os.path.basename(x).lower(),
        )

        for csv_file in csv_files:
            filename = os.path.basename(csv_file)
            match = user_id_pattern.search(filename)
            if not match:
                print(f"Error: Unable to extract user ID from filename '{filename}'.")
                continue

            user_id = match.group(1)

            # Load and clean data
            try:
                df = pd.read_csv(csv_file)
            except Exception as e:
                print(f"Error reading '{csv_file}': {e}")
                continue

            df = df.dropna(how="any")

            # Extract sensor values
            try:
                values = df[["x", "y", "z"]].values
            except KeyError as e:
                print(f"Missing required columns in '{csv_file}': {e}")
                continue

            # Create labels array
            labels = np.full(values.shape[0], trial_label, dtype=str)

            # Append to user_datasets
            user_entry = user_datasets.setdefault(user_id, [])
            user_entry.append((values, labels))

    return user_datasets

if __name__ == "__main__":
    # Example usage (replace 'path_to_data' with the actual path)
    data_path = "path_to_data"
    datasets = process_motion_sense_accelerometer_files(data_path)
    for user, entries in datasets.items():
        print(f"User {user}: {len(entries)} trial(s)")