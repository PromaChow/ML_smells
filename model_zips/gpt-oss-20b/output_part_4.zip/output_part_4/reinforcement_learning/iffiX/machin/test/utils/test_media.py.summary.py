import os

import numpy as np
import pytest

from machin.utils.media import (
    show_image,
    create_video,
    create_video_subproc,
    create_image,
    create_image_subproc,
)


@pytest.fixture
def images():
    """Generate 120 random 128x128 RGB images with uint8 values."""
    return [
        np.random.randint(
            0,
            256,
            size=(128, 128, 3),
            dtype=np.uint8,
        )
        for _ in range(120)
    ]


@pytest.fixture
def images_f():
    """Generate 120 random 128x128 RGB images with float values in [0.0, 1.0]."""
    return [
        np.random.rand(128, 128, 3).astype(np.float32)
        for _ in range(120)
    ]


def test_show_image(images):
    # Test with normalized display
    show_image(images[0], show_normalized=True)
    # Test with raw display
    show_image(images[0], show_normalized=False)


def test_create_video(images, tmpdir):
    dir_path = tmpdir.make_numbered_dir()
    gif_path = os.path.join(dir_path, "vid.gif")
    mp4_path = os.path.join(dir_path, "vid.mp4")

    create_video(images, gif_path)
    create_video(images, mp4_path)

    assert os.path.exists(gif_path)
    assert os.path.exists(mp4_path)


def test_create_video_float(images_f, tmpdir):
    dir_path = tmpdir.make_numbered_dir()
    gif_path = os.path.join(dir_path, "vid.gif")
    mp4_path = os.path.join(dir_path, "vid.mp4")

    create_video(images_f, gif_path)
    create_video(images_f, mp4_path)

    assert os.path.exists(gif_path)
    assert os.path.exists(mp4_path)


def test_create_video_subproc(images, tmpdir):
    dir_path = tmpdir.make_numbered_dir()

    # Empty image list should produce an empty GIF
    empty_gif = os.path.join(dir_path, "empty.gif")
    create_video_subproc([], empty_gif)
    assert os.path.exists(empty_gif)

    # Valid image list
    valid_gif = os.path.join(dir_path, "vid.gif")
    create_video_subproc(images, valid_gif)
    assert os.path.exists(valid_gif)


def test_create_image(images, tmpdir):
    dir_path = tmpdir.make_numbered_dir()
    img_path = os.path.join(dir_path, "img.png")

    create_image(images[0], img_path)

    assert os.path.exists(img_path)


def test_create_image_float(images_f, tmpdir):
    dir_path = tmpdir.make_numbered_dir()
    img_path = os.path.join(dir_path, "img.png")

    create_image(images_f[0], img_path)

    assert os.path.exists(img_path)


def test_create_image_subproc(images, tmpdir):
    dir_path = tmpdir.make_numbered_dir()
    img_path = os.path.join(dir_path, "img.png")

    create_image_subproc(images[0], img_path)

    assert os.path.exists(img_path)