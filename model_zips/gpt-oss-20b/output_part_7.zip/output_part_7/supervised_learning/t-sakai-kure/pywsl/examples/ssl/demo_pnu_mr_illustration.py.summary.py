import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from pywsl.ssl.pnu_mr import PNU_SL_FastCV
from pywsl.cpe.cpe_ene import cpe

def calc_err(f_dec, x_tp, x_tn, prior):
    """Weighted error rate based on decision function outputs."""
    tp_scores = f_dec(x_tp)
    tn_scores = f_dec(x_tn)
    err_tp = np.mean(tp_scores <= 0)
    err_tn = np.mean(tn_scores > 0)
    return prior * err_tp + (1 - prior) * err_tn

def gendata(n_l, n_u, n_t, prior_l, prior_u):
    """Generate synthetic 2‑D data for labeled, unlabeled and test sets."""
    # Labeled data
    n_l_pos = int(np.round(n_l * prior_l))
    n_l_neg = n_l - n_l_pos
    x_l_pos = np.random.randn(n_l_pos, 2) + np.array([1, 1])
    x_l_neg = np.random.randn(n_l_neg, 2) + np.array([-1, -1])
    x_l = np.vstack([x_l_pos, x_l_neg])
    y_l = np.hstack([np.ones(n_l_pos), -np.ones(n_l_neg)])

    # Unlabeled data
    n_u_pos = int(np.round(n_u * prior_u))
    n_u_neg = n_u - n_u_pos
    x_u_pos = np.random.randn(n_u_pos, 2) + np.array([1, 1])
    x_u_neg = np.random.randn(n_u_neg, 2) + np.array([-1, -1])
    x_u = np.vstack([x_u_pos, x_u_neg])

    # Test data
    x_tp = np.random.randn(n_t, 2) + np.array([1, 1])
    x_tn = np.random.randn(n_t, 2) + np.array([-1, -1])

    return x_l, y_l, x_u, x_tp, x_tn

def decision_function_from_weights(weights):
    """Return a callable decision function from weight vector."""
    def f(x):
        return np.dot(x, weights[:2]) + weights[2]
    return f

if __name__ == "__main__":
    # Parameters
    n_l = 10
    n_u = 300
    n_t = 1000
    prior_l = 0.5
    prior_u = 0.3
    eta_list = np.arange(-0.9, 1.01, 0.1)
    n_trial = 20

    np.random.seed(1)

    errs1 = []
    errs2 = np.zeros(len(eta_list))
    priors_est = []

    best_err = np.inf
    best_w = None
    best_x = None
    best_y = None

    for _ in range(n_trial):
        x_l, y_l, x_u, x_tp, x_tn = gendata(n_l, n_u, n_t, prior_l, prior_u)

        # Prior estimation
        prior_est = cpe.cpe(x_u, x_l, y_l)
        priors_est.append(prior_est)

        # Model training with sweep over eta
        f_dec, outs, funcs = PNU_SL_FastCV(x_l, y_l, x_u, prior_est, eta_list)

        # Best model error
        err_best = calc_err(f_dec, x_tp, x_tn, prior_l)
        errs1.append(err_best)

        # Errors for each eta
        for i, f in enumerate(funcs):
            errs2[i] += calc_err(f, x_tp, x_tn, prior_l)

        # Track best model across trials
        if err_best < best_err:
            best_err = err_best
            best_w = outs[0]  # assume first weight vector is best
            best_x = x_l
            best_y = y_l

    # Average errors
    errs1_mean = np.mean(errs1)
    errs1_se = np.std(errs1, ddof=1) / np.sqrt(n_trial)

    errs2_mean = errs2 / n_trial
    errs2_std = np.std(errs2 / n_trial, axis=0, ddof=1)

    priors_est_mean = np.mean(priors_est)
    priors_est_se = np.std(priors_est, ddof=1) / np.sqrt(n_trial)

    print(f"Average misclassification rate: {errs1_mean:.4f} ± {errs1_se:.4f}")
    print(f"Estimated prior mean: {priors_est_mean:.4f} ± {priors_est_se:.4f}")

    # Plot data
    plt.figure(figsize=(8, 6))
    plt.scatter(x_u[:, 0], x_u[:, 1], color='black', s=10, label='Unlabeled')
    plt.scatter(best_x[best_y == 1, 0], best_x[best_y == 1, 1],
                facecolors='none', edgecolors='blue', s=80, label='Positive (labeled)')
    plt.scatter(best_x[best_y == -1, 0], best_x[best_y == -1, 1],
                marker='x', color='red', s=80, label='Negative (labeled)')

    # Decision boundary from best model
    w = best_w
    x_vals = np.linspace(np.min(best_x[:, 0]) - 1, np.max(best_x[:, 0]) + 1, 200)
    if abs(w[1]) > 1e-6:
        y_vals = -(w[0] * x_vals + w[2]) / w[1]
        plt.plot(x_vals, y_vals, 'k-', lw=2, label='Best decision boundary')

    plt.xlim(np.min(best_x[:, 0]) - 1, np.max(best_x[:, 0]) + 1)
    plt.ylim(np.min(best_x[:, 1]) - 1, np.max(best_x[:, 1]) + 1)
    plt.legend()
    plt.title('Synthetic Data and Decision Boundary')
    plt.xlabel('Feature 1')
    plt.ylabel('Feature 2')
    plt.tight_layout()
    plt.show()

    # Error curve
    plt.figure(figsize=(8, 4))
    sns.barplot(x=eta_list, y=errs2_mean, yerr=errs2_std, palette='viridis')
    plt.title('Average Misclassification Rate vs. η')
    plt.xlabel('η')
    plt.ylabel('Error Rate')
    plt.tight_layout()
    plt.show()
