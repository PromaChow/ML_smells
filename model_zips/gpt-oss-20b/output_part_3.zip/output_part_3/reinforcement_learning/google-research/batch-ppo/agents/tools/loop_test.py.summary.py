import pytest
from dataclasses import dataclass, field
from typing import Callable, List, Optional, Any, Tuple


@dataclass
class Phase:
    steps: int
    report_every: int = 1
    feed: Optional[Callable[[int], Any]] = None
    score: Optional[Callable[[Any], Any]] = None
    done: Optional[Callable[[int], bool]] = None


class Loop:
    def __init__(self, max_steps: int, phases: List[Phase]):
        self.max_steps = max_steps
        self.phases = phases
        self.reported: List[Any] = []

    def run(self) -> List[Any]:
        phase_idx = 0
        phase_step = 0
        overall_step = 0

        while overall_step < self.max_steps:
            phase = self.phases[phase_idx]

            # Prepare feed
            feed_data = phase.feed(overall_step) if phase.feed else None
            # Compute score
            score_val = phase.score(feed_data) if phase.score else None

            # Check done condition
            done = phase.done(overall_step) if phase.done else True

            # Report if needed
            if done and ((overall_step + 1) % phase.report_every == 0):
                self.reported.append(score_val)

            # Advance phase
            phase_step += 1
            if phase_step >= phase.steps:
                phase_step = 0
                phase_idx = (phase_idx + 1) % len(self.phases)

            overall_step += 1

        return self.reported


def test_report_every_step():
    step = 0

    def feed(step_val):
        nonlocal step
        step = step_val + 1
        return None

    phase = Phase(
        steps=1,
        report_every=3,
        feed=feed,
        score=lambda _: None,
    )

    loop = Loop(max_steps=9, phases=[phase])
    loop.run()
    assert step == 9


def test_phases_feed():
    scores_collected: List[int] = []

    def score_factory(val):
        return lambda _: val

    phase1 = Phase(steps=1, report_every=1, score=score_factory(1))
    phase2 = Phase(steps=3, report_every=1, score=score_factory(2))
    phase3 = Phase(steps=2, report_every=1, score=score_factory(3))

    loop = Loop(max_steps=15, phases=[phase1, phase2, phase3])
    loop.run()
    assert loop.reported == [1, 2, 2, 2, 3, 3, 1, 2, 2, 2, 3, 3, 1, 2, 2]


def test_average_score_over_phases():
    scores_collected: List[float] = []

    phase1 = Phase(
        steps=1,
        report_every=2,
        score=lambda _: 1
    )
    phase2 = Phase(
        steps=2,
        report_every=5,
        score=lambda _: 2
    )

    loop = Loop(max_steps=17, phases=[phase1, phase2])
    loop.run()

    # Aggregate scores from each phase at its report intervals
    # and then compute the average over all reported scores.
    scores_collected = loop.reported
    avg_scores = [sum(scores_collected[i::5]) / max(1, len(scores_collected[i::5]))
                  for i in range(5)]
    # For this specific setup the expected averaged list is
    # [1, 2, 1, 2, 1]
    assert avg_scores == [1, 2, 1, 2, 1]


def test_not_done():
    collected_scores: List[int] = []

    def done(step_val):
        return (step_val + 1) % 2 == 0

    def score(step_val):
        return step_val

    phase = Phase(
        steps=1,
        report_every=1,
        done=done,
        score=score
    )

    loop = Loop(max_steps=9, phases=[phase])
    loop.run()
    assert loop.reported == [1, 4, 7]


def test_not_done_batch():
    batches: List[Tuple[int, int]] = []

    def done(step_val):
        return step_val % 3 == 0 and step_val % 4 == 0

    def score(step_val):
        return (step_val, step_val ** 2)

    phase = Phase(
        steps=1,
        report_every=1,
        done=done,
        score=score
    )

    loop = Loop(max_steps=8, phases=[phase])
    loop.run()

    # collect batches when done is true
    for s, v in loop.reported:
        batches.append((s, v))

    # average across the collected batches
    if batches:
        avg_s = sum(b[0] for b in batches) / len(batches)
        avg_v = sum(b[1] for b in batches) / len(batches)
        assert [avg_s, avg_v] == [0, 0]
    else:
        assert [] == []  # No batches collected

```