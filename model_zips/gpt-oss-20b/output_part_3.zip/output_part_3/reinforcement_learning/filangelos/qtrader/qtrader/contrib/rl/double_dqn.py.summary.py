import random
import numpy as np
from collections import deque
from tensorflow.keras.models import Sequential, clone_model
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.initializers import HeUniform

class DoubleDQNAgent:
    def __init__(self, state_size, action_size):
        self.state_size = state_size
        self.action_size = action_size

        # Hyperparameters
        self.gamma = 0.99
        self.lr = 0.001
        self.epsilon = 1.0
        self.epsilon_min = 0.01
        self.epsilon_decay = 0.995
        self.batch_size = 64
        self.train_start = 1000
        self.memory = deque(maxlen=5000)
        self.update_freq = 10
        self.train_step = 0

        # Models
        self.model = self._build_model()
        self.target_model = clone_model(self.model)
        self.target_model.set_weights(self.model.get_weights())

    def _build_model(self):
        model = Sequential([
            Dense(50, activation='relu', kernel_initializer=HeUniform(), input_shape=(self.state_size,)),
            Dense(50, activation='relu', kernel_initializer=HeUniform()),
            Dense(self.action_size, activation='linear')
        ])
        model.compile(optimizer=Adam(learning_rate=self.lr), loss='mse')
        return model

    def update_target_model(self):
        self.target_model.set_weights(self.model.get_weights())

    def append_sample(self, state, action, reward, next_state, done):
        self.memory.append((state, action, reward, next_state, done))
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay
            if self.epsilon < self.epsilon_min:
                self.epsilon = self.epsilon_min

    def get_action(self, state):
        if np.random.rand() < self.epsilon:
            return random.randrange(self.action_size)
        state = np.array(state).reshape(1, -1).astype(np.float32)
        q_values = self.model.predict(state, verbose=0)
        return np.argmax(q_values[0])

    def train(self):
        if len(self.memory) < self.train_start:
            return

        batch = random.sample(self.memory, min(self.batch_size, len(self.memory)))

        states = np.array([sample[0] for sample in batch], dtype=np.float32)
        actions = np.array([sample[1] for sample in batch])
        rewards = np.array([sample[2] for sample in batch])
        next_states = np.array([sample[3] for sample in batch], dtype=np.float32)
        dones = np.array([sample[4] for sample in batch])

        # Current Q values
        q_values = self.model.predict(states, verbose=0)
        # Next Q values from main model for action selection
        q_next_main = self.model.predict(next_states, verbose=0)
        best_actions = np.argmax(q_next_main, axis=1)
        # Next Q values from target model for evaluation
        q_next_target = self.target_model.predict(next_states, verbose=0)
        target_q = rewards + self.gamma * q_next_target[np.arange(len(batch)), best_actions] * (1 - dones)

        q_values[np.arange(len(batch)), actions] = target_q

        self.model.train_on_batch(states, q_values)

        self.train_step += 1
        if self.train_step % self.update_freq == 0:
            self.update_target_model()