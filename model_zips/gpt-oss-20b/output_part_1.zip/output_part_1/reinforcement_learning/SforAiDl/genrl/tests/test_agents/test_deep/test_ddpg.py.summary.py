import os
import shutil
import numpy as np

from genrl.envs import VectorEnv
from genrl.algorithms import DDPG
from genrl.algorithms.common.noise import NormalActionNoise
from genrl.trainer.offpolicy import OffPolicyTrainer


def _create_env():
    return VectorEnv("Pendulum-v0", n_envs=2)


def _create_agent(env, shared_layers=None):
    action_noise = NormalActionNoise(
        mean=np.zeros(env.action_space.shape),
        sigma=0.1 * np.ones(env.action_space.shape),
    )
    return DDPG(
        env=env,
        policy="mlp",
        value="mlp",
        batch_size=5,
        policy_layers=[1, 1],
        value_layers=[1, 1],
        action_noise=action_noise,
        shared_layers=shared_layers,
    )


def _train_agent(agent, env):
    trainer = OffPolicyTrainer(
        env=env,
        agent=agent,
        train_epochs=4,
        max_steps=200,
        warmup=10,
        start_step=10,
        log_dir="./logs",
        log_format="csv",
    )
    trainer.train()


def _cleanup():
    if os.path.exists("./logs"):
        shutil.rmtree("./logs")


def test_ddpg():
    _cleanup()
    env = _create_env()
    agent = _create_agent(env)
    _train_agent(agent, env)
    _cleanup()


def test_ddpg_shared():
    _cleanup()
    env = _create_env()
    agent = _create_agent(env, shared_layers=[1, 1])
    _train_agent(agent, env)
    _cleanup()


if __name__ == "__main__":
    test_ddpg()
    test_ddpg_shared()
