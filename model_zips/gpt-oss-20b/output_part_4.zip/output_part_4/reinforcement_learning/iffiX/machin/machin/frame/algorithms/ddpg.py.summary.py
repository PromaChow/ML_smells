import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import copy
from collections import deque, namedtuple
from typing import List, Tuple, Dict, Any, Optional


# Simple fully connected network for actor and critic
class MLP(nn.Module):
    def __init__(self, input_dim: int, output_dim: int, hidden_dims: Tuple[int, ...] = (256, 256)):
        super().__init__()
        layers = []
        last_dim = input_dim
        for h in hidden_dims:
            layers.append(nn.Linear(last_dim, h))
            layers.append(nn.ReLU())
            last_dim = h
        layers.append(nn.Linear(last_dim, output_dim))
        self.model = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.model(x)


# Replay buffer implementation
class ReplayBuffer:
    Transition = namedtuple(
        "Transition",
        ("state", "action", "reward", "next_state", "done"),
    )

    def __init__(self, capacity: int):
        self.capacity = capacity
        self.buffer = deque(maxlen=capacity)

    def push(self, *args):
        self.buffer.append(self.Transition(*args))

    def sample(self, batch_size: int) -> ReplayBuffer.Transition:
        batch = random.sample(self.buffer, batch_size)
        return ReplayBuffer.Transition(*zip(*batch))

    def __len__(self) -> int:
        return len(self.buffer)


# Ornstein-Uhlenbeck noise for exploration
class OrnsteinUhlenbeckNoise:
    def __init__(self, size: int, mu: float = 0.0, theta: float = 0.15, sigma: float = 0.2):
        self.size = size
        self.mu = mu
        self.theta = theta
        self.sigma = sigma
        self.state = np.ones(self.size) * self.mu

    def reset(self):
        self.state = np.ones(self.size) * self.mu

    def sample(self) -> np.ndarray:
        x = self.state
        dx = self.theta * (self.mu - x) + self.sigma * np.random.randn(self.size)
        self.state = x + dx
        return self.state


# DDPG implementation
class DDPG:
    def __init__(self, config: Dict[str, Any]):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.state_dim = config["state_dim"]
        self.action_dim = config["action_dim"]
        self.action_bound = config["action_bound"]
        self.actor_hidden = config["actor_hidden"]
        self.critic_hidden = config["critic_hidden"]

        self.actor = MLP(self.state_dim, self.action_dim, self.actor_hidden).to(self.device)
        self.critic = MLP(self.state_dim + self.action_dim, 1, self.critic_hidden).to(self.device)
        self.target_actor = copy.deepcopy(self.actor)
        self.target_critic = copy.deepcopy(self.critic)

        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=config["actor_lr"])
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=config["critic_lr"])

        self.actor_scheduler = (
            optim.lr_scheduler.StepLR(self.actor_optimizer, step_size=config["lr_step_size"], gamma=config["lr_gamma"])
            if config.get("actor_scheduler")
            else None
        )
        self.critic_scheduler = (
            optim.lr_scheduler.StepLR(self.critic_optimizer, step_size=config["lr_step_size"], gamma=config["lr_gamma"])
            if config.get("critic_scheduler")
            else None
        )

        self.replay_buffer = ReplayBuffer(config["replay_buffer_capacity"])
        self.gamma = config["gamma"]
        self.tau = config["tau"]
        self.update_steps = config["update_steps"]
        self.update_rate = config["update_rate"]
        self.batch_size = config["batch_size"]
        self.total_steps = 0
        self.noise = OrnsteinUhlenbeckNoise(self.action_dim)

    def act(self, state: np.ndarray, use_target: bool = False) -> np.ndarray:
        self.actor.eval()
        self.target_actor.eval()
        with torch.no_grad():
            state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
            net = self.target_actor if use_target else self.actor
            action = net(state_tensor).cpu().numpy()[0]
            action = np.clip(action, -self.action_bound, self.action_bound)
        self.actor.train()
        self.target_actor.train()
        return action

    def act_with_noise(self, state: np.ndarray, noise_type: str = "OU") -> np.ndarray:
        action = self.act(state)
        if noise_type == "uniform":
            noise = np.random.uniform(-self.action_bound, self.action_bound, size=action.shape)
        elif noise_type == "normal":
            noise = np.random.normal(0, self.action_bound, size=action.shape)
        elif noise_type == "clipped_normal":
            noise = np.clip(np.random.normal(0, self.action_bound, size=action.shape), -self.action_bound, self.action_bound)
        elif noise_type == "OU":
            noise = self.noise.sample()
        else:
            noise = np.zeros_like(action)
        return np.clip(action + noise, -self.action_bound, self.action_bound)

    def act_discrete(self, state: np.ndarray, use_target: bool = False) -> int:
        self.actor.eval()
        self.target_actor.eval()
        with torch.no_grad():
            state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
            net = self.target_actor if use_target else self.actor
            logits = net(state_tensor)
            action = torch.argmax(logits, dim=1).cpu().item()
        self.actor.train()
        self.target_actor.train()
        return action

    def act_discrete_with_noise(self, state: np.ndarray, temperature: float = 1.0) -> int:
        self.actor.eval()
        with torch.no_grad():
            state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
            logits = self.actor(state_tensor) / temperature
            probs = torch.softmax(logits, dim=1)
            action = torch.multinomial(probs, num_samples=1).cpu().item()
        self.actor.train()
        return action

    def store_episode(self, transitions: List[Tuple[np.ndarray, np.ndarray, float, np.ndarray, bool]]):
        for t in transitions:
            self.replay_buffer.push(*t)

    def update(self):
        if len(self.replay_buffer) < self.batch_size:
            return

        transitions = self.replay_buffer.sample(self.batch_size)
        state_batch = torch.FloatTensor(np.array(transitions.state)).to(self.device)
        action_batch = torch.FloatTensor(np.array(transitions.action)).to(self.device)
        reward_batch = torch.FloatTensor(np.array(transitions.reward)).unsqueeze(1).to(self.device)
        next_state_batch = torch.FloatTensor(np.array(transitions.next_state)).to(self.device)
        done_batch = torch.FloatTensor(np.array(transitions.done).astype(np.float32)).unsqueeze(1).to(self.device)

        # Critic update
        with torch.no_grad():
            next_action_batch = self.target_actor(next_state_batch)
            next_q = self.target_critic(torch.cat([next_state_batch, next_action_batch], dim=1))
            target_q = reward_batch + (1 - done_batch) * self.gamma * next_q

        current_q = self.critic(torch.cat([state_batch, action_batch], dim=1))
        critic_loss = nn.MSELoss()(current_q, target_q)

        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.critic.parameters(), 1.0)
        self.critic_optimizer.step()

        # Actor update
        actor_actions = self.actor(state_batch)
        actor_loss = -self.critic(torch.cat([state_batch, actor_actions], dim=1)).mean()

        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.actor.parameters(), 1.0)
        self.actor_optimizer.step()

        # Update target networks
        self.total_steps += 1
        if self.update_rate is not None:
            self._soft_update(self.target_actor, self.actor, self.tau)
            self._soft_update(self.target_critic, self.critic, self.tau)

        if self.update_steps is not None and self.total_steps % self.update_steps == 0:
            self._hard_update(self.target_actor, self.actor)
            self._hard_update(self.target_critic, self.critic)

        # Step learning rate schedulers
        if self.actor_scheduler:
            self.actor_scheduler.step()
        if self.critic_scheduler:
            self.critic_scheduler.step()

    def _soft_update(self, target: nn.Module, source: nn.Module, tau: float):
        for target_param, param in zip(target.parameters(), source.parameters()):
            target_param.data.copy_(tau * param.data + (1.0 - tau) * target_param.data)

    def _hard_update(self, target: nn.Module, source: nn.Module):
        target.load_state_dict(source.state_dict())

    def update_lr_scheduler(self):
        if self.actor_scheduler:
            self.actor_scheduler.step()
        if self.critic_scheduler:
            self.critic_scheduler.step()

    @staticmethod
    def generate_config() -> Dict[str, Any]:
        return {
            "state_dim": 24,
            "action_dim": 4,
            "action_bound": 1.0,
            "actor_hidden": (256, 256),
            "critic_hidden": (256, 256),
            "actor_lr": 1e-4,
            "critic_lr": 1e-3,
            "gamma": 0.99,
            "tau": 0.005,
            "update_steps": None,
            "update_rate": 0.005,
            "batch_size": 64,
            "replay_buffer_capacity": 1000000,
            "lr_step_size": 10000,
            "lr_gamma": 0.9,
            "actor_scheduler": True,
            "critic_scheduler": True,
        }

    @classmethod
    def init_from_config(cls, config: Dict[str, Any]) -> "DDPG":
        return cls(config)

    @staticmethod
    def reward_function(reward: float, discount: float, done: bool) -> float:
        return reward + (0 if done else discount)

    @staticmethod
    def action_transform_function(action: np.ndarray) -> Dict[str, np.ndarray]:
        return {"action": action}
```