import datasetUtils as dsu
import numpy as np
import matplotlib.pyplot as plt

yO, yC, yE, yA, yN = [], [], [], [], []
posts = []

posts, yO, yC, yE, yA, yN = dsu.readMyPersonality()

def plotDistribution(x_values, y_values):
    plt.figure()
    plt.scatter(x_values, y_values)
    plt.grid(True)
    plt.show()

xvals = np.linspace(0.0, 5.0, 101)

for trait_list in (yO, yC, yE, yA, yN):
    yvals = [0] * 101
    for v in trait_list:
        idx = int(v / 0.05 - 1)
        if idx < 0:
            idx = 0
        if idx > 100:
            idx = 100
        yvals[idx] += 1
    plotDistribution(xvals, yvals)