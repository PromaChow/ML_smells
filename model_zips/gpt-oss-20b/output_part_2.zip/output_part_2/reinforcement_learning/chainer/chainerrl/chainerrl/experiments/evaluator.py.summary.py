import os
import time
import logging
import datetime
import statistics
from typing import Any, List, Dict, Tuple, Optional
import multiprocessing

# Basic metrics tracked during evaluation
_basic_columns = (
    "steps",
    "episodes",
    "mean_return",
    "median_return",
    "std_return",
    "max_return",
    "min_return",
    "mean_length",
    "median_length",
    "std_length",
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)

def run_evaluation_episodes(
    agent: Any,
    env: Any,
    n_steps: Optional[int] = None,
    n_episodes: Optional[int] = None,
    max_episode_len: Optional[int] = None,
) -> List[float]:
    """Evaluate an agent in a single environment."""
    episode_returns = []
    steps_done = 0
    episodes_done = 0
    obs = env.reset()
    done = False
    ep_return = 0.0
    ep_len = 0
    while True:
        action = agent.act(obs)
        obs, reward, terminated, truncated, info = env.step(action)
        steps_done += 1
        ep_return += reward
        ep_len += 1
        done = terminated or truncated
        if done or (max_episode_len is not None and ep_len >= max_episode_len):
            episode_returns.append(ep_return)
            episodes_done += 1
            logging.info(
                f"Episode {episodes_done} finished: return={ep_return:.3f}, steps={ep_len}"
            )
            obs = env.reset()
            ep_return = 0.0
            ep_len = 0
        if (n_steps is not None and steps_done >= n_steps) or (
            n_episodes is not None and episodes_done >= n_episodes
        ):
            break
    return episode_returns

def batch_run_evaluation_episodes(
    agent: Any,
    env: Any,
    n_steps: Optional[int] = None,
    n_episodes: Optional[int] = None,
    max_episode_len: Optional[int] = None,
) -> List[float]:
    """Evaluate an agent in a vectorized environment."""
    n_envs = getattr(env, "n_envs", 1)
    episode_returns = [0.0] * n_envs
    episode_lengths = [0] * n_envs
    episodes_done = 0
    steps_done = 0
    obs = env.reset()
    dones = [False] * n_envs
    while True:
        actions = agent.batch_act(obs)
        obs, rewards, terminated, truncated, infos = env.step(actions)
        steps_done += n_envs
        for i in range(n_envs):
            episode_returns[i] += rewards[i]
            episode_lengths[i] += 1
            done = terminated[i] or truncated[i]
            if done or (max_episode_len is not None and episode_lengths[i] >= max_episode_len):
                episodes_done += 1
                logging.info(
                    f"Env {i} episode {episodes_done} finished: return={episode_returns[i]:.3f}, steps={episode_lengths[i]}"
                )
                episode_returns[i] = 0.0
                episode_lengths[i] = 0
        if (n_steps is not None and steps_done >= n_steps) or (
            n_episodes is not None and episodes_done >= n_episodes
        ):
            break
    # Flatten returns for all episodes finished
    return [ret for ret in episode_returns if ret != 0.0]

def eval_performance(
    agent: Any,
    env: Any,
    n_steps: Optional[int] = None,
    n_episodes: Optional[int] = None,
    max_episode_len: Optional[int] = None,
) -> Dict[str, float]:
    """Run evaluation and compute statistics."""
    if hasattr(env, "n_envs") and env.n_envs > 1:
        returns = batch_run_evaluation_episodes(
            agent, env, n_steps, n_episodes, max_episode_len
        )
    else:
        returns = run_evaluation_episodes(
            agent, env, n_steps, n_episodes, max_episode_len
        )
    stats = {}
    stats["mean_return"] = statistics.mean(returns) if returns else 0.0
    stats["median_return"] = statistics.median(returns) if returns else 0.0
    stats["std_return"] = statistics.stdev(returns) if len(returns) > 1 else 0.0
    stats["max_return"] = max(returns) if returns else 0.0
    stats["min_return"] = min(returns) if returns else 0.0
    # Placeholder for episode lengths; omitted in this simplified implementation
    stats["mean_length"] = 0.0
    stats["median_length"] = 0.0
    stats["std_length"] = 0.0
    stats["max_length"] = 0.0
    stats["min_length"] = 0.0
    stats["steps"] = n_steps or 0
    stats["episodes"] = len(returns)
    return stats

def record_stats(stats: Dict[str, float], path: str = "scores.txt") -> None:
    """Append evaluation statistics to a tab-separated file."""
    header_written = False
    if not os.path.exists(path):
        header_written = True
    with open(path, "a", encoding="utf-8") as f:
        if header_written:
            f.write("\t".join(_basic_columns) + "\n")
        row = [str(stats.get(col, "")) for col in _basic_columns]
        f.write("\t".join(row) + "\n")

def save_agent(agent: Any, directory: str = ".", suffix: str = "") -> None:
    """Save agent model to disk with a timestamp."""
    os.makedirs(directory, exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"agent_{timestamp}{suffix}.pth"
    path = os.path.join(directory, filename)
    # Assuming agent has a save method that accepts a filepath
    agent.save(path)
    logging.info(f"Agent model saved to {path}")

class Evaluator:
    def __init__(
        self,
        agent: Any,
        env: Any,
        n_steps: int = 1000,
        n_episodes: int = 10,
        eval_interval: int = 5000,
        out_dir: str = ".",
    ) -> None:
        self.agent = agent
        self.env = env
        self.n_steps = n_steps
        self.n_episodes = n_episodes
        self.eval_interval = eval_interval
        self.out_dir = out_dir
        self.best_mean_return = float("-inf")
        self.last_eval_step = -eval_interval
        header_path = os.path.join(self.out_dir, "scores.txt")
        if not os.path.exists(header_path):
            with open(header_path, "w", encoding="utf-8") as f:
                f.write("\t".join(_basic_columns) + "\n")

    def evaluate_and_update_max_score(self, current_step: int) -> None:
        stats = eval_performance(
            self.agent,
            self.env,
            n_steps=self.n_steps,
            n_episodes=self.n_episodes,
        )
        record_stats(stats, os.path.join(self.out_dir, "scores.txt"))
        if stats["mean_return"] > self.best_mean_return:
            self.best_mean_return = stats["mean_return"]
            save_agent(self.agent, self.out_dir, suffix="_best")
        self.last_eval_step = current_step

    def evaluate_if_necessary(self, current_step: int) -> None:
        if current_step - self.last_eval_step >= self.eval_interval:
            self.evaluate_and_update_max_score(current_step)

class AsyncEvaluator:
    def __init__(
        self,
        agent: Any,
        env: Any,
        n_steps: int = 1000,
        n_episodes: int = 10,
        eval_interval: int = 5000,
        out_dir: str = ".",
    ) -> None:
        self.agent = agent
        self.env = env
        self.n_steps = n_steps
        self.n_episodes = n_episodes
        self.eval_interval = eval_interval
        self.out_dir = out_dir
        self.prev_eval_t = multiprocessing.Value("i", -eval_interval)
        self.max_score = multiprocessing.Value("d", float("-inf"))
        self.wrote_header = multiprocessing.Value("i", 0)
        header_path = os.path.join(self.out_dir, "scores.txt")
        if not os.path.exists(header_path):
            with open(header_path, "w", encoding="utf-8") as f:
                f.write("\t".join(_basic_columns) + "\n")

    def write_header(self) -> None:
        with self.wrote_header.get_lock():
            if self.wrote_header.value == 0:
                header_path = os.path.join(self.out_dir, "scores.txt")
                with open(header_path, "w", encoding="utf-8") as f:
                    f.write("\t".join(_basic_columns) + "\n")
                self.wrote_header.value = 1

    def evaluate_and_update_max_score(self, current_step: int) -> None:
        stats = eval_performance(
            self.agent,
            self.env,
            n_steps=self.n_steps,
            n_episodes=self.n_episodes,
        )
        record_stats(stats, os.path.join(self.out_dir, "scores.txt"))
        with self.max_score.get_lock():
            if stats["mean_return"] > self.max_score.value:
                self.max_score.value = stats["mean_return"]
                save_agent(self.agent, self.out_dir, suffix="_best_async")
        with self.prev_eval_t.get_lock():
            self.prev_eval_t.value = current_step

    def evaluate_if_necessary(self, current_step: int) -> None:
        with self.prev_eval_t.get_lock():
            last = self.prev_eval_t.value
        if current_step - last >= self.eval_interval:
            self.write_header()
            self.evaluate_and_update_max_score(current_step)