import abc
import random
from typing import List, Tuple

import torch
import torch.nn.functional as F


class Bandit(abc.ABC):
    @abc.abstractmethod
    def step(self, action: int) -> Tuple[torch.Tensor, float]:
        """Execute an action and return (new_context, reward)."""

    @abc.abstractmethod
    def reset(self) -> torch.Tensor:
        """Reset the bandit and return the initial context."""


class BanditAgent(abc.ABC):
    @abc.abstractmethod
    def select_action(self, context: torch.Tensor) -> int:
        """Select an action given a context."""


class MultiArmedBandit(Bandit):
    def __init__(self, bandits: int, arms: int, context_type: str = "tensor"):
        self.bandits = bandits
        self.arms = arms
        if context_type not in ("int", "tensor"):
            raise ValueError("context_type must be 'int' or 'tensor'")
        self.context_type = context_type
        self.n_actions = arms
        self.context_dim = bandits

        # Reward model: each bandit has a mean reward per arm
        self._means = torch.rand(bandits, arms)
        self._std = 0.1 * torch.ones(bandits, arms)

        # Precompute optimal reward per bandit
        self._optimal_rewards = self._means.max(dim=1).values

        self._reset_metrics()
        self._reset_bandit()

    def _reset_metrics(self):
        self.reward_hist: List[float] = []
        self.regret_hist: List[float] = []
        self.cum_reward_hist: List[float] = []
        self.cum_regret_hist: List[float] = []
        self.cum_reward: float = 0.0
        self.cum_regret: float = 0.0

    def _reset_bandit(self):
        self.curr_bandit = random.randint(0, self.bandits - 1)
        if self.context_type == "tensor":
            one_hot = torch.zeros(self.context_dim)
            one_hot[self.curr_bandit] = 1.0
            self.curr_context = one_hot
        else:
            self.curr_context = self.curr_bandit

    def reset(self) -> torch.Tensor:
        self._reset_metrics()
        self._reset_bandit()
        if self.context_type == "tensor":
            return self.curr_context.clone()
        else:
            return torch.tensor(self.curr_context, dtype=torch.long)

    def _compute_reward(self, action: int) -> Tuple[float, float]:
        mean = self._means[self.curr_bandit, action]
        std = self._std[self.curr_bandit, action]
        reward = random.gauss(mean.item(), std.item())
        max_reward = self._optimal_rewards[self.curr_bandit].item()
        return reward, max_reward

    def step(self, action: int) -> Tuple[torch.Tensor, float]:
        reward, max_reward = self._compute_reward(action)
        regret = max_reward - reward

        self.cum_reward += reward
        self.cum_regret += regret

        self.reward_hist.append(reward)
        self.regret_hist.append(regret)
        self.cum_reward_hist.append(self.cum_reward)
        self.cum_regret_hist.append(self.cum_regret)

        self._reset_bandit()

        if self.context_type == "tensor":
            return self.curr_context.clone(), reward
        else:
            return torch.tensor(self.curr_context, dtype=torch.long), reward
