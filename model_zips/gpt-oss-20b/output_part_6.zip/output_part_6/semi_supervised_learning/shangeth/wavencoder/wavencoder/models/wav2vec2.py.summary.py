import os
import urllib.request
import warnings
from pathlib import Path

import torch
from fairseq import checkpoint_utils
from tqdm import tqdm


class Wav2Vec2:
    model_links = {
        "base": "https://dl.fbaipublicfiles.com/fairseq/wav2vec/wav2vec_small.pt",
        "large": "https://dl.fbaipublicfiles.com/fairseq/wav2vec/wav2vec_large.pt",
        "xlsr53": "https://dl.fbaipublicfiles.com/fairseq/wav2vec/xlsr53.pt",
    }

    def __init__(
        self,
        model_type: str = "base",
        pretrained: bool = True,
        pretrained_path: str | None = None,
        device: str = "cpu",
        custom_model_link: str | None = None,
    ):
        self.device = torch.device(device)
        if not pretrained:
            warnings.warn(
                "Only pretrained models are supported. "
                "Please download the weights manually if you need a custom model."
            )
            raise ValueError("pretrained=False is not supported.")

        if pretrained_path:
            if not os.path.isfile(pretrained_path):
                raise FileNotFoundError(f"Specified pretrained_path not found: {pretrained_path}")
            model_file = pretrained_path
        else:
            model_file = self._get_local_model_file(model_type, custom_model_link)

        models, _, _ = checkpoint_utils.load_model_ensemble_and_task([model_file])
        self.model = models[0].to(self.device)
        self.model.eval()

    def _get_local_model_file(self, model_type: str, custom_link: str | None) -> str:
        if custom_link:
            url = custom_link
        else:
            if model_type not in self.model_links:
                raise ValueError(f"Unsupported model_type: {model_type}")
            url = self.model_links[model_type]

        filename = Path(url).name
        local_path = os.path.join(os.getcwd(), filename)

        if not os.path.isfile(local_path):
            self._download_with_progress(url, local_path)

        return local_path

    @staticmethod
    def _download_with_progress(url: str, dest_path: str):
        def _reporthook(blocknum, blocksize, totalsize):
            if blocknum == 0:
                tqdm_bar.total = totalsize
            tqdm_bar.update(blocksize)

        tqdm_bar = tqdm(unit="B", unit_scale=True, miniters=1, desc="Downloading")
        try:
            urllib.request.urlretrieve(url, dest_path, _reporthook)
        finally:
            tqdm_bar.close()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        with torch.no_grad():
            x = x.squeeze(1)
            features = self.model.extract_features(x, features_only=True)
            return features["x"]


if __name__ == "__main__":
    # Example usage
    wav = torch.randn(1, 1, 16000)  # 1-second dummy audio at 16kHz
    model = Wav2Vec2(model_type="base", pretrained=True, device="cpu")
    out = model.forward(wav)
    print(out.shape)