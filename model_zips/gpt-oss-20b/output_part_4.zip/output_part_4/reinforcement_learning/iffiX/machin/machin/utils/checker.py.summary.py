import torch
import inspect
from collections import Counter
from torch.utils.tensorboard import SummaryWriter

class CheckError(Exception):
    """Raised when a tensor check fails."""
    pass


def check_shape(tensor, required_shape, name=""):
    if tuple(tensor.shape) != required_shape:
        raise CheckError(f"Shape mismatch for {name}: expected {required_shape}, got {tensor.shape}")


def check_nan(tensor, name=""):
    if torch.isnan(tensor).any():
        raise CheckError(f"NaN detected in {name}")


def _add_input_check_hook(sub_module, counter, interval, writer, hooks, model, module_name):
    sig = inspect.signature(sub_module.forward)
    param_names = list(sig.parameters.keys())

    def hook(module, inputs):
        if counter['count'] % interval == 0:
            for name, inp in zip(param_names, inputs):
                if isinstance(inp, torch.Tensor):
                    for chk in hooks:
                        chk(inp, name, writer, counter, module_name)

    handle = sub_module.register_forward_pre_hook(hook)
    return handle


def _add_output_check_hook(sub_module, counter, interval, writer, hooks, model, module_name):
    output_names = getattr(sub_module, "_output_names", None)

    def hook(module, inputs, output):
        if counter['count'] % interval == 0:
            if output_names:
                outs = output if isinstance(output, tuple) else (output,)
                for name, out in zip(output_names, outs):
                    if isinstance(out, torch.Tensor):
                        for chk in hooks:
                            chk(out, name, writer, counter, module_name)
            else:
                if isinstance(output, tuple):
                    for idx, out in enumerate(output):
                        if isinstance(out, torch.Tensor):
                            for chk in hooks:
                                chk(out, f"{idx}", writer, counter, module_name)
                else:
                    if isinstance(output, torch.Tensor):
                        for chk in hooks:
                            chk(output, "output", writer, counter, module_name)

    handle = sub_module.register_forward_hook(hook)
    return handle


def _add_param_check_hook(sub_module, counter, interval, writer, hooks, model, module_name):
    handles = []

    for name, param in sub_module.named_parameters(recurse=False):
        def grad_hook(grad, param=param, name=name):
            if counter['count'] % interval == 0:
                for chk in hooks:
                    chk(param, name, writer, counter, module_name)
        handles.append(param.register_hook(grad_hook))

    return handles


def i_chk_nan(tensor, name, writer, counter, module_name):
    if torch.isnan(tensor).any():
        raise CheckError(f"NaN detected in input {module_name}.{name}")


def i_chk_range(tensor, name, writer, counter, module_name):
    tag_base = f"{module_name}/input/{name}"
    writer.add_scalar(f"{tag_base}/min", tensor.min().item(), counter['count'])
    writer.add_scalar(f"{tag_base}/max", tensor.max().item(), counter['count'])
    writer.add_scalar(f"{tag_base}/mean", tensor.mean().item(), counter['count'])


def o_chk_nan(tensor, name, writer, counter, module_name):
    if torch.isnan(tensor).any():
        raise CheckError(f"NaN detected in output {module_name}.{name}")


def o_chk_range(tensor, name, writer, counter, module_name):
    tag_base = f"{module_name}/output/{name}"
    writer.add_scalar(f"{tag_base}/min", tensor.min().item(), counter['count'])
    writer.add_scalar(f"{tag_base}/max", tensor.max().item(), counter['count'])
    writer.add_scalar(f"{tag_base}/mean", tensor.mean().item(), counter['count'])


def p_chk_nan(tensor, name, writer, counter, module_name):
    if torch.isnan(tensor).any():
        raise CheckError(f"NaN detected in parameter {module_name}.{name}")


def p_chk_range(tensor, name, writer, counter, module_name):
    tag_base = f"{module_name}/param/{name}"
    writer.add_scalar(f"{tag_base}/min", tensor.min().item(), counter['count'])
    writer.add_scalar(f"{tag_base}/max", tensor.max().item(), counter['count'])
    writer.add_scalar(f"{tag_base}/mean", tensor.mean().item(), counter['count'])
    writer.add_histogram(f"{tag_base}/hist", tensor, counter['count'])


def mark_as_atom_module(module):
    setattr(module, "_is_atom", True)
    return module


def mark_module_output(module, output_names):
    setattr(module, "_output_names", output_names)
    return module


def check_model(model,
                writer: SummaryWriter,
                input_interval: int = 1,
                output_interval: int = 1,
                param_interval: int = 1):
    forward_counter = Counter()
    backward_counter = Counter()
    handles = []

    # Hook to count forward passes
    def pre_forward_hook(module):
        forward_counter['count'] += 1

    handles.append(model.register_forward_pre_hook(pre_forward_hook))

    # Hook to count backward passes
    for param in model.parameters():
        def grad_counter_hook(grad, counter=backward_counter):
            counter['count'] += 1
        handles.append(param.register_hook(grad_counter_hook))

    for name, sub in model.named_modules():
        if name == "":
            continue
        is_atom = getattr(sub, "_is_atom", False)
        is_leaf = len(list(sub.children())) == 0
        if not is_leaf and not is_atom:
            continue

        handles.append(
            _add_input_check_hook(
                sub, forward_counter, input_interval, writer,
                [i_chk_nan, i_chk_range], model, name
            )
        )
        handles.append(
            _add_output_check_hook(
                sub, forward_counter, output_interval, writer,
                [o_chk_nan, o_chk_range], model, name
            )
        )
        handles.extend(
            _add_param_check_hook(
                sub, backward_counter, param_interval, writer,
                [p_chk_nan, p_chk_range], model, name
            )
        )

    def cancel():
        for h in handles:
            if isinstance(h, list):
                for sub_h in h:
                    sub_h.remove()
            else:
                h.remove()

    return cancel
