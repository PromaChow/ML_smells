import numpy as np

# 1. Define Original Feature Names
feature_name_celeba_org = [
    '5_o_Clock_Shadow', 'Arched_Eyebrows', 'Attractive', 'Bags_Under_Eyes',
    'Bald', 'Bangs', 'Big_Lips', 'Big_Nose', 'Black_Hair', 'Blond_Hair',
    'Blurry', 'Brown_Hair', 'Bushy_Eyebrows', 'Chubby', 'Double_Chin',
    'Eyeglasses', 'Goatee', 'Gray_Hair', 'Heavy_Makeup', 'High_Cheekbones',
    'Male', 'Mouth_Slightly_Open', 'Mustache', 'Nose_Raised', 'Pale_Skin',
    'Pointy_Nose', 'Receding_Hairline', 'Rosy_Cheeks', 'Sideburns',
    'Smiling', 'Straight_Hair', 'Wavy_Hair', 'Wearing_Earrings',
    'Wearing_Hat', 'Wearing_Lipstick', 'Wearing_Necklace',
    'Wearing_Necktie', 'Young'
]

# 2. Rename Features
feature_name_celeba_rename = [
    'Shadow', 'Eyebrows', 'Attractive', 'Under_Eyes',
    'Hair_Bald', 'Hair_Bangs', 'Lips_Big', 'Nose_Big', 'Hair_Black', 'Hair_Blond',
    'Image_Blurry', 'Hair_Brown', 'Eyebrows_Bushy', 'Body_Chubby', 'Body_Thick',
    'Eyeglasses', 'Facial_Goatee', 'Hair_Gray', 'Makeup_Heavy', 'Cheekbones_High',
    'Gender_Male', 'Mouth_Open', 'Facial_Mustache', 'Nose_Raised', 'Skin_Pale',
    'Nose_Pointy', 'Hair_Receding', 'Cheeks_Rosy', 'Body_Sideburns',
    'Mouth_Smiling', 'Hair_Straight', 'Hair_Wavy', 'Accessory_Earrings',
    'Accessory_Hat', 'Accessory_Lipstick', 'Accessory_Necklace',
    'Accessory_Necktie', 'Age_Young'
]

# 3. Create Feature Reversal Indicator
# 1 indicates normal, -1 indicates reversed (e.g., age)
feature_reverse = np.ones(40, dtype=int)
feature_reverse[39] = -1  # Age_Young reversed

# 4. Group Features into Layout
feature_celeba_layout = [
    [0, 1, 2, 3],                     # Facial attributes
    [4, 5, 6, 7, 8, 9],                # Hair attributes
    [10, 11, 12, 13, 14],              # Physical traits
    [15, 16, 17, 18, 19],              # Makeup and expressions
    [20, 21, 22, 23, 24],              # Gender and facial features
    [25, 26, 27, 28, 29, 30, 31],      # Additional attributes
    [32, 33, 34, 35, 36, 37, 38, 39]   # Accessories and age
]