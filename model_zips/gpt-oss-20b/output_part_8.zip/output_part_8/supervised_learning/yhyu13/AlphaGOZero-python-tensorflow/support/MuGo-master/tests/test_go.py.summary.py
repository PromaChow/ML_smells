import unittest
import numpy as np

# Constants
EMPTY = 0
BLACK = 1
WHITE = 2
KOMI = 6.5

# Helper coordinate parsing
def parse_kgs_coords(coord, size=9):
    col_char, row_str = coord[0], coord[1:]
    col = ord(col_char.upper()) - ord('A')
    if col >= 8:  # skip 'I'
        col -= 1
    row = int(row_str) - 1
    return (row, col)

def parse_sgf_coords(coord, size=9):
    if len(coord) < 2:
        raise ValueError(f"Invalid SGF coordinate: {coord}")
    col = ord(coord[0]) - ord('a')
    row = int(coord[1:]) - 1
    return (row, col)

def pc_set(coords, size=9):
    return [parse_kgs_coords(c, size) for c in coords]

class Group:
    def __init__(self, color):
        self.color = color
        self.stones = set()
        self.liberties = set()

class Board:
    def __init__(self, size=9):
        self.size = size
        self.board = np.zeros((size, size), dtype=int)
        self.groups = {}  # root -> Group
        self.parent = {}  # root lookup for union-find
        self.ko = None
        self.turn = BLACK
        self.move_count = 0
        self.recent = []

    def _index(self, r, c):
        return r * self.size + c

    def _find(self, idx):
        # Path compression
        path = []
        while self.parent[idx] != idx:
            path.append(idx)
            idx = self.parent[idx]
        for p in path:
            self.parent[p] = idx
        return idx

    def _union(self, idx1, idx2):
        r1, r2 = self._find(idx1), self._find(idx2)
        if r1 == r2:
            return r1
        group1, group2 = self.groups[r1], self.groups[r2]
        if len(group1.stones) < len(group2.stones):
            r1, r2 = r2, r1
            group1, group2 = group2, group1
        self.parent[r2] = r1
        group1.stones.update(group2.stones)
        group1.liberties.update(group2.liberties)
        del self.groups[r2]
        return r1

    def _neighbors(self, r, c):
        for dr, dc in [(-1,0),(1,0),(0,-1),(0,1)]:
            nr, nc = r+dr, c+dc
            if 0 <= nr < self.size and 0 <= nc < self.size:
                yield nr, nc

    def _init_group(self, r, c, color):
        idx = self._index(r, c)
        self.parent[idx] = idx
        group = Group(color)
        group.stones.add((r,c))
        for nr, nc in self._neighbors(r, c):
            if self.board[nr,nc] == EMPTY:
                group.liberties.add((nr,nc))
        self.groups[idx] = group

    def load_from_string(self, board_str):
        lines = board_str.strip().splitlines()
        for r, line in enumerate(lines):
            for c, ch in enumerate(line.strip()):
                if ch == 'X':
                    self.board[r,c] = BLACK
                elif ch == 'O':
                    self.board[r,c] = WHITE

    def _remove_group(self, root):
        group = self.groups[root]
        for r, c in group.stones:
            self.board[r,c] = EMPTY
            # Update liberties of neighbors
            for nr, nc in self._neighbors(r, c):
                if self.board[nr,nc] != EMPTY:
                    nidx = self._index(nr, nc)
                    nroot = self._find(nidx)
                    if self.groups[nroot].color == self.turn:
                        self.groups[nroot].liberties.add((r,c))
                else:
                    pass

        # Remove group
        for r, c in group.stones:
            idx = self._index(r,c)
            del self.parent[idx]
        del self.groups[root]

    def play(self, r, c):
        if self.board[r,c] != EMPTY:
            raise ValueError("Point occupied")
        # Place stone tentatively
        self.board[r,c] = self.turn
        idx = self._index(r,c)
        self.parent[idx] = idx
        self.groups[idx] = Group(self.turn)
        self.groups[idx].stones.add((r,c))
        for nr, nc in self._neighbors(r, c):
            if self.board[nr,nc] == EMPTY:
                self.groups[idx].liberties.add((nr,nc))
        # Merge with same color neighbors
        for nr, nc in self._neighbors(r, c):
            if self.board[nr,nc] == self.turn:
                nidx = self._index(nr, nc)
                self._union(idx, nidx)
        # Capture opponent groups
        captured = []
        for nr, nc in self._neighbors(r, c):
            if self.board[nr,nc] == 3 - self.turn:
                nidx = self._index(nr, nc)
                nroot = self._find(nidx)
                self.groups[nroot].liberties.discard((r,c))
                if not self.groups[nroot].liberties:
                    captured.append(nroot)
        for root in captured:
            self._remove_group(root)
        # Suicide check
        root = self._find(idx)
        if not self.groups[root].liberties and not captured:
            self.board[r,c] = EMPTY
            del self.parent[idx]
            del self.groups[root]
            raise ValueError("Suicide move")
        # Ko detection
        if len(captured) == 1:
            cap_root = captured[0]
            cap_group = self.groups.get(cap_root, None)
            if cap_group and len(cap_group.stones) == 1:
                self.ko = cap_group.stones.pop()
            else:
                self.ko = None
        else:
            self.ko = None
        # Record move
        self.recent.append((self.turn, (r,c)))
        self.move_count += 1
        self.turn = 3 - self.turn

    def pass_turn(self):
        self.move_count += 1
        self.recent.append((self.turn, None))
        self.turn = 3 - self.turn
        self.ko = None

    def liberties_at(self, r, c):
        idx = self._index(r,c)
        root = self._find(idx)
        return len(self.groups[root].liberties)

    def score(self):
        # Simple area scoring: count stones + territories
        visited = np.zeros_like(self.board, dtype=bool)
        black_area = 0
        white_area = 0
        for r in range(self.size):
            for c in range(self.size):
                if self.board[r,c] == BLACK:
                    black_area += 1
                elif self.board[r,c] == WHITE:
                    white_area += 1
                elif not visited[r,c]:
                    # Flood fill empty area
                    stack = [(r,c)]
                    visited[r,c] = True
                    area = [(r,c)]
                    owners = set()
                    while stack:
                        cr, cc = stack.pop()
                        for nr, nc in self._neighbors(cr, cc):
                            if self.board[nr,nc] == EMPTY and not visited[nr,nc]:
                                visited[nr,nc] = True
                                stack.append((nr,nc))
                                area.append((nr,nc))
                            elif self.board[nr,nc] in (BLACK, WHITE):
                                owners.add(self.board[nr,nc])
                    if len(owners) == 1:
                        if BLACK in owners:
                            black_area += len(area)
                        elif WHITE in owners:
                            white_area += len(area)
        black_score = black_area
        white_score = white_area + KOMI
        return black_score, white_score

class TestGoEngine(unittest.TestCase):
    def setUp(self):
        self.size = 9
        self.board = Board(self.size)

    def test_board_initialization(self):
        self.assertTrue(np.array_equal(self.board.board, np.zeros((self.size,self.size))))

    def test_parse_kgs(self):
        self.assertEqual(parse_kgs_coords("A1"), (0,0))
        self.assertEqual(parse_kgs_coords("J1"), (0,8))  # J is after I

    def test_parse_sgf(self):
        self.assertEqual(parse_sgf_coords("a1"), (0,0))
        self.assertEqual(parse_sgf_coords("i9"), (8,8))

    def test_load_from_string(self):
        board_str = """
        .........
        ..X......
        ....O....
        .........
        .........
        .........
        .........
        .........
        .........
        """
        self.board.load_from_string(board_str)
        self.assertEqual(self.board.board[1,2], BLACK)
        self.assertEqual(self.board.board[2,4], WHITE)

    def test_liberties_single(self):
        r,c = 0,0
        self.board.play(r,c)
        self.assertEqual(self.board.liberties_at(r,c), 2)

    def test_group_merge(self):
        self.board.play(0,0)  # black
        self.board.play(1,1)  # white
        self.board.play(0,1)  # black
        self.assertTrue((0,0) in self.board.groups[self.board._find(self.board._index(0,0))].stones)
        self.assertTrue((0,1) in self.board.groups[self.board._find(self.board._index(0,1))].stones)

    def test_capture(self):
        # Set up a white group with one liberty
        self.board.play(0,0)  # B
        self.board.play(1,0)  # W
        self.board.play(0,1)  # B
        self.board.play(1,1)  # W
        self.board.play(0,2)  # B
        self.board.play(1,2)  # B capturing
        self.assertEqual(self.board.board[1,0], EMPTY)
        self.assertEqual(self.board.board[1,1], EMPTY)

    def test_ko(self):
        # Classic ko situation
        self.board.play(0,0)  # B
        self.board.play(1,0)  # W
        self.board.play(0,1)  # B
        self.board.play(1,1)  # W
        self.board.play(0,2)  # B
        self.board.play(1,2)  # B
        self.board.play(2,1)  # B
        self.board.play(1,1)  # W captures, ko point at (1,0)
        self.assertEqual(self.board.ko, (1,0))
        with self.assertRaises(ValueError):
            self.board.play(1,0)  # illegal ko recapture

    def test_pass_and_turn(self):
        self.board.play(0,0)  # B
        self.board.pass_turn()  # W passes
        self.assertEqual(self.board.turn, BLACK)
        self.assertEqual(self.board.move_count, 2)

    def test_scoring(self):
        # Simple scoring: all stones counted
        self.board.play(0,0)  # B
        self.board.play(1,1)  # W
        self.board.play(0,1)  # B
        black_score, white_score = self.board.score()
        self.assertEqual(black_score, 2)
        self.assertAlmostEqual(white_score, 1+KOMI)

if __name__ == "__main__":
    unittest.main()
