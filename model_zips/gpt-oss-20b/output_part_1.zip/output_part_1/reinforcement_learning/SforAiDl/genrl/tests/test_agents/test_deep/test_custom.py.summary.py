import os
import shutil

import gym
from stable_baselines3 import VPG, PPO
from stable_baselines3.common.policies import MlpPolicy, ActorCriticPolicy
from stable_baselines3.common.vec_env import DummyVecEnv


class custom_policy(MlpPolicy):
    def __init__(self, *args, **kwargs):
        policy_kwargs = kwargs.pop("policy_kwargs", {})
        policy_kwargs.setdefault("net_arch", [64, 64])
        super().__init__(*args, policy_kwargs=policy_kwargs, **kwargs)


class custom_actorcritic(ActorCriticPolicy):
    def __init__(self, *args, **kwargs):
        policy_kwargs = kwargs.pop("policy_kwargs", {})
        policy_kwargs.setdefault("net_arch", [64, 64])
        super().__init__(*args, policy_kwargs=policy_kwargs, **kwargs)


def test_vpg():
    env = DummyVecEnv([lambda: gym.make("CartPole-v0")])
    model = VPG(
        policy=custom_policy,
        env=env,
        verbose=0,
        tensorboard_log="./logs",
    )
    model.learn(total_timesteps=1000)
    env.close()


def test_ppo():
    env = DummyVecEnv([lambda: gym.make("CartPole-v0")])
    model = PPO(
        policy=custom_actorcritic,
        env=env,
        verbose=0,
        tensorboard_log="./logs",
    )
    model.learn(total_timesteps=1000)
    env.close()


if __name__ == "__main__":
    test_vpg()
    test_ppo()
    shutil.rmtree("./logs")
