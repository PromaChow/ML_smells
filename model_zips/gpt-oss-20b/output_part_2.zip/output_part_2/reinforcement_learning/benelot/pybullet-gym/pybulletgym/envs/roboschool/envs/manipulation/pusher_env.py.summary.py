import numpy as np
import pybullet as p

class PusherBulletEnv(BaseBulletEnv):
    def __init__(self, *args, **kwargs):
        self.robot = Pusher()
        super().__init__(self.robot, *args, **kwargs)

    def create_single_player_scene(self):
        self.scene = SingleRobotEmptyScene(
            robot=self.robot,
            gravity=9.81,
            timestep=0.002,
            frame_skip=5
        )

    def step(self, action):
        self.robot.apply_action(action)
        self.scene.global_step()
        state = self.robot.calc_state()
        to_target_vec = state.get("to_target_vec", np.zeros(3))
        potential = self.calc_potential(to_target_vec)
        velocities = self.robot.get_joint_velocities()
        action_abs = np.abs(action)
        action_product = np.sum(action_abs * np.abs(velocities))
        action_sum = np.sum(action_abs)
        electricity_cost = -0.10 * action_product - 0.01 * action_sum
        stuck_penalty = self._stuck_joint_penalty()
        reward = potential + electricity_cost + stuck_penalty
        self.HUD(state, action, reward)
        return state, reward, False, {}

    def calc_potential(self, to_target_vec):
        return -100.0 * np.linalg.norm(to_target_vec)

    def _stuck_joint_penalty(self):
        penalty = 0.0
        positions = self.robot.get_joint_positions()
        limits = self.robot.get_joint_limits()
        for idx, (pos, (min_limit, max_limit)) in enumerate(zip(positions, limits)):
            if pos <= min_limit * 1.01 or pos >= max_limit * 0.99:
                penalty -= 0.1
        return penalty

    def HUD(self, state, action, reward):
        # Placeholder for HUD display logic
        pass

    def camera_adjust(self):
        fingertip_pos = self.robot.get_fingertip_position()
        focal = np.array(fingertip_pos) * 0.5
        dist = 1.0
        yaw = 0
        pitch = -30
        p.resetDebugVisualizerCamera(dist, yaw, pitch, focal.tolist())