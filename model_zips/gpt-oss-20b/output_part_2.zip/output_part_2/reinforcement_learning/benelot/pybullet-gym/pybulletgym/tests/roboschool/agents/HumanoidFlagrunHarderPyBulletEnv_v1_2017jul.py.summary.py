import numpy as np

def relu(x: np.ndarray) -> np.ndarray:
    return np.maximum(0, x)

def softmax(x: np.ndarray) -> np.ndarray:
    exp_x = np.exp(x - np.max(x, axis=1, keepdims=True))
    return exp_x / np.sum(exp_x, axis=1, keepdims=True)

def forward_pass(
    X: np.ndarray,
    weights_dense1_w: np.ndarray,
    weights_dense1_b: np.ndarray,
    weights_dense2_w: np.ndarray,
    weights_dense2_b: np.ndarray,
    weights_final_w: np.ndarray,
    weights_final_b: np.ndarray
) -> np.ndarray:
    """
    Forward pass through a 3-layer dense neural network.

    Parameters
    ----------
    X : np.ndarray
        Input tensor of shape (batch_size, 128).
    weights_dense1_w : np.ndarray
        Weights for the first dense layer, shape (128, 64).
    weights_dense1_b : np.ndarray
        Biases for the first dense layer, shape (64,).
    weights_dense2_w : np.ndarray
        Weights for the second dense layer, shape (64, 64).
    weights_dense2_b : np.ndarray
        Biases for the second dense layer, shape (64,).
    weights_final_w : np.ndarray
        Weights for the final dense layer, shape (64, 37).
    weights_final_b : np.ndarray
        Biases for the final dense layer, shape (37,).

    Returns
    -------
    np.ndarray
        Class probabilities of shape (batch_size, 37).
    """
    # First dense layer
    z1 = X @ weights_dense1_w + weights_dense1_b
    a1 = relu(z1)

    # Second dense layer
    z2 = a1 @ weights_dense2_w + weights_dense2_b
    a2 = relu(z2)

    # Final dense layer
    z3 = a2 @ weights_final_w + weights_final_b
    y = softmax(z3)

    return y

# Example usage (weights should be replaced with actual trained parameters)
if __name__ == "__main__":
    batch_size = 4
    X = np.random.randn(batch_size, 128)

    weights_dense1_w = np.random.randn(128, 64)
    weights_dense1_b = np.random.randn(64)
    weights_dense2_w = np.random.randn(64, 64)
    weights_dense2_b = np.random.randn(64)
    weights_final_w = np.random.randn(64, 37)
    weights_final_b = np.random.randn(37)

    probs = forward_pass(
        X,
        weights_dense1_w,
        weights_dense1_b,
        weights_dense2_w,
        weights_dense2_b,
        weights_final_w,
        weights_final_b
    )

    print(probs)