import os
import sys
import io
import pickle
import logging
import datetime
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from collections import OrderedDict
from moviepy.editor import TextClip
from typing import List, Tuple, Optional, Union, Dict, Any, Iterable

# ----------------------------------------------------------------------
# Legacy pickle handling
# ----------------------------------------------------------------------
def load_pkl(filename: str) -> Any:
    """Load a pickled object with legacy latin1 encoding."""
    with open(filename, "rb") as f:
        return pickle.load(f, encoding="latin1", errors="ignore")

def save_pkl(obj: Any, filename: str) -> None:
    """Save an object to a pickle file with highest protocol."""
    with open(filename, "wb") as f:
        pickle.dump(obj, f, protocol=pickle.HIGHEST_PROTOCOL)

# ----------------------------------------------------------------------
# Image utilities
# ----------------------------------------------------------------------
def adjust_dynamic_range(
    data: np.ndarray,
    drange_in: Tuple[float, float],
    drange_out: Tuple[float, float],
) -> np.ndarray:
    """Map data from drange_in to drange_out."""
    data = data.astype(np.float32)
    data = (data - drange_in[0]) / (drange_in[1] - drange_in[0])
    data = data * (drange_out[1] - drange_out[0]) + drange_out[0]
    return data

def create_image_grid(
    images: List[np.ndarray], grid_size: Optional[Tuple[int, int]] = None
) -> np.ndarray:
    """Arrange a list of images into a grid."""
    n = len(images)
    if grid_size is None:
        side = int(np.ceil(np.sqrt(n)))
        grid_size = (side, side)
    rows, cols = grid_size
    assert rows * cols >= n, "Grid size too small for number of images"
    # Determine image shape
    h, w = images[0].shape[:2]
    grid = np.zeros((rows * h, cols * w, 3), dtype=images[0].dtype)
    for idx, img in enumerate(images):
        r = idx // cols
        c = idx % cols
        grid[r * h : (r + 1) * h, c * w : (c + 1) * w] = img
    return grid

def convert_to_pil_image(image: np.ndarray, drange: Tuple[float, float]) -> Image.Image:
    """Convert a numpy array to a PIL Image, adjusting dynamic range."""
    img = adjust_dynamic_range(image, drange, (0.0, 255.0))
    img = np.clip(img, 0, 255).astype(np.uint8)
    if img.ndim == 2:  # grayscale
        return Image.fromarray(img, mode="L")
    elif img.shape[2] == 3:
        return Image.fromarray(img, mode="RGB")
    elif img.shape[2] == 4:
        return Image.fromarray(img, mode="RGBA")
    else:
        raise ValueError("Unsupported image shape")

def save_image(
    image: Union[np.ndarray, List[np.ndarray]],
    filename: str,
    drange: Tuple[float, float] = (-1.0, 1.0),
    quality: int = 95,
) -> None:
    """Save a single image or a grid of images."""
    if isinstance(image, list):
        image = create_image_grid(image)
    pil = convert_to_pil_image(image, drange)
    pil.save(filename, quality=quality)

def save_image_grid(
    images: List[np.ndarray],
    filename: str,
    drange: Tuple[float, float] = (-1.0, 1.0),
    grid_size: Optional[Tuple[int, int]] = None,
    quality: int = 95,
) -> None:
    """Save a grid of images to a single file."""
    grid = create_image_grid(images, grid_size)
    pil = convert_to_pil_image(grid, drange)
    pil.save(filename, quality=quality)

# ----------------------------------------------------------------------
# Logging and output management
# ----------------------------------------------------------------------
class TeeOutputStream(io.TextIOBase):
    """Stream that writes to original stream and a log file."""
    def __init__(self, original_stream: io.TextIOBase, log_file: str, mode: str = "wt"):
        self.original = original_stream
        self.log = open(log_file, mode)
    def write(self, s: str) -> int:
        self.original.write(s)
        self.original.flush()
        self.log.write(s)
        self.log.flush()
        return len(s)
    def flush(self) -> None:
        self.original.flush()
        self.log.flush()
    def close(self) -> None:
        self.log.close()
        super().close()

_output_log_file: Optional[str] = None

def set_output_log_file(filename: str, mode: str = "wt") -> None:
    global _output_log_file
    _output_log_file = filename
    sys.stdout = TeeOutputStream(sys.__stdout__, filename, mode)
    sys.stderr = TeeOutputStream(sys.__stderr__, filename, mode)

def init_output_logging() -> None:
    """Redirect stdout and stderr to a default log file in current directory."""
    if _output_log_file is None:
        set_output_log_file("log.txt")

# ----------------------------------------------------------------------
# Result directory management
# ----------------------------------------------------------------------
def format_time(seconds: float) -> str:
    """Human‑readable time formatting."""
    seconds = int(round(seconds))
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    parts = []
    if h: parts.append(f"{h}h")
    if m: parts.append(f"{m}m")
    if s or not parts: parts.append(f"{s}s")
    return " ".join(parts)

def create_result_subdir(result_dir: str, desc: str) -> str:
    """Create a unique subdirectory under result_dir with a timestamp name."""
    os.makedirs(result_dir, exist_ok=True)
    now = datetime.datetime.now()
    base_name = now.strftime("%Y%m%d_%H%M%S")
    # Find a unique counter
    counter = 1
    while True:
        subdir = os.path.join(result_dir, f"{counter:03d}-{desc}")
        if not os.path.exists(subdir):
            os.makedirs(subdir)
            break
        counter += 1
    # Write config and empty log
    with open(os.path.join(subdir, "config.txt"), "w") as f:
        f.write(f"created: {now.isoformat()}\n")
        f.write(f"description: {desc}\n")
    with open(os.path.join(subdir, "log.txt"), "w") as f:
        f.write("")
    return subdir

# ----------------------------------------------------------------------
# Locating and loading results
# ----------------------------------------------------------------------
def _sorted_run_dirs(base_dir: str) -> List[str]:
    dirs = [d for d in os.listdir(base_dir) if os.path.isdir(os.path.join(base_dir, d))]
    dirs = sorted(dirs, key=lambda x: int(x.split("-", 1)[0]))
    return dirs

def locate_result_subdir(run_id_or_result_subdir: Union[int, str]) -> str:
    """Resolve a run ID or a path to the correct result subdirectory."""
    if isinstance(run_id_or_result_subdir, int):
        base_dir = os.path.dirname(os.path.abspath(__file__))
        dirs = _sorted_run_dirs(base_dir)
        if run_id_or_result_subdir < 0 or run_id_or_result_subdir >= len(dirs):
            raise ValueError("Invalid run ID")
        return os.path.join(base_dir, dirs[run_id_or_result_subdir])
    else:
        path = os.path.abspath(run_id_or_result_subdir)
        if os.path.isdir(path):
            return path
        else:
            raise ValueError("Provided path does not exist or is not a directory")

def list_network_pkls(run_id_or_result_subdir: Union[int, str], include_final: bool = False) -> List[str]:
    """List sorted .pkl files (network checkpoints) from a result directory."""
    subdir = locate_result_subdir(run_id_or_result_subdir)
    pkls = [f for f in os.listdir(subdir) if f.endswith(".pkl")]
    pkls = sorted(pkls, key=lambda x: int(x.split("-")[1].split(".")[0]))
    if not include_final:
        pkls = [p for p in pkls if not p.startswith("network-final")]
    return [os.path.join(subdir, p) for p in pkls]

def locate_network_pkl(
    run_id_or_result_subdir: Union[int, str],
    snapshot: int,
) -> str:
    """Find a specific .pkl file by snapshot number."""
    subdir = locate_result_subdir(run_id_or_result_subdir)
    fname = f"network-{snapshot:05d}.pkl"
    path = os.path.join(subdir, fname)
    if not os.path.exists(path):
        raise FileNotFoundError(f"Network pkl not found: {path}")
    return path

def load_network_pkl(
    run_id_or_result_subdir: Union[int, str],
    snapshot: int,
) -> Any:
    """Load a network checkpoint."""
    return load_pkl(locate_network_pkl(run_id_or_result_subdir, snapshot))

# ----------------------------------------------------------------------
# Dataset handling
# ----------------------------------------------------------------------
def load_dataset_for_previous_run(
    run_id: Union[int, str], **kwargs: Any
) -> Tuple[Any, bool]:
    """Parse config.txt of a previous run and construct dataset."""
    subdir = locate_result_subdir(run_id)
    config_path = os.path.join(subdir, "config.txt")
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"No config.txt in {subdir}")
    # Very simple parsing: assume each line "key: value"
    params: Dict[str, Any] = {}
    with open(config_path) as f:
        for line in f:
            if ":" in line:
                k, v = line.split(":", 1)
                params[k.strip()] = v.strip()
    # Handle legacy transformations
    if "h5_path" in params:
        params["h5_path"] = params["h5_path"].replace("old_dataset", "new_dataset")
    mirror_augment = params.get("mirror_augment", "False") == "True"
    # Placeholder: return params dict and flag
    return params, mirror_augment

def apply_mirror_augment(minibatch: np.ndarray) -> np.ndarray:
    """Randomly flip images horizontally."""
    if np.random.rand() < 0.5:
        return np.flip(minibatch, axis=2)
    return minibatch

# ----------------------------------------------------------------------
# Text label generation
# ----------------------------------------------------------------------
_text_label_cache: "OrderedDict[str, Tuple[Image.Image, Image.Image]]" = OrderedDict()
_text_label_cache_size = 64

def setup_text_label(
    text: str,
    font_size: int = 40,
    font_path: Optional[str] = None,
    glow_size: int = 3,
) -> Tuple[Image.Image, Image.Image]:
    """Generate alpha and glow masks for a text label, with caching."""
    key = f"{text}_{font_size}_{glow_size}_{font_path}"
    if key in _text_label_cache:
        _text_label_cache.move_to_end(key)
        return _text_label_cache[key]
    # Generate text clip using moviepy
    txt_clip = TextClip(
        txt=text,
        fontsize=font_size,
        color="white",
        font=font_path,
        bg_color=None,
        method="caption",
    )
    txt_clip = txt_clip.set_pos("center")
    txt_clip = txt_clip.set_duration(1)
    # Convert to PIL
    alpha_mask = Image.fromarray((txt_clip.to_ImageClip().img * 255).astype(np.uint8))
    # Glow effect
    glow = alpha_mask.filter(ImageFilter.GaussianBlur(radius=glow_size))
    # Cache
    _text_label_cache[key] = (alpha_mask, glow)
    if len(_text_label_cache) > _text_label_cache_size:
        _text_label_cache.popitem(last=False)
    return alpha_mask, glow

def draw_text_label(
    img: Image.Image,
    text: str,
    x: int,
    y: int,
    font_size: int = 40,
    glow_size: int = 3,
    alpha: float = 1.0,
) -> Image.Image:
    """Overlay text with glow onto an image."""
    alpha_mask, glow = setup_text_label(text, font_size, glow_size=glow_size)
    # Position
    img = img.copy()
    img.paste(glow, (x, y), glow)
    img.paste(alpha_mask, (x, y), alpha_mask)
    return img

# ----------------------------------------------------------------------
# Exported names
# ----------------------------------------------------------------------
__all__ = [
    "load_pkl",
    "save_pkl",
    "adjust_dynamic_range",
    "create_image_grid",
    "convert_to_pil_image",
    "save_image",
    "save_image_grid",
    "set_output_log_file",
    "init_output_logging",
    "format_time",
    "create_result_subdir",
    "locate_result_subdir",
    "list_network_pkls",
    "locate_network_pkl",
    "load_network_pkl",
    "load_dataset_for_previous_run",
    "apply_mirror_augment",
    "setup_text_label",
    "draw_text_label",
]
