import torch
import torch.nn as nn
import torch.optim as optim
import unittest


class Switch:
    def __init__(self, value: bool = False):
        self.value = value

    def __bool__(self):
        return self.value

    def set(self, value: bool):
        self.value = value


class NormalNoiseGen:
    def __init__(self, std: float = 1.0):
        self.std = std

    def __call__(self, shape, device):
        return torch.randn(shape, device=device) * self.std


class AdaptiveParamNoise:
    def __init__(self, sigma_init: float = 0.1, adaptation_coefficient: float = 1.5, target_dev: float = 0.1):
        self.sigma = sigma_init
        self.adaptation_coefficient = adaptation_coefficient
        self.target_dev = target_dev

    def adapt(self, mean_distance: float, current_std: float):
        if mean_distance > self.target_dev:
            self.sigma *= self.adaptation_coefficient
        else:
            self.sigma /= self.adaptation_coefficient
        return self.sigma

    def get_dev(self):
        return self.sigma

    def __repr__(self):
        return f"AdaptiveParamNoise(sigma={self.sigma:.4f}, target_dev={self.target_dev:.4f})"


def perturb_model(model: nn.Module, p_switch: Switch, r_switch: Switch,
                  gen_func=None, debug_backward: bool = False):
    if not hasattr(model, "_original_state_dict"):
        model._original_state_dict = {k: v.clone() for k, v in model.state_dict().items()}
    if not hasattr(model, "_noise"):
        model._noise = {k: torch.zeros_like(v) for k, v in model.state_dict().items()}

    if gen_func is None:
        gen_func = NormalNoiseGen()

    if p_switch:
        if r_switch:
            for name, param in model.named_parameters():
                model._noise[name] = gen_func(param.shape, param.device)
        with torch.no_grad():
            for name, param in model.named_parameters():
                param.copy_(model._original_state_dict[name] + model._noise[name])
    else:
        with torch.no_grad():
            for name, param in model.named_parameters():
                param.copy_(model._original_state_dict[name])

    # Prepare a deterministic input
    input_tensor = torch.arange(4, dtype=torch.float32).reshape(2, 2)
    output = model(input_tensor)
    if debug_backward:
        output.requires_grad_(True)
    return output


class TestAdaptiveParamNoise(unittest.TestCase):
    def test_adapt(self):
        apn = AdaptiveParamNoise(sigma_init=0.2, adaptation_coefficient=2.0, target_dev=0.1)
        apn.adapt(mean_distance=1.0, current_std=0.2)
        self.assertAlmostEqual(apn.sigma, 0.4)
        apn.adapt(mean_distance=0.0, current_std=0.4)
        self.assertAlmostEqual(apn.sigma, 0.2)

    def test_get_dev(self):
        apn = AdaptiveParamNoise(sigma_init=0.3)
        self.assertAlmostEqual(apn.get_dev(), 0.3)

    def test_repr(self):
        apn = AdaptiveParamNoise(sigma_init=0.5, target_dev=0.15)
        self.assertEqual(repr(apn), "AdaptiveParamNoise(sigma=0.5000, target_dev=0.1500)")


class TestPerturbModelDefaultNoise(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(0)
        self.model = nn.Linear(2, 2, bias=False)
        with torch.no_grad():
            self.model.weight.copy_(torch.ones_like(self.model.weight))
        self.p_switch = Switch(True)
        self.r_switch = Switch(True)
        self.optimizer = optim.Adam(self.model.parameters(), lr=0.01)

    def expected_output(self, noise=None):
        input_tensor = torch.arange(4, dtype=torch.float32).reshape(2, 2)
        weight = self.model.weight.data
        if noise is not None:
            weight = weight + noise
        return input_tensor @ weight.t()

    def test_cases_and_optimization(self):
        # Case 1: Perturbation on, Noise on
        output1 = perturb_model(self.model, self.p_switch, self.r_switch, debug_backward=True)
        expected1 = self.expected_output(noise=self.model._noise["weight"])
        torch.testing.assert_allclose(output1, expected1, atol=1e-6)

        # Case 2: Perturbation off, Noise on
        self.p_switch.set(False)
        output2 = perturb_model(self.model, self.p_switch, self.r_switch, debug_backward=True)
        expected2 = self.expected_output(noise=None)
        torch.testing.assert_allclose(output2, expected2, atol=1e-6)

        # Case 3: Perturbation on, Noise off
        self.p_switch.set(True)
        self.r_switch.set(False)
        output3 = perturb_model(self.model, self.p_switch, self.r_switch, debug_backward=True)
        expected3 = self.expected_output(noise=self.model._noise["weight"])
        torch.testing.assert_allclose(output3, expected3, atol=1e-6)

        # Case 4: Perturbation on, Noise on again
        self.r_switch.set(True)
        output4 = perturb_model(self.model, self.p_switch, self.r_switch, debug_backward=True)
        expected4 = self.expected_output(noise=self.model._noise["weight"])
        torch.testing.assert_allclose(output4, expected4, atol=1e-6)

        # Backward pass and optimization
        target = torch.zeros_like(output4)
        loss = nn.MSELoss()(output4, target)
        loss.backward()
        self.optimizer.step()
        # Expected weights after step
        expected_weight = self.model.weight.data.clone()
        torch.testing.assert_allclose(self.model.weight.data, expected_weight, atol=1e-6)


class TestPerturbModelCustomNoise(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(42)
        self.model = nn.Linear(2, 2, bias=False)
        with torch.no_grad():
            self.model.weight.copy_(torch.ones_like(self.model.weight))
        self.p_switch = Switch(True)
        self.r_switch = Switch(True)
        self.optimizer = optim.Adam(self.model.parameters(), lr=0.01)

        def gen_func(shape, device):
            return NormalNoiseGen(std=0.05)(shape, device)

        self.gen_func = gen_func

    def expected_output(self, noise=None):
        input_tensor = torch.arange(4, dtype=torch.float32).reshape(2, 2)
        weight = self.model.weight.data
        if noise is not None:
            weight = weight + noise
        return input_tensor @ weight.t()

    def test_cases_and_optimization(self):
        # Case 1: Perturbation on, Noise on
        output1 = perturb_model(self.model, self.p_switch, self.r_switch,
                                gen_func=self.gen_func, debug_backward=True)
        expected1 = self.expected_output(noise=self.model._noise["weight"])
        torch.testing.assert_allclose(output1, expected1, atol=1e-6)

        # Case 2: Perturbation off, Noise on
        self.p_switch.set(False)
        output2 = perturb_model(self.model, self.p_switch, self.r_switch,
                                gen_func=self.gen_func, debug_backward=True)
        expected2 = self.expected_output(noise=None)
        torch.testing.assert_allclose(output2, expected2, atol=1e-6)

        # Case 3: Perturbation on, Noise off
        self.p_switch.set(True)
        self.r_switch.set(False)
        output3 = perturb_model(self.model, self.p_switch, self.r_switch,
                                gen_func=self.gen_func, debug_backward=True)
        expected3 = self.expected_output(noise=self.model._noise["weight"])
        torch.testing.assert_allclose(output3, expected3, atol=1e-6)

        # Case 4: Perturbation on, Noise on again
        self.r_switch.set(True)
        output4 = perturb_model(self.model, self.p_switch, self.r_switch,
                                gen_func=self.gen_func, debug_backward=True)
        expected4 = self.expected_output(noise=self.model._noise["weight"])
        torch.testing.assert_allclose(output4, expected4, atol=1e-6)

        # Backward pass and optimization
        target = torch.zeros_like(output4)
        loss = nn.MSELoss()(output4, target)
        loss.backward()
        self.optimizer.step()
        # Expected weights after step
        expected_weight = self.model.weight.data.clone()
        torch.testing.assert_allclose(self.model.weight.data, expected_weight, atol=1e-6)


if __name__ == "__main__":
    unittest.main()
