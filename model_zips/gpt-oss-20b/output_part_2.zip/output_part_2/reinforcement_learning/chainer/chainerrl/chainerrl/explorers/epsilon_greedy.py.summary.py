import random
import logging

class Explorer:
    """Base Explorer class placeholder."""
    pass


def select_action_epsilon_greedily(epsilon, random_action_func, greedy_action_func):
    """
    Choose an action based on epsilon-greedy strategy.

    Parameters
    ----------
    epsilon : float
        Probability of selecting a random action.
    random_action_func : callable
        Function that returns a random action.
    greedy_action_func : callable
        Function that returns the greedy (best) action.

    Returns
    -------
    tuple
        (action, is_greedy) where is_greedy is True if the action was greedy.
    """
    if random.random() < epsilon:
        action = random_action_func()
        return action, False
    else:
        action = greedy_action_func()
        return action, True


class ConstantEpsilonGreedy(Explorer):
    """
    Exploration strategy with a fixed epsilon value.
    """

    def __init__(self, epsilon, random_action_func, greedy_action_func, logger=None):
        if not (0.0 <= epsilon <= 1.0):
            raise ValueError("epsilon must be in [0, 1]")
        self.epsilon = epsilon
        self.random_action_func = random_action_func
        self.greedy_action_func = greedy_action_func
        self.logger = logger or logging.getLogger(self.__class__.__name__)

    def select_action(self, t, *args, **kwargs):
        action, is_greedy = select_action_epsilon_greedily(
            self.epsilon, self.random_action_func, self.greedy_action_func
        )
        self.logger.debug(
            f"t={t} action={action} epsilon={self.epsilon:.4f} greedy={is_greedy}"
        )
        return action

    def __repr__(self):
        return f"{self.__class__.__name__}(epsilon={self.epsilon:.4f})"


class LinearDecayEpsilonGreedy(Explorer):
    """
    Exploration strategy with linearly decaying epsilon.
    """

    def __init__(
        self,
        start_epsilon,
        end_epsilon,
        decay_steps,
        random_action_func,
        greedy_action_func,
        logger=None,
    ):
        if not (0.0 <= start_epsilon <= 1.0):
            raise ValueError("start_epsilon must be in [0, 1]")
        if not (0.0 <= end_epsilon <= 1.0):
            raise ValueError("end_epsilon must be in [0, 1]")
        if decay_steps < 0:
            raise ValueError("decay_steps must be non-negative")
        self.start_epsilon = start_epsilon
        self.end_epsilon = end_epsilon
        self.decay_steps = decay_steps
        self.random_action_func = random_action_func
        self.greedy_action_func = greedy_action_func
        self.logger = logger or logging.getLogger(self.__class__.__name__)

    def compute_epsilon(self, t):
        if self.decay_steps == 0 or t >= self.decay_steps:
            return self.end_epsilon
        fraction = t / self.decay_steps
        return self.start_epsilon + fraction * (self.end_epsilon - self.start_epsilon)

    def select_action(self, t, *args, **kwargs):
        epsilon = self.compute_epsilon(t)
        action, is_greedy = select_action_epsilon_greedily(
            epsilon, self.random_action_func, self.greedy_action_func
        )
        self.logger.debug(
            f"t={t} action={action} epsilon={epsilon:.4f} greedy={is_greedy}"
        )
        return action

    def __repr__(self):
        current_eps = self.compute_epsilon(0)
        return f"{self.__class__.__name__}(current_epsilon={current_eps:.4f})"