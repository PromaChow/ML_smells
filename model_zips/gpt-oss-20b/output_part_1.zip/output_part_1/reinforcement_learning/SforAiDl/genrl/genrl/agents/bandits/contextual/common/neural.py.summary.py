import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torch.nn.utils import clip_grad_norm_


class DeepContextualBandit(nn.Module):
    def __init__(
        self,
        context_dim: int,
        hidden_dims: list[int],
        n_actions: int,
        init_lr: float = 1e-3,
        max_grad_norm: float = 5.0,
        lr_decay: float = 0.99,
        lr_reset: float = 1.0,
        dropout_p: float = 0.0,
    ):
        super().__init__()
        self.context_dim = context_dim
        self.hidden_dims = hidden_dims
        self.n_actions = n_actions
        self.init_lr = init_lr
        self.max_grad_norm = max_grad_norm
        self.lr_decay = lr_decay
        self.lr_reset = lr_reset
        self.dropout_p = dropout_p

        layers = []
        prev_dim = context_dim
        for dim in hidden_dims:
            layers.append(nn.Linear(prev_dim, dim))
            prev_dim = dim
        self.hidden_layers = nn.ModuleList(layers)
        self.output_layer = nn.Linear(prev_dim, n_actions)

    def forward(self, context: torch.Tensor, use_dropout: bool = False):
        x = context
        for idx, layer in enumerate(self.hidden_layers):
            x = F.relu(layer(x))
            if self.dropout_p > 0 and use_dropout:
                x = F.dropout(x, p=self.dropout_p, training=self.training)
        pred_rewards = self.output_layer(x)
        return {"x": x, "pred_rewards": pred_rewards}

    @staticmethod
    def compute_loss(
        reward_vec: torch.Tensor,
        pred_rewards: torch.Tensor,
        action_mask: torch.Tensor,
        batch_size: int,
    ) -> torch.Tensor:
        diff = reward_vec - pred_rewards
        squared = diff.pow(2)
        weighted = squared * action_mask
        loss = weighted.sum() / batch_size
        return loss


class TransitionDB(Dataset):
    """
    Dummy dataset for demonstration.
    Each sample is a tuple of (context, action_mask, reward_vec).
    """

    def __init__(self, num_samples: int, context_dim: int, n_actions: int):
        super().__init__()
        self.num_samples = num_samples
        self.context_dim = context_dim
        self.n_actions = n_actions
        self.data = [
            (
                torch.randn(context_dim),
                torch.randint(0, 2, (n_actions,)).float(),
                torch.randn(n_actions),
            )
            for _ in range(num_samples)
        ]

    def __len__(self):
        return self.num_samples

    def __getitem__(self, idx):
        return self.data[idx]


def train_one_epoch(
    model: DeepContextualBandit,
    dataloader: DataLoader,
    optimizer,
    device: torch.device,
):
    model.train()
    for batch in dataloader:
        context, action_mask, reward_vec = batch
        context = context.to(device)
        action_mask = action_mask.to(device)
        reward_vec = reward_vec.to(device)

        outputs = model(context, use_dropout=True)
        pred_rewards = outputs["pred_rewards"]

        loss = DeepContextualBandit.compute_loss(
            reward_vec, pred_rewards, action_mask, batch_size=context.size(0)
        )

        optimizer.zero_grad()
        loss.backward()
        clip_grad_norm_(model.parameters(), model.max_grad_norm)
        optimizer.step()


def main():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    context_dim = 20
    hidden_dims = [64, 32]
    n_actions = 10

    model = DeepContextualBandit(
        context_dim=context_dim,
        hidden_dims=hidden_dims,
        n_actions=n_actions,
        dropout_p=0.1,
    ).to(device)

    optimizer = torch.optim.Adam(
        model.parameters(), lr=model.init_lr, weight_decay=0.0
    )

    dataset = TransitionDB(num_samples=1000, context_dim=context_dim, n_actions=n_actions)
    dataloader = DataLoader(dataset, batch_size=32, shuffle=True)

    for epoch in range(5):
        train_one_epoch(model, dataloader, optimizer, device)
        print(f"Epoch {epoch+1} completed.")


if __name__ == "__main__":
    main()
