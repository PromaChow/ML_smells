import gym
import torch
import torch.nn as nn
import torch.optim as optim
import torch.multiprocessing as mp
import numpy as np
import time
from collections import deque


class Actor(nn.Module):
    def __init__(self, state_dim, action_dim, action_range):
        super().__init__()
        self.action_range = action_range
        self.net = nn.Sequential(
            nn.Linear(state_dim, 64),
            nn.ReLU(),
            nn.Linear(64, action_dim),
            nn.Tanh()
        )

    def forward(self, state):
        return self.net(state) * self.action_range


class Critic(nn.Module):
    def __init__(self, state_dim, action_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim + action_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 1)
        )

    def forward(self, state, action):
        x = torch.cat([state, action], dim=-1)
        return self.net(x)


class DDPGApex:
    def __init__(self, actor, critic, actor_target, critic_target,
                 optimizer, loss_fn, replay_queue, sync=True):
        self.actor = actor
        self.critic = critic
        self.actor_target = actor_target
        self.critic_target = critic_target
        self.optimizer = optimizer
        self.loss_fn = loss_fn
        self.replay_queue = replay_queue
        self.sync = sync
        self.device = torch.device("cpu")

        self.actor_target.load_state_dict(self.actor.state_dict())
        self.critic_target.load_state_dict(self.critic.state_dict())

    def set_sync(self, sync: bool):
        self.sync = sync

    def manual_sync(self):
        if self.sync:
            self.actor_target.load_state_dict(self.actor.state_dict())
            self.critic_target.load_state_dict(self.critic.state_dict())

    def act_with_noise(self, state, noise_std=0.2):
        state_t = torch.tensor(state, dtype=torch.float32).unsqueeze(0)
        with torch.no_grad():
            action = self.actor(state_t).cpu().numpy()[0]
        noise = np.random.normal(0, noise_std, size=action.shape)
        action = action + noise
        return np.clip(action, -self.actor.action_range, self.actor.action_range)

    def update(self, batch_size=64):
        if self.replay_queue.qsize() < batch_size:
            return
        batch = [self.replay_queue.get() for _ in range(batch_size)]
        states, actions, rewards, next_states, dones = zip(*batch)

        states = torch.tensor(states, dtype=torch.float32)
        actions = torch.tensor(actions, dtype=torch.float32)
        rewards = torch.tensor(rewards, dtype=torch.float32).unsqueeze(1)
        next_states = torch.tensor(next_states, dtype=torch.float32)
        dones = torch.tensor(dones, dtype=torch.float32).unsqueeze(1)

        with torch.no_grad():
            next_actions = self.actor_target(next_states)
            q_next = self.critic_target(next_states, next_actions)
            q_target = rewards + (1 - dones) * 0.99 * q_next

        q_current = self.critic(states, actions)
        critic_loss = self.loss_fn(q_current, q_target)

        self.optimizer.zero_grad()
        critic_loss.backward()
        self.optimizer.step()

        actor_loss = -self.critic(states, self.actor(states)).mean()

        self.optimizer.zero_grad()
        actor_loss.backward()
        self.optimizer.step()

        self.soft_update(self.actor_target, self.actor, tau=0.005)
        self.soft_update(self.critic_target, self.critic, tau=0.005)

    @staticmethod
    def soft_update(target, source, tau):
        for target_param, param in zip(target.parameters(), source.parameters()):
            target_param.data.copy_(target_param.data * (1.0 - tau) + param.data * tau)


def worker_process(rank, world_size, replay_queue, barrier, action_range, solved_reward, max_consecutive=10):
    env = gym.make("Pendulum-v0")
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.shape[0]

    actor = Actor(state_dim, action_dim, action_range).share_memory()
    critic = Critic(state_dim, action_dim).share_memory()
    actor_target = Actor(state_dim, action_dim, action_range).share_memory()
    critic_target = Critic(state_dim, action_dim).share_memory()

    optimizer = optim.Adam(list(actor.parameters()) + list(critic.parameters()), lr=1e-3)
    loss_fn = nn.MSELoss()
    ddpg = DDPGApex(actor, critic, actor_target, critic_target, optimizer, loss_fn, replay_queue, sync=True)

    ddpg.set_sync(False)

    reward_history = deque(maxlen=max_consecutive)
    solved = False
    episode = 0

    while not solved:
        ddpg.manual_sync()
        state = env.reset()
        done = False
        total_reward = 0.0
        while not done:
            action = ddpg.act_with_noise(state)
            next_state, reward, done, _ = env.step(action)
            replay_queue.put((state, action, reward, next_state, done))
            state = next_state
            total_reward += reward
        reward_history.append(total_reward)
        avg_reward = np.mean(reward_history)
        print(f"[Worker {rank}] Episode {episode} Reward {total_reward:.2f} Avg {avg_reward:.2f}")
        if len(reward_history) == max_consecutive and avg_reward >= solved_reward:
            solved = True
        episode += 1
    print(f"[Worker {rank}] Solved!")
    env.close()


def learner_process(rank, world_size, replay_queue, barrier, min_buffer=500):
    env = gym.make("Pendulum-v0")
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.shape[0]
    action_range = env.action_space.high[0]

    actor = Actor(state_dim, action_dim, action_range).share_memory()
    critic = Critic(state_dim, action_dim).share_memory()
    actor_target = Actor(state_dim, action_dim, action_range).share_memory()
    critic_target = Critic(state_dim, action_dim).share_memory()

    optimizer = optim.Adam(list(actor.parameters()) + list(critic.parameters()), lr=1e-3)
    loss_fn = nn.MSELoss()
    ddpg = DDPGApex(actor, critic, actor_target, critic_target, optimizer, loss_fn, replay_queue, sync=False)

    while True:
        if replay_queue.qsize() >= min_buffer:
            ddpg.update()
        else:
            time.sleep(0.01)
    env.close()


def main(rank, world_size, replay_queue, barrier, action_range, solved_reward):
    if rank < 2:
        worker_process(rank, world_size, replay_queue, barrier, action_range, solved_reward)
    else:
        learner_process(rank, world_size, replay_queue, barrier)


if __name__ == "__main__":
    mp.set_start_method("spawn")
    world_size = 4
    action_range = 2.0  # Pendulum action range
    solved_reward = -200.0  # Example threshold

    replay_queue = mp.Queue()
    barrier = mp.Barrier(world_size)

    mp.spawn(
        main,
        args=(world_size, replay_queue, barrier, action_range, solved_reward),
        nprocs=world_size,
        join=True
    )