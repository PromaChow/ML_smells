import random

class Agent:
    """Base agent class."""
    def __init__(self):
        pass

    def act(self):
        """Determine action for the agent."""
        raise NotImplementedError("Subclasses must implement act method.")


class RandomAgent(Agent):
    """Agent that selects actions randomly from a given action space."""

    def __init__(self, action_space):
        super().__init__()
        self.action_space = action_space
        self._id = 'random'

    def act(self):
        """Return a random action sampled from the action space."""
        return self.action_space.sample()
