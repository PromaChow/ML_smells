import torch
import torch.nn as nn
import math

def normalized_columns_initializer(tensor: torch.Tensor, std: float) -> torch.Tensor:
    """
    Scale the columns of the tensor so that each column has a standard deviation of `std`.
    """
    out = tensor.data
    col_norms = out.norm(p=2, dim=0, keepdim=True)
    out.copy_(out / col_norms * std)
    return tensor

def weights_init(module: nn.Module) -> None:
    """
    He initialization for Conv2d and Linear layers.
    Custom initialization for LSTMCell weights and biases.
    """
    if isinstance(module, nn.Conv2d) or isinstance(module, nn.Linear):
        fan_in = 1
        if isinstance(module, nn.Conv2d):
            fan_in = module.in_channels * module.kernel_size[0] * module.kernel_size[1]
        else:  # Linear
            fan_in = module.in_features
        fan_out = 1
        if isinstance(module, nn.Conv2d):
            fan_out = module.out_channels * module.kernel_size[0] * module.kernel_size[1]
        else:  # Linear
            fan_out = module.out_features
        bound = math.sqrt(6.0 / (fan_in + fan_out))
        nn.init.uniform_(module.weight, -bound, bound)
        if module.bias is not None:
            nn.init.constant_(module.bias, 0.0)
    elif isinstance(module, nn.LSTMCell):
        # Initialize weight_ih
        weight_ih = getattr(module, "weight_ih")
        fan_in_ih = weight_ih.shape[1]  # input_size
        fan_out_ih = weight_ih.shape[0]  # 4*hidden_size
        bound_ih = math.sqrt(6.0 / (fan_in_ih + fan_out_ih))
        nn.init.uniform_(weight_ih, -bound_ih, bound_ih)
        # Initialize weight_hh
        weight_hh = getattr(module, "weight_hh")
        fan_in_hh = weight_hh.shape[1]  # hidden_size
        fan_out_hh = weight_hh.shape[0]  # 4*hidden_size
        bound_hh = math.sqrt(6.0 / (fan_in_hh + fan_out_hh))
        nn.init.uniform_(weight_hh, -bound_hh, bound_hh)
        # Zero biases
        nn.init.constant_(module.bias_ih, 0.0)
        nn.init.constant_(module.bias_hh, 0.0)

class ActorCritic(nn.Module):
    def __init__(self, num_inputs: int, action_space: int) -> None:
        super().__init__()
        self.conv1 = nn.Conv2d(num_inputs, 32, kernel_size=3, stride=2, padding=1)
        self.conv2 = nn.Conv2d(32, 32, kernel_size=3, stride=2, padding=1)
        self.conv3 = nn.Conv2d(32, 32, kernel_size=3, stride=2, padding=1)
        self.conv4 = nn.Conv2d(32, 32, kernel_size=3, stride=2, padding=1)
        # Assuming final feature map size is 3x3
        conv_output_size = 32 * 3 * 3
        self.lstm = nn.LSTMCell(conv_output_size, 256)
        self.critic_linear = nn.Linear(256, 1)
        self.actor_linear = nn.Linear(256, action_space)

        # Apply weight initialization
        self.apply(weights_init)
        # Actor and critic linear layers with normalized column init
        normalized_columns_initializer(self.actor_linear.weight, 0.01)
        nn.init.constant_(self.actor_linear.bias, 0.0)
        normalized_columns_initializer(self.critic_linear.weight, 1.0)
        nn.init.constant_(self.critic_linear.bias, 0.0)

    def forward(self, x: torch.Tensor, hx: torch.Tensor, cx: torch.Tensor):
        """
        Forward pass through the network.

        Parameters
        ----------
        x : torch.Tensor
            Input observation tensor of shape (batch, channels, height, width).
        hx : torch.Tensor
            LSTM hidden state of shape (batch, hidden_size).
        cx : torch.Tensor
            LSTM cell state of shape (batch, hidden_size).

        Returns
        -------
        tuple
            (critic_value, actor_logits, (hx, cx))
        """
        x = torch.nn.functional.elu(self.conv1(x))
        x = torch.nn.functional.elu(self.conv2(x))
        x = torch.nn.functional.elu(self.conv3(x))
        x = torch.nn.functional.elu(self.conv4(x))
        x = x.view(x.size(0), -1)  # flatten
        hx, cx = self.lstm(x, (hx, cx))
        critic_value = self.critic_linear(hx)
        actor_logits = self.actor_linear(hx)
        return critic_value, actor_logits, (hx, cx)