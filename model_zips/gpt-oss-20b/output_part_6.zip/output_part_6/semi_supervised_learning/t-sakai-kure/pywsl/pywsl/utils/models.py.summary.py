import chainer
import chainer.functions as F
import chainer.links as L

class TLP(chainer.Chain):
    def __init__(self, in_size):
        super().__init__()
        with self.init_scope():
            self.l1 = L.Linear(in_size, 100)
            self.l2 = L.Linear(100, 1)

    def __call__(self, x):
        h = F.relu(self.l1(x))
        return self.l2(h)

class MLP(chainer.Chain):
    def __init__(self, in_size):
        super().__init__()
        with self.init_scope():
            self.l1 = L.Linear(in_size, 100)
            self.b1 = L.BatchNormalization(100)
            self.l2 = L.Linear(100, 100)
            self.b2 = L.BatchNormalization(100)
            self.l3 = L.Linear(100, 100)
            self.b3 = L.BatchNormalization(100)
            self.l4 = L.Linear(100, 1)

    def __call__(self, x):
        h = F.relu(self.b1(self.l1(x)))
        h = F.relu(self.b2(self.l2(h)))
        h = F.relu(self.b3(self.l3(h)))
        return self.l4(h)

class CNN(chainer.Chain):
    def __init__(self):
        super().__init__()
        with self.init_scope():
            self.conv1 = L.Convolution2D(3, 96, ksize=3, stride=1, pad=1)
            self.b1 = L.BatchNormalization(96)
            self.conv2 = L.Convolution2D(96, 256, ksize=3, stride=1, pad=1)
            self.b2 = L.BatchNormalization(256)
            self.conv3 = L.Convolution2D(256, 384, ksize=3, stride=2, pad=1)
            self.b3 = L.BatchNormalization(384)
            self.conv4 = L.Convolution2D(384, 384, ksize=3, stride=1, pad=1)
            self.b4 = L.BatchNormalization(384)
            self.conv5 = L.Convolution2D(384, 256, ksize=3, stride=1, pad=1)
            self.b5 = L.BatchNormalization(256)
            self.conv6 = L.Convolution2D(256, 256, ksize=3, stride=2, pad=1)
            self.b6 = L.BatchNormalization(256)
            self.conv7 = L.Convolution2D(256, 256, ksize=3, stride=1, pad=1)
            self.b7 = L.BatchNormalization(256)
            self.conv8 = L.Convolution2D(256, 256, ksize=3, stride=1, pad=1)
            self.b8 = L.BatchNormalization(256)
            self.conv9 = L.Convolution2D(256, 256, ksize=1, stride=1, pad=1)
            self.b9 = L.BatchNormalization(256)
            self.fc1 = L.Linear(None, 1000)
            self.fc2 = L.Linear(1000, 1000)
            self.fc3 = L.Linear(1000, 1)

    def __call__(self, x):
        h = F.relu(self.b1(self.conv1(x)))
        h = F.relu(self.b2(self.conv2(h)))
        h = F.relu(self.b3(self.conv3(h)))
        h = F.relu(self.b4(self.conv4(h)))
        h = F.relu(self.b5(self.conv5(h)))
        h = F.relu(self.b6(self.conv6(h)))
        h = F.relu(self.b7(self.conv7(h)))
        h = F.relu(self.b8(self.conv8(h)))
        h = F.relu(self.b9(self.conv9(h)))
        h = F.reshape(h, (h.shape[0], -1))
        h = F.relu(self.fc1(h))
        h = F.relu(self.fc2(h))
        return self.fc3(h)