import numpy as np
import tensorflow as tf
from collections import deque

tf.compat.v1.disable_eager_execution()

# Parameters
height = 3
width = 4
target = 3
n_classes = 5
learning_rate = 0.001
training_iters = 50000
batch_size = 1000
display_step = 10
keep_prob_val = 0.75
model_path = "/tmp/model.ckpt"


def state_matrix(state):
    board, _ = state
    matrix = np.array(board, dtype=np.float32)
    return matrix


def check_winner(board, player):
    b = np.array(board)
    # horizontal
    for r in range(height):
        for c in range(width - target + 1):
            if np.all(b[r, c : c + target] == player):
                return True
    # vertical
    for c in range(width):
        for r in range(height - target + 1):
            if np.all(b[r : r + target, c] == player):
                return True
    # diagonal /
    for r in range(height - target + 1):
        for c in range(target - 1, width):
            if np.all([b[r + i, c - i] == player for i in range(target)]):
                return True
    # diagonal \
    for r in range(height - target + 1):
        for c in range(width - target + 1):
            if np.all([b[r + i, c + i] == player for i in range(target)]):
                return True
    return False


def play():
    start_board = tuple([tuple([0] * width) for _ in range(height)])
    start_state = (start_board, 1)
    visited = set()
    X = []
    Y = []
    queue = deque([start_state])

    while queue:
        board, player = queue.popleft()
        state_id = (board, player)
        if state_id in visited:
            continue
        visited.add(state_id)

        X.append(state_matrix((board, player)))
        # Random one‑hot label for demonstration
        label = np.zeros(n_classes, dtype=np.float32)
        label[np.random.randint(0, n_classes)] = 1.0
        Y.append(label)

        for col in range(width):
            col_vals = [board[row][col] for row in range(height)]
            if all(v == 0 for v in col_vals):
                for row in reversed(range(height)):
                    if board[row][col] == 0:
                        new_row = list(row for row in board)
                        new_row = [list(r) for r in new_row]
                        new_row[row][col] = player
                        new_board = tuple(tuple(r) for r in new_row)
                        next_state = (new_board, 3 - player)
                        queue.append(next_state)
                        break

    X = np.array(X, dtype=np.float32)
    Y = np.array(Y, dtype=np.float32)
    return X, Y


def batch_x_y(X, Y, batch_size):
    indices = np.random.choice(len(X), batch_size, replace=False)
    return X[indices], Y[indices]


def conv2d(x, W):
    return tf.nn.conv2d(x, W, strides=[1, 1, 1, 1], padding="SAME")


def max_pool(x):
    return tf.nn.max_pool2d(x, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding="SAME")


def main():
    X_data, Y_data = play()

    # Placeholders
    x = tf.compat.v1.placeholder(tf.float32, [None, height, width, 1], name="x")
    y = tf.compat.v1.placeholder(tf.float32, [None, n_classes], name="y")
    keep_prob = tf.compat.v1.placeholder(tf.float32, name="keep_prob")

    # Weights and biases
    weights = {
        "wc1": tf.Variable(tf.random.normal([3, 4, 1, 32]), name="wc1"),
        "wc2": tf.Variable(tf.random.normal([3, 4, 32, 64]), name="wc2"),
        "wd1": tf.Variable(tf.random.normal([height * width * 64, 1024]), name="wd1"),
        "out": tf.Variable(tf.random.normal([1024, n_classes]), name="out"),
    }
    biases = {
        "bc1": tf.Variable(tf.random.normal([32]), name="bc1"),
        "bc2": tf.Variable(tf.random.normal([64]), name="bc2"),
        "bd1": tf.Variable(tf.random.normal([1024]), name="bd1"),
        "out": tf.Variable(tf.random.normal([n_classes]), name="bias_out"),
    }

    # Reshape input
    x_reshaped = tf.reshape(x, shape=[-1, height, width, 1])

    # Convolution Layer 1
    conv1 = tf.nn.relu(conv2d(x_reshaped, weights["wc1"]) + biases["bc1"])
    # Convolution Layer 2
    conv2 = tf.nn.relu(conv2d(conv1, weights["wc2"]) + biases["bc2"])
    # Flatten
    flatten = tf.reshape(conv2, shape=[-1, height * width * 64])
    # Fully connected layer
    fc1 = tf.nn.relu(tf.matmul(flatten, weights["wd1"]) + biases["bd1"])
    fc1_drop = tf.nn.dropout(fc1, keep_prob)
    # Output layer
    logits = tf.matmul(fc1_drop, weights["out"]) + biases["out"]
    prediction = tf.nn.softmax(logits)

    # Loss and optimizer
    loss_op = tf.reduce_mean(
        tf.nn.softmax_cross_entropy_with_logits_v2(logits=logits, labels=y)
    )
    optimizer = tf.compat.v1.train.AdamOptimizer(learning_rate=learning_rate)
    train_op = optimizer.minimize(loss_op)

    # Accuracy
    correct_pred = tf.equal(tf.argmax(prediction, 1), tf.argmax(y, 1))
    accuracy = tf.reduce_mean(tf.cast(correct_pred, tf.float32))

    # Saver
    saver = tf.compat.v1.train.Saver()

    with tf.compat.v1.Session() as sess:
        sess.run(tf.compat.v1.global_variables_initializer())
        for step in range(1, training_iters + 1):
            batch_x, batch_y = batch_x_y(X_data, Y_data, batch_size)
            sess.run(
                train_op, feed_dict={x: batch_x[:, :, :, None], y: batch_y, keep_prob: keep_prob_val}
            )
            if step % display_step == 0 or step == 1:
                loss, acc = sess.run(
                    [loss_op, accuracy],
                    feed_dict={x: batch_x[:, :, :, None], y: batch_y, keep_prob: 1.0},
                )
                print(
                    "Step {}, Minibatch Loss= {:.4f}, Training Accuracy= {:.3f}".format(
                        step, loss, acc
                    )
                )
        saver.save(sess, model_path)
        print("Model saved to {}".format(model_path))


if __name__ == "__main__":
    main()
