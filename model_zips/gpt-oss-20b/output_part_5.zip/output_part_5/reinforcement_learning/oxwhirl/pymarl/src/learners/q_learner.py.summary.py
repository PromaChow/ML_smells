import copy
import torch
import torch.nn as nn
import torch.optim as optim

class QLearner:
    def __init__(
        self,
        mac,
        mixer=None,
        lr=0.0005,
        alpha=0.99,
        eps=1e-5,
        gamma=0.99,
        target_update_interval=200,
        learner_log_interval=10,
        double_q=True,
        grad_norm_clip=10,
    ):
        self.mac = mac
        self.mixer = mixer
        self.target_mac = copy.deepcopy(mac)
        self.target_mixer = copy.deepcopy(mixer) if mixer else None

        self.gamma = gamma
        self.target_update_interval = target_update_interval
        self.learner_log_interval = learner_log_interval
        self.double_q = double_q
        self.grad_norm_clip = grad_norm_clip

        self.optimizer = optim.RMSprop(
            self.mac.parameters(), lr=lr, alpha=alpha, eps=eps
        )

        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.mac.to(self.device)
        if self.mixer:
            self.mixer.to(self.device)
        if self.target_mixer:
            self.target_mixer.to(self.device)

    def train(self, batch, episode_num):
        rewards = batch.rewards.to(self.device)
        actions = batch.actions.to(self.device)
        terminated = batch.terminated.to(self.device)
        masks = batch.masks.to(self.device)
        avail_actions = batch.avail_actions.to(self.device) if hasattr(batch, "avail_actions") else None
        states = batch.states.to(self.device) if hasattr(batch, "states") else None

        # Adjust mask for terminated episodes
        masks = masks * (1.0 - terminated)

        seq_len = rewards.size(1)
        batch_size = rewards.size(0)
        n_agents = rewards.size(2)

        # Compute Q-values for all time steps
        q_vals = []
        for t in range(seq_len):
            obs_t = batch.observations[:, t]
            agent_qs = self.mac.forward(obs_t)  # (batch, agents, actions)
            q_vals.append(agent_qs)
        q_vals = torch.stack(q_vals, dim=1)  # (batch, seq, agents, actions)

        actions_expanded = actions.unsqueeze(-1)
        chosen_q_vals = q_vals.gather(-1, actions_expanded).squeeze(-1)  # (batch, seq, agents)

        # Compute target Q-values
        with torch.no_grad():
            target_q_vals = []
            for t in range(1, seq_len):
                next_obs = batch.observations[:, t]
                target_agent_qs = self.target_mac.forward(next_obs)
                target_q_vals.append(target_agent_qs)
            if target_q_vals:
                last_q = torch.zeros_like(target_q_vals[0])
                target_q_vals = torch.cat(target_q_vals + [last_q], dim=1)
            else:
                target_q_vals = torch.zeros_like(q_vals[:, 0:1])

            # Mask unavailable actions
            if avail_actions is not None:
                avail_next = avail_actions[:, 1:]
                mask_tensor = avail_next.to(torch.bool)
                target_q_vals[~mask_tensor] = -9999999

            if self.double_q:
                # Max actions from current Q-values (excluding first time step)
                max_actions = q_vals[:, 1:].max(-1)[1]
                max_actions_exp = max_actions.unsqueeze(-1)
                target_max = target_q_vals[:, 1:].gather(-1, max_actions_exp).squeeze(-1)
            else:
                target_max = target_q_vals[:, 1:].max(-1)[0]

            target_max = torch.cat([torch.zeros_like(target_max[:, :1]), target_max], dim=1)

        # Mixer
        if self.mixer:
            if states is not None:
                chosen_q_vals = self.mixer(chosen_q_vals, states)
                target_max = self.target_mixer(target_max, states)
            else:
                chosen_q_vals = self.mixer(chosen_q_vals)
                target_max = self.target_mixer(target_max)

        # TD target
        targets = rewards + self.gamma * (1 - terminated) * target_max
        td_error = chosen_q_vals - targets

        # Mask TD error
        td_error = td_error * masks
        loss = (td_error ** 2).sum() / masks.sum()

        # Optimization step
        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.mac.parameters(), self.grad_norm_clip)
        self.optimizer.step()

        # Target network update
        if episode_num % self.target_update_interval == 0:
            self.target_mac.load_state_dict(self.mac.state_dict())
            if self.mixer and self.target_mixer:
                self.target_mixer.load_state_dict(self.mixer.state_dict())

        # Logging
        if episode_num % self.learner_log_interval == 0:
            print(
                f"Episode {episode_num}, Loss: {loss.item():.4f}, "
                f"TD Mean: {td_error.abs().mean().item():.4f}"
            )

    def save_models(self, path):
        torch.save(self.mac.state_dict(), f"{path}_mac.pth")
        if self.mixer:
            torch.save(self.mixer.state_dict(), f"{path}_mixer.pth")
        torch.save(self.optimizer.state_dict(), f"{path}_optim.pth")

    def load_models(self, path):
        self.mac.load_state_dict(torch.load(f"{path}_mac.pth", map_location=self.device))
        if self.mixer:
            self.mixer.load_state_dict(torch.load(f"{path}_mixer.pth", map_location=self.device))
        self.optimizer.load_state_dict(torch.load(f"{path}_optim.pth", map_location=self.device))
        self.mac.to(self.device)
        if self.mixer:
            self.mixer.to(self.device)
        if self.target_mixer:
            self.target_mixer.to(self.device)
        if self.target_mac:
            self.target_mac.to(self.device)