import numpy as np

def make_rendered(env, *render_args, **render_kwargs):
    """Ensures the environment renders after every step and during closure."""
    original_step = env.step
    original_close = env.close

    def step_wrapper(action):
        obs, reward, done, info = original_step(action)
        env.render(*render_args, **render_kwargs)
        return obs, reward, done, info

    def close_wrapper():
        env.render(*render_args, close=True, **render_kwargs)
        original_close()

    env.step = step_wrapper
    env.close = close_wrapper
    return env


def make_timestep_limited(env, timestep_limit):
    """Limits the number of steps the environment can take."""
    original_step = env.step
    original_reset = env.reset
    t = 1

    def step_wrapper(action):
        nonlocal t
        obs, reward, done, info = original_step(action)
        t += 1
        if t > timestep_limit:
            done = True
        return obs, reward, done, info

    def reset_wrapper(*args, **kwargs):
        nonlocal t
        t = 1
        return original_reset(*args, **kwargs)

    env.step = step_wrapper
    env.reset = reset_wrapper
    return env


def make_action_filtered(env, action_filter):
    """Applies a filter to actions before they are processed."""
    original_step = env.step

    def step_wrapper(action):
        filtered_action = action_filter(action)
        return original_step(filtered_action)

    env.step = step_wrapper
    return env


def make_reward_filtered(env, reward_filter):
    """Modifies the reward returned by the environment."""
    original_step = env.step

    def step_wrapper(action):
        obs, reward, done, info = original_step(action)
        reward = reward_filter(reward)
        return obs, reward, done, info

    env.step = step_wrapper
    return env


def make_reward_clipped(env, low, high):
    """Clips rewards to a specified range."""
    return make_reward_filtered(env, lambda x: np.clip(x, low, high))


def make_action_repeated(env, n_times):
    """Repeats the same action multiple times and accumulates rewards."""
    original_step = env.step

    def step_wrapper(action):
        obs = None
        r_total = 0.0
        done = False
        info = {}
        for _ in range(n_times):
            obs, reward, done, info = original_step(action)
            r_total += reward
            if done:
                break
        return obs, r_total, done, info

    env.step = step_wrapper
    return env

