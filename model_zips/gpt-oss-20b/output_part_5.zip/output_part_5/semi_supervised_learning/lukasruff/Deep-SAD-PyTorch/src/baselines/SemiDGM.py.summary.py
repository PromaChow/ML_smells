import json
import time
from pathlib import Path
from typing import Dict, Optional

import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.metrics import roc_auc_score


class VAE(nn.Module):
    def __init__(self, input_dim: int, latent_dim: int):
        super().__init__()
        self.fc1 = nn.Linear(input_dim, 256)
        self.fc21 = nn.Linear(256, latent_dim)   # mean
        self.fc22 = nn.Linear(256, latent_dim)   # logvar
        self.fc3 = nn.Linear(latent_dim, 256)
        self.fc4 = nn.Linear(256, input_dim)
        self.relu = nn.ReLU()

    def encode(self, x):
        h1 = self.relu(self.fc1(x))
        return self.fc21(h1), self.fc22(h1)

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def decode(self, z):
        h3 = self.relu(self.fc3(z))
        return torch.sigmoid(self.fc4(h3))

    def forward(self, x):
        mu, logvar = self.encode(x.view(x.size(0), -1))
        z = self.reparameterize(mu, logvar)
        return self.decode(z), mu, logvar


class SemiSupervisedNetwork(nn.Module):
    def __init__(self, vae: VAE, num_classes: int = 2):
        super().__init__()
        self.vae = vae
        self.classifier = nn.Linear(vae.fc21.out_features, num_classes)

    def forward(self, x):
        recon, mu, logvar = self.vae(x)
        logits = self.classifier(mu)
        return recon, mu, logvar, logits


class VAETrainer:
    def __init__(
        self,
        model: VAE,
        optimizer: optim.Optimizer,
        epochs: int,
        batch_size: int,
        device: torch.device,
    ):
        self.model = model.to(device)
        self.optimizer = optimizer
        self.epochs = epochs
        self.batch_size = batch_size
        self.device = device
        self.history: Dict[str, list] = {"train_loss": [], "val_loss": []}

    def loss_function(self, recon_x, x, mu, logvar):
        BCE = nn.functional.binary_cross_entropy(
            recon_x, x.view(-1, x.size(1)), reduction="sum"
        )
        KLD = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
        return (BCE + KLD) / x.size(0)

    def train(self, train_loader, val_loader):
        start = time.time()
        for epoch in range(self.epochs):
            self.model.train()
            train_loss = 0
            for batch, _ in train_loader:
                batch = batch.to(self.device)
                self.optimizer.zero_grad()
                recon_batch, mu, logvar = self.model(batch)
                loss = self.loss_function(recon_batch, batch, mu, logvar)
                loss.backward()
                train_loss += loss.item()
                self.optimizer.step()
            train_loss /= len(train_loader.dataset)
            self.history["train_loss"].append(train_loss)

            self.model.eval()
            val_loss = 0
            with torch.no_grad():
                for batch, _ in val_loader:
                    batch = batch.to(self.device)
                    recon_batch, mu, logvar = self.model(batch)
                    loss = self.loss_function(recon_batch, batch, mu, logvar)
                    val_loss += loss.item()
            val_loss /= len(val_loader.dataset)
            self.history["val_loss"].append(val_loss)
        elapsed = time.time() - start
        return {"time": elapsed, "train_loss": self.history["train_loss"], "val_loss": self.history["val_loss"]}


class SemiDeepGenerativeTrainer:
    def __init__(
        self,
        model: SemiSupervisedNetwork,
        optimizer: optim.Optimizer,
        epochs: int,
        batch_size: int,
        device: torch.device,
    ):
        self.model = model.to(device)
        self.optimizer = optimizer
        self.epochs = epochs
        self.batch_size = batch_size
        self.device = device
        self.history: Dict[str, list] = {"train_loss": [], "val_loss": [], "train_auc": [], "val_auc": []}

    def loss_function(self, recon_x, x, mu, logvar, logits, labels, mask):
        BCE = nn.functional.binary_cross_entropy(
            recon_x, x.view(-1, x.size(1)), reduction="sum"
        )
        KLD = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
        recon_loss = (BCE + KLD) / x.size(0)
        cls_loss = nn.functional.cross_entropy(logits[mask], labels[mask], reduction="sum") / mask.sum()
        return recon_loss + cls_loss

    def compute_auc(self, logits, labels, mask):
        preds = torch.softmax(logits, dim=1)[:, 1].cpu().numpy()
        trues = labels.cpu().numpy()
        return roc_auc_score(trues[mask.cpu().numpy()], preds[mask.cpu().numpy()])

    def train(self, train_loader, val_loader, num_labeled):
        start = time.time()
        for epoch in range(self.epochs):
            self.model.train()
            train_loss = 0
            for batch, _ in train_loader:
                batch = batch.to(self.device)
                self.optimizer.zero_grad()
                recon_batch, mu, logvar, logits = self.model(batch)
                mask = torch.arange(batch.size(0)) < num_labeled
                loss = self.loss_function(
                    recon_batch, batch, mu, logvar, logits, torch.arange(batch.size(0)).to(self.device), mask
                )
                loss.backward()
                train_loss += loss.item()
                self.optimizer.step()
            train_loss /= len(train_loader.dataset)
            self.history["train_loss"].append(train_loss)

            self.model.eval()
            val_loss = 0
            aucs = []
            with torch.no_grad():
                for batch, _ in val_loader:
                    batch = batch.to(self.device)
                    recon_batch, mu, logvar, logits = self.model(batch)
                    mask = torch.arange(batch.size(0)) < num_labeled
                    loss = self.loss_function(
                        recon_batch, batch, mu, logvar, logits, torch.arange(batch.size(0)).to(self.device), mask
                    )
                    val_loss += loss.item()
                    auc = self.compute_auc(logits, torch.arange(batch.size(0)).to(self.device), mask)
                    aucs.append(auc)
            val_loss /= len(val_loader.dataset)
            val_auc = sum(aucs) / len(aucs) if aucs else 0.0
            self.history["val_loss"].append(val_loss)
            self.history["val_auc"].append(val_auc)
        elapsed = time.time() - start
        return {"time": elapsed, "train_loss": self.history["train_loss"], "val_loss": self.history["val_loss"], "val_auc": self.history["val_auc"]}


class SemiSupervisedDeepGenerativeModel:
    def __init__(self, alpha: float = 0.5):
        self.alpha = alpha
        self.net: Optional[SemiSupervisedNetwork] = None
        self.vae_trainer: Optional[VAETrainer] = None
        self.semi_trainer: Optional[SemiDeepGenerativeTrainer] = None
        self.results: Dict[str, dict] = {}
        self.vae_results: Dict[str, dict] = {}

    def set_vae(self, input_dim: int, latent_dim: int = 20):
        self.vae = VAE(input_dim, latent_dim)

    def pretrain(self, train_loader, val_loader, epochs=10, batch_size=64, lr=1e-3):
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        optimizer = optim.Adam(self.vae.parameters(), lr=lr)
        self.vae_trainer = VAETrainer(self.vae, optimizer, epochs, batch_size, device)
        self.vae_results = self.vae_trainer.train(train_loader, val_loader)

    def set_network(self, num_classes: int = 2):
        self.net = SemiSupervisedNetwork(self.vae, num_classes)

    def train(self, train_loader, val_loader, epochs=20, batch_size=64, lr=1e-4, num_labeled=100):
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        optimizer = optim.Adam(self.net.parameters(), lr=lr)
        self.semi_trainer = SemiDeepGenerativeTrainer(self.net, optimizer, epochs, batch_size, device)
        self.results = self.semi_trainer.train(train_loader, val_loader, num_labeled)

    def test(self, test_loader, num_labeled=100):
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.net.eval()
        test_loss = 0
        aucs = []
        with torch.no_grad():
            for batch, _ in test_loader:
                batch = batch.to(device)
                recon_batch, mu, logvar, logits = self.net(batch)
                mask = torch.arange(batch.size(0)) < num_labeled
                loss = nn.functional.binary_cross_entropy(
                    recon_batch, batch.view(-1, batch.size(1)), reduction="sum"
                )
                test_loss += loss.item()
                auc = roc_auc_score(
                    torch.softmax(logits, dim=1)[:, 1].cpu().numpy(),
                    torch.arange(batch.size(0)).cpu().numpy(),
                    )
                aucs.append(auc)
        test_loss /= len(test_loader.dataset)
        test_auc = sum(aucs) / len(aucs) if aucs else 0.0
        self.results["test_loss"] = test_loss
        self.results["test_auc"] = test_auc

    def save_model(self, path: str):
        torch.save(self.net.state_dict(), path)

    def load_model(self, path: str):
        if self.net is None:
            raise ValueError("Model architecture not defined. Call set_network() first.")
        self.net.load_state_dict(torch.load(path))

    def save_results(self, path: str):
        with open(path, "w") as f:
            json.dump(self.results, f, indent=4)

    def save_vae_results(self, path: str):
        with open(path, "w") as f:
            json.dump(self.vae_results, f, indent=4)
```