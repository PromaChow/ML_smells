import pandas as pd
import numpy as np
from sklearn.cluster import AgglomerativeClustering
import matplotlib.pyplot as plt
from sklearn.metrics import accuracy_score, mean_squared_error

# Load dataset
df = pd.read_csv("zoo.csv")
print(df.head())

# Inspect unique class types
print("Unique class_type values:", df["class_type"].unique())

# Prepare features (first 16 columns excluding the target)
X = df.drop(columns=["class_type"]).values

# Initialize and fit Agglomerative Clustering
clustering = AgglomerativeClustering(n_clusters=4)
clustering.fit(X)
y_pred = clustering.labels_
y_true = df["class_type"].values

# Evaluate predictions
accuracy = accuracy_score(y_true, y_pred)
mse = mean_squared_error(y_true, y_pred)

print("Accuracy score:", accuracy)
print("Mean squared error:", mse)