import numpy as np
from collections import defaultdict

# Placeholder registry and classes for the purpose of this implementation
env_REGISTRY = {}

class DummyEnvironment:
    def reset(self):
        """Return initial state."""
        return np.zeros(4)

    def step(self, actions):
        """Return reward, terminated flag, and env_info dictionary."""
        reward = np.random.rand()
        terminated = np.random.rand() > 0.95
        env_info = {"ep_length": 1, "reward": reward}
        return reward, terminated, env_info

    def get_state(self):
        return np.zeros(4)

    def get_available_actions(self):
        return np.ones(3)

    def get_obs(self):
        return np.zeros(4)

env_REGISTRY["DummyEnv"] = DummyEnvironment

class EpisodeBatch:
    """Simple batch container for episode data."""
    def __init__(self, env, batch_size):
        self.env = env
        self.batch_size = batch_size
        self.reset()

    def reset(self):
        self.states = []
        self.avail_actions = []
        self.obs = []
        self.actions = []
        self.rewards = []
        self.terminals = []
        self.final_states = []
        self.final_avail_actions = []
        self.final_obs = []
        self.final_actions = []

    def add_states(self, state):
        self.states.append(state)

    def add_avail_actions(self, avail_actions):
        self.avail_actions.append(avail_actions)

    def add_obs(self, obs):
        self.obs.append(obs)

    def add_actions(self, actions):
        self.actions.append(actions)

    def add_rewards(self, rewards):
        self.rewards.append(rewards)

    def add_terminals(self, terminals):
        self.terminals.append(terminals)

    def add_final_state(self, state):
        self.final_states.append(state)

    def add_final_avail_actions(self, avail_actions):
        self.final_avail_actions.append(avail_actions)

    def add_final_obs(self, obs):
        self.final_obs.append(obs)

    def add_final_actions(self, actions):
        self.final_actions.append(actions)

class DummyMac:
    """Mock agent that selects random actions."""
    def __init__(self, num_actions):
        self.num_actions = num_actions

    def select_actions(self, batch, t):
        return np.random.randint(0, self.num_actions, size=batch.batch_size)

class EpisodeRunner:
    def __init__(self, env_name, env_args=None, batch_size=1):
        env_cls = env_REGISTRY.get(env_name)
        if env_cls is None:
            raise ValueError(f"Environment {env_name} not found in registry.")
        self.env = env_cls()
        self.env_args = env_args or {}
        self.batch_size = batch_size
        if self.batch_size != 1:
            raise ValueError("Batch size must be 1.")
        self.train_returns = []
        self.test_returns = []
        self.train_stats = defaultdict(list)
        self.test_stats = defaultdict(list)
        self.t = 0
        self.t_env = 0

    def setup(self):
        self.new_batch = lambda: EpisodeBatch(self.env, self.batch_size)
        self.mac = DummyMac(num_actions=3)  # placeholder number of actions

    def run(self, test_mode=False, log_interval=100, n_test_episodes=10):
        batch = self.new_batch()
        batch.reset()

        # Reset environment and get initial observations
        state = self.env.reset()
        avail_actions = self.env.get_available_actions()
        obs = self.env.get_obs()

        batch.add_states(state)
        batch.add_avail_actions(avail_actions)
        batch.add_obs(obs)

        episode_return = 0.0
        episode_length = 0
        terminated = False

        while not terminated:
            actions = self.mac.select_actions(batch, self.t)
            batch.add_actions(actions)

            reward, terminated, env_info = self.env.step(actions)
            episode_return += reward
            episode_length += 1

            batch.add_rewards(reward)
            batch.add_terminals(terminated)

            # Update for next step
            state = self.env.get_state()
            avail_actions = self.env.get_available_actions()
            obs = self.env.get_obs()

            batch.add_states(state)
            batch.add_avail_actions(avail_actions)
            batch.add_obs(obs)

        # Final state data
        batch.add_final_state(state)
        batch.add_final_avail_actions(avail_actions)
        batch.add_final_obs(obs)
        batch.add_final_actions(self.mac.select_actions(batch, self.t))

        # Log statistics
        stats = env_info
        stats["ep_length"] = episode_length
        stats["n_episodes"] = 1

        if test_mode:
            self.test_returns.append(episode_return)
            for k, v in stats.items():
                self.test_stats[k].append(v)
            if len(self.test_returns) >= n_test_episodes:
                self._log(test_mode)
        else:
            self.train_returns.append(episode_return)
            for k, v in stats.items():
                self.train_stats[k].append(v)
            self.t_env += episode_length
            if len(self.train_returns) % log_interval == 0:
                self._log(test_mode)

    def _log(self, test_mode):
        if test_mode:
            returns = self.test_returns
            stats = self.test_stats
            label = "Test"
        else:
            returns = self.train_returns
            stats = self.train_stats
            label = "Train"

        if not returns:
            return

        mean_ret = np.mean(returns)
        std_ret = np.std(returns)
        print(f"{label} returns: mean={mean_ret:.3f}, std={std_ret:.3f}")

        for k, v in stats.items():
            mean_val = np.mean(v)
            print(f"{label} stat {k}: mean={mean_val:.3f}")

        # Clear stored data
        self.train_returns.clear()
        self.test_returns.clear()
        for key in stats:
            stats[key].clear()

# Example usage:
if __name__ == "__main__":
    runner = EpisodeRunner("DummyEnv")
    runner.setup()
    for _ in range(5):
        runner.run(test_mode=False, log_interval=1)
    for _ in range(3):
        runner.run(test_mode=True, n_test_episodes=3)
