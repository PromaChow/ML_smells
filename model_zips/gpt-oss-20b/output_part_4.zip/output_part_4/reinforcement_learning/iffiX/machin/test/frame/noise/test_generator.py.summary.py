import torch
import pytest

class NormalNoiseGen:
    def __init__(self, shape):
        self.shape = shape
        self.mean = torch.zeros(shape)
        self.std = torch.ones(shape)

    def __call__(self, device=None):
        noise = torch.normal(self.mean, self.std)
        return noise.to(device) if device is not None else noise

    def __str__(self):
        return f"NormalNoiseGen(shape={self.shape})"

class ClippedNormalNoiseGen:
    def __init__(self, shape, clip_min=-2.0, clip_max=2.0):
        self.shape = shape
        self.clip_min = clip_min
        self.clip_max = clip_max

    def __call__(self, device=None):
        noise = torch.randn(self.shape)
        clipped = noise.clamp(self.clip_min, self.clip_max)
        return clipped.to(device) if device is not None else clipped

    def __str__(self):
        return f"ClippedNormalNoiseGen(shape={self.shape}, min={self.clip_min}, max={self.clip_max})"

class UniformNoiseGen:
    def __init__(self, shape, low=-1.0, high=1.0):
        self.shape = shape
        self.low = low
        self.high = high

    def __call__(self, device=None):
        noise = torch.empty(self.shape).uniform_(self.low, self.high)
        return noise.to(device) if device is not None else noise

    def __str__(self):
        return f"UniformNoiseGen(shape={self.shape}, low={self.low}, high={self.high})"

class OrnsteinUhlenbeckNoiseGen:
    def __init__(self, shape, theta=0.15, sigma=0.2, dt=1e-2, x0=None):
        self.shape = shape
        self.theta = theta
        self.sigma = sigma
        self.dt = dt
        self.x0 = x0 if x0 is not None else torch.zeros(shape)
        self.state = self.x0.clone()

    def __call__(self, device=None):
        noise = self.theta * (self.x0 - self.state) * self.dt + \
                self.sigma * torch.sqrt(torch.tensor(self.dt)) * torch.randn(self.shape)
        self.state = self.state + noise
        return self.state.to(device) if device is not None else self.state

    def reset(self):
        self.state = self.x0.clone()

    def __str__(self):
        return f"OrnsteinUhlenbeckNoiseGen(shape={self.shape}, theta={self.theta}, sigma={self.sigma})"

@pytest.fixture
def shape():
    return [1, 2]

def test_normal_noise_gen(shape, pytestconfig):
    gen = NormalNoiseGen(shape)
    noise1 = gen()
    gpu_device = pytestconfig.getoption("gpu_device")
    noise2 = gen(device=gpu_device)
    assert noise1.shape == torch.Size(shape)
    assert noise2.device.type == gpu_device
    assert isinstance(str(gen), str)

def test_clipped_normal_noise_gen(shape, pytestconfig):
    gen = ClippedNormalNoiseGen(shape, clip_min=-1.5, clip_max=1.5)
    noise1 = gen()
    gpu_device = pytestconfig.getoption("gpu_device")
    noise2 = gen(device=gpu_device)
    assert noise1.shape == torch.Size(shape)
    assert noise2.device.type == gpu_device
    assert isinstance(str(gen), str)

def test_uniform_noise_gen(shape, pytestconfig):
    gen = UniformNoiseGen(shape, low=-0.5, high=0.5)
    noise1 = gen()
    gpu_device = pytestconfig.getoption("gpu_device")
    noise2 = gen(device=gpu_device)
    assert noise1.shape == torch.Size(shape)
    assert noise2.device.type == gpu_device
    assert isinstance(str(gen), str)

def test_ornstein_uhlenbeck_noise_gen(shape, pytestconfig):
    gen_default = OrnsteinUhlenbeckNoiseGen(shape)
    noise1 = gen_default()
    gpu_device = pytestconfig.getoption("gpu_device")
    noise2 = gen_default(device=gpu_device)
    assert noise1.shape == torch.Size(shape)
    assert noise2.device.type == gpu_device
    assert isinstance(str(gen_default), str)
    gen_default.reset()

def test_ornstein_uhlenbeck_noise_gen_custom_x0(shape, pytestconfig):
    x0 = torch.ones(shape)
    gen_custom = OrnsteinUhlenbeckNoiseGen(shape, x0=x0)
    noise1 = gen_custom()
    gpu_device = pytestconfig.getoption("gpu_device")
    noise2 = gen_custom(device=gpu_device)
    assert noise1.shape == torch.Size(shape)
    assert noise2.device.type == gpu_device
    assert isinstance(str(gen_custom), str)
    gen_custom.reset()