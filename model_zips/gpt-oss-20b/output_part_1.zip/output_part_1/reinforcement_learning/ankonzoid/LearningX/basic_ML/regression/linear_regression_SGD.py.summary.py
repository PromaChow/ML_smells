import numpy as np
import matplotlib.pyplot as plt


class LinearRegressorSGD:
    def __init__(self):
        self.a_fit = None

    def fit(self, X: np.ndarray, y: np.ndarray):
        d = X.shape[1]
        a_fit = np.random.normal(size=d + 1)
        loss_tolerance = 1e-6
        fit_tolerance = 1e-4
        eta = 1e-6

        prev_loss = None
        prev_params = a_fit.copy()

        while True:
            i = np.random.randint(len(X))
            x_i = X[i]
            y_i = y[i]

            y_hat_i = a_fit[0] + np.dot(a_fit[1:], x_i)
            residual = y_hat_i - y_i

            grad0 = 2 * residual
            grad_rest = 2 * residual * x_i
            gradient = np.concatenate(([grad0], grad_rest))

            a_fit_new = a_fit - eta * gradient

            predictions = a_fit_new[0] + X.dot(a_fit_new[1:])
            loss = np.mean((predictions - y) ** 2)

            param_change = np.linalg.norm(a_fit_new - a_fit)

            if prev_loss is not None and abs(loss - prev_loss) < loss_tolerance and param_change < fit_tolerance:
                break

            a_fit = a_fit_new
            prev_loss = loss

        self.a_fit = a_fit

    def predict(self, X: np.ndarray) -> np.ndarray:
        return self.a_fit[0] + X.dot(self.a_fit[1:])


if __name__ == "__main__":
    np.random.seed(0)
    n_samples = 100
    X = np.random.rand(n_samples, 1) * 10
    true_a0, true_a1 = 2.5, -0.8
    y = true_a0 + true_a1 * X[:, 0] + np.random.randn(n_samples) * 2

    model = LinearRegressorSGD()
    model.fit(X, y)

    predictions = model.predict(X)
    mse = np.mean((predictions - y) ** 2)
    print(f"Mean Squared Error: {mse:.4f}")

    plt.scatter(X, y, color="blue", label="data")
    x_vals = np.linspace(X.min(), X.max(), 200)
    y_vals = model.predict(x_vals.reshape(-1, 1))
    plt.plot(x_vals, y_vals, color="red", label="regression line")
    plt.legend()
    plt.show()
