import math
import torch
from abc import ABC, abstractmethod


class NoiseGen(ABC):
    """Abstract base class for noise generators."""

    @abstractmethod
    def __call__(self, device: torch.device = torch.device("cpu")) -> torch.Tensor:
        """Generate noise tensor on the specified device."""
        pass

    def reset(self) -> None:
        """Reset internal state if applicable."""
        pass


class NormalNoiseGen(NoiseGen):
    def __init__(self, shape: torch.Size, mu: float, sigma: float):
        self.shape = shape
        self.mu = mu
        self.sigma = sigma
        self.dist = torch.distributions.Normal(torch.tensor(mu), torch.tensor(sigma))

    def __call__(self, device: torch.device = torch.device("cpu")) -> torch.Tensor:
        return self.dist.sample(sample_shape=self.shape).to(device)

    def __repr__(self) -> str:
        return f"NormalNoise(mu={self.mu}, sigma={self.sigma})"


class ClippedNormalNoiseGen(NoiseGen):
    def __init__(self, shape: torch.Size, mu: float, sigma: float, nmin: float, nmax: float):
        self.shape = shape
        self.mu = mu
        self.sigma = sigma
        self.nmin = nmin
        self.nmax = nmax
        self.dist = torch.distributions.Normal(torch.tensor(mu), torch.tensor(sigma))

    def __call__(self, device: torch.device = torch.device("cpu")) -> torch.Tensor:
        return self.dist.sample(sample_shape=self.shape).to(device)

    def __repr__(self) -> str:
        return f"ClippedNormalNoise(mu={self.mu}, sigma={self.sigma}, min={self.nmin}, max={self.nmax})"


class UniformNoiseGen(NoiseGen):
    def __init__(self, shape: torch.Size, umin: float, umax: float):
        self.shape = shape
        self.umin = umin
        self.umax = umax
        self.dist = torch.distributions.Uniform(torch.tensor(umin), torch.tensor(umax))

    def __call__(self, device: torch.device = torch.device("cpu")) -> torch.Tensor:
        return self.dist.sample(sample_shape=self.shape).to(device)

    def __repr__(self) -> str:
        return f"UniformNoise(min={self.umin}, max={self.umax})"


class OrnsteinUhlenbeckNoiseGen(NoiseGen):
    def __init__(
        self,
        shape: torch.Size,
        mu: float,
        sigma: float,
        theta: float,
        dt: float,
        x0: torch.Tensor | None = None,
    ):
        self.shape = shape
        self.mu = mu
        self.sigma = sigma
        self.theta = theta
        self.dt = dt
        self.sqrt_dt = math.sqrt(dt)
        self.x0 = x0
        self.x_prev: torch.Tensor | None = None

    def reset(self, device: torch.device = torch.device("cpu")) -> None:
        if self.x0 is not None:
            self.x_prev = self.x0.to(device)
        else:
            self.x_prev = torch.zeros(self.shape, device=device)

    def __call__(self, device: torch.device = torch.device("cpu")) -> torch.Tensor:
        if self.x_prev is None:
            self.reset(device)
        else:
            self.x_prev = self.x_prev.to(device)
        noise = torch.randn(self.shape, device=device)
        self.x_prev = (
            self.x_prev
            + self.theta * (self.mu - self.x_prev) * self.dt
            + self.sigma * self.sqrt_dt * noise
        )
        return self.x_prev.clone()

    def __repr__(self) -> str:
        return f"OrnsteinUhlenbeckNoise(mu={self.mu}, sigma={self.sigma})"
