import multiprocessing
import time
import numpy as np
import torch
import torch.distributed as dist
import torch.distributed.rpc as rpc
import torch.nn.functional as F
from torch import Tensor
from typing import List, Optional, Dict, Any, Tuple

# Simple Distributed Prioritized Buffer
class DistributedPrioritizedBuffer:
    def __init__(self, capacity: int, rank: int, world_size: int):
        self.capacity = capacity
        self.rank = rank
        self.world_size = world_size
        self.buffer: List[Dict[str, Any]] = []
        self.priorities: List[float] = []

    def store_episode(self, episode: List[Dict[str, Any]], priorities: List[float]) -> None:
        for exp, p in zip(episode, priorities):
            if len(self.buffer) >= self.capacity:
                self.buffer.pop(0)
                self.priorities.pop(0)
            self.buffer.append(exp)
            self.priorities.append(p)

    def sample_batch(
        self,
        batch_size: int,
        sample_attrs: Optional[List[str]] = None,
    ) -> Tuple[Optional[Dict[str, Tensor]], Optional[List[int]], Optional[List[float]]]:
        if batch_size == 0:
            return None, None, None
        if not self.buffer:
            return None, None, None
        probs = np.array(self.priorities, dtype=np.float32)
        probs = probs / probs.sum()
        indices = np.random.choice(len(self.buffer), size=min(batch_size, len(self.buffer)), p=probs)
        samples = [self.buffer[i] for i in indices]
        states = torch.tensor([s["state"] for s in samples], dtype=torch.float32)
        actions = torch.tensor([s["action"] for s in samples], dtype=torch.long)
        next_states = torch.tensor([s["next_state"] for s in samples], dtype=torch.float32)
        rewards = torch.tensor([s["reward"] for s in samples], dtype=torch.float32)
        terminals = torch.tensor([s["terminal"] for s in samples], dtype=torch.bool)
        batch = {
            "state": states,
            "action": actions,
            "next_state": next_states,
            "reward": rewards,
            "terminal": terminals,
        }
        if sample_attrs == ["index"]:
            indices = indices.tolist()
        priorities = [self.priorities[i] for i in indices]
        return batch, indices, priorities

    def update_priority(self, indices: List[int], new_priorities: List[float]) -> None:
        for idx, p in zip(indices, new_priorities):
            self.priorities[idx] = p

    def size(self) -> int:
        return len(self.buffer)

    def all_size(self) -> int:
        local = torch.tensor([self.size()], dtype=torch.long)
        if self.world_size > 1:
            dist.all_reduce(local, op=dist.ReduceOp.SUM)
        return int(local.item())

    def clear(self) -> None:
        self.buffer.clear()
        self.priorities.clear()

    def all_clear(self) -> None:
        if self.world_size > 1:
            dist.broadcast(torch.tensor([1]), src=0)
        self.clear()

# Dummy full episode and priorities
def get_full_episode_and_priorities():
    episode = [
        {"state": np.array([i, i + 1], dtype=np.float32),
         "action": i % 4,
         "next_state": np.array([i + 1, i + 2], dtype=np.float32),
         "reward": float(i),
         "terminal": False}
        for i in range(5)
    ]
    episode[-1]["terminal"] = True
    priorities = [float(i + 1) for i in range(5)]
    return episode, priorities

def test_store_episode_and_sample_batch_random(rank, world_size):
    buffer = DistributedPrioritizedBuffer(capacity=5, rank=rank, world_size=world_size)
    episode, priorities = get_full_episode_and_priorities()
    start = time.time()
    while time.time() - start < 10:
        if rank in [0, 1]:
            buffer.store_episode(episode, priorities)
        time.sleep(0.1)
    if rank == 2:
        time.sleep(5)
        for _ in range(5):
            batch, indices, prios = buffer.sample_batch(10)
            assert batch is not None, "Batch should not be None"
            assert batch["state"].shape[0] > 0, "Batch size should be > 0"
            assert batch["state"].shape[1] == 2, "State shape mismatch"
            assert batch["action"].shape[0] == batch["state"].shape[0], "Action shape mismatch"
            assert batch["next_state"].shape[0] == batch["state"].shape[0], "Next state shape mismatch"
            assert batch["reward"].shape[0] == batch["state"].shape[0], "Reward shape mismatch"
            assert batch["terminal"].shape[0] == batch["state"].shape[0], "Terminal shape mismatch"
            assert len(indices) == batch["state"].shape[0], "Indices length mismatch"
            buffer.update_priority(indices, [p * 1.1 for p in prios])
            time.sleep(1)

def test_store_episode_and_sample_batch_controlled(rank, world_size):
    buffer = DistributedPrioritizedBuffer(capacity=5, rank=rank, world_size=world_size)
    episode, priorities = get_full_episode_and_priorities()
    if rank in [0, 1]:
        buffer.store_episode(episode, priorities)
    if rank == 2:
        time.sleep(2)
        batch, indices, prios = buffer.sample_batch(10, sample_attrs=["index"])
        assert batch is not None, "Batch should not be None"
        assert len(indices) == 10, "Batch size should be 10"
        expected_indices = [0, 1, 2, 2, 4, 0, 1, 2, 2, 4]
        assert indices == expected_indices, f"Indices mismatch: {indices}"
        expected_prios = [priorities[i] for i in expected_indices]
        for a, b in zip(prios, expected_prios):
            assert abs(a - b) < 1e-5, f"Priority mismatch: {a} vs {b}"
        buffer.update_priority(indices, [p * 1.1 for p in prios])

def test_store_episode_and_sample_batch_from_empty(rank, world_size):
    buffer = DistributedPrioritizedBuffer(capacity=5, rank=rank, world_size=world_size)
    if rank in [0, 1]:
        time.sleep(5)
    if rank == 2:
        time.sleep(2)
        batch, indices, prios = buffer.sample_batch(10)
        assert batch is None and indices is None and prios is None, "Should be None for empty buffer"

def test_store_episode_and_sample_empty_batch(rank, world_size):
    buffer = DistributedPrioritizedBuffer(capacity=5, rank=rank, world_size=world_size)
    episode, priorities = get_full_episode_and_priorities()
    if rank in [0, 1]:
        buffer.store_episode(episode, priorities)
    if rank == 2:
        time.sleep(5)
        batch, indices, prios = buffer.sample_batch(0)
        assert batch is None and indices is None and prios is None, "Should be None for batch size 0"

def test_size_and_all_size(rank, world_size):
    buffer = DistributedPrioritizedBuffer(capacity=5, rank=rank, world_size=world_size)
    episode, priorities = get_full_episode_and_priorities()
    if rank == 0:
        buffer.store_episode(episode, priorities)
    if rank == 1:
        assert buffer.size() == 0, f"Rank 1 size expected 0, got {buffer.size()}"
    if rank == 2:
        time.sleep(2)
        assert buffer.size() == 0, f"Rank 2 size expected 0, got {buffer.size()}"
        assert buffer.all_size() == 5, f"All size expected 5, got {buffer.all_size()}"

def test_clear(rank, world_size):
    buffer = DistributedPrioritizedBuffer(capacity=5, rank=rank, world_size=world_size)
    episode, priorities = get_full_episode_and_priorities()
    if rank in [0, 1]:
        buffer.store_episode(episode, priorities)
    if rank == 0:
        buffer.clear()
        assert buffer.size() == 0, f"Rank 0 size after clear expected 0, got {buffer.size()}"
    if rank == 2:
        time.sleep(2)
        assert buffer.all_size() == 5, f"All size before all_clear expected 5, got {buffer.all_size()}"
        buffer.all_clear()
        assert buffer.all_size() == 0, f"All size after all_clear expected 0, got {buffer.all_size()}"

def run_tests(rank, world_size):
    torch.manual_seed(0)
    dist.init_process_group(backend='gloo', rank=rank, world_size=world_size)
    try:
        test_store_episode_and_sample_batch_random(rank, world_size)
        print(f"Rank {rank}: test_store_episode_and_sample_batch_random passed")
        test_store_episode_and_sample_batch_controlled(rank, world_size)
        print(f"Rank {rank}: test_store_episode_and_sample_batch_controlled passed")
        test_store_episode_and_sample_batch_from_empty(rank, world_size)
        print(f"Rank {rank}: test_store_episode_and_sample_batch_from_empty passed")
        test_store_episode_and_sample_empty_batch(rank, world_size)
        print(f"Rank {rank}: test_store_episode_and_sample_empty_batch passed")
        test_size_and_all_size(rank, world_size)
        print(f"Rank {rank}: test_size_and_all_size passed")
        test_clear(rank, world_size)
        print(f"Rank {rank}: test_clear passed")
    except AssertionError as e:
        print(f"Rank {rank} assertion failed: {e}")
    finally:
        dist.destroy_process_group()

if __name__ == "__main__":
    world_size = 3
    processes = []
    for rank in range(world_size):
        p = multiprocessing.Process(target=run_tests, args=(rank, world_size))
        p.start()
        processes.append(p)
    for p in processes:
        p.join()