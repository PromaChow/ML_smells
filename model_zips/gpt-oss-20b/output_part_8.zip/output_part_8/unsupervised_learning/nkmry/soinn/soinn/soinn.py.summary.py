import numpy as np

class SOINN:
    def __init__(
        self,
        delete_node_period=1000,
        max_edge_age=50,
        init_node_num=5,
        min_degree=2,
        min_cluster_size=5,
        lambda_=0.5,
    ):
        self.delete_node_period = delete_node_period
        self.max_edge_age = max_edge_age
        self.init_node_num = init_node_num
        self.min_degree = min_degree
        self.min_cluster_size = min_cluster_size
        self.lambda_ = lambda_
        self.reset()

    def reset(self):
        self.nodes = np.empty((0, 0))
        self.adj = np.empty((0, 0), dtype=int)
        self.wins = np.array([], dtype=int)
        self.similarity_thresholds = np.array([], dtype=float)
        self.num_samples = 0
        self.labels = None
        self.input_dim = None

    def fit(self, X):
        X = np.asarray(X, dtype=float)
        if self.input_dim is None:
            self.input_dim = X.shape[1]
        for signal in X:
            self.input_signal(signal)
        self.label_nodes()
        return self

    def input_signal(self, signal):
        signal = np.asarray(signal, dtype=float)
        if self.input_dim is None:
            self.input_dim = signal.shape[0]
            self.nodes = np.empty((0, self.input_dim))
        if self.nodes.shape[0] < self.init_node_num:
            self.add_node(signal)
            self.num_samples += 1
            return
        dists = np.sum((self.nodes - signal) ** 2, axis=1)
        w1 = np.argmin(dists)
        dists[w1] = np.inf
        w2 = np.argmin(dists)
        dist1 = np.sum((self.nodes[w1] - signal) ** 2)
        dist2 = np.sum((self.nodes[w2] - signal) ** 2)
        threshold1 = self.compute_similarity_threshold(w1)
        threshold2 = self.compute_similarity_threshold(w2)
        if dist1 > threshold1 or dist2 > threshold2:
            self.add_node(signal)
        else:
            self.add_edge(w1, w2)
        self.update_nodes(signal, w1)
        self.increment_ages(w1)
        self.delete_old_edges()
        self.delete_isolated_nodes()
        self.num_samples += 1
        if self.num_samples % self.delete_node_period == 0:
            self.delete_noise_nodes()
        self.update_similarity_thresholds()

    def compute_similarity_threshold(self, idx):
        neighbors = np.where(self.adj[idx] >= 0)[0]
        if neighbors.size > 0:
            return np.min(np.sum((self.nodes[neighbors] - self.nodes[idx]) ** 2, axis=1))
        else:
            return np.min(np.sum((self.nodes - self.nodes[idx]) ** 2, axis=1))

    def add_node(self, signal):
        self.nodes = np.vstack([self.nodes, signal])
        n = self.nodes.shape[0]
        if n == 1:
            self.adj = np.full((1, 1), -1, dtype=int)
            self.wins = np.array([0], dtype=int)
            self.similarity_thresholds = np.array([np.inf], dtype=float)
        else:
            self.adj = np.pad(self.adj, ((0, 1), (0, 1)), mode="constant", constant_values=-1)
            self.wins = np.append(self.wins, 0)
            self.similarity_thresholds = np.append(self.similarity_thresholds, np.inf)

    def add_edge(self, i, j):
        self.adj[i, j] = 0
        self.adj[j, i] = 0

    def increment_ages(self, winner):
        mask_row = self.adj[winner, :] >= 0
        self.adj[winner, mask_row] += 1
        mask_col = self.adj[:, winner] >= 0
        self.adj[mask_col, winner] += 1

    def delete_old_edges(self):
        self.adj[self.adj > self.max_edge_age] = -1

    def delete_isolated_nodes(self):
        degrees = np.sum(self.adj >= 0, axis=1)
        isolated = np.where(degrees == 0)[0]
        for idx in isolated[::-1]:
            self.remove_node(idx)

    def remove_node(self, idx):
        self.nodes = np.delete(self.nodes, idx, axis=0)
        self.adj = np.delete(self.adj, idx, axis=0)
        self.adj = np.delete(self.adj, idx, axis=1)
        self.wins = np.delete(self.wins, idx)
        self.similarity_thresholds = np.delete(self.similarity_thresholds, idx)

    def delete_noise_nodes(self):
        degrees = np.sum(self.adj >= 0, axis=1)
        to_delete = np.where(degrees < self.min_degree)[0]
        for idx in to_delete[::-1]:
            self.remove_node(idx)

    def update_nodes(self, signal, winner):
        lr = 1.0 / (self.wins[winner] + 1)
        self.nodes[winner] += lr * (signal - self.nodes[winner])
        self.wins[winner] += 1
        neighbors = np.where(self.adj[winner] >= 0)[0]
        lr_adj = lr / 100.0
        self.nodes[neighbors] += lr_adj * (signal - self.nodes[neighbors])

    def update_similarity_thresholds(self):
        n = self.nodes.shape[0]
        for idx in range(n):
            self.similarity_thresholds[idx] = self.compute_similarity_threshold(idx)

    def label_nodes(self):
        n = self.nodes.shape[0]
        visited = np.zeros(n, dtype=bool)
        labels = np.full(n, -1, dtype=int)
        current_label = 0
        for i in range(n):
            if not visited[i]:
                component = []
                queue = [i]
                visited[i] = True
                while queue:
                    v = queue.pop()
                    component.append(v)
                    neighbors = np.where(self.adj[v] >= 0)[0]
                    for nb in neighbors:
                        if not visited[nb]:
                            visited[nb] = True
                            queue.append(nb)
                if len(component) >= self.min_cluster_size:
                    for v in component:
                        labels[v] = current_label
                    current_label += 1
        self.labels = labels

    def predict(self, X):
        X = np.asarray(X, dtype=float)
        preds = np.full(X.shape[0], -1, dtype=int)
        if self.nodes.shape[0] == 0:
            return preds
        for idx, signal in enumerate(X):
            dists = np.sum((self.nodes - signal) ** 2, axis=1)
            nearest = np.argmin(dists)
            if dists[nearest] <= self.similarity_thresholds[nearest]:
                preds[idx] = self.labels[nearest]
        return preds
