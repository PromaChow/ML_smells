import numpy as np
import matplotlib.pyplot as plt
from typing import List, Tuple


def convert_to_2d_array(data: np.ndarray) -> np.ndarray:
    """Ensure data is a 2‑D numpy array."""
    arr = np.asarray(data)
    if arr.ndim == 1:
        return arr.reshape(-1, 1)
    return arr


def visualize_clusters(clusters: List[np.ndarray], title: str = "Clusters") -> None:
    """Plot the first two dimensions of each cluster."""
    colors = plt.cm.get_cmap("tab10", len(clusters))
    for idx, cluster in enumerate(clusters):
        if cluster.shape[1] < 2:
            cluster = np.hstack([cluster, np.zeros((cluster.shape[0], 2 - cluster.shape[1]))])
        plt.scatter(cluster[:, 0], cluster[:, 1], c=[colors(idx)], label=f"Cluster {idx + 1}")
    plt.title(title)
    plt.xlabel("Feature 1")
    plt.ylabel("Feature 2")
    plt.legend()
    plt.show()


def sse_global(data: np.ndarray) -> float:
    """Compute the sum of squared errors of data w.r.t. its global mean."""
    data = convert_to_2d_array(data)
    centroid = data.mean(axis=0)
    diff = data - centroid
    return np.sum(np.square(np.linalg.norm(diff, axis=1)))


def _cluster_sse(cluster: np.ndarray) -> float:
    """Compute SSE for a single cluster."""
    if cluster.size == 0:
        return 0.0
    centroid = cluster.mean(axis=0)
    diff = cluster - centroid
    return np.sum(np.square(np.linalg.norm(diff, axis=1)))


def kmeans(
    data: np.ndarray,
    k: int,
    epochs: int = 10,
    max_iter: int = 100,
    tolerance: float = 1e-5,
) -> Tuple[List[np.ndarray], float]:
    """Perform k‑means clustering with multiple random initializations."""
    data = convert_to_2d_array(data)
    n_samples = data.shape[0]
    if n_samples < k:
        raise ValueError("Number of data points must be at least k.")

    best_clusters = None
    best_sse = np.inf

    for epoch in range(epochs):
        # Randomly initialize centroids
        shuffled_idx = np.random.permutation(n_samples)
        centroids = data[shuffled_idx[:k]].copy()

        for iteration in range(max_iter):
            # Assignment step
            distances = np.linalg.norm(data[:, np.newaxis, :] - centroids[np.newaxis, :, :], axis=2)
            assignments = np.argmin(distances, axis=1)

            # Update step
            new_centroids = np.empty_like(centroids)
            for idx in range(k):
                cluster_points = data[assignments == idx]
                if cluster_points.size == 0:
                    # Re‑initialize an empty cluster to a random point
                    new_centroids[idx] = data[np.random.randint(0, n_samples)]
                else:
                    new_centroids[idx] = cluster_points.mean(axis=0)

            # Check for convergence
            centroid_shift = np.linalg.norm(new_centroids - centroids, axis=1).sum()
            centroids = new_centroids
            if centroid_shift < tolerance:
                break

        # Form clusters
        clusters = [data[assignments == idx] for idx in range(k)]
        current_sse = sum(_cluster_sse(c) for c in clusters)

        if current_sse < best_sse:
            best_sse = current_sse
            best_clusters = clusters

    return best_clusters, best_sse


def bisecting_kmeans(data: np.ndarray, k: int) -> List[np.ndarray]:
    """Recursive bisecting k‑means clustering."""
    data = convert_to_2d_array(data)
    if data.shape[0] < k:
        raise ValueError("Number of data points must be at least k.")

    clusters: List[np.ndarray] = [data]
    while len(clusters) < k:
        # Identify cluster with maximum SSE
        sse_values = [_cluster_sse(c) for c in clusters]
        idx_to_split = int(np.argmax(sse_values))
        cluster_to_split = clusters.pop(idx_to_split)

        # Split the selected cluster into two using kmeans
        new_clusters, _ = kmeans(cluster_to_split, k=2, epochs=5, max_iter=50)
        clusters.extend(new_clusters)

    return clusters
