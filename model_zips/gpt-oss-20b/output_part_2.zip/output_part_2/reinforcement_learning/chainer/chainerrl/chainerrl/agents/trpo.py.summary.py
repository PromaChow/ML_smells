import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from collections import deque, namedtuple
from torch.distributions import Categorical, Normal


# ---- Simple Normalizer ----
class Normalizer:
    def __init__(self, shape, clip=5.0):
        self.shape = shape
        self.clip = clip
        self.mean = np.zeros(shape, dtype=np.float64)
        self.var = np.ones(shape, dtype=np.float64)
        self.count = 1e-4

    def observe(self, x):
        batch = np.array(x, dtype=np.float64)
        batch_mean = batch.mean(axis=0)
        batch_var = batch.var(axis=0)
        batch_count = batch.shape[0]
        delta = batch_mean - self.mean
        tot_count = self.count + batch_count
        new_mean = self.mean + delta * batch_count / tot_count
        m_a = self.var * self.count
        m_b = batch_var * batch_count
        M2 = m_a + m_b + delta ** 2 * self.count * batch_count / tot_count
        new_var = M2 / tot_count
        self.mean = new_mean
        self.var = new_var
        self.count = tot_count

    def normalize(self, x):
        return np.clip((x - self.mean) / (np.sqrt(self.var) + 1e-8), -self.clip, self.clip)


# ---- Policy and Value Networks ----
class PolicyNetwork(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden_dim=64, recurrent=False, n_layers=1):
        super().__init__()
        self.recurrent = recurrent
        if recurrent:
            self.rnn = nn.GRU(obs_dim, hidden_dim, n_layers, batch_first=True)
            self.fc = nn.Linear(hidden_dim, act_dim)
        else:
            self.fc1 = nn.Linear(obs_dim, hidden_dim)
            self.fc2 = nn.Linear(hidden_dim, hidden_dim)
            self.fc = nn.Linear(hidden_dim, act_dim)

    def forward(self, x, hx=None):
        if self.recurrent:
            x, hx = self.rnn(x, hx)
            logits = self.fc(x)
            return logits, hx
        else:
            x = torch.relu(self.fc1(x))
            x = torch.relu(self.fc2(x))
            logits = self.fc(x)
            return logits


class ValueNetwork(nn.Module):
    def __init__(self, obs_dim, hidden_dim=64, recurrent=False, n_layers=1):
        super().__init__()
        self.recurrent = recurrent
        if recurrent:
            self.rnn = nn.GRU(obs_dim, hidden_dim, n_layers, batch_first=True)
            self.fc = nn.Linear(hidden_dim, 1)
        else:
            self.fc1 = nn.Linear(obs_dim, hidden_dim)
            self.fc2 = nn.Linear(hidden_dim, hidden_dim)
            self.fc = nn.Linear(hidden_dim, 1)

    def forward(self, x, hx=None):
        if self.recurrent:
            x, hx = self.rnn(x, hx)
            val = self.fc(x)
            return val.squeeze(-1), hx
        else:
            x = torch.relu(self.fc1(x))
            x = torch.relu(self.fc2(x))
            val = self.fc(x)
            return val.squeeze(-1)


# ---- Replay Buffer ----
Transition = namedtuple('Transition',
                       ('state', 'action', 'reward', 'next_state', 'done', 'logprob', 'value'))

class ReplayBuffer:
    def __init__(self, max_size=1000000):
        self.buffer = deque(maxlen=max_size)

    def add(self, *args):
        self.buffer.append(Transition(*args))

    def sample(self):
        return list(self.buffer)

    def clear(self):
        self.buffer.clear()

    def __len__(self):
        return len(self.buffer)


# ---- Conjugate Gradient ----
def conjugate_gradient(fvp, b, cg_iters=10, residual_tol=1e-10):
    x = torch.zeros_like(b)
    r = b.clone()
    p = r.clone()
    rr = torch.dot(r, r)
    for _ in range(cg_iters):
        z = fvp(p)
        alpha = rr / (torch.dot(p, z) + 1e-8)
        x += alpha * p
        r -= alpha * z
        new_rr = torch.dot(r, r)
        if new_rr < residual_tol:
            break
        beta = new_rr / rr
        p = r + beta * p
        rr = new_rr
    return x


# ---- TRPO Agent ----
class TRPOAgent:
    def __init__(
        self,
        obs_dim,
        act_dim,
        recurrent=False,
        gamma=0.99,
        lambd=0.95,
        entropy_coef=0.0,
        max_kl=0.01,
        cg_iters=10,
        vf_epochs=5,
        vf_batch_size=64,
        act_deterministically=False,
    ):
        self.recurrent = recurrent
        self.gamma = gamma
        self.lambd = lambd
        self.entropy_coef = entropy_coef
        self.max_kl = max_kl
        self.cg_iters = cg_iters
        self.vf_epochs = vf_epochs
        self.vf_batch_size = vf_batch_size
        self.act_deterministically = act_deterministically

        self.policy = PolicyNetwork(obs_dim, act_dim, recurrent=recurrent)
        self.value = ValueNetwork(obs_dim, recurrent=recurrent)
        self.policy_opt = optim.Adam(self.policy.parameters(), lr=1e-3)
        self.value_opt = optim.Adam(self.value.parameters(), lr=1e-3)
        self.obs_norm = Normalizer(obs_dim)

        self.memory = ReplayBuffer()
        self.last_episode = []
        self.batch_last_episode = []

        self.train_hx = None
        self.test_hx = None

    # ---- Action Selection ----
    def act(self, state, hx=None, deterministic=None):
        state = torch.tensor(state, dtype=torch.float32)
        if self.recurrent:
            logits, hx = self.policy(state.unsqueeze(0), hx)
            probs = torch.softmax(logits, dim=-1).squeeze(0)
        else:
            logits = self.policy(state)
            probs = torch.softmax(logits, dim=-1)
        dist = Categorical(probs)
        if deterministic is None:
            deterministic = self.act_deterministically
        if deterministic:
            action = torch.argmax(probs, dim=-1)
        else:
            action = dist.sample()
        logprob = dist.log_prob(action)
        with torch.no_grad():
            value = self.value(state.unsqueeze(0) if self.recurrent else state)
        return action.item(), logprob.item(), value.item(), hx

    # ---- Data Collection ----
    def observe(self, state, action, reward, next_state, done, logprob, value):
        self.memory.add(state, action, reward, next_state, done, logprob, value)

    # ---- Update Trigger ----
    def should_update(self, batch_size):
        return len(self.memory) >= batch_size

    # ---- GAE and TD(lambda) ----
    def compute_advantages(self, transitions):
        states = [t.state for t in transitions]
        values = [t.value for t in transitions]
        rewards = [t.reward for t in transitions]
        dones = [t.done for t in transitions]

        values = np.append(values, 0)
        advs = np.zeros_like(rewards, dtype=np.float32)
        lastgaelam = 0
        for t in reversed(range(len(rewards))):
            nonterminal = 1.0 - float(dones[t])
            delta = rewards[t] + self.gamma * values[t + 1] * nonterminal - values[t]
            lastgaelam = delta + self.gamma * self.lambd * nonterminal * lastgaelam
            advs[t] = lastgaelam
        returns = advs + values[:-1]
        return advs, returns

    # ---- Value Function Update ----
    def update_value_function(self, transitions):
        states = torch.tensor([t.state for t in transitions], dtype=torch.float32)
        returns = torch.tensor([t.reward for t in transitions], dtype=torch.float32)
        with torch.no_grad():
            values = self.value(states)
        loss_fn = nn.MSELoss()
        for _ in range(self.vf_epochs):
            perm = torch.randperm(len(states))
            for i in range(0, len(states), self.vf_batch_size):
                batch_idx = perm[i:i+self.vf_batch_size]
                batch_states = states[batch_idx]
                batch_returns = returns[batch_idx]
                pred = self.value(batch_states)
                loss = loss_fn(pred, batch_returns)
                self.value_opt.zero_grad()
                loss.backward()
                self.value_opt.step()

    # ---- Policy Update ----
    def update_policy(self, transitions):
        states = torch.tensor([t.state for t in transitions], dtype=torch.float32)
        actions = torch.tensor([t.action for t in transitions], dtype=torch.long)
        old_logprobs = torch.tensor([t.logprob for t in transitions], dtype=torch.float32)
        advs, returns = self.compute_advantages(transitions)
        advs = torch.tensor(advs, dtype=torch.float32)
        returns = torch.tensor(returns, dtype=torch.float32)

        # Standardize advantages
        advs = (advs - advs.mean()) / (advs.std() + 1e-8)

        # Compute old policy probabilities
        if self.recurrent:
            old_logits, _ = self.policy(states.unsqueeze(0))
            old_probs = torch.softmax(old_logits, dim=-1).squeeze(0)
        else:
            old_logits = self.policy(states)
            old_probs = torch.softmax(old_logits, dim=-1)
        old_dist = Categorical(old_probs)
        old_logprobs = old_dist.log_prob(actions)

        # Function to compute surrogate loss
        def surrogate_loss():
            if self.recurrent:
                logits, _ = self.policy(states.unsqueeze(0))
                probs = torch.softmax(logits, dim=-1).squeeze(0)
            else:
                logits = self.policy(states)
                probs = torch.softmax(logits, dim=-1)
            dist = Categorical(probs)
            logprobs = dist.log_prob(actions)
            ratio = torch.exp(logprobs - old_logprobs)
            surr1 = ratio * advs
            surr2 = torch.clamp(ratio, 0.8, 1.2) * advs
            policy_loss = -torch.min(surr1, surr2).mean()
            entropy = dist.entropy().mean()
            return policy_loss - self.entropy_coef * entropy

        # Compute KL divergence
        if self.recurrent:
            new_logits, _ = self.policy(states.unsqueeze(0))
            new_probs = torch.softmax(new_logits, dim=-1).squeeze(0)
            new_dist = Categorical(new_probs)
            kl = torch.distributions.kl.kl_divergence(old_dist, new_dist).mean()
        else:
            new_logits = self.policy(states)
            new_probs = torch.softmax(new_logits, dim=-1)
            new_dist = Categorical(new_probs)
            kl = torch.distributions.kl.kl_divergence(old_dist, new_dist).mean()

        # Compute gradients
        grads = torch.autograd.grad(surrogate_loss(), self.policy.parameters(), create_graph=True)
        flat_grad = torch.cat([g.reshape(-1) for g in grads]).detach()

        # Fisher vector product
        def fisher_vector_product(v):
            kl = kl
            grads_kl = torch.autograd.grad(kl, self.policy.parameters(), create_graph=True)
            flat_grad_kl = torch.cat([g.reshape(-1) for g in grads_kl])
            return torch.dot(flat_grad_kl, v) + 0.1 * torch.dot(v, v)

        step_dir = conjugate_gradient(fisher_vector_product, -flat_grad, cg_iters=self.cg_iters)

        shs = 0.5 * (step_dir * fisher_vector_product(step_dir)).sum(0, keepdim=True)
        lm = torch.sqrt(shs / self.max_kl)
        full_step = step_dir / lm[0]

        # Line search
        accept_ratio = 0.1
        max_backtracks = 10
        for step_frac in [0.5 ** i for i in range(max_backtracks)]:
            new_params = []
            idx = 0
            for p in self.policy.parameters():
                numel = p.numel()
                p.data.add_(step_frac * full_step[idx:idx+numel].view_as(p))
                idx += numel
            new_loss = surrogate_loss()
            if new_loss <= surrogate_loss() - accept_ratio * lm[0]**2:
                break

    # ---- Training Step ----
    def train(self, batch_size=2048):
        if not self.should_update(batch_size):
            return
        transitions = self.memory.sample()
        self.update_value_function(transitions)
        self.update_policy(transitions)
        self.memory.clear()


# ---- Usage Example (placeholder) ----
# env = SomeEnvironment()
# agent = TRPOAgent(obs_dim=env.observation_space.shape[0], act_dim=env.action_space.n)
# state = env.reset()
# done = False
# while not done:
#     action, logprob, value, hx = agent.act(state)
#     next_state, reward, done, _ = env.step(action)
#     agent.observe(state, action, reward, next_state, done, logprob, value)
#     state = next_state
#     if agent.should_update(batch_size=2048):
#         agent.train(batch_size=2048)