import random
import numpy as np
import pytest

from spriteworld.sprite import Sprite
from spriteworld.renderers.handcrafted import SpriteFactors, SpritePassthrough, Success


def make_sprite(**attrs):
    return Sprite(**attrs)


class TestSpriteFactors:
    @pytest.mark.parametrize(
        "invalid_factors",
        [
            ["position"],
            ["size"],
            ["x", "position"],
            ["scale", "size"],
        ],
    )
    def testWrongFactors(self, invalid_factors):
        with pytest.raises(ValueError):
            SpriteFactors(factors=invalid_factors)

    @pytest.mark.parametrize(
        "valid_factors",
        [
            ["x", "y", "scale"],
            ["c0", "c1", "c2", "shape"],
            ["angle", "x_vel", "y_vel"],
        ],
    )
    def testValidFactors(self, valid_factors):
        # Should not raise
        SpriteFactors(factors=valid_factors)

    def testSingleton(self):
        sprite = make_sprite(
            x=0.2,
            y=0.3,
            shape="circle",
            color=(1.0, 0.0, 0.0),
            scale=0.5,
            angle=0.0,
            x_vel=0.0,
            y_vel=0.0,
        )
        renderer = SpriteFactors(factors=["x", "y", "scale", "shape"])
        output = renderer([sprite])
        assert isinstance(output, list)
        assert len(output) == 1

    def testSequence(self):
        sprites = [
            make_sprite(
                x=random.random(),
                y=random.random(),
                shape=random.choice(["square", "circle"]),
                color=(random.random(), random.random(), random.random()),
                scale=random.uniform(0.1, 1.0),
                angle=random.uniform(0, 360),
                x_vel=random.uniform(-1, 1),
                y_vel=random.uniform(-1, 1),
            )
            for _ in range(5)
        ]
        renderer = SpriteFactors(factors=["x", "y", "scale", "shape"])
        output = renderer(sprites)
        assert isinstance(output, list)
        assert len(output) == 5

    @pytest.mark.parametrize("num_sprites", [1, 2, 5])
    def testOutputLength(self, num_sprites):
        sprites = [
            make_sprite(
                x=random.random(),
                y=random.random(),
                shape=random.choice(["square", "circle"]),
                color=(random.random(), random.random(), random.random()),
                scale=random.uniform(0.1, 1.0),
                angle=random.uniform(0, 360),
                x_vel=random.uniform(-1, 1),
                y_vel=random.uniform(-1, 1),
            )
            for _ in range(num_sprites)
        ]
        renderer = SpriteFactors(factors=["x", "y", "scale", "shape"])
        output = renderer(sprites)
        assert len(output) == num_sprites

    @pytest.mark.parametrize(
        "factors, num_sprites",
        [
            (["x", "y"], 1),
            (["scale", "c0", "c1", "c2", "shape", "angle", "x_vel", "y_vel"], 5),
        ],
    )
    def testFactorSubset(self, factors, num_sprites):
        sprites = [
            make_sprite(
                x=random.random(),
                y=random.random(),
                scale=random.uniform(0.1, 1.0),
                c0=random.random(),
                c1=random.random(),
                c2=random.random(),
                shape=random.choice(["square", "circle"]),
                angle=random.uniform(0, 360),
                x_vel=random.uniform(-1, 1),
                y_vel=random.uniform(-1, 1),
            )
            for _ in range(num_sprites)
        ]
        renderer = SpriteFactors(factors=factors)
        output = renderer(sprites)
        for obs in output:
            assert set(obs.keys()) == set(factors)

    def testObservationSpec(self):
        factors = ["x", "y", "scale"]
        renderer = SpriteFactors(factors=factors)
        spec = renderer.observation_spec()
        # Spec should be a dict mapping each factor to its expected type/shape
        assert isinstance(spec, dict)
        assert set(spec.keys()) == set(factors)

    def testAttributesSingleton(self):
        sprite = make_sprite(
            x=0.5,
            y=0.5,
            shape="square",
            scale=0.5,
            angle=0,
            c0=0.1,
            c1=0.2,
            c2=0.3,
            x_vel=0.0,
            y_vel=0.0,
        )
        renderer = SpriteFactors(factors=["x", "y", "scale", "shape", "angle", "c0", "c1", "c2", "x_vel", "y_vel"])
        output = renderer([sprite])[0]
        assert output["x"] == 0.5
        assert output["y"] == 0.5
        assert output["shape"] == "square"
        assert output["scale"] == 0.5
        assert output["angle"] == 0
        assert output["c0"] == 0.1
        assert output["c1"] == 0.2
        assert output["c2"] == 0.3
        assert output["x_vel"] == 0.0
        assert output["y_vel"] == 0.0

    def testAttributesTwoSprites(self):
        sprite1 = make_sprite(
            x=0.1,
            y=0.2,
            shape="square",
            scale=0.3,
            angle=45,
            c0=0.1,
            c1=0.2,
            c2=0.3,
            x_vel=0.5,
            y_vel=-0.5,
        )
        sprite2 = make_sprite(
            x=0.6,
            y=0.7,
            shape="circle",
            scale=0.8,
            angle=90,
            c0=0.4,
            c1=0.5,
            c2=0.6,
            x_vel=-0.3,
            y_vel=0.3,
        )
        renderer = SpriteFactors(
            factors=["x", "y", "scale", "shape", "angle", "c0", "c1", "c2", "x_vel", "y_vel"]
        )
        outputs = renderer([sprite1, sprite2])
        for obs, sprite in zip(outputs, [sprite1, sprite2]):
            assert obs["x"] == sprite.x
            assert obs["y"] == sprite.y
            assert obs["shape"] == sprite.shape
            assert obs["scale"] == sprite.scale
            assert obs["angle"] == sprite.angle
            assert obs["c0"] == sprite.c0
            assert obs["c1"] == sprite.c1
            assert obs["c2"] == sprite.c2
            assert obs["x_vel"] == sprite.x_vel
            assert obs["y_vel"] == sprite.y_vel


class TestSpritePassthrough:
    def testRenderOne(self):
        sprite = make_sprite(x=0.1, y=0.2, shape="square")
        renderer = SpritePassthrough()
        output = renderer([sprite])
        assert output == [sprite]

    @pytest.mark.parametrize("num_sprites", [3, 5, 10])
    def testKSprites(self, num_sprites):
        sprites = [
            make_sprite(
                x=random.random(),
                y=random.random(),
                shape=random.choice(["square", "circle"]),
            )
            for _ in range(num_sprites)
        ]
        renderer = SpritePassthrough()
        output = renderer(sprites)
        assert output == sprites


class TestSuccess:
    def testRenderTrue(self):
        renderer = Success()
        global_state = {"success": True}
        result = renderer(global_state)
        assert result is True

    def testRenderFalse(self):
        renderer = Success()
        global_state = {"success": False}
        result = renderer(global_state)
        assert result is False

    def testMissingKey(self):
        renderer = Success()
        global_state = {}
        with pytest.raises(KeyError):
            renderer(global_state)