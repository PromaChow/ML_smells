import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor, DecisionTreeClassifier
from sklearn.metrics import mean_squared_error, accuracy_score
from pathlib import Path

# ----------------------------------------------------------------------
# ModelTree implementation
# ----------------------------------------------------------------------
class ModelTree:
    """
    A simplified ModelTree that supports three types of leaf models:
    - mean_regr: uses sklearn's DecisionTreeRegressor with mean predictions.
    - linear_regr: uses sklearn's DecisionTreeRegressor to split, then fits a LinearRegression
                   model on the samples of each leaf.
    - modal_clf: uses sklearn's DecisionTreeClassifier with majority vote predictions.
    """
    def __init__(self, leaf_model='mean_regr', max_depth=None):
        self.leaf_model = leaf_model
        self.max_depth = max_depth
        self.is_regression = leaf_model in ('mean_regr', 'linear_regr')
        self.is_classification = leaf_model == 'modal_clf'
        if self.is_regression:
            self.base_tree = DecisionTreeRegressor(max_depth=self.max_depth)
        else:
            self.base_tree = DecisionTreeClassifier(max_depth=self.max_depth)
        self.leaf_models = {}

    def fit(self, X, y):
        self.base_tree.fit(X, y)
        if self.leaf_model == 'linear_regr':
            leaf_indices = self.base_tree.apply(X)
            unique_leaves = np.unique(leaf_indices)
            self.leaf_models = {}
            for leaf in unique_leaves:
                idx = np.where(leaf_indices == leaf)[0]
                X_leaf = X[idx]
                y_leaf = y[idx]
                if len(X_leaf) < 2:
                    self.leaf_models[leaf] = ('mean', y_leaf.mean())
                else:
                    lr = LinearRegression()
                    lr.fit(X_leaf, y_leaf)
                    self.leaf_models[leaf] = lr
        return self

    def predict(self, X):
        if self.leaf_model == 'mean_regr':
            return self.base_tree.predict(X)
        elif self.leaf_model == 'linear_regr':
            leaf_indices = self.base_tree.apply(X)
            preds = np.empty(X.shape[0])
            for leaf, lr in self.leaf_models.items():
                mask = (leaf_indices == leaf)
                if isinstance(lr, tuple) and lr[0] == 'mean':
                    preds[mask] = lr[1]
                else:
                    preds[mask] = lr.predict(X[mask])
            return preds
        elif self.leaf_model == 'modal_clf':
            return self.base_tree.predict(X)
        else:
            raise ValueError(f'Unknown leaf model: {self.leaf_model}')

    def score(self, X, y):
        preds = self.predict(X)
        if self.is_regression:
            return mean_squared_error(y, preds)
        else:
            return accuracy_score(y, preds)


# ----------------------------------------------------------------------
# Helper functions
# ----------------------------------------------------------------------
def experiment(model, X, y):
    """Compute loss (MSE for regression, accuracy for classification)."""
    return model.score(X, y)


def generate_csv_data(func, filename, n_samples=500, x_range=(0, 10),
                      input_col_name='x1', target_col_name='y'):
    """Create a CSV file with synthetic data generated from func."""
    xs = np.linspace(x_range[0], x_range[1], n_samples)
    ys = func(xs)
    df = pd.DataFrame({input_col_name: xs, target_col_name: ys})
    df.to_csv(filename, index=False)


def plot_model_tree_fit(X, y, leaf_model, depths, title_prefix, output_path):
    """Train ModelTree at various depths, plot predictions vs data, and save figure."""
    n = len(depths)
    ncols = 3
    nrows = (n + ncols - 1) // ncols
    fig, axes = plt.subplots(nrows, ncols, figsize=(5 * ncols, 4 * nrows), squeeze=False)
    fig.suptitle(f'{title_prefix} Fit Across Depths', fontsize=16)
    for idx, depth in enumerate(depths):
        row, col = divmod(idx, ncols)
        ax = axes[row][col]
        mt = ModelTree(leaf_model=leaf_model, max_depth=depth)
        mt.fit(X, y)
        preds = mt.predict(X)
        ax.scatter(X.squeeze(), y, color='blue', alpha=0.4, label='Data')
        ax.plot(X.squeeze(), preds, color='red', linewidth=2, label='Model')
        ax.set_title(f'Depth = {depth}')
        ax.set_xlabel('x')
        ax.set_ylabel('y')
        ax.legend()
    # Remove empty subplots
    total_plots = nrows * ncols
    for idx in range(n, total_plots):
        row, col = divmod(idx, ncols)
        fig.delaxes(axes[row][col])
    plt.tight_layout(rect=[0, 0.03, 1, 0.95])
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    plt.savefig(output_path)
    plt.close(fig)


def run_tests(ModelTreeCls, data_path):
    """Validate ModelTree against known baselines."""
    df = pd.read_csv(data_path)
    if 'y' not in df.columns or 'x1' not in df.columns:
        raise ValueError('CSV must contain columns x1 and y')
    X = df[['x1']].values
    y = df['y'].values

    tol = 1e-6
    print('Running Test 1: Depth-0 ModelTree vs LinearRegression')
    mt0 = ModelTreeCls(leaf_model='linear_regr', max_depth=0)
    mt0.fit(X, y)
    loss_mt0 = mt0.score(X, y)
    lr = LinearRegression()
    lr.fit(X, y)
    loss_lr = lr.score(X, y)
    print(f'  ModelTree loss: {loss_mt0:.6f}, LinearRegression loss: {loss_lr:.6f}')
    assert abs(loss_mt0 - loss_lr) < tol, 'Test 1 failed'

    print('Running Test 2: ModelTree (mean_regr) vs DecisionTreeRegressor')
    mt_mean = ModelTreeCls(leaf_model='mean_regr', max_depth=20)
    mt_mean.fit(X, y)
    loss_mt_mean = mt_mean.score(X, y)
    dtr = DecisionTreeRegressor(max_depth=20)
    dtr.fit(X, y)
    loss_dtr = dtr.score(X, y)
    print(f'  ModelTree loss: {loss_mt_mean:.6f}, DecisionTreeRegressor loss: {loss_dtr:.6f}')
    assert abs(loss_mt_mean - loss_dtr) < tol, 'Test 2 failed'

    print('Running Test 3: ModelTree (modal_clf) vs DecisionTreeClassifier')
    mt_modal = ModelTreeCls(leaf_model='modal_clf', max_depth=20)
    mt_modal.fit(X, y)
    loss_mt_modal = mt_modal.score(X, y)
    dtc = DecisionTreeClassifier(max_depth=20)
    dtc.fit(X, y)
    loss_dtc = dtc.score(X, y)
    print(f'  ModelTree loss: {loss_mt_modal:.6f}, DecisionTreeClassifier loss: {loss_dtc:.6f}')
    assert abs(loss_mt_modal - loss_dtc) < tol, 'Test 3 failed'
    print('All tests passed.')


# ----------------------------------------------------------------------
# Main execution
# ----------------------------------------------------------------------
if __name__ == '__main__':
    # 1. Run tests on preloaded data
    # Assuming 'data_clf.csv' is available in the current directory
    run_tests(ModelTree, 'data_clf.csv')

    # 2. Generate 1D polynomial data
    def poly4(x):
        return (x - 1) * (x - 4) * (x - 8) * (x - 8)

    poly_csv = 'data_poly4_regr.csv'
    generate_csv_data(poly4, poly_csv, n_samples=500, x_range=(0, 10))

    # 3. Load polynomial data
    df_poly = pd.read_csv(poly_csv)
    X_poly = df_poly[['x1']].values
    y_poly = df_poly['y'].values

    # 4. Visualize ModelTree fits
    depths = list(range(6))  # 0 to 5 inclusive
    output_dir = Path('output')
    output_dir.mkdir(exist_ok=True)

    plot_model_tree_fit(
        X_poly, y_poly,
        leaf_model='mean_regr',
        depths=depths,
        title_prefix='Mean Regressor',
        output_path=output_dir / 'test_mean_regr_fit.png'
    )

    plot_model_tree_fit(
        X_poly, y_poly,
        leaf_model='linear_regr',
        depths=depths,
        title_prefix='Linear Regressor',
        output_path=output_dir / 'test_linear_regr_fit.png'
    )
