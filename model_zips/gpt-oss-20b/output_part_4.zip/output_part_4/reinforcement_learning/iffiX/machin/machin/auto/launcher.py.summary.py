import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.distributed as dist
from torch.utils.data import DataLoader, TensorDataset
import pytorch_lightning as pl

# ------------------------------------------------------------------
# Simple RL framework placeholder
# ------------------------------------------------------------------
class Frame(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        self.model = nn.Linear(10, 1)
        self.optimizer = torch.optim.Adam(self.parameters(), lr=cfg.lr)
        self.lr_scheduler = torch.optim.lr_scheduler.StepLR(self.optimizer, step_size=10, gamma=0.1)

    def update(self, batch):
        x, y = batch
        y_hat = self.model(x)
        loss = F.mse_loss(y_hat, y)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        return loss.item()

    def optimizers(self):
        return [self.optimizer]

    def lr_schedulers(self):
        return [self.lr_scheduler]

    def get_early_stop_monitors(self):
        return ["val_loss"]

    def log_metrics(self, metrics):
        return metrics

# ------------------------------------------------------------------
# Configuration placeholder
# ------------------------------------------------------------------
class Config:
    def __init__(self, distributed=False, batch_size=32, lr=1e-3):
        self.distributed = distributed
        self.batch_size = batch_size
        self.lr = lr

    def init_framework(self):
        return Frame(self)

# ------------------------------------------------------------------
# Environment dataset creator placeholder
# ------------------------------------------------------------------
def env_dataset_creator(train=True):
    size = 1000 if train else 200
    X = torch.randn(size, 10)
    y = torch.randn(size, 1)
    return TensorDataset(X, y)

# ------------------------------------------------------------------
# Lightning modules
# ------------------------------------------------------------------
class Launcher(pl.LightningModule):
    def __init__(self, cfg: Config, env_dataset_creator):
        super().__init__()
        assert not cfg.distributed, "Launcher expects non-distributed configuration."
        self.cfg = cfg
        self.env_dataset_creator = env_dataset_creator
        self.frame = cfg.init_framework()
        # Register submodules
        for name, module in self.frame.named_modules():
            if module is not self.frame:
                self.add_module(name, module)

    def train_dataloader(self):
        dataset = self.env_dataset_creator(train=True)
        return DataLoader(dataset, batch_size=self.cfg.batch_size)

    def test_dataloader(self):
        dataset = self.env_dataset_creator(train=False)
        return DataLoader(dataset, batch_size=self.cfg.batch_size)

    def training_step(self, batch, batch_idx):
        loss = self.frame.update(batch)
        if self.global_rank == 0:
            self._log("train_loss", loss, sync_dist=False)
        return loss

    def test_step(self, batch, batch_idx):
        x, y = batch
        y_hat = self.frame.model(x)
        loss = F.mse_loss(y_hat, y)
        self._log("val_loss", loss, sync_dist=False)
        return loss

    def configure_optimizers(self):
        return self.frame.optimizers(), self.frame.lr_schedulers()

    def _log(self, name, value, sync_dist=True):
        self.log(name, value, prog_bar=True, sync_dist=sync_dist)


class DistributedLauncher(pl.LightningModule):
    def __init__(self, cfg: Config, env_dataset_creator):
        super().__init__()
        assert cfg.distributed, "DistributedLauncher requires distributed configuration."
        self.cfg = cfg
        self.env_dataset_creator = env_dataset_creator
        self.frame = None
        self._early_stop_monitors = []
        self._skip_first_batch = True

    def on_train_start(self):
        self._init_frame_with_pl()

    def on_test_start(self):
        self._init_frame_with_pl()

    def _init_frame_with_pl(self):
        if self.trainer.accelerator != "ddp" and self.trainer.accelerator != "ddp_spawn":
            raise RuntimeError("DistributedLauncher requires DDP accelerator.")
        self.init_frame()

    def init_frame(self):
        if dist.is_available() and dist.is_initialized():
            dist.new_group()
        self.frame = self.cfg.init_framework()
        for name, module in self.frame.named_modules():
            if module is not self.frame:
                self.add_module(name, module)
        self._early_stop_monitors = self.frame.get_early_stop_monitors()

    def train_dataloader(self):
        dataset = self.env_dataset_creator(train=True)
        return DataLoader(dataset, batch_size=self.cfg.batch_size)

    def test_dataloader(self):
        dataset = self.env_dataset_creator(train=False)
        return DataLoader(dataset, batch_size=self.cfg.batch_size)

    def training_step(self, batch, batch_idx):
        if self._skip_first_batch:
            self._skip_first_batch = False
            return torch.tensor(0.0)
        loss = self.frame.update(batch)
        if self.global_rank == 0:
            self._log("train_loss", loss, sync_dist=False)
        if dist.is_available() and dist.is_initialized():
            dist.barrier()
        return loss

    def test_step(self, batch, batch_idx):
        x, y = batch
        y_hat = self.frame.model(x)
        loss = F.mse_loss(y_hat, y)
        self._log("val_loss", loss, sync_dist=False)
        return loss

    def configure_optimizers(self):
        return None

    def _log(self, name, value, sync_dist=True):
        if name in self._early_stop_monitors:
            sync_dist = True
        self.log(name, value, prog_bar=True, sync_dist=sync_dist)

# ------------------------------------------------------------------
# Example usage
# ------------------------------------------------------------------
if __name__ == "__main__":
    cfg = Config(distributed=False, batch_size=32, lr=1e-3)
    launcher = Launcher(cfg, env_dataset_creator)
    trainer = pl.Trainer(max_epochs=1, gpus=0)
    trainer.fit(launcher)