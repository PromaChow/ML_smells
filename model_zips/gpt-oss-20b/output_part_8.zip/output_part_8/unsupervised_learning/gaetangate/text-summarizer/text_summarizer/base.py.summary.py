import re
import string
import numpy as np
from scipy.spatial.distance import cosine
from flashtext import KeywordProcessor
from gensim.utils import split_sentences as gensim_split_sentences
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from unidecode import unidecode

# Ensure required NLTK resources are available
nltk.download('punkt', quiet=True)
nltk.download('stopwords', quiet=True)


def similarity(vec1: np.ndarray, vec2: np.ndarray) -> float:
    """Return cosine similarity in [0,1] avoiding division by zero."""
    norm1 = np.linalg.norm(vec1)
    norm2 = np.linalg.norm(vec2)
    if norm1 == 0 or norm2 == 0:
        return 0.0
    return 1.0 - cosine(vec1, vec2)


class BaseSummarizer:
    def __init__(
        self,
        language: str = 'english',
        preprocessing: str = 'nltk',
        remove_stopwords: bool = True,
        min_sentence_length: int = 10,
        debug: bool = False,
    ):
        self.language = language.lower()
        self.preprocessing = preprocessing.lower()
        self.remove_stopwords = remove_stopwords
        self.min_sentence_length = min_sentence_length
        self.debug = debug

        if self.remove_stopwords:
            self.stop_words = set(stopwords.words(self.language))
            self.stop_kw = KeywordProcessor(case_sensitive=False)
            for sw in self.stop_words:
                self.stop_kw.add_keyword(sw)
        else:
            self.stop_kw = None

    def _tokenize_sentences(self, text: str):
        if self.language == 'english':
            sentences = nltk.sent_tokenize(text)
        else:
            sentences = gensim_split_sentences(text, self.language)
        return sentences

    def _filter_sentences(self, sentences):
        filtered = []
        for sent in sentences:
            if sent.strip().endswith(':'):
                continue
            if len(sent.strip()) < self.min_sentence_length:
                continue
            filtered.append(sent)
        return filtered

    def _preprocess_nltk(self, sentence: str):
        tokens = word_tokenize(sentence)
        tokens = [t for t in tokens if t not in string.punctuation]
        tokens = [t.lower() for t in tokens if t.lower() not in {"''", '``', "'s"}]
        if self.remove_stopwords:
            tokens = [t for t in tokens if t not in self.stop_words]
        return tokens

    def _preprocess_regex(self, sentence: str):
        ascii_text = unidecode(sentence)
        ascii_text = re.sub(r'[^A-Za-z0-9\s]', ' ', ascii_text)
        tokens = ascii_text.lower().split()
        if self.remove_stopwords:
            tokens = [t for t in tokens if t not in self.stop_words]
        return tokens

    def preprocess(self, text: str):
        sentences = self._tokenize_sentences(text)
        sentences = self._filter_sentences(sentences)
        if self.preprocessing == 'nltk':
            return [self._preprocess_nltk(s) for s in sentences]
        else:
            return [self._preprocess_regex(s) for s in sentences]

    def summarize(self, text: str, limit_type: str = 'word', limit: int = 100):
        """Abstract method. Implement summarization logic here."""
        raise NotImplementedError("summarize method must be implemented by subclasses.")


if __name__ == "__main__":
    sample_text = (
        "Artificial intelligence (AI) is rapidly evolving. "
        "It has the potential to transform many industries: healthcare, finance, "
        "and transportation. "
        "However, challenges remain. "
        "Data privacy and algorithmic bias must be addressed."
    )
    summarizer = BaseSummarizer()
    preprocessed = summarizer.preprocess(sample_text)
    print(preprocessed)