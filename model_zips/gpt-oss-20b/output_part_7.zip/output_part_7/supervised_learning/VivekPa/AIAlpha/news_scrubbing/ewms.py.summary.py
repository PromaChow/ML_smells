import pandas as pd
import numpy as np
import bokeh.plotting

pd.options.mode.chained_assignment = None

df = pd.read_csv('export.csv')

df2 = df[['Title', 'Date', 'Title Sentiment', 'Body Sentiment']].copy()

df2['Weighted Sentiment'] = np.random.randn(len(df2))

for idx, row in df2.iterrows():
    title_sent = row['Title Sentiment']
    body_sent = row['Body Sentiment']
    weighted = title_sent * 0.8 + body_sent * 0.2
    df2.loc[idx, 'Weighted Sentiment'] = weighted

print(df2)