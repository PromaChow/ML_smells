import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset
from typing import List, Callable, Dict, Any, Optional, Union, Tuple
from dataclasses import dataclass, field
import random
import os
import copy

# ----------------------------------------------------------------------
# Utility functions for network updates
# ----------------------------------------------------------------------
def hard_update(target: nn.Module, source: nn.Module) -> None:
    target.load_state_dict(source.state_dict())

def soft_update(target: nn.Module, source: nn.Module, tau: float) -> None:
    for target_param, param in zip(target.parameters(), source.parameters()):
        target_param.data.copy_(tau * param.data + (1.0 - tau) * target_param.data)

# ----------------------------------------------------------------------
# Simple Replay Buffer
# ----------------------------------------------------------------------
class Buffer:
    def __init__(self, capacity: int, device: torch.device):
        self.capacity = capacity
        self.device = device
        self.storage: List[Dict[str, torch.Tensor]] = []
        self.ptr = 0

    def push(self, transition: Dict[str, torch.Tensor]) -> None:
        if len(self.storage) < self.capacity:
            self.storage.append(transition)
        else:
            self.storage[self.ptr] = transition
            self.ptr = (self.ptr + 1) % self.capacity

    def sample_batch(self, batch_size: int, sample_method: str = "random_unique") -> Dict[str, torch.Tensor]:
        indices = random.sample(range(len(self.storage)), batch_size)
        batch = {key: torch.stack([self.storage[i][key] for i in indices]).to(self.device)
                 for key in self.storage[0].keys()}
        return batch

    def __len__(self):
        return len(self.storage)

# ----------------------------------------------------------------------
# Transition dataclass
# ----------------------------------------------------------------------
@dataclass
class Transition:
    state: torch.Tensor
    action: torch.Tensor
    reward: torch.Tensor
    next_state: torch.Tensor
    terminal: torch.Tensor

# ----------------------------------------------------------------------
# DQN Agent
# ----------------------------------------------------------------------
class DQNAgent:
    def __init__(
        self,
        qnet: nn.Module,
        qnet_target: Optional[nn.Module] = None,
        optimizer: Callable[..., torch.optim.Optimizer] = torch.optim.Adam,
        learning_rate: float = 1e-3,
        replay_buffer: Optional[Buffer] = None,
        replay_size: int = 100000,
        replay_device: torch.device = torch.device("cpu"),
        batch_size: int = 64,
        epsilon_decay: float = 0.995,
        update_rate: Optional[float] = None,
        update_steps: Optional[int] = None,
        discount: float = 0.99,
        gradient_max: float = 10.0,
        mode: str = "vanilla",
        lr_scheduler: Optional[Callable[..., torch.optim.lr_scheduler._LRScheduler]] = None,
        lr_scheduler_args: Tuple[Any, ...] = (),
        lr_scheduler_kwargs: Dict[str, Any] = {},
    ):
        self.qnet = qnet
        self.mode = mode.lower()
        if self.mode not in ("vanilla", "fixed_target", "double"):
            raise ValueError("mode must be one of 'vanilla', 'fixed_target', 'double'")

        if qnet_target is None:
            self.qnet_target = copy.deepcopy(qnet)
        else:
            self.qnet_target = qnet_target

        self.qnet_optim = optimizer(self.qnet.parameters(), lr=learning_rate)

        if replay_buffer is None:
            self.replay_buffer = Buffer(replay_size, replay_device)
        else:
            self.replay_buffer = replay_buffer

        self.batch_size = batch_size
        self.epsilon_decay = epsilon_decay
        self.update_rate = update_rate
        self.update_steps = update_steps
        self.discount = discount
        self.gradient_max = gradient_max
        self.criterion = nn.MSELoss()

        if (update_rate is None) == (update_steps is None):
            raise ValueError("Specify exactly one of update_rate or update_steps")
        self.train_step_counter = 0

        # Synchronize target network
        hard_update(self.qnet_target, self.qnet)

        # Learning rate scheduler
        if lr_scheduler is not None:
            self.lr_scheduler = lr_scheduler(self.qnet_optim, *lr_scheduler_args, **lr_scheduler_kwargs)
        else:
            self.lr_scheduler = None

        # Exploration parameter
        self.epsilon = 1.0

    # ------------------------------------------------------------------
    # Action selection
    # ------------------------------------------------------------------
    def act_discrete(self, state: torch.Tensor, use_target: bool = False) -> int:
        net = self.qnet_target if use_target else self.qnet
        with torch.no_grad():
            q_values = net(state.unsqueeze(0))
            action = torch.argmax(q_values, dim=1).item()
        return action

    def act_discrete_with_noise(
        self,
        state: torch.Tensor,
        use_target: bool = False,
        decay_epsilon: bool = True,
    ) -> int:
        if random.random() < self.epsilon:
            action = random.randrange(self.qnet_output_dim())
        else:
            action = self.act_discrete(state, use_target=use_target)

        if decay_epsilon:
            self.epsilon = max(0.01, self.epsilon * self.epsilon_decay)
        return action

    def qnet_output_dim(self) -> int:
        dummy = torch.zeros(1, *self.qnet.state_shape)
        return self.qnet(dummy).shape[-1]

    # ------------------------------------------------------------------
    # Experience storage
    # ------------------------------------------------------------------
    def store_episode(self, transitions: List[Union[Transition, Dict[str, Any]]]) -> None:
        for tr in transitions:
            if isinstance(tr, Transition):
                transition = {
                    "state": tr.state,
                    "action": tr.action,
                    "reward": tr.reward,
                    "next_state": tr.next_state,
                    "terminal": tr.terminal,
                }
            else:
                transition = tr
            self.replay_buffer.push(transition)

    # ------------------------------------------------------------------
    # Training update
    # ------------------------------------------------------------------
    def update(self) -> None:
        if len(self.replay_buffer) < self.batch_size:
            return

        batch = self.replay_buffer.sample_batch(self.batch_size)

        states = batch["state"]
        actions = batch["action"].unsqueeze(1)
        rewards = batch["reward"]
        next_states = batch["next_state"]
        terminals = batch["terminal"]

        # Current Q values
        q_values = self.qnet(states).gather(1, actions).squeeze(1)

        with torch.no_grad():
            if self.mode == "vanilla":
                next_q_values = self.qnet(next_states).max(1)[0]
            elif self.mode == "fixed_target":
                next_q_values = self.qnet_target(next_states).max(1)[0]
                # Soft update target network
                if self.update_rate is not None:
                    soft_update(self.qnet_target, self.qnet, self.update_rate)
            elif self.mode == "double":
                next_actions = self.qnet(next_states).max(1)[1].unsqueeze(1)
                next_q_values = self.qnet_target(next_states).gather(1, next_actions).squeeze(1)
                if self.update_rate is not None:
                    soft_update(self.qnet_target, self.qnet, self.update_rate)
                else:
                    if self.train_step_counter % self.update_steps == 0:
                        hard_update(self.qnet_target, self.qnet)

        targets = rewards + self.discount * (1 - terminals) * next_q_values
        loss = self.criterion(q_values, targets)

        self.qnet_optim.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(self.qnet.parameters(), self.gradient_max)
        self.qnet_optim.step()

        self.train_step_counter += 1

        if self.lr_scheduler is not None:
            self.lr_scheduler.step()

    # ------------------------------------------------------------------
    # Scheduler update
    # ------------------------------------------------------------------
    def update_lr_scheduler(self) -> None:
        if self.lr_scheduler is not None:
            self.lr_scheduler.step()

    # ------------------------------------------------------------------
    # Model restoration
    # ------------------------------------------------------------------
    def load(self, directory: str) -> None:
        qnet_path = os.path.join(directory, "qnet.pth")
        target_path = os.path.join(directory, "qnet_target.pth")
        if os.path.exists(qnet_path):
            self.qnet.load_state_dict(torch.load(qnet_path))
        if os.path.exists(target_path):
            self.qnet_target.load_state_dict(torch.load(target_path))
        hard_update(self.qnet_target, self.qnet)

    # ------------------------------------------------------------------
    # Utility functions
    # ------------------------------------------------------------------
    @staticmethod
    def action_get_function(transition: Dict[str, Any]) -> torch.Tensor:
        return transition["action"]

    @staticmethod
    def reward_function(
        reward: torch.Tensor,
        next_value: torch.Tensor,
        terminal: torch.Tensor,
        discount: float,
    ) -> torch.Tensor:
        return reward + discount * (1 - terminal) * next_value

    # ------------------------------------------------------------------
    # Configuration utilities
    # ------------------------------------------------------------------
    @staticmethod
    def generate_config() -> Dict[str, Any]:
        return {
            "models": {
                "qnet": "QNetwork",
                "qnet_target": None,
            },
            "optimizer": {
                "class": torch.optim.Adam,
                "lr": 1e-3,
            },
            "criterion": "MSELoss",
            "replay_buffer": {
                "class": Buffer,
                "capacity": 100000,
                "device": torch.device("cpu"),
            },
            "hyperparameters": {
                "batch_size": 64,
                "epsilon_decay": 0.995,
                "update_rate": 0.005,
                "update_steps": None,
                "discount": 0.99,
                "gradient_max": 10.0,
                "mode": "vanilla",
            },
        }

    @classmethod
    def init_from_config(cls, config: Dict[str, Any]) -> "DQNAgent":
        # Instantiate Q-networks
        qnet_cls = globals()[config["models"]["qnet"]]
        qnet = qnet_cls()
        qnet_target_cls = config["models"]["qnet_target"]
        qnet_target = qnet_target_cls() if qnet_target_cls else None

        # Optimizer
        optim_cfg = config["optimizer"]
        optimizer_cls = optim_cfg["class"]
        optimizer_kwargs = {k: v for k, v in optim_cfg.items() if k != "class"}

        # Replay buffer
        rb_cfg = config["replay_buffer"]
        rb_cls = rb_cfg["class"]
        rb_kwargs = {k: v for k, v in rb_cfg.items() if k != "class"}
        replay_buffer = rb_cls(**rb_kwargs)

        # Hyperparameters
        hp = config["hyperparameters"]

        return cls(
            qnet=qnet,
            qnet_target=qnet_target,
            optimizer=optimizer_cls,
            learning_rate=optimizer_kwargs.get("lr", 1e-3),
            replay_buffer=replay_buffer,
            batch_size=hp.get("batch_size", 64),
            epsilon_decay=hp.get("epsilon_decay", 0.995),
            update_rate=hp.get("update_rate"),
            update_steps=hp.get("update_steps"),
            discount=hp.get("discount", 0.99),
            gradient_max=hp.get("gradient_max", 10.0),
            mode=hp.get("mode", "vanilla"),
        )

# ----------------------------------------------------------------------
# Example Q-network for discrete action space
# ----------------------------------------------------------------------
class QNetwork(nn.Module):
    def __init__(self, state_shape: Tuple[int, ...] = (4,), action_dim: int = 2):
        super().__init__()
        self.state_shape = state_shape
        self.action_dim = action_dim
        self.fc1 = nn.Linear(state_shape[0], 128)
        self.fc2 = nn.Linear(128, 128)
        self.out = nn.Linear(128, action_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x.view(x.size(0), -1)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        return self.out(x)
