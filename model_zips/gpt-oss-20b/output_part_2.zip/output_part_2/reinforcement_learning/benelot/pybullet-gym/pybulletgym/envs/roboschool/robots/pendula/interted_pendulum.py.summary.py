import math
import random
import numpy as np
import pybullet as pb

# Assume MJCFBasedRobot is available in the environment
try:
    from mjcf_robot import MJCFBasedRobot
except ImportError:
    # Placeholder base class if the real one is unavailable
    class MJCFBasedRobot:
        def __init__(self, mjcf_file, robot_body_name, action_dim, observation_dim):
            self.mjcf_file = mjcf_file
            self.robot_body_name = robot_body_name
            self.action_dim = action_dim
            self.observation_dim = observation_dim
            self.bullet_client = pb
            self.robot_id = None  # To be set in reset

        def reset(self):
            # Placeholder reset logic
            self.robot_id = None
            return np.zeros(self.observation_dim)

        def apply_action(self, a):
            pass

        def calc_state(self):
            return np.zeros(self.observation_dim)


class InvertedPendulum(MJCFBasedRobot):
    def __init__(self, *args, **kwargs):
        super().__init__(
            mjcf_file="inverted_pendulum.xml",
            robot_body_name="cart",
            action_dim=1,
            observation_dim=5,
        )
        self.swingup = False

    def reset(self):
        super().reset()
        # Assume robot_id is set by base class reset
        if self.robot_id is None:
            # Search for the robot body in the simulation
            bodies = self.bullet_client.getBodyInfo()
            for body_id, body_info in enumerate(bodies):
                name = body_info[1].decode("utf-8")
                if name == self.robot_body_name:
                    self.robot_id = body_id
                    break
        if self.robot_id is None:
            raise RuntimeError("Robot body not found in simulation.")

        # Retrieve joint indices
        self.hinge_joint_index = self._find_joint_index("hinge")
        self.slider_joint_index = self._find_joint_index("slider")

        # Initialize hinge angle
        if self.swingup:
            init_angle = math.pi + random.uniform(-0.1, 0.1)
        else:
            init_angle = random.uniform(-0.1, 0.1)

        self.bullet_client.resetJointState(
            bodyUniqueId=self.robot_id,
            jointIndex=self.hinge_joint_index,
            targetValue=init_angle,
            targetVelocity=0,
        )

        # Ensure hinge motor torque is zero
        self.bullet_client.setJointMotorControl2(
            bodyIndex=self.robot_id,
            jointIndex=self.hinge_joint_index,
            controlMode=pb.TORQUE_CONTROL,
            force=0,
        )
        return self.calc_state()

    def apply_action(self, a):
        if not np.all(np.isfinite(a)):
            raise ValueError("Action contains non-finite values.")
        torque = np.clip(a[0], -1.0, 1.0) * 100
        self.bullet_client.setJointMotorControl2(
            bodyIndex=self.robot_id,
            jointIndex=self.slider_joint_index,
            controlMode=pb.TORQUE_CONTROL,
            force=torque,
        )

    def calc_state(self):
        hinge_state = self.bullet_client.getJointState(
            bodyUniqueId=self.robot_id,
            jointIndex=self.hinge_joint_index,
        )
        slider_state = self.bullet_client.getJointState(
            bodyUniqueId=self.robot_id,
            jointIndex=self.slider_joint_index,
        )

        theta = hinge_state[0]
        theta_dot = hinge_state[1]
        x = slider_state[0]
        vx = slider_state[1]

        # Replace non-finite values with zero
        for val in [theta, theta_dot, x, vx]:
            if not np.isfinite(val):
                raise ValueError("State contains non-finite values.")

        state = np.array(
            [x, vx, math.cos(theta), math.sin(theta), theta_dot], dtype=np.float32
        )
        return state

    def _find_joint_index(self, joint_name):
        for i in range(self.bullet_client.getNumJoints(self.robot_id)):
            joint_info = self.bullet_client.getJointInfo(self.robot_id, i)
            name = joint_info[1].decode("utf-8")
            if name == joint_name:
                return i
        raise ValueError(f"Joint '{joint_name}' not found.")


class InvertedPendulumSwingup(InvertedPendulum):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.swingup = True
        # Ensure hinge joint index is reset after setting swingup
        if self.robot_id is not None:
            self.hinge_joint_index = self._find_joint_index("hinge")
            self.slider_joint_index = self._find_joint_index("slider")
            # Reinitialize joint states
            self.reset()
```