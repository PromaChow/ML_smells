import numpy as np
from scipy.stats import mode

class modal_clf:
    def __init__(self):
        self.y_mode = None

    def fit(self, X, y):
        mode_result = mode(y, axis=None)
        self.y_mode = mode_result.mode[0]
        return self

    def predict(self, X):
        if self.y_mode is None:
            raise ValueError("Model has not been fitted yet.")
        if hasattr(X, "shape"):
            n_samples = X.shape[0]
        else:
            n_samples = len(X)
        return np.full(n_samples, int(self.y_mode), dtype=int)

    def loss(self, y):
        classes, counts = np.unique(y, return_counts=True)
        proportions = counts / counts.sum()
        gini_impurity = 1.0 - np.sum(proportions ** 2)
        return gini_impurity

if __name__ == "__main__":
    clf = modal_clf()
    X = np.random.randn(10, 3)
    y = np.array([0, 1, 0, 0, 2, 0, 1, 0, 0, 2])
    clf.fit(X, y)
    predictions = clf.predict(X)
    print("Predictions:", predictions)
    print("Gini impurity:", clf.loss(y))