import os
import sys
import tempfile
import pickle
import shutil
import numpy as np
import pytest
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import LabelEncoder

try:
    import gensim
    from gensim.models import FastText as GensimFastTextModel
except ImportError:
    gensim = None

try:
    import fasttext
    from fasttext import train_supervised, load_model
except ImportError:
    fasttext = None


# ----------------------------------------------------------------------
# Helper functions and data
# ----------------------------------------------------------------------
@pytest.fixture(scope="session")
def dataset():
    samples = [
        "I love sunny days",
        "Rainy days are gloomy",
        "I enjoy sunshine",
        "Rain falls hard",
    ]
    targets = ["positive", "negative", "positive", "negative"]
    return samples, targets


@pytest.fixture(scope="session")
def pre_docs():
    return [
        "the quick brown fox jumps over the lazy dog",
        "never jump over the lazy dog quickly",
        "the dog is quick and loves the fox",
        "slow dogs are lazy",
    ]


def train_gensim_fasttext(sentences, size=10, window=3, min_count=1, epochs=5):
    if gensim is None:
        return None
    model = GensimFastTextModel(
        sentences=sentences,
        vector_size=size,
        window=window,
        min_count=min_count,
        epochs=epochs,
    )
    return model


def train_fasttext_supervised(sentences, labels, **kwargs):
    if fasttext is None:
        return None
    # fasttext expects training file in format: __label__label sentence
    with tempfile.NamedTemporaryFile(delete=False, mode="w", encoding="utf-8") as f:
        for s, l in zip(sentences, labels):
            f.write(f"__label__{l} {s}\n")
        train_file = f.name
    model = train_supervised(
        input=train_file,
        label="__label__",
        **kwargs,
    )
    os.unlink(train_file)
    return model


# ----------------------------------------------------------------------
# Custom wrappers
# ----------------------------------------------------------------------
class GensimFastTextClassifier:
    def __init__(self, pretrained=None, **kwargs):
        self.pretrained = pretrained
        self.model = pretrained
        self.lr = LogisticRegression(max_iter=200)
        self.le = LabelEncoder()
        self.params = kwargs

    def fit(self, X, y):
        if self.model is None:
            self.model = GensimFastTextModel(
                sentences=X,
                vector_size=self.params.get("size", 10),
                window=self.params.get("window", 3),
                min_count=self.params.get("min_count", 1),
                epochs=self.params.get("epochs", 5),
            )
        X_vec = np.array([self._sent_vec(s) for s in X])
        self.le.fit(y)
        y_enc = self.le.transform(y)
        self.lr.fit(X_vec, y_enc)

    def partial_fit(self, X, y):
        self.fit(X, y)

    def _sent_vec(self, sentence):
        words = sentence.split()
        vecs = [self.model.wv[w] for w in words if w in self.model.wv]
        if not vecs:
            return np.zeros(self.model.vector_size)
        return np.mean(vecs, axis=0)

    def predict_proba(self, X):
        X_vec = np.array([self._sent_vec(s) for s in X])
        probs = self.lr.predict_proba(X_vec)
        return probs

    def predict(self, X):
        probs = self.predict_proba(X)
        idx = np.argmax(probs, axis=1)
        return self.le.inverse_transform(idx)

    def save(self, path):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self.model.save(os.path.join(path, "gensim_fasttext.model"))
        with open(os.path.join(path, "lr.pkl"), "wb") as f:
            pickle.dump(self.lr, f)
        with open(os.path.join(path, "le.pkl"), "wb") as f:
            pickle.dump(self.le, f)

    @classmethod
    def load(cls, path, **kwargs):
        model = GensimFastTextModel.load(os.path.join(path, "gensim_fasttext.model"))
        with open(os.path.join(path, "lr.pkl"), "rb") as f:
            lr = pickle.load(f)
        with open(os.path.join(path, "le.pkl"), "rb") as f:
            le = pickle.load(f)
        clf = cls(pretrained=model, **kwargs)
        clf.model = model
        clf.lr = lr
        clf.le = le
        return clf


class FastTextClassifier:
    def __init__(self, pretrained=None, **kwargs):
        self.pretrained = pretrained
        self.model = pretrained
        self.params = kwargs

    def fit(self, X, y):
        self.model = train_fasttext_supervised(
            X, y, **self.params
        )

    def predict(self, X):
        return [self.model.predict(s)[0].replace("__label__", "") for s in X]

    def predict_proba(self, X):
        probs = []
        for s in X:
            preds = self.model.predict(s, k=len(self.model.get_labels()))
            probs.append([float(p[1]) for p in preds])
        return np.array(probs)

    def save(self, path):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self.model.save_model(os.path.join(path, "fasttext.model"))

    @classmethod
    def load(cls, path, **kwargs):
        model = load_model(os.path.join(path, "fasttext.model"))
        clf = cls(pretrained=model, **kwargs)
        clf.model = model
        return clf


# ----------------------------------------------------------------------
# Fixtures
# ----------------------------------------------------------------------
@pytest.fixture
def bunch_of_gensim_classifiers(dataset):
    if gensim is None:
        pytest.skip("gensim not installed")
    samples, targets = dataset
    models = [
        train_gensim_fasttext(samples, size=10, window=3, epochs=5),
        train_gensim_fasttext(samples, size=15, window=5, epochs=3),
    ]
    return [GensimFastTextClassifier(pretrained=m) for m in models]


@pytest.fixture
def bunch_of_fasttext_classifiers(dataset):
    if fasttext is None:
        pytest.skip("fasttext not installed")
    samples, targets = dataset
    configs = [
        {"loss": "softmax", "bucket": 200000, "epoch": 5, "dim": 10},
        {"loss": "hs", "bucket": 200000, "epoch": 3, "dim": 15},
    ]
    return [FastTextClassifier(**conf).fit(samples, targets) for conf in configs]


# ----------------------------------------------------------------------
# Prediction helper
# ----------------------------------------------------------------------
def _predict(clf, test_sentence="I love sunshine"):
    probs = clf.predict_proba([test_sentence])[0]
    top_prob = np.max(probs)
    assert top_prob > 0.33
    preds = clf.predict([test_sentence])[0]
    labels = clf.le.classes_ if hasattr(clf, "le") else clf.model.get_labels()
    return preds, top_prob


# ----------------------------------------------------------------------
# Tests
# ----------------------------------------------------------------------
def test_gensim_predict(bunch_of_gensim_classifiers):
    for clf in bunch_of_gensim_classifiers:
        _predict(clf)


def test_gensim_fit(dataset):
    if gensim is None:
        pytest.skip("gensim not installed")
    samples, targets = dataset
    clf = GensimFastTextClassifier()
    clf.fit(samples, targets)
    _predict(clf)


def test_fasttext_predict(bunch_of_fasttext_classifiers):
    for clf in bunch_of_fasttext_classifiers:
        _predict(clf)


def _persistence(classifiers):
    for clf in classifiers:
        with tempfile.NamedTemporaryFile(delete=False) as tmp:
            path = tmp.name
        try:
            clf.save(path)
            if isinstance(clf, GensimFastTextClassifier):
                loaded = GensimFastTextClassifier.load(path)
            else:
                loaded = FastTextClassifier.load(path)
            orig_pred = clf.predict(["I love sunshine"])[0]
            loaded_pred = loaded.predict(["I love sunshine"])[0]
            assert orig_pred == loaded_pred
        finally:
            shutil.rmtree(path, ignore_errors=True)


def test_persistence_gensim(bunch_of_gensim_classifiers):
    _persistence(bunch_of_gensim_classifiers)


@pytest.mark.skipif(
    os.getenv("TRAVIS") == "true" and sys.version_info >= (3, 5),
    reason="Travis CI Python 3.5+ environment issue",
)
def test_persistence_fasttext(bunch_of_fasttext_classifiers):
    _persistence(bunch_of_fasttext_classifiers)


def test_duplicate_arguments():
    if gensim is None:
        pytest.skip("gensim not installed")
    clf = GensimFastTextClassifier(seed=42, random_state=42, neg=5, negative=5)
    assert clf.params.get("seed") == 42
    assert clf.params.get("neg") == 5


def test_fit_embeddings(pre_docs, dataset):
    if gensim is None:
        pytest.skip("gensim not installed")
    samples, targets = dataset
    # Train embeddings
    emb_model = train_gensim_fasttext(pre_docs, size=20, epochs=5)
    clf = GensimFastTextClassifier(pretrained=emb_model)
    clf.fit(samples, targets)
    _predict(clf)


def test_buckets():
    if gensim is None:
        pytest.skip("gensim not installed")
    model = GensimFastTextModel(
        sentences=["a b c d e"],
        vector_size=10,
        bucket=10,
        min_count=1,
        epochs=5,
    )
    vocab = list(model.wv.key_to_index.keys())
    assert len(vocab) <= 10
    assert all(k.isdigit() for k in model.wv.key_to_index.keys())


def test_gensim_partial_fit(dataset):
    if gensim is None:
        pytest.skip("gensim not installed")
    samples, targets = dataset
    clf = GensimFastTextClassifier()
    clf.partial_fit([samples[0]], [targets[0]])
    vocab_before = set(clf.model.wv.key_to_index.keys())
    clf.partial_fit([samples[1]], [targets[1]])
    vocab_after = set(clf.model.wv.key_to_index.keys())
    assert len(vocab_after) >= len(vocab_before)
    _predict(clf)
```