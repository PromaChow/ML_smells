import pygame
import sys
import random
import math

# Constants
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
FPS = 60
PLAYER_SIZE = (30, 30)
BLOCK_SIZE = (40, 40)
TERRAIN_SIZE = (60, 60)
SCROLL_SPEED = 4
GRAVITY = 0.5
CLIMB_FORCE = -10
INITIAL_LIVES = 3
TERRAIN_SPACING = 150
TERRAIN_AMPLITUDE_RANGE = (30, 120)
TERRAIN_FREQUENCY_RANGE = (0.001, 0.003)
TERRAIN_JITTER_RANGE = (-20, 20)

class Player(pygame.sprite.Sprite):
    def __init__(self, pos):
        super().__init__()
        self.image = pygame.Surface(PLAYER_SIZE)
        self.image.fill((255, 255, 255))
        self.rect = self.image.get_rect(center=pos)
        self.velocity_y = 0

class Block(pygame.sprite.Sprite):
    def __init__(self, pos):
        super().__init__()
        self.image = pygame.Surface(BLOCK_SIZE)
        self.image.fill((0, 255, 0))
        self.rect = self.image.get_rect(center=pos)

class TerrainTile(pygame.sprite.Sprite):
    def __init__(self, pos):
        super().__init__()
        self.image = pygame.Surface(TERRAIN_SIZE)
        self.image.fill((100, 50, 20))
        self.rect = self.image.get_rect(topleft=pos)

class Pixelcopter:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.lives = INITIAL_LIVES
        self.score = 0
        self.player = None
        self.player_group = pygame.sprite.Group()
        self.block_group = pygame.sprite.Group()
        self.terrain_group = pygame.sprite.Group()
        self.init()

    def init(self):
        self.player = Player((self.width * 0.2, self.height // 2))
        self.player_group.empty()
        self.block_group.empty()
        self.terrain_group.empty()
        self.player_group.add(self.player)
        self._add_terrain()
        self._add_blocks()
        self.lives = INITIAL_LIVES
        self.score = 0

    def _add_terrain(self):
        start_x = 0
        end_x = self.width + TERRAIN_SPACING * 3
        freq = random.uniform(*TERRAIN_FREQUENCY_RANGE)
        amplitude = random.uniform(*TERRAIN_AMPLITUDE_RANGE)
        jitter = random.uniform(*TERRAIN_JITTER_RANGE)
        x = start_x
        while x < end_x:
            y_offset = math.sin(x * freq) * amplitude
            y = self.height // 2 + y_offset + jitter
            y = max(0, min(self.height - TERRAIN_SIZE[1], y))
            tile = TerrainTile((x, y))
            self.terrain_group.add(tile)
            x += TERRAIN_SPACING

    def _add_blocks(self):
        for _ in range(5):
            x = random.randint(self.width, self.width + 500)
            y = random.randint(0, self.height - BLOCK_SIZE[1])
            block = Block((x, y))
            self.block_group.add(block)

    def step(self, events, keys_pressed):
        if self.game_over():
            return

        # Player input
        if keys_pressed[pygame.K_w] or keys_pressed[pygame.K_UP]:
            self.player.velocity_y = CLIMB_FORCE
        else:
            self.player.velocity_y += GRAVITY

        # Update player
        self.player.rect.y += int(self.player.velocity_y)

        # Move terrain and blocks
        for sprite in self.terrain_group:
            sprite.rect.x -= SCROLL_SPEED
        for sprite in self.block_group:
            sprite.rect.x -= SCROLL_SPEED

        # Collision detection
        collided_blocks = pygame.sprite.spritecollide(self.player, self.block_group, True)
        if collided_blocks:
            self.lives -= 1

        collided_terrain = pygame.sprite.spritecollide(self.player, self.terrain_group, False)
        if collided_terrain:
            self.lives -= 1

        # Boundary check
        if self.player.rect.top < 0 or self.player.rect.bottom > self.height:
            self.lives -= 1
            self.player.rect.center = (self.width * 0.2, self.height // 2)
            self.player.velocity_y = 0

        # Remove offscreen terrain and blocks
        for sprite in list(self.terrain_group):
            if sprite.rect.right < 0:
                self.terrain_group.remove(sprite)
        for sprite in list(self.block_group):
            if sprite.rect.right < 0:
                self.block_group.remove(sprite)

        # Add new terrain if needed
        if len(self.terrain_group) == 0 or max(t.rect.x for t in self.terrain_group) < self.width:
            self._add_terrain()

        # Add new blocks if needed
        if len(self.block_group) < 5:
            self._add_blocks()

        # Update score
        self.score += 1

    def getGameState(self):
        state = {
            'player_position': self.player.rect.center,
            'player_velocity_y': self.player.velocity_y,
            'score': self.score,
            'lives': self.lives
        }
        # Distance to next terrain tile
        future_tiles = [t for t in self.terrain_group if t.rect.x > self.player.rect.x]
        if future_tiles:
            next_tile = min(future_tiles, key=lambda t: t.rect.x)
            state['distance_to_next_terrain'] = next_tile.rect.x - self.player.rect.x
        else:
            state['distance_to_next_terrain'] = None

        # Next block info
        future_blocks = [b for b in self.block_group if b.rect.x > self.player.rect.x]
        if future_blocks:
            next_block = min(future_blocks, key=lambda b: b.rect.x)
            state['next_block'] = {
                'position': next_block.rect.center,
                'distance': next_block.rect.x - self.player.rect.x
            }
        else:
            state['next_block'] = None

        return state

    def game_over(self):
        return self.lives <= 0

    def reset(self):
        self.init()

def main():
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Pixelcopter")
    clock = pygame.time.Clock()
    font = pygame.font.SysFont(None, 24)

    game = Pixelcopter(SCREEN_WIDTH, SCREEN_HEIGHT)

    while True:
        events = pygame.event.get()
        for event in events:
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        keys_pressed = pygame.key.get_pressed()

        game.step(events, keys_pressed)

        screen.fill((0, 0, 0))
        game.terrain_group.draw(screen)
        game.block_group.draw(screen)
        game.player_group.draw(screen)

        # UI
        score_text = font.render(f"Score: {game.score}", True, (255, 255, 255))
        lives_text = font.render(f"Lives: {game.lives}", True, (255, 255, 255))
        screen.blit(score_text, (10, 10))
        screen.blit(lives_text, (10, 30))

        pygame.display.flip()
        clock.tick(FPS)

if __name__ == "__main__":
    main()
