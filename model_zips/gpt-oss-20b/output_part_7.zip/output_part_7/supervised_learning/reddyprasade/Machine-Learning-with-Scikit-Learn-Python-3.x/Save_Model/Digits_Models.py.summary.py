import joblib
from sklearn.datasets import load_digits
from sklearn.linear_model import SGDClassifier

def main():
    # Load the digits dataset
    digits = load_digits()
    X, y = digits.data, digits.target

    # Initialize and train the SGD classifier
    classifier = SGDClassifier()
    classifier.fit(X, y)

    # Evaluate the model on the training data
    accuracy = classifier.score(X, y)
    print(f"Training accuracy: {accuracy:.4f}")

    # Serialize the trained model with compression level 9
    dump_path = 'digits_classifier.joblib.pkl'
    dump_result = joblib.dump(classifier, dump_path, compress=9)

    # Output the dump result
    print(f"Dump result: {dump_result}")

if __name__ == "__main__":
    main()