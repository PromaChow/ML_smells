import os
import random
import time
import torch
import torch.distributed as dist
import torch.distributed.rpc as rpc
import torch.nn as nn
import torch.multiprocessing as mp

SERVER_NAME = "server"


class Model(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Parameter(torch.tensor(1.0))
        self.fc2 = nn.Parameter(torch.tensor(2.0))
        self.fc3 = nn.Parameter(torch.tensor(3.0))

    def forward(self, x):
        return self.fc1 * x + self.fc2 * x + self.fc3 * x

    def state_dict(self):
        return {"fc1": self.fc1, "fc2": self.fc2, "fc3": self.fc3}

    def load_state_dict(self, state):
        self.fc1.copy_(state["fc1"])
        self.fc2.copy_(state["fc2"])
        self.fc3.copy_(state["fc3"])


class PushPullModelServerImpl:
    def __init__(self):
        self.model = Model()

    def push(self, state_dict):
        self.model.load_state_dict(state_dict)
        return True

    def pull(self, dummy):
        return self.model.state_dict()


class PushPullGradServerImpl:
    def __init__(self, reduce_method="mean", reduce_batch_size=2):
        self.model = Model()
        self.reduce_method = reduce_method
        self.reduce_batch_size = reduce_batch_size
        self.grad_buffer = {}
        self.buffer_count = 0

    def push_gradient(self, grads):
        for name, grad in grads.items():
            if name not in self.grad_buffer:
                self.grad_buffer[name] = grad.clone()
            else:
                self.grad_buffer[name] += grad
        self.buffer_count += 1
        if self.buffer_count >= self.reduce_batch_size:
            self._aggregate()
            self.grad_buffer.clear()
            self.buffer_count = 0
        return True

    def _aggregate(self):
        if self.reduce_method == "mean":
            factor = 1.0 / self.reduce_batch_size
        else:  # sum
            factor = 1.0
        for name, agg_grad in self.grad_buffer.items():
            self.model.state_dict()[name] -= agg_grad * factor

    def pull(self, dummy):
        return self.model.state_dict()


def test_push_pull_model_server(rank, world_size):
    dist.init_process_group(backend="gloo", init_method="tcp://127.0.0.1:29500",
                            rank=rank, world_size=world_size)
    rpc.init_rpc(f"worker{rank}", rank=rank, world_size=world_size)

    group = dist.new_group(list(range(world_size)))

    server = None
    if rank == 0:
        server = PushPullModelServerImpl()
        rpc.register_rpc_method("server", server)
    dist.barrier(group)

    if rank == 1:
        local_model = Model()
        pull_model = Model()
        for iter in range(10):
            local_model.fc1 += 1.0
            local_model.fc2 += 1.0
            local_model.fc3 += 1.0
            state = local_model.state_dict()
            rpc.rpc_sync("server", server.push, args=(state,))
            local_model.pp_version = iter
            time.sleep(random.random() * 0.2)

        pulled_state = rpc.rpc_sync("server", server.pull, args=(None,))
        pull_model.load_state_dict(pulled_state)

        assert abs(pull_model.fc1.item() - 11.0) < 1e-5
        assert abs(pull_model.fc2.item() - 12.0) < 1e-5
        assert abs(pull_model.fc3.item() - 13.0) < 1e-5

    dist.barrier(group)
    rpc.shutdown()
    dist.destroy_process_group()


def test_push_pull_grad_server(rank, world_size, reduce_method):
    dist.init_process_group(backend="gloo", init_method="tcp://127.0.0.1:29501",
                            rank=rank, world_size=world_size)
    rpc.init_rpc(f"worker{rank}", rank=rank, world_size=world_size)

    group = dist.new_group(list(range(world_size)))

    server = None
    if rank == 0:
        server = PushPullGradServerImpl(reduce_method=reduce_method,
                                        reduce_batch_size=2)
        rpc.register_rpc_method("server", server)
    dist.barrier(group)

    if rank != 0:
        local_model = Model()
        for iter in range(2):
            local_model.zero_grad()
            x = torch.ones([1, 1])
            out = local_model.forward(x)
            loss = out.sum()
            loss.backward()
            if reduce_method == "mean":
                grads = {"fc1": torch.tensor(6.0),
                         "fc2": torch.tensor(3.0),
                         "fc3": torch.tensor(-2.0)}
            else:  # sum
                grads = {"fc1": torch.tensor(12.0),
                         "fc2": torch.tensor(6.0),
                         "fc3": torch.tensor(4.0)}
            rpc.rpc_sync("server", server.push_gradient, args=(grads,))
            time.sleep(random.random() * 0.2)

    dist.barrier(group)

    if rank == 0:
        pulled_state = rpc.rpc_sync("server", server.pull, args=(None,))
        server.model.load_state_dict(pulled_state)
        final = server.model
        if reduce_method == "mean":
            assert abs(final.fc1.item() + 5.0) < 1e-5
            assert abs(final.fc2.item() + 1.0) < 1e-5
            assert abs(final.fc3.item() - 1.0) < 1e-5
        else:  # sum
            assert abs(final.fc1.item() + 23.0) < 1e-5
            assert abs(final.fc2.item() + 10.0) < 1e-5
            assert abs(final.fc3.item() + 5.0) < 1e-5

    dist.barrier(group)
    rpc.shutdown()
    dist.destroy_process_group()


def run_test(rank, world_size, test_type, reduce_method=None):
    if test_type == "model":
        test_push_pull_model_server(rank, world_size)
    else:
        test_push_pull_grad_server(rank, world_size, reduce_method)


if __name__ == "__main__":
    # Example usage:
    # For model test: mp.spawn(run_test, args=(2, "model"), nprocs=2)
    # For grad test with mean: mp.spawn(run_test, args=(3, "grad", "mean"), nprocs=3)
    # For grad test with sum: mp.spawn(run_test, args=(3, "grad", "sum"), nprocs=3)

    # Select test to run
    TEST_TYPE = os.getenv("TEST_TYPE", "model")          # "model" or "grad"
    REDUCE_METHOD = os.getenv("REDUCE_METHOD", "mean")   # "mean" or "sum"

    if TEST_TYPE == "model":
        world_size = 2
        mp.spawn(run_test,
                 args=(world_size, TEST_TYPE),
                 nprocs=world_size,
                 join=True)
    else:
        world_size = 3
        mp.spawn(run_test,
                 args=(world_size, TEST_TYPE, REDUCE_METHOD),
                 nprocs=world_size,
                 join=True)