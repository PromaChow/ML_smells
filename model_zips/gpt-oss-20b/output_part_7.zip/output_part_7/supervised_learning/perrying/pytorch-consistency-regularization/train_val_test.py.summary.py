import os
import random
import math
import datetime
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import numpy as np
from torch.utils.data import Dataset, DataLoader
from dataclasses import dataclass, field
from typing import Tuple, Optional, Callable, Dict, Any


# ------------------- Utility Functions ------------------- #
def set_seed(seed: int = 42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def copy_model(model: nn.Module) -> nn.Module:
    new_model = type(model)()
    new_model.load_state_dict(model.state_dict())
    return new_model


# ------------------- Config ------------------- #
@dataclass
class Config:
    seed: int = 42
    batch_size: int = 32
    val_batch_size: int = 64
    test_batch_size: int = 64
    num_classes: int = 10
    image_size: int = 32
    iteration: int = 1000
    disp: int = 100
    checkpoint: int = 200
    out_dir: str = "./outputs"
    ema: bool = True
    ema_rate: float = 0.999
    weight_avg: bool = True
    weight_avg_rate: float = 0.999
    optimizer: str = "SGD"  # or "AdamW"
    lr: float = 0.03
    momentum: float = 0.9
    weight_decay: float = 5e-4
    scheduler: str = "cosine"  # or "step"
    milestones: Tuple[int, ...] = (400, 800)
    gamma: float = 0.1
    coef: float = 1.0
    tsa: bool = True
    entropy: bool = True
    save_best: bool = True
    best_model_name: str = "best_model.pth"
    verbose: bool = True
    ssl_alg: str = "MeanTeacher"  # placeholder
    consistency: str = "KLD"  # placeholder
    ema_teacher: bool = True


# ------------------- Dataset and DataLoader ------------------- #
class DummyDataset(Dataset):
    def __init__(self, size: int, num_classes: int, image_size: int, labeled: bool = True):
        self.size = size
        self.num_classes = num_classes
        self.image_size = image_size
        self.labeled = labeled
        self.data = torch.randn(size, 3, image_size, image_size)
        if labeled:
            self.targets = torch.randint(0, num_classes, (size,))

    def __len__(self):
        return self.size

    def __getitem__(self, idx):
        if self.labeled:
            return self.data[idx], self.targets[idx]
        else:
            return self.data[idx]


def gen_dataloader(cfg: Config) -> Tuple[DataLoader, DataLoader, DataLoader, DataLoader, int, int]:
    num_labeled = 1000
    num_unlabeled = 5000
    val_size = 1000
    test_size = 1000

    labeled_dataset = DummyDataset(num_labeled, cfg.num_classes, cfg.image_size, labeled=True)
    unlabeled_dataset = DummyDataset(num_unlabeled, cfg.num_classes, cfg.image_size, labeled=False)
    val_dataset = DummyDataset(val_size, cfg.num_classes, cfg.image_size, labeled=True)
    test_dataset = DummyDataset(test_size, cfg.num_classes, cfg.image_size, labeled=True)

    lt_loader = DataLoader(labeled_dataset, batch_size=cfg.batch_size, shuffle=True, drop_last=True)
    ult_loader = DataLoader(unlabeled_dataset, batch_size=cfg.batch_size, shuffle=True, drop_last=True)
    val_loader = DataLoader(val_dataset, batch_size=cfg.val_batch_size, shuffle=False, drop_last=False)
    test_loader = DataLoader(test_dataset, batch_size=cfg.test_batch_size, shuffle=False, drop_last=False)

    class_counts = np.bincount(labeled_dataset.targets.numpy(), minlength=cfg.num_classes)
    return lt_loader, ult_loader, val_loader, test_loader, class_counts, cfg.image_size


# ------------------- Model ------------------- #
class SimpleCNN(nn.Module):
    def __init__(self, num_classes: int):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 32, 3, padding=1), nn.ReLU(),
            nn.Conv2d(32, 64, 3, padding=1), nn.ReLU(),
            nn.AdaptiveAvgPool2d(1)
        )
        self.classifier = nn.Linear(64, num_classes)

    def forward(self, x):
        x = self.features(x)
        x = x.view(x.size(0), -1)
        return self.classifier(x)


def gen_model(cfg: Config) -> nn.Module:
    return SimpleCNN(cfg.num_classes)


# ------------------- SSL Algorithm and Consistency ------------------- #
def mean_teacher_consistency(student_logits: torch.Tensor, teacher_logits: torch.Tensor, loss_fn: Callable) -> torch.Tensor:
    return loss_fn(teacher_logits, student_logits)


def gen_ssl_alg(cfg: Config) -> Callable[[torch.Tensor, torch.Tensor, Callable], torch.Tensor]:
    if cfg.ssl_alg == "MeanTeacher":
        return mean_teacher_consistency
    # Placeholder for other algorithms
    return mean_teacher_consistency


def kld_loss(target: torch.Tensor, input: torch.Tensor) -> torch.Tensor:
    return F.kl_div(F.log_softmax(input, dim=1), F.softmax(target, dim=1), reduction='batchmean')


def gen_consistency(cfg: Config) -> Callable[[torch.Tensor, torch.Tensor], torch.Tensor]:
    if cfg.consistency == "KLD":
        return kld_loss
    # Placeholder for other consistency functions
    return kld_loss


# ------------------- Evaluation ------------------- #
def evaluation(loader: DataLoader, model: nn.Module, device: torch.device, criterion: Callable) -> Dict[str, float]:
    model.eval()
    total_loss = 0.0
    correct = 0
    total = 0
    with torch.no_grad():
        for data, targets in loader:
            data, targets = data.to(device), targets.to(device)
            logits = model(data)
            loss = criterion(logits, targets)
            total_loss += loss.item() * data.size(0)
            preds = logits.argmax(dim=1)
            correct += (preds == targets).sum().item()
            total += data.size(0)
    return {
        "loss": total_loss / total,
        "accuracy": correct / total
    }


# ------------------- Meter ------------------- #
class Meter:
    def __init__(self):
        self.values: Dict[str, float] = {}
        self.count: int = 0

    def update(self, **kwargs):
        for k, v in kwargs.items():
            self.values.setdefault(k, 0.0)
            self.values[k] += v
        self.count += 1

    def average(self) -> Dict[str, float]:
        return {k: v / self.count for k, v in self.values.items()}

    def reset(self):
        self.values.clear()
        self.count = 0


# ------------------- EMA Update ------------------- #
def ema_update(ema_model: nn.Module, new_model: nn.Module, rate: float):
    for ema_param, new_param in zip(ema_model.parameters(), new_model.parameters()):
        ema_param.data.mul_(rate).add_(new_param.data, alpha=1 - rate)


# ------------------- Main Training Function ------------------- #
def train(cfg: Config):
    set_seed(cfg.seed)
    os.makedirs(cfg.out_dir, exist_ok=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if torch.cuda.is_available():
        torch.backends.cudnn.benchmark = True

    lt_loader, ult_loader, val_loader, test_loader, class_counts, img_size = gen_dataloader(cfg)

    consistency_fn = gen_consistency(cfg)
    ssl_alg_fn = gen_ssl_alg(cfg)

    student = gen_model(cfg).to(device)
    optimizer = (
        optim.SGD(student.parameters(), lr=cfg.lr, momentum=cfg.momentum, weight_decay=cfg.weight_decay, nesterov=True)
        if cfg.optimizer == "SGD"
        else optim.AdamW(student.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay)
    )

    if cfg.scheduler == "cosine":
        scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=cfg.iteration)
    else:
        scheduler = optim.lr_scheduler.MultiStepLR(optimizer, milestones=cfg.milestones, gamma=cfg.gamma)

    teacher: Optional[nn.Module] = copy_model(student) if cfg.ema_teacher else None
    eval_model: Optional[nn.Module] = copy_model(student) if cfg.weight_avg else None

    best_val_acc = 0.0
    best_state = None
    meter = Meter()
    loss_fn = nn.CrossEntropyLoss()
    total_iter = 0

    labeled_iter = iter(lt_loader)
    unlabeled_iter = iter(ult_loader)

    while total_iter < cfg.iteration:
        try:
            l_data, l_labels = next(labeled_iter)
        except StopIteration:
            labeled_iter = iter(lt_loader)
            l_data, l_labels = next(labeled_iter)

        try:
            ul_data = next(unlabeled_iter)
        except StopIteration:
            unlabeled_iter = iter(ult_loader)
            ul_data = next(unlabeled_iter)

        l_data, l_labels = l_data.to(device), l_labels.to(device)
        ul_data = ul_data.to(device)

        optimizer.zero_grad()

        # Forward for all data
        all_data = torch.cat([l_data, ul_data], dim=0)
        logits = student(all_data)

        l_logits = logits[:l_data.size(0)]
        ul_logits = logits[l_data.size(0):]

        # Supervised loss
        if cfg.tsa:
            # Temperature scaling annealing
            tsa_weight = min(1.0, total_iter / (cfg.iteration * 0.8))
            sup_loss = loss_fn(l_logits, l_labels) * tsa_weight
        else:
            sup_loss = loss_fn(l_logits, l_labels)

        loss = sup_loss

        # Consistency loss
        if cfg.coef > 0:
            if teacher is not None:
                with torch.no_grad():
                    teacher_logits = teacher(all_data)
                target = teacher_logits
            else:
                target = logits.detach()
            cons_loss = ssl_alg_fn(ul_logits, target[l_data.size(0):], consistency_fn)
            loss += cfg.coef * cons_loss

        # Entropy minimization
        if cfg.entropy:
            entropy_loss = -torch.mean(torch.sum(F.softmax(ul_logits, dim=1) * torch.log_softmax(ul_logits, dim=1), dim=1))
            loss -= entropy_loss

        loss.backward()
        optimizer.step()
        scheduler.step()

        # EMA updates
        if teacher is not None:
            ema_update(teacher, student, cfg.ema_rate)
        if eval_model is not None:
            ema_update(eval_model, student, cfg.weight_avg_rate)

        # Accuracy
        with torch.no_grad():
            acc = (l_logits.argmax(dim=1) == l_labels).float().mean().item()

        meter.update(loss=loss.item(), accuracy=acc)

        total_iter += 1

        if total_iter % cfg.disp == 0 and cfg.verbose:
            avg = meter.average()
            lr = optimizer.param_groups[0]["lr"]
            print(f"[{datetime.datetime.now().strftime('%H:%M:%S')}] Iter {total_iter}/{cfg.iteration} | "
                  f"Loss: {avg['loss']:.4f} | Acc: {avg['accuracy']:.4f} | LR: {lr:.6f} | Coef: {cfg.coef}")

        if total_iter % cfg.checkpoint == 0:
            eval_metrics = evaluation(val_loader, student if not eval_model else eval_model, device, loss_fn)
            print(f"Validation @ {total_iter}: Loss {eval_metrics['loss']:.4f} Acc {eval_metrics['accuracy']:.4f}")
            if eval_metrics['accuracy'] > best_val_acc:
                best_val_acc = eval_metrics['accuracy']
                best_state = {
                    "student": student.state_dict(),
                    "optimizer": optimizer.state_dict(),
                    "epoch": total_iter
                }
                torch.save(best_state, os.path.join(cfg.out_dir, cfg.best_model_name))

        meter.reset()

    # Final evaluation
    if best_state is not None:
        student.load_state_dict(best_state["student"])
    test_metrics = evaluation(test_loader, student if not eval_model else eval_model, device, loss_fn)
    print(f"Final Test Accuracy: {test_metrics['accuracy']:.4f}")


if __name__ == "__main__":
    cfg = Config()
    train(cfg)