import nltk
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer

# Ensure required NLTK resources are available
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')
try:
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords')

from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize, sent_tokenize


class base:
    @staticmethod
    def similarity(vec1, vec2):
        """Cosine similarity between two sparse vectors."""
        dot_product = np.dot(vec1.toarray(), vec2.toarray()).sum()
        norm1 = np.linalg.norm(vec1.toarray())
        norm2 = np.linalg.norm(vec2.toarray())
        if norm1 == 0 or norm2 == 0:
            return 0.0
        return dot_product / (norm1 * norm2)


class BaseSummarizer:
    def __init__(self, preprocess_type='default', stopwords_remove=True, language='english'):
        self.preprocess_type = preprocess_type
        self.stopwords_remove = stopwords_remove
        self.language = language
        self._stop_words = set(stopwords.words(language)) if stopwords_remove else set()

    def preprocess_text(self, sentences):
        """Tokenize, lowercase, and remove stopwords from each sentence."""
        processed = []
        for sent in sentences:
            tokens = word_tokenize(sent, language=self.language)
            tokens = [t.lower() for t in tokens]
            if self.stopwords_remove:
                tokens = [t for t in tokens if t.isalpha() and t not in self._stop_words]
            processed.append(' '.join(tokens))
        return processed


class CentroidSummarizer(BaseSummarizer):
    def __init__(
        self,
        language='english',
        preprocess_type='default',
        stopwords_remove=True,
        topic_threshold=0.3,
        sim_threshold=0.95,
        limit_type='word',
        limit=200,
    ):
        super().__init__(preprocess_type, stopwords_remove, language)
        self.topic_threshold = topic_threshold
        self.sim_threshold = sim_threshold
        self.limit_type = limit_type
        self.limit = limit

    def summarize(self, text):
        # 1. Text Preprocessing
        raw_sentences = sent_tokenize(text, language=self.language)
        processed_sentences = self.preprocess_text(raw_sentences)

        # 2. TF-IDF Matrix Construction
        vectorizer = CountVectorizer()
        term_matrix = vectorizer.fit_transform(processed_sentences)
        transformer = TfidfTransformer(norm=None)
        tfidf_matrix = transformer.fit_transform(term_matrix)

        # 3. Centroid Vector Calculation
        centroid_vec = tfidf_matrix.sum(axis=0)
        centroid_vec = np.asarray(centroid_vec).flatten()
        if centroid_vec.max() != 0:
            centroid_vec = centroid_vec / centroid_vec.max()
        centroid_vec[centroid_vec < self.topic_threshold] = 0
        centroid_vec = centroid_vec.reshape(1, -1)

        # 4. Sentence Scoring
        scored_sentences = []
        for idx, (sent, vec) in enumerate(zip(raw_sentences, tfidf_matrix)):
            score = base.similarity(vec, centroid_vec)
            scored_sentences.append((idx, sent, score, vec))

        # 5. Sorting and Redundancy Check
        scored_sentences.sort(key=lambda x: x[2], reverse=True)
        selected = []
        for idx, sent, score, vec in scored_sentences:
            redundant = False
            for _, _, _, sel_vec in selected:
                if base.similarity(vec, sel_vec) > self.sim_threshold:
                    redundant = True
                    break
            if not redundant:
                selected.append((idx, sent, score, vec))

        # 6. Summary Construction
        if self.limit_type == 'word':
            count = 0
            summary_parts = []
            for _, sent, _, _ in selected:
                words = sent.split()
                if count + len(words) > self.limit:
                    break
                summary_parts.append(sent)
                count += len(words)
        else:  # character limit
            chars = 0
            summary_parts = []
            for _, sent, _, _ in selected:
                if chars + len(sent) > self.limit:
                    break
                summary_parts.append(sent)
                chars += len(sent)

        return '\n'.join(summary_parts)
