import torch
from .utils import make_pseudo_label
from .consistency_regularization import ConsistencyRegularization


class PseudoLabel(ConsistencyRegularization):
    def __init__(self, consistency: str, threshold: float = 0.95,
                 sharpen: float = None, temp_softmax: float = None):
        super().__init__(consistency=consistency,
                         threshold=threshold,
                         sharpen=sharpen,
                         temp_softmax=temp_softmax)
        self.threshold = threshold
        self.sharpen = sharpen
        self.temp_softmax = temp_softmax

    def __call__(self, stu_preds: torch.Tensor, tea_logits: torch.Tensor):
        hard_label, mask = make_pseudo_label(tea_logits, threshold=self.threshold)
        return stu_preds, hard_label, mask

    def __repr__(self):
        return (f"{self.__class__.__name__}"
                f"(threshold={self.threshold}, "
                f"sharpen={self.sharpen}, "
                f"tau={self.temp_softmax})")