import argparse
import os
import random
import pathlib
import numpy as np

import torch
import torch.nn as nn
import torch.optim as optim
from torch import Tensor

import gym
from gym.wrappers import Monitor, Render

from rlpyt.envs.atari import wrap_deepmind
from rlpyt.envs.env_wrappers import atari_env
from rlpyt.networks.discrete import DiscreteActionValue
from rlpyt.algos.dqn import DoubleDQN
from rlpyt.replay_buffers.replay_buffer import ReplayBuffer
from rlpyt.replay_buffers.episodic import EpisodicReplayBuffer
from rlpyt.training.trainer import train_agent_with_evaluation
from rlpyt.utils.logging import create_loggers
from rlpyt.utils.tensor import to_device
from rlpyt.utils.buffer import ReplayBuffer
from rlpyt.utils.replay import replay
from rlpyt.utils.buffer import ReplayBuffer
from rlpyt.utils.replay import replay
from rlpyt.utils.buffer import ReplayBuffer
from rlpyt.utils.buffer import ReplayBuffer
from torchviz import make_dot

def parse_args():
    parser = argparse.ArgumentParser(description="Train a DRQN on Atari")
    parser.add_argument("--env", default="BreakoutNoFrameskip-v4", help="Atari env name")
    parser.add_argument("--out-dir", required=True, help="Output directory")
    parser.add_argument("--seed", type=int, default=42, help="Random seed")
    parser.add_argument("--gpu", action="store_true", help="Use GPU")
    parser.add_argument("--final-epsilon", type=float, default=0.01, help="Final epsilon")
    parser.add_argument("--final-exploration-frames", type=int, default=10**6,
                        help="Final exploration frames")
    parser.add_argument("--train-steps", type=int, default=5*10**7,
                        help="Total training steps")
    parser.add_argument("--replay-start-size", type=int, default=5*10**4,
                        help="Replay buffer start size")
    parser.add_argument("--target-update-interval", type=int, default=3*10**4,
                        help="Target network update interval")
    parser.add_argument("--eval-epsilon", type=float, default=0.001,
                        help="Evaluation epsilon")
    parser.add_argument("--eval-interval", type=int, default=250_000,
                        help="Evaluation interval")
    parser.add_argument("--demo-n-episodes", type=int, default=30,
                        help="Number of demo episodes")
    parser.add_argument("--recurrent", action="store_true", help="Use recurrent model")
    parser.add_argument("--flicker", action="store_true", help="Flickering env")
    parser.add_argument("--no-frame-stack", action="store_true", help="Disable frame stacking")
    parser.add_argument("--monitor", action="store_true", help="Monitor env")
    parser.add_argument("--render", action="store_true", help="Render env")
    parser.add_argument("--demo", action="store_true", help="Run demo only")
    return parser.parse_args()

def create_env(env_name, seed, flicker, no_stack, monitor, render):
    env = gym.make(env_name)
    env.seed(seed)
    env = wrap_deepmind(
        env,
        frame_stack=not no_stack,
        clip_rewards=True,
        scale=False,
        frame_size=84,
        flicker=flicker,
    )
    if monitor:
        env = Monitor(env, directory=None, video_callable=lambda x: False)
    if render:
        env = Render(env, mode="human")
    return env

class CNNFeatureExtractor(nn.Module):
    def __init__(self, output_dim):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(4, 32, kernel_size=8, stride=4),
            nn.ReLU(),
            nn.Conv2d(32, 64, kernel_size=4, stride=2),
            nn.ReLU(),
            nn.Conv2d(64, 64, kernel_size=3, stride=1),
            nn.ReLU(),
        )
        # compute conv output size
        dummy_input = torch.zeros(1, 4, 84, 84)
        conv_out = self.conv(dummy_input)
        self.flat_dim = conv_out.view(1, -1).size(1)
        self.fc = nn.Sequential(
            nn.Linear(self.flat_dim, output_dim),
            nn.ReLU(),
        )

    def forward(self, x):
        x = self.conv(x)
        x = x.view(x.size(0), -1)
        return self.fc(x)

class NonRecurrentPolicy(nn.Module):
    def __init__(self, num_actions):
        super().__init__()
        self.feature = CNNFeatureExtractor(512)
        self.output = nn.Linear(512, num_actions)

    def forward(self, observation):
        h = self.feature(observation)
        q = self.output(h)
        return q

class RecurrentPolicy(nn.Module):
    def __init__(self, num_actions):
        super().__init__()
        self.feature = CNNFeatureExtractor(512)
        self.lstm = nn.LSTM(512, 512, batch_first=True)
        self.output = nn.Linear(512, num_actions)

    def forward(self, observation, hidden_state):
        h = self.feature(observation)
        h = h.unsqueeze(1)  # seq_len=1
        lstm_out, hidden_state = self.lstm(h, hidden_state)
        lstm_out = lstm_out.squeeze(1)
        q = self.output(lstm_out)
        return q, hidden_state

def make_policy(num_actions, recurrent):
    if recurrent:
        return RecurrentPolicy(num_actions)
    else:
        return NonRecurrentPolicy(num_actions)

def main():
    args = parse_args()
    pathlib.Path(args.out_dir).mkdir(parents=True, exist_ok=True)

    # Set seeds
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if args.gpu and torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
        device = torch.device("cuda")
    else:
        device = torch.device("cpu")

    # Environments
    train_env = create_env(
        args.env,
        seed=args.seed,
        flicker=args.flicker,
        no_stack=args.no_frame_stack,
        monitor=False,
        render=False,
    )
    eval_env = create_env(
        args.env,
        seed=args.seed + 1,
        flicker=args.flicker,
        no_stack=args.no_frame_stack,
        monitor=args.monitor,
        render=args.render,
    )

    num_actions = train_env.action_space.n

    # Replay buffer
    buffer_cls = EpisodicReplayBuffer if args.recurrent else ReplayBuffer
    replay_buffer = buffer_cls(
        capacity=1_000_000,
        num_sequences=10 if args.recurrent else None,
    )

    # Policy
    policy = make_policy(num_actions, args.recurrent).to(device)

    # Optimizer
    optimizer = optim.Adam(policy.parameters(), lr=2.5e-4)

    # Exploration schedule
    exploration_schedule = {
        "initial_epsilon": 1.0,
        "final_epsilon": args.final_epsilon,
        "final_step": args.final_exploration_frames,
    }

    # Agent
    agent = DoubleDQN(
        num_actions=num_actions,
        network=policy,
        optimizer=optimizer,
        gamma=0.99,
        buffer=replay_buffer,
        replay_start_size=args.replay_start_size,
        target_update_interval=args.target_update_interval,
        update_interval=4,
        batch_size=32,
        episode_length=1000,
        recurrent=args.recurrent,
        hidden_size=512,
        sequence_length=10 if args.recurrent else None,
        phi=lambda x: x / 255.0,
        device=device,
        exploration_schedule=exploration_schedule,
    )

    # Demo mode
    if args.demo:
        episode_rewards = []
        for _ in range(args.demo_n_episodes):
            obs = eval_env.reset()
            done = False
            ep_reward = 0.0
            hidden = None
            while not done:
                obs_tensor = torch.tensor(obs, dtype=torch.float32).unsqueeze(0).to(device)
                if args.recurrent:
                    q_values, hidden = policy(obs_tensor, hidden)
                else:
                    q_values = policy(obs_tensor)
                action = torch.argmax(q_values, dim=1).item()
                obs, reward, done, _ = eval_env.step(action)
                ep_reward += reward
            episode_rewards.append(ep_reward)
        rewards = np.array(episode_rewards)
        print(f"Demo statistics: mean={rewards.mean():.2f}, median={np.median(rewards):.2f}, std={rewards.std():.2f}")
        return

    # Training
    train_agent_with_evaluation(
        algo=agent,
        env=train_env,
        eval_env=eval_env,
        eval_interval=args.eval_interval,
        eval_steps=args.eval_interval,
        total_steps=args.train_steps,
        output_dir=args.out_dir,
    )

    # Visualize network
    dummy_input = torch.zeros(1, 4, 84, 84).to(device)
    if args.recurrent:
        dummy_hidden = (torch.zeros(1, 1, 512).to(device), torch.zeros(1, 1, 512).to(device))
        output, _ = policy(dummy_input, dummy_hidden)
    else:
        output = policy(dummy_input)
    dot = make_dot(output, params=dict(policy.named_parameters()))
    dot.render(os.path.join(args.out_dir, "q_network"), format="pdf")

if __name__ == "__main__":
    main()
