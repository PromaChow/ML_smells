from machin.parallel.distributed import World
from torch.multiprocessing import spawn
import torch as t

def main(rank):
    world = World(world_size=3, rank=rank, name=f"proc{rank}", rpc_timeout=20)

    group = world.create_collective_group(ranks=[0, 1, 2], all_processes=True)

    if rank == 0:
        a = t.ones(5)
    else:
        a = t.zeros(5)

    group.broadcast(a, src=0)

    print(a)

    world.destroy_collective_group(group)

    return True

if __name__ == "__main__":
    spawn(main, nprocs=3)