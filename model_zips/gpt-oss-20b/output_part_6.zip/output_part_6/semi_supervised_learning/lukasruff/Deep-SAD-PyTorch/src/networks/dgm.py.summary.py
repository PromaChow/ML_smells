import torch
import torch.nn as nn
import torch.nn.functional as F
import math


def init_weights(m):
    if isinstance(m, nn.Linear):
        nn.init.xavier_normal_(m.weight)
        nn.init.zeros_(m.bias)


class Classifier(nn.Module):
    def __init__(self, x_dim=None, h_dim=None, net=None, y_dim=2):
        super().__init__()
        if net is not None:
            self.net = net
            self.logits = nn.Linear(net[-1].out_features, y_dim)
            init_weights(self.logits)
        else:
            if x_dim is None or h_dim is None:
                raise ValueError("x_dim and h_dim must be provided if net is not given")
            self.net = nn.Sequential(
                nn.Linear(x_dim, h_dim),
                nn.ReLU(),
                nn.Linear(h_dim, y_dim)
            )
        self.apply(init_weights)

    def forward(self, x):
        out = self.net(x)
        out = self.logits(out) if hasattr(self, 'logits') else out
        return F.softmax(out, dim=1)

    def logits_forward(self, x):
        out = self.net(x)
        out = self.logits(out) if hasattr(self, 'logits') else out
        return out


class VariationalAutoencoder(nn.Module):
    def __init__(self, x_dim, h_dim, z_dim):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(x_dim, h_dim),
            nn.ReLU(),
            nn.Linear(h_dim, h_dim),
            nn.ReLU(),
            nn.Linear(h_dim, z_dim * 2)  # mu and logvar
        )
        self.decoder = nn.Sequential(
            nn.Linear(z_dim, h_dim),
            nn.ReLU(),
            nn.Linear(h_dim, h_dim),
            nn.ReLU(),
            nn.Linear(h_dim, x_dim),
            nn.Sigmoid()
        )
        self.apply(init_weights)

    def encode(self, x):
        h = self.encoder(x)
        mu, logvar = torch.chunk(h, 2, dim=1)
        return mu, logvar

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def decode(self, z):
        return self.decoder(z)

    def forward(self, x):
        mu, logvar = self.encode(x)
        z = self.reparameterize(mu, logvar)
        recon = self.decode(z)
        return recon, mu, logvar


class DeepGenerativeModel(VariationalAutoencoder):
    def __init__(self, x_dim, y_dim, z_dim, h_dim, classifier=None):
        # encoder and decoder will accept concatenated (x, y) or (z, y)
        super().__init__(x_dim + y_dim, h_dim, z_dim)
        self.x_dim = x_dim
        self.y_dim = y_dim
        self.z_dim = z_dim
        self.h_dim = h_dim

        self.encoder = nn.Sequential(
            nn.Linear(x_dim + y_dim, h_dim[0]),
            nn.ReLU(),
            nn.Linear(h_dim[0], h_dim[1]),
            nn.ReLU(),
            nn.Linear(h_dim[1], z_dim * 2)
        )
        self.decoder = nn.Sequential(
            nn.Linear(z_dim + y_dim, h_dim[1]),
            nn.ReLU(),
            nn.Linear(h_dim[1], h_dim[0]),
            nn.ReLU(),
            nn.Linear(h_dim[0], x_dim),
            nn.Sigmoid()
        )

        if classifier is not None:
            self.classifier = classifier
        else:
            self.classifier = Classifier(x_dim=x_dim, h_dim=h_dim[0], y_dim=y_dim)

        self.apply(init_weights)
        self.kl_divergence = None

    def forward(self, x, y):
        # x: [batch, x_dim], y: [batch, y_dim]
        xy = torch.cat([x, y], dim=1)
        h = self.encoder(xy)
        mu, logvar = torch.chunk(h, 2, dim=1)
        z = self.reparameterize(mu, logvar)
        z_y = torch.cat([z, y], dim=1)
        recon = self.decoder(z_y)
        self.kl_divergence = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp(), dim=1)
        return recon, mu, logvar

    def classify(self, x):
        return self.classifier.logits_forward(x)

    def sample(self, z, y):
        z_y = torch.cat([z, y], dim=1)
        return self.decoder(z_y)


class StackedDeepGenerativeModel(DeepGenerativeModel):
    def __init__(self, features, y_dim, z_dim, h_dim, classifier=None):
        # features: pre-trained VAE
        super().__init__(features.x_dim, y_dim, z_dim, h_dim, classifier)
        self.features = features
        for p in self.features.parameters():
            p.requires_grad = False

        # Reinitialize encoder and decoder to match features latent dim
        self.encoder = nn.Sequential(
            nn.Linear(features.latent_dim + y_dim, h_dim[0]),
            nn.ReLU(),
            nn.Linear(h_dim[0], h_dim[1]),
            nn.ReLU(),
            nn.Linear(h_dim[1], z_dim * 2)
        )
        self.decoder = nn.Sequential(
            nn.Linear(z_dim + y_dim, h_dim[1]),
            nn.ReLU(),
            nn.Linear(h_dim[1], h_dim[0]),
            nn.ReLU(),
            nn.Linear(h_dim[0], features.x_dim),
            nn.Sigmoid()
        )
        self.apply(init_weights)

    def forward(self, x, y):
        # Encode with pre-trained features to obtain latent representation
        mu_feat, logvar_feat = self.features.encode(x)
        z_feat = self.features.reparameterize(mu_feat, logvar_feat)
        # Use z_feat as new 'x' for DGM
        recon, mu, logvar = super().forward(z_feat, y)
        return recon, mu, logvar

    def classify(self, x):
        mu_feat, _ = self.features.encode(x)
        return self.classifier.logits_forward(mu_feat)

# Example of usage (not executed):
# x_dim = 784
# y_dim = 2
# z_dim = 20
# h_dim = [400, 200]
# features = VariationalAutoencoder(x_dim, h_dim[0], z_dim)
# sdgm = StackedDeepGenerativeModel(features, y_dim, z_dim, h_dim)
# x_batch = torch.randn(64, x_dim)
# y_batch = torch.randint(0, 2, (64,)).float().unsqueeze(1)
# recon, mu, logvar = sdgm(x_batch, y_batch)
# class_logits = sdgm.classify(x_batch)
# samples = sdgm.sample(mu, y_batch)