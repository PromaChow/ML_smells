import torch
from torch.utils.data import DataLoader

# Assuming BaseADDataset is defined elsewhere in the project
from addataset import BaseADDataset


class TorchvisionDataset(BaseADDataset):
    def __init__(self, root: str):
        super().__init__(root)

    def loaders(
        self,
        batch_size: int,
        shuffle_train: bool = True,
        shuffle_test: bool = False,
        num_workers: int = 0,
    ) -> tuple[DataLoader, DataLoader]:
        train_loader = DataLoader(
            dataset=self.train_set,
            batch_size=batch_size,
            shuffle=shuffle_train,
            num_workers=num_workers,
            drop_last=True,
        )
        test_loader = DataLoader(
            dataset=self.test_set,
            batch_size=batch_size,
            shuffle=shuffle_test,
            num_workers=num_workers,
            drop_last=False,
        )
        return train_loader, test_loader

# Example usage (commented out to keep the module self-contained):
# if __name__ == "__main__":
#     dataset = TorchvisionDataset(root="/path/to/data")
#     train_dl, test_dl = dataset.loaders(batch_size=32)
#     for images, labels in train_dl:
#         print(images.shape, labels.shape)
#         break
