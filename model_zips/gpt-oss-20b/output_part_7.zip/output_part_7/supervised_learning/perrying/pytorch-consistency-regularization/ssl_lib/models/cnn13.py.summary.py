import torch
import torch.nn as nn
import torch.nn.init as init


def conv3x3(in_channels: int, out_channels: int, bias: bool = True) -> nn.Conv2d:
    return nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=1, padding=1, bias=bias)


class CNN13(nn.Module):
    def __init__(self, num_classes: int, filters: int):
        super().__init__()
        self.filters = filters
        self.num_classes = num_classes

        # Stage 1
        stage1_blocks = []
        for _ in range(3):
            stage1_blocks.append(
                nn.Sequential(
                    conv3x3(filters, filters, bias=True),
                    nn.LeakyReLU(inplace=True),
                    nn.BatchNorm2d(filters),
                )
            )
        stage1 = nn.Sequential(*stage1_blocks, nn.MaxPool2d(kernel_size=2, stride=2))

        # Stage 2
        stage2_blocks = []
        for _ in range(3):
            stage2_blocks.append(
                nn.Sequential(
                    conv3x3(filters, 2 * filters, bias=True),
                    nn.LeakyReLU(inplace=True),
                    nn.BatchNorm2d(2 * filters),
                )
            )
        stage2 = nn.Sequential(*stage2_blocks, nn.MaxPool2d(kernel_size=2, stride=2))

        # Stage 3
        stage3_block1 = nn.Sequential(
            nn.Conv2d(2 * filters, 4 * filters, kernel_size=3, stride=1, padding=1, bias=True),
            nn.LeakyReLU(inplace=True),
            nn.BatchNorm2d(4 * filters),
        )
        stage3_block2 = nn.Sequential(
            nn.Conv2d(4 * filters, 2 * filters, kernel_size=1, stride=1, bias=False),
            nn.LeakyReLU(inplace=True),
            nn.BatchNorm2d(2 * filters),
        )
        stage3_block3 = nn.Sequential(
            nn.Conv2d(2 * filters, filters, kernel_size=1, stride=1, bias=False),
            nn.LeakyReLU(inplace=True),
            nn.BatchNorm2d(filters),
        )
        stage3 = nn.Sequential(stage3_block1, stage3_block2, stage3_block3)

        self.features = nn.Sequential(stage1, stage2, stage3)
        self.global_pool = nn.AdaptiveAvgPool2d((1, 1))
        self.classifier = nn.Linear(filters, num_classes)

        self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d) or isinstance(m, nn.Linear):
                init.xavier_normal_(m.weight)
                if m.bias is not None:
                    init.constant_(m.bias, 0)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.features(x)
        x = self.global_pool(x)
        x = torch.flatten(x, 1)
        x = self.classifier(x)
        return x

if __name__ == "__main__":
    model = CNN13(num_classes=10, filters=64)
    dummy = torch.randn(1, 3, 224, 224)
    out = model(dummy)
    print(out.shape)