import torch
import gym
import numpy as np


class BaseAgent:
    def __init__(self, env: gym.Env):
        self.env = env


class RolloutBuffer:
    def __init__(self, size: int):
        self.size = size
        self.reset()

    def reset(self):
        self.states = []
        self.actions = []
        self.rewards = []
        self.dones = []
        self.values = []
        self.old_log_probs = []

    def add(self, state, action, reward, done, value, old_log_probs):
        self.states.append(state)
        self.actions.append(action)
        self.rewards.append(reward)
        self.dones.append(done)
        self.values.append(value)
        self.old_log_probs.append(old_log_probs)


class OnPolicyAgent(BaseAgent):
    def __init__(
        self,
        env: gym.Env,
        rollout_size: int,
        buffer_type: str,
        gamma: float = 0.99,
        lr_policy: float = 1e-4,
        lr_value: float = 1e-3,
        gae_lambda: float = 1.0,
    ):
        super().__init__(env)
        self.rollout_size = rollout_size
        self.gamma = gamma
        self.lr_policy = lr_policy
        self.lr_value = lr_value
        self.gae_lambda = gae_lambda

        if buffer_type == "rollout":
            self.buffer = RolloutBuffer(self.rollout_size)
        else:
            raise ValueError(f"Unsupported buffer_type: {buffer_type}")

        self.rewards = []
        self.current_episode_reward = 0.0

    def collect_rollouts(self, state: torch.Tensor, render: bool = False):
        self.current_episode_reward = 0.0
        for _ in range(self.rollout_size):
            action, value, old_log_probs = self.select_action(state)

            next_state, reward, done, info = self.env.step(action)

            if render:
                self.env.render()

            self.buffer.add(state, action, reward, done, value, old_log_probs)

            self.collect_rewards(reward, done)

            state = next_state

        if self.current_episode_reward != 0.0:
            self.rewards.append(self.current_episode_reward)
            self.current_episode_reward = 0.0
            self.env.reset_single_env()

    def collect_rewards(self, reward: float, done: bool):
        self.current_episode_reward += reward
        if done:
            self.rewards.append(self.current_episode_reward)
            self.current_episode_reward = 0.0
            self.env.reset_single_env()

    def select_action(self, state: torch.Tensor):
        raise NotImplementedError("select_action must be implemented by subclasses")

    def update_params(self):
        raise NotImplementedError("update_params must be implemented by subclasses")