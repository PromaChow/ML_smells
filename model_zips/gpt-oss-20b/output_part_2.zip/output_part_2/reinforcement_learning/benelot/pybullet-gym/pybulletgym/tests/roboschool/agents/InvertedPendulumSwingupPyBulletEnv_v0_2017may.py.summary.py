import os
import sys
import numpy as np

# Add the parent directory of the current script to sys.path
parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

# Dense Layer 1
weights_dense1_w = np.arange(5 * 100).reshape(5, 100)
weights_dense1_b = np.arange(5)

# Dense Layer 2
weights_dense2_w = np.arange(32 * 5).reshape(32, 5)
weights_dense2_b = np.arange(32)

# Final Output Layer
weights_final_w = np.arange(1 * 32).reshape(1, 32)
weights_final_b = np.arange(1)