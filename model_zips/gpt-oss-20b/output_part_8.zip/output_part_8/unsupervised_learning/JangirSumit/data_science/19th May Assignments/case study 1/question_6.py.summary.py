import pandas as pd
import numpy as np

# 6.1: Case Conversion and Length Calculation
series6_1 = pd.Series(['Amit', 'Bob', 'Kate', 'A', 'b', np.nan, 'Car', 'dog', 'cat'])
lower_series = series6_1.astype(str).str.lower()
upper_series = series6_1.astype(str).str.upper()
print("6.1 Lowercase:\n", lower_series)
print("\n6.1 Uppercase:\n", upper_series)
print("\n6.1 Length of Series:", len(series6_1))

# 6.2: String Trimming Operations
series6_2 = pd.Series([' Atul', 'John ', ' jack ', 'Sam'])
trim_both = series6_2.str.strip()
trim_left = series6_2.str.lstrip()
trim_right = series6_2.str.rstrip()
print("\n6.2 Trim Both Ends:\n", trim_both)
print("\n6.2 Trim Left Only:\n", trim_left)
print("\n6.2 Trim Right Only:\n", trim_right)

# 6.3: String Splitting and Flattening
series6_3 = pd.Series(['India_is_big', 'Population_is_huge', np.nan, 'Has_diverse_culture'])
split_lists = series6_3.astype(str).apply(lambda x: x.split('_') if pd.notna(x) else [])
flattened = [item for sublist in split_lists for item in sublist]
print("\n6.3 Flattened List:")
for idx, item in enumerate(flattened, 1):
    print(f"Element {idx}: {item}")

# 6.4: String Replacement
series6_4 = pd.Series(['A', 'B', 'C', 'AabX', 'BacX', '', np.nan, 'CABA', 'dog', 'cat'])
replaced = series6_4.replace('X', 'XX-XX', regex=False).replace('dog', 'XX-XX', regex=False)
print("\n6.4 Replaced Series:\n", replaced)

# 6.5: Removing Dollar Signs
series6_5 = pd.Series(['12', '-$10', '$10,000'])
removed_dollar = series6_5.replace(r'\$', '', regex=True)
print("\n6.5 Without Dollar Signs:\n", removed_dollar)

# 6.6: Reversing Series Elements
series6_6 = pd.Series(['india 1998', 'big country', np.nan])
reversed_series = series6_6.iloc[::-1]
print("\n6.6 Reversed Series:\n", reversed_series)

# 6.7: Alphanumeric Check
series6_7 = pd.Series(['1', '2', '1a', '2b', '2003c'])
isalnum_series = series6_7.astype(str).str.isalnum().fillna(False)
print("\n6.7 Alphanumeric Check:\n", isalnum_series)

# 6.8: Presence of 'A' Check
series6_8 = pd.Series(['1', '2', '1a', '2b', 'America', 'VietnAm', 'vietnam', '2003c'])
contains_A = series6_8.astype(str).apply(lambda x: 'A' in x)
print("\n6.8 Contains 'A':\n", contains_A)

# 6.9: Regex Match for a, b, or c
series6_9 = pd.Series(['a', 'a|b', np.nan, 'a|c'])
regex_match = series6_9.astype(str).str.contains('[abc]', regex=True, na=False).astype(int)
print("\n6.9 Regex Match (1 = match, 0 = no match):\n", regex_match)

# 6.10: DataFrame Merging
df1 = pd.DataFrame({'key': [1, 2, 3], 'value1': ['A', 'B', 'C']})
df2 = pd.DataFrame({'key': [2, 3, 4], 'value2': ['X', 'Y', 'Z']})
merged_df = pd.merge(df1, df2, on='key', sort=True)
print("\n6.10 Merged DataFrame:\n", merged_df)