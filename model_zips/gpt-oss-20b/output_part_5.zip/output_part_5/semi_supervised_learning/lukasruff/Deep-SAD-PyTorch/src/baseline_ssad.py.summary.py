import argparse
import json
import logging
import os
import random
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.utils.data as data
from torch import nn, optim
from torch.utils.data import DataLoader, TensorDataset


def seed_all(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def load_dataset(
    dataset_name: str,
    normal_class: int,
    known_outlier_class: int,
    n_known_outlier_classes: int,
    ratio_known_normal: float,
    ratio_known_outlier: float,
    ratio_pollution: float,
):
    """
    Dummy dataset loader. Returns tensors for training, unlabeled, and test sets.
    """
    # For demonstration, generate synthetic data
    n_samples = 1000
    input_dim = 20
    X = np.random.randn(n_samples, input_dim).astype(np.float32)
    y = np.full(n_samples, normal_class, dtype=np.int64)

    # Inject known outliers
    n_known_outliers = int(n_samples * ratio_known_outlier)
    y[:n_known_outliers] = known_outlier_class

    # Unlabeled data (may contain pollution)
    X_unlabeled = X.copy()
    y_unlabeled = np.full(n_samples, -1, dtype=np.int64)  # -1 indicates unknown
    n_polluted = int(n_samples * ratio_pollution)
    y_unlabeled[:n_polluted] = known_outlier_class

    # Test set
    X_test = np.random.randn(200, input_dim).astype(np.float32)
    y_test = np.random.randint(0, 2, size=(200,), dtype=np.int64)

    return (
        torch.from_numpy(X).float(),
        torch.from_numpy(y).long(),
        torch.from_numpy(X_unlabeled).float(),
        torch.from_numpy(y_unlabeled).long(),
        torch.from_numpy(X_test).float(),
        torch.from_numpy(y_test).long(),
    )


class AutoEncoder(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int = 10):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden_dim), nn.ReLU(), nn.Linear(hidden_dim, hidden_dim)
        )
        self.decoder = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim), nn.ReLU(), nn.Linear(hidden_dim, input_dim)
        )

    def forward(self, x):
        z = self.encoder(x)
        return self.decoder(z), z


def load_autoencoder(path: Path, input_dim: int) -> AutoEncoder:
    ae = AutoEncoder(input_dim)
    if path.exists():
        state = torch.load(path, map_location="cpu")
        ae.load_state_dict(state["model_state"])
    return ae


class SSAD:
    def __init__(self, kernel: str = "rbf", kappa: float = 1.0, hybrid: bool = False):
        self.kernel = kernel
        self.kappa = kappa
        self.hybrid = hybrid
        self.model = nn.Sequential(
            nn.Linear(20, 64),
            nn.ReLU(),
            nn.Linear(64, 1),
            nn.Sigmoid(),
        )
        self.optimizer = optim.Adam(self.model.parameters(), lr=1e-3)
        self.criterion = nn.BCELoss()

    def load_weights(self, path: Path):
        if path.exists():
            state = torch.load(path, map_location="cpu")
            self.model.load_state_dict(state["model_state"])

    def train(
        self,
        X_train: torch.Tensor,
        y_train: torch.Tensor,
        X_unlabeled: torch.Tensor,
        n_workers: int = 4,
    ):
        dataset = TensorDataset(X_train, y_train)
        loader = DataLoader(dataset, batch_size=32, shuffle=True, num_workers=n_workers)
        for epoch in range(5):
            for x_batch, y_batch in loader:
                self.optimizer.zero_grad()
                outputs = self.model(x_batch).squeeze()
                loss = self.criterion(outputs, y_batch.float())
                loss.backward()
                self.optimizer.step()

    def test(self, X_test: torch.Tensor) -> np.ndarray:
        with torch.no_grad():
            scores = self.model(X_test).squeeze().cpu().numpy()
        return scores


def visualize_samples(
    X: torch.Tensor,
    scores: np.ndarray,
    indices: np.ndarray,
    exp_path: Path,
    title: str,
):
    fig, axes = plt.subplots(2, 4, figsize=(12, 6))
    for ax, idx in zip(axes.flatten(), indices):
        img = X[idx].view(28, 28).numpy()
        ax.imshow(img, cmap="gray")
        ax.set_title(f"{title}\nScore: {scores[idx]:.4f}")
        ax.axis("off")
    fig.tight_layout()
    exp_path.mkdir(parents=True, exist_ok=True)
    plt.savefig(exp_path / f"{title.lower().replace(' ', '_')}.png")
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_name", type=str, default="mnist")
    parser.add_argument("--experiment_path", type=str, default="exp")
    parser.add_argument("--data_path", type=str, default="data")
    parser.add_argument("--ratio_known_normal", type=float, default=0.8)
    parser.add_argument("--ratio_known_outlier", type=float, default=0.1)
    parser.add_argument("--ratio_pollution", type=float, default=0.05)
    parser.add_argument("--kernel", type=str, default="rbf")
    parser.add_argument("--kappa", type=float, default=1.0)
    parser.add_argument("--hybrid", action="store_true")
    parser.add_argument("--load_model", type=str, default=None)
    parser.add_argument("--load_ae", type=str, default=None)
    parser.add_argument("--seed", type=int, default=None)
    parser.add_argument("--n_jobs_dataloader", type=int, default=4)
    args = parser.parse_args()

    if args.seed is not None:
        seed_all(args.seed)

    exp_path = Path(args.experiment_path)
    exp_path.mkdir(parents=True, exist_ok=True)

    # Logging
    log_file = exp_path / "experiment.log"
    logging.basicConfig(
        filename=str(log_file),
        filemode="w",
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
    )
    logging.info(f"Arguments: {args}")

    # Load dataset
    X_train, y_train, X_unlabeled, y_unlabeled, X_test, y_test = load_dataset(
        dataset_name=args.dataset_name,
        normal_class=0,
        known_outlier_class=1,
        n_known_outlier_classes=1,
        ratio_known_normal=args.ratio_known_normal,
        ratio_known_outlier=args.ratio_known_outlier,
        ratio_pollution=args.ratio_pollution,
    )

    # Model initialization
    ssad = SSAD(kernel=args.kernel, kappa=args.kappa, hybrid=args.hybrid)

    if args.load_model:
        ssad.load_weights(Path(args.load_model))

    if args.hybrid and args.load_ae:
        ae = load_autoencoder(Path(args.load_ae), input_dim=20)
        # Replace X_train with encoded features
        with torch.no_grad():
            _, z_train = ae(X_train)
            X_train = z_train
            _, z_test = ae(X_test)
            X_test = z_test

    # Training
    ssad.train(X_train, y_train, X_unlabeled, n_workers=args.n_jobs_dataloader)

    # Testing
    scores = ssad.test(X_test)

    # Save results
    results = []
    for idx, (label, score) in enumerate(zip(y_test.tolist(), scores)):
        results.append({"index": idx, "label": label, "score": float(score)})
    results_path = exp_path / "test_results.json"
    with open(results_path, "w") as f:
        json.dump(results, f, indent=4)

    # Save config
    config_path = exp_path / "config.json"
    with open(config_path, "w") as f:
        json.dump(vars(args), f, indent=4)

    # Visualization for image datasets
    image_datasets = {"mnist", "fmnist", "cifar10"}
    if args.dataset_name.lower() in image_datasets:
        top_indices = np.argsort(scores)[-4:][::-1]
        bottom_indices = np.argsort(scores)[:4]
        visualize_samples(
            X_test,
            scores,
            top_indices,
            exp_path,
            title="Most Anomalous",
        )
        visualize_samples(
            X_test,
            scores,
            bottom_indices,
            exp_path,
            title="Most Normal",
        )


if __name__ == "__main__":
    main()
