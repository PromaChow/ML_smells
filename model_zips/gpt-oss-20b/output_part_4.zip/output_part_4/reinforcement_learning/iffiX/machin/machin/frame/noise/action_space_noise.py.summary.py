import torch
from typing import Iterable, Tuple, Union, Dict, Any

# Global Ornstein-Uhlenbeck generator
DEFAULT_OU_GEN: Union[None, "OrnsteinUhlenbeckNoiseGen"] = None


class OrnsteinUhlenbeckNoiseGen:
    """
    Ornstein-Uhlenbeck noise generator.
    """

    def __init__(self, shape: torch.Size, **params: Any):
        self.shape = shape
        self.theta = params.get("theta", 0.15)
        self.mu = params.get("mu", 0.0)
        self.sigma = params.get("sigma", 0.2)
        self.dt = params.get("dt", 1.0)
        self.state = torch.zeros(shape, dtype=torch.float32)

    def reset(self) -> None:
        self.state.zero_()

    def sample(self, device: torch.device) -> torch.Tensor:
        noise = torch.randn(self.shape, dtype=self.state.dtype, device=device)
        delta = self.theta * (self.mu - self.state) * self.dt + self.sigma * torch.sqrt(
            torch.tensor(self.dt, dtype=self.state.dtype, device=device)
        ) * noise
        self.state += delta
        return self.state.clone()


def _prepare_params(
    noise_param: Union[Tuple[Any, ...], Iterable[Tuple[Any, ...]]],
    dim: int,
) -> Iterable[Tuple[Any, ...]]:
    if isinstance(noise_param, (list, tuple)) and len(noise_param) > 0 and isinstance(noise_param[0], tuple):
        if len(noise_param) != dim:
            raise ValueError(
                f"Number of parameter tuples ({len(noise_param)}) does not match action dimension ({dim})."
            )
        return noise_param
    else:
        # Broadcast single tuple to all dimensions
        return [noise_param for _ in range(dim)]


def add_uniform_noise_to_action(
    action: torch.Tensor,
    noise_param: Union[Tuple[float, float], Iterable[Tuple[float, float]]],
    ratio: float,
) -> torch.Tensor:
    dim = action.shape[-1]
    params = _prepare_params(noise_param, dim)
    min_vals = torch.tensor([p[0] for p in params], device=action.device, dtype=action.dtype)
    max_vals = torch.tensor([p[1] for p in params], device=action.device, dtype=action.dtype)
    shape = [1] * (action.dim() - 1) + [dim]
    min_vals = min_vals.view(shape)
    max_vals = max_vals.view(shape)

    noise = torch.rand_like(action)
    noise = noise * (max_vals - min_vals) + min_vals
    noise.mul_(ratio)
    return action + noise


def add_clipped_normal_noise_to_action(
    action: torch.Tensor,
    noise_param: Union[Tuple[float, float, float, float], Iterable[Tuple[float, float, float, float]]],
    ratio: float,
) -> torch.Tensor:
    dim = action.shape[-1]
    params = _prepare_params(noise_param, dim)
    means = torch.tensor([p[0] for p in params], device=action.device, dtype=action.dtype)
    sigmas = torch.tensor([p[1] for p in params], device=action.device, dtype=action.dtype)
    clip_mins = torch.tensor([p[2] for p in params], device=action.device, dtype=action.dtype)
    clip_maxs = torch.tensor([p[3] for p in params], device=action.device, dtype=action.dtype)

    shape = [1] * (action.dim() - 1) + [dim]
    means = means.view(shape)
    sigmas = sigmas.view(shape)
    clip_mins = clip_mins.view(shape)
    clip_maxs = clip_maxs.view(shape)

    noise = torch.randn_like(action)
    noise = noise * sigmas + means
    noise.clamp_(clip_mins, clip_maxs)
    noise.mul_(ratio)
    return action + noise


def add_normal_noise_to_action(
    action: torch.Tensor,
    noise_param: Union[Tuple[float, float], Iterable[Tuple[float, float]]],
    ratio: float,
) -> torch.Tensor:
    dim = action.shape[-1]
    params = _prepare_params(noise_param, dim)
    means = torch.tensor([p[0] for p in params], device=action.device, dtype=action.dtype)
    sigmas = torch.tensor([p[1] for p in params], device=action.device, dtype=action.dtype)

    shape = [1] * (action.dim() - 1) + [dim]
    means = means.view(shape)
    sigmas = sigmas.view(shape)

    noise = torch.randn_like(action)
    noise = noise * sigmas + means
    noise.mul_(ratio)
    return action + noise


def add_ou_noise_to_action(
    action: torch.Tensor,
    noise_param: Dict[str, Any],
    ratio: float,
    reset: bool = False,
) -> torch.Tensor:
    global DEFAULT_OU_GEN

    if reset:
        DEFAULT_OU_GEN = None

    if DEFAULT_OU_GEN is None:
        DEFAULT_OU_GEN = OrnsteinUhlenbeckNoiseGen(
            shape=action.shape, **noise_param
        )
        DEFAULT_OU_GEN.reset()

    noise = DEFAULT_OU_GEN.sample(device=action.device)
    noise = noise * ratio
    return action + noise
