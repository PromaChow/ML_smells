import os
import sys
import numpy as np

# Adjust the Python path to include the parent directory
parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

# Define weight matrices and bias vectors for a neural network with three dense layers

# First dense layer: 5 neurons, each with 50 input features
weights_dense1_w = np.arange(5 * 50, dtype=np.float32).reshape(5, 50)
weights_dense1_b = np.arange(5, dtype=np.float32)

# Second dense layer: 30 neurons, each receiving 5 inputs from the first layer
weights_dense2_w = np.arange(30 * 5, dtype=np.float32).reshape(30, 5)
weights_dense2_b = np.arange(30, dtype=np.float32)

# Final output layer: 30 inputs from the second layer producing a single output
weights_final_w = np.arange(30 * 1, dtype=np.float32).reshape(30, 1)
weights_final_b = np.array([0.0], dtype=np.float32)  # single bias term
