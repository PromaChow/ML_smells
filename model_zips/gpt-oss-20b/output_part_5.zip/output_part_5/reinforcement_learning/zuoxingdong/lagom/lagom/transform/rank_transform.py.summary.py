import numpy as np

def rank_transform(x, centered=True):
    x_arr = np.asarray(x)
    assert x_arr.ndim == 1, "Input must be one-dimensional."
    n = x_arr.size
    ranks = np.empty(n, dtype=float)
    sorted_indices = np.argsort(x_arr)
    ranks[sorted_indices] = np.arange(n)
    if centered:
        if n > 1:
            ranks = ranks / (n - 1) - 0.5
        else:
            ranks = np.array([0.0])
    return ranks[:]  # ensure a copy is returned if necessary
