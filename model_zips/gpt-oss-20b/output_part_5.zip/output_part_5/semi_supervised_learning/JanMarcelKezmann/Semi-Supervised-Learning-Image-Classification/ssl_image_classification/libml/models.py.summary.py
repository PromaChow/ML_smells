import tensorflow as tf

def get_model(
    height: int,
    width: int,
    name: str,
    include_top: bool = True,
    classes: int = 1000,
    weights: str | None = "imagenet",
    pooling: str | None = None,
    classifier_activation: str | None = "softmax",
    alpha: float = 1.0,
    depth_multiplier: float = 1.0,
    dropout: float = 0.0,
):
    # Validate height and width types
    if not isinstance(height, int) or not isinstance(width, int):
        raise TypeError("height and width must be integers")

    # Supported models
    large_models = {
        "DenseNet121",
        "DenseNet169",
        "DenseNet201",
        "EfficientNetB0",
        "EfficientNetB1",
        "EfficientNetB2",
        "EfficientNetB3",
        "EfficientNetB4",
        "EfficientNetB5",
        "EfficientNetB6",
        "EfficientNetB7",
        "MobileNet",
        "MobileNetV2",
        "NASNetMobile",
        "NASNetLarge",
        "ResNet50",
        "ResNet101",
        "ResNet152",
        "VGG16",
        "VGG19",
    }
    inception_models = {"InceptionResNetV2", "InceptionV3"}
    xception_model = "Xception"

    # Minimum size checks
    if name in large_models:
        min_size = 32
    elif name in inception_models:
        min_size = 75
    elif name == xception_model:
        min_size = 71
    else:
        valid_names = sorted(large_models | inception_models | {xception_model})
        raise ValueError(
            f"Unsupported model name '{name}'. "
            f"Valid options are: {', '.join(valid_names)}"
        )

    if height < min_size or width < min_size:
        raise ValueError(
            f"{name} requires input size at least {min_size}x{min_size}. "
            f"Got {height}x{width}."
        )

    # Mapping from name to constructor
    constructors = {
        "DenseNet121": tf.keras.applications.DenseNet121,
        "DenseNet169": tf.keras.applications.DenseNet169,
        "DenseNet201": tf.keras.applications.DenseNet201,
        "EfficientNetB0": tf.keras.applications.EfficientNetB0,
        "EfficientNetB1": tf.keras.applications.EfficientNetB1,
        "EfficientNetB2": tf.keras.applications.EfficientNetB2,
        "EfficientNetB3": tf.keras.applications.EfficientNetB3,
        "EfficientNetB4": tf.keras.applications.EfficientNetB4,
        "EfficientNetB5": tf.keras.applications.EfficientNetB5,
        "EfficientNetB6": tf.keras.applications.EfficientNetB6,
        "EfficientNetB7": tf.keras.applications.EfficientNetB7,
        "MobileNet": tf.keras.applications.MobileNet,
        "MobileNetV2": tf.keras.applications.MobileNetV2,
        "NASNetMobile": tf.keras.applications.NASNetMobile,
        "NASNetLarge": tf.keras.applications.NASNetLarge,
        "ResNet50": tf.keras.applications.ResNet50,
        "ResNet101": tf.keras.applications.ResNet101,
        "ResNet152": tf.keras.applications.ResNet152,
        "VGG16": tf.keras.applications.VGG16,
        "VGG19": tf.keras.applications.VGG19,
        "InceptionResNetV2": tf.keras.applications.InceptionResNetV2,
        "InceptionV3": tf.keras.applications.InceptionV3,
        "Xception": tf.keras.applications.Xception,
    }

    constructor = constructors[name]

    # Base model arguments
    base_kwargs = {
        "include_top": include_top,
        "classes": classes,
        "weights": weights,
        "input_shape": (height, width, 3),
        "pooling": pooling,
        "classifier_activation": classifier_activation,
    }

    # Add MobileNet specific arguments
    if name in {"MobileNet", "MobileNetV2"}:
        base_kwargs.update(
            {
                "alpha": alpha,
                "depth_multiplier": depth_multiplier,
                "dropout": dropout,
            }
        )

    base_model = constructor(**base_kwargs)

    # Create custom model with dual outputs
    inputs = base_model.input
    outputs = [base_model.output, base_model.layers[-2].output]
    return tf.keras.Model(inputs=inputs, outputs=outputs)