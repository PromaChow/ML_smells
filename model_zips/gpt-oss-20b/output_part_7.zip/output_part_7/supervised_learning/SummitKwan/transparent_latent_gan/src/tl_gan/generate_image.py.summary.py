import os
import sys
import pickle
import numpy as np
import tensorflow as tf
from PIL import Image

# Add pg-gan source to sys.path
PGGAN_SRC = "/path/to/pg-gan"
sys.path.append(PGGAN_SRC)

# Pre-trained model path
PATH_MODEL = "/path/to/pretrained_model.pkl"

# Constants
LEN_Z = 512
LEN_DUMMY = 0

# Load the pre-trained generator
with open(PATH_MODEL, "rb") as f:
    Gs = pickle.load(f)

def generate_image(z: np.ndarray = None) -> np.ndarray:
    """
    Generate a single image using the pg-gan generator.

    Parameters
    ----------
    z : np.ndarray, optional
        Latent vector. If None, a random vector of shape (LEN_Z,) is generated.

    Returns
    -------
    np.ndarray
        RGB image array of shape (H, W, 3) with dtype uint8.
    """
    if z is None:
        z = np.random.randn(LEN_Z).astype(np.float32)
    if z.ndim == 1:
        z = z[np.newaxis, :]

    dummy = np.zeros([z.shape[0], LEN_DUMMY], dtype=np.float32)

    # Generator inference
    # Gs.run returns a list [images, _] where images is a NCHW array
    out = Gs.run(z, dummy)[0]
    images = out

    # Post-processing
    images = (images + 1.0) / 2.0 * 255.0
    images = np.clip(images, 0, 255).astype(np.uint8)
    images = np.transpose(images, (0, 2, 3, 1))  # NCHW -> NHWC

    return images[0]

def save_img(img_array: np.ndarray, file_path: str) -> None:
    """
    Save an RGB image array to disk.

    Parameters
    ----------
    img_array : np.ndarray
        RGB image array of shape (H, W, 3) with dtype uint8.
    file_path : str
        Destination file path.
    """
    img = Image.fromarray(img_array)
    img.save(file_path)

# Example usage
if __name__ == "__main__":
    img = generate_image()
    save_img(img, "generated_image.png")