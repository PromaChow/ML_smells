import torch
from abc import ABC, abstractmethod
from typing import Tuple

class Transform(ABC):
    @abstractmethod
    def transform(self, input_tensor: torch.Tensor) -> torch.Tensor:
        """Process the input tensor and return the transformed tensor."""
        pass

    @abstractmethod
    def infer_output_info(self) -> Tuple[Tuple[int, ...], torch.dtype]:
        """Return output shape tuple and torch data type."""
        pass

class OneHot(Transform):
    def __init__(self, out_dim: int):
        self.out_dim = out_dim

    def transform(self, input_tensor: torch.Tensor) -> torch.Tensor:
        device = input_tensor.device
        output_shape = input_tensor.shape[:-1] + (self.out_dim,)
        output = torch.zeros(output_shape, device=device, dtype=torch.float32)
        indices = input_tensor.long()
        src = torch.ones_like(indices, dtype=torch.float32)
        output.scatter_(-1, indices.unsqueeze(-1), src)
        return output

    def infer_output_info(self) -> Tuple[Tuple[int, ...], torch.dtype]:
        return (self.out_dim,), torch.float32

if __name__ == "__main__":
    # Example usage
    batch = 2
    seq = 3
    input_dim = 5
    out_dim = 10
    input_tensor = torch.randint(0, out_dim, (batch, seq, input_dim))
    one_hot = OneHot(out_dim)
    output_tensor = one_hot.transform(input_tensor)
    print("Input shape:", input_tensor.shape)
    print("Output shape:", output_tensor.shape)
    print("Output info:", one_hot.infer_output_info())
    print(output_tensor)