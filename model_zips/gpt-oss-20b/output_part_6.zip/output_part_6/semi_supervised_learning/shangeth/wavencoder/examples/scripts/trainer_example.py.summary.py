import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
import torchaudio

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# --- Model components --------------------------------------------------------

class LSTM_Attn_Classifier(nn.Module):
    def __init__(self, input_dim: int, hidden_size: int, num_classes: int):
        super().__init__()
        self.lstm = nn.LSTM(input_dim, hidden_size, batch_first=True, bidirectional=True)
        self.attn = nn.Linear(hidden_size * 2, 1)
        self.fc = nn.Linear(hidden_size * 2, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (batch, time, features)
        lstm_out, _ = self.lstm(x)  # (batch, time, hidden*2)
        attn_weights = torch.softmax(self.attn(lstm_out), dim=1)  # (batch, time, 1)
        context = torch.sum(attn_weights * lstm_out, dim=1)  # (batch, hidden*2)
        logits = self.fc(context)  # (batch, num_classes)
        return logits


# --- Data preparation --------------------------------------------------------

X_train = torch.randn(10, 1, 16000, dtype=torch.float32)
y_train = torch.randint(0, 2, (10, 1), dtype=torch.float32)

X_val = torch.randn(5, 1, 16000, dtype=torch.float32)
y_val = torch.randint(0, 2, (5, 1), dtype=torch.float32)

X_test = torch.randn(10, 1, 16000, dtype=torch.float32)
y_test = torch.randint(0, 2, (10, 1), dtype=torch.float32)

train_dataset = TensorDataset(X_train, y_train)
val_dataset = TensorDataset(X_val, y_val)
test_dataset = TensorDataset(X_test, y_test)

train_loader = DataLoader(train_dataset, batch_size=10, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=5, shuffle=False)
test_loader = DataLoader(test_dataset, batch_size=5, shuffle=False)

# --- Model architecture -----------------------------------------------------

wav2vec_encoder = torchaudio.models.wav2vec2_base(pretrained=False)
wav2vec_encoder = wav2vec_encoder.to(device)

classifier = LSTM_Attn_Classifier(input_dim=512, hidden_size=64, num_classes=2).to(device)

model = nn.Sequential(wav2vec_encoder, classifier)
model = model.to(device)

# --- Optimizer and scheduler -----------------------------------------------

optimizer = optim.SGD(model.parameters(), lr=1e-3)
scheduler = optim.lr_scheduler.CyclicLR(optimizer, base_lr=1e-4, max_lr=1e-1, step_size_up=10, mode='triangular')

criterion = nn.BCEWithLogitsLoss()

# --- Training loop ----------------------------------------------------------

def train(model, train_loader, val_loader, epochs, optimizer, scheduler):
    model.train()
    for epoch in range(epochs):
        epoch_loss = 0.0
        for batch_idx, (data, target) in enumerate(train_loader):
            data, target = data.to(device), target.to(device)
            optimizer.zero_grad()
            output = model(data)
            loss = criterion(output, target)
            loss.backward()
            optimizer.step()
            scheduler.step()
            epoch_loss += loss.item()
        # Validation
        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for data, target in val_loader:
                data, target = data.to(device), target.to(device)
                output = model(data)
                loss = criterion(output, target)
                val_loss += loss.item()
        model.train()
        print(f'Epoch {epoch+1}/{epochs} - Train loss: {epoch_loss/len(train_loader):.4f} - Val loss: {val_loss/len(val_loader):.4f}')

# --- Testing ---------------------------------------------------------------

def test_predict_classifier(model, test_loader):
    model.eval()
    predictions = []
    with torch.no_grad():
        for data, _ in test_loader:
            data = data.to(device)
            logits = model(data)
            probs = torch.sigmoid(logits)
            preds = (probs > 0.5).int()
            predictions.extend(preds.cpu().numpy().tolist())
    return {"predictions": predictions}

# --- Execute pipeline --------------------------------------------------------

train(model, train_loader, val_loader, epochs=5, optimizer=optimizer, scheduler=scheduler)
test_dict = test_predict_classifier(model, test_loader)
print(test_dict)