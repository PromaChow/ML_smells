import unittest
import numpy as np
from pywsl import cpe_ene, gen_twonorm_ssl

class TestCPEEne(unittest.TestCase):
    def _prepare_data(self):
        # Generate synthetic data
        X, y = gen_twonorm_ssl(
            n_l=100,
            prior_l=0.5,
            n_u=300,
            prior_u=0.3,
            n_t=100
        )
        # Separate labeled and unlabeled samples
        mask_labeled = y != 0
        mask_unlabeled = y == 0
        x_l = X[mask_labeled]
        y_l = y[mask_labeled]
        x_u = X[mask_unlabeled]
        return x_l, y_l, x_u

    def test_alpha_one(self):
        x_l, y_l, x_u = self._prepare_data()
        prior_est = cpe_ene(x_l, y_l, x_u)
        self.assertTrue(0.2 <= prior_est <= 0.4,
                        f"Estimated prior {prior_est} not within [0.2, 0.4]")

    def test_alpha_half(self):
        x_l, y_l, x_u = self._prepare_data()
        prior_est = cpe_ene(x_l, y_l, x_u, alpha=0.5)
        print(f"Estimated prior with alpha=0.5: {prior_est}")

if __name__ == "__main__":
    unittest.main()