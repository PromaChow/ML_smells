import numpy as np

def numpify(x):
    """Convert input to a NumPy array of type float32."""
    return np.asarray(x, dtype=np.float32)

def td0_target(rewards, Vs, last_V, gamma, reach_terminal):
    """
    Compute TD(0) targets for a batch of episodic transitions.
    
    Parameters
    ----------
    rewards : array-like
        Rewards received at each transition.
    Vs : array-like
        Estimated state values at each state in the batch.
    last_V : float or array-like
        Estimated value of the final state (used when terminal state is not reached).
    gamma : float
        Discount factor.
    reach_terminal : bool
        Flag indicating whether the episode ended in a terminal state.
    
    Returns
    -------
    ndarray
        TD(0) targets as a float32 array.
    """
    rewards = numpify(rewards)
    Vs = numpify(Vs)
    last_V = numpify(last_V)

    if reach_terminal:
        Vs_extended = np.append(Vs, 0.0)
    else:
        Vs_extended = np.append(Vs, last_V)

    target = rewards + gamma * Vs_extended[1:]
    return target.astype(np.float32)

def td0_error(rewards, Vs, last_V, gamma, reach_terminal):
    """
    Compute TD(0) errors for a batch of episodic transitions.
    
    Parameters
    ----------
    rewards : array-like
        Rewards received at each transition.
    Vs : array-like
        Estimated state values at each state in the batch.
    last_V : float or array-like
        Estimated value of the final state (used when terminal state is not reached).
    gamma : float
        Discount factor.
    reach_terminal : bool
        Flag indicating whether the episode ended in a terminal state.
    
    Returns
    -------
    ndarray
        TD(0) errors as a float32 array.
    """
    rewards = numpify(rewards)
    Vs = numpify(Vs)
    last_V = numpify(last_V)

    if reach_terminal:
        Vs_extended = np.append(Vs, 0.0)
    else:
        Vs_extended = np.append(Vs, last_V)

    target = rewards + gamma * Vs_extended[1:]
    error = target - Vs_extended[:-1]
    return error.astype(np.float32)