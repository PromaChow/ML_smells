import re
import csv
import numpy as np
from pathlib import Path
from sklearn.feature_extraction.text import CountVectorizer
import joblib

import datasetUtils as dsu
import embeddings


def clean_tweet(tweet: str) -> str:
    """Remove URLs and mentions from a tweet."""
    tweet = re.sub(r'http\S+', '', tweet)          # http URLs
    tweet = re.sub(r'www\.\S+', '', tweet)          # non-http URLs
    tweet = re.sub(r'@\w+', '', tweet)             # mentions
    return tweet.strip()


def load_usernames(user_input: str) -> list[str]:
    """Return a list of usernames based on user input."""
    usernames = []
    user_input = user_input.strip()
    if user_input.startswith("@"):
        usernames.append(user_input[1:])
    else:
        file_path = Path(user_input)
        if file_path.is_file() and file_path.stat().st_size > 0:
            with file_path.open('r', encoding='utf-8') as f:
                for line in f:
                    name = line.strip()
                    if name and name.startswith("@"):
                        usernames.append(name[1:])
                    elif name:
                        usernames.append(name)
    return usernames


def process_tweets(username: str) -> list[str]:
    """Read and filter tweets for a given username."""
    tweet_file = Path("Data") / username / f"_{username}_tweets.txt"
    if not tweet_file.is_file():
        return []

    filtered = []
    with tweet_file.open('r', encoding='utf-8') as f:
        for line in f:
            tweet = line.strip()
            if not tweet or tweet.startswith("RT"):
                continue
            tweet = clean_tweet(tweet)
            if tweet:
                filtered.append(tweet)
    return filtered


def main() -> None:
    # Configuration
    fasttext_path = Path("../FastText/dataset.vec")
    tweet_threshold = 3
    vectorizer = CountVectorizer(stop_words="english", analyzer="word")

    # Load resources
    fasttext_dict = dsu.parseFastText(str(fasttext_path))
    svm_models = {}
    for trait in ["O", "C", "E", "A", "N"]:
        model_file = Path(f"SVM_Big_conc_{trait}_userWise.pkl")
        if not model_file.is_file():
            print(f"Missing model file: {model_file}")
            return
        svm_models[trait] = joblib.load(str(model_file))

    # Input handling
    user_input = input("Enter a username (e.g., @user) or filename: ")
    usernames = load_usernames(user_input)
    if not usernames:
        print("No valid usernames found.")
        return

    # Prepare output
    results = []
    for username in usernames:
        tweets = process_tweets(username)
        if not tweets:
            print(f"No valid tweets for {username}. Skipping.")
            continue

        # Convert tweets to embeddings
        try:
            embeddings_arr = embeddings.transformTextForTesting(tweets, fasttext_dict, tweet_threshold)
        except Exception as e:
            print(f"Embedding transformation failed for {username}: {e}")
            continue

        if embeddings_arr is None or embeddings_arr.size == 0:
            print(f"No embeddings obtained for {username}. Skipping.")
            continue

        # Predict trait scores
        trait_scores = {}
        for trait, model in svm_models.items():
            try:
                # Use decision_function if available, else predict_proba
                if hasattr(model, "decision_function"):
                    preds = model.decision_function(embeddings_arr)
                else:
                    preds = model.predict_proba(embeddings_arr)[:, 1]
                avg_score = float(np.round(np.mean(preds), 5))
            except Exception as e:
                print(f"Prediction failed for {trait} on {username}: {e}")
                avg_score = 0.0
            trait_scores[trait] = avg_score

        # Determine Jungian type
        jungian = ""
        jungian += "E" if trait_scores["E"] > 3 else "I"
        jungian += "N" if trait_scores["O"] > 3 else "S"
        jungian += "F" if trait_scores["A"] > 3 else "T"
        jungian += "J" if trait_scores["C"] > 3 else "P"

        # Store result
        result_row = {
            "username": username,
            "O": trait_scores["O"],
            "C": trait_scores["C"],
            "E": trait_scores["E"],
            "A": trait_scores["A"],
            "N": trait_scores["N"],
            "Jungian_type": jungian,
        }
        results.append(result_row)

    # Write CSV
    if results:
        csv_path = Path("personality_predictions1_big_userWise.csv")
        fieldnames = ["username", "O", "C", "E", "A", "N", "Jungian_type"]
        with csv_path.open('w', newline='', encoding='utf-8') as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            for row in results:
                writer.writerow(row)
        print(f"Results written to {csv_path}")
    else:
        print("No results to write.")


if __name__ == "__main__":
    main()