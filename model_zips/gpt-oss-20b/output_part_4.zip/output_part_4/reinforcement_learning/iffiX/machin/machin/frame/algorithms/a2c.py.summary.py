import gym
import random
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim

class ReplayBuffer:
    def __init__(self, capacity=100000):
        self.capacity = capacity
        self.buffer = []

    def add(self, transition):
        if len(self.buffer) >= self.capacity:
            self.buffer.pop(0)
        self.buffer.append(transition)

    def sample(self, batch_size):
        batch = random.sample(self.buffer, batch_size)
        batch_dict = {}
        for key in batch[0]:
            batch_dict[key] = torch.stack([torch.tensor(item[key], dtype=torch.float32) for item in batch])
        return batch_dict

    def clear(self):
        self.buffer = []

class ActorNetwork(nn.Module):
    def __init__(self, obs_dim, action_dim, action_type='discrete', hidden_sizes=(128, 128)):
        super().__init__()
        layers = []
        last_dim = obs_dim
        for size in hidden_sizes:
            layers.append(nn.Linear(last_dim, size))
            layers.append(nn.ReLU())
            last_dim = size
        self.base = nn.Sequential(*layers)
        self.action_type = action_type
        if action_type == 'discrete':
            self.logits = nn.Linear(last_dim, action_dim)
        else:
            self.mean = nn.Linear(last_dim, action_dim)
            self.log_std = nn.Parameter(torch.zeros(action_dim))

    def forward(self, state):
        x = self.base(state)
        if self.action_type == 'discrete':
            logits = self.logits(x)
            dist = torch.distributions.Categorical(logits=logits)
        else:
            mean = self.mean(x)
            std = torch.exp(self.log_std)
            dist = torch.distributions.Normal(mean, std)
        return dist

class CriticNetwork(nn.Module):
    def __init__(self, obs_dim, hidden_sizes=(128, 128)):
        super().__init__()
        layers = []
        last_dim = obs_dim
        for size in hidden_sizes:
            layers.append(nn.Linear(last_dim, size))
            layers.append(nn.ReLU())
            last_dim = size
        layers.append(nn.Linear(last_dim, 1))
        self.value_net = nn.Sequential(*layers)

    def forward(self, state):
        return self.value_net(state).squeeze(-1)

class A2C:
    def __init__(self,
                 env,
                 actor_cfg,
                 critic_cfg,
                 actor_opt_cfg,
                 critic_opt_cfg,
                 lr_scheduler_cfg=None,
                 batch_size=64,
                 gamma=0.99,
                 lam=0.95,
                 entropy_weight=0.01,
                 value_weight=0.5,
                 normalize_advantage=True,
                 clip_norm=0.5):
        self.env = env
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.actor = ActorNetwork(**actor_cfg).to(self.device)
        self.critic = CriticNetwork(**critic_cfg).to(self.device)
        self.actor_opt = optim.Adam(self.actor.parameters(), **actor_opt_cfg)
        self.critic_opt = optim.Adam(self.critic.parameters(), **critic_opt_cfg)
        self.lr_schedulers = {}
        if lr_scheduler_cfg is not None:
            self.lr_schedulers['actor'] = optim.lr_scheduler.StepLR(self.actor_opt, **lr_scheduler_cfg.get('actor', {}))
            self.lr_schedulers['critic'] = optim.lr_scheduler.StepLR(self.critic_opt, **lr_scheduler_cfg.get('critic', {}))
        self.buffer = ReplayBuffer()
        self.batch_size = batch_size
        self.gamma = gamma
        self.lam = lam
        self.entropy_weight = entropy_weight
        self.value_weight = value_weight
        self.normalize_advantage = normalize_advantage
        self.clip_norm = clip_norm

    def act(self, state):
        state_t = torch.tensor(state, dtype=torch.float32).unsqueeze(0).to(self.device)
        dist = self.actor(state_t)
        if isinstance(dist, torch.distributions.Categorical):
            action = dist.sample()
            log_prob = dist.log_prob(action)
        else:
            action = dist.rsample()
            log_prob = dist.log_prob(action).sum(-1)
        return action.cpu().numpy(), log_prob.cpu().numpy()

    def _eval_act(self, state, action):
        state_t = torch.tensor(state, dtype=torch.float32).unsqueeze(0).to(self.device)
        action_t = torch.tensor(action, dtype=torch.float32).unsqueeze(0).to(self.device)
        dist = self.actor(state_t)
        if isinstance(dist, torch.distributions.Categorical):
            log_prob = dist.log_prob(action_t.long())
        else:
            log_prob = dist.log_prob(action_t).sum(-1)
        return log_prob

    def _criticize(self, state):
        state_t = torch.tensor(state, dtype=torch.float32).unsqueeze(0).to(self.device)
        with torch.no_grad():
            value = self.critic(state_t)
        return value.item()

    def store_episode(self, episode):
        values = []
        for transition in episode:
            val = self._criticize(transition['state'])
            values.append(val)
        values = values + [0]
        advantages = [0] * len(episode)
        gae = 0
        for t in reversed(range(len(episode))):
            delta = episode[t]['reward'] + self.gamma * values[t + 1] * (1 - episode[t]['done']) - values[t]
            gae = delta + self.gamma * self.lam * (1 - episode[t]['done']) * gae
            advantages[t] = gae
        returns = [adv + values[t] for t, adv in enumerate(advantages)]
        for t, transition in enumerate(episode):
            transition['value'] = values[t]
            transition['advantage'] = advantages[t]
            transition['return'] = returns[t]
            self.buffer.add(transition)

    def update(self):
        if len(self.buffer.buffer) < self.batch_size:
            return
        batch = self.buffer.sample(self.batch_size)
        states = batch['state']
        actions = batch['action']
        log_probs_old = batch['log_prob']
        advantages = batch['advantage']
        returns = batch['return']

        if self.normalize_advantage:
            adv_mean = advantages.mean()
            adv_std = advantages.std() + 1e-8
            advantages = (advantages - adv_mean) / adv_std

        # Actor update
        self.actor_opt.zero_grad()
        dist = self.actor(states)
        if isinstance(dist, torch.distributions.Categorical):
            log_probs = dist.log_prob(actions.long())
            entropy = dist.entropy().mean()
        else:
            log_probs = dist.log_prob(actions).sum(-1)
            entropy = dist.entropy().sum(-1).mean()
        actor_loss = -(log_probs * advantages.detach()).mean()
        if self.entropy_weight > 0:
            actor_loss -= self.entropy_weight * entropy
        actor_loss.backward()
        nn.utils.clip_grad_norm_(self.actor.parameters(), self.clip_norm)
        self.actor_opt.step()

        # Critic update
        self.critic_opt.zero_grad()
        values_pred = self.critic(states)
        critic_loss = ((values_pred - returns.detach()) ** 2).mean() * self.value_weight
        critic_loss.backward()
        nn.utils.clip_grad_norm_(self.critic.parameters(), self.clip_norm)
        self.critic_opt.step()

        self.buffer.clear()
        self.actor.eval()
        self.critic.eval()

    def update_lr_scheduler(self):
        for scheduler in self.lr_schedulers.values():
            scheduler.step()

    @staticmethod
    def generate_config():
        return {
            'actor': {
                'obs_dim': 4,
                'action_dim': 2,
                'action_type': 'discrete',
                'hidden_sizes': (128, 128)
            },
            'critic': {
                'obs_dim': 4,
                'hidden_sizes': (128, 128)
            },
            'actor_opt': {
                'lr': 3e-4
            },
            'critic_opt': {
                'lr': 3e-4
            },
            'lr_scheduler': {
                'actor': {'step_size': 1000, 'gamma': 0.99},
                'critic': {'step_size': 1000, 'gamma': 0.99}
            },
            'batch_size': 64,
            'gamma': 0.99,
            'lam': 0.95,
            'entropy_weight': 0.01,
            'value_weight': 0.5,
            'normalize_advantage': True,
            'clip_norm': 0.5
        }

    @classmethod
    def init_from_config(cls, env, config):
        return cls(
            env=env,
            actor_cfg=config['actor'],
            critic_cfg=config['critic'],
            actor_opt_cfg=config['actor_opt'],
            critic_opt_cfg=config['critic_opt'],
            lr_scheduler_cfg=config.get('lr_scheduler'),
            batch_size=config.get('batch_size', 64),
            gamma=config.get('gamma', 0.99),
            lam=config.get('lam', 0.95),
            entropy_weight=config.get('entropy_weight', 0.01),
            value_weight=config.get('value_weight', 0.5),
            normalize_advantage=config.get('normalize_advantage', True),
            clip_norm=config.get('clip_norm', 0.5)
        )
```