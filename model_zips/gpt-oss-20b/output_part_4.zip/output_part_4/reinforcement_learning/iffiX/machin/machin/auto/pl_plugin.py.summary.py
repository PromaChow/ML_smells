import os
import logging
import multiprocessing as mp
import torch
import torch.distributed as dist
import pytorch_lightning as pl
from pytorch_lightning.plugins import DDPPlugin as LightningDDPPlugin
from pytorch_lightning.plugins import DDPSpawnPlugin as LightningDDPSpawnPlugin

pl_logger = logging.getLogger("pytorch_lightning")

def assert_world_config(master_addr, master_port, world_size):
    if not master_addr:
        raise AssertionError("MASTER_ADDR is not set. Please set it before running.")
    if not master_port:
        raise AssertionError("MASTER_PORT is not set. Please set it before running.")
    if not world_size:
        raise AssertionError("WORLD_SIZE is not set. Please set it before running.")
    if int(world_size) < 1:
        raise AssertionError("WORLD_SIZE must be at least 1.")

class CustomDDPPlugin(LightningDDPPlugin):
    def init_ddp_connection(self):
        master_addr = os.getenv("MASTER_ADDR", None)
        master_port = os.getenv("MASTER_PORT", None)
        world_size = os.getenv("WORLD_SIZE", None)
        assert_world_config(master_addr, master_port, world_size)
        if not dist.is_initialized():
            dist.init_process_group(
                backend="gloo",
                init_method=f"tcp://{master_addr}:{master_port}",
                world_size=int(world_size),
                rank=dist.get_rank() if dist.is_initialized() else 0,
            )
        pl_logger.debug("DDP world initialized with gloo backend.")

    def configure_ddp(self):
        self.init_ddp_connection()
        framework = self.lightning_module.framework
        self.trainer.accelerator.set_optimizers(
            framework.optimizers, framework.lr_schedulers
        )
        super().configure_ddp()

    def train(self, *args, **kwargs):
        return self.lightning_module.train(*args, **kwargs)

    def validate(self, *args, **kwargs):
        return self.lightning_module.validate(*args, **kwargs)

    def test(self, *args, **kwargs):
        return self.lightning_module.test(*args, **kwargs)

    def predict(self, *args, **kwargs):
        return self.lightning_module.predict(*args, **kwargs)

class CustomDDPSpawnPlugin(LightningDDPSpawnPlugin):
    def init_ddp_connection(self):
        master_addr = os.getenv("MASTER_ADDR", None)
        master_port = os.getenv("MASTER_PORT", None)
        world_size = os.getenv("WORLD_SIZE", None)
        assert_world_config(master_addr, master_port, world_size)
        if not dist.is_initialized():
            dist.init_process_group(
                backend="gloo",
                init_method=f"tcp://{master_addr}:{master_port}",
                world_size=int(world_size),
                rank=dist.get_rank() if dist.is_initialized() else 0,
            )
        pl_logger.debug("DDPSpawn world initialized with gloo backend.")

    def configure_ddp(self):
        self.init_ddp_connection()
        framework = self.lightning_module.framework
        self.trainer.accelerator.set_optimizers(
            framework.optimizers, framework.lr_schedulers
        )
        super().configure_ddp()

    def _spawn(self, target, args=(), kwargs=None):
        if kwargs is None:
            kwargs = {}
        world_size = int(os.getenv("WORLD_SIZE", "1"))
        processes = []
        exception = None

        def wrapper(rank, *p_args):
            try:
                self.init_ddp_connection()
                target(*p_args, **kwargs)
            except Exception as e:
                nonlocal exception
                exception = e

        for rank in range(world_size):
            p = mp.Process(target=wrapper, args=(rank, *args))
            p.start()
            processes.append(p)

        for p in processes:
            p.join()
            if p.exitcode != 0:
                exception = exception or RuntimeError(f"Process {p.pid} exited with code {p.exitcode}")

        if exception:
            for p in processes:
                if p.is_alive():
                    p.terminate()
            raise RuntimeError(f"Distributed process failed: {exception}")

    def start_training(self):
        self._spawn(self.trainer.fit)

    def start_testing(self):
        self._spawn(self.trainer.test)

    def start_predicting(self):
        self._spawn(self.trainer.predict)

    def train(self, *args, **kwargs):
        return self.lightning_module.train(*args, **kwargs)

    def validate(self, *args, **kwargs):
        return self.lightning_module.validate(*args, **kwargs)

    def test(self, *args, **kwargs):
        return self.lightning_module.test(*args, **kwargs)

    def predict(self, *args, **kwargs):
        return self.lightning_module.predict(*args, **kwargs)

# Monkey patch
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp.DDPPlugin = CustomDDPPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawn
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin
pl.plugins.dist.ddp_spawn.DDPSpawnPlugin = CustomDDPSpawnPlugin

