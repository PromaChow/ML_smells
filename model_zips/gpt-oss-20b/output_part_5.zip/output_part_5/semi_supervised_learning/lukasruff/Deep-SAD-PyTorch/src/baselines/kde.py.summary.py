import json
import time
import numpy as np
import torch
from torch.utils.data import DataLoader
from sklearn.neighbors import KernelDensity
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import roc_auc_score


class KDEHybridModel:
    def __init__(self, kernel="gaussian", n_jobs=1, seed=42,
                 hybrid=False, device="cpu", ae_path=None, batch_size=128):
        self.kernel = kernel
        self.n_jobs = n_jobs
        self.seed = seed
        self.hybrid = hybrid
        self.device = torch.device(device)
        self.batch_size = batch_size

        torch.manual_seed(self.seed)
        np.random.seed(self.seed)

        self.kde = KernelDensity(kernel=self.kernel)
        self.ae_net = None
        if self.hybrid:
            if ae_path is None:
                raise ValueError("ae_path must be provided when hybrid is True")
            self.ae_net = self.load_ae(ae_path)
        self.results = {
            "train_time": None,
            "test_time": None,
            "auc": None,
            "scores": None
        }

    def load_ae(self, path):
        ae = torch.load(path, map_location=self.device)
        if hasattr(ae, "eval"):
            ae.eval()
        return ae

    def _extract_features(self, batch):
        inputs = batch
        if self.hybrid:
            with torch.no_grad():
                feats = self.ae_net.encoder(inputs.to(self.device))
            return feats.cpu().numpy()
        else:
            return inputs.cpu().numpy()

    def train(self, dataset):
        train_loader = DataLoader(dataset.train_set,
                                  batch_size=self.batch_size,
                                  shuffle=False)
        X_parts = []
        start = time.time()
        for batch in train_loader:
            batch = batch.to(self.device) if isinstance(batch, torch.Tensor) else batch[0]
            feats = self._extract_features(batch)
            X_parts.append(feats.reshape(feats.shape[0], -1))
        X = np.concatenate(X_parts, axis=0)

        if self.kernel == "exponential":
            dists = np.linalg.norm(X[:, None] - X[None, :], axis=2)
            bandwidth = np.max(dists) ** 2
            self.kde = KernelDensity(kernel=self.kernel, bandwidth=bandwidth)
            self.kde.fit(X)
        else:
            bandwidths = np.logspace(np.log2(2**0.5), np.log2(2**5), num=10)
            param_grid = {"bandwidth": bandwidths}
            grid = GridSearchCV(KernelDensity(kernel=self.kernel),
                                param_grid,
                                cv=5,
                                n_jobs=self.n_jobs,
                                verbose=0)
            grid.fit(X)
            best_bw = grid.best_params_["bandwidth"]
            self.kde = KernelDensity(kernel=self.kernel, bandwidth=best_bw)
            self.kde.fit(X)

        self.results["train_time"] = time.time() - start

    def test(self, dataset):
        test_loader = DataLoader(dataset.test_set,
                                 batch_size=self.batch_size,
                                 shuffle=False)
        X_parts = []
        idxs = []
        labels = []
        for batch_idx, batch in enumerate(test_loader):
            inputs, lbls = batch[0].to(self.device), batch[1]
            feats = self._extract_features(inputs)
            X_parts.append(feats.reshape(feats.shape[0], -1))
            batch_size = feats.shape[0]
            idxs.extend(range(batch_idx * self.batch_size,
                              batch_idx * self.batch_size + batch_size))
            labels.extend(lbls.tolist())

        X_test = np.concatenate(X_parts, axis=0)
        start = time.time()
        scores = -self.kde.score_samples(X_test)
        test_time = time.time() - start
        auc = roc_auc_score(labels, scores)

        self.results.update({
            "test_time": test_time,
            "auc": auc,
            "scores": {
                "indices": idxs,
                "labels": labels,
                "scores": scores.tolist()
            }
        })

    def save_results(self, path):
        with open(path, "w") as f:
            json.dump(self.results, f, indent=4)