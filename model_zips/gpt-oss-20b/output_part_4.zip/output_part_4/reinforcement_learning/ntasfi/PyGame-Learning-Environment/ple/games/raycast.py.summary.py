import pygame
import sys
import numpy as np
import math

# Block definitions
BLOCKS = {
    0: {"pass": True, "color": (0, 0, 0)},          # empty
    1: {"pass": False, "color": (200, 200, 200)},   # wall
    2: {"pass": False, "color": (150, 50, 50)},     # red wall
    3: {"pass": False, "color": (50, 150, 50)},     # green wall
    4: {"pass": False, "color": (50, 50, 150)},     # blue wall
}

class RayCastPlayer:
    def __init__(self, map_data, width=640, height=480, resolution=320):
        self.map = map_data
        self.map_height, self.map_width = map_data.shape
        self.width = width
        self.height = height
        self.resolution = resolution
        self.x = 3.5
        self.y = 3.5
        self.dir_x = -1.0
        self.dir_y = 0.0
        self.plane_x = 0.0
        self.plane_y = 0.66
        self.move_speed = 0.05
        self.rot_speed = 0.03

    def _handle_player_events(self, keys):
        # Movement forward/backward
        if keys[pygame.K_w]:
            new_x = self.x + self.dir_x * self.move_speed
            new_y = self.y + self.dir_y * self.move_speed
            if BLOCKS[self.map[int(new_y), int(self.x)]["pass"]]:
                self.x = new_x
            if BLOCKS[self.map[int(self.y), int(new_x)]["pass"]]:
                self.y = new_y
        if keys[pygame.K_s]:
            new_x = self.x - self.dir_x * self.move_speed
            new_y = self.y - self.dir_y * self.move_speed
            if BLOCKS[self.map[int(new_y), int(self.x)]["pass"]]:
                self.x = new_x
            if BLOCKS[self.map[int(self.y), int(new_x)]["pass"]]:
                self.y = new_y
        # Rotation
        if keys[pygame.K_a]:
            old_dir_x = self.dir_x
            self.dir_x = self.dir_x * math.cos(self.rot_speed) - self.dir_y * math.sin(self.rot_speed)
            self.dir_y = old_dir_x * math.sin(self.rot_speed) + self.dir_y * math.cos(self.rot_speed)
            old_plane_x = self.plane_x
            self.plane_x = self.plane_x * math.cos(self.rot_speed) - self.plane_y * math.sin(self.rot_speed)
            self.plane_y = old_plane_x * math.sin(self.rot_speed) + self.plane_y * math.cos(self.rot_speed)
        if keys[pygame.K_d]:
            old_dir_x = self.dir_x
            self.dir_x = self.dir_x * math.cos(-self.rot_speed) - self.dir_y * math.sin(-self.rot_speed)
            self.dir_y = old_dir_x * math.sin(-self.rot_speed) + self.dir_y * math.cos(-self.rot_speed)
            old_plane_x = self.plane_x
            self.plane_x = self.plane_x * math.cos(-self.rot_speed) - self.plane_y * math.sin(-self.rot_speed)
            self.plane_y = old_plane_x * math.sin(-self.rot_speed) + self.plane_y * math.cos(-self.rot_speed)

    def draw(self, surface):
        for x in range(self.resolution):
            camera_x = 2 * x / float(self.resolution) - 1
            ray_dir_x = self.dir_x + self.plane_x * camera_x
            ray_dir_y = self.dir_y + self.plane_y * camera_x

            map_x = int(self.x)
            map_y = int(self.y)

            delta_dist_x = abs(1 / ray_dir_x) if ray_dir_x != 0 else 1e30
            delta_dist_y = abs(1 / ray_dir_y) if ray_dir_y != 0 else 1e30

            if ray_dir_x < 0:
                step_x = -1
                side_dist_x = (self.x - map_x) * delta_dist_x
            else:
                step_x = 1
                side_dist_x = (map_x + 1.0 - self.x) * delta_dist_x
            if ray_dir_y < 0:
                step_y = -1
                side_dist_y = (self.y - map_y) * delta_dist_y
            else:
                step_y = 1
                side_dist_y = (map_y + 1.0 - self.y) * delta_dist_y

            hit = False
            side = 0
            while not hit:
                if side_dist_x < side_dist_y:
                    side_dist_x += delta_dist_x
                    map_x += step_x
                    side = 0
                else:
                    side_dist_y += delta_dist_y
                    map_y += step_y
                    side = 1
                if 0 <= map_x < self.map_width and 0 <= map_y < self.map_height:
                    if self.map[map_y, map_x] > 0:
                        hit = True

            if side == 0:
                perp_wall_dist = (map_x - self.x + (1 - step_x) / 2) / ray_dir_x
            else:
                perp_wall_dist = (map_y - self.y + (1 - step_y) / 2) / ray_dir_y

            line_height = int(self.height / (perp_wall_dist + 0.0001))

            draw_start = -line_height // 2 + self.height // 2
            if draw_start < 0:
                draw_start = 0
            draw_end = line_height // 2 + self.height // 2
            if draw_end >= self.height:
                draw_end = self.height - 1

            block_type = self.map[map_y, map_x]
            base_color = BLOCKS[block_type]["color"]
            shade = 0.7 if side == 1 else 1.0
            brightness = max(0, min(1, 1 / (perp_wall_dist ** 2 + 0.1)))
            color = (
                int(base_color[0] * shade * brightness),
                int(base_color[1] * shade * brightness),
                int(base_color[2] * shade * brightness),
            )

            pygame.draw.line(surface, color, (x * self.width // self.resolution, draw_start),
                             (x * self.width // self.resolution, draw_end))

def make_map(size_x, size_y):
    m = np.zeros((size_y, size_x), dtype=int)
    m[0, :] = 1
    m[-1, :] = 1
    m[:, 0] = 1
    m[:, -1] = 1
    return m

def make_box(m, x, y, w, h, block_type):
    m[y:y+h, x:x+w] = block_type

def main():
    pygame.init()
    screen_width = 640
    screen_height = 480
    screen = pygame.display.set_mode((screen_width, screen_height))
    clock = pygame.time.Clock()

    map_data = make_map(16, 16)
    make_box(map_data, 4, 4, 8, 1, 2)
    make_box(map_data, 4, 8, 1, 4, 3)
    make_box(map_data, 11, 8, 1, 4, 4)
    make_box(map_data, 8, 12, 8, 1, 1)

    player = RayCastPlayer(map_data, screen_width, screen_height, resolution=screen_width)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        keys = pygame.key.get_pressed()
        player._handle_player_events(keys)

        screen.fill((0, 0, 0))
        player.draw(screen)
        pygame.display.flip()
        clock.tick(60)

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
