import numpy as np
import chainer
import chainer.backends.cuda as cuda
from chainerrl.models import MLPBN
from chainerrl import testing
from nose.plugins.attrib import attr


class TestMLPBN:
    @testing.product(
        in_size=[1, 5, 10],
        out_size=[1, 5, 10],
        hidden_sizes=[(), (8,), (8, 8)],
        normalize_input=[False, True],
        normalize_output=[False, True],
        nonlinearity=[None, 'relu', 'tanh'],
        last_wscale=[None, 0.5, 1.0],
    )
    def _test_call(
        self,
        in_size,
        out_size,
        hidden_sizes,
        normalize_input,
        normalize_output,
        nonlinearity,
        last_wscale,
        gpu,
    ):
        mlp = MLPBN(
            in_size=in_size,
            out_size=out_size,
            hidden_sizes=hidden_sizes,
            normalize_input=normalize_input,
            normalize_output=normalize_output,
            nonlinearity=nonlinearity,
            last_wscale=last_wscale,
        )

        batch_size = 7
        x_np = np.random.randn(batch_size, in_size).astype(np.float32)

        if gpu >= 0:
            x = cuda.to_gpu(x_np, device=gpu)
            mlp.to_gpu(gpu)
        else:
            x = chainer.Variable(x_np)
            mlp.to_cpu()

        y = mlp(x)

        assert y.shape == (batch_size, out_size)
        if gpu >= 0:
            assert cuda.get_device_from_id(gpu) == cuda.get_device_from_id(y.data.device)
        else:
            assert isinstance(y.data, np.ndarray)

    def test_call_cpu(self):
        self._test_call(gpu=-1)

    @attr.gpu
    def test_call_gpu(self):
        self._test_call(gpu=0)