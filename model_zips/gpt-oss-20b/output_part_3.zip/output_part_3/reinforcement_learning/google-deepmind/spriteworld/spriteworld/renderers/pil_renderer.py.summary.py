import numpy as np
from PIL import Image, ImageDraw, ImageOps


class Renderer:
    def __init__(
        self,
        image_size,
        anti_aliasing=1,
        background_color=(0, 0, 0),
        color_to_rgb=lambda c: c,
    ):
        self.image_size = image_size
        self.anti_aliasing = anti_aliasing
        self.background_color = background_color
        self.color_to_rgb = color_to_rgb

        self.canvas_size = (
            int(image_size[0] * anti_aliasing),
            int(image_size[1] * anti_aliasing),
        )
        self.background = Image.new("RGB", self.canvas_size, background_color)
        self.observation_spec = np.zeros(
            (image_size[1], image_size[0], 3), dtype=np.uint8
        )

    def render(self, sprites):
        canvas = self.background.copy()
        draw = ImageDraw.Draw(canvas)

        for sprite in sprites:
            vertices = np.array(sprite["vertices"], dtype=np.float32)
            scaled_vertices = (vertices * self.anti_aliasing).tolist()
            color = self.color_to_rgb(sprite["color"])
            draw.polygon(scaled_vertices, fill=color)

        image = canvas.resize(self.image_size, Image.LANCZOS)
        image = ImageOps.flip(image)

        return np.array(image)