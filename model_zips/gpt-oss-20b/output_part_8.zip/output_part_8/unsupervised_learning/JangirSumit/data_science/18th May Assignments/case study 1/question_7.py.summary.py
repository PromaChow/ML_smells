import numpy as np

# Create array with NaN values
arr = np.array([np.nan, 1.0, 2.0, np.nan, 3.0, 4.0, 5.0], dtype=float)

# Print original array
print("Original array:")
print(arr)

# Create mask for NaN positions and filter
mask = ~np.isnan(arr)
filtered_arr = arr[mask]

# Print filtered array
print("\nFiltered array (NaNs removed):")
print(filtered_arr)