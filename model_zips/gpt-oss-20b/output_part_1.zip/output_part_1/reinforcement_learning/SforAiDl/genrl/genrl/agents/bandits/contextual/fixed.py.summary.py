import torch
from typing import List, Optional


class FixedAgent:
    def __init__(
        self,
        bandit: "DataBasedBandit",
        p: Optional[List[float]] = None,
        device: str = "cpu",
    ) -> None:
        self.bandit = bandit
        n_actions = getattr(bandit, "n_actions", None)
        if n_actions is None:
            raise AttributeError("Bandit must have an 'n_actions' attribute.")

        if p is None:
            p = [1.0 / n_actions] * n_actions

        if len(p) != n_actions:
            raise ValueError(
                f"Probability list length {len(p)} does not match number of actions {n_actions}."
            )

        self.p = torch.tensor(p, dtype=torch.float32, device=device)
        self.t = 0

    def select_action(self, context: torch.Tensor) -> int:
        self.t += 1
        action = torch.multinomial(self.p, 1).item()
        return action

    def update_db(self, *args, **kwargs) -> None:
        pass

    def update_params(self, *args, **kwargs) -> None:
        pass
