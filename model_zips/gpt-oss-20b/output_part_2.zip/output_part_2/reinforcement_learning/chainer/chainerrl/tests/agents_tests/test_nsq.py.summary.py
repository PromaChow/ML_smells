import os
import tempfile
import logging
import warnings

import pytest
import chainerrl
from chainerrl import training, q_functions, optimizers, explorers
from chainerrl.agents import DQN

logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s %(levelname)s %(message)s",
)

# Create a temporary directory for the test outputs
tmp_dir = tempfile.mkdtemp()


def make_env(episodic: bool, use_lstm: bool, deterministic: bool):
    """
    Create an ABC environment with the given configuration.
    """
    return chainerrl.envs.make_abc(
        episodic=episodic,
        partially_observable=use_lstm,
        deterministic=deterministic,
    )


@pytest.fixture(scope="module")
def env_template():
    return {"episodic": True, "use_lstm": False, "deterministic": False}


def build_qfunc(env, use_lstm: bool):
    """
    Construct the Q-function used by the agent.
    """
    if use_lstm:
        return q_functions.FCLSTMStateQFunction(
            env.observation_spec,
            env.action_space.n,
            hidden_sizes=(50, 50),
            activation=chainerrl.activations.relu,
        )
    else:
        return q_functions.FCStateQFunctionWithDiscreteAction(
            env.observation_spec,
            env.action_space.n,
            hidden_sizes=(50, 50),
            activation=chainerrl.activations.relu,
        )


def build_optimizer():
    """
    Build the optimizer used by the agent.
    """
    return optimizers.RMSpropAsync(learning_rate=1e-3, epsilon=1e-2, alpha=0.99)


def explorer_factory(env, explorer_type: str):
    """
    Return an explorer instance for the given environment.
    """
    if explorer_type == "epsilon_greedy":
        epsilon = 0.1 + env.process_index * 0.01
        return explorers.ConstantEpsilonGreedy(epsilon)
    elif explorer_type == "boltzmann":
        return explorers.Boltzmann(temperature=1.0)
    else:
        raise ValueError(f"Unknown explorer type: {explorer_type}")


def train_agent(
    t_max: int,
    use_lstm: bool,
    episodic: bool,
    explorer_type: str,
    steps: int = 100_000,
    require_success: bool = True,
):
    """
    Run asynchronous training of a DQN agent on the ABC environment.
    """
    # Build the environment once to query spec
    base_env = make_env(episodic, use_lstm, deterministic=False)

    # Build Q-function and optimizer
    q_func = build_qfunc(base_env, use_lstm)
    optimizer = build_optimizer()

    # Train the agent asynchronously
    model_dir = os.path.join(tmp_dir, f"{t_max}_{use_lstm}_{episodic}_{explorer_type}")
    os.makedirs(model_dir, exist_ok=True)

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        training.train_agent_async(
            make_env,
            model_dir,
            q_func,
            optimizer,
            explorer=explorer_factory,
            nproc=8,
            steps=steps,
            max_episode_len=5,
            eval_interval=500,
            eval_n_episodes=5,
            success_score=1,
            success_interval=1,
            explorer_kwargs={"explorer_type": explorer_type},
            verbose=0,
        )
        # Ensure no AbnormalExitWarning was raised
        assert not any(
            issubclass(warn.category, chainerrl.util.AbnormalExitWarning) for warn in w
        )

    # Load the successful model if required
    if require_success:
        successful_path = os.path.join(model_dir, "successful")
        assert os.path.exists(successful_path), "Successful model not found"
        agent = DQN.load_from_folder(successful_path)
    else:
        agent = None

    return agent, model_dir


def run_deterministic_evaluation(
    agent: DQN, use_lstm: bool, episodic: bool, require_success: bool
):
    """
    Run 5 deterministic episodes and validate total reward.
    """
    env = make_env(episodic, use_lstm, deterministic=True)
    for _ in range(5):
        state = env.reset()
        total_reward = 0.0
        done = False
        while not done:
            action = agent.act(state, deterministic=True)
            state, reward, done, _ = env.step(action)
            total_reward += reward
        if require_success:
            assert total_reward == 1, f"Episode reward {total_reward} != 1"


@pytest.mark.parametrize(
    "t_max,use_lstm,episodic,explorer",
    [
        (1, True, True, "epsilon_greedy"),
        (1, True, True, "boltzmann"),
        (1, True, False, "epsilon_greedy"),
        (1, True, False, "boltzmann"),
        (1, False, True, "epsilon_greedy"),
        (1, False, True, "boltzmann"),
        (1, False, False, "epsilon_greedy"),
        (1, False, False, "boltzmann"),
        (2, True, True, "epsilon_greedy"),
        (2, True, True, "boltzmann"),
        (2, True, False, "epsilon_greedy"),
        (2, True, False, "boltzmann"),
        (2, False, True, "epsilon_greedy"),
        (2, False, True, "boltzmann"),
        (2, False, False, "epsilon_greedy"),
        (2, False, False, "boltzmann"),
        (5, True, True, "epsilon_greedy"),
        (5, True, True, "boltzmann"),
        (5, True, False, "epsilon_greedy"),
        (5, True, False, "boltzmann"),
        (5, False, True, "epsilon_greedy"),
        (5, False, True, "boltzmann"),
        (5, False, False, "epsilon_greedy"),
        (5, False, False, "boltzmann"),
    ],
)
def test_nsq_agent_async(
    t_max, use_lstm, episodic, explorer
):
    agent, _ = train_agent(
        t_max=t_max,
        use_lstm=use_lstm,
        episodic=episodic,
        explorer_type=explorer,
        steps=100_000,
        require_success=True,
    )
    run_deterministic_evaluation(agent, use_lstm, episodic, require_success=True)


def test_nsq_agent_async_fast():
    """
    A fast version of the test with fewer steps and no success requirement.
    """
    agent, _ = train_agent(
        t_max=1,
        use_lstm=True,
        episodic=True,
        explorer_type="epsilon_greedy",
        steps=10,
        require_success=False,
    )
    # Even if no success required, we still want to ensure agent can run
    env = make_env(True, True, deterministic=True)
    state = env.reset()
    done = False
    while not done:
        action = agent.act(state, deterministic=True)
        state, reward, done, _ = env.step(action)
    # No assertion on reward; just ensure no exceptions are raised
    assert True

