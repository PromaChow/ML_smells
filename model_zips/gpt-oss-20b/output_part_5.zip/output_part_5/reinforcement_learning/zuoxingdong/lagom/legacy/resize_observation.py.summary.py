import gym
import numpy as np
import cv2
from gym import spaces
from gym.core import ObservationWrapper
import pytest

class ResizeObservation(ObservationWrapper):
    def __init__(self, env: gym.Env, size: int):
        super().__init__(env)
        if not isinstance(size, int) or size <= 0:
            raise ValueError("size must be a positive integer")
        self.size = size

        orig_shape = env.observation_space.shape
        if len(orig_shape) == 2:
            channels = 1
        elif len(orig_shape) == 3:
            channels = orig_shape[2]
        else:
            raise ValueError("Unsupported observation shape")

        new_shape = (self.size, self.size, channels)
        self.observation_space = spaces.Box(
            low=0,
            high=255,
            shape=new_shape,
            dtype=np.uint8
        )

    def observation(self, observation: np.ndarray) -> np.ndarray:
        resized = cv2.resize(observation, (self.size, self.size), interpolation=cv2.INTER_AREA)
        if resized.ndim == 2:
            resized = resized[..., None]
        return resized.astype(np.uint8)

@pytest.mark.parametrize("env_name", ["Pong-v0", "SpaceInvaders-v0"])
@pytest.mark.parametrize("size", [16, 32])
def test_resize_observation(env_name: str, size: int):
    env = gym.make(env_name)
    wrapped = ResizeObservation(env, size)

    # Check observation space
    assert wrapped.observation_space.shape == (size, size, 3)

    # Reset and check observation shape
    obs = wrapped.reset()
    if isinstance(obs, tuple):
        obs = obs[0]
    assert obs.shape == (size, size, 3)
    assert obs.dtype == np.uint8
    assert obs.min() >= 0 and obs.max() <= 255
    wrapped.close()
    env.close()
