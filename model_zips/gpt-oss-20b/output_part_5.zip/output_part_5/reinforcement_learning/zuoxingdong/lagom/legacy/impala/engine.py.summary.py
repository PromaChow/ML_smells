import numpy as np
from time import perf_counter
from collections import defaultdict
from typing import Any, Dict, Iterable, List, Tuple, Union

# --------------------------------------------------------------------------- #
# Helper utilities
# --------------------------------------------------------------------------- #

def describe(values: Iterable[Union[float, int]]) -> Dict[str, float]:
    """Return basic descriptive statistics for a numeric iterable."""
    arr = np.array(list(values), dtype=float)
    if arr.size == 0:
        return {
            'min': np.nan,
            'max': np.nan,
            'mean': np.nan,
            'std': np.nan,
            'p10': np.nan,
            'p25': np.nan,
            'median': np.nan,
            'p75': np.nan,
            'p90': np.nan,
        }
    return {
        'min': float(np.min(arr)),
        'max': float(np.max(arr)),
        'mean': float(np.mean(arr)),
        'std': float(np.std(arr)),
        'p10': float(np.percentile(arr, 10)),
        'p25': float(np.percentile(arr, 25)),
        'median': float(np.median(arr)),
        'p75': float(np.percentile(arr, 75)),
        'p90': float(np.percentile(arr, 90)),
    }

class Logger:
    """Simple logger that stores metrics in a dictionary."""
    def __init__(self) -> None:
        self.data: Dict[str, Any] = defaultdict(list)

    def log(self, key: str, value: Any) -> None:
        self.data[key].append(value)

    def __repr__(self) -> str:
        return f'Logger({dict(self.data)})'

# --------------------------------------------------------------------------- #
# Agent placeholder
# --------------------------------------------------------------------------- #

class Agent:
    """Mock agent with train, learn and total_timestep attributes."""
    def __init__(self) -> None:
        self.total_timestep: int = 0

    def train(self) -> None:
        """Set agent to training mode (placeholder)."""
        pass

    def learn(self, D: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Mock learning process that updates total_timestep."""
        timesteps = sum(len(traj['numpy_rewards']) for traj in D)
        self.total_timestep += timesteps
        # Example output dictionary
        return {
            'loss': np.random.rand(),
            'entropy': np.random.rand(),
        }

# --------------------------------------------------------------------------- #
# VecMonitor placeholder
# --------------------------------------------------------------------------- #

class VecMonitor:
    """Mock VecMonitor with return and horizon queues."""
    def __init__(self) -> None:
        self.return_queue: List[float] = []
        self.horizon_queue: List[int] = []

    def record(self, ret: float, horizon: int) -> None:
        self.return_queue.append(ret)
        self.horizon_queue.append(horizon)

# --------------------------------------------------------------------------- #
# Environment placeholder
# --------------------------------------------------------------------------- #

class Env:
    """Mock environment that may contain a VecMonitor wrapper."""
    def __init__(self) -> None:
        self.vec_monitor: Union[VecMonitor, None] = None

# --------------------------------------------------------------------------- #
# Engine implementation
# --------------------------------------------------------------------------- #

class Engine:
    def __init__(self, agent: Agent, env: Env, n: int = 0) -> None:
        self.agent = agent
        self.env = env
        self.n = n  # current iteration index

    def train(self, **kwargs: Any) -> Logger:
        # 1. Set agent to training mode
        self.agent.train()

        # 2. Record the start time
        start_time = perf_counter()

        # 3. Retrieve the dataset D
        D: List[Dict[str, Any]] = kwargs['D']

        # 4. Execute the agent's learning process
        out_agent: Dict[str, Any] = self.agent.learn(D)

        # 5. Initialize a Logger instance
        logger = Logger()

        # 6. Log training iteration number
        logger.log('iteration', self.n + 1)

        # 7. Log the elapsed time
        elapsed = perf_counter() - start_time
        logger.log('elapsed_time', round(elapsed, 1))

        # 8. Log all key-value pairs from out_agent
        for k, v in out_agent.items():
            logger.log(k, v)

        # 9. Log the number of trajectories in D
        logger.log('num_trajectories', len(D))

        # 10. Log the total number of timesteps across all trajectories
        total_timesteps = sum(len(traj.get('numpy_rewards', [])) for traj in D)
        logger.log('total_timesteps', total_timesteps)

        # 11. Log the accumulated trained timesteps
        logger.log('accumulated_timesteps', self.agent.total_timestep)

        # 12. Calculate returns for each trajectory and log them
        trajectory_returns = [np.sum(traj.get('numpy_rewards', [])) for traj in D]
        logger.log('trajectory_returns', describe(trajectory_returns))

        # 13. Extract episode information
        episode_infos = []
        for traj in D:
            infos = traj.get('infos', [])
            for info in infos:
                if 'episode' in info:
                    episode_infos.append(info)

        # 14. Log online returns and horizons
        online_returns = [info['episode']['r'] for info in episode_infos if 'episode' in info]
        online_horizons = [info['episode']['l'] for info in episode_infos if 'episode' in info]
        logger.log('online_returns', describe(online_returns))
        logger.log('online_horizons', describe(online_horizons))

        # 15. Access VecMonitor wrapper
        vec_monitor = getattr(self.env, 'vec_monitor', None)
        if vec_monitor is not None:
            # 16. Log running returns and horizons from queues
            running_returns = vec_monitor.return_queue
            running_horizons = vec_monitor.horizon_queue
            logger.log('running_returns', describe(running_returns))
            logger.log('running_horizons', describe(running_horizons))

        # 17. Return the populated Logger
        return logger

    def eval(self, **kwargs: Any) -> None:
        pass

# --------------------------------------------------------------------------- #
# Example usage (commented out)
# --------------------------------------------------------------------------- #

# if __name__ == "__main__":
#     agent = Agent()
#     env = Env()
#     env.vec_monitor = VecMonitor()
#     engine = Engine(agent, env, n=0)
#     
#     # Create mock dataset
#     D = []
#     for _ in range(5):
#         rewards = np.random.randn(10).tolist()
#         infos = [{'episode': {'r': np.sum(rewards), 'l': len(rewards)}}]
#         D.append({'numpy_rewards': rewards, 'infos': infos})
#     
#     logger = engine.train(D=D)
#     print(logger)
