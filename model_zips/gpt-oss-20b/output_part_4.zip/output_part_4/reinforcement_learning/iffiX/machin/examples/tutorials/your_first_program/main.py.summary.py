import gym
import torch
import torch.nn as nn
import torch.optim as optim
import random
from collections import deque

# Configuration
env_name = "CartPole-v0"
max_episodes = 1000
max_steps_per_episode = 200
solved_reward = 190
solved_repeat = 5

obs_dim = 4
n_actions = 2
gamma = 0.99
buffer_capacity = 10000
batch_size = 32
learning_rate = 1e-3

# Q-Network definition
class QNet(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(QNet, self).__init__()
        self.fc1 = nn.Linear(input_dim, 16)
        self.fc2 = nn.Linear(16, 16)
        self.fc3 = nn.Linear(16, output_dim)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return self.fc3(x)

# DQN agent
class DQN:
    def __init__(self, q_net, q_net_t, optimizer, loss_fn):
        self.q_net = q_net
        self.q_net_t = q_net_t
        self.optimizer = optimizer
        self.loss_fn = loss_fn
        self.replay_buffer = deque(maxlen=buffer_capacity)
        self.epsilon = 1.0
        self.epsilon_decay = 0.995
        self.epsilon_min = 0.01

    def act_discrete_with_noise(self, state):
        if random.random() < self.epsilon:
            return random.randint(0, n_actions - 1)
        state_tensor = torch.tensor(state, dtype=torch.float32).unsqueeze(0)
        with torch.no_grad():
            q_values = self.q_net(state_tensor)
        return q_values.argmax().item()

    def store_transition(self, state, action, next_state, reward, done):
        self.replay_buffer.append((state, action, next_state, reward, done))

    def sample_batch(self):
        batch = random.sample(self.replay_buffer, min(batch_size, len(self.replay_buffer)))
        states, actions, next_states, rewards, dones = zip(*batch)
        return (
            torch.tensor(states, dtype=torch.float32),
            torch.tensor(actions, dtype=torch.long),
            torch.tensor(next_states, dtype=torch.float32),
            torch.tensor(rewards, dtype=torch.float32),
            torch.tensor(dones, dtype=torch.float32),
        )

    def update(self, num_updates):
        for _ in range(num_updates):
            if len(self.replay_buffer) < batch_size:
                break
            states, actions, next_states, rewards, dones = self.sample_batch()
            q_values = self.q_net(states).gather(1, actions.unsqueeze(1)).squeeze(1)
            with torch.no_grad():
                next_q_values = self.q_net_t(next_states).max(1)[0]
                target_q = rewards + gamma * next_q_values * (1 - dones)
            loss = self.loss_fn(q_values, target_q)
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()
        # Decay epsilon
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay

# Environment
env = gym.make(env_name)

# Networks and DQN
q_net = QNet(obs_dim, n_actions)
q_net_t = QNet(obs_dim, n_actions)
q_net_t.load_state_dict(q_net.state_dict())
optimizer = optim.Adam(q_net.parameters(), lr=learning_rate)
loss_fn = nn.MSELoss(reduction="sum")
dqn = DQN(q_net, q_net_t, optimizer, loss_fn)

# Training loop
smoothed_reward = 0.0
solved_count = 0

for episode in range(1, max_episodes + 1):
    state = env.reset()
    total_reward = 0.0
    done = False
    step = 0
    while not done and step < max_steps_per_episode:
        action = dqn.act_discrete_with_noise(state)
        next_state, reward, done, _ = env.step(action)
        dqn.store_transition(state, action, next_state, reward, done)
        state = next_state
        total_reward += reward
        step += 1
    dqn.update(step)
    # Update target network
    q_net_t.load_state_dict(q_net.state_dict())
    # Smooth reward
    smoothed_reward = 0.9 * smoothed_reward + 0.1 * total_reward
    print(f"Episode {episode} | Total Reward: {total_reward:.2f} | Smoothed Reward: {smoothed_reward:.2f}")
    if smoothed_reward >= solved_reward:
        solved_count += 1
        if solved_count >= solved_repeat:
            print(f"Solved in episode {episode}")
            break
    else:
        solved_count = 0

env.close()