import math
from typing import Callable

import torch
from torch.optim import Optimizer
from torch.optim.lr_scheduler import LambdaLR


def exp_warmup(base_value: float, max_warmup_iter: int, cur_step: int) -> float:
    """
    Exponential warmup schedule.

    :param base_value: Maximum learning rate value.
    :param max_warmup_iter: Number of iterations for the warmup phase.
    :param cur_step: Current iteration index.
    :return: Warmup learning rate for the current step.
    """
    if cur_step > max_warmup_iter:
        return base_value
    t = cur_step / max_warmup_iter
    return base_value * math.exp(-5 * (1 - t) ** 2)


def linear_warmup(base_value: float, max_warmup_iter: int, cur_step: int) -> float:
    """
    Linear warmup schedule.

    :param base_value: Maximum learning rate value.
    :param max_warmup_iter: Number of iterations for the warmup phase.
    :param cur_step: Current iteration index.
    :return: Warmup learning rate for the current step.
    """
    if cur_step > max_warmup_iter:
        return base_value
    t = cur_step / max_warmup_iter
    return base_value * t


def cosine_decay(base_lr: float, max_iteration: int, cur_step: int) -> float:
    """
    Cosine decay schedule.

    :param base_lr: Initial maximum learning rate.
    :param max_iteration: Total number of training iterations.
    :param cur_step: Current iteration index.
    :return: Decayed learning rate for the current step.
    """
    cosine_term = math.cos((7 * math.pi * cur_step) / (16 * max_iteration))
    return base_lr * cosine_term


class CosineAnnealingLR:
    """
    Cosine annealing learning rate scheduler for PyTorch optimizers.
    """

    def __init__(self, optimizer: Optimizer, max_iteration: int):
        """
        Initialize the scheduler.

        :param optimizer: PyTorch optimizer.
        :param max_iteration: Total number of training iterations.
        """
        lr_lambda: Callable[[int], float] = lambda cur_step: math.cos(
            (7 * math.pi * cur_step) / (16 * max_iteration)
        )
        self._scheduler = LambdaLR(optimizer, lr_lambda=lr_lambda)

    def step(self):
        """
        Update the learning rate for the next step.
        """
        self._scheduler.step()

    @property
    def lr(self) -> float:
        """
        Get the current learning rate.
        """
        return self._scheduler.get_last_lr()[0] if self._scheduler.get_last_lr() else 0.0
