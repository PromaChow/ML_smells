import os
import sys
import time

import gym
import numpy as np

# Path setup: add parent directory to Python path
parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if parent_dir not in sys.path:
    sys.path.append(parent_dir)

# ReLU activation
def relu(x: np.ndarray) -> np.ndarray:
    return np.maximum(0, x)

class SmallReactivePolicy:
    def __init__(self, obs_dim: int, act_dim: int):
        # Define network architecture
        hidden1 = 16
        hidden2 = 16

        # Hardcoded weights and biases using fixed random seeds
        rng1 = np.random.RandomState(0)
        rng2 = np.random.RandomState(1)
        rng3 = np.random.RandomState(2)
        rng4 = np.random.RandomState(3)
        rng5 = np.random.RandomState(4)

        self.weights_dense1_w = rng1.randn(hidden1, obs_dim)
        self.weights_dense1_b = rng2.randn(hidden1)
        self.weights_dense2_w = rng3.randn(hidden2, hidden1)
        self.weights_dense2_b = rng4.randn(hidden2)
        self.weights_final_w = rng5.randn(act_dim, hidden2)
        self.weights_final_b = rng1.randn(act_dim)

        # Validate shapes
        assert self.weights_dense1_w.shape == (hidden1, obs_dim)
        assert self.weights_dense1_b.shape == (hidden1,)
        assert self.weights_dense2_w.shape == (hidden2, hidden1)
        assert self.weights_dense2_b.shape == (hidden2,)
        assert self.weights_final_w.shape == (act_dim, hidden2)
        assert self.weights_final_b.shape == (act_dim,)

    def act(self, obs: np.ndarray) -> np.ndarray:
        # Forward pass through the fixed MLP
        h1 = relu(np.dot(obs, self.weights_dense1_w.T) + self.weights_dense1_b)
        h2 = relu(np.dot(h1, self.weights_dense2_w.T) + self.weights_dense2_b)
        out = np.dot(h2, self.weights_final_w.T) + self.weights_final_b
        return out

def main() -> None:
    env = gym.make("InvertedDoublePendulumPyBulletEnv-v0")
    obs_dim = env.observation_space.shape[0]
    act_dim = env.action_space.shape[0]
    policy = SmallReactivePolicy(obs_dim, act_dim)

    while True:
        obs = env.reset()
        episode_reward = 0.0
        done = False
        while not done:
            env.render()
            action = policy.act(obs)
            # Clip action to environment bounds
            action = np.clip(action, env.action_space.low, env.action_space.high)
            obs, reward, done, _ = env.step(action)
            episode_reward += reward
        print(f"Episode finished. Total reward: {episode_reward}")
        time.sleep(2)

if __name__ == "__main__":
    main()
