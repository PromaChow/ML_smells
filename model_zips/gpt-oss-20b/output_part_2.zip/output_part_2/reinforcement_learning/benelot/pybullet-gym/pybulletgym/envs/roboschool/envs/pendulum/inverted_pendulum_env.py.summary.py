import pybullet as p
import numpy as np
from gymnasium import spaces

# Placeholder imports for base classes and robot models.
# These should be replaced with actual implementations.
try:
    from base_bullet_env import BaseBulletEnv
except ImportError:
    class BaseBulletEnv:
        def __init__(self):
            self.action_space = spaces.Box(low=-1.0, high=1.0, shape=(1,), dtype=np.float32)
            self.observation_space = spaces.Box(low=-np.inf, high=np.inf, shape=(3,), dtype=np.float32)
            self.stateId = None

        def global_step(self):
            p.stepSimulation()

        def reset(self):
            raise NotImplementedError

        def step(self, action):
            raise NotImplementedError

try:
    from robot_models import InvertedPendulum, InvertedPendulumSwingup
except ImportError:
    class InvertedPendulum:
        def __init__(self):
            self.body_id = None

        def reset(self):
            pass

        def apply_action(self, action):
            pass

        def get_state(self):
            return np.array([0.0, 0.0, 0.0])

        @property
        def theta(self):
            return 0.0

    class InvertedPendulumSwingup(InvertedPendulum):
        pass


class InvertedPendulumBulletEnv(BaseBulletEnv):
    def __init__(self):
        super().__init__()
        self.robot = InvertedPendulum()
        self.create_single_player_scene()
        self.camera_adjust()

    def create_single_player_scene(self):
        p.setGravity(0, 0, -9.8)
        p.setTimeStep(0.0165)
        p.setPhysicsEngineParameter(numSolverIterations=10)
        p.setRealTimeSimulation(0)

    def reset(self):
        if self.stateId is not None:
            p.restoreState(self.stateId)
        else:
            self.robot.reset()
            self.stateId = p.saveState()
        obs = self.robot.get_state()
        return obs

    def step(self, a):
        self.robot.apply_action(a)
        self.global_step()
        theta = self.robot.theta
        reward = 1.0
        done = bool(abs(theta) > 0.2)
        info = {"theta": theta}
        obs = self.robot.get_state()
        return obs, reward, done, False, info

    def camera_adjust(self):
        p.resetDebugVisualizerCamera(
            cameraDistance=2.0,
            cameraYaw=90,
            cameraPitch=-30,
            cameraTargetPosition=[0, 0, 0.5]
        )
        p.resetDebugVisualizerCamera(
            cameraDistance=2.0,
            cameraYaw=90,
            cameraPitch=-30,
            cameraTargetPosition=[0, 0, 0.5]
        )
        p.resetDebugVisualizerCamera(
            cameraDistance=2.0,
            cameraYaw=90,
            cameraPitch=-30,
            cameraTargetPosition=[0, 0, 0.5]
        )


class InvertedPendulumSwingupBulletEnv(InvertedPendulumBulletEnv):
    def __init__(self):
        self.robot = InvertedPendulumSwingup()
        super().__init__()

    def step(self, a):
        self.robot.apply_action(a)
        self.global_step()
        theta = self.robot.theta
        reward = np.cos(theta)
        done = False
        info = {"theta": theta}
        obs = self.robot.get_state()
        return obs, reward, done, False, info
