import torch
import torch.nn as nn
import torch.nn.functional as F

class _ShakeShake(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, x1: torch.Tensor, x2: torch.Tensor) -> torch.Tensor:
        if self.training:
            mu = torch.rand(x1.shape[0], 1, 1, 1, device=x1.device)
            return mu * x1 + (1 - mu) * x2
        else:
            return 0.5 * (x1 + x2)

class _Branch(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, stride: int = 1):
        super().__init__()
        self.seq = nn.Sequential(
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=stride,
                      padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, stride=1,
                      padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.seq(x)

class _Residual(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, stride: int = 1):
        super().__init__()
        self.branch1 = _Branch(in_channels, out_channels, stride)
        self.branch2 = _Branch(in_channels, out_channels, stride)
        self.shake = _ShakeShake()
        self.use_skip = (stride != 1 or in_channels != out_channels)
        if self.use_skip:
            self.skip = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, kernel_size=1,
                          stride=stride, bias=False),
                nn.BatchNorm2d(out_channels),
            )
        else:
            self.skip = None

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = self.shake(self.branch1(x), self.branch2(x))
        if self.skip is not None:
            out = out + self.skip(x)
        else:
            out = out + x
        return out

class ShakeNet(nn.Module):
    def __init__(
        self,
        num_classes: int,
        scales: int = 4,
        repeat: int = 2,
        dropout: float = 0.5,
        use_dropout: bool = True,
    ):
        super().__init__()
        layers = []
        in_channels = 3
        out_channels = 16
        layers.append(
            nn.Sequential(
                nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=1,
                          padding=1, bias=False),
                nn.BatchNorm2d(out_channels),
                nn.ReLU(inplace=True),
            )
        )
        in_channels = out_channels
        for scale in range(scales):
            out_channels = 16 << scale
            for r in range(repeat):
                stride = 2 if scale > 0 and r == 0 else 1
                layers.append(_Residual(in_channels, out_channels, stride))
                in_channels = out_channels

        self.features = nn.Sequential(*layers)
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.dropout = nn.Dropout(dropout) if use_dropout else nn.Identity()
        self.classifier = nn.Linear(in_channels, num_classes)

        self._initialize_parameters()

    def _initialize_parameters(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.zeros_(m.bias)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.features(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.dropout(x)
        x = self.classifier(x)
        return x
