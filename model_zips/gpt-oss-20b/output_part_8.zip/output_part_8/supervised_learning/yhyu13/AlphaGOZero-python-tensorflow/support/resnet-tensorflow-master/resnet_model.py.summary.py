import tensorflow as tf
from collections import namedtuple

# Hyperparameters definition
HParams = namedtuple('HParams', [
    'batch_size',
    'num_classes',
    'learning_rate',
    'num_units',
    'use_bottleneck',
    'weight_decay',
    'optimizer_type'
])

class ResNet:
    def __init__(self, hparams, images, labels, mode):
        self.hparams = hparams
        self.images = images
        self.labels = labels
        self.mode = mode  # 'train' or 'eval'
        self.is_training = tf.convert_to_tensor(mode == 'train', dtype=tf.bool)
        self.global_step = tf.Variable(0, trainable=False, name='global_step')
        self.build_graph()

    def conv_bn_relu(self, x, filters, kernel_size, stride, name):
        conv = tf.layers.conv2d(
            inputs=x,
            filters=filters,
            kernel_size=kernel_size,
            strides=stride,
            padding='same',
            kernel_initializer=tf.initializers.he_normal(),
            name=name + '_DW'
        )
        bn = tf.layers.batch_normalization(
            conv,
            training=self.is_training,
            name=name + '_bn'
        )
        relu = tf.nn.relu(bn, name=name + '_relu')
        return relu

    def standard_unit(self, x, filters, stride, name):
        shortcut = x
        if stride != 1 or shortcut.shape[-1] != filters:
            shortcut = tf.layers.conv2d(
                inputs=shortcut,
                filters=filters,
                kernel_size=1,
                strides=stride,
                padding='same',
                kernel_initializer=tf.initializers.he_normal(),
                name=name + '_proj_DW'
            )
            shortcut = tf.layers.batch_normalization(
                shortcut,
                training=self.is_training,
                name=name + '_proj_bn'
            )
        y = self.conv_bn_relu(x, filters, 3, stride, name + '_conv1')
        y = tf.layers.conv2d(
            inputs=y,
            filters=filters,
            kernel_size=3,
            strides=1,
            padding='same',
            kernel_initializer=tf.initializers.he_normal(),
            name=name + '_conv2_DW'
        )
        y = tf.layers.batch_normalization(
            y,
            training=self.is_training,
            name=name + '_bn2'
        )
        out = tf.nn.relu(y + shortcut, name=name + '_out')
        return out

    def bottleneck_unit(self, x, filters, stride, name):
        shortcut = x
        if stride != 1 or shortcut.shape[-1] != filters * 4:
            shortcut = tf.layers.conv2d(
                inputs=shortcut,
                filters=filters * 4,
                kernel_size=1,
                strides=stride,
                padding='same',
                kernel_initializer=tf.initializers.he_normal(),
                name=name + '_proj_DW'
            )
            shortcut = tf.layers.batch_normalization(
                shortcut,
                training=self.is_training,
                name=name + '_proj_bn'
            )
        y = self.conv_bn_relu(x, filters, 1, 1, name + '_conv1')
        y = self.conv_bn_relu(y, filters, 3, stride, name + '_conv2')
        y = tf.layers.conv2d(
            inputs=y,
            filters=filters * 4,
            kernel_size=1,
            strides=1,
            padding='same',
            kernel_initializer=tf.initializers.he_normal(),
            name=name + '_conv3_DW'
        )
        y = tf.layers.batch_normalization(
            y,
            training=self.is_training,
            name=name + '_bn3'
        )
        out = tf.nn.relu(y + shortcut, name=name + '_out')
        return out

    def build_residual_blocks(self, x):
        num_units = self.hparams.num_units
        use_bottleneck = self.hparams.use_bottleneck
        filters = 16
        strides = [1, 2, 2]
        for i, stride in enumerate(strides):
            for j in range(num_units // 3):
                name = f'block{i+1}_unit{j+1}'
                if i == 0 and j == 0:
                    unit_stride = stride
                else:
                    unit_stride = stride if j == 0 else 1
                if use_bottleneck:
                    x = self.bottleneck_unit(x, filters, unit_stride, name)
                else:
                    x = self.standard_unit(x, filters, unit_stride, name)
            filters *= 2
        return x

    def build_model(self):
        # Initial conv
        net = tf.layers.conv2d(
            inputs=self.images,
            filters=16,
            kernel_size=3,
            strides=1,
            padding='same',
            kernel_initializer=tf.initializers.he_normal(),
            name='init_conv_DW'
        )
        net = tf.layers.batch_normalization(
            net,
            training=self.is_training,
            name='init_bn'
        )
        net = tf.nn.relu(net, name='init_relu')
        # Residual blocks
        net = self.build_residual_blocks(net)
        # Global average pooling
        net = tf.reduce_mean(net, axis=[1, 2], name='global_avg_pool')
        # Logits
        logits = tf.layers.dense(
            inputs=net,
            units=self.hparams.num_classes,
            kernel_initializer=tf.initializers.glorot_uniform(),
            name='logits'
        )
        self.logits = logits
        self.probabilities = tf.nn.softmax(logits, name='probabilities')
        return logits

    def compute_loss(self, logits):
        ce_loss = tf.reduce_mean(
            tf.nn.softmax_cross_entropy_with_logits_v2(
                logits=logits,
                labels=self.labels
            ),
            name='cross_entropy'
        )
        l2_loss = tf.add_n([
            tf.nn.l2_loss(v) for v in tf.trainable_variables() if 'DW' in v.name
        ]) * self.hparams.weight_decay
        total_loss = ce_loss + l2_loss
        tf.summary.scalar('cross_entropy', ce_loss)
        tf.summary.scalar('l2_loss', l2_loss)
        tf.summary.scalar('total_loss', total_loss)
        return total_loss

    def compute_accuracy(self, logits):
        predictions = tf.argmax(logits, axis=1, output_type=tf.int32)
        labels = tf.argmax(self.labels, axis=1, output_type=tf.int32)
        accuracy = tf.reduce_mean(
            tf.cast(tf.equal(predictions, labels), tf.float32),
            name='accuracy'
        )
        tf.summary.scalar('accuracy', accuracy)
        return accuracy

    def build_graph(self):
        logits = self.build_model()
        loss = self.compute_loss(logits)
        acc = self.compute_accuracy(logits)

        if self.mode == 'train':
            optimizer = (tf.train.MomentumOptimizer(self.hparams.learning_rate, 0.9)
                         if self.hparams.optimizer_type == 'Momentum'
                         else tf.train.GradientDescentOptimizer(self.hparams.learning_rate))
            grads_and_vars = optimizer.compute_gradients(loss)
            train_op = optimizer.apply_gradients(grads_and_vars, global_step=self.global_step)
            update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
            with tf.control_dependencies(update_ops):
                train_op = tf.identity(train_op, name='train_op')
            self.train_op = train_op
            self.summaries = tf.summary.merge_all()
        else:
            self.eval_ops = [acc, logits]
            self.summaries = tf.summary.merge_all()

if __name__ == '__main__':
    hparams = HParams(
        batch_size=128,
        num_classes=10,
        learning_rate=0.01,
        num_units=20,
        use_bottleneck=False,
        weight_decay=1e-4,
        optimizer_type='SGD'
    )
    images_ph = tf.placeholder(tf.float32, shape=[None, 32, 32, 3], name='images')
    labels_ph = tf.placeholder(tf.float32, shape=[None, hparams.num_classes], name='labels')
    mode = tf.placeholder(tf.string, shape=[], name='mode')
    model = ResNet(hparams, images_ph, labels_ph, mode)
    with tf.Session() as sess:
        sess.run(tf.global_variables_initializer())
        # Dummy data for demonstration
        dummy_images = tf.zeros([hparams.batch_size, 32, 32, 3]).eval()
        dummy_labels = tf.one_hot(tf.zeros([hparams.batch_size], dtype=tf.int32), hparams.num_classes).eval()
        feed_dict = {
            images_ph: dummy_images,
            labels_ph: dummy_labels,
            mode: 'train'
        }
        _, loss_val = sess.run([model.train_op, model.summaries], feed_dict=feed_dict)
        print('Training step executed.')
