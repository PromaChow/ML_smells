import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.colors as mcolors
from sklearn.base import BaseEstimator

def plot_feature_importances(clf: BaseEstimator, feature_names: list):
    """
    Plot horizontal bar chart of feature importances for a trained classifier.

    Parameters
    ----------
    clf : BaseEstimator
        Trained classifier with attribute feature_importances_.
    feature_names : list
        List of feature names.
    """
    importance = clf.feature_importances_
    indices = np.argsort(importance)[::-1]
    sorted_names = [feature_names[i] for i in indices]
    sorted_importance = importance[indices]

    plt.figure(figsize=(8, 0.4 * len(sorted_names)))
    plt.barh(sorted_names, sorted_importance, color="steelblue")
    plt.xlabel("Importance")
    plt.title("Feature Importances")
    plt.tight_layout()
    plt.show()


def plot_labelled_scatter(
    X: np.ndarray,
    y: np.ndarray,
    class_labels: list,
):
    """
    Scatter plot of two-dimensional data colored by class label.

    Parameters
    ----------
    X : ndarray of shape (n_samples, 2)
        Input feature matrix.
    y : ndarray of shape (n_samples,)
        Class labels.
    class_labels : list
        List of class names corresponding to y values.
    """
    min_x, max_x = X[:, 0].min(), X[:, 0].max()
    min_y, max_y = X[:, 1].min(), X[:, 1].max()
    padding = 1.0
    x_lim = (min_x - padding, max_x + padding)
    y_lim = (min_y - padding, max_y + padding)

    markers = ["o", "^", "*", "s", "D"]
    colors = ["#FFFF00", "#00AAFF", "#000000", "#FF00AA", "#FF5733"]

    cmap = mcolors.ListedColormap(colors[: len(class_labels)])
    bounds = np.arange(-0.5, len(class_labels) + 0.5)
    norm = mcolors.BoundaryNorm(bounds, cmap.N)

    plt.figure(figsize=(8, 6))
    scatter = plt.scatter(
        X[:, 0],
        X[:, 1],
        c=y,
        cmap=cmap,
        norm=norm,
        marker="o",
        s=60,
        edgecolor="k",
        alpha=0.8,
    )
    plt.xlim(*x_lim)
    plt.ylim(*y_lim)
    plt.xlabel("Feature 1")
    plt.ylabel("Feature 2")
    plt.title("Labelled Scatter Plot")

    patches = [
        mpatches.Patch(color=colors[i], label=class_labels[i]) for i in range(len(class_labels))
    ]
    plt.legend(handles=patches, title="Classes", loc="best")
    plt.grid(True, linestyle="--", alpha=0.5)
    plt.tight_layout()
    plt.show()


def plot_class_regions_for_classifier_subplot(
    clf: BaseEstimator,
    X: np.ndarray,
    y: np.ndarray,
    X_test: np.ndarray = None,
    y_test: np.ndarray = None,
    ax: plt.Axes = None,
    target_names: list = None,
    plot_decision_regions: bool = True,
):
    """
    Plot decision regions and data points on a given subplot axis.

    Parameters
    ----------
    clf : BaseEstimator
        Trained classifier with predict method.
    X, y : ndarray
        Training data and labels.
    X_test, y_test : ndarray, optional
        Test data and labels.
    ax : matplotlib.axes.Axes
        Axis object to plot on.
    target_names : list, optional
        Names of target classes for legend.
    plot_decision_regions : bool, default True
        Whether to plot the decision boundaries.
    """
    if ax is None:
        ax = plt.gca()

    # Define color palettes
    color_list_light = ["#FFAAAA", "#AAAAFF", "#AAFFAA", "#FFFFAA", "#FFAAFF"]
    color_list_bold = ["#FF0000", "#0000FF", "#00FF00", "#FFFF00", "#FF00FF"]

    # Mesh grid for decision boundary
    h = 0.02
    x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx, yy = np.meshgrid(
        np.arange(x_min, x_max, h), np.arange(y_min, y_max, h)
    )
    grid = np.c_[xx.ravel(), yy.ravel()]
    Z = clf.predict(grid)
    Z = Z.reshape(xx.shape)

    if plot_decision_regions:
        ax.contourf(
            xx,
            yy,
            Z,
            alpha=0.4,
            cmap=plt.get_cmap("coolwarm"),
        )

    # Plot training points
    ax.scatter(
        X[:, 0],
        X[:, 1],
        c=y,
        cmap=plt.cm.Paired,
        edgecolor="k",
        s=40,
        label="train",
    )

    # Plot test points if provided
    if X_test is not None and y_test is not None:
        ax.scatter(
            X_test[:, 0],
            X_test[:, 1],
            c=y_test,
            cmap=plt.cm.Paired,
            marker="^",
            edgecolor="k",
            s=60,
            label="test",
        )

    # Scores
    train_score = clf.score(X, y)
    title = f"Train accuracy: {train_score:.3f}"
    if X_test is not None and y_test is not None:
        test_score = clf.score(X_test, y_test)
        title += f", Test accuracy: {test_score:.3f}"
    ax.set_title(title)

    ax.set_xlim(x_min, x_max)
    ax.set_ylim(y_min, y_max)
    ax.set_xlabel("Feature 1")
    ax.set_ylabel("Feature 2")

    if target_names is not None:
        patches = [
            mpatches.Patch(color=plt.cm.Paired(i), label=target_names[i])
            for i in range(len(target_names))
        ]
        ax.legend(handles=patches, title="Classes", loc="upper right")
    else:
        ax.legend(loc="upper right")

    ax.grid(True, linestyle="--", alpha=0.5)


def plot_class_regions_for_classifier(
    clf: BaseEstimator,
    X: np.ndarray,
    y: np.ndarray,
    X_test: np.ndarray = None,
    y_test: np.ndarray = None,
    target_names: list = None,
    plot_decision_regions: bool = True,
):
    """
    Plot decision regions and data points in a new figure.

    Parameters
    ----------
    clf : BaseEstimator
        Trained classifier with predict method.
    X, y : ndarray
        Training data and labels.
    X_test, y_test : ndarray, optional
        Test data and labels.
    target_names : list, optional
        Names of target classes for legend.
    plot_decision_regions : bool, default True
        Whether to plot the decision boundaries.
    """
    fig, ax = plt.subplots(figsize=(8, 6))
    plot_class_regions_for_classifier_subplot(
        clf,
        X,
        y,
        X_test,
        y_test,
        ax,
        target_names,
        plot_decision_regions,
    )
    plt.show()
