import torch
import torch.nn.functional as F

class DataTransformer:
    def __init__(self, flip: bool = False, r_crop: bool = False, g_noise: bool = False):
        self.flip = flip
        self.r_crop = r_crop
        self.g_noise = g_noise
        print(f"DataTransformer initialized with flip={self.flip}, r_crop={self.r_crop}, g_noise={self.g_noise}")

    def __call__(self, x: torch.Tensor) -> torch.Tensor:
        if self.flip:
            if torch.rand(1).item() > 0.5:
                x = x.flip(-1)

        if self.r_crop:
            orig_h, orig_w = x.shape[-2], x.shape[-1]
            x = F.pad(x, [2, 2, 2, 2], mode="reflect")
            t = torch.randint(0, 5, (1,)).item()
            l = torch.randint(0, 5, (1,)).item()
            x = x[..., t : t + orig_h, l : l + orig_w]

        if self.g_noise:
            noise = torch.randn_like(x) * 0.15
            x = x + noise

        return x
