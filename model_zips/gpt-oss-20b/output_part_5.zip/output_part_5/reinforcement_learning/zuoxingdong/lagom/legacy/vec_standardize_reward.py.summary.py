import gymnasium
import numpy as np


class RunningMeanVar:
    """Tracks running mean and variance using Welford's algorithm."""
    def __init__(self):
        self.n = 0
        self.mean = 0.0
        self.M2 = 0.0

    def update(self, x):
        """
        Update running statistics with new samples `x`.
        `x` should be a NumPy array of arbitrary shape.
        """
        x_flat = x.ravel()
        for val in x_flat:
            self.n += 1
            delta = val - self.mean
            self.mean += delta / self.n
            delta2 = val - self.mean
            self.M2 += delta * delta2

    @property
    def var(self):
        return self.M2 / self.n if self.n > 0 else 0.0


class RewardStandardizationWrapper(gymnasium.Wrapper):
    """
    Reward standardization wrapper for vectorized environments.
    """

    def __init__(self, env, clip=10.0, gamma=0.99, constant_var=None):
        super().__init__(env)
        if gamma >= 1.0:
            raise ValueError("Discount factor gamma must be less than 1.0.")
        self.clip = float(clip)
        self.gamma = float(gamma)
        self.constant_var = float(constant_var) if constant_var is not None else None
        self.eps = 1e-8

        self.num_envs = env.num_envs
        self.all_returns = np.zeros(self.num_envs, dtype=np.float32)

        if self.constant_var is None:
            self.running_moments = RunningMeanVar()
        else:
            self.running_moments = None

    def step(self, actions):
        obs, rewards, dones, infos = self.env.step(actions)

        rewards = self.process_reward(rewards, dones)

        # Reset returns for environments that terminated
        self.all_returns[dones] = 0.0

        return obs, rewards, dones, infos

    def reset(self, **kwargs):
        self.all_returns = np.zeros(self.num_envs, dtype=np.float32)
        return self.env.reset(**kwargs)

    def process_reward(self, rewards, dones):
        rewards = np.asarray(rewards, dtype=np.float32)

        if self.constant_var is None:
            # Online mode
            self.all_returns = rewards + self.gamma * self.all_returns
            self.running_moments.update(self.all_returns)

            if self.running_moments.n >= 2:
                std = np.sqrt(self.running_moments.var + self.eps)
                standardized = rewards / std
            else:
                standardized = rewards
        else:
            # Constant variance mode
            std = np.sqrt(self.constant_var + self.eps)
            standardized = rewards / std

        standardized = np.clip(standardized, -self.clip, self.clip)
        return standardized
