import pandas as pd
import matplotlib.pyplot as plt

def main() -> None:
    # Load the dataset
    df = pd.read_csv("BigMartSalesData.csv")

    # Filter for records from the year 2011 and select relevant columns
    df_2011 = df[df["Year"] == 2011][["Country", "Amount"]]

    # Aggregate sales by country
    sales_by_country = df_2011.groupby("Country", as_index=False)["Amount"].sum()

    # Prepare data for the pie chart
    labels = sales_by_country["Country"]
    sizes = sales_by_country["Amount"]

    # Create the pie chart
    plt.figure(figsize=(8, 8))
    plt.pie(
        sizes,
        labels=labels,
        autopct="%1.1f%%",
        shadow=True,
        startangle=140,
    )
    plt.title("Sales Distribution by Country (2011)")
    plt.axis("equal")  # Equal aspect ratio ensures that pie is drawn as a circle.

    # Ensure proper spacing and display the chart
    plt.tight_layout()
    plt.show()

    # United Kingdom contributes the highest towards sales

if __name__ == "__main__":
    main()