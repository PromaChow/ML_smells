import random
import numpy as np
from kaldi import resample_waveform

class SpeedChange:
    def __init__(self, factor_range=(-0.15, 0.15), orig_freq=16000, p=0.5):
        self.factor_range = factor_range
        self.orig_freq = orig_freq
        self.p = p

    def __call__(self, wav):
        # Probability check
        if random.random() >= self.p:
            return wav

        # Ensure waveform is 1D numpy array
        wav = np.asarray(wav).reshape(-1)
        orig_len = wav.shape[0]

        # Warp factor calculation
        warp_factor = random.uniform(*self.factor_range)
        samp_warp = self.orig_freq + self.orig_freq * warp_factor
        if samp_warp <= 0:
            samp_warp = 1e-6  # avoid non-positive sample rate

        # Resample using Kaldi
        rwav = resample_waveform(wav, self.orig_freq, samp_warp)
        rwav = np.asarray(rwav).reshape(-1)
        new_len = rwav.shape[0]

        # Length adjustment
        if new_len > orig_len:
            start = (new_len - orig_len) // 2
            rwav = rwav[start:start + orig_len]
        elif new_len < orig_len:
            diff = orig_len - new_len
            pad_left = diff // 2
            pad_right = diff - pad_left
            rwav = np.pad(rwav, (pad_left, pad_right), mode='constant')

        # Final reshape to 2D (1 channel, N samples)
        rwav = rwav.reshape(1, -1)
        return rwav
