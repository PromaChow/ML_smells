import numpy as np
import matplotlib.pyplot as plt
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split

# Try to import the semi‑supervised libraries, fall back to dummy implementations
try:
    from scikitTSVM import SKTSVM
except Exception:
    class SKTSVM:
        def __init__(self, **kwargs):
            self.model = SVC(**kwargs)

        def fit(self, X, y):
            self.model.fit(X, y)

        def predict(self, X):
            return self.model.predict(X)

try:
    from cple_learning import CPLELearningModel
except Exception:
    class CPLELearningModel:
        def __init__(self, base_estimator, pessimistic=True, **kwargs):
            self.base_estimator = base_estimator
            self.pessimistic = pessimistic
            self.estimator = self.base_estimator(**kwargs)

        def fit(self, X, y):
            self.estimator.fit(X, y)

        def predict(self, X):
            return self.estimator.predict(X)

# ---------------- Data Generation ---------------- #
np.random.seed(42)
n_clusters = 6
points_per_cluster = 10
total_points = n_clusters * points_per_cluster
Xs = []
ys = []

for _ in range(n_clusters):
    mean = np.random.uniform(-2, 2, 2)
    s = np.random.uniform(0.5, 1.5)
    cov = np.diag([s, s])
    cluster_points = np.random.multivariate_normal(mean, cov, points_per_cluster)
    Xs.append(cluster_points)
    # placeholder labels (will be recomputed)
    ys.append(np.zeros(points_per_cluster, dtype=int))

Xs = np.vstack(Xs)
# ---------------- Label Creation (XOR pattern) ---------------- #
overall_mean = Xs.mean(axis=0)
ytrue = np.where(
    ((Xs[:, 0] < overall_mean[0]) & (Xs[:, 1] < overall_mean[1])) |
    ((Xs[:, 0] > overall_mean[0]) & (Xs[:, 1] > overall_mean[1])),
    1,
    0
)

# ---------------- Semi‑Supervised Setup ---------------- #
labeled_indices = []
for cls in [0, 1]:
    cls_indices = np.where(ytrue == cls)[0]
    chosen = np.random.choice(cls_indices, 2, replace=False)
    labeled_indices.extend(chosen)

ys_semi = np.full(total_points, -1, dtype=int)
ys_semi[labeled_indices] = ytrue[labeled_indices]

Xsupervised = Xs[labeled_indices]
ysupervised = ys_semi[labeled_indices]

# ---------------- Model Definitions ---------------- #
models = {}

# Purely supervised SVM
svm_supervised = SVC(kernel='rbf', probability=True)
svm_supervised.fit(Xsupervised, ysupervised)
models['Supervised SVM'] = svm_supervised

# S3VM (Gieseke et al. 2012)
s3vm = SKTSVM(kernel='rbf')
s3vm.fit(Xs, ys_semi)
models['S3VM'] = s3vm

# CPLE (pessimistic)
cple_pess = CPLELearningModel(base_estimator=SVC, pessimistic=True, kernel='rbf', probability=True)
cple_pess.fit(Xs, ys_semi)
models['CPLE Pessimistic'] = cple_pess

# CPLE (optimistic)
cple_opt = CPLELearningModel(base_estimator=SVC, pessimistic=False, kernel='rbf', probability=True)
cple_opt.fit(Xs, ys_semi)
models['CPLE Optimistic'] = cple_opt

# ---------------- Evaluation and Visualization ---------------- #
def evaluate_and_plot(model, X, y_true, title):
    y_pred = model.predict(X)
    acc = accuracy_score(y_true, y_pred)
    print(f'{title} Accuracy: {acc:.3f}')

    xx, yy = np.meshgrid(
        np.linspace(X[:, 0].min() - 1, X[:, 0].max() + 1, 200),
        np.linspace(X[:, 1].min() - 1, X[:, 1].max() + 1, 200)
    )
    grid = np.c_[xx.ravel(), yy.ravel()]
    if hasattr(model, 'predict'):
        Z = model.predict(grid).reshape(xx.shape)
    else:
        Z = np.zeros_like(xx)

    plt.figure(figsize=(6, 5))
    plt.contourf(xx, yy, Z, alpha=0.3, cmap=plt.cm.coolwarm)
    # Plot labeled points
    plt.scatter(Xsupervised[:, 0], Xsupervised[:, 1], c=ysupervised, cmap=plt.cm.coolwarm, edgecolors='k', s=80, label='Labeled')
    # Plot unlabeled points
    unlabeled_mask = ys_semi == -1
    plt.scatter(Xs[unlabeled_mask, 0], Xs[unlabeled_mask, 1], c='gray', edgecolors='k', s=30, label='Unlabeled')
    # Plot true class boundaries
    plt.scatter(Xs[ytrue == 0, 0], Xs[ytrue == 0, 1], facecolors='none', edgecolors='green', s=60, label='Class 0')
    plt.scatter(Xs[ytrue == 1, 0], Xs[ytrue == 1, 1], facecolors='none', edgecolors='red', s=60, label='Class 1')
    plt.title(title)
    plt.legend()
    plt.tight_layout()
    plt.show()

for name, model in models.items():
    evaluate_and_plot(model, Xs, ytrue, name)