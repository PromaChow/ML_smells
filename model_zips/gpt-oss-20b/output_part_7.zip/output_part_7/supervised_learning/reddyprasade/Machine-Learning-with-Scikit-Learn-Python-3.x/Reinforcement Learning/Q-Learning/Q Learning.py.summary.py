import gym
import numpy as np
import matplotlib.pyplot as plt
from collections import defaultdict
from windy_gridworld import WindyGridworldEnv, plotting

plt.style.use('ggplot')

# Environment initialization
env = WindyGridworldEnv()
num_actions = env.action_space.n

# Hyperparameters
discount_factor = 1.0
alpha = 0.6
epsilon = 0.1
num_episodes = 5

# Q-table initialization
Q = defaultdict(lambda: defaultdict(float))

def epsilon_greedy_policy(state, Q, epsilon, num_actions):
    probs = np.full(num_actions, epsilon / num_actions, dtype=float)
    state_q = Q[state]
    if state_q:
        best_action = max(state_q, key=state_q.get)
        probs[best_action] += (1.0 - epsilon)
    return probs

def select_action(state, Q, epsilon, num_actions):
    probs = epsilon_greedy_policy(state, Q, epsilon, num_actions)
    return np.random.choice(num_actions, p=probs)

# Statistics tracker
stats = plotting.EpisodeStats()

for episode in range(num_episodes):
    state = env.reset()
    done = False
    while not done:
        action = select_action(state, Q, epsilon, num_actions)
        next_state, reward, done, _ = env.step(action)
        max_next_q = 0.0
        if Q[next_state]:
            max_next_q = max(Q[next_state].values())
        td_target = reward + discount_factor * max_next_q
        td_error = td_target - Q[state][action]
        Q[state][action] += alpha * td_error
        stats.update(reward, done)
        state = next_state
    stats.end_episode()

plotting.plot_episode_stats(stats)