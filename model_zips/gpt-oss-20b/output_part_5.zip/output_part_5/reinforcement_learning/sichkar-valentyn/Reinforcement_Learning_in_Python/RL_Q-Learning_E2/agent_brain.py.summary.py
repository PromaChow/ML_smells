import random
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from env import final_states


class QLearningTable:
    def __init__(self, actions, learning_rate=0.01, reward_decay=0.9, e_greedy=0.9):
        self.actions = actions
        self.lr = learning_rate
        self.gamma = reward_decay
        self.epsilon = e_greedy
        self.q_table = pd.DataFrame(columns=self.actions, dtype=np.float64)
        self.q_table_final = pd.DataFrame(columns=self.actions, dtype=np.float64)
        self.steps = []
        self.costs = []

    def check_state_exist(self, state):
        if state not in self.q_table.index:
            self.q_table.loc[state] = [0 for _ in range(len(self.actions))]

    def choose_action(self, observation):
        self.check_state_exist(observation)
        if np.random.uniform() < self.epsilon:
            state_action = self.q_table.loc[observation]
            action = np.random.choice(state_action[state_action == np.max(state_action)].index)
        else:
            action = np.random.choice(self.actions)
        return action

    def learn(self, state, action, reward, next_state, done):
        self.check_state_exist(next_state)
        q_predict = self.q_table.loc[state, action]
        if not done:
            q_target = reward + self.gamma * self.q_table.loc[next_state].max()
        else:
            q_target = reward
        self.q_table.loc[state, action] += self.lr * (q_target - q_predict)

    def print_q_table(self):
        final_state_list = final_states()
        for state in final_state_list:
            if state in self.q_table.index:
                if state not in self.q_table_final.index:
                    self.q_table_final.loc[state] = self.q_table.loc[state]
        print("Final route Q-Table:")
        print(self.q_table_final)
        print(f"Length of final route Q-Table: {len(self.q_table_final)}")
        print("\nAll states Q-Table:")
        print(self.q_table)
        print(f"Length of all states Q-Table: {len(self.q_table)}")

    def plot_results(self):
        episodes = range(1, len(self.steps) + 1)
        fig, axs = plt.subplots(2, 1, figsize=(8, 12))
        axs[0].plot(episodes, self.steps, label='Steps per episode')
        axs[0].set_xlabel('Episode')
        axs[0].set_ylabel('Steps')
        axs[0].legend()
        axs[1].plot(episodes, self.costs, label='Cost per episode')
        axs[1].set_xlabel('Episode')
        axs[1].set_ylabel('Cost')
        axs[1].legend()
        plt.tight_layout()
        plt.show()

        plt.figure(figsize=(8, 4))
        plt.subplot(1, 2, 1)
        plt.plot(episodes, self.steps)
        plt.title('Steps per Episode')
        plt.xlabel('Episode')
        plt.ylabel('Steps')

        plt.subplot(1, 2, 2)
        plt.plot(episodes, self.costs)
        plt.title('Cost per Episode')
        plt.xlabel('Episode')
        plt.ylabel('Cost')

        plt.tight_layout()
        plt.show()
