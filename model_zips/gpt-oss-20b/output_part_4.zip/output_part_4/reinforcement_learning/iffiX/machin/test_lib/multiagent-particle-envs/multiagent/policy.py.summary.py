import numpy as np
import pyglet
from pyglet.window import key

class Policy:
    def action(self, obs):
        raise NotImplementedError("Subclasses must implement the action method.")


class InteractivePolicy(Policy):
    def __init__(self, env, agent_index=0):
        self.env = env
        self.agent_index = agent_index
        self.move = [False, False, False, False]  # left, right, up, down
        self.comm = []  # placeholder for communication vectors

        self._register_key_handlers()

    def _register_key_handlers(self):
        viewer = getattr(self.env, "viewer", None)
        if viewer is None:
            return
        if hasattr(viewer, "windows"):
            window = viewer.windows[self.agent_index]
        else:
            window = viewer
        window.push_handlers(on_key_press=self.key_press, on_key_release=self.key_release)

    def key_press(self, symbol, modifiers):
        if symbol == key.LEFT:
            self.move[0] = True
        elif symbol == key.RIGHT:
            self.move[1] = True
        elif symbol == key.UP:
            self.move[2] = True
        elif symbol == key.DOWN:
            self.move[3] = True

    def key_release(self, symbol, modifiers):
        if symbol == key.LEFT:
            self.move[0] = False
        elif symbol == key.RIGHT:
            self.move[1] = False
        elif symbol == key.UP:
            self.move[2] = False
        elif symbol == key.DOWN:
            self.move[3] = False

    def action(self, obs):
        if hasattr(self.env, "action_space"):
            action_space = self.env.action_space
            if hasattr(action_space, "n") and isinstance(action_space, type(self.env.action_space)):
                # Assume discrete action space
                mapping = {0: 1, 1: 2, 2: 4, 3: 3}
                for idx, active in enumerate(self.move):
                    if active:
                        return mapping.get(idx, 0)
                return 0
            elif hasattr(action_space, "shape") and isinstance(action_space.shape, tuple):
                # Continuous action space
                move_vec = np.zeros(action_space.shape[0])
                for idx, active in enumerate(self.move):
                    if active and idx < move_vec.size:
                        move_vec[idx] = 1.0
                comm_vec = np.zeros(len(self.comm))
                return np.concatenate([move_vec, comm_vec])
        # Default fallback
        return 0
