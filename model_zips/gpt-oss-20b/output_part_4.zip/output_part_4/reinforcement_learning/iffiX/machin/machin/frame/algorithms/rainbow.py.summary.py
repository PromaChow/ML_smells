import random
import math
import numpy as np
from collections import namedtuple, deque
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F


Transition = namedtuple('Transition',
                        ('state', 'action', 'reward', 'next_state', 'done', 'n_step_reward'))


class PrioritizedBuffer:
    def __init__(self, capacity, alpha=0.6, device='cpu'):
        self.capacity = capacity
        self.buffer = []
        self.pos = 0
        self.priorities = np.zeros((capacity,), dtype=np.float32)
        self.alpha = alpha
        self.device = device

    def push(self, *args):
        max_prio = self.priorities.max() if self.buffer else 1.0
        if len(self.buffer) < self.capacity:
            self.buffer.append(Transition(*args))
        else:
            self.buffer[self.pos] = Transition(*args)
        self.priorities[self.pos] = max_prio
        self.pos = (self.pos + 1) % self.capacity

    def sample(self, batch_size, beta=0.4):
        if len(self.buffer) == self.capacity:
            prios = self.priorities
        else:
            prios = self.priorities[:self.pos]
        probs = prios ** self.alpha
        probs /= probs.sum()

        indices = np.random.choice(len(self.buffer), batch_size, p=probs)
        samples = [self.buffer[idx] for idx in indices]

        total = len(self.buffer)
        weights = (total * probs[indices]) ** (-beta)
        weights /= weights.max()
        weights = torch.tensor(weights, dtype=torch.float32, device=self.device)

        batch = Transition(*zip(*samples))
        states = torch.stack(batch.state).to(self.device)
        actions = torch.tensor(batch.action, dtype=torch.int64, device=self.device).unsqueeze(1)
        rewards = torch.tensor(batch.reward, dtype=torch.float32, device=self.device).unsqueeze(1)
        next_states = torch.stack(batch.next_state).to(self.device)
        dones = torch.tensor(batch.done, dtype=torch.float32, device=self.device).unsqueeze(1)
        n_step_rewards = torch.tensor(batch.n_step_reward, dtype=torch.float32, device=self.device).unsqueeze(1)

        return states, actions, rewards, next_states, dones, n_step_rewards, weights, indices

    def update_priorities(self, batch_indices, batch_priorities):
        for idx, prio in zip(batch_indices, batch_priorities):
            self.priorities[idx] = prio


class RainbowDQN:
    def __init__(self,
                 qnet,
                 qnet_target,
                 optimizer,
                 value_min,
                 value_max,
                 n_atoms=51,
                 batch_size=32,
                 discount_factor=0.99,
                 epsilon=1.0,
                 epsilon_min=0.01,
                 epsilon_decay=0.995,
                 reward_future_steps=3,
                 device='cpu',
                 replay_buffer=None,
                 buffer_capacity=1000000,
                 update_rate=0.005,
                 update_steps=1000):
        self.qnet = qnet
        self.qnet_target = qnet_target
        self.optimizer = optimizer
        self.value_min = value_min
        self.value_max = value_max
        self.n_atoms = n_atoms
        self.batch_size = batch_size
        self.gamma = discount_factor
        self.epsilon = epsilon
        self.epsilon_min = epsilon_min
        self.epsilon_decay = epsilon_decay
        self.reward_future_steps = reward_future_steps
        self.update_rate = update_rate
        self.update_steps = update_steps
        self.device = device
        self.step_count = 0

        self.support = torch.linspace(value_min, value_max, n_atoms, device=self.device)
        self.delta_z = (value_max - value_min) / (n_atoms - 1)

        if replay_buffer is None:
            self.replay_buffer = PrioritizedBuffer(buffer_capacity, device=self.device)
        else:
            self.replay_buffer = replay_buffer

    def act_discrete(self, state):
        with torch.no_grad():
            state = torch.tensor(state, dtype=torch.float32, device=self.device).unsqueeze(0)
            logits = self.qnet(state)  # shape: [1, num_actions, n_atoms]
            probs = F.softmax(logits, dim=-1)
            q_values = torch.sum(probs * self.support, dim=-1)
            action = q_values.argmax().item()
        return action

    def act_discrete_with_noise(self, state):
        if random.random() < self.epsilon:
            action = random.randrange(self.qnet.num_actions)
        else:
            action = self.act_discrete(state)
        self.epsilon = max(self.epsilon_min, self.epsilon * self.epsilon_decay)
        return action

    def store_episode(self, episode):
        """
        episode: list of (state, action, reward, next_state, done)
        """
        n = len(episode)
        rewards = [t[2] for t in episode]
        for i in range(n):
            n_step_return = 0.0
            discount = 1.0
            for k in range(self.reward_future_steps):
                if i + k >= n:
                    break
                n_step_return += discount * rewards[i + k]
                discount *= self.gamma
                if episode[i + k][4]:  # done
                    break
            state, action, _, next_state, done = episode[i]
            self.replay_buffer.push(torch.tensor(state, dtype=torch.float32, device=self.device),
                                    action,
                                    rewards[i],
                                    torch.tensor(next_state, dtype=torch.float32, device=self.device),
                                    done,
                                    n_step_return)

    def update(self, beta=0.4):
        if len(self.replay_buffer.buffer) < self.batch_size:
            return
        self.step_count += 1
        states, actions, rewards, next_states, dones, n_step_rewards, weights, indices = \
            self.replay_buffer.sample(self.batch_size, beta=beta)

        logits = self.qnet(states)  # [batch, num_actions, n_atoms]
        probs = F.softmax(logits, dim=-1)  # current distribution

        # Gather the probabilities of the taken actions
        action_indices = actions.squeeze(1)
        probs_a = probs.gather(1, action_indices.unsqueeze(-1).unsqueeze(-1).expand(-1, -1, self.n_atoms)).squeeze(1)

        # Compute target distribution
        with torch.no_grad():
            next_logits = self.qnet_target(next_states)
            next_probs = F.softmax(next_logits, dim=-1)
            next_q_values = torch.sum(next_probs * self.support, dim=-1)
            next_actions = next_q_values.argmax(dim=1, keepdim=True)
            target_probs = next_probs.gather(1, next_actions.unsqueeze(-1).expand(-1, -1, self.n_atoms)).squeeze(1)

            # Bellman update
            Tz = n_step_rewards + self.gamma ** self.reward_future_steps * self.support * (1 - dones)
            Tz = Tz.clamp(min=self.value_min, max=self.value_max)
            b = (Tz - self.value_min) / self.delta_z
            l = b.floor().long()
            u = b.ceil().long()

            m = torch.zeros_like(target_probs)
            for i in range(self.n_atoms):
                l_i = l[:, i]
                u_i = u[:, i]
                l_weight = (u[:, i].float() - b[:, i])
                u_weight = (b[:, i] - l[:, i].float())

                m.view(-1, self.n_atoms).scatter_add_(1, l_i.unsqueeze(1), target_probs[:, i] * l_weight.unsqueeze(1))
                m.view(-1, self.n_atoms).scatter_add_(1, u_i.unsqueeze(1), target_probs[:, i] * u_weight.unsqueeze(1))

        log_probs = torch.log(probs_a + 1e-12)
        loss = - (m * log_probs).sum(dim=1)
        loss = (loss * weights.squeeze()).mean()

        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.qnet.parameters(), 10.0)
        self.optimizer.step()

        # Update priorities
        td_errors = (m - probs_a).abs().sum(dim=1).detach().cpu().numpy()
        new_priorities = td_errors + 1e-6
        self.replay_buffer.update_priorities(indices, new_priorities)

        # Soft update of target network
        if self.step_count % self.update_steps == 0:
            for target_param, param in zip(self.qnet_target.parameters(), self.qnet.parameters()):
                target_param.data.copy_(self.update_rate * param.data + (1 - self.update_rate) * target_param.data)

    @staticmethod
    def generate_config():
        return {
            'value_min': -1.0,
            'value_max': 1.0,
            'reward_future_steps': 3,
            'batch_size': 32,
            'discount_factor': 0.99,
            'epsilon': 1.0,
            'epsilon_min': 0.01,
            'epsilon_decay': 0.995,
            'n_atoms': 51,
            'update_rate': 0.005,
            'update_steps': 1000,
            'buffer_capacity': 1000000,
        }


# Example neural network for Rainbow DQN
class QNetwork(nn.Module):
    def __init__(self, state_dim, action_dim, n_atoms):
        super().__init__()
        self.num_actions = action_dim
        self.n_atoms = n_atoms
        self.feature = nn.Sequential(
            nn.Linear(state_dim, 128),
            nn.ReLU(),
        )
        self.dist = nn.Linear(128, action_dim * n_atoms)

    def forward(self, x):
        x = self.feature(x)
        x = self.dist(x)
        x = x.view(-1, self.num_actions, self.n_atoms)
        return x
