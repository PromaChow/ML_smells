import multiprocessing
import time
import random
import torch

class DistributedBuffer:
    def __init__(self, rank, world_size, manager):
        self.rank = rank
        self.world_size = world_size
        if 'buffers' not in manager.dict():
            manager.dict()['buffers'] = manager.dict()
            for r in range(world_size):
                manager.dict()['buffers'][r] = manager.list()
        self.buffers = manager.dict()['buffers']

    def store_episode(self, episode):
        self.buffers[self.rank].append(episode)

    def sample_batch(self, n):
        all_episodes = []
        for r in range(self.world_size):
            all_episodes.extend(self.buffers[r])
        if not all_episodes:
            return []
        sample_size = min(n, len(all_episodes))
        return random.sample(all_episodes, sample_size)

    def size(self):
        return len(self.buffers[self.rank])

    def all_size(self):
        return sum(len(self.buffers[r]) for r in range(self.world_size))

    def clear(self):
        self.buffers[self.rank].clear()

    def all_clear(self):
        for r in range(self.world_size):
            self.buffers[r].clear()

def episode_generator():
    episode = []
    for _ in range(5):
        step = {
            'state': torch.zeros(3),
            'action': torch.zeros(1),
            'reward': torch.tensor(1.5),
            'terminal': True
        }
        episode.append(step)
    return episode

def test_store_and_sample(rank, world_size, manager, result_queue):
    buffer = DistributedBuffer(rank, world_size, manager)
    if rank in (0, 1):
        ep = episode_generator()
        buffer.store_episode(ep)
    if rank == 2:
        time.sleep(2)
        batch = buffer.sample_batch(7)
        try:
            assert len(batch) > 0
            for ep in batch:
                assert len(ep) == 5
                for step in ep:
                    assert torch.equal(step['state'], torch.zeros(3))
                    assert torch.equal(step['reward'], torch.tensor(1.5))
                    assert step['terminal'] is True
        except AssertionError:
            result_queue.put(False)
            return
    result_queue.put(True)

def test_size_and_all_size(rank, world_size, manager, result_queue):
    buffer = DistributedBuffer(rank, world_size, manager)
    if rank == 0:
        ep = episode_generator()
        buffer.store_episode(ep)
        try:
            assert buffer.size() == 5
        except AssertionError:
            result_queue.put(False)
            return
    time.sleep(5)
    if rank == 2:
        try:
            assert buffer.size() == 0
            assert buffer.all_size() == 5
        except AssertionError:
            result_queue.put(False)
            return
    result_queue.put(True)

def test_clear_and_all_clear(rank, world_size, manager, result_queue):
    buffer = DistributedBuffer(rank, world_size, manager)
    if rank in (0, 1):
        ep = episode_generator()
        buffer.store_episode(ep)
    if rank == 0:
        buffer.clear()
        try:
            assert buffer.size() == 0
        except AssertionError:
            result_queue.put(False)
            return
    time.sleep(5)
    if rank == 2:
        try:
            assert buffer.all_size() == 5
            buffer.all_clear()
            assert buffer.all_size() == 0
        except AssertionError:
            result_queue.put(False)
            return
    result_queue.put(True)

def run_test(test_func):
    world_size = 3
    manager = multiprocessing.Manager()
    result_queue = manager.Queue()
    processes = []
    for rank in range(world_size):
        p = multiprocessing.Process(target=test_func, args=(rank, world_size, manager, result_queue))
        p.start()
        processes.append(p)
    for p in processes:
        p.join()
    results = [result_queue.get() for _ in range(world_size)]
    return all(results)

if __name__ == '__main__':
    assert run_test(test_store_and_sample)
    assert run_test(test_size_and_all_size)
    assert run_test(test_clear_and_all_clear)
    print("All tests passed.")