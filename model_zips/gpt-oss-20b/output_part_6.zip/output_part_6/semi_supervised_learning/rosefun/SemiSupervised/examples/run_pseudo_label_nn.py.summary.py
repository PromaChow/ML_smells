import numpy as np
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import accuracy_score
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, BatchNormalization, Dropout
from semisupervised.PseudoLabelSSL import PseudoLabelNeuralNetworkClassifier

class DNN:
    def __init__(self, input_dim: int = 30, output_dim: int = 2, hidden_dim_list=None):
        if hidden_dim_list is None:
            hidden_dim_list = [128, 50]
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.hidden_dim_list = hidden_dim_list

    def build_model(self):
        model = Sequential()
        model.add(Dense(self.hidden_dim_list[0], input_dim=self.input_dim, activation='relu'))
        model.add(BatchNormalization())
        model.add(Dropout(0.5))
        for hidden_dim in self.hidden_dim_list[1:]:
            model.add(Dense(hidden_dim, activation='relu'))
            model.add(BatchNormalization())
            model.add(Dropout(0.5))
        model.add(Dense(self.output_dim, activation='softmax'))
        model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
        return model

# 1. Data Preparation
data = load_breast_cancer()
X, y = data.data, data.target

scaler = MinMaxScaler()
X_scaled = scaler.fit_transform(X)

X_train_full, X_test, y_train_full, y_test = train_test_split(
    X_scaled, y, test_size=0.1, random_state=0, stratify=y
)

# Introduce unlabeled data (label = -1) in 10% of training set
rng = np.random.RandomState(42)
mask = rng.choice([True, False], size=y_train_full.shape[0], p=[0.1, 0.9])
y_train = y_train_full.copy()
y_train[mask] = -1

# Separate labeled and unlabeled data
label_mask = y_train != -1
unlabel_mask = y_train == -1

label_X_train = X_train_full[label_mask]
label_y_train = y_train[label_mask]

unlabel_X_train = X_train_full[unlabel_mask]
unlabel_y_train = y_train[unlabel_mask]  # all -1

# 2. Model Definition
dnn_builder = lambda: DNN().build_model()

# 3. Semi-Supervised Training Setup
clf = PseudoLabelNeuralNetworkClassifier(
    model_builder=dnn_builder,
    pretrain_epochs=40,
    finetune_epochs=40,
    batch_size=128
)

# 4. Training Execution
X_combined = np.vstack((label_X_train, unlabel_X_train))
y_combined = np.concatenate((label_y_train, unlabel_y_train))

clf.fit(
    X_combined,
    y_combined,
    validation_data=(label_X_train, label_y_train)
)

# 5. Evaluation
y_pred = clf.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print(f"Test Accuracy: {accuracy:.4f}")