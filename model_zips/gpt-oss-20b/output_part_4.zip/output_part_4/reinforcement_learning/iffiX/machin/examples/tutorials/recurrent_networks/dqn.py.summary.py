import gym
import torch
import torch.nn as nn
import torch.optim as optim
import logging
from collections import deque

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


def disable_view_window():
    pass  # Stub to match specification; no rendering windows will appear


class History:
    def __init__(self, depth):
        self.depth = depth
        self.buffer = deque(maxlen=depth)

    def append(self, state):
        self.buffer.append(torch.tensor(state, dtype=torch.float32))

    def get(self):
        if len(self.buffer) < self.depth:
            # Pad with zeros if not enough history
            pad = [torch.zeros_like(self.buffer[0]) for _ in range(self.depth - len(self.buffer))]
            data = pad + list(self.buffer)
        else:
            data = list(self.buffer)
        return torch.cat(data, dim=0).unsqueeze(0).to(device)


class QNet(nn.Module):
    def __init__(self, history_depth, action_num):
        super().__init__()
        input_size = 128 * history_depth
        self.fc1 = nn.Linear(input_size, 256)
        self.fc2 = nn.Linear(256, 256)
        self.fc3 = nn.Linear(256, action_num)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return self.fc3(x)


# Dummy PER and History classes to satisfy imports
# In a real implementation, replace with actual DQNPer and History from the library
class DQNPer:
    def __init__(self, q_net, q_net_t, optimizer, loss_fn):
        self.q_net = q_net
        self.q_net_t = q_net_t
        self.optimizer = optimizer
        self.loss_fn = loss_fn
        self.memory = []

    def act_discrete_with_noise(self, history):
        with torch.no_grad():
            q_values = self.q_net(history.get())
        action = q_values.argmax().item()
        return action

    def store_transition(self, state, action, next_state, reward, terminal):
        self.memory.append((state, action, next_state, reward, terminal))

    def update(self):
        if not self.memory:
            return
        batch = self.memory[-32:]  # Simple recent replay
        states, actions, next_states, rewards, terminals = zip(*batch)
        states = torch.cat(states)
        actions = torch.tensor(actions, dtype=torch.long, device=device)
        next_states = torch.cat(next_states)
        rewards = torch.tensor(rewards, dtype=torch.float32, device=device)
        terminals = torch.tensor(terminals, dtype=torch.float32, device=device)

        q_values = self.q_net(states).gather(1, actions.unsqueeze(1)).squeeze(1)
        with torch.no_grad():
            next_q_values = self.q_net_t(next_states).max(1)[0]
        target = rewards + (1 - terminals) * 0.99 * next_q_values
        loss = self.loss_fn(q_values, target)

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()


# Environment setup
env = gym.make("Frostbite-ram-v0")
action_num = env.action_space.n
max_episodes = 20000
history_depth = 4

disable_view_window()

q_net = QNet(history_depth, action_num).to(device)
q_net_t = QNet(history_depth, action_num).to(device)

optimizer = optim.Adam(list(q_net.parameters()) + list(q_net_t.parameters()), lr=5e-4)
loss_fn = nn.MSELoss(reduction="sum")
dqn = DQNPer(q_net, q_net_t, optimizer, loss_fn)

smoothed_reward = 0.0

for episode in range(max_episodes):
    state = env.reset()
    hist = History(history_depth)
    hist.append(state)

    total_reward = 0.0
    step = 0
    done = False

    while not done:
        action = dqn.act_discrete_with_noise(hist)
        next_state, reward, done, _ = env.step(action)
        hist.append(next_state)

        # Use current history as state and next history as next state
        state_tensor = hist.get()  # after appending next_state
        next_state_tensor = hist.get()  # same as current because history already updated

        dqn.store_transition(state_tensor, action, next_state_tensor, reward, done)
        total_reward += reward
        step += 1

    if episode > 20:
        updates = step // 10
        for _ in range(updates):
            dqn.update()

    if episode == 0:
        smoothed_reward = total_reward
    else:
        smoothed_reward = smoothed_reward * 0.9 + total_reward * 0.1

    logger.info(f"Episode {episode+1} Reward: {total_reward:.2f} Smoothed: {smoothed_reward:.2f}")
    if episode % 100 == 0:
        torch.save(q_net.state_dict(), f"q_net_episode_{episode}.pth")
        torch.save(q_net_t.state_dict(), f"q_net_t_episode_{episode}.pth")
        logger.info("Models saved.")
