import argparse
import logging
import os
import random
import time
from collections import deque
from dataclasses import dataclass
from multiprocessing import Process, Queue, current_process, set_start_method
from typing import Any, Dict, List, Tuple

import gym
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim

# Ensure reproducibility across processes
def set_random_seed(seed: int, device: int = 0) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)

# Simple observation scaling wrapper
class ScaleReward(gym.RewardWrapper):
    def __init__(self, env: gym.Env, factor: float = 1e-2):
        super().__init__(env)
        self.factor = factor

    def reward(self, reward: float) -> float:
        return reward * self.factor

# Environment factory
def make_env(env_name: str, seed: int, monitor: bool = False, render: bool = False) -> gym.Env:
    env = gym.make(env_name)
    env.seed(seed)
    env.action_space.seed(seed)
    env.observation_space.seed(seed)
    env = ScaleReward(env)
    if monitor:
        env = gym.wrappers.Monitor(env, f"monitor_{seed}", video_callable=False, force=True)
    if render and current_process().name == "MainProcess":
        env = gym.wrappers.RenderVideo(env, f"render_{seed}", frames_per_second=30)
    return env

# Simple MLP network
def mlp(obs_dim: int, action_dim: int, hidden_channels: int, hidden_layers: int) -> nn.Module:
    layers = []
    in_dim = obs_dim
    for _ in range(hidden_layers):
        layers.append(nn.Linear(in_dim, hidden_channels))
        layers.append(nn.ReLU())
        in_dim = hidden_channels
    layers.append(nn.Linear(in_dim, action_dim))
    return nn.Sequential(*layers)

# Policy for continuous actions
class GaussianPolicy(nn.Module):
    def __init__(self, obs_dim: int, action_dim: int, hidden_channels: int, hidden_layers: int, action_low: float, action_high: float):
        super().__init__()
        self.net = mlp(obs_dim, action_dim * 2, hidden_channels, hidden_layers)
        self.action_low = torch.tensor(action_low)
        self.action_high = torch.tensor(action_high)

    def forward(self, x: torch.Tensor) -> Tuple[torch.distributions.Distribution, torch.Tensor]:
        out = self.net(x)
        mu, log_std = torch.chunk(out, 2, dim=-1)
        std = torch.exp(log_std)
        dist = torch.distributions.Normal(mu, std)
        return dist, mu

    def sample(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        dist, mu = self.forward(x)
        action = dist.sample()
        action = torch.tanh(action)  # enforce bounds [-1,1]
        scaled_action = self.action_low + (action + 1.0) * 0.5 * (self.action_high - self.action_low)
        logp = dist.log_prob(action).sum(-1)
        return scaled_action, logp

# Policy for discrete actions
class SoftmaxPolicy(nn.Module):
    def __init__(self, obs_dim: int, action_dim: int, hidden_channels: int, hidden_layers: int):
        super().__init__()
        self.net = mlp(obs_dim, action_dim, hidden_channels, hidden_layers)

    def forward(self, x: torch.Tensor) -> torch.distributions.Distribution:
        logits = self.net(x)
        dist = torch.distributions.Categorical(logits=logits)
        return dist

    def sample(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        dist = self.forward(x)
        action = dist.sample()
        logp = dist.log_prob(action)
        return action.unsqueeze(-1), logp.unsqueeze(-1)

# Value function network
class ValueFunction(nn.Module):
    def __init__(self, obs_dim: int, hidden_channels: int, hidden_layers: int):
        super().__init__()
        self.net = mlp(obs_dim, 1, hidden_channels, hidden_layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x).squeeze(-1)

# Simple replay buffer for episodes
@dataclass
class Transition:
    obs: np.ndarray
    action: np.ndarray
    reward: float
    next_obs: np.ndarray
    done: bool
    logp: float

class EpisodicReplayBuffer:
    def __init__(self, capacity: int):
        self.capacity = capacity
        self.buffer: deque = deque(maxlen=capacity)

    def add_episode(self, episode: List[Transition]) -> None:
        self.buffer.append(episode)

    def sample(self, batch_size: int) -> List[Transition]:
        return random.sample(self.buffer, batch_size)

    def __len__(self) -> int:
        return len(self.buffer)

# Simple agent encapsulating policy, value, optimizer, buffer
class PCLAgent:
    def __init__(self,
                 env: gym.Env,
                 hidden_channels: int = 100,
                 hidden_layers: int = 2,
                 lr: float = 7e-4,
                 gamma: float = 0.99,
                 tau: float = 1e-2,
                 rollout_len: int = 10,
                 n_times_replay: int = 1,
                 device: str = "cpu",
                 prioritized: bool = False):
        self.env = env
        self.device = device
        self.gamma = gamma
        self.tau = tau
        self.rollout_len = rollout_len
        self.n_times_replay = n_times_replay

        obs_dim = env.observation_space.shape[0]
        if isinstance(env.action_space, gym.spaces.Discrete):
            action_dim = env.action_space.n
            self.policy = SoftmaxPolicy(obs_dim, action_dim, hidden_channels, hidden_layers).to(device)
        else:
            low = env.action_space.low
            high = env.action_space.high
            action_dim = env.action_space.shape[0]
            self.policy = GaussianPolicy(obs_dim, action_dim, hidden_channels, hidden_layers, low, high).to(device)

        self.value = ValueFunction(obs_dim, hidden_channels, hidden_layers).to(device)

        self.optimizer = optim.Adam(
            list(self.policy.parameters()) + list(self.value.parameters()), lr=lr
        )
        self.buffer = EpisodicReplayBuffer(capacity=5000)

    def select_action(self, obs: np.ndarray) -> Tuple[np.ndarray, float]:
        obs_tensor = torch.tensor(obs, dtype=torch.float32).to(self.device)
        if isinstance(self.policy, GaussianPolicy):
            action, logp = self.policy.sample(obs_tensor)
            return action.cpu().detach().numpy(), logp.item()
        else:
            action, logp = self.policy.sample(obs_tensor)
            return action.cpu().detach().numpy(), logp.item()

    def rollout(self, max_steps: int = 1000) -> List[Transition]:
        episode = []
        obs = self.env.reset()
        for _ in range(max_steps):
            action, logp = self.select_action(obs)
            next_obs, reward, done, _ = self.env.step(action)
            transition = Transition(
                obs=np.array(obs, dtype=np.float32),
                action=np.array(action, dtype=np.float32),
                reward=reward,
                next_obs=np.array(next_obs, dtype=np.float32),
                done=done,
                logp=logp,
            )
            episode.append(transition)
            obs = next_obs
            if done:
                break
        return episode

    def compute_returns(self, episode: List[Transition]) -> List[float]:
        returns = []
        G = 0.0
        for transition in reversed(episode):
            G = transition.reward + self.gamma * G
            returns.insert(0, G)
        return returns

    def update(self, batch: List[Transition]) -> None:
        self.optimizer.zero_grad()
        obs_batch = torch.tensor([t.obs for t in batch], dtype=torch.float32).to(self.device)
        action_batch = torch.tensor([t.action for t in batch], dtype=torch.float32).to(self.device)
        reward_batch = torch.tensor([t.reward for t in batch], dtype=torch.float32).to(self.device)
        next_obs_batch = torch.tensor([t.next_obs for t in batch], dtype=torch.float32).to(self.device)
        done_batch = torch.tensor([t.done for t in batch], dtype=torch.float32).to(self.device)
        logp_batch = torch.tensor([t.logp for t in batch], dtype=torch.float32).to(self.device)

        # Compute targets
        with torch.no_grad():
            next_vals = self.value(next_obs_batch)
            targets = reward_batch + self.gamma * next_vals * (1 - done_batch)

        # Critic loss
        values = self.value(obs_batch)
        critic_loss = nn.functional.mse_loss(values, targets)

        # Actor loss (policy gradient)
        if isinstance(self.policy, GaussianPolicy):
            dist, _ = self.policy.forward(obs_batch)
            logp = dist.log_prob(action_batch).sum(-1)
        else:
            dist = self.policy.forward(obs_batch)
            logp = dist.log_prob(action_batch.squeeze(-1))
        actor_loss = -(logp * (targets - values).detach()).mean()

        loss = actor_loss + critic_loss
        loss.backward()
        self.optimizer.step()

    def train(self, steps: int, eval_interval: int = 100000, eval_env: gym.Env = None, eval_episodes: int = 10) -> None:
        step = 0
        while step < steps:
            episode = self.rollout()
            self.buffer.add_episode(episode)
            if len(self.buffer) >= self.rollout_len:
                for _ in range(self.n_times_replay):
                    batch = self.buffer.sample(self.rollout_len)
                    self.update(batch)
            step += len(episode)
            if step % eval_interval == 0 and eval_env is not None:
                returns = self.evaluate(eval_env, eval_episodes)
                logging.info(f"Eval at step {step}: mean={np.mean(returns):.2f}, std={np.std(returns):.2f}")

    def evaluate(self, env: gym.Env, n_episodes: int = 10) -> List[float]:
        returns = []
        for _ in range(n_episodes):
            episode = []
            obs = env.reset()
            total = 0.0
            for _ in range(1000):
                action, _ = self.select_action(obs)
                obs, reward, done, _ = env.step(action)
                total += reward
                if done:
                    break
            returns.append(total)
        return returns

# Async worker
def worker_loop(env_name: str, seed: int, queue: Queue, steps: int, device: str) -> None:
    set_random_seed(seed)
    env = make_env(env_name, seed, monitor=False, render=False)
    agent = PCLAgent(env, device=device)
    agent.train(steps=steps)

def train_agent_async(env_name: str, seed: int, processes: int, steps: int, outdir: str) -> None:
    os.makedirs(outdir, exist_ok=True)
    queue = Queue()
    workers = []
    for i in range(processes):
        p = Process(target=worker_loop, args=(env_name, seed + i, queue, steps // processes, "cpu"))
        p.start()
        workers.append(p)
    for p in workers:
        p.join()

def train_agent_with_evaluation(env_name: str,
                                seed: int,
                                outdir: str,
                                steps: int,
                                eval_interval: int,
                                eval_n_runs: int) -> None:
    os.makedirs(outdir, exist_ok=True)
    set_random_seed(seed)
    env_train = make_env(env_name, seed, monitor=False, render=False)
    env_eval = make_env(env_name, seed + 1000, monitor=False, render=False)
    agent = PCLAgent(env_train, device="cpu")
    agent.train(steps=steps,
                eval_interval=eval_interval,
                eval_env=env_eval,
                eval_episodes=eval_n_runs)

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--env", default="CartPole-v0")
    parser.add_argument("--processes", type=int, default=8)
    parser.add_argument("--gpu", type=int, default=0)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--outdir", default="results")
    parser.add_argument("--batchsize", type=int, default=10)
    parser.add_argument("--rollout-len", type=int, default=10)
    parser.add_argument("--hidden-channels", type=int, default=100)
    parser.add_argument("--hidden-layers", type=int, default=2)
    parser.add_argument("--buffer-capacity", type=int, default=5000)
    parser.add_argument("--replay-start-size", type=int, default=10000)
    parser.add_argument("--lr", type=float, default=7e-4)
    parser.add_argument("--train-async", action="store_true")
    parser.add_argument("--prioritized-replay", action="store_true")
    parser.add_argument("--demo", action="store_true")
    parser.add_argument("--eval-n-runs", type=int, default=10)
    parser.add_argument("--steps", type=int, default=int(8e7))
    parser.add_argument("--eval-interval", type=int, default=int(1e5))
    parser.add_argument("--monitor", action="store_true")
    parser.add_argument("--render", action="store_true")
    args = parser.parse_args()

    logging.basicConfig(level=logging.DEBUG, format="%(asctime)s %(levelname)s %(message)s")
    set_random_seed(args.seed, device=args.gpu)

    if args.demo:
        set_random_seed(args.seed + 9999)
        env = make_env(args.env, args.seed + 9999, monitor=args.monitor, render=args.render)
        agent = PCLAgent(env, device=f"cuda:{args.gpu}" if torch.cuda.is_available() else "cpu")
        returns = agent.evaluate(env, n_episodes=args.eval_n_runs)
        print(f"Demo returns: mean={np.mean(returns):.2f}, median={np.median(returns):.2f}, std={np.std(returns):.2f}")
        return

    if args.train_async:
        train_agent_async(args.env, args.seed, args.processes, args.steps, args.outdir)
    else:
        train_agent_with_evaluation(args.env,
                                    args.seed,
                                    args.outdir,
                                    args.steps,
                                    args.eval_interval,
                                    args.eval_n_runs)

if __name__ == "__main__":
    try:
        set_start_method("spawn")
    except RuntimeError:
        pass
    main()
