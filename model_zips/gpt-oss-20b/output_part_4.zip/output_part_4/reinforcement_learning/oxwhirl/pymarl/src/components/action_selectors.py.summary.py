import torch
from torch.distributions import Categorical

class DecayThenFlatSchedule:
    """Linear decay schedule followed by a flat value."""
    def __init__(self, start: float, finish: float, anneal_time: int):
        self.start = start
        self.finish = finish
        self.anneal_time = max(1, anneal_time)

    def __call__(self, t: int) -> float:
        if t >= self.anneal_time:
            return self.finish
        return self.start + (self.finish - self.start) * t / self.anneal_time

REGISTRY = {}

class MultinomialActionSelector:
    """
    Action selector that samples from a multinomial distribution over policy logits.
    """
    def __init__(self, args):
        self.schedule = DecayThenFlatSchedule(
            epsilon_start=args.epsilon_start,
            epsilon_finish=args.epsilon_finish,
            anneal_time=args.epsilon_anneal_time
        )
        self.test_greedy = getattr(args, "test_greedy", False)

    def __call__(self, agent_inputs: torch.Tensor, avail_actions: torch.Tensor,
                 t_env: int, test_mode: bool) -> torch.Tensor:
        # Clone and mask unavailable actions
        policies = agent_inputs.clone()
        policies[avail_actions == 0] = 0.0

        epsilon = self.schedule(t_env)

        if test_mode and self.test_greedy:
            # Greedy action selection
            actions = torch.argmax(policies, dim=-1)
        else:
            # Sample from categorical distribution
            cat = Categorical(logits=policies)
            actions = cat.sample()
        return actions

class EpsilonGreedyActionSelector:
    """
    Action selector that uses epsilon-greedy policy over Q-values.
    """
    def __init__(self, args):
        self.schedule = DecayThenFlatSchedule(
            epsilon_start=args.epsilon_start,
            epsilon_finish=args.epsilon_finish,
            anneal_time=args.epsilon_anneal_time
        )

    def __call__(self, agent_inputs: torch.Tensor, avail_actions: torch.Tensor,
                 t_env: int, test_mode: bool) -> torch.Tensor:
        # Compute epsilon
        epsilon = self.schedule(t_env)
        if test_mode:
            epsilon = 0.0

        q_values = agent_inputs.clone()
        q_values[avail_actions == 0] = -float("inf")

        batch_size = q_values.size(0)
        device = q_values.device

        # Random mask for exploration
        rand_vals = torch.rand(batch_size, device=device)
        explore_mask = rand_vals < epsilon

        # Greedy actions
        greedy_actions = torch.argmax(q_values, dim=-1)

        # Random actions uniformly over available actions
        # Convert avail_actions to probability distribution
        probs = avail_actions.float()
        # Avoid zero division: if an agent has no available actions, default to zero action
        zero_prob = probs.sum(dim=1, keepdim=True) == 0
        probs[zero_prob] = 1.0
        probs = probs / probs.sum(dim=1, keepdim=True)
        cat = Categorical(probs=probs)
        random_actions = cat.sample()

        # Combine actions
        actions = torch.where(explore_mask, random_actions, greedy_actions)
        return actions

# Register strategies
REGISTRY["multinomial"] = MultinomialActionSelector
REGISTRY["epsilon_greedy"] = EpsilonGreedyActionSelector
