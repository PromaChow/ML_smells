import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

try:
    from qn_s3vm import QN_S3VM
except ImportError:
    raise ImportError("QN_S3VM library is required but not installed.")


class S3VM:
    def __init__(self, kernel='RBF', C=1.0, gamma=0.1, lamU=1.0, probability=False):
        self.kernel = kernel
        self.C = C
        self.gamma = gamma
        self.lamU = lamU
        self.probability = probability
        self.model = None
        self.lr = None

    def fit(self, X, y):
        X = np.asarray(X)
        y = np.asarray(y)

        labeled_mask = y != -1
        unlabeled_mask = y == -1

        if not np.any(unlabeled_mask):
            raise ValueError("No unlabeled samples provided for training.")

        labeledX = X[labeled_mask]
        labeledy = y[labeled_mask]
        unlabeledX = X[unlabeled_mask]

        # Convert 0 to -1, keep 1 as 1
        labeledy_converted = np.where(labeledy == 0, -1, 1)

        # Initialize and train the QN_S3VM model
        self.model = QN_S3VM(
            labeledX,
            labeledy_converted,
            unlabeledX,
            C=self.C,
            lamU=self.lamU,
            gamma=self.gamma,
            kernel=self.kernel
        )
        self.model.train()

        # Probability estimation via Platt scaling
        if self.probability:
            preds = self.model.predict(labeledX).reshape(-1, 1)
            self.lr = LogisticRegression()
            self.lr.fit(preds, labeledy)

    def predict(self, X):
        X = np.asarray(X)
        preds = self.model.predict(X)
        return np.where(preds == -1, 0, 1)

    def predict_proba(self, X):
        if not self.probability or self.lr is None:
            raise RuntimeError("Probability estimation not enabled or model not fitted.")
        X = np.asarray(X)
        preds = self.model.predict(X).reshape(-1, 1)
        return self.lr.predict_proba(preds)

    def score(self, X, y_true):
        y_pred = self.predict(X)
        return accuracy_score(y_true, y_pred)


if __name__ == "__main__":
    # Sample dataset with labeled (0, 1) and unlabeled (-1) instances
    X = np.array([
        [0.0, 0.0],
        [1.0, 1.0],
        [0.5, 0.5],
        [2.0, 2.0],
        [3.0, 3.0],
        [4.0, 4.0]
    ])
    y = np.array([0, 1, -1, -1, 0, 1])

    clf = S3VM(probability=True)
    clf.fit(X, y)

    print("Predicted labels:", clf.predict(X))
    print("Predicted probabilities:\n", clf.predict_proba(X))
    print("Accuracy on labeled data:", clf.score(X[y != -1], y[y != -1]))