import pandas as pd
import numpy as np


class DataProcessing:
    def __init__(self):
        pass

    def make_features(
        self,
        csv_path: str,
        window: int,
        verbose: bool = True,
        save_csv: bool = False,
    ) -> pd.DataFrame:
        df = pd.read_csv(csv_path, index_col=0)
        base_columns = [col for col in df.columns if col.lower() != "volume"]
        for col in base_columns:
            log_ret_col = f"{col}_log_ret"
            df[log_ret_col] = np.log(df[col]) - np.log(df[col].shift(1))
            for lag in range(1, window, 2):
                shift_col = f"{col}_log_ret_lag_{lag}"
                df[shift_col] = np.log(df[col].shift(lag)) - np.log(df[col].shift(lag + 1))
                if lag >= 2:
                    ma_col = f"{col}_ma_lag_{lag}"
                    df[ma_col] = df[shift_col].rolling(window=lag, min_periods=1).mean()
                    ewm_col = f"{col}_ewm_lag_{lag}"
                    df[ewm_col] = df[shift_col].ewm(span=lag, adjust=False).mean()
            if window > 10:
                for lag in range(10, window, 5):
                    vol_col = f"{col}_vol_lag_{lag}"
                    df[vol_col] = df[shift_col].rolling(window=lag, min_periods=1).std()
                    ewm_vol_col = f"{col}_ewm_vol_lag_{lag}"
                    df[ewm_vol_col] = df[shift_col].ewm(span=lag, adjust=False).std()
        if "close" in df.columns and "volume" in df.columns:
            liquidity = df["close"] * df["volume"]
            df["liquidity"] = liquidity
            df["liquidity_log_ret"] = np.log(liquidity) - np.log(liquidity.shift(1))
            for lag in range(2, window, 2):
                liq_ret_col = f"liquidity_log_ret_lag_{lag}"
                df[liq_ret_col] = np.log(liquidity.shift(lag)) - np.log(liquidity.shift(lag + 1))
                liq_ma_col = f"liquidity_ma_lag_{lag}"
                df[liq_ma_col] = df[liq_ret_col].rolling(window=lag, min_periods=1).mean()
                liq_ewm_col = f"liquidity_ewm_lag_{lag}"
                df[liq_ewm_col] = df[liq_ret_col].ewm(span=lag, adjust=False).mean()
        if verbose:
            df.dropna(inplace=True)
            print("Processed DataFrame shape:", df.shape)
            print("Sample data:")
            print(df.head())
        if save_csv:
            df.to_csv("full_features.csv")
        return df

    def make_train_test(
        self,
        df_x: pd.DataFrame,
        df_y: pd.DataFrame | None = None,
        window: int = 0,
        has_y: bool = False,
        binary_y: bool = False,
        split: float = 0.8,
        save_csv: bool = False,
    ) -> tuple[pd.DataFrame, pd.Series, pd.DataFrame, pd.Series]:
        if not has_y:
            if "close" not in df_x.columns:
                raise ValueError("Input DataFrame must contain 'close' column for target generation.")
            y = np.log(df_x["close"].shift(-window)) - np.log(df_x["close"])
            y = pd.Series(y, index=df_x.index)
        else:
            if df_y is None:
                raise ValueError("df_y must be provided when has_y=True.")
            y = df_y.squeeze()
        y.dropna(inplace=True)
        if binary_y:
            y = y.apply(lambda x: 1 if x > 0 else -1 if x < 0 else 0)
        if window > 0:
            df_x_aligned = df_x.iloc[:-window]
        else:
            df_x_aligned = df_x
        df_x_aligned = df_x_aligned.loc[y.index]
        n_train = int(len(df_x_aligned) * split)
        train_x = df_x_aligned.iloc[:n_train]
        train_y = y.iloc[:n_train]
        test_x = df_x_aligned.iloc[n_train:]
        test_y = y.iloc[n_train:]
        if save_csv:
            train_x.to_csv("train_x.csv")
            train_y.to_csv("train_y.csv")
            test_x.to_csv("test_x.csv")
            test_y.to_csv("test_y.csv")
            df_x_aligned.to_csv("full_x.csv")
            y.to_csv("full_y.csv")
        return train_x, train_y, test_x, test_y

    def check_labels(self, y_values: pd.Series) -> None:
        print("Label frequency counts:")
        print(y_values.value_counts())