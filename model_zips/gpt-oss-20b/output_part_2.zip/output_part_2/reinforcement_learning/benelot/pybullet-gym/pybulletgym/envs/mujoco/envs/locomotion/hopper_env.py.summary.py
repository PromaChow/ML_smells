import numpy as np

# Minimal stubs to make the environment executable
class Scene:
    def global_step(self):
        pass

scene = Scene()

class HUD:
    def update(self, state, action, done):
        pass

class Hopper:
    def __init__(self):
        self.state = np.zeros(6)  # example state vector

    def apply_action(self, a):
        # placeholder for applying action to the robot
        pass

    def calc_potential(self):
        # placeholder for potential calculation (e.g., forward progress)
        return np.sum(self.state[:2])  # simple example

class WalkerBaseMuJoCoEnv:
    def __init__(self, robot, **kwargs):
        self.robot = robot
        self.multiplayer = kwargs.get('multiplayer', False)

    def step(self, action):
        raise NotImplementedError

class HopperMuJoCoEnv(WalkerBaseMuJoCoEnv):
    def __init__(self, **kwargs):
        robot = Hopper()
        super().__init__(robot, **kwargs)
        self.debugmode = kwargs.get('debugmode', 0)
        self.HUD = HUD()

    def step(self, a):
        if not self.multiplayer:
            self.robot.apply_action(a)
            scene.global_step()

        state = self.robot.state
        alive_bonus = 1.0
        potential = self.robot.calc_potential()
        power_cost = -1e-3 * np.sum(np.square(a))

        rewards = [potential, alive_bonus, power_cost]

        if self.debugmode == 1:
            print(f"Potential: {potential}, Power Cost: {power_cost}, Rewards: {rewards}")

        done = False
        if not np.all(np.isfinite(state)):
            done = True
        if np.any(np.abs(state[2:]) > 100):
            done = True
        if state[0] < -0.3:
            done = True
        if np.abs(state[1]) > 0.2:
            done = True

        self.HUD.update(state, a, done)

        return state, sum(rewards), done, {}
