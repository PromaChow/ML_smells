from abc import ABC, abstractmethod
from typing import Tuple, Optional

from torch.utils.data import Dataset, DataLoader


class BaseADDataset(ABC):
    """
    Abstract base class for anomaly detection datasets.

    Subclasses must define:
        - normal_classes
        - outlier_classes
        - train_set
        - test_set
    and implement the `loaders` method.
    """

    def __init__(self, root: str) -> None:
        self.root: str = root
        self.n_classes: int = 2  # normal and outlier
        self.normal_classes: Optional[list] = None
        self.outlier_classes: Optional[list] = None
        self.train_set: Optional[Dataset] = None
        self.test_set: Optional[Dataset] = None

    @abstractmethod
    def loaders(
        self,
        batch_size: int = 32,
        shuffle_train: bool = True,
        shuffle_test: bool = False,
        num_workers: int = 0,
    ) -> Tuple[DataLoader, DataLoader]:
        """
        Return DataLoader instances for training and testing sets.

        Parameters
        ----------
        batch_size : int, default 32
            Number of samples per batch.
        shuffle_train : bool, default True
            Whether to shuffle training data.
        shuffle_test : bool, default False
            Whether to shuffle test data.
        num_workers : int, default 0
            Number of subprocesses for data loading.

        Returns
        -------
        Tuple[DataLoader, DataLoader]
            DataLoaders for training and testing.
        """
        pass

    def __repr__(self) -> str:
        return self.__class__.__name__