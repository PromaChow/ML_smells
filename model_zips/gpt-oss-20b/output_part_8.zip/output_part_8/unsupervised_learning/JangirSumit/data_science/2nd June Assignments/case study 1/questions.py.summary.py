import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import accuracy_score

# 1. Data Loading
df = pd.read_csv("voice-classification.csv")

# 2. Feature and Target Separation
X = df.drop(columns=["label"])
Y = df["label"]

# 3. Data Splitting
train_x, test_x, train_y, test_y = train_test_split(
    X, Y, test_size=0.3, random_state=10
)

# 4. Model Initialization
gnb = GaussianNB()

# 5. Model Training
gnb.fit(train_x, train_y)

# 6. Prediction
predictions = gnb.predict(test_x)

# 7. Evaluation
accuracy = accuracy_score(test_y, predictions)
print(f"Accuracy: {accuracy:.4f}")