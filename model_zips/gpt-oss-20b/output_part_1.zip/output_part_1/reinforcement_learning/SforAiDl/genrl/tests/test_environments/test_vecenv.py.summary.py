import unittest
import gymnasium as gym
import torch
from stable_baselines3.common.vec_env import (
    DummyVecEnv,
    SubprocVecEnv,
    VecNormalize,
    VecMonitor,
)
from stable_baselines3.common.running_mean_std import RunningMeanStd


def make_vec_env(env_id: str, n_envs: int, parallel: bool):
    env_fns = [lambda: gym.make(env_id) for _ in range(n_envs)]
    if parallel:
        return SubprocVecEnv(env_fns)
    return DummyVecEnv(env_fns)


class TestVectorEnvironments(unittest.TestCase):
    def test_vecenv_parallel(self):
        env = make_vec_env("CartPole-v1", 2, parallel=True)
        env.seed(0)
        spaces = env.get_spaces()
        obs = env.reset()
        actions = env.sample()
        next_obs, rewards, dones, infos = env.step(actions)
        env.close()

        self.assertEqual(obs.shape[0], 2)
        self.assertEqual(next_obs.shape[0], 2)
        self.assertEqual(rewards.shape[0], 2)
        self.assertEqual(dones.shape[0], 2)

    def test_vecenv_serial(self):
        env = make_vec_env("CartPole-v1", 2, parallel=False)
        env.seed(0)
        spaces = env.get_spaces()
        obs = env.reset()
        actions = env.sample()
        next_obs, rewards, dones, infos = env.step(actions)
        env.close()

        self.assertEqual(obs.shape[0], 2)
        self.assertEqual(next_obs.shape[0], 2)
        self.assertEqual(rewards.shape[0], 2)
        self.assertEqual(dones.shape[0], 2)

    def test_vecnormalize(self):
        env = make_vec_env("CartPole-v1", 2, parallel=False)
        env = VecNormalize(
            env,
            norm_obs=True,
            norm_reward=True,
            clip_obs=1.0,
            clip_reward=1.0,
        )
        obs = env.reset()
        actions = env.sample()
        next_obs, rewards, dones, infos = env.step(actions)
        env.close()

        self.assertTrue(rewards.max() <= 1.0)
        self.assertTrue(rewards.min() >= -1.0)

    def test_vecmonitor(self):
        env = make_vec_env("CartPole-v1", 2, parallel=False)
        env = VecMonitor(env, history_length=1)
        obs = env.reset()
        actions = env.sample()
        next_obs, rewards, dones, infos = env.step(actions)

        while not dones[0]:
            actions = env.sample()
            next_obs, rewards, dones, infos = env.step(actions)

        episode_info = infos[0].get("episode")
        self.assertIsNotNone(episode_info)
        self.assertIn("r", episode_info)
        self.assertIn("l", episode_info)
        self.assertIn("t", episode_info)

        env.close()

    def test_rms(self):
        rms = RunningMeanStd(shape=(5, 2))
        batch = torch.randn(5, 2)
        rms.update(batch)
        self.assertEqual(rms.mean.shape, (5, 2))
        self.assertEqual(rms.var.shape, (5, 2))
        self.assertAlmostEqual(rms.count, 5.0, places=5)


if __name__ == "__main__":
    unittest.main()
