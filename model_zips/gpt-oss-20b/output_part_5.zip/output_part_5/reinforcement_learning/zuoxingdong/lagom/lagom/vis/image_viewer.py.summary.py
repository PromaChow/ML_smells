import numpy as np
import pyglet

try:
    from pyglet import gl
except Exception as exc:
    raise ImportError(
        "OpenGL support is required for pyglet.\n"
        "Please install the necessary packages:\n"
        "  pip install pyglet\n"
        "  # On Linux, you might need to install system libraries:\n"
        "  sudo apt-get install libgl1-mesa-dev libglu1-mesa-dev\n"
        "  # For headless servers, ensure you have an OpenGL context provider.\n"
        "If you are using a virtual environment or a CI system, make sure the "
        "display is set (e.g., xvfb)."
    ) from exc


class ImageViewer(pyglet.window.Window):
    def __init__(self, max_width=800, *args, **kwargs):
        super().__init__(
            width=1,
            height=1,
            resizable=True,
            vsync=False,
            visible=False,
            *args,
            **kwargs,
        )
        self.max_width = max_width
        self.closed = False

    def __call__(self, image_array: np.ndarray):
        if not isinstance(image_array, np.ndarray):
            raise TypeError("image_array must be a numpy.ndarray")
        if image_array.ndim != 3 or image_array.shape[2] != 3:
            raise ValueError("image_array must have shape (H, W, 3)")
        height, width, _ = image_array.shape

        if width > self.max_width:
            scale = self.max_width / width
            new_width = self.max_width
            new_height = int(round(height * scale))
        else:
            new_width, new_height = width, height

        self.set_size(new_width, new_height)
        if not self.visible:
            self.set_visible(True)

        image_data = pyglet.image.ImageData(
            new_width, new_height, "RGB", image_array.tobytes()
        )
        texture = image_data.get_texture()
        texture.min_filter = gl.GL_NEAREST
        texture.mag_filter = gl.GL_NEAREST
        texture.width = new_width
        texture.height = new_height

        self.switch_to()
        gl.glClear(gl.GL_COLOR_BUFFER_BIT)
        texture.blit(0, 0)
        self.flip()

    def close(self):
        if not self.closed:
            self.closed = True
            super().close()
