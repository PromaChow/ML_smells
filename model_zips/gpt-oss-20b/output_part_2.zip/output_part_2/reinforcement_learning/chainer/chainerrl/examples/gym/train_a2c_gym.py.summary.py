import argparse
import logging
import os
import sys

import gym
import numpy as np

import chainer
import chainer.links as L
import chainer.optimizers as O
import chainer.functions as F
import chainer.backends.cuda as cuda
import chainer.datasets
import chainer.chemistry
import chainer.loss
import chainer.optimizers
import chainer.links
import chainer.links.Chain
import chainer.optimizers
import chainer.training

import chainer_rl.algorithms as algo
import chainer_rl.algorithms.a2c as a2c
import chainer_rl.envs as rl_envs
import chainer_rl.utils as rl_utils
import chainer_rl.experiments as experiments
import chainer.utils.misc as misc


# ----- Environment wrappers -----
class Float32ObsWrapper(gym.ObservationWrapper):
    def observation(self, observation):
        return observation.astype(np.float32)


class RewardScaleWrapper(gym.RewardWrapper):
    def __init__(self, env, factor):
        super().__init__(env)
        self.factor = factor

    def reward(self, reward):
        return reward * self.factor


# ----- Model definitions -----
class MLP(chainer.Chain):
    def __init__(self, input_size, output_size, hidden_units=(64, 64)):
        super().__init__()
        with self.init_scope():
            self.l1 = L.Linear(input_size, hidden_units[0])
            self.l2 = L.Linear(hidden_units[0], hidden_units[1])
            self.out = L.Linear(hidden_units[1], output_size)

    def __call__(self, x):
        h = F.relu(self.l1(x))
        h = F.relu(self.l2(h))
        return self.out(h)


def make_policy_model(env, arch):
    obs_space = env.observation_space
    act_space = env.action_space

    if isinstance(act_space, gym.spaces.Discrete):
        n_actions = act_space.n
        policy_net = MLP(obs_space.shape[0], n_actions)
        value_net = MLP(obs_space.shape[0], 1)
        if arch == "FFSoftmax":
            policy = a2c.A2CFFSoftmax(policy_net, value_net)
        else:
            policy = a2c.A2CFFMellowmax(policy_net, value_net)
    else:  # Continuous
        act_dim = act_space.shape[0]
        policy_net = MLP(obs_space.shape[0], act_dim * 2)
        value_net = MLP(obs_space.shape[0], 1)
        policy = a2c.A2CGaussian(policy_net, value_net)
    return policy


# ----- Argument parsing -----
parser = argparse.ArgumentParser()
parser.add_argument("--env", type=str, default="Pendulum-v0")
parser.add_argument("--arch", type=str, default="Gaussian", choices=["FFSoftmax", "FFMellowmax", "Gaussian"])
parser.add_argument("--seed", type=int, default=0)
parser.add_argument("--outdir", type=str, required=True)
parser.add_argument("--steps", type=float, default=8e7)
parser.add_argument("--lr", type=float, default=7e-4)
parser.add_argument("--gamma", type=float, default=0.99)
parser.add_argument("--rmsprop-epsilon", type=float, default=1e-5)
parser.add_argument("--alpha", type=float, default=0.99)
parser.add_argument("--update-steps", type=int, default=5)
parser.add_argument("--max-grad-norm", type=float, default=0.5)
parser.add_argument("--weight-decay", type=float, default=0.0)
parser.add_argument("--num-envs", type=int, default=1)
parser.add_argument("--reward-scale-factor", type=float, default=1e-2)
parser.add_argument("--monitor", action="store_true")
parser.add_argument("--logger-level", type=str, default="DEBUG")
parser.add_argument("--load", type=str, default=None)
parser.add_argument("--demo", action="store_true")
parser.add_argument("--eval-n-runs", type=int, default=10)
parser.add_argument("--eval-interval", type=float, default=1e5)
parser.add_argument("--log-interval", type=int, default=1000)
args = parser.parse_args()


# ----- Logging and seeds -----
numeric_level = getattr(logging, args.logger_level.upper(), logging.DEBUG)
logging.basicConfig(level=numeric_level, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger()

misc.set_random_seed(args.seed)
process_seeds = np.arange(args.num_envs) + args.seed * args.num_envs


# ----- Output directory -----
outdir = experiments.prepare_output_dir(
    args.outdir,
    env_name=args.env,
    arch=args.arch,
    seed=args.seed,
    args=args,
)
os.makedirs(outdir, exist_ok=True)


# ----- Environment creation -----
def make_env(env_name, seed, monitor):
    def _make():
        env = gym.make(env_name)
        env.seed(seed)
        env = Float32ObsWrapper(env)
        env = RewardScaleWrapper(env, args.reward_scale_factor)
        if monitor:
            env = gym.wrappers.Monitor(env, os.path.join(outdir, f"monitor_{seed}"), force=True)
        return env
    return _make


# Test environment for evaluation
test_env = make_env(args.env, args.seed + 1000, False)()


# Batch environments
env_fns = [make_env(args.env, int(seed), i == 0 and args.monitor) for i, seed in enumerate(process_seeds)]
envs = rl_envs.MultiprocessVectorEnv(env_fns)


# ----- Model selection -----
policy = make_policy_model(test_env, args.arch)


# ----- Optimizer -----
optimizer = O.RMSprop(alpha=args.alpha, eps=args.rmsprop_epsilon)
optimizer.setup(policy)
optimizer.add_hook(chainer.optimizer_hooks.GradientClipping(args.max_grad_norm))
if args.weight_decay > 0:
    optimizer.add_hook(chainer.optimizer_hooks.WeightDecay(args.weight_decay))


# ----- Agent -----
agent = a2c.A2C(
    model=policy,
    optimizer=optimizer,
    gamma=args.gamma,
    num_processes=args.num_envs,
    update_steps=args.update_steps,
    use_gae=False,
    tau=0.95,
)

# Load pretrained weights if specified
if args.load:
    agent.load(args.load)


# ----- Demo mode -----
if args.demo:
    rewards = rl_utils.eval_performance(agent, test_env, n_runs=args.eval_n_runs, render=False)
    logger.info(f"Demo mode: mean={np.mean(rewards):.3f}, median={np.median(rewards):.3f}, std={np.std(rewards):.3f}")
    sys.exit(0)


# ----- Training loop -----
experiments.train_agent_batch_with_evaluation(
    agent,
    envs,
    test_env,
    nsteps=int(args.steps),
    eval_interval=int(args.eval_interval),
    eval_n_runs=args.eval_n_runs,
    log_interval=args.log_interval,
    outdir=outdir,
    logger_level=args.logger_level,
)