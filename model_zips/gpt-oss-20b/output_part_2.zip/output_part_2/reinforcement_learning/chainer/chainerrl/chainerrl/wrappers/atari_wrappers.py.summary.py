import gym
import numpy as np
import cv2
from collections import deque
from typing import Any, Dict, Tuple, List, Optional


class LazyFrames:
    def __init__(self, frames: List[np.ndarray]):
        self.frames = frames
        self._out = None

    def __array__(self, dtype=None):
        if self._out is None:
            self._out = np.concatenate(self.frames, axis=0)
        if dtype is not None:
            return self._out.astype(dtype)
        return self._out

    def __len__(self):
        return len(self._out) if self._out is not None else sum(len(f) for f in self.frames)

    def __getitem__(self, i):
        return np.array(self.frames[i])


class NoopResetEnv(gym.Wrapper):
    def __init__(self, env: gym.Env, noop_max: int = 30):
        super().__init__(env)
        self.noop_max = noop_max
        if not isinstance(env.action_space, gym.spaces.Discrete) or env.action_space.n <= 0:
            raise ValueError("NoopResetEnv requires a discrete action space.")
        if env.action_space.n <= 0:
            raise ValueError("Action space must contain at least one action.")

    def reset(self, **kwargs) -> Any:
        obs = self.env.reset(**kwargs)
        noops = np.random.randint(1, self.noop_max + 1)
        for _ in range(noops):
            obs, _, done, _ = self.env.step(0)
            if done:
                obs = self.env.reset(**kwargs)
        return obs

    def step(self, action: int) -> Tuple[Any, float, bool, Dict]:
        return self.env.step(action)


class FireResetEnv(gym.Wrapper):
    def __init__(self, env: gym.Env):
        super().__init__(env)
        if not isinstance(env.action_space, gym.spaces.Discrete):
            raise ValueError("FireResetEnv requires a discrete action space.")

    def reset(self, **kwargs) -> Any:
        obs = self.env.reset(**kwargs)
        for action in [1, 2]:
            obs, _, done, _ = self.env.step(action)
            if done:
                obs = self.env.reset(**kwargs)
        return obs

    def step(self, action: int) -> Tuple[Any, float, bool, Dict]:
        return self.env.step(action)


class EpisodicLifeEnv(gym.Wrapper):
    def __init__(self, env: gym.Env):
        super().__init__(env)
        self.lives = 0
        self.was_real_done = False

    def step(self, action: int) -> Tuple[Any, float, bool, Dict]:
        obs, reward, done, info = self.env.step(action)
        lives = self.env.unwrapped.ale.lives()
        if lives < self.lives and lives > 0:
            done = True
        self.was_real_done = done
        self.lives = lives
        return obs, reward, done, info

    def reset(self, **kwargs) -> Any:
        if self.was_real_done:
            obs = self.env.reset(**kwargs)
        else:
            obs, _, _, _ = self.env.step(0)
        self.lives = self.env.unwrapped.ale.lives()
        return obs


class MaxAndSkipEnv(gym.Wrapper):
    def __init__(self, env: gym.Env, skip: int = 4):
        super().__init__(env)
        self.skip = skip
        self._obs_buffer: List[np.ndarray] = []

    def step(self, action: int) -> Tuple[Any, float, bool, Dict]:
        total_reward = 0.0
        done = False
        for _ in range(self.skip):
            obs, reward, done, info = self.env.step(action)
            self._obs_buffer.append(obs)
            total_reward += reward
            if done:
                break
        max_frame = np.max(np.stack(self._obs_buffer, axis=0), axis=0)
        self._obs_buffer = []
        return max_frame, total_reward, done, info

    def reset(self, **kwargs) -> Any:
        obs = self.env.reset(**kwargs)
        self._obs_buffer = []
        return obs


class ClipRewardEnv(gym.RewardWrapper):
    def reward(self, reward: float) -> float:
        return np.sign(reward)


class WarpFrame(gym.ObservationWrapper):
    def __init__(self, env: gym.Env, width: int = 84, height: int = 84, channel_order: str = "chw"):
        super().__init__(env)
        self.width = width
        self.height = height
        self.channel_order = channel_order.lower()
        obs_shape = env.observation_space.shape
        if len(obs_shape) == 3:
            channel = obs_shape[2]
            if channel == 3:
                self.dtype = np.uint8
                if self.channel_order == "chw":
                    self.observation_space = gym.spaces.Box(low=0, high=255, shape=(1, height, width), dtype=np.uint8)
                else:
                    self.observation_space = gym.spaces.Box(low=0, high=255, shape=(height, width, 1), dtype=np.uint8)
            else:
                self.dtype = obs_shape[0]
                if self.channel_order == "chw":
                    self.observation_space = gym.spaces.Box(low=0, high=255, shape=(obs_shape[2], height, width), dtype=obs_shape[0])
                else:
                    self.observation_space = gym.spaces.Box(low=0, high=255, shape=(height, width, obs_shape[2]), dtype=obs_shape[0])
        else:
            self.dtype = obs_shape[0]
            if self.channel_order == "chw":
                self.observation_space = gym.spaces.Box(low=0, high=255, shape=(1, height, width), dtype=obs_shape[0])
            else:
                self.observation_space = gym.spaces.Box(low=0, high=255, shape=(height, width, 1), dtype=obs_shape[0])

    def observation(self, obs: np.ndarray) -> np.ndarray:
        obs = cv2.cvtColor(obs, cv2.COLOR_RGB2GRAY)
        obs = cv2.resize(obs, (self.width, self.height), interpolation=cv2.INTER_AREA)
        if self.channel_order == "chw":
            obs = np.expand_dims(obs, axis=0)
        else:
            obs = np.expand_dims(obs, axis=-1)
        return obs.astype(np.uint8)


class FrameStack(gym.Wrapper):
    def __init__(self, env: gym.Env, num_frames: int = 4, channel_order: str = "chw"):
        super().__init__(env)
        self.num_frames = num_frames
        self.channel_order = channel_order.lower()
        self.frames: deque = deque(maxlen=num_frames)
        shp = env.observation_space.shape
        if self.channel_order == "chw":
            new_shape = (num_frames, shp[1], shp[2])
        else:
            new_shape = (shp[0], shp[1], num_frames)
        self.observation_space = gym.spaces.Box(low=0, high=255, shape=new_shape, dtype=env.observation_space.dtype)

    def reset(self, **kwargs) -> Any:
        obs = self.env.reset(**kwargs)
        for _ in range(self.num_frames):
            self.frames.append(obs)
        return LazyFrames(list(self.frames))

    def step(self, action: int) -> Tuple[Any, float, bool, Dict]:
        obs, reward, done, info = self.env.step(action)
        self.frames.append(obs)
        return LazyFrames(list(self.frames)), reward, done, info


class ScaledFloatFrame(gym.ObservationWrapper):
    def __init__(self, env: gym.Env):
        super().__init__(env)
        self.observation_space = gym.spaces.Box(low=0.0, high=1.0, shape=env.observation_space.shape, dtype=np.float32)

    def observation(self, obs: np.ndarray) -> np.ndarray:
        return obs.astype(np.float32) / 255.0


class FlickerFrame(gym.ObservationWrapper):
    def __init__(self, env: gym.Env, flicker: bool = True):
        super().__init__(env)
        self.flicker = flicker

    def observation(self, obs: np.ndarray) -> np.ndarray:
        if self.flicker and np.random.rand() < 0.5:
            return np.zeros_like(obs)
        return obs


def make_atari(env_id: str, max_frames: int = 30 * 60 * 60) -> gym.Env:
    env = gym.make(env_id)
    if not env_id.endswith("NoFrameskip-v4"):
        raise ValueError(f"Environment {env_id} must be a NoFrameskip variant.")
    while isinstance(env, gym.wrappers.TimeLimit):
        env = env.env
    env = gym.wrappers.TimeLimit(env, max_episode_steps=max_frames)
    env = NoopResetEnv(env, noop_max=30)
    env = MaxAndSkipEnv(env, skip=4)
    return env


def wrap_deepmind(
    env: gym.Env,
    episode_life: bool = True,
    fire_reset: bool = True,
    scale: bool = True,
    clip_rewards: bool = True,
    flicker: bool = False,
    channel_order: str = "chw",
) -> gym.Env:
    if episode_life:
        env = EpisodicLifeEnv(env)
    if fire_reset:
        env = FireResetEnv(env)
    env = WarpFrame(env, channel_order=channel_order)
    if scale:
        env = ScaledFloatFrame(env)
    if clip_rewards:
        env = ClipRewardEnv(env)
    if flicker:
        env = FlickerFrame(env)
    env = FrameStack(env, num_frames=4, channel_order=channel_order)
    return env

if __name__ == "__main__":
    env = make_atari("BreakoutNoFrameskip-v4")
    env = wrap_deepmind(env, flicker=True)
    obs = env.reset()
    done = False
    while not done:
        action = env.action_space.sample()
        obs, reward, done, info = env.step(action)
    env.close()
