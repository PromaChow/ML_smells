import argparse
import os
import logging
import numpy as np
import gym
import chainer
import chainer.functions as F
import chainerrl
import chainerrl.links
import chainerrl.optimizers
import chainerrl.explorers
import chainerrl.replay_buffer
import chainerrl.training
import chainerrl.envs
from chainerrl.envs import atari_wrappers
from chainerrl.envs import RandomizeAction
from gym.wrappers import Monitor, Render


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--env", default="BreakoutNoFrameskip-v4")
    parser.add_argument("--outdir", required=True)
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--gpu", type=int, default=-1)
    parser.add_argument("--demo", action="store_true")
    parser.add_argument("--load", default=None)
    parser.add_argument("--final-epsilon", type=float, default=0.1)
    parser.add_argument("--final-exploration-frames", type=int, default=1_000_000)
    parser.add_argument("--steps", type=int, default=10_000_000)
    parser.add_argument("--replay-start-size", type=int, default=50_000)
    parser.add_argument("--arch", default="nature", choices=["nature", "doubledqn", "nips", "dueling"])
    parser.add_argument("--agent", default="dqn", choices=["dqn", "double", "pal"])
    parser.add_argument("--noisy-net-sigma", type=float, default=0.0)
    parser.add_argument("--monitor", action="store_true")
    parser.add_argument("--render", action="store_true")
    parser.add_argument("--eval-epsilon", type=float, default=0.0)
    parser.add_argument("--eval-interval", type=int, default=200_000)
    parser.add_argument("--eval-n-runs", type=int, default=10)
    parser.add_argument("--checkpoint-frequency", type=int, default=1_000_000)
    parser.add_argument("--prioritized", action="store_true")
    parser.add_argument("--num-step-return", type=int, default=1)
    parser.add_argument("--update-interval", type=int, default=4)
    parser.add_argument("--log-level", default="INFO")
    return parser.parse_args()


def make_env(seed, eval_mode=False, monitor=False, render=False):
    env = gym.make(args.env)
    env.seed(seed)
    if eval_mode:
        env = atari_wrappers.wrap_deepmind(env, episode_life=False, clip_rewards=False)
    else:
        env = atari_wrappers.wrap_deepmind(env)
    if args.demo:
        env = RandomizeAction(env, args.eval_epsilon)
    if monitor:
        env = Monitor(env, args.outdir, force=True)
    if render:
        env = Render(env)
    return env


def parse_arch(arch_name, n_actions):
    arch_map = {
        "nature": chainerrl.links.nature_dqn,
        "doubledqn": chainerrl.links.doubledqn,
        "nips": chainerrl.links.nips_dqn,
        "dueling": chainerrl.links.dueling_dqn,
    }
    return arch_map[arch_name](n_actions=n_actions)


def parse_agent(agent_name):
    agent_map = {
        "dqn": chainerrl.agents.DQN,
        "double": chainerrl.agents.DoubleDQN,
        "pal": chainerrl.agents.PAL,
    }
    return agent_map[agent_name]


def phi(x):
    return x.astype(np.float32) / 255.0


def evaluate(env, agent, n_runs):
    rewards = []
    for _ in range(n_runs):
        obs = env.reset()
        total_reward = 0.0
        done = False
        while not done:
            action = agent.act(obs, stochastic=False)
            obs, reward, done, _ = env.step(action)
            total_reward += reward
        rewards.append(total_reward)
    return rewards


if __name__ == "__main__":
    args = parse_args()
    os.makedirs(args.outdir, exist_ok=True)
    logging.basicConfig(level=getattr(logging, args.log_level.upper()))
    device = chainer.get_device(args.gpu)
    device.use()
    chainerrl.misc.set_random_seed(args.seed)

    train_env = make_env(args.seed, monitor=args.monitor, render=args.render)
    eval_env = make_env(args.seed + 1, eval_mode=True, monitor=args.monitor)

    n_actions = train_env.action_space.n
    q_func = parse_arch(args.arch, n_actions)
    if args.noisy_net_sigma > 0:
        q_func = chainerrl.links.NoisyFactorized(q_func, sigma=args.noisy_net_sigma)
        explorer = chainerrl.explorers.GreedyExplorer()
    else:
        explorer = chainerrl.explorers.LinearDecayEpsilonGreedy(
            start=1.0,
            end=args.final_epsilon,
            decay_steps=args.final_exploration_frames,
        )

    graph = chainer.functions.draw_graph(q_func, name="q_func")
    graph.draw(os.path.join(args.outdir, "q_func_graph.png"))

    optimizer = chainerrl.optimizers.RMSpropGraves(
        q_func,
        lr=args.lr if hasattr(args, "lr") else 2.5e-4,
        alpha=0.95,
        momentum=0.0,
        epsilon=1e-2,
    )

    capacity = int(1e6)
    if args.prioritized:
        replay_buffer = chainerrl.replay_buffer.PrioritizedReplayBuffer(
            capacity=capacity,
            alpha=0.6,
            beta0=0.4,
            betasteps=args.steps // args.update_interval,
        )
    else:
        replay_buffer = chainerrl.replay_buffer.ReplayBuffer(capacity=capacity)

    agent_cls = parse_agent(args.agent)
    agent = agent_cls(
        q_func=q_func,
        optimizer=optimizer,
        replay_buffer=replay_buffer,
        gpu=args.gpu,
        gamma=0.99,
        explorer=explorer,
        replay_start_size=args.replay_start_size,
        target_update_interval=30_000,
        clip_delta=True,
        update_interval=args.update_interval,
        batch_accumulator=sum,
        phi=phi,
    )

    if args.load:
        agent.load(args.load)

    if args.demo:
        rewards = evaluate(eval_env, agent, args.eval_n_runs)
        mean = np.mean(rewards)
        median = np.median(rewards)
        std = np.std(rewards)
        logging.info(f"Demo: mean={mean:.2f}, median={median:.2f}, std={std:.2f}")
    else:
        monitor = train_env if args.monitor else None
        eval_monitor = eval_env if args.monitor else None
        chainerrl.training.train_agent_with_evaluation(
            agent,
            train_env,
            eval_env,
            steps=args.steps,
            eval_interval=args.eval_interval,
            eval_n_episodes=args.eval_n_runs,
            monitor=monitor,
            eval_monitor=eval_monitor,
            log_dir=args.outdir,
            checkpoint_frequency=args.checkpoint_frequency,
        )