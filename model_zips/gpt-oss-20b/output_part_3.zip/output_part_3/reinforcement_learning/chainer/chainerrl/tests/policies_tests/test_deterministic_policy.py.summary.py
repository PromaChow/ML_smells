import numpy as np
import chainer
import chainer.cuda as cuda
import chainer.functions as F
import chainer.links as L
from chainer import Variable
from nose.plugins.attrib import attr
from chainerrl.testing.testing import parameterize, to_gpu
from chainerrl.model import FCDeterministicPolicy, FCBNDeterministicPolicy, FCLSTMDeterministicPolicy
from chainerrl.policy import ContinuousDeterministicDistribution


def _make_model(**kwargs):
    base_params = {
        'n_input_channels': kwargs['n_input_channels'],
        'action_size': kwargs['action_size'],
        'bound_action': kwargs['bound_action'],
        'min_action': -1.0,
        'max_action': 1.0,
        'nonlinearity': kwargs['nonlinearity'],
    }
    model_params = {k: v for k, v in kwargs.items() if k not in base_params}
    return kwargs['model'](n_input_channels=base_params['n_input_channels'],
                            action_size=base_params['action_size'],
                            bound_action=base_params['bound_action'],
                            min_action=base_params['min_action'],
                            max_action=base_params['max_action'],
                            nonlinearity=base_params['nonlinearity'],
                            **model_params)


@parametrize(
    {'model': FCDeterministicPolicy,
     'n_input_channels': 1,
     'action_size': 1,
     'bound_action': True,
     'nonlinearity': 'relu',
     'n_hidden_layers': 1,
     'n_hidden_channels': 32,
     'last_wscale': 1.0},
    {'model': FCDeterministicPolicy,
     'n_input_channels': 5,
     'action_size': 2,
     'bound_action': False,
     'nonlinearity': 'elu',
     'n_hidden_layers': 2,
     'n_hidden_channels': 64,
     'last_wscale': 0.5},
    {'model': FCBNDeterministicPolicy,
     'n_input_channels': 1,
     'action_size': 1,
     'bound_action': True,
     'nonlinearity': 'relu',
     'n_hidden_layers': 1,
     'n_hidden_channels': 32,
     'normalize_input': True,
     'last_wscale': 1.0},
    {'model': FCBNDeterministicPolicy,
     'n_input_channels': 5,
     'action_size': 2,
     'bound_action': False,
     'nonlinearity': 'elu',
     'n_hidden_layers': 2,
     'n_hidden_channels': 64,
     'normalize_input': False,
     'last_wscale': 0.5},
    {'model': FCLSTMDeterministicPolicy,
     'n_input_channels': 1,
     'action_size': 1,
     'bound_action': True,
     'nonlinearity': 'relu',
     'n_hidden_layers': 1,
     'n_hidden_channels': 32,
     'n_lstm_units': 32,
     'last_wscale': 1.0},
    {'model': FCLSTMDeterministicPolicy,
     'n_input_channels': 5,
     'action_size': 2,
     'bound_action': False,
     'nonlinearity': 'elu',
     'n_hidden_layers': 2,
     'n_hidden_channels': 64,
     'n_lstm_units': 64,
     'last_wscale': 0.5},
)
class TestDeterministicPolicy:
    batch_size = 7

    def _test_call(self, use_gpu=False):
        model = _make_model(**self.__dict__)
        x_np = np.random.randn(self.batch_size, self.n_input_channels).astype(np.float32)
        if use_gpu:
            x_np = to_gpu(x_np)
        x = Variable(x_np)
        dist = model(x)
        assert isinstance(dist, ContinuousDeterministicDistribution), (
            f"Expected ContinuousDeterministicDistribution, got {type(dist)}"
        )
        action = dist.action
        assert action.shape == (self.batch_size, self.action_size), (
            f"Expected action shape {(self.batch_size, self.action_size)}, got {action.shape}"
        )
        if use_gpu:
            assert cuda.get_array_module(action).cupy.get_device(action.data) == cuda.get_array_module(x).cupy.get_device(x.data)
        else:
            assert action.device == 'cpu'
        if self.bound_action:
            assert np.all(action.data >= -1.0), "Action below min bound"
            assert np.all(action.data <= 1.0), "Action above max bound"

    def test_call_cpu(self):
        self._test_call(use_gpu=False)

    @attr.gpu
    def test_call_gpu(self):
        self._test_call(use_gpu=True)