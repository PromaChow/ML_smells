import numpy as np
from sklearn.tree import DecisionTreeRegressor

class BaggedTreeRegressor:
    def __init__(self, n_estimators: int = 20, max_depth: int = 5,
                 min_samples_split: int = 2, min_samples_leaf: int = 1):
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.min_samples_leaf = min_samples_leaf
        self.models = []

    def fit(self, X, y):
        X = np.asarray(X)
        y = np.asarray(y)
        n_samples = X.shape[0]
        self.models = []

        for _ in range(self.n_estimators):
            # Bootstrap sampling
            indices = np.random.choice(n_samples, size=n_samples, replace=True)
            X_boot = X[indices]
            y_boot = y[indices]

            # Tree initialization without min_samples_* parameters
            tree = DecisionTreeRegressor(max_depth=self.max_depth)
            tree.fit(X_boot, y_boot)
            self.models.append(tree)

    def predict(self, X):
        if not self.models:
            raise ValueError("The model has not been fitted yet.")
        X = np.asarray(X)
        preds = np.column_stack([model.predict(X) for model in self.models])
        return np.mean(preds, axis=1)