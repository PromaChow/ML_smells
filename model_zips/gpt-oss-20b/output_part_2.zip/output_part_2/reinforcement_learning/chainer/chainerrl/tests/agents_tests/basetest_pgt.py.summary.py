import chainer
import chainerrl
import chainerrl.links as L
import chainerrl.q_functions as Q
import chainerrl.policies as P
import chainerrl.explorers as explorers
import chainerrl.replay_buffer as replay_buffer
import gym
from dataclasses import dataclass
from abc import ABC, abstractmethod
from chainerrl.agents import pgta


@dataclass
class Model:
    policy: chainer.Link
    q_func: chainer.Link


class BasePGTTest(ABC):
    def make_agent(self, env: gym.Env):
        model = self.make_model(env)
        opt_actor = chainer.optimizers.Adam(alpha=1e-4)
        opt_actor.setup(model.policy)
        opt_critic = chainer.optimizers.Adam(alpha=1e-3)
        opt_critic.setup(model.q_func)
        explorer = explorers.LinearDecayEpsilonGreedy(
            1.0, 0.2, 1000, lambda: env.action_space.sample()
        )
        replay_buffer_obj = self.make_replay_buffer()
        agent = self.make_pgt_agent(
            env, model, opt_actor, opt_critic, explorer, replay_buffer_obj
        )
        return agent

    @abstractmethod
    def make_model(self, env: gym.Env) -> Model:
        ...

    @abstractmethod
    def make_env_and_successful_return(self) -> tuple[gym.Env, float]:
        ...

    def make_replay_buffer(self):
        return replay_buffer.ReplayBuffer(capacity=100_000)

    @abstractmethod
    def make_pgt_agent(
        self,
        env: gym.Env,
        model: Model,
        opt_actor: chainer.Optimizer,
        opt_critic: chainer.Optimizer,
        explorer: explorers.Explorer,
        replay_buffer_obj: replay_buffer.ReplayBuffer,
    ) -> pgta.PGTAgent:
        ...


class TestPGTOnContinuousPOABC(BasePGTTest):
    def make_model(self, env: gym.Env) -> Model:
        policy = L.Sequential(
            L.Linear(10, 64),
            L.ReLU(),
            L.LSTM(64, 64),
            P.GaussianPolicy(64, env.action_space.shape[0], 0.1),
        )
        q_func = Q.FCLSTMSAQFunction(
            input_shape=env.observation_space.shape,
            hidden_sizes=[64, 64],
            lstm_size=64,
        )
        return Model(policy=policy, q_func=q_func)

    def make_env_and_successful_return(self) -> tuple[gym.Env, float]:
        env = gym.make("abc/continuous-po", discrete=False, partial_observable=True)
        return env, 1.0

    def make_replay_buffer(self):
        return replay_buffer.EpisodicReplayBuffer(capacity=100_000)

    def make_pgt_agent(
        self,
        env: gym.Env,
        model: Model,
        opt_actor: chainer.Optimizer,
        opt_critic: chainer.Optimizer,
        explorer: explorers.Explorer,
        replay_buffer_obj: replay_buffer.ReplayBuffer,
    ) -> pgta.PGTAgent:
        return pgta.PGTAgent(
            model=model,
            policy_optimizer=opt_actor,
            q_func_optimizer=opt_critic,
            explorer=explorer,
            replay_buffer=replay_buffer_obj,
            discount=0.99,
            tau=0.005,
            l2_reg=0.0,
        )


class TestPGTOnContinuousABC(BasePGTTest):
    def make_model(self, env: gym.Env) -> Model:
        policy = P.FCGaussianPolicy(
            input_size=env.observation_space.shape[0], hidden_sizes=[64, 64]
        )
        q_func = Q.FCSAQFunction(
            input_size=env.observation_space.shape[0], hidden_sizes=[64, 64]
        )
        return Model(policy=policy, q_func=q_func)

    def make_env_and_successful_return(self) -> tuple[gym.Env, float]:
        env = gym.make("abc/continuous-abc", discrete=False, partial_observable=False)
        return env, 1.0

    def make_pgt_agent(
        self,
        env: gym.Env,
        model: Model,
        opt_actor: chainer.Optimizer,
        opt_critic: chainer.Optimizer,
        explorer: explorers.Explorer,
        replay_buffer_obj: replay_buffer.ReplayBuffer,
    ) -> pgta.PGTAgent:
        return pgta.PGTAgent(
            model=model,
            policy_optimizer=opt_actor,
            q_func_optimizer=opt_critic,
            explorer=explorer,
            replay_buffer=replay_buffer_obj,
            discount=0.99,
            tau=0.005,
            l2_reg=0.0,
        )