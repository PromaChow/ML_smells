import argparse
import json
import logging
import os
import random
import sys
from collections import deque
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.optim.lr_scheduler import CosineAnnealingLR, StepLR

import yaml
from ssl_lib.datasets.builder import gen_dataloader
from ssl_lib.models.builder import gen_model
from ssl_lib.losses import gen_consistency
from ssl_lib.algorithms import gen_ssl_alg


def set_seed(seed: int):
    torch.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


class Meter:
    def __init__(self):
        self.reset()

    def reset(self):
        self.sum = 0.0
        self.count = 0

    def update(self, val, n=1):
        self.sum += val * n
        self.count += n

    @property
    def avg(self):
        return self.sum / self.count if self.count else 0.0


def ema_update(teacher: nn.Module, student: nn.Module, momentum: float):
    with torch.no_grad():
        for t_param, s_param in zip(teacher.parameters(), student.parameters()):
            t_param.data.mul_(momentum).add_(s_param.data, alpha=1 - momentum)


def avg_update(avg_model: nn.Module, student: nn.Module, momentum: float):
    with torch.no_grad():
        for a_param, s_param in zip(avg_model.parameters(), student.parameters()):
            a_param.data.mul_(momentum).add_(s_param.data, alpha=1 - momentum)


def evaluate(model: nn.Module, loader, device, criterion):
    model.eval()
    loss_meter = Meter()
    acc_meter = Meter()
    with torch.no_grad():
        for batch in loader:
            inputs = batch["images"].to(device)
            targets = batch["labels"].to(device)
            outputs = model(inputs)
            loss = criterion(outputs, targets)
            loss_meter.update(loss.item(), inputs.size(0))
            preds = torch.argmax(outputs, dim=1)
            acc = (preds == targets).float().sum()
            acc_meter.update(acc.item(), inputs.size(0))
    return acc_meter.avg, loss_meter.avg, model


def main():
    parser = argparse.ArgumentParser(description="SSL Training Pipeline")
    parser.add_argument("--config", type=str, required=True, help="Path to YAML config file")
    parser.add_argument("--output_dir", type=str, required=True, help="Output directory")
    args = parser.parse_args()

    # Load configuration
    with open(args.config, "r") as f:
        cfg = yaml.safe_load(f)

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Setup logging
    logger = logging.getLogger("SSLTrainer")
    logger.setLevel(logging.INFO)
    formatter = logging.Formatter("[%(asctime)s] %(levelname)s: %(message)s")
    ch = logging.StreamHandler(sys.stdout)
    ch.setFormatter(formatter)
    fh = logging.FileHandler(output_dir / "train.log")
    fh.setFormatter(formatter)
    logger.addHandler(ch)
    logger.addHandler(fh)

    # Reproducibility
    set_seed(cfg.get("seed", 42))

    # Device
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if torch.cuda.is_available():
        torch.backends.cudnn.benchmark = True

    # Data loaders
    labeled_loader, unlabeled_loader, test_loader, class_count, image_size = gen_dataloader(
        cfg["dataset"], batch_size=cfg["batch_size"]
    )

    # SSL components
    consistency = gen_consistency(cfg["consistency"])
    ssl_alg = gen_ssl_alg(cfg["ssl_algorithm"])
    student = gen_model(cfg["model"]).to(device)
    teacher = None
    if cfg.get("ema_teacher", False):
        teacher = gen_model(cfg["model"]).to(device)
        teacher.load_state_dict(student.state_dict())
        teacher.eval()
    avg_model = None
    if cfg.get("weight_averaging", False):
        avg_model = gen_model(cfg["model"]).to(device)
        avg_model.load_state_dict(student.state_dict())

    # Optimizer
    if cfg["optimizer"]["type"] == "sgd":
        optimizer = optim.SGD(
            student.parameters(),
            lr=cfg["optimizer"]["lr"],
            momentum=cfg["optimizer"].get("momentum", 0.9),
            weight_decay=cfg["optimizer"].get("weight_decay", 5e-4),
        )
    elif cfg["optimizer"]["type"] == "adam":
        optimizer = optim.Adam(
            student.parameters(),
            lr=cfg["optimizer"]["lr"],
            weight_decay=cfg["optimizer"].get("weight_decay", 5e-4),
        )
    else:
        raise ValueError("Unsupported optimizer type")

    # Scheduler
    if cfg["scheduler"]["type"] == "cosine":
        scheduler = CosineAnnealingLR(
            optimizer,
            T_max=cfg["scheduler"].get("T_max", cfg["total_iters"]),
            eta_min=cfg["scheduler"].get("eta_min", 0),
        )
    elif cfg["scheduler"]["type"] == "step":
        scheduler = StepLR(
            optimizer,
            step_size=cfg["scheduler"].get("step_size", 10000),
            gamma=cfg["scheduler"].get("gamma", 0.5),
        )
    else:
        raise ValueError("Unsupported scheduler type")

    criterion = nn.CrossEntropyLoss()

    # Training loop
    labeled_iter = iter(labeled_loader)
    unlabeled_iter = iter(unlabeled_loader)
    total_iters = cfg["total_iters"]
    log_interval = cfg.get("log_interval", 100)
    eval_interval = cfg.get("eval_interval", 1000)
    save_interval = cfg.get("save_interval", 1000)
    ema_momentum = cfg.get("ema_momentum", 0.999)
    avg_momentum = cfg.get("avg_momentum", 0.999)
    ssl_coef_warmup = cfg.get("ssl_coef_warmup", 1000)
    entropy_minimization = cfg.get("entropy_minimization", False)

    ssl_coef_meter = Meter()
    sup_loss_meter = Meter()
    cons_loss_meter = Meter()
    ent_loss_meter = Meter()
    acc_meter = Meter()

    test_accuracies = deque(maxlen=50)
    raw_accuracies = deque(maxlen=50)

    for iteration in range(1, total_iters + 1):
        # Get batches
        try:
            labeled_batch = next(labeled_iter)
        except StopIteration:
            labeled_iter = iter(labeled_loader)
            labeled_batch = next(labeled_iter)

        try:
            unlabeled_batch = next(unlabeled_iter)
        except StopIteration:
            unlabeled_iter = iter(unlabeled_loader)
            unlabeled_batch = next(unlabeled_iter)

        # Labeled data
        x_l = labeled_batch["images"].to(device)
        y_l = labeled_batch["labels"].to(device)

        # Unlabeled data: assume dict with 'weak' and 'strong'
        x_u_w = unlabeled_batch["weak"].to(device)
        x_u_s = unlabeled_batch["strong"].to(device)

        # Forward pass
        student.train()
        if teacher:
            teacher.eval()
        if avg_model:
            avg_model.eval()

        # Student outputs
        logits_l = student(x_l)
        logits_u_w = student(x_u_w)
        logits_u_s = student(x_u_s)

        # Supervised loss
        sup_loss = criterion(logits_l, y_l)

        # Consistency loss
        if cfg.get("use_consistency", False):
            # Teacher predictions
            with torch.no_grad():
                if teacher:
                    teacher_logits_u_w = teacher(x_u_w)
                else:
                    teacher_logits_u_w = logits_u_w.detach()
            # Pseudo labels via SSL algorithm
            pseudo_labels = ssl_alg(logits_u_w, teacher_logits_u_w)
            # Consistency loss between student strong and pseudo labels
            cons_loss = consistency(logits_u_s, pseudo_labels)
        else:
            cons_loss = torch.tensor(0.0, device=device)

        # Entropy minimization
        if entropy_minimization:
            probs = F.softmax(logits_u_s, dim=1)
            ent_loss = -torch.mean(torch.sum(probs * torch.log(probs + 1e-8), dim=1))
        else:
            ent_loss = torch.tensor(0.0, device=device)

        # SSL coefficient
        ssl_coef = min(1.0, iteration / ssl_coef_warmup)
        total_loss = sup_loss + ssl_coef * cons_loss + ent_loss

        # Backpropagation
        optimizer.zero_grad()
        total_loss.backward()
        optimizer.step()
        scheduler.step()

        # EMA updates
        if teacher:
            ema_update(teacher, student, ema_momentum)
        if avg_model:
            avg_update(avg_model, student, avg_momentum)

        # Metrics
        preds_l = torch.argmax(logits_l, dim=1)
        acc = (preds_l == y_l).float().mean().item()

        sup_loss_meter.update(sup_loss.item(), x_l.size(0))
        cons_loss_meter.update(cons_loss.item(), x_l.size(0))
        ent_loss_meter.update(ent_loss.item(), x_l.size(0))
        acc_meter.update(acc, x_l.size(0))
        ssl_coef_meter.update(ssl_coef, x_l.size(0))

        if iteration % log_interval == 0:
            logger.info(
                f"Iter {iteration:5d} | "
                f"SupLoss: {sup_loss_meter.avg:.4f} | "
                f"ConsLoss: {cons_loss_meter.avg:.4f} | "
                f"EntLoss: {ent_loss_meter.avg:.4f} | "
                f"Acc: {acc_meter.avg:.4f} | "
                f"LR: {optimizer.param_groups[0]['lr']:.6f} | "
                f"SSLCoef: {ssl_coef_meter.avg:.4f}"
            )
            sup_loss_meter.reset()
            cons_loss_meter.reset()
            ent_loss_meter.reset()
            acc_meter.reset()
            ssl_coef_meter.reset()

        # Evaluation
        if iteration % eval_interval == 0:
            raw_acc, raw_loss, _ = evaluate(student, test_loader, device, criterion)
            eval_acc, eval_loss, _ = evaluate(avg_model if avg_model else student, test_loader, device, criterion)
            logger.info(f"Evaluation @ Iter {iteration}: RawAcc={raw_acc:.4f}, EvalAcc={eval_acc:.4f}")
            test_accuracies.append(eval_acc)
            raw_accuracies.append(raw_acc)
            np.save(output_dir / f"test_acc_{iteration}.npy", np.array(eval_acc))
            np.save(output_dir / f"raw_acc_{iteration}.npy", np.array(raw_acc))

            # Median accuracy over last checkpoints
            medians = {}
            for window in [1, 10, 20, 50]:
                if len(test_accuracies) >= window:
                    medians[f"median_{window}"] = np.median(list(test_accuracies)[-window:])
            json.dump(medians, open(output_dir / "median_acc.json", "w"))

        # Checkpoint
        if iteration % save_interval == 0:
            checkpoint = {
                "iter": iteration,
                "student_state_dict": student.state_dict(),
                "optimizer_state_dict": optimizer.state_dict(),
                "scheduler_state_dict": scheduler.state_dict(),
                "ema_state_dict": teacher.state_dict() if teacher else None,
                "avg_state_dict": avg_model.state_dict() if avg_model else None,
            }
            torch.save(checkpoint, output_dir / f"checkpoint_{iteration}.pth")

    logger.info("Training completed.")


if __name__ == "__main__":
    main()
