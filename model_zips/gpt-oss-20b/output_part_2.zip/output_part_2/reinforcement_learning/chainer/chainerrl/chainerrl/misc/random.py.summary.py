import numpy as np

def sample_k_distinct(n: int, k: int) -> np.ndarray:
    if k < 0 or k > n:
        raise ValueError("k must satisfy 0 ≤ k ≤ n")
    if k == 0:
        return np.array([], dtype=int)

    # Direct sampling when k is large relative to n
    if 3 * k >= n:
        return np.random.choice(n, k, replace=False)

    # Efficient sampling for small k
    samples = np.random.choice(n, 2 * k, replace=True)
    selected = set()
    j = k
    for i in range(k):
        while samples[i] in selected:
            if j == 2 * k:
                samples[k:2 * k] = np.random.choice(n, k, replace=True)
                j = k
            samples[i] = samples[j]
            j += 1
        selected.add(samples[i])
    return samples[:k]