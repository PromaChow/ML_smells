import numpy as np

def cv_index(n: int, n_fold: int) -> np.ndarray:
    """
    Generate cross‑validation indices for `n` samples divided into `n_fold` folds.
    """
    indices = (np.arange(n) * n_fold) // n
    return np.random.permutation(indices)


def squared_dist(x: np.ndarray, c: np.ndarray) -> np.ndarray:
    """
    Compute squared Euclidean distance between each row of `x` and each row of `c`.
    Returns an array of shape (len(x), len(c)).
    """
    xx = np.sum(x ** 2, axis=1, keepdims=True)
    cc = np.sum(c ** 2, axis=1, keepdims=True).T
    return xx + cc - 2 * x @ c.T


def gauss_basis(dist2: np.ndarray, sigma: float) -> np.ndarray:
    """
    Apply Gaussian kernel to squared distances.
    """
    return np.exp(-dist2 / (2 * sigma ** 2))


def homo_coord(x: np.ndarray) -> np.ndarray:
    """
    Append a column of ones to the right of `x` to create homogeneous coordinates.
    """
    ones = np.ones((x.shape[0], 1), dtype=x.dtype)
    return np.concatenate((x, ones), axis=1)


def bin_clf_err(y_h: np.ndarray, y_t: np.ndarray, prior: float | None = None) -> float:
    """
    Compute binary classification error between predicted labels `y_h` and true labels `y_t`.
    If `prior` is given, weight false positives and false negatives accordingly.
    """
    y_h = np.asarray(y_h)
    y_t = np.asarray(y_t)

    if prior is not None:
        f_p = np.mean((y_h == 1) & (y_t == -1))
        f_n = np.mean((y_h == -1) & (y_t == 1))
        return prior * f_p + (1 - prior) * f_n
    else:
        return np.mean(y_h * y_t <= 0)