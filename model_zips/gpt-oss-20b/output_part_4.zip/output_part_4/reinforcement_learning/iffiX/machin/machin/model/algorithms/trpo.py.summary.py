import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Categorical, Normal


class TRPO:
    @staticmethod
    def set_flat_params(module: nn.Module, flat_params: torch.Tensor):
        """Replace module parameters with values from a flat vector."""
        pointer = 0
        for p in module.parameters():
            numel = p.numel()
            new_param = flat_params[pointer : pointer + numel].view_as(p)
            p.data.copy_(new_param)
            pointer += numel


class ActorDiscrete(nn.Module):
    def __init__(self, action_dim: int, hidden_dim: int = 64):
        super().__init__()
        self.action_dim = action_dim
        self.policy_net = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, action_dim),
        )
        self.action_param = None  # Stores action probabilities from the last forward pass

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Compute action probabilities and store them."""
        logits = self.policy_net(x)
        probs = F.softmax(logits, dim=-1)
        self.action_param = probs
        return probs

    def sample(self, probability: torch.Tensor, action: torch.Tensor | None = None):
        """Sample actions from a categorical distribution."""
        eps = 1e-6
        prob = probability + eps
        dist = Categorical(prob)
        if action is None:
            action = dist.sample()
        log_prob = dist.log_prob(action)
        self.action_param = probability
        return action.view(-1, 1), log_prob.view(-1, 1)

    def get_kl(self) -> torch.Tensor:
        """Compute KL divergence of current distribution with its detached copy."""
        if self.action_param is None:
            raise RuntimeError("No action probabilities stored from a forward pass.")
        action_prob_0 = self.action_param.detach()
        action_prob_1 = self.action_param
        kl = action_prob_0 * (torch.log(action_prob_0) - torch.log(action_prob_1))
        return kl.sum(-1)  # Sum over action dimension

    def compare_kl(self, params: torch.Tensor, observation: torch.Tensor) -> torch.Tensor:
        """Compare KL divergence between two sets of parameters."""
        backup = [p.clone() for p in self.parameters()]
        TRPO.set_flat_params(self, params)

        # Forward pass with new parameters
        action_prob_old = self.forward(observation).detach()

        # Restore original parameters
        for p, b in zip(self.parameters(), backup):
            p.data.copy_(b)

        # Forward pass with original parameters
        action_prob_new = self.forward(observation)

        kl = action_prob_old * (torch.log(action_prob_old) - torch.log(action_prob_new))
        return kl.sum(-1).mean()

    def get_fim(self) -> tuple[torch.Tensor, torch.Tensor]:
        """Compute Fisher Information Matrix approximation."""
        if self.action_param is None:
            raise RuntimeError("No action probabilities stored from a forward pass.")
        M = 1.0 / self.action_param
        return M.detach(), self.action_param


class ActorContinuous(nn.Module):
    def __init__(self, action_dim: int, hidden_dim: int = 64, log_std_init: float = 0.0):
        super().__init__()
        self.action_dim = action_dim
        self.policy_net = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, action_dim),
        )
        self.action_log_std = nn.Parameter(
            torch.full((action_dim,), log_std_init)
        )
        self.action_param = None  # Stores mean from the last forward pass

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Compute action mean and store it."""
        mean = self.policy_net(x)
        self.action_param = mean
        return mean

    def sample(self, mean: torch.Tensor, action: torch.Tensor | None = None):
        """Sample actions from a Gaussian distribution."""
        std = torch.exp(self.action_log_std)
        dist = Normal(mean, std.expand_as(mean))
        if action is None:
            action = dist.sample()
        log_prob = dist.log_prob(action).sum(-1)
        self.action_param = mean
        return action, log_prob

    def get_kl(self) -> torch.Tensor:
        """Compute KL divergence between current and detached Gaussian."""
        if self.action_param is None:
            raise RuntimeError("No action mean stored from a forward pass.")
        mean_0 = self.action_param.detach()
        mean_1 = self.action_param
        log_std0 = self.action_log_std.detach()
        log_std1 = self.action_log_std
        std0 = torch.exp(log_std0)
        std1 = torch.exp(log_std1)

        term1 = log_std1 - log_std0
        term2 = (std0.pow(2) + (mean_0 - mean_1).pow(2)) / (2 * std1.pow(2))
        kl = term1 + term2 - 0.5
        return kl.sum(-1)  # Sum over action dimension

    def compare_kl(self, params: torch.Tensor, observation: torch.Tensor) -> torch.Tensor:
        """Compare KL divergence between two sets of parameters."""
        backup = [p.clone() for p in self.parameters()]
        TRPO.set_flat_params(self, params)

        # Forward pass with new parameters
        mean_old = self.forward(observation).detach()

        # Restore original parameters
        for p, b in zip(self.parameters(), backup):
            p.data.copy_(b)

        # Forward pass with original parameters
        mean_new = self.forward(observation)

        log_std0 = self.action_log_std.detach()
        log_std1 = self.action_log_std
        std0 = torch.exp(log_std0)
        std1 = torch.exp(log_std1)

        term1 = log_std1 - log_std0
        term2 = (std0.pow(2) + (mean_old - mean_new).pow(2)) / (2 * std1.pow(2))
        kl = term1 + term2 - 0.5
        return kl.sum(-1).mean()

    def get_fim(self) -> tuple[torch.Tensor, torch.Tensor]:
        """Compute Fisher Information Matrix approximation."""
        if self.action_param is None:
            raise RuntimeError("No action mean stored from a forward pass.")
        M = torch.exp(-2 * self.action_log_std)
        return M.detach(), self.action_param
