from dataclasses import dataclass, replace
from typing import Optional, Dict

@dataclass(frozen=True)
class PPOConfig:
    # General PPO settings
    algo: str = "PPO"
    num_agents: int = 30
    eval_episodes: int = 30
    use_gpu: bool = False

    # Network settings
    policy_type: str = "Gaussian"           # "Gaussian" or "Categorical"
    hidden_layers: tuple[int, ...] = (200, 100)
    init_std: float = 0.35
    output_factor: float = 0.1

    # Optimization settings
    optimizer_lr: float = 1e-4
    update_every: int = 30
    epochs: int = 25
    batch_size: int = 20
    chunk_len: int = 50

    # Loss / regularization
    discount: float = 0.995
    kl_target: float = 0.01
    cutoff_factor: float = 2.0
    penalty_coeff: float = 1000.0

    # Environment specifics
    env_name: str = ""
    max_episode_length: int = 0
    range_norm: bool = True   # True unless disabled
    steps: int = 0

# Default configuration
default_config = PPOConfig(
    env_name="default",
    max_episode_length=0
)

# Individual environment configurations
pendulum_cfg = replace(
    default_config,
    env_name="Pendulum-v0",
    steps=1_000_000,
    max_episode_length=200,
    batch_size=20,
    chunk_len=50
)

cartpole_cfg = replace(
    default_config,
    env_name="CartPole-v1",
    steps=200_000,
    max_episode_length=500,
    range_norm=False,
    policy_type="Categorical"
)

reacher_cfg = replace(
    default_config,
    env_name="Reacher-v2",
    steps=5_000_000,
    max_episode_length=1000,
    discount=0.985,
    update_every=60
)

halfcheetah_cfg = replace(
    default_config,
    env_name="HalfCheetah-v2",
    steps=10_000_000,
    max_episode_length=1000,
    discount=0.99
)

walker2d_cfg = replace(
    default_config,
    env_name="Walker2d-v2",
    steps=10_000_000,
    max_episode_length=1000
)

hopper_cfg = replace(
    default_config,
    env_name="Hopper-v2",
    steps=10_000_000,
    max_episode_length=1000,
    update_every=60
)

ant_cfg = replace(
    default_config,
    env_name="Ant-v2",
    steps=20_000_000,
    max_episode_length=1000
)

humanoid_cfg = replace(
    default_config,
    env_name="Humanoid-v2",
    steps=50_000_000,
    max_episode_length=1000,
    update_every=60
)

bullet_ant_cfg = replace(
    default_config,
    env_name="AntBulletEnv-v0",
    steps=30_000_000,
    max_episode_length=1000,
    update_every=60
)

# Mapping of environment names to their configurations
ENV_CONFIGS: Dict[str, PPOConfig] = {
    "Pendulum-v0": pendulum_cfg,
    "CartPole-v1": cartpole_cfg,
    "Reacher-v2": reacher_cfg,
    "HalfCheetah-v2": halfcheetah_cfg,
    "Walker2d-v2": walker2d_cfg,
    "Hopper-v2": hopper_cfg,
    "Ant-v2": ant_cfg,
    "Humanoid-v2": humanoid_cfg,
    "AntBulletEnv-v0": bullet_ant_cfg,
}

if __name__ == "__main__":
    # Example usage: print configurations
    for name, cfg in ENV_CONFIGS.items():
        print(f"{name}: {cfg}")