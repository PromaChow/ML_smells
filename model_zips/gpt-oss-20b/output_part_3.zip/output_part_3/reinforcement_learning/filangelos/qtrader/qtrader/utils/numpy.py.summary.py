import numpy as np

eps = np.finfo(float).eps

def append_row(a: np.ndarray, row: np.ndarray) -> np.ndarray:
    """
    Append a 1D row to a 2D array `a` along the first axis.

    Parameters
    ----------
    a : np.ndarray
        2D array to which the row will be appended.
    row : np.ndarray
        1D array representing the row to append.

    Returns
    -------
    np.ndarray
        New array with the row appended.
    """
    return np.r_[a, [row]]


def softmax(x: np.ndarray) -> np.ndarray:
    """
    Compute the softmax of `x` along the columns (axis 0).

    Parameters
    ----------
    x : np.ndarray
        Input array of scores.

    Returns
    -------
    np.ndarray
        Softmax probabilities, same shape as `x`.
    """
    # Subtract the maximum value per column for numerical stability
    shifted = x - np.max(x, axis=0, keepdims=True)
    exp_shifted = np.exp(shifted)
    sums = np.sum(exp_shifted, axis=0, keepdims=True)
    return exp_shifted / sums

