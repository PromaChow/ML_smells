import argparse
import os
import sys

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd


def parse_arguments():
    parser = argparse.ArgumentParser(description="Plot scores from tab‑separated files.")
    parser.add_argument(
        '--title', type=str, default=None,
        help='Optional title for the plot.'
    )
    parser.add_argument(
        '--file', type=str, nargs='+', required=True,
        help='Paths to files or directories containing scores.txt.'
    )
    parser.add_argument(
        '--label', type=str, nargs='+', required=True,
        help='Labels corresponding to each file input.'
    )
    args = parser.parse_args()

    if not args.file or not args.label:
        parser.error("Both --file and --label must be provided.")
    if len(args.file) != len(args.label):
        parser.error("The number of --file and --label arguments must be equal.")
    return args


def resolve_path(path):
    if os.path.isdir(path):
        return os.path.join(path, 'scores.txt')
    return path


def load_and_plot(file_path, label):
    if not os.path.isfile(file_path):
        sys.exit(f"Error: File not found: {file_path}")
    df = pd.read_csv(file_path, sep='\t', usecols=['steps', 'mean'])
    plt.plot(df['steps'], df['mean'], label=label)


def main():
    args = parse_arguments()

    for path, lbl in zip(args.file, args.label):
        resolved = resolve_path(path)
        load_and_plot(resolved, lbl)

    plt.xlabel('steps')
    plt.ylabel('score')
    plt.legend(loc='best')
    if args.title:
        plt.title(args.title)

    first_input = args.file[0]
    base_name = first_input
    if args.title:
        output_path = f"{base_name}_{args.title}.png"
    else:
        output_path = f"{base_name}.png"

    plt.savefig(output_path, bbox_inches='tight')
    plt.close()
    print(f"Plot saved to {output_path}")


if __name__ == "__main__":
    main()
