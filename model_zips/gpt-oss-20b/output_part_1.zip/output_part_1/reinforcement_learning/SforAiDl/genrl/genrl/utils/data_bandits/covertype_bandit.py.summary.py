import pathlib
import pandas as pd
import torch
from pathlib import Path

# Utility imports – assume these are available in the environment
from utils import DataBasedBandit, download_data, fetch_zipped_data_without_header


class CovertypeDataBandit(DataBasedBandit):
    """Contextual bandit for the UCI Covertype dataset."""

    _URL = (
        "https://archive.ics.uci.edu/ml/machine-learning-databases/covtype/covtype.data.gz"
    )

    def __init__(
        self,
        device: str = "cpu",
        path: pathlib.Path | str | None = None,
        download: bool = True,
        force_download: bool = False,
    ) -> None:
        super().__init__()
        self.device = torch.device(device)
        self.path = Path(path) if path else Path.cwd() / "data"
        self.download = download
        self.force_download = force_download

        if self.download:
            downloaded_path = download_data(self._URL, self.path)
            self._df = fetch_zipped_data_without_header(downloaded_path)
        else:
            self._df = fetch_covertype_data(self.path)

        self.n_actions = int(self._df.iloc[:, -1].nunique())
        self.context_dim = self._df.shape[1] - 1
        self.len = len(self._df)
        self._idx = 0

    def reset(self):
        """Shuffle the dataset and return the first context."""
        self._df = self._df.sample(frac=1).reset_index(drop=True)
        self._idx = 0
        self._reset()
        return self._get_context()

    def _compute_reward(self, action: int):
        """Return reward and a binary indicator for the chosen action."""
        true_label = self._df.iloc[self._idx, -1]
        reward = 1 if (action + 1) == true_label else 0
        return reward, 1

    def _get_context(self):
        """Return the feature vector of the current row as a tensor."""
        features = self._df.iloc[self._idx, :-1].values.astype(float)
        return torch.tensor(features, device=self.device, dtype=torch.float32)

    def _step(self, action: int):
        """Execute one step of the bandit."""
        reward, _ = self._compute_reward(action)
        self._idx = min(self._idx + 1, self.len - 1)
        return self._get_context(), reward


def fetch_covertype_data(path: pathlib.Path | str):
    """
    Load the Covertype dataset from a local path.
    Supports .data files and compressed .gz files.
    """
    p = Path(path)

    if p.is_file():
        if p.suffix == ".data":
            df = pd.read_csv(p, header=None, na_filter=False)
        elif p.suffix in {".gz", ".zip"}:
            df = fetch_zipped_data_without_header(p)
        else:
            raise ValueError(f"Unsupported file extension: {p.suffix}")
    elif p.is_dir():
        gz_file = p / "covtype.data.gz"
        if not gz_file.exists():
            raise FileNotFoundError(f"Compressed file not found: {gz_file}")
        df = fetch_zipped_data_without_header(gz_file)
    else:
        raise FileNotFoundError(f"Path does not exist: {p}")

    return df
