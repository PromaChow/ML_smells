import argparse
import importlib
import time

import gym
from gym.utils import seeding
import pybullet as p


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run a robot in PyBullet's GUI."
    )
    parser.add_argument(
        "robot",
        help="Fully qualified class name, e.g., module.path.ClassName",
    )
    args = parser.parse_args()

    # Connect to PyBullet GUI
    p.connect(p.GUI)

    # Dynamically import robot class
    module_path, class_name = args.robot.rsplit(".", 1)
    module = importlib.import_module(module_path)
    robot_cls = getattr(module, class_name)
    robot = robot_cls()

    # Seed random number generator
    _, np_random = seeding.np_random()

    # Reset robot simulation
    robot.reset(p)

    try:
        while True:
            low = robot.action_space.low
            high = robot.action_space.high
            action = np_random.uniform(low, high)
            robot.apply_action(action)
            p.stepSimulation()
            time.sleep(1 / 240.0)
    except KeyboardInterrupt:
        pass
    finally:
        p.disconnect()


if __name__ == "__main__":
    main()