import random
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F

class TransitionDB:
    def __init__(self):
        self.transitions = []

    def add(self, context, action, reward):
        self.transitions.append((context, action, reward))

    def sample(self, batch_size):
        return random.sample(self.transitions, min(batch_size, len(self.transitions)))

class NeuralBanditModel(nn.Module):
    def __init__(self, input_dim, n_actions, hidden_dims=(64, 32), dropout=0.1):
        super().__init__()
        layers = []
        prev_dim = input_dim
        for h in hidden_dims:
            layers.append(nn.Linear(prev_dim, h))
            layers.append(nn.ReLU())
            layers.append(nn.Dropout(dropout))
            prev_dim = h
        layers.append(nn.Linear(prev_dim, n_actions))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)

class BootstrapNeuralAgent:
    def __init__(
        self,
        problem,
        init_pulls=100,
        n=5,
        add_prob=0.5,
        device=None,
        hidden_dims=(64, 32),
        lr=1e-3,
        grad_clip=1.0,
        dropout=0.1,
        eval_with_dropout=True,
        train_epochs=10,
        batch_size=32,
        train_freq=50,
    ):
        self.problem = problem
        self.n_actions = problem.n_actions
        self.init_pulls = init_pulls
        self.n = n
        self.add_prob = add_prob
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.eval_with_dropout = eval_with_dropout
        self.train_epochs = train_epochs
        self.batch_size = batch_size
        self.train_freq = train_freq
        self.grad_clip = grad_clip

        self.step_counter = 0
        self.update_count = 0

        self.ensemble = [
            NeuralBanditModel(
                input_dim=problem.context_dim,
                n_actions=self.n_actions,
                hidden_dims=hidden_dims,
                dropout=dropout,
            ).to(self.device)
            for _ in range(self.n)
        ]
        self.optimizers = [optim.Adam(m.parameters(), lr=lr) for m in self.ensemble]
        self.transition_dbs = [TransitionDB() for _ in range(self.n)]

    def select_action(self, context):
        if self.step_counter < self.init_pulls * self.n_actions:
            action = self.step_counter % self.n_actions
            self.step_counter += 1
            return action
        idx = random.randrange(self.n)
        model = self.ensemble[idx]
        if self.eval_with_dropout:
            model.train()
        else:
            model.eval()
        with torch.no_grad():
            ctx = context.to(self.device)
            preds = model(ctx)
            action = torch.argmax(preds).item()
        self.step_counter += 1
        return action

    def update_database(self, context, action, reward):
        for db in self.transition_dbs:
            if self.update_count <= 1 or random.random() < self.add_prob:
                db.add(context, action, reward)

    def train_ensemble(self):
        for idx, model in enumerate(self.ensemble):
            db = self.transition_dbs[idx]
            if not db.transitions:
                continue
            optimizer = self.optimizers[idx]
            for _ in range(self.train_epochs):
                batch = db.sample(self.batch_size)
                contexts = torch.stack([t[0] for t in batch]).to(self.device)
                actions = torch.tensor([t[1] for t in batch], dtype=torch.long, device=self.device)
                rewards = torch.tensor([t[2] for t in batch], dtype=torch.float32, device=self.device)
                optimizer.zero_grad()
                preds = model(contexts)
                pred_actions = preds.gather(1, actions.unsqueeze(1)).squeeze(1)
                loss = F.mse_loss(pred_actions, rewards)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), self.grad_clip)
                optimizer.step()
        self.update_count += 1

    def step(self, context):
        action = self.select_action(context)
        reward = self.problem.evaluate(context, action)
        self.update_database(context, action, reward)
        if self.step_counter % self.train_freq == 0:
            self.train_ensemble()
        return action, reward
