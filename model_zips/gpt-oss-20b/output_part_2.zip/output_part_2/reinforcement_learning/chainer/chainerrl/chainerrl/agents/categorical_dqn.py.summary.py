import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import Tensor
import dqn  # assumes a base DQN implementation is available


def categorical_projection(y: Tensor, y_probs: Tensor, z: Tensor) -> Tensor:
    """
    Projects a distribution defined by atoms `y` and their probabilities `y_probs`
    onto the fixed support `z`.

    Args:
        y: Atom values before projection, shape (batch, n_atoms).
        y_probs: Probabilities of the atoms in `y`, shape (batch, n_atoms).
        z: Target atom values, shape (n_atoms,).

    Returns:
        z_probs: Projected probabilities onto the `z` atoms, shape (batch, n_atoms).
    """
    v_min = z[0]
    v_max = z[-1]
    delta_z = z[1] - z[0]
    batch_size, n_atoms = y.shape

    # Clip y to [v_min, v_max]
    y_clipped = torch.clamp(y, min=v_min, max=v_max)

    # Compute bj
    bj = (y_clipped - v_min) / delta_z
    bj = torch.clamp(bj, 0, n_atoms - 1)

    l = torch.floor(bj).long()
    u = torch.ceil(bj).long()

    l = l.clamp(0, n_atoms - 1)
    u = u.clamp(0, n_atoms - 1)

    # Calculate weights
    u_float = u.to(y.dtype)
    l_float = l.to(y.dtype)
    l_weight = u_float - bj
    u_weight = bj - l_float

    # Scatter add to the projected probabilities
    z_probs = torch.zeros((batch_size, n_atoms), device=y.device, dtype=y.dtype)
    # Lower indices
    z_probs.scatter_add_(1, l, l_weight * y_probs)
    # Upper indices
    z_probs.scatter_add_(1, u, u_weight * y_probs)

    return z_probs


def compute_value_loss(eltwise_loss: Tensor, batch_accumulator: str = "mean") -> Tensor:
    """
    Computes the loss by summing or averaging the element-wise losses across the batch.

    Args:
        eltwise_loss: Element-wise loss per example, shape (batch_size,).
        batch_accumulator: 'mean' or 'sum'.

    Returns:
        Scalar loss.
    """
    if batch_accumulator == "mean":
        return eltwise_loss.mean()
    elif batch_accumulator == "sum":
        return eltwise_loss.sum()
    else:
        raise ValueError("batch_accumulator must be 'mean' or 'sum'")


def compute_weighted_value_loss(
    eltwise_loss: Tensor, weights: Tensor, batch_accumulator: str = "mean"
) -> Tensor:
    """
    Computes weighted loss per example.

    Args:
        eltwise_loss: Loss per example, shape (batch_size,).
        weights: Weights per example, shape (batch_size,).
        batch_accumulator: 'mean' or 'sum'.

    Returns:
        Scalar loss.
    """
    weighted_loss = eltwise_loss * weights
    if batch_accumulator == "mean":
        return weighted_loss.mean()
    elif batch_accumulator == "sum":
        return weighted_loss.sum()
    else:
        raise ValueError("batch_accumulator must be 'mean' or 'sum'")


class CategoricalDQN(dqn.DQN):
    """
    Categorical Distributional DQN implementation.
    """

    def __init__(
        self,
        env,
        model,
        target_network,
        optimizer,
        replay_buffer,
        n_atoms: int,
        v_min: float,
        v_max: float,
        batch_accumulator: str = "mean",
        **kwargs,
    ):
        super().__init__(env, model, target_network, optimizer, replay_buffer, **kwargs)
        self.n_atoms = n_atoms
        self.v_min = v_min
        self.v_max = v_max
        self.delta_z = (v_max - v_min) / (n_atoms - 1)
        self.z_values = torch.linspace(v_min, v_max, n_atoms).to(self.device)
        self.batch_accumulator = batch_accumulator

    def _apply_categorical_projection(self, y: Tensor, y_probs: Tensor) -> Tensor:
        """
        Wrapper for the categorical projection.
        """
        return categorical_projection(y, y_probs, self.z_values)

    def _compute_target_values(self, exp_batch: dict) -> Tensor:
        """
        Compute the target distribution for the next state.
        """
        next_state = exp_batch["next_state"].to(self.device)
        next_recurrent_state = exp_batch.get("next_recurrent_state", None)
        reward = exp_batch["reward"].to(self.device).unsqueeze(1)
        terminal = exp_batch["is_state_terminal"].to(self.device).unsqueeze(1)
        discount = exp_batch["discount"].to(self.device).unsqueeze(1)

        if self.recurrent and next_recurrent_state is not None:
            target_next_qout = self.target_network(
                next_state, next_recurrent_state, training=False
            )
        else:
            target_next_qout = self.target_network(next_state, training=False)

        # target_next_qout: (batch, action, n_atoms) -> probabilities
        # Compute expected Q-values
        next_expected_q = torch.sum(target_next_qout * self.z_values, dim=2)
        # Choose best action
        next_best_action = torch.argmax(next_expected_q, dim=1)

        # Gather the probabilities of the best action
        batch_indices = torch.arange(next_state.size(0), device=self.device)
        next_action_probs = target_next_qout[batch_indices, next_best_action, :]

        # Compute Tz
        Tz = reward + (1.0 - terminal) * discount * self.z_values
        Tz = Tz.clamp(self.v_min, self.v_max)

        # Project onto z_values
        projected = self._apply_categorical_projection(Tz, next_action_probs)
        return projected

    def _compute_y_and_t(self, exp_batch: dict) -> tuple[Tensor, Tensor]:
        """
        Compute current distribution and target distribution for the batch.
        """
        state = exp_batch["state"].to(self.device)
        recurrent_state = exp_batch.get("recurrent_state", None)
        actions = exp_batch["action"].to(self.device)

        if self.recurrent and recurrent_state is not None:
            qout = self.model(state, recurrent_state)
        else:
            qout = self.model(state)

        # qout: (batch, action, n_atoms)
        batch_indices = torch.arange(state.size(0), device=self.device)
        y = qout[batch_indices, actions, :]

        t = self._compute_target_values(exp_batch)
        return y, t

    def _compute_loss(self, exp_batch: dict, errors_out: list | None = None) -> Tensor:
        """
        Compute cross-entropy loss between predicted and target distributions.
        """
        y, t = self._compute_y_and_t(exp_batch)

        # Cross-entropy: -sum t * log(y)
        eps = 1e-8
        y_clipped = y.clamp(min=eps)
        cross_entropy = -torch.sum(t * torch.log(y_clipped), dim=1)

        if errors_out is not None:
            errors_out.append(cross_entropy.detach().cpu())

        weights = exp_batch.get("weight", None)
        if weights is not None:
            weights = weights.to(self.device)
            loss = compute_weighted_value_loss(cross_entropy, weights, self.batch_accumulator)
        else:
            loss = compute_value_loss(cross_entropy, self.batch_accumulator)

        return loss
