import time
import statistics
from collections import deque
from typing import List, Dict, Any, Callable


def describe(trajectory: List[Dict[str, Any]]) -> float:
    """Compute the total return of a trajectory."""
    return sum(step.get("reward", 0.0) for step in trajectory)


class Logger:
    def __init__(self) -> None:
        self.records: Dict[str, Any] = {}

    def log(self, key: str, value: Any) -> None:
        self.records[key] = value

    def __repr__(self) -> str:
        return f"Logger({self.records})"


class Engine:
    def __init__(
        self,
        agent: Any,
        runner: Callable[[Any, Any, int], List[List[Dict[str, Any]]]],
        env: Any,
        timesteps_per_iteration: int,
    ) -> None:
        self.agent = agent
        self.runner = runner
        self.env = env
        self.timesteps_per_iteration = timesteps_per_iteration

    def train(self, iteration: int) -> Logger:
        # 1. Initiate training
        self.agent.train()

        # 2. Record start time
        start = time.perf_counter()

        # 3. Collect data
        D = self.runner(self.agent, self.env, self.timesteps_per_iteration)

        # 4. Learn from data
        out_agent = self.agent.learn(D)

        # 5. Initialize Logger
        logger = Logger()

        # 6. Log current training iteration
        logger.log("iteration", iteration + 1)

        # 7. Compute and log elapsed time
        elapsed = time.perf_counter() - start
        logger.log("elapsed_time", elapsed)

        # 8. Log agent-specific metrics
        for k, v in out_agent.items():
            logger.log(k, v)

        # 9. Log trajectory counts and total timesteps
        num_traj = len(D)
        total_timesteps = sum(len(traj) for traj in D)
        logger.log("num_trajectories", num_traj)
        logger.log("total_timesteps", total_timesteps)

        # 10. Log cumulative timesteps trained by agent
        logger.log("agent_total_timesteps", getattr(self.agent, "total_timestep", None))

        # 11. Compute and log returns per trajectory
        returns = [describe(traj) for traj in D]
        logger.log("returns_summary", f"{returns}")

        # 12. Extract episode-specific metrics from last step of each trajectory
        online_returns = []
        online_horizons = []
        for traj in D:
            if traj:
                last_step = traj[-1]
                er = last_step.get("episode_return")
                eh = last_step.get("episode_horizon")
                if er is not None:
                    online_returns.append(er)
                if eh is not None:
                    online_horizons.append(eh)
        if online_returns:
            logger.log("online_return", statistics.mean(online_returns))
        if online_horizons:
            logger.log("online_horizon", statistics.mean(online_horizons))

        # 13. Log running averages from environment queues
        return_queue: deque = getattr(self.env, "return_queue", deque())
        horizon_queue: deque = getattr(self.env, "horizon_queue", deque())
        if return_queue:
            logger.log("env_return_avg", statistics.mean(return_queue))
        if horizon_queue:
            logger.log("env_horizon_avg", statistics.mean(horizon_queue))

        # 14. Return populated Logger
        return logger

    def eval(self) -> None:
        pass

# Example placeholders for demonstration purposes
class DummyAgent:
    def __init__(self):
        self.total_timestep = 0

    def train(self):
        pass

    def learn(self, data):
        self.total_timestep += sum(len(traj) for traj in data)
        return {"loss": 0.1, "accuracy": 0.95}


class DummyEnv:
    def __init__(self):
        self.return_queue = deque([1.0, 2.0, 3.0])
        self.horizon_queue = deque([10, 12, 11])


def dummy_runner(agent, env, n):
    # Produce n trajectories each with 5 steps
    return [
        [{"reward": i, "episode_return": 10 + i, "episode_horizon": 5 + i} for i in range(5)]
        for _ in range(n)
    ]


# Example usage
if __name__ == "__main__":
    agent = DummyAgent()
    env = DummyEnv()
    engine = Engine(agent, dummy_runner, env, timesteps_per_iteration=10)
    logger = engine.train(iteration=0)
    print(logger)