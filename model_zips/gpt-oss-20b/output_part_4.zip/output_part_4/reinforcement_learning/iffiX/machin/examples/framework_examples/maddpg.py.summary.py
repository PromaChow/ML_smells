import copy
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from collections import deque, namedtuple

# Environment setup
def create_env():
    from multiagent.environment import MultiAgentEnv
    from multiagent.scenario import Scenario
    scenario = Scenario('simple_spread')
    env = MultiAgentEnv(scenario, max_cycles=30)
    env.set_max_steps(100)
    return env

# Actor network for discrete actions
class ActorDiscrete(nn.Module):
    def __init__(self, state_dim, action_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, action_dim),
            nn.Softmax(dim=-1)
        )

    def forward(self, state):
        return self.net(state)

# Critic network that observes all agents
class Critic(nn.Module):
    def __init__(self, state_dim, action_dim, num_agents):
        super().__init__()
        input_dim = num_agents * (state_dim + action_dim)
        self.net = nn.Sequential(
            nn.Linear(input_dim, 256),
            nn.ReLU(),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Linear(128, 1)
        )

    def forward(self, states, actions):
        # Flatten states and actions
        inp = torch.cat([states, actions], dim=-1)
        return self.net(inp)

# Replay buffer transition
Transition = namedtuple('Transition', ('state', 'action', 'reward', 'next_state', 'done'))

class MADDPG:
    def __init__(self, env, agent_num, device='cpu'):
        self.env = env
        self.agent_num = agent_num
        self.device = device

        obs_space = env.observation_space[0]
        action_space = env.action_space[0]
        state_dim = obs_space.shape[0]
        action_dim = action_space.n

        self.actors = []
        self.critics = []
        self.actor_optimizers = []
        self.critic_optimizers = []

        for _ in range(agent_num):
            actor = ActorDiscrete(state_dim, action_dim).to(device)
            critic = Critic(state_dim, action_dim, agent_num).to(device)
            self.actors.append(actor)
            self.critics.append(critic)
            self.actor_optimizers.append(optim.Adam(actor.parameters(), lr=1e-3))
            self.critic_optimizers.append(optim.Adam(critic.parameters(), lr=1e-3))

        self.criterion = nn.MSELoss()
        self.memory = deque(maxlen=10000)

    def act_discrete_with_noise(self, states, epsilon=0.1):
        actions = []
        with torch.no_grad():
            for i, state in enumerate(states):
                state_t = torch.tensor(state, dtype=torch.float32, device=self.device).unsqueeze(0)
                probs = self.actors[i](state_t)
                if np.random.rand() < epsilon:
                    action = np.random.choice(len(probs[0]))
                else:
                    action = torch.multinomial(probs[0], 1).item()
                actions.append(action)
        return actions

    def store_episodes(self, episode_transitions):
        for agent_id, trans in enumerate(episode_transitions):
            for t in trans:
                self.memory.append((agent_id, t))

    def update(self, batch_size=64, gamma=0.95):
        if len(self.memory) < batch_size:
            return
        batch = random.sample(self.memory, batch_size)
        for agent_id in range(self.agent_num):
            # Filter transitions for this agent
            agent_batch = [b for b in batch if b[0] == agent_id]
            if not agent_batch:
                continue
            states = torch.tensor([t.state for _, t in agent_batch], dtype=torch.float32, device=self.device)
            actions = torch.tensor([[t.action] for _, t in agent_batch], dtype=torch.float32, device=self.device)
            rewards = torch.tensor([t.reward for _, t in agent_batch], dtype=torch.float32, device=self.device).unsqueeze(1)
            next_states = torch.tensor([t.next_state for _, t in agent_batch], dtype=torch.float32, device=self.device)
            dones = torch.tensor([t.done for _, t in agent_batch], dtype=torch.float32, device=self.device).unsqueeze(1)

            # Gather all agents' states and actions
            full_states = torch.cat([states] * self.agent_num, dim=-1)
            full_actions = torch.cat([actions] * self.agent_num, dim=-1)
            full_next_states = torch.cat([next_states] * self.agent_num, dim=-1)
            with torch.no_grad():
                next_actions = torch.zeros_like(full_actions)
                for i in range(self.agent_num):
                    next_actions[:, i] = self.actors[i](full_next_states[:, i * states.shape[-1]:(i + 1) * states.shape[-1]]).argmax(dim=-1)
                target_q = self.critics[agent_id](full_next_states, next_actions)
                y = rewards + gamma * (1 - dones) * target_q

            current_q = self.critics[agent_id](full_states, full_actions)
            critic_loss = self.criterion(current_q, y)
            self.critic_optimizers[agent_id].zero_grad()
            critic_loss.backward()
            self.critic_optimizers[agent_id].step()

            # Actor loss
            actor_actions = torch.zeros_like(full_actions)
            for i in range(self.agent_num):
                probs = self.actors[i](full_states[:, i * states.shape[-1]:(i + 1) * states.shape[-1]])
                actor_actions[:, i] = probs.argmax(dim=-1)
            actor_loss = -self.critics[agent_id](full_states, actor_actions).mean()
            self.actor_optimizers[agent_id].zero_grad()
            actor_loss.backward()
            self.actor_optimizers[agent_id].step()

import random

def main():
    env = create_env()
    agent_num = 3
    maddpg = MADDPG(env, agent_num)

    max_episodes = 2000
    solved_reward = -15
    solved_repeat = 5
    ema = 0
    recent = []

    for episode in range(max_episodes):
        obs = env.reset()
        states = [o for o in obs]
        episode_transitions = [[] for _ in range(agent_num)]
        total_reward = 0

        for t in range(env._max_cycles):
            actions = maddpg.act_discrete_with_noise(states)
            obs_, rewards, dones, _ = env.step(actions)
            next_states = [o for o in obs_]
            for i in range(agent_num):
                trans = Transition(state=states[i],
                                   action=actions[i],
                                   reward=rewards[i],
                                   next_state=next_states[i],
                                   done=dones[i])
                episode_transitions[i].append(trans)
                total_reward += rewards[i]
            states = next_states

        maddpg.store_episodes(episode_transitions)
        for _ in range(t + 1):
            maddpg.update()

        ema = 0.9 * ema + 0.1 * total_reward
        recent.append(ema)
        if len(recent) > solved_repeat:
            recent.pop(0)
        if len(recent) == solved_repeat and min(recent) >= solved_reward:
            print(f"Solved after {episode+1} episodes!")
            break

if __name__ == "__main__":
    main()
