import unittest
import numpy as np
import random
import re
import time

import go
import utils

# Set board size to 9x9
go.set_board_size(9)

def load_board(string):
    """
    Convert a string representation of a Go board into a NumPy array.

    Parameters
    ----------
    string : str
        String containing board characters.

    Returns
    -------
    np.ndarray
        2D array of shape (board_size, board_size) with Go constants.
    """
    reverse_map = {
        'X': go.BLACK,
        'O': go.WHITE,
        '.': go.EMPTY,
        '#': go.PASS,
        'B': go.BLACK,
        'W': go.WHITE,
    }
    board_size = go.get_board_size()
    cleaned = re.sub(r'[^XOo.#BWw\s]', '', string)
    cleaned = cleaned.replace('\n', '').replace(' ', '')
    if len(cleaned) != board_size * board_size:
        raise ValueError(
            f"Board string length {len(cleaned)} does not match board size {board_size*board_size}"
        )
    board = np.empty((board_size, board_size), dtype=object)
    idx = 0
    for r in range(board_size):
        for c in range(board_size):
            ch = cleaned[idx]
            if ch.upper() not in reverse_map:
                raise ValueError(f"Invalid character '{ch}' at position ({r},{c})")
            board[r, c] = reverse_map[ch.upper()]
            idx += 1
    return board


class TestUtils(unittest.TestCase):
    def test_parse_sgf_coords(self):
        self.assertEqual(utils.parse_sgf_coords('aa'), (0, 0))
        self.assertEqual(utils.parse_sgf_coords('ad'), (0, 3))
        self.assertEqual(utils.parse_sgf_coords(''), None)
        self.assertRaises(ValueError, utils.parse_sgf_coords, 'zzz')

    def test_parse_kgs_coords(self):
        self.assertEqual(utils.parse_kgs_coords('A1'), (0, 0))
        self.assertEqual(utils.parse_kgs_coords('D4'), (3, 3))
        self.assertEqual(utils.parse_kgs_coords(''), None)
        self.assertRaises(ValueError, utils.parse_kgs_coords, '1A')

    def test_parse_pygtp_coords(self):
        self.assertEqual(utils.parse_pygtp_coords('A1'), (0, 0))
        self.assertEqual(utils.parse_pygtp_coords('D4'), (3, 3))
        self.assertEqual(utils.parse_pygtp_coords(''), None)
        self.assertRaises(ValueError, utils.parse_pygtp_coords, 'Z9')

    def test_flatten_unflatten(self):
        for r in range(9):
            for c in range(9):
                flat = utils.flatten_coords(r, c)
                r2, c2 = utils.unflatten_coords(flat)
                self.assertEqual((r, c), (r2, c2))

    def test_shuffler(self):
        random.seed(42)
        seq = list(range(10))
        utils.shuffler(seq)
        self.assertEqual(seq, [0, 4, 9, 3, 2, 5, 1, 8, 7, 6])

    def test_parse_game_result(self):
        self.assertEqual(utils.parse_game_result('B+3.5'), ('B', 3.5))
        self.assertEqual(utils.parse_game_result('W+T'), ('W', None))
        self.assertEqual(utils.parse_game_result(''), None)
        self.assertRaises(ValueError, utils.parse_game_result, 'C+2')


class GoPositionTestCase(unittest.TestCase):
    def setUp(self):
        self.start_time = time.time()

    def tearDown(self):
        elapsed = time.time() - self.start_time
        print(f"{self.id()} took {elapsed:.3f}s")

    def assertEqualNPArray(self, a, b, msg=None):
        try:
            np.testing.assert_array_equal(a, b)
        except AssertionError as e:
            self.fail(msg or str(e))

    def assertEqualLibTracker(self, tracker1, tracker2, msg=None):
        def normalize(tracker):
            groups = {}
            for gid, liberties in tracker.items():
                key = tuple(sorted(liberties))
                groups[key] = groups.get(key, 0) + 1
            return groups

        norm1 = normalize(tracker1)
        norm2 = normalize(tracker2)
        if norm1 != norm2:
            self.fail(msg or f"Liberty trackers differ: {norm1} != {norm2}")

    def assertEqualPositions(self, pos1, pos2, msg=None):
        if pos1.board.shape != pos2.board.shape:
            self.fail(msg or "Boards have different shapes")
        self.assertEqualNPArray(pos1.board, pos2.board, msg)

        self.assertEqualLibTracker(pos1.lib_tracker, pos2.lib_tracker, msg)

        if pos1.move_count != pos2.move_count:
            self.fail(msg or f"Move counts differ: {pos1.move_count} != {pos2.move_count}")

        if pos1.captured != pos2.captured:
            self.fail(msg or f"Captured stones differ: {pos1.captured} != {pos2.captured}")

        if pos1.ko != pos2.ko:
            self.fail(msg or f"Ko status differs: {pos1.ko} != {pos2.ko}")

        if pos1.recent_moves != pos2.recent_moves:
            self.fail(msg or f"Recent moves differ: {pos1.recent_moves} != {pos2.recent_moves}")

        if pos1.player_to_move != pos2.player_to_move:
            self.fail(msg or f"Player to move differs: {pos1.player_to_move} != {pos2.player_to_move}")

    def test_position_equality(self):
        board1 = load_board('X.' * 9 + 'O' * 81)
        board2 = load_board('X.' * 9 + 'O' * 81)
        pos1 = go.Position(board1)
        pos2 = go.Position(board2)
        self.assertEqualPositions(pos1, pos2)

    def test_position_inequality(self):
        board1 = load_board('X.' * 9 + 'O' * 81)
        board2 = load_board('O.' * 9 + 'X' * 81)
        pos1 = go.Position(board1)
        pos2 = go.Position(board2)
        with self.assertRaises(AssertionError):
            self.assertEqualPositions(pos1, pos2)


if __name__ == "__main__":
    unittest.main()