import os
import tempfile
import shutil
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import gymnasium as gym
import pytest
from machin.algorithms.td3 import TD3
from machin.utils.logging import default_logger

# Fixtures ------------------------------------------------------------

@pytest.fixture(scope="module")
def train_config():
    return {
        "env_name": "Pendulum-v0",
        "state_dim": 3,
        "action_dim": 1,
        "action_range": 2.0,
        "max_episodes": 1000,
        "max_steps": 200,
        "replay_buffer_size": 100000,
        "solved_reward": -400.0,
        "solved_repeat": 10,
    }

@pytest.fixture(scope="module")
def td3(train_config):
    state_dim = train_config["state_dim"]
    action_dim = train_config["action_dim"]
    action_range = train_config["action_range"]
    actor = nn.Sequential(
        nn.Linear(state_dim, 256),
        nn.ReLU(),
        nn.Linear(256, 256),
        nn.ReLU(),
        nn.Linear(256, action_dim),
        nn.Tanh(),
    )
    critic = nn.Sequential(
        nn.Linear(state_dim + action_dim, 256),
        nn.ReLU(),
        nn.Linear(256, 256),
        nn.ReLU(),
        nn.Linear(256, 1),
    )
    critic2 = nn.Sequential(
        nn.Linear(state_dim + action_dim, 256),
        nn.ReLU(),
        nn.Linear(256, 256),
        nn.ReLU(),
        nn.Linear(256, 1),
    )
    optimizer = optim.Adam(
        list(actor.parameters()) + list(critic.parameters()) + list(critic2.parameters()),
        lr=3e-4,
    )
    loss_fn = nn.MSELoss()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    agent = TD3(
        state_dim=state_dim,
        action_dim=action_dim,
        action_range=action_range,
        actor=actor,
        critic=critic,
        critic2=critic2,
        actor_optim=optimizer,
        critic_optim=optimizer,
        critic2_optim=optimizer,
        critic_loss_fn=loss_fn,
        critic2_loss_fn=loss_fn,
        buffer_capacity=train_config["replay_buffer_size"],
        device=device,
    )
    return agent

@pytest.fixture
def td3_vis(td3):
    viz_dir = tempfile.mkdtemp()
    td3.visualize_dir = viz_dir
    return td3

@pytest.fixture
def td3_lr(td3):
    return td3

@pytest.fixture
def td3_train(td3):
    return td3

# Tests -------------------------------------------------------------

def test__criticize(td3):
    state = torch.randn(1, td3.state_dim, device=td3.device)
    action = torch.randn(1, td3.action_dim, device=td3.device)
    with torch.no_grad():
        q1 = td3._criticize(state, action)
        q2 = td3._criticize2(state, action)
        q1_target = td3._criticize_target(state, action)
        q2_target = td3._criticize2_target(state, action)
    assert q1.shape == (1, 1)
    assert q2.shape == (1, 1)
    assert q1_target.shape == (1, 1)
    assert q2_target.shape == (1, 1)

def test_update(td3):
    # Populate replay buffer with dummy transitions
    for _ in range(10):
        state = torch.randn(td3.state_dim)
        action = torch.randn(td3.action_dim)
        next_state = torch.randn(td3.state_dim)
        reward = torch.tensor(0.0)
        done = torch.tensor(False)
        td3.replay_buffer.add(state, action, next_state, reward, done)
    # Perform updates
    td3.update(batch_size=5, update_policy=False, update_value=True, update_target=True)
    # No assertion needed; test that no exception occurs

def test_save_load(td3):
    with tempfile.TemporaryDirectory() as tmpdir:
        save_path = os.path.join(tmpdir, "td3.pth")
        td3.save(save_path, {"actor": td3.actor, "critic": td3.critic, "critic2": td3.critic2})
        # Load into a new agent
        new_agent = TD3(
            state_dim=td3.state_dim,
            action_dim=td3.action_dim,
            action_range=td3.action_range,
            actor=td3.actor,
            critic=td3.critic,
            critic2=td3.critic2,
            actor_optim=td3.actor_optim,
            critic_optim=td3.critic_optim,
            critic2_optim=td3.critic2_optim,
            critic_loss_fn=td3.critic_loss_fn,
            critic2_loss_fn=td3.critic2_loss_fn,
            buffer_capacity=td3.replay_buffer.capacity,
            device=td3.device,
        )
        new_agent.load(save_path, {"actor": new_agent.actor, "critic": new_agent.critic, "critic2": new_agent.critic2})
        # Compare parameters
        for p1, p2 in zip(td3.actor.parameters(), new_agent.actor.parameters()):
            assert torch.allclose(p1, p2)
        for p1, p2 in zip(td3.critic.parameters(), new_agent.critic.parameters()):
            assert torch.allclose(p1, p2)
        for p1, p2 in zip(td3.critic2.parameters(), new_agent.critic2.parameters()):
            assert torch.allclose(p1, p2)

def test_lr_scheduler(td3_lr):
    def custom_lr(step):
        return 3e-4 * (0.99 ** step)
    td3_lr.update_lr_scheduler(custom_lr)
    # Run a few steps to ensure scheduler updates optimizer lr
    for step in range(5):
        td3_lr.update_lr_scheduler(custom_lr, step=step)
        lr = td3_lr.actor_optim.param_groups[0]["lr"]
        expected = custom_lr(step)
        assert np.isclose(lr, expected, atol=1e-8)

def test_config_init():
    config = TD3.generate_config(
        env_name="Pendulum-v0",
        state_dim=3,
        action_dim=1,
        action_range=2.0,
        actor_hidden_sizes=[256, 256],
        critic_hidden_sizes=[256, 256],
        lr=3e-4,
        buffer_capacity=100000,
    )
    td3 = TD3(
        state_dim=config["state_dim"],
        action_dim=config["action_dim"],
        action_range=config["action_range"],
        actor=nn.Sequential(
            nn.Linear(config["state_dim"], config["actor_hidden_sizes"][0]),
            nn.ReLU(),
            nn.Linear(config["actor_hidden_sizes"][0], config["actor_hidden_sizes"][1]),
            nn.ReLU(),
            nn.Linear(config["actor_hidden_sizes"][1], config["action_dim"]),
            nn.Tanh(),
        ),
        critic=nn.Sequential(
            nn.Linear(config["state_dim"] + config["action_dim"], config["critic_hidden_sizes"][0]),
            nn.ReLU(),
            nn.Linear(config["critic_hidden_sizes"][0], config["critic_hidden_sizes"][1]),
            nn.ReLU(),
            nn.Linear(config["critic_hidden_sizes"][1], 1),
        ),
        critic2=nn.Sequential(
            nn.Linear(config["state_dim"] + config["action_dim"], config["critic_hidden_sizes"][0]),
            nn.ReLU(),
            nn.Linear(config["critic_hidden_sizes"][0], config["critic_hidden_sizes"][1]),
            nn.ReLU(),
            nn.Linear(config["critic_hidden_sizes"][1], 1),
        ),
        actor_optim=optim.Adam([], lr=config["lr"]),
        critic_optim=optim.Adam([], lr=config["lr"]),
        critic2_optim=optim.Adam([], lr=config["lr"]),
        critic_loss_fn=nn.MSELoss(),
        critic2_loss_fn=nn.MSELoss(),
        buffer_capacity=config["buffer_capacity"],
        device=torch.device("cpu"),
    )
    # Store dummy data
    state = torch.randn(3)
    action = torch.randn(1)
    next_state = torch.randn(3)
    reward = torch.tensor(0.0)
    done = torch.tensor(False)
    td3.replay_buffer.add(state, action, next_state, reward, done)
    assert len(td3.replay_buffer) == 1

def test_full_train(td3_train, train_config):
    env = gym.make(train_config["env_name"], render_mode=None)
    env.seed(0)
    torch.manual_seed(0)
    np.random.seed(0)
    max_episodes = train_config["max_episodes"]
    max_steps = train_config["max_steps"]
    solved_reward = train_config["solved_reward"]
    solved_repeat = train_config["solved_repeat"]
    noise_interval = 5
    smooth_rewards = []
    solved_count = 0
    for episode in range(1, max_episodes + 1):
        state, _ = env.reset(seed=0)
        total_reward = 0.0
        for step in range(max_steps):
            if step % noise_interval == 0:
                action = td3_train.act_with_noise(state, noise_std=0.1)
            else:
                action = td3_train.act(state)
            next_state, reward, terminated, truncated, _ = env.step(action.cpu().numpy())
            done = terminated or truncated
            td3_train.replay_buffer.add(state, action, next_state, torch.tensor(reward), torch.tensor(done))
            state = next_state
            total_reward += reward
            if done:
                break
        smooth_rewards.append(total_reward)
        if len(smooth_rewards) > 10:
            smooth_rewards.pop(0)
        avg_reward = np.mean(smooth_rewards)
        if avg_reward > solved_reward:
            solved_count += 1
        else:
            solved_count = 0
        if solved_count >= solved_repeat:
            default_logger.info(f"Solved at episode {episode}")
            break
        if episode % noise_interval == 0:
            default_logger.info(f"Episode {episode}: Total Reward {total_reward:.2f}")
        if episode > 100:
            td3_train.update(batch_size=64, update_policy=True, update_value=True, update_target=True)
    env.close()
    assert avg_reward > solved_reward or episode == max_episodes
    if avg_reward <= solved_reward and episode == max_episodes:
        pytest.fail("TD3 Training failed.")