import numpy as np
from sklearn.tree import DecisionTreeRegressor


class RandomForestRegressor:
    def __init__(
        self,
        n_estimators: int = 100,
        max_depth: int | None = None,
        min_samples_split: int = 2,
        min_samples_leaf: int = 1,
        random_state: int | None = None,
    ):
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.min_samples_leaf = min_samples_leaf
        self.random_state = random_state
        self.models = []

    def fit(self, X: np.ndarray, y: np.ndarray) -> None:
        n_samples, n_features = X.shape
        max_features = max(1, int(np.floor(n_features / 3)))
        rng = np.random.default_rng(self.random_state)

        self.models = []
        for _ in range(self.n_estimators):
            indices = rng.choice(n_samples, size=n_samples, replace=True)
            X_boot = X[indices]
            y_boot = y[indices]

            tree = DecisionTreeRegressor(
                max_depth=self.max_depth,
                min_samples_split=self.min_samples_split,
                min_samples_leaf=self.min_samples_leaf,
                max_features=max_features,
                splitter="random",
                random_state=rng.integers(0, 1_000_000_000),
            )
            tree.fit(X_boot, y_boot)
            self.models.append(tree)

    def predict(self, X: np.ndarray) -> np.ndarray:
        preds = np.column_stack([tree.predict(X) for tree in self.models])
        return preds.mean(axis=1)