import numpy as np
from sklearn.metrics import mean_squared_error


class mean_regr:
    def __init__(self):
        self.y_mean = None

    def fit(self, X, y):
        self.y_mean = sum(y) / len(y)

    def predict(self, X):
        return np.full(len(X), self.y_mean)

    def loss(self, X, y, y_pred):
        return mean_squared_error(y, y_pred)