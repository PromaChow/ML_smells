import numpy as np
import pybullet as p
from mjcf_based_robot import MJCFBasedRobot


class InvertedDoublePendulum(MJCFBasedRobot):
    def __init__(self):
        super().__init__(
            mjcf_file="inverted_double_pendulum.xml",
            body_name="cart",
            action_dim=1,
            observation_dim=11,
        )
        self.bullet_client = None
        self.slider_index = None
        self.j1_index = None
        self.j2_index = None
        self.cart_id = None

    def robot_specific_reset(self):
        # Initialize physics client
        self.bullet_client = p.connect(p.DIRECT)

        # Retrieve body and joint indices
        self.cart_id = self.model.get_body("cart").id
        self.slider_index = self.model.get_joint("slider").index
        self.j1_index = self.model.get_joint("j1").index
        self.j2_index = self.model.get_joint("j2").index

        # Random initial joint positions
        init_theta = np.random.uniform(-0.1, 0.1)
        init_gamma = np.random.uniform(-0.1, 0.1)

        # Reset joint states
        p.resetJointState(self.cart_id, self.j1_index, init_theta)
        p.resetJointState(self.cart_id, self.j2_index, init_gamma)

        # Zero motor torques
        p.setJointMotorControl2(
            bodyIndex=self.cart_id,
            jointIndex=self.j1_index,
            controlMode=p.TORQUE_CONTROL,
            force=0.0,
        )
        p.setJointMotorControl2(
            bodyIndex=self.cart_id,
            jointIndex=self.j2_index,
            controlMode=p.TORQUE_CONTROL,
            force=0.0,
        )

    def apply_action(self, action):
        if not np.all(np.isfinite(action)):
            raise ValueError("Non-finite action values detected.")
        torque = np.clip(action[0], -1.0, 1.0) * 200.0
        p.setJointMotorControl2(
            bodyIndex=self.cart_id,
            jointIndex=self.slider_index,
            controlMode=p.TORQUE_CONTROL,
            force=torque,
        )

    def calc_state(self):
        # Cart position and velocity
        cart_pos, _ = p.getBasePositionAndOrientation(self.cart_id)
        cart_vel, _ = p.getBaseVelocity(self.cart_id)
        x = cart_pos[0]
        vx = cart_vel[0]

        # Joint angles and velocities
        theta, theta_dot, _, _ = p.getJointState(self.cart_id, self.j1_index)
        gamma, gamma_dot, _, _ = p.getJointState(self.cart_id, self.j2_index)

        # Position and velocity arrays
        qpos = np.array([x, theta, gamma])
        qvel = np.array([vx, theta_dot, gamma_dot])
        qfrc_constraint = np.zeros(3)

        # Observation construction
        obs = np.concatenate(
            [
                qpos[:1],
                np.sin(qpos[1:]),
                np.cos(qpos[1:]),
                np.clip(qvel, -10.0, 10.0),
                np.clip(qfrc_constraint, -10.0, 10.0),
            ]
        )
        return obs.reshape(-1)  # Ensure shape (11,)  