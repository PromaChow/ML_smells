import os
import json
import tempfile
import shutil
import pickle
import numpy as np
from typing import Iterable, List, Union, Optional, Dict, Tuple

try:
    from gensim.models import Word2Vec
except Exception:
    raise ImportError("Gensim is required for GensimFastText")

try:
    import fasttext
except Exception:
    raise ImportError("fasttext is required for FastText classifier")


class BaseClassifier:
    def __init__(self):
        self.label_set: List[str] = []
        self.label2index: Dict[str, int] = {}

    def build_label_info(self, y: Iterable[Union[str, int, Iterable[Union[str, int]]]]):
        labels = set()
        for target in y:
            if isinstance(target, (list, set, tuple)):
                labels.update(str(l) for l in target)
            else:
                labels.add(str(target))
        self.label_set = sorted(labels)
        self.label2index = {label: idx for idx, label in enumerate(self.label_set)}

    def _data_iter(
        self,
        documents: Iterable[List[str]],
        y: Iterable[Union[str, int, Iterable[Union[str, int]]]]
    ) -> Iterable[Tuple[List[str], List[str]]]:
        for doc, target in zip(documents, y):
            if isinstance(target, (list, set, tuple)):
                labels = [f"__label__{str(t)}" for t in target]
            else:
                labels = [f"__label__{str(target)}"]
            yield doc + labels, labels

    def save(self, path: str):
        raise NotImplementedError

    def load(self, path: str):
        raise NotImplementedError


class GensimFastText(BaseClassifier):
    def __init__(
        self,
        size: int = 100,
        alpha: float = 0.025,
        min_count: int = 5,
        workers: int = 4,
        pre_trained: Optional[Word2Vec] = None,
        **kwargs
    ):
        super().__init__()
        self.size = size
        self.alpha = alpha
        self.min_count = min_count
        self.workers = workers
        self.kwargs = kwargs
        if pre_trained is not None:
            self.model = pre_trained
            self.build_label_info(pre_trained.wv.key_to_index.keys())
        else:
            self.model = Word2Vec(
                vector_size=self.size,
                alpha=self.alpha,
                min_count=self.min_count,
                workers=self.workers,
                **self.kwargs
            )

    def fit(self, documents: Iterable[List[str]], y: Iterable[Union[str, int, Iterable[Union[str, int]]]]):
        sentences = [list(pair[0]) for pair in self._data_iter(documents, y)]
        self.model.build_vocab(sentences)
        self.model.train(
            sentences,
            total_examples=len(sentences),
            epochs=self.model.epochs
        )
        self.build_label_info(y)
        return self

    def _document_vector(self, tokens: List[str]) -> np.ndarray:
        return self.model.infer_vector(tokens, epochs=10)

    def _label_vector(self, label: str) -> np.ndarray:
        key = f"__label__{label}"
        if key in self.model.wv:
            return self.model.wv[key]
        else:
            return np.zeros(self.size)

    def predict(self, documents: Iterable[List[str]]) -> List[str]:
        preds = []
        for doc in documents:
            vec = self._document_vector(doc)
            sims = [np.dot(vec, self._label_vector(l)) for l in self.label_set]
            best_idx = np.argmax(sims)
            preds.append(self.label_set[best_idx])
        return preds

    def predict_proba(self, documents: Iterable[List[str]]) -> List[List[Tuple[str, float]]]:
        probs_list = []
        for doc in documents:
            vec = self._document_vector(doc)
            sims = [np.dot(vec, self._label_vector(l)) for l in self.label_set]
            sims = np.maximum(sims, 0)
            total = np.sum(sims)
            if total == 0:
                probs = [0.0] * len(self.label_set)
            else:
                probs = sims / total
            probs_list.append(list(zip(self.label_set, probs)))
        return probs_list

    def save(self, path: str):
        self.model.save(path + ".CLF")

    def load(self, path: str):
        self.model = Word2Vec.load(path + ".CLF")
        self.build_label_info(self.model.wv.key_to_index.keys())


class FastTextClassifier(BaseClassifier):
    def __init__(
        self,
        lr: float = 0.1,
        dim: int = 100,
        epoch: int = 5,
        loss: str = "softmax",
        min_count: int = 1,
        **kwargs
    ):
        super().__init__()
        self.lr = lr
        self.dim = dim
        self.epoch = epoch
        self.loss = loss
        self.min_count = min_count
        self.kwargs = kwargs
        self._tmp_dir = tempfile.mkdtemp()
        self._train_file = os.path.join(self._tmp_dir, "train.txt")
        self._classifier: Optional[fasttext.FastText] = None

    def _write_train_file(self, documents: Iterable[List[str]], y: Iterable[Union[str, int, Iterable[Union[str, int]]]]):
        with open(self._train_file, "w", encoding="utf-8") as f:
            for doc, target in zip(documents, y):
                if isinstance(target, (list, set, tuple)):
                    labels = [f"__label__{str(t)}" for t in target]
                else:
                    labels = [f"__label__{str(target)}"]
                line = " ".join(labels + doc)
                f.write(line + "\n")

    def fit(self, documents: Iterable[List[str]], y: Iterable[Union[str, int, Iterable[Union[str, int]]]]):
        self._write_train_file(documents, y)
        self._classifier = fasttext.train_supervised(
            input=self._train_file,
            lr=self.lr,
            dim=self.dim,
            epoch=self.epoch,
            loss=self.loss,
            minCount=self.min_count,
            **self.kwargs
        )
        self.build_label_info(y)
        return self

    def predict(self, documents: Iterable[List[str]]) -> List[str]:
        preds = []
        for doc in documents:
            labels, probs = self._classifier.predict(" ".join(doc), k=1)
            label = labels[0].replace("__label__", "")
            preds.append(label)
        return preds

    def predict_proba(self, documents: Iterable[List[str]]) -> List[List[Tuple[str, float]]]:
        probs_list = []
        for doc in documents:
            labels, probs = self._classifier.predict_proba(" ".join(doc), k=len(self.label_set))
            probs_clean = [(lbl.replace("__label__", ""), prob) for lbl, prob in zip(labels, probs)]
            probs_list.append(probs_clean)
        return probs_list

    def save(self, path: str):
        if self._classifier is not None:
            self._classifier.save_model(path + ".bin")

    def load(self, path: str):
        self._classifier = fasttext.load_model(path + ".bin")
        self.build_label_info(self._classifier.get_labels())

    def close(self):
        if os.path.exists(self._tmp_dir):
            shutil.rmtree(self._tmp_dir)

    def __del__(self):
        self.close()
