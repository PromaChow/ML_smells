import pandas as pd

def main():
    df = pd.read_csv("SalaryGender.csv")
    male_phd = df[(df["Gender"] == 1) & (df["PhD"] == 1)]
    female_phd = df[(df["Gender"] == 0) & (df["PhD"] == 1)]
    print(f"Number of men with a PhD: {male_phd.shape[0]}")
    print(f"Number of women with a PhD: {female_phd.shape[0]}")

if __name__ == "__main__":
    main()