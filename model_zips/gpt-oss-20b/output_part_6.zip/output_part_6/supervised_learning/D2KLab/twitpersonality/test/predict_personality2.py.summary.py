import re
from pathlib import Path
import numpy as np
import joblib
from sklearn.feature_extraction.text import CountVectorizer

# Custom modules (assumed to be available in the PYTHONPATH)
import datasetUtils
import embeddings

def preprocess_tweets(raw_tweets):
    """Apply preprocessing rules to a list of raw tweet texts."""
    processed = []
    url_http_pattern = re.compile(r"http\S+")
    url_no_http_pattern = re.compile(r"(?:www\.|[a-zA-Z0-9]+\.[a-zA-Z]{2,})(?:[^\s]*)")
    mention_pattern = re.compile(r"@\w+")
    for tweet in raw_tweets:
        tweet = tweet.strip()
        if tweet.startswith("RT"):
            continue
        tweet = url_http_pattern.sub("", tweet)
        tweet = url_no_http_pattern.sub("", tweet)
        tweet = mention_pattern.sub("", tweet)
        if tweet:
            processed.append(tweet)
    return processed

def load_usernames():
    """Prompt user for a username or a file with usernames."""
    user_input = input("Enter a username (prefixed with @) or a filename: ").strip()
    usernames = []

    if user_input.startswith("@"):
        usernames.append(user_input[1:].strip())
    else:
        file_path = Path(user_input)
        if file_path.is_file() and file_path.stat().st_size > 0:
            with file_path.open("r", encoding="utf-8") as f:
                for line in f:
                    name = line.strip()
                    if name and not name.startswith("#"):
                        usernames.append(name)
        else:
            print(f"File '{user_input}' not found or empty. No usernames loaded.")
    return usernames

def main():
    tweet_threshold = 3
    embedding_path = Path("dataset.vec")
    if not embedding_path.is_file():
        print(f"Embedding file '{embedding_path}' not found.")
        return

    print("Loading FastText embeddings...")
    word_dict = datasetUtils.parseFastText(embedding_path)

    usernames = load_usernames()
    if not usernames:
        print("No usernames to process.")
        return

    output_lines = []

    for username in usernames:
        tweet_file = Path("Data") / username / f"{username}_tweets.txt"
        if not tweet_file.is_file():
            print(f"Tweet file for user '{username}' not found. Skipping.")
            continue

        with tweet_file.open("r", encoding="utf-8") as f:
            raw_tweets = f.readlines()

        processed_tweets = preprocess_tweets(raw_tweets)

        if not processed_tweets:
            print(f"No valid tweets after preprocessing for user '{username}'. Skipping.")
            continue

        embeddings_matrix = embeddings.transformTextForTesting(word_dict, processed_tweets, tweet_threshold)
        if embeddings_matrix is None or len(embeddings_matrix) == 0:
            print(f"No embeddings generated for user '{username}'. Skipping.")
            continue

        mean_vector = np.mean(embeddings_matrix, axis=0).reshape(1, -1)

        trait_scores = {}
        traits = ["O", "C", "E", "A", "N"]
        for trait in traits:
            model_path = Path("Models") / f"SVM_fasttext_conc_{trait}.pkl"
            if not model_path.is_file():
                print(f"Model file '{model_path}' not found. Skipping trait '{trait}'.")
                trait_scores[trait] = None
                continue
            model = joblib.load(model_path)
            pred = model.predict(mean_vector)[0]
            trait_scores[trait] = round(float(pred), 5)

        # Determine Jungian type
        if trait_scores["E"] is None or trait_scores["O"] is None or trait_scores["A"] is None or trait_scores["C"] is None:
            jungian_type = "N/A"
        else:
            jungian_type = (
                ("E" if trait_scores["E"] > 3 else "I") +
                ("N" if trait_scores["O"] > 3 else "S") +
                ("F" if trait_scores["A"] > 3 else "T") +
                ("J" if trait_scores["C"] > 3 else "P")
            )

        line = f"{username}," + ",".join(str(trait_scores[tr]) for tr in ["O", "C", "E", "A", "N"]) + f",{jungian_type}"
        output_lines.append(line)

    output_file = Path("personality_predictions2.csv")
    with output_file.open("w", encoding="utf-8") as f:
        for line in output_lines:
            f.write(line + "\n")

    print(f"Results written to '{output_file}'.")

if __name__ == "__main__":
    main()
