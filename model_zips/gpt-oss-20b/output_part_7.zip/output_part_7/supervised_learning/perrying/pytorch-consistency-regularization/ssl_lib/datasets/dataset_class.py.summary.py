import torch
import numpy as np
from torch.utils.data import Dataset
from typing import Callable, Optional

def _identity(x: torch.Tensor) -> torch.Tensor:
    return x

class LabeledDataset(Dataset):
    def __init__(self, dataset: dict, transform: Optional[Callable[[torch.Tensor], torch.Tensor]] = None):
        self.dataset = dataset
        self.transform = transform

    def __len__(self) -> int:
        return len(self.dataset["images"])

    def __getitem__(self, idx: int):
        img_np = np.array(self.dataset["images"][idx])
        img = torch.from_numpy(img_np).float().permute(2, 0, 1) / 255.0
        label = int(self.dataset["labels"][idx])

        if self.transform is not None:
            img = self.transform(img)

        return img, label

class UnlabeledDataset(Dataset):
    def __init__(
        self,
        dataset: dict,
        weak_augmentation: Optional[Callable[[torch.Tensor], torch.Tensor]] = None,
        strong_augmentation: Optional[Callable[[torch.Tensor], torch.Tensor]] = None,
    ):
        self.dataset = dataset
        self.weak_augmentation = weak_augmentation if weak_augmentation is not None else _identity
        self.strong_augmentation = (
            strong_augmentation if strong_augmentation is not None else self.weak_augmentation
        )

    def __len__(self) -> int:
        return len(self.dataset["images"])

    def __getitem__(self, idx: int):
        img_np = np.array(self.dataset["images"][idx])
        img = torch.from_numpy(img_np).float().permute(2, 0, 1) / 255.0
        label = int(self.dataset["labels"][idx])

        w_aug_image = self.weak_augmentation(img)
        s_aug_image = self.strong_augmentation(img)

        return w_aug_image, s_aug_image, label

if __name__ == "__main__":
    # Example usage with dummy data
    dummy_images = [np.random.randint(0, 256, (32, 32, 3), dtype=np.uint8) for _ in range(10)]
    dummy_labels = [i % 5 for i in range(10)]
    dataset_dict = {"images": dummy_images, "labels": dummy_labels}

    labeled = LabeledDataset(dataset_dict, transform=None)
    unlabeled = UnlabeledDataset(dataset_dict)

    for i in range(len(labeled)):
        img, lbl = labeled[i]
        w_img, s_img, lbl_u = unlabeled[i]
        print(f"Index {i}: lbl={lbl}, lbl_u={lbl_u}, img_shape={img.shape}, w_img_shape={w_img.shape}")
