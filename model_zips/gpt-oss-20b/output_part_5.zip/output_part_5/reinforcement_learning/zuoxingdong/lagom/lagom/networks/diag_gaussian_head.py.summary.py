import torch
import torch.nn as nn
import torch.distributions as D


class DiagonalGaussianActionDist(nn.Module):
    def __init__(
        self,
        feature_dim: int,
        action_dim: int,
        std0: float,
        device: torch.device | str = "cpu",
    ):
        super().__init__()
        self.mean_head = nn.Linear(feature_dim, action_dim)
        nn.init.orthogonal_(self.mean_head.weight, gain=0.01)
        nn.init.zeros_(self.mean_head.bias)

        init_logstd = torch.log(torch.tensor(std0, dtype=torch.float32, device=device))
        self.logstd_head = nn.Parameter(
            torch.full((action_dim,), init_logstd, dtype=torch.float32, device=device)
        )

        self.to(device)

    def forward(self, x: torch.Tensor) -> D.Independent:
        mean = self.mean_head(x)
        logstd = self.logstd_head.expand_as(mean)
        std = logstd.exp()
        dist = D.Normal(mean, std)
        return D.Independent(dist, 1)