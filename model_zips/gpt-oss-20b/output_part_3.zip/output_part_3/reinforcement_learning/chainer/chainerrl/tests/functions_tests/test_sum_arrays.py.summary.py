import numpy as np
import chainer
import chainer.cuda
from chainer.testing import testing, gradient_check, parameterized
import chainerrl.functions as cf


shapes = [
    (1,),
    (2, 3),
    (3, 2, 4),
    (4,),
    (5, 1, 2),
]

PARAMS = [(b, n, s) for b in (1, 3) for n in (1, 2, 7) for s in shapes]


@parameterized.expand(PARAMS)
class TestSumArrays(testing.parameterized.TestCase):
    def __init__(self, *args):
        super(TestSumArrays, self).__init__(*args)
        self.batchsize, self.n, self.shape = args

    def setUp(self):
        self.batch_size = 5
        xs_shape = (self.batchsize,) + self.shape
        self.xs = [np.random.randn(*xs_shape).astype(np.float32) for _ in range(self.n)]
        self.gy = np.random.randn(*xs_shape).astype(np.float32)

    def check_forward(self, xs):
        y = cf.sum_arrays(xs)
        y_cpu = y.array if hasattr(y, 'array') else y
        expected = np.sum(np.array(xs), axis=0)
        gradient_check.assert_allclose(self, y_cpu, expected)

    def test_forward_cpu(self):
        self.check_forward(self.xs)

    def test_forward_gpu(self):
        xs_gpu = [chainer.cuda.to_gpu(x) for x in self.xs]
        self.check_forward(xs_gpu)

    def test_backward_cpu(self):
        grad_func = cf.SumArrays()
        gradient_check.check_backward(
            self,
            grad_func,
            self.xs,
            gy=self.gy,
            eps=1e-2,
            rtol=1e-2,
        )

    def test_backward_gpu(self):
        xs_gpu = [chainer.cuda.to_gpu(x) for x in self.xs]
        gy_gpu = chainer.cuda.to_gpu(self.gy)
        grad_func = cf.SumArrays()
        gradient_check.check_backward(
            self,
            grad_func,
            xs_gpu,
            gy=gy_gpu,
            eps=1e-2,
            rtol=1e-2,
        )


if __name__ == "__main__":
    testing.run_module(__name__, __file__)