import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

warnings.filterwarnings("ignore")


def distribution(df: pd.DataFrame, transformed: bool = False) -> None:
    """Visualize the distribution of 'capital-gain' and 'capital-loss'."""
    fig, axes = plt.subplots(1, 2, figsize=(12, 5), tight_layout=True)

    bins = 25
    color = "#00A0A0"

    # Capital Gain
    ax = axes[0]
    ax.hist(df["capital-gain"], bins=bins, color=color, edgecolor="black")
    ax.set_xlabel("Capital Gain")
    ax.set_ylabel("Frequency")
    ax.set_title(
        "Log-Transformed Capital Gain Distribution"
        if transformed
        else "Capital Gain Distribution"
    )

    # Capital Loss
    ax = axes[1]
    ax.hist(df["capital-loss"], bins=bins, color=color, edgecolor="black")
    ax.set_xlabel("Capital Loss")
    ax.set_ylabel("Frequency")
    ax.set_title(
        "Log-Transformed Capital Loss Distribution"
        if transformed
        else "Capital Loss Distribution"
    )

    plt.show()


def evaluate(
    models: list[str],
    training_sizes: list[str],
    training_time: np.ndarray,
    prediction_time: np.ndarray,
    accuracy: np.ndarray,
    f1_score: np.ndarray,
    baseline_acc: float = 0.5,
    baseline_f1: float = 0.5,
) -> None:
    """
    Compare training/prediction time, accuracy, and F1 score across models.

    Parameters
    ----------
    models : list of str
        Names of the supervised learning models.
    training_sizes : list of str
        Labels for training set sizes (e.g., ['1%', '10%', '100%']).
    training_time : array-like of shape (n_models, n_sizes)
        Training times for each model and size.
    prediction_time : array-like of shape (n_models, n_sizes)
        Prediction times for each model and size.
    accuracy : array-like of shape (n_models, n_sizes)
        Accuracy scores for each model and size.
    f1_score : array-like of shape (n_models, n_sizes)
        F1 scores for each model and size.
    baseline_acc : float
        Baseline accuracy for naive predictor.
    baseline_f1 : float
        Baseline F1 for naive predictor.
    """
    metrics = ["Training Time", "Prediction Time", "Accuracy", "F1 Score"]
    fig, axes = plt.subplots(2, 3, figsize=(18, 10), tight_layout=True)

    colors = ["#1f77b4", "#ff7f0e", "#2ca02c"]

    for idx, metric in enumerate(metrics):
        ax = axes[idx // 3, idx % 3]
        x = np.arange(len(training_sizes))
        width = 0.25

        for i, model in enumerate(models):
            if metric == "Training Time":
                values = training_time[i]
            elif metric == "Prediction Time":
                values = prediction_time[i]
            elif metric == "Accuracy":
                values = accuracy[i]
            else:  # F1 Score
                values = f1_score[i]

            ax.bar(
                x + i * width,
                values,
                width=width,
                label=model,
                color=colors[i],
            )

        ax.set_xticks(x + width)
        ax.set_xticklabels(training_sizes)
        ax.set_ylabel(metric)
        ax.set_title(metric + " by Training Size")

        if metric in ("Accuracy", "F1 Score"):
            baseline = baseline_acc if metric == "Accuracy" else baseline_f1
            ax.axhline(baseline, color="gray", linestyle="--", linewidth=1)
            ax.set_ylim(0, 1.05)

    # Legend
    axes[1, 2].legend(handles=[plt.Rectangle((0, 0), 1, 1, color=c) for c in colors],
                      labels=models, loc="center")
    axes[1, 2].axis("off")

    fig.suptitle("Model Performance Comparison Across Training Sizes", fontsize=16)
    plt.show()


def feature_plot(importances: pd.Series) -> None:
    """Visualize the top five feature importances and cumulative weights."""
    sorted_imp = importances.sort_values(ascending=False)
    top5 = sorted_imp.head(5)
    features = top5.index.tolist()
    values = top5.values

    cumulative = np.cumsum(values)

    fig, ax = plt.subplots(figsize=(10, 6), tight_layout=True)

    x = np.arange(len(features))
    width = 0.4

    ax.bar(
        x,
        values,
        width=width,
        label="Individual Weight",
        color="#4c72b0",
    )
    ax.bar(
        x,
        cumulative,
        width=width,
        label="Cumulative Weight",
        color="#dd8452",
        alpha=0.7,
    )

    ax.set_xticks(x)
    ax.set_xticklabels(features, rotation=45, ha="right")
    ax.set_ylabel("Weight")
    ax.set_title("Top 5 Feature Importances")
    ax.legend()

    plt.show()
```