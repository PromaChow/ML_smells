import os
import random
from typing import Tuple

import chainer
import numpy as np


def set_random_seed(seed: int, gpus: Tuple[int, ...]) -> None:
    """
    Seed all random number generators used by ChainerRL.

    Parameters
    ----------
    seed : int
        The seed value to use for reproducibility.
    gpus : tuple[int, ...]
        GPU device IDs to seed. Negative IDs are ignored.
    """
    # 1. Python's built-in random module
    random.seed(seed)

    # 2. NumPy random generator
    np.random.seed(seed)

    # 3. GPU-specific initialization
    for gpu_id in gpus:
        if gpu_id < 0:
            continue
        dev = chainer.cuda.get_device_from_id(gpu_id)
        with dev:
            chainer.cuda.cupy.random.seed(seed)

    # 4. Environment variable for Chainer
    os.environ["CHAINER_SEED"] = str(seed)