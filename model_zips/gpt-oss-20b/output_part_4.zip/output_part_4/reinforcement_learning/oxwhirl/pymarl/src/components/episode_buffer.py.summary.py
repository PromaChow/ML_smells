import torch
from typing import Dict, Any, Tuple, Union, List, Callable, Optional

TensorDict = Dict[str, torch.Tensor]
Scheme = Dict[str, Dict[str, Any]]
Groups = Dict[str, List[str]]


class EpisodeBatch:
    def __init__(
        self,
        scheme: Scheme,
        groups: Groups,
        batch_size: int,
        max_seq_length: int,
        data: Optional[Dict[str, Any]] = None,
        preprocess: Optional[Dict[str, Callable[[torch.Tensor], torch.Tensor]]] = None,
    ):
        self.scheme = scheme
        self.groups = groups
        self.batch_size = batch_size
        self.max_seq_length = max_seq_length
        self.preprocess = preprocess or {}

        # Ensure "filled" is part of the scheme
        if "filled" not in self.scheme:
            self.scheme["filled"] = {"shape": (), "dtype": torch.bool, "episode_const": False}

        if data is None:
            self.transition_data, self.episode_data = self._setup_data()
        else:
            # data should contain tensors already in correct shape
            self.transition_data = data.get("transition", {})
            self.episode_data = data.get("episode", {})

    def _setup_data(self) -> Tuple[TensorDict, TensorDict]:
        transition_data: TensorDict = {}
        episode_data: TensorDict = {}
        for key, attr in self.scheme.items():
            shape = attr["shape"]
            dtype = attr["dtype"]
            episode_const = attr["episode_const"]
            if episode_const:
                tensor_shape = (self.batch_size, *shape)
                episode_data[key] = torch.zeros(tensor_shape, dtype=dtype)
            else:
                tensor_shape = (self.batch_size, self.max_seq_length, *shape)
                transition_data[key] = torch.zeros(tensor_shape, dtype=dtype)
        return transition_data, episode_data

    def extend(self, new_data: Optional[Dict[str, Any]] = None) -> None:
        # Re-setup data to include any new keys
        transition_data, episode_data = self._setup_data()
        self.transition_data.update(transition_data)
        self.episode_data.update(episode_data)

    def to(self, device: torch.device) -> None:
        for tensor in self.transition_data.values():
            tensor.to(device)
        for tensor in self.episode_data.values():
            tensor.to(device)

    def update(
        self,
        data: Dict[str, torch.Tensor],
        bs: Union[int, slice, torch.Tensor] = slice(None),
        ts: Union[int, slice, torch.Tensor] = slice(None),
    ) -> None:
        bs = self._parse_slices(bs, self.batch_size)
        ts = self._parse_slices(ts, self.max_seq_length)

        for key, value in data.items():
            if key in self.preprocess:
                value = self.preprocess[key](value)

            if key in self.transition_data:
                target = self.transition_data[key]
            elif key in self.episode_data:
                target = self.episode_data[key]
            else:
                raise KeyError(f"Unknown key {key} in update")

            self._check_safe_view(target[bs, ts] if key in self.transition_data else target[bs], value)
            if key in self.transition_data:
                target[bs, ts].copy_(value)
            else:
                target[bs].copy_(value)

        # Mark filled
        if "filled" in self.transition_data:
            self.transition_data["filled"][bs, ts] = True

    def _check_safe_view(self, target: torch.Tensor, source: torch.Tensor) -> None:
        if target.shape != source.shape:
            raise ValueError(f"Shape mismatch: target {target.shape} vs source {source.shape}")

    def __getitem__(self, key: Union[str, Tuple[str, ...], slice]) -> Union[torch.Tensor, "EpisodeBatch"]:
        if isinstance(key, str):
            if key in self.transition_data:
                return self.transition_data[key]
            if key in self.episode_data:
                return self.episode_data[key]
            raise KeyError(f"Key {key} not found")
        if isinstance(key, tuple):
            return EpisodeBatch(
                scheme={k: self.scheme[k] for k in key},
                groups={k: self.groups[k] for k in key},
                batch_size=self.batch_size,
                max_seq_length=self.max_seq_length,
                data={
                    "transition": {k: self.transition_data[k] for k in key if k in self.transition_data},
                    "episode": {k: self.episode_data[k] for k in key if k in self.episode_data},
                },
                preprocess={k: self.preprocess[k] for k in key if k in self.preprocess},
            )
        if isinstance(key, slice):
            bs = self._parse_slices(key, self.batch_size)
            return EpisodeBatch(
                scheme=self.scheme,
                groups=self.groups,
                batch_size=len(bs.indices if isinstance(bs, slice) else bs),
                max_seq_length=self.max_seq_length,
                data={
                    "transition": {k: v[bs] for k, v in self.transition_data.items()},
                    "episode": {k: v[bs] for k, v in self.episode_data.items()},
                },
                preprocess=self.preprocess,
            )
        raise TypeError("Unsupported key type")

    def _parse_slices(
        self,
        key: Union[int, slice, torch.Tensor],
        length: int,
    ) -> Union[slice, torch.Tensor]:
        if isinstance(key, int):
            return slice(key, key + 1)
        if isinstance(key, slice):
            return key
        if isinstance(key, torch.Tensor):
            return key
        raise TypeError("Invalid slice key")

    def max_t_filled(self) -> torch.Tensor:
        filled = self.transition_data["filled"]
        # For each batch, find last filled index
        t_filled = filled.cumsum(-1).max(-1).values
        return t_filled

    def __repr__(self) -> str:
        keys = list(self.scheme.keys())
        return (
            f"<EpisodeBatch batch_size={self.batch_size} "
            f"max_seq_length={self.max_seq_length} keys={keys}>"
        )


class ReplayBuffer(EpisodeBatch):
    def __init__(
        self,
        scheme: Scheme,
        groups: Groups,
        buffer_size: int,
        max_seq_length: int,
        preprocess: Optional[Dict[str, Callable[[torch.Tensor], torch.Tensor]]] = None,
    ):
        # Create storage with buffer capacity
        self.capacity = buffer_size
        self.counter = 0
        self.idx = 0
        self.scheme = scheme
        self.groups = groups
        self.max_seq_length = max_seq_length
        self.preprocess = preprocess or {}

        if "filled" not in self.scheme:
            self.scheme["filled"] = {"shape": (), "dtype": torch.bool, "episode_const": False}

        # Allocate storage tensors
        self.transition_data: TensorDict = {}
        self.episode_data: TensorDict = {}
        for key, attr in self.scheme.items():
            shape = attr["shape"]
            dtype = attr["dtype"]
            episode_const = attr["episode_const"]
            if episode_const:
                tensor_shape = (self.capacity, *shape)
                self.episode_data[key] = torch.zeros(tensor_shape, dtype=dtype)
            else:
                tensor_shape = (self.capacity, self.max_seq_length, *shape)
                self.transition_data[key] = torch.zeros(tensor_shape, dtype=dtype)

    def insert_episode_batch(self, batch: EpisodeBatch) -> None:
        batch_size = batch.batch_size
        first_part = min(batch_size, self.capacity - self.idx)
        second_part = batch_size - first_part

        # Copy first part
        if first_part > 0:
            for key, tensor in batch.transition_data.items():
                self.transition_data[key][self.idx : self.idx + first_part] = tensor[:first_part]
            for key, tensor in batch.episode_data.items():
                self.episode_data[key][self.idx : self.idx + first_part] = tensor[:first_part]

        # Copy second part
        if second_part > 0:
            for key, tensor in batch.transition_data.items():
                self.transition_data[key][:second_part] = tensor[first_part:]
            for key, tensor in batch.episode_data.items():
                self.episode_data[key][:second_part] = tensor[first_part:]

        self.idx = (self.idx + batch_size) % self.capacity
        self.counter = min(self.counter + batch_size, self.capacity)

    def can_sample(self, batch_size: int) -> bool:
        return self.counter >= batch_size

    def sample(self, batch_size: int) -> EpisodeBatch:
        if not self.can_sample(batch_size):
            raise ValueError("Not enough samples to draw")
        max_idx = min(self.counter, self.capacity)
        indices = torch.randint(0, max_idx, (batch_size,))
        sampled_transition = {k: v[indices] for k, v in self.transition_data.items()}
        sampled_episode = {k: v[indices] for k, v in self.episode_data.items()}
        return EpisodeBatch(
            scheme=self.scheme,
            groups=self.groups,
            batch_size=batch_size,
            max_seq_length=self.max_seq_length,
            data={"transition": sampled_transition, "episode": sampled_episode},
            preprocess=self.preprocess,
        )

    def __repr__(self) -> str:
        return (
            f"<ReplayBuffer capacity={self.capacity} counter={self.counter} "
            f"batch_size={self.batch_size} max_seq_length={self.max_seq_length}>"
        )