import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import random
from collections import deque
from typing import List, Dict, Any, Tuple, Optional

# Placeholder for distributed components
class RpcGroup:
    def __init__(self, *args, **kwargs):
        pass

class PushPullModelServer:
    def __init__(self, model: nn.Module):
        self.model = model

    def push(self):
        pass  # In real implementation this would push the model to other processes

# Base buffer class
class DistributedBuffer:
    def __init__(self):
        self.storage = []

    def add(self, item):
        self.storage.append(item)

    def sample(self, num_samples: int):
        return random.sample(self.storage, min(num_samples, len(self.storage)))

# IMPALA-specific buffer storing full episodes
class IMPALABuffer(DistributedBuffer):
    def __init__(self, replay_size: int = 1000):
        super().__init__()
        self.replay_size = replay_size
        self.storage = deque(maxlen=replay_size)

    def store_episode(self, episode: List[Dict[str, torch.Tensor]]):
        # Augment episode with episode_length
        length = len(episode)
        for i, transition in enumerate(episode):
            transition = transition.copy()
            transition["episode_length"] = torch.tensor(length if i == 0 else 0, dtype=torch.float32)
            self.storage.append(transition)

    def sample(self, batch_size: int) -> List[Dict[str, torch.Tensor]]:
        return random.sample(self.storage, min(batch_size, len(self.storage)))

# Simple neural network modules
class ActorNet(nn.Module):
    def __init__(self, state_dim: int, action_dim: int, hidden_dim: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, action_dim)
        )

    def forward(self, state: torch.Tensor) -> torch.distributions.Categorical:
        logits = self.net(state)
        return torch.distributions.Categorical(logits=logits)

class CriticNet(nn.Module):
    def __init__(self, state_dim: int, hidden_dim: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1)
        )

    def forward(self, state: torch.Tensor) -> torch.Tensor:
        return self.net(state).squeeze(-1)

# Main IMPALA class
class IMPALA:
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.state_dim = config["state_dim"]
        self.action_dim = config["action_dim"]
        self.actor = ActorNet(self.state_dim, self.action_dim)
        self.critic = CriticNet(self.state_dim)
        self.buffer = IMPALABuffer(config["replay_size"])
        self.actor_optim = optim.Adam(self.actor.parameters(), lr=config["actor_lr"])
        self.critic_optim = optim.Adam(self.critic.parameters(), lr=config["critic_lr"])
        self.lr_scheduler_actor = optim.lr_scheduler.StepLR(self.actor_optim, step_size=1000, gamma=0.99) \
            if config.get("lr_scheduler") else None
        self.lr_scheduler_critic = optim.lr_scheduler.StepLR(self.critic_optim, step_size=1000, gamma=0.99) \
            if config.get("lr_scheduler") else None
        self.model_server = PushPullModelServer(self.actor)
        self.is_warmup = True

    def store_episode(self, episode: List[Dict[str, Any]]):
        # Convert dict values to tensors
        tensorized_episode = []
        for t in episode:
            tensorized_transition = {k: torch.tensor(v) if not isinstance(v, torch.Tensor) else v for k, v in t.items()}
            tensorized_episode.append(tensorized_transition)
        self.buffer.store_episode(tensorized_episode)

    def _disable_update(self):
        pass

    def update(self):
        if not self.buffer.storage:
            return
        batch = self.buffer.sample(self.config["batch_size"])
        states = []
        actions = []
        rewards = []
        next_states = []
        log_probs = []
        terminals = []
        episode_lengths = []

        for transition in batch:
            states.append(transition["state"])
            actions.append(transition["action"])
            rewards.append(transition["reward"])
            next_states.append(transition["next_state"])
            log_probs.append(transition["action_log_prob"])
            terminals.append(transition["terminal"])
            episode_lengths.append(transition["episode_length"])

        states = torch.stack(states)
        actions = torch.stack(actions)
        rewards = torch.stack(rewards)
        next_states = torch.stack(next_states)
        log_probs = torch.stack(log_probs)
        terminals = torch.stack(terminals).bool()
        episode_lengths = torch.stack(episode_lengths)

        # Current policy log probs
        current_dist = self.actor(states)
        current_log_probs = current_dist.log_prob(actions)

        # Importance weights
        rho = torch.exp(current_log_probs - log_probs)
        isw_clip_rho = self.config.get("isw_clip_rho", 1.0)
        isw_clip_c = self.config.get("isw_clip_c", 1.0)
        rho = torch.clamp(rho, max=isw_clip_rho)
        c = torch.clamp(rho, max=isw_clip_c)

        # Value estimates
        values = self.critic(states)
        next_values = self.critic(next_states)
        next_values = next_values * (~terminals).float()

        # Delta V
        discounts = torch.full_like(rewards, self.config["discount"])
        delta_v = rho * (rewards + discounts * next_values - values)

        # V-trace targets
        vs = torch.zeros_like(values)
        vs[-1] = values[-1] + delta_v[-1]
        for t in range(len(batch)-2, -1, -1):
            vs[t] = values[t] + delta_v[t] + discounts[t] * c[t+1] * (vs[t+1] - values[t+1])

        # Shifted vs
        vss = torch.cat([vs[1:], torch.zeros(1, device=vs.device)])

        # Losses
        value_loss = F.mse_loss(values, vs.detach())
        policy_loss = -rho * current_log_probs * (rewards + discounts * vss - values)
        if self.config.get("entropy_weight", 0) > 0:
            entropy = current_dist.entropy()
            policy_loss -= self.config["entropy_weight"] * entropy
        policy_loss = policy_loss.mean()

        # Update actors and critics
        if self.config.get("update_policy", True):
            self.actor_optim.zero_grad()
            policy_loss.backward()
            torch.nn.utils.clip_grad_norm_(self.actor.parameters(), self.config.get("gradient_max", 40))
            self.actor_optim.step()

        if self.config.get("update_value", True):
            self.critic_optim.zero_grad()
            value_loss.backward()
            torch.nn.utils.clip_grad_norm_(self.critic.parameters(), self.config.get("gradient_max", 40))
            self.critic_optim.step()

        # Synchronize model
        self.model_server.push()

    def update_lr_scheduler(self):
        if self.lr_scheduler_actor:
            self.lr_scheduler_actor.step()
        if self.lr_scheduler_critic:
            self.lr_scheduler_critic.step()

    @staticmethod
    def generate_config() -> Dict[str, Any]:
        return {
            "state_dim": 128,
            "action_dim": 10,
            "batch_size": 32,
            "discount": 0.99,
            "entropy_weight": 0.01,
            "actor_lr": 1e-4,
            "critic_lr": 5e-4,
            "replay_size": 5000,
            "isw_clip_rho": 1.0,
            "isw_clip_c": 1.0,
            "update_policy": True,
            "update_value": True,
            "gradient_max": 40,
            "lr_scheduler": True
        }

    @classmethod
    def init_from_config(cls, config: Optional[Dict[str, Any]] = None):
        if config is None:
            config = cls.generate_config()
        return cls(config)

# Example usage
if __name__ == "__main__":
    impala = IMPALA.init_from_config()
    # Simulate storing an episode
    episode = []
    for _ in range(5):
        transition = {
            "state": torch.randn(impala.state_dim),
            "action": torch.randint(0, impala.action_dim, (1,)),
            "reward": torch.randn(1),
            "next_state": torch.randn(impala.state_dim),
            "terminal": torch.tensor(0.0),
            "action_log_prob": torch.randn(1)
        }
        episode.append(transition)
    impala.store_episode(episode)
    # Perform an update
    impala.update()
    impala.update_lr_scheduler()
