import numpy as np

# Placeholder base classes to allow the code to run standalone.
class WalkerBase:
    def __init__(self, power: float = 1.0):
        self.power = power
        self.jdict = {f"joint_{i}": i for i in range(17)}  # dummy joint dictionary
        self.motors = []

    def robot_specific_reset(self):
        pass


class MJCFBasedRobot:
    def __init__(
        self,
        mjcf_path: str,
        root_body: str,
        action_dim: int,
        observation_dim: int,
    ):
        self.mjcf_path = mjcf_path
        self.root_body = root_body
        self.action_dim = action_dim
        self.observation_dim = observation_dim
        self.initial_orientation = np.zeros(3)
        self.initial_position = np.zeros(3)
        self.initial_z = 0.0
        self.torques = np.zeros(action_dim)


class Humanoid(WalkerBase, MJCFBasedRobot):
    self_collision = True
    foot_list = ["right_foot", "left_foot"]

    def __init__(self, random_yaw: bool = True, random_lean: bool = True):
        WalkerBase.__init__(self, power=0.41)
        MJCFBasedRobot.__init__(
            self,
            mjcf_path="humanoid_symmetric.xml",
            root_body="torso",
            action_dim=17,
            observation_dim=44,
        )
        self.random_yaw = random_yaw
        self.random_lean = random_lean
        self.force_gain = 1.0
        self.motor_power = 1.0

    def robot_specific_reset(self):
        super().robot_specific_reset()
        # Motor configuration
        motor_names = [
            "abdomen",
            "hip_right",
            "knee_right",
            "ankle_right",
            "hip_left",
            "knee_left",
            "ankle_left",
            "shoulder_right",
            "elbow_right",
            "shoulder_left",
            "elbow_left",
            "torso",
            "pelvis",
            "waist",
            "head",
            "neck",
            "hand_right",
        ]
        motor_powers = [0.2] * 17  # dummy power values
        self.motors = [self.jdict[name] for name in motor_names]
        self.motor_powers = motor_powers

        # Random initialization of orientation and position
        yaw = 0.0
        pitch = 0.0
        z_offset = 0.0
        if self.random_yaw:
            yaw = np.random.uniform(-np.pi, np.pi)
        if self.random_lean:
            if np.random.rand() < 0.5:
                pitch = np.pi / 2
                z_offset = 0.45
            else:
                pitch = 3 * np.pi / 2
                z_offset = 0.25
            self.initial_orientation = np.array([pitch, 0.0, yaw])
            self.initial_position = np.array([0.0, 0.0, 1.4 + z_offset])
        else:
            self.initial_orientation = np.array([0.0, 0.0, yaw])
            self.initial_position = np.array([0.0, 0.0, 1.4])

        self.initial_z = 0.8

    def apply_action(self, a: np.ndarray):
        if a.shape[0] != self.action_dim:
            raise ValueError(f"Action dimension must be {self.action_dim}")
        torque = a * self.force_gain * self.motor_power * self.power
        self.torques = torque
        # In a real simulator, torques would be applied to the joints here.

    def alive_bonus(self, z: float) -> float:
        return 2.0 if z > 0.78 else -1.0
