import logging
from collections import defaultdict
from datetime import datetime


class Logger:
    def __init__(self, console_logger: logging.Logger):
        self.console_logger = console_logger
        self.use_tb = False
        self.use_sacred = False
        self.use_hdf = False
        self.stats: defaultdict[str, list[tuple[float, float]]] = defaultdict(list)
        self.tb_logger = None
        self.sacred_info = {}

    def setup_tb(self, log_dir: str):
        try:
            import tensorboard_logger
        except ImportError:
            raise RuntimeError("tensorboard_logger is not installed")
        self.log_dir = log_dir
        self.tb_logger = lambda tag, value, step: tensorboard_logger.log_value(
            tag, value, step
        )
        self.use_tb = True

    def setup_sacred(self, sacred_run_dict: dict):
        self.sacred_info = dict(sacred_run_dict)
        self.use_sacred = True

    def log_stat(self, key: str, t: float, value: float):
        self.stats[key].append((t, value))
        if self.use_tb:
            self.tb_logger(key, value, t)
        if self.use_sacred:
            self.sacred_info.setdefault(key, []).append(value)
            self.sacred_info.setdefault(f"{key}_T", []).append(t)

    def print_recent_stats(self):
        if "episode" not in self.stats or not self.stats["episode"]:
            episode = "N/A"
        else:
            episode = self.stats["episode"][-1][1]

        stat_parts = []
        for key, data in self.stats.items():
            if key == "episode":
                continue
            values = [v for _, v in data]
            if key == "epsilon":
                avg = values[-1] if values else 0.0
            else:
                recent = values[-5:] if len(values) >= 5 else values
                avg = sum(recent) / len(recent) if recent else 0.0
            stat_parts.append(f"{key}: {avg:.4f}")

        log_str = f"Episode {episode} | " + " | ".join(stat_parts)
        self.console_logger.info(log_str)


def get_logger(name: str) -> logging.Logger:
    logger = logging.getLogger(name)
    for h in logger.handlers[:]:
        logger.removeHandler(h)
    handler = logging.StreamHandler()
    formatter = logging.Formatter(
        "[%(levelname)s %(asctime)s] %(name)s %(message)s"
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.DEBUG)
    return logger
