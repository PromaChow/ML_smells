import time
import numpy as np
from dataclasses import dataclass, field
from typing import Any, Dict, List


# ------------------------------------------------------------------
# Placeholder classes for environment wrappers and agent
# ------------------------------------------------------------------
class VecMonitor:
    """Mock VecMonitor wrapper that stores running averages of returns and horizons."""
    def __init__(self, env):
        self.env = env
        self.return_queue = []
        self.horizon_queue = []

    def step(self, *args, **kwargs):
        return self.env.step(*args, **kwargs)


class VecStandardize:
    """Mock VecStandardize wrapper for evaluation environment."""
    def __init__(self, env, obs_clip: float = 10.0, gamma: float = 0.99, running_averages: Dict[str, Any] = None):
        self.env = env
        self.obs_clip = obs_clip
        self.gamma = gamma
        self.running_averages = running_averages or {}

    def step(self, *args, **kwargs):
        return self.env.step(*args, **kwargs)


# ------------------------------------------------------------------
# Dataset representation
# ------------------------------------------------------------------
@dataclass
class Dataset:
    trajectories: List[Any]
    rewards: List[float]
    infos: List[Dict[str, Any]]


# ------------------------------------------------------------------
# Episode runner
# ------------------------------------------------------------------
class EpisodeRunner:
    def __init__(self, env, max_steps: int):
        self.env = env
        self.max_steps = max_steps

    def run(self) -> Dataset:
        # For demo purposes, generate random trajectories
        trajectories = [np.random.randn(10, 4) for _ in range(5)]
        rewards = np.random.rand(5).tolist()
        infos = [
            {"return": r, "horizon": np.random.randint(1, 50)} for r in rewards
        ]
        return Dataset(trajectories, rewards, infos)


# ------------------------------------------------------------------
# Logger
# ------------------------------------------------------------------
class Logger:
    def __init__(self):
        self.logs = {}

    def log(self, key: str, value: Any):
        self.logs[key] = value

    def dump(self):
        for k, v in self.logs.items():
            print(f"{k}: {v}")


# ------------------------------------------------------------------
# Mock agent
# ------------------------------------------------------------------
class Agent:
    def train(self):
        pass

    def eval(self):
        pass

    def learn(self, dataset: Dataset) -> Dict[str, Any]:
        # Dummy learning: return random loss values
        return {"policy_loss": np.random.rand(), "value_loss": np.random.rand()}


# ------------------------------------------------------------------
# Configuration
# ------------------------------------------------------------------
@dataclass
class Config:
    train_ratio_T: float = 0.1
    eval_standardization: bool = True
    obs_clip: float = 10.0
    gamma: float = 0.99


# ------------------------------------------------------------------
# Runner holding environment
# ------------------------------------------------------------------
@dataclass
class Runner:
    env: Any


# ------------------------------------------------------------------
# Training and evaluation engine
# ------------------------------------------------------------------
class Engine:
    def __init__(self, agent: Agent, runner: Runner, config: Config):
        self.agent = agent
        self.runner = runner
        self.config = config

    def train(self, n: int) -> Dict[str, Any]:
        self.agent.train()
        start_time = time.time()

        T = int(self.runner.env.T * self.config.train_ratio_T)
        runner = EpisodeRunner(self.runner.env, T)
        D = runner.run()

        out_agent = self.agent.learn(D)

        elapsed = time.time() - start_time
        train_output = {
            "dataset": D,
            "out_agent": out_agent,
            "n": n,
            "elapsed": elapsed,
        }

        # Logging
        logger = Logger()
        logger.log("Iteration", n + 1)
        logger.log("Elapsed Time (s)", elapsed)
        for key, value in out_agent.items():
            logger.log(f"Agent {key}", value)

        # Episode statistics
        returns = [info["return"] for info in D.infos]
        horizons = [info["horizon"] for info in D.infos]
        logger.log("Episode Mean Return", np.mean(returns))
        logger.log("Episode Std Return", np.std(returns))
        logger.log("Episode Min Return", np.min(returns))
        logger.log("Episode Max Return", np.max(returns))
        logger.log("Episode Mean Horizon", np.mean(horizons))
        logger.log("Episode Std Horizon", np.std(horizons))
        logger.log("Episode Min Horizon", np.min(horizons))
        logger.log("Episode Max Horizon", np.max(horizons))

        # VecMonitor metrics
        if hasattr(self.runner.env, "return_queue"):
            r_q = self.runner.env.return_queue
            h_q = self.runner.env.horizon_queue
            logger.log("VecMonitor Return Queue Mean", np.mean(r_q) if r_q else None)
            logger.log("VecMonitor Horizon Queue Mean", np.mean(h_q) if h_q else None)

        print("-" * 40)
        logger.dump()
        return logger.logs

    def evaluate(self, n: int) -> Dict[str, Any]:
        self.agent.eval()
        start_time = time.time()

        # Environment setup for evaluation
        if self.config.eval_standardization:
            eval_env = VecStandardize(
                self.runner.env,
                obs_clip=self.config.obs_clip,
                gamma=self.config.gamma,
                running_averages={
                    "returns": getattr(self.runner.env, "return_queue", []),
                    "horizons": getattr(self.runner.env, "horizon_queue", []),
                },
            )
        else:
            eval_env = self.runner.env

        T = getattr(eval_env, "T", 1000)  # Default if not present
        runner = EpisodeRunner(eval_env, T)
        D = runner.run()

        elapsed = time.time() - start_time
        eval_output = {
            "dataset": D,
            "n": n,
            "T": T,
            "elapsed": elapsed,
        }

        # Logging
        logger = Logger()
        logger.log("Evaluation Iteration", n + 1)
        logger.log("Elapsed Time (s)", elapsed)
        logger.log("Trajectories", len(D.trajectories))
        logger.log("Max Horizon", T)
        logger.log("Accumulated Training Timesteps", getattr(self.runner.env, "T", None))

        # Return statistics
        returns = D.rewards
        logger.log("Eval Mean Return", np.mean(returns))
        logger.log("Eval Std Return", np.std(returns))
        logger.log("Eval Min Return", np.min(returns))
        logger.log("Eval Max Return", np.max(returns))

        print("\033[93m" + "-" * 40 + "\033[0m")  # Yellow separator
        logger.dump()
        return logger.logs


# ------------------------------------------------------------------
# Example usage (would normally be in a separate script)
# ------------------------------------------------------------------
if __name__ == "__main__":
    # Mock environment with total timesteps
    class MockEnv:
        T = 1000
        def step(self, *args, **kwargs):
            pass

    env = VecMonitor(MockEnv())
    agent = Agent()
    runner = Runner(env)
    config = Config()
    engine = Engine(agent, runner, config)

    # Train for 3 iterations
    for i in range(3):
        engine.train(i)

    # Evaluate
    engine.evaluate(0)