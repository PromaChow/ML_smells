import logging
import pandas as pd
import quandl
import statsmodels.tsa.api as _VAR

logging.basicConfig(level=logging.INFO)

def clean(df: pd.DataFrame) -> pd.DataFrame:
    """Remove rows with any missing values."""
    return df.dropna()


class Finance:
    def __init__(self, freq: str = "B", csv_path: str | None = None):
        self.freq = freq
        self.csv_path = csv_path

    def _get(self, ticker: str) -> pd.DataFrame | None:
        try:
            df = quandl.get(f"WIKI/{ticker}")
            return df
        except Exception as e:
            logging.warning(f"Failed to fetch data for {ticker}: {e}")
            return None

    def _csv(self, tickers: list[str]) -> pd.DataFrame:
        df = pd.read_csv(self.csv_path, parse_dates=True, index_col=0)
        # Keep only columns that match requested tickers
        df = df[[col for col in df.columns if col in tickers]]
        df.sort_index(inplace=True)
        return df

    def Prices(self, tickers: list[str]) -> pd.DataFrame:
        if self.csv_path:
            df = self._csv(tickers)
            return df.resample(self.freq).last()
        frames = []
        for t in tickers:
            data = self._get(t)
            if data is not None:
                frames.append(
                    data[["Adj. Close"]].rename(columns={"Adj. Close": t})
                )
        if not frames:
            return pd.DataFrame()
        df = pd.concat(frames, axis=1)
        return df.resample(self.freq).last()

    def Returns(self, tickers: list[str]) -> pd.DataFrame:
        if self.csv_path:
            df = self._csv(tickers)
            return df.pct_change().dropna()
        prices = self.Prices(tickers)
        return prices.pct_change().dropna()

    def SP500(self, full: bool = False):
        url = "https://en.wikipedia.org/wiki/List_of_S%26P_500_companies"
        tables = pd.read_html(url)
        df = tables[0][["Symbol", "Security", "GICS Sector"]]
        df.set_index("Symbol", inplace=True)
        if not full:
            return df
        tickers = df.index.tolist()
        prices = self.Prices(tickers)
        returns = self.Returns(tickers)
        return {"info": df, "prices": prices, "returns": returns}


class VAR:
    def __init__(self, finance: Finance, order: int = 2, steps: int = 252):
        self.finance = finance
        self.order = order
        self.steps = steps

    def Returns(
        self, tickers: list[str], return_params: bool = False
    ) -> pd.DataFrame | tuple[pd.DataFrame, pd.DataFrame]:
        raw = self.finance.Returns(tickers)
        data = clean(raw)
        if data.empty:
            raise ValueError("No data available to fit VAR.")
        model = _VAR.VAR(data)
        results = model.fit(self.order)
        sim = results.simulate_var(self.steps)
        if return_params:
            return sim, results.params
        return sim

    def Prices(
        self, tickers: list[str], return_params: bool = False
    ) -> pd.DataFrame | tuple[pd.DataFrame, pd.DataFrame]:
        sim_returns = self.Returns(tickers, return_params=return_params)
        if return_params:
            sim_returns, params = sim_returns
        else:
            params = None
        prices = (sim_returns + 1).cumprod()
        if return_params:
            return prices, params
        return prices
