import numpy as np
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List


@dataclass
class ContinuousFactor:
    name: str
    low: float
    high: float
    sample: Callable[[], float] = field(init=False)

    def __post_init__(self) -> None:
        self.sample = lambda: np.random.uniform(self.low, self.high)


@dataclass
class DiscreteFactor:
    name: str
    options: List[Any]
    sample: Callable[[], Any] = field(init=False)

    def __post_init__(self) -> None:
        self.sample = lambda: np.random.choice(self.options)


class NoReward:
    def get_reward(self, *args: Any, **kwargs: Any) -> float:
        return 0.0


def action_space() -> List[str]:
    return ["UP", "DOWN", "LEFT", "RIGHT"]


def renderers() -> List[str]:
    return ["basic"]


class SpriteGenerator:
    def __init__(self, factors: Dict[str, Any], num_sprites_fn: Callable[[], int]) -> None:
        self.factors = factors
        self.num_sprites_fn = num_sprites_fn

    def initialize_episode(self) -> List[Dict[str, Any]]:
        sprites: List[Dict[str, Any]] = []
        n = self.num_sprites_fn()
        for _ in range(n):
            sprite = {name: factor.sample() for name, factor in self.factors.items()}
            sprites.append(sprite)
        return sprites


sprite_factors: Dict[str, Any] = {
    "x": ContinuousFactor("x", 0.1, 0.9),
    "y": ContinuousFactor("y", 0.1, 0.9),
    "c0": ContinuousFactor("c0", 0.0, 1.0),
    "c1": ContinuousFactor("c1", 0.3, 1.0),
    "c2": ContinuousFactor("c2", 0.9, 1.0),
    "shape": DiscreteFactor("shape", ["square", "triangle", "circle"]),
    "scale": DiscreteFactor("scale", [0.13]),
}

num_sprites_fn: Callable[[], int] = lambda: np.random.randint(1, 7)

sprite_generator = SpriteGenerator(sprite_factors, num_sprites_fn)


@dataclass
class EnvironmentConfig:
    task: Any
    action_space: List[str]
    renderers: List[str]
    sprite_generator: SpriteGenerator
    max_episode_length: int
    metadata: Dict[str, Any] = field(default_factory=dict)


env_config = EnvironmentConfig(
    task=NoReward(),
    action_space=action_space(),
    renderers=renderers(),
    sprite_generator=sprite_generator,
    max_episode_length=10,
    metadata={"task_id": __file__},
)