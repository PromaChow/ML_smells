import torch


class TransitionBase:
    MAJOR_ATTRS = set()
    SUB_ATTRS = set()
    CUSTOM_ATTRS = set()

    def __init__(self, **kwargs):
        allowed = self.allowed_attrs()
        for key, value in kwargs.items():
            if key not in allowed:
                raise AttributeError(f"Attribute '{key}' not allowed for {self.__class__.__name__}")
            setattr(self, key, value)
        self._batch_size = None
        self._check_validity()

    def allowed_attrs(self):
        return self.MAJOR_ATTRS | self.SUB_ATTRS | self.CUSTOM_ATTRS

    def __setattr__(self, name, value):
        if name.startswith("_") or name in self.allowed_attrs():
            object.__setattr__(self, name, value)
        else:
            raise AttributeError(f"Cannot set unknown attribute '{name}' on {self.__class__.__name__}")

    def __setitem__(self, key, value):
        self.__setattr__(key, value)

    def _check_validity(self):
        if not self.MAJOR_ATTRS:
            raise ValueError("No major attributes defined.")
        batch_size = None
        # Validate major attributes
        for attr in self.MAJOR_ATTRS:
            data = getattr(self, attr, None)
            if data is None:
                raise ValueError(f"Major attribute '{attr}' is missing.")
            if not isinstance(data, dict):
                raise ValueError(f"Major attribute '{attr}' must be a dict of tensors.")
            for key, tensor in data.items():
                if not torch.is_tensor(tensor):
                    raise ValueError(f"Tensor for key '{key}' in '{attr}' is not a torch.Tensor.")
                if tensor.dim() < 1:
                    raise ValueError(f"Tensor for key '{key}' in '{attr}' must have at least 1 dimension.")
                if batch_size is None:
                    batch_size = tensor.size(0)
                elif tensor.size(0) != batch_size:
                    raise ValueError(f"Inconsistent batch sizes in major attribute '{attr}'.")
        # Validate sub attributes
        for attr in self.SUB_ATTRS:
            data = getattr(self, attr, None)
            if data is None:
                raise ValueError(f"Sub attribute '{attr}' is missing.")
            if not torch.is_tensor(data):
                raise ValueError(f"Sub attribute '{attr}' must be a torch.Tensor.")
            if batch_size is None:
                batch_size = data.size(0)
            elif data.size(0) != batch_size:
                raise ValueError(f"Inconsistent batch sizes in sub attribute '{attr}'.")
        if batch_size is None:
            raise ValueError("Unable to determine batch size.")
        self._batch_size = batch_size

    def to(self, device):
        for attr in self.MAJOR_ATTRS | self.SUB_ATTRS:
            data = getattr(self, attr)
            if isinstance(data, dict):
                for key, tensor in data.items():
                    data[key] = tensor.to(device)
            else:
                setattr(self, attr, data.to(device))

    def _detach(self):
        for attr in self.MAJOR_ATTRS | self.SUB_ATTRS:
            data = getattr(self, attr)
            if isinstance(data, dict):
                for key, tensor in data.items():
                    data[key] = tensor.detach()
            else:
                setattr(self, attr, data.detach())


class Transition(TransitionBase):
    MAJOR_ATTRS = {"state", "action", "next_state"}
    SUB_ATTRS = {"reward", "terminal"}
    CUSTOM_ATTRS = set()

    def __init__(self, **kwargs):
        # Separate custom kwargs
        custom_kwargs = {k: v for k, v in kwargs.items()
                         if k not in self.MAJOR_ATTRS | self.SUB_ATTRS}
        # Process sub attributes: convert scalars to tensors
        sub_kwargs = {}
        for key in self.SUB_ATTRS:
            if key in kwargs:
                val = kwargs[key]
                if not torch.is_tensor(val):
                    if isinstance(val, (int, float)):
                        val = torch.tensor([val], dtype=torch.float32)
                    else:
                        val = torch.tensor(val)
                sub_kwargs[key] = val
        # Prepare major kwargs
        major_kwargs = {k: v for k, v in kwargs.items()
                        if k in self.MAJOR_ATTRS}
        # Initialize base class with major and sub attributes
        super().__init__(**{**major_kwargs, **sub_kwargs})
        # Store custom attributes
        sorted_keys = sorted(custom_kwargs.keys())
        self._custom_keys = sorted_keys
        for key in sorted_keys:
            object.__setattr__(self, key, custom_kwargs[key])

    def _check_validity(self):
        super()._check_validity()
        if self._batch_size != 1:
            raise ValueError("Transition batch size must be 1.")

    @property
    def custom_keys(self):
        return self._custom_keys
