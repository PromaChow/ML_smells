import numpy as np
from scipy.spatial.distance import pdist

def ker(x, x_c, sigma, model):
    if model == 'gauss':
        d2 = np.sum((x[:, None, :] - x_c[None, :, :]) ** 2, axis=2)
        return np.exp(-d2 / (2 * sigma ** 2))
    elif model == 'lm':
        phi_x = np.hstack([np.ones((x.shape[0], 1)), x])
        if x_c is None:
            return phi_x
        phi_c = np.hstack([np.ones((x_c.shape[0], 1)), x_c])
        return phi_x @ phi_c.T
    else:
        raise ValueError(f"Unknown model type: {model}")

def calc_risk(gp, gu, prior):
    fnr = np.mean(gp <= 0)
    fpr = np.mean(gu > 0)
    return prior * fnr + (1 - prior) * fpr

def make_func(w, x_c, sigma, model, x_t):
    k_t = ker(x_t, x_c, sigma, model)
    return np.sign(k_t @ w)

class PU_SL:
    def __init__(self, prior, sigma, lam, basis='gauss', n_basis=200):
        if not (0 <= prior <= 1):
            raise ValueError("prior must be in [0, 1]")
        self.prior = prior
        self.sigma = sigma
        self.lam = lam
        self.basis = basis
        self.n_basis = n_basis
        self.coef_ = None
        self.centers_ = None

    def fit(self, x, y):
        x = np.asarray(x)
        y = np.asarray(y)
        x_p = x[y == 1]
        x_u = x[y == 0]
        if self.basis == 'gauss':
            rng = np.random.default_rng()
            idx = rng.choice(len(x_u), self.n_basis, replace=False)
            self.centers_ = x_u[idx]
            k_p = ker(x_p, self.centers_, self.sigma, 'gauss')
            k_u = ker(x_u, self.centers_, self.sigma, 'gauss')
        else:  # 'lm'
            self.centers_ = None
            k_p = ker(x_p, None, None, 'lm')
            k_u = ker(x_u, None, None, 'lm')
        H = (k_u.T @ k_u) / len(x_u)
        h = self.prior * k_p.mean(axis=0) - (1 - self.prior) * k_u.mean(axis=0)
        R = self.lam * np.eye(H.shape[0])
        self.coef_ = np.linalg.solve(H + R, h)

    def predict(self, x):
        if self.coef_ is None:
            raise RuntimeError("Model has not been fitted.")
        k = ker(x, self.centers_, self.sigma, self.basis)
        return np.sign(k @ self.coef_)

    def score(self, x, y):
        x = np.asarray(x)
        y = np.asarray(y)
        x_p = x[y == 1]
        x_u = x[y == 0]
        k_p = ker(x_p, self.centers_, self.sigma, self.basis)
        k_u = ker(x_u, self.centers_, self.sigma, self.basis)
        gp = k_p @ self.coef_
        gu = k_u @ self.coef_
        return calc_risk(gp, gu, self.prior)

def pu_sl(x_p, x_u, prior, sigma_list=None, lambda_list=None,
          n_fold=5, basis='gauss', n_basis=200):
    x_p = np.asarray(x_p)
    x_u = np.asarray(x_u)
    if sigma_list is None:
        if basis == 'gauss':
            dists = pdist(x_u, 'euclidean')
            sigma_list = [np.median(dists) if dists.size > 0 else 1.0]
        else:
            sigma_list = [1.0]
    if lambda_list is None:
        lambda_list = [1e-3, 1e-2, 1e-1, 1]
    pos_indices = np.arange(len(x_p))
    unl_indices = np.arange(len(x_u))
    pos_folds = np.array_split(pos_indices, n_fold)
    unl_folds = np.array_split(unl_indices, n_fold)
    best_sigma = None
    best_lam = None
    best_risk = np.inf
    for sigma in sigma_list:
        for lam in lambda_list:
            risk_acc = 0.0
            for fold in range(n_fold):
                train_pos = np.hstack([pos_folds[i] for i in range(n_fold) if i != fold])
                test_pos = pos_folds[fold]
                train_unl = np.hstack([unl_folds[i] for i in range(n_fold) if i != fold])
                test_unl = unl_folds[fold]
                xp_train = x_p[train_pos]
                xu_train = x_u[train_unl]
                if basis == 'gauss':
                    rng = np.random.default_rng()
                    idx = rng.choice(len(xu_train), n_basis, replace=False)
                    centers = xu_train[idx]
                    k_p = ker(xp_train, centers, sigma, 'gauss')
                    k_u = ker(xu_train, centers, sigma, 'gauss')
                else:
                    centers = None
                    k_p = ker(xp_train, None, None, 'lm')
                    k_u = ker(xu_train, None, None, 'lm')
                H = (k_u.T @ k_u) / len(xu_train)
                h = prior * k_p.mean(axis=0) - (1 - prior) * k_u.mean(axis=0)
                R = lam * np.eye(H.shape[0])
                w = np.linalg.solve(H + R, h)
                xp_test = x_p[test_pos]
                xu_test = x_u[test_unl]
                if basis == 'gauss':
                    k_p_test = ker(xp_test, centers, sigma, 'gauss')
                    k_u_test = ker(xu_test, centers, sigma, 'gauss')
                else:
                    k_p_test = ker(xp_test, None, None, 'lm')
                    k_u_test = ker(xu_test, None, None, 'lm')
                gp = k_p_test @ w
                gu = k_u_test @ w
                risk_acc += calc_risk(gp, gu, prior)
            avg_risk = risk_acc / n_fold
            if avg_risk < best_risk:
                best_risk = avg_risk
                best_sigma = sigma
                best_lam = lam
    # Train final model
    model = PU_SL(prior, best_sigma, best_lam, basis, n_basis)
    model.fit(np.vstack([x_p, x_u]), np.hstack([np.ones(len(x_p)), np.zeros(len(x_u))]))
    def predict_fn(x):
        return make_func(model.coef_, model.centers_, best_sigma, basis, x)
    metadata = {'best_sigma': best_sigma, 'best_lambda': best_lam, 'cv_risk': best_risk}
    return predict_fn, metadata
