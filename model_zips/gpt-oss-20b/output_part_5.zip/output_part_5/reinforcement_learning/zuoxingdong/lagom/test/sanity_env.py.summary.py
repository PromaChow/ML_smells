import gym
import numpy as np
import random
from gym.core import Env, ObsType, ActionType
from gym.envs.registration import EnvSpec


class SanityEnv(Env):
    metadata = {"render.modes": []}

    def __init__(self):
        # Randomly select the maximum number of steps per episode (T)
        self.T = random.randint(4, 6)

        # Reward starts at 0.1 and can grow indefinitely
        self.reward_range = (0.1, float("inf"))

        # Observation space: scalar Box in [10, 60]
        self.observation_space = gym.spaces.Box(
            low=10.0, high=60.0, shape=(1,), dtype=np.float32
        )

        # Action space: scalar Box in [1, 6]
        self.action_space = gym.spaces.Box(
            low=1.0, high=6.0, shape=(1,), dtype=np.float32
        )

        # Environment specification
        self.spec = EnvSpec("Sanity-v0", max_episode_steps=self.T)

        # Internal state
        self.reset()

    def step(self, action: ActionType) -> tuple[ObsType, float, bool, dict]:
        self.t += 1
        self.s += 10.0
        self.r += 0.1
        done = self.t == self.T
        return self.s, self.r, done, {}

    def reset(self) -> ObsType:
        self.s = 0.0
        self.r = 0.0
        self.t = 0
        return self.s

    def seed(self, seed=None):
        return [seed]

    def render(self, mode="human"):
        pass

    def close(self):
        pass
