import numpy as np
import tensorflow as tf
from sklearn.model_selection import train_test_split

def sliding_window_np(data, window_size, shift=None, stride=1):
    """
    Create sliding windows over the first axis of `data`.
    """
    if shift is None:
        shift = window_size
    n_samples = data.shape[0]
    windows = []
    for start in range(0, n_samples - window_size + 1, stride):
        windows.append(data[start:start + window_size])
    return np.array(windows)  # shape: (n_windows, window_size, features)

def get_mode(labels):
    """
    Return the majority label from an array of labels.
    """
    values, counts = np.unique(labels, return_counts=True)
    return values[np.argmax(counts)]

def combine_windowed_dataset(windowed_data, train_users, test_users):
    """
    Split the windowed data into training and test sets based on user ids.
    """
    X_train, y_train = [], []
    X_test, y_test = [], []

    for user_id, (sensors, labels) in windowed_data.items():
        if user_id in train_users:
            X_train.append(sensors)
            y_train.append(labels)
        elif user_id in test_users:
            X_test.append(sensors)
            y_test.append(labels)

    X_train = np.concatenate(X_train, axis=0) if X_train else np.empty((0, *sensors.shape[1:]))
    y_train = np.concatenate(y_train, axis=0) if y_train else np.empty((0,))
    X_test = np.concatenate(X_test, axis=0) if X_test else np.empty((0, *sensors.shape[1:]))
    y_test = np.concatenate(y_test, axis=0) if y_test else np.empty((0,))

    return (X_train, y_train), (X_test, y_test)

def get_mean_std_from_user_list_format(X):
    """
    Compute mean and std over all samples and features.
    """
    mean = np.mean(X, axis=0)
    std = np.std(X, axis=0)
    std[std == 0] = 1.0  # avoid division by zero
    return mean, std

def apply_label_map(labels, label_map):
    """
    Map labels according to `label_map`. Labels not found become None.
    """
    vectorized_map = np.vectorize(lambda x: label_map.get(x, None))
    return vectorized_map(labels)

def filter_none_label(X, y):
    """
    Remove samples where label is None.
    """
    mask = y != None
    return X[mask], np.array([label for label in y[mask] if label is not None])

def add_user_id_to_windowed_dataset(X, user_ids, as_feature=True):
    """
    Append user_id as a feature or as a separate label.
    """
    if as_feature:
        # Replicate user id for each window
        user_id_array = np.array(user_ids).reshape(-1, 1)
        # Expand to match number of windows
        user_id_expanded = np.repeat(user_id_array, X.shape[1], axis=1)
        # Flatten to 1D
        user_id_expanded = user_id_expanded.reshape(-1, 1)
        X_flat = X.reshape(X.shape[0], -1)
        X_new = np.concatenate([X_flat, user_id_expanded], axis=1)
        return X_new
    else:
        # Return user ids as separate labels
        return user_ids

def make_batches_reshape(X, y, batch_size):
    """
    Reshape windows into 2D and create batches.
    """
    X_flat = X.reshape(X.shape[0], -1)
    n_samples = X_flat.shape[0]
    n_batches = n_samples // batch_size
    X_batched = X_flat[:n_batches * batch_size].reshape(n_batches, batch_size, -1)
    y_batched = y[:n_batches * batch_size].reshape(n_batches, batch_size)
    return X_batched, y_batched

def get_batched_dataset_generator(X, y, batch_size):
    """
    Generator yielding batches of data and labels.
    """
    X_batched, y_batched = make_batches_reshape(X, y, batch_size)
    for X_batch, y_batch in zip(X_batched, y_batched):
        yield X_batch, y_batch

def pre_process_dataset_composite_in_user_format(
    data_dict,
    window_size,
    shift=None,
    stride=1,
    normalize=True,
    label_map=None,
    output_shape=None,
    validation_split_proportion=None,
    add_user_id=False,
    user_id_as_feature=True,
    batch_size=32
):
    """
    Process each user's data separately, returning train/val/test sets.
    """
    processed = {}
    for user_id, trials in data_dict.items():
        # Combine all trials for this user
        sensor_data = np.concatenate([trial["sensor"] for trial in trials], axis=0)
        label_data = np.concatenate([trial["label"] for trial in trials], axis=0)

        # Windowing
        sensor_windows = sliding_window_np(sensor_data, window_size, shift, stride)
        label_windows = []
        for win_labels in sliding_window_np(label_data, window_size, shift, stride):
            label_windows.append(get_mode(win_labels))
        label_windows = np.array(label_windows)

        # Label mapping
        if label_map is not None:
            label_windows = apply_label_map(label_windows, label_map)

        # Filter unmapped labels
        sensor_windows, label_windows = filter_none_label(sensor_windows, label_windows)

        # Normalization
        if normalize:
            mean, std = get_mean_std_from_user_list_format(sensor_windows)
            sensor_windows = (sensor_windows - mean) / std

        # One-hot encode
        if output_shape is not None:
            label_windows = tf.keras.utils.to_categorical(label_windows, num_classes=output_shape)

        # Add user id
        if add_user_id:
            if user_id_as_feature:
                sensor_windows = add_user_id_to_windowed_dataset(sensor_windows, [user_id]*sensor_windows.shape[0], as_feature=True)
            else:
                label_windows = np.append(label_windows, [user_id], axis=1)

        # Train-validation split
        if validation_split_proportion is not None:
            X_train, X_val, y_train, y_val = train_test_split(
                sensor_windows, label_windows, test_size=validation_split_proportion, shuffle=True
            )
        else:
            X_train, y_train = sensor_windows, label_windows
            X_val, y_val = None, None

        # Test set is empty because no separate test users
        X_test, y_test = None, None

        processed[user_id] = {
            "train": {"X": X_train, "y": y_train},
            "val": {"X": X_val, "y": y_val},
            "test": {"X": X_test, "y": y_test}
        }
    return processed

def preprocess_dataset(
    data_dict,
    train_users,
    test_users,
    window_size,
    shift=None,
    stride=1,
    normalize=True,
    label_map=None,
    output_shape=None,
    validation_split_proportion=None,
    add_user_id=False,
    user_id_as_feature=True,
    batch_size=32
):
    """
    Full preprocessing pipeline for time-series data.
    """
    # Windowing per user
    windowed_data = {}
    for user_id, trials in data_dict.items():
        # Combine trials
        sensor_data = np.concatenate([trial["sensor"] for trial in trials], axis=0)
        label_data = np.concatenate([trial["label"] for trial in trials], axis=0)

        sensor_windows = sliding_window_np(sensor_data, window_size, shift, stride)
        label_windows = []
        for win_labels in sliding_window_np(label_data, window_size, shift, stride):
            label_windows.append(get_mode(win_labels))
        label_windows = np.array(label_windows)

        windowed_data[user_id] = (sensor_windows, label_windows)

    # Split into train/test
    (X_train, y_train), (X_test, y_test) = combine_windowed_dataset(windowed_data, train_users, test_users)

    # Normalization
    if normalize:
        mean, std = get_mean_std_from_user_list_format(X_train)
        X_train = (X_train - mean) / std
        X_test = (X_test - mean) / std

    # Label mapping
    if label_map is not None:
        y_train = apply_label_map(y_train, label_map)
        y_test = apply_label_map(y_test, label_map)

    # Filter unmapped labels
    X_train, y_train = filter_none_label(X_train, y_train)
    X_test, y_test = filter_none_label(X_test, y_test)

    # One-hot encode
    if output_shape is not None:
        y_train = tf.keras.utils.to_categorical(y_train, num_classes=output_shape)
        y_test = tf.keras.utils.to_categorical(y_test, num_classes=output_shape)

    # Add user id
    if add_user_id:
        if user_id_as_feature:
            # Create arrays of user ids
            train_user_ids = np.array([user_id for user_id, _ in windowed_data.items() if user_id in train_users])
            test_user_ids = np.array([user_id for user_id, _ in windowed_data.items() if user_id in test_users])
            # Repeat ids to match windows
            train_user_ids = np.repeat(train_user_ids, X_train.shape[0] // len(train_user_ids))
            test_user_ids = np.repeat(test_user_ids, X_test.shape[0] // len(test_user_ids))
            X_train = add_user_id_to_windowed_dataset(X_train, train_user_ids, as_feature=True)
            X_test = add_user_id_to_windowed_dataset(X_test, test_user_ids, as_feature=True)
        else:
            # Append user id to labels
            train_user_ids = np.array([user_id for user_id, _ in windowed_data.items() if user_id in train_users])
            test_user_ids = np.array([user_id for user_id, _ in windowed_data.items() if user_id in test_users])
            train_user_ids = np.repeat(train_user_ids, y_train.shape[0] // len(train_user_ids))
            test_user_ids = np.repeat(test_user_ids, y_test.shape[0] // len(test_user_ids))
            y_train = np.append(y_train, train_user_ids, axis=1)
            y_test = np.append(y_test, test_user_ids, axis=1)

    # Train-validation split
    if validation_split_proportion is not None:
        X_train, X_val, y_train, y_val = train_test_split(
            X_train, y_train, test_size=validation_split_proportion, shuffle=True
        )
    else:
        X_val, y_val = None, None

    # Batch generators
    train_gen = get_batched_dataset_generator(X_train, y_train, batch_size)
    val_gen = get_batched_dataset_generator(X_val, y_val, batch_size) if X_val is not None else None
    test_gen = get_batched_dataset_generator(X_test, y_test, batch_size) if X_test is not None else None

    return {
        "train": {"generator": train_gen, "shape": X_train.shape},
        "validation": {"generator": val_gen, "shape": X_val.shape if X_val is not None else None},
        "test": {"generator": test_gen, "shape": X_test.shape if X_test is not None else None},
        "stats": {"mean": mean if normalize else None, "std": std if normalize else None}
    }
```