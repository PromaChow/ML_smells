import numpy as np

def gen_twonorm_ssl(n_l: int, prior_l: float, n_u: int, prior_u: float, n_t: int):
    """
    Generate synthetic data for semi-supervised learning (SSL).

    Parameters
    ----------
    n_l : int
        Number of labeled samples.
    prior_l : float
        Probability that a labeled sample is positive.
    n_u : int
        Number of unlabeled samples.
    prior_u : float
        Probability that an unlabeled sample is positive.
    n_t : int
        Number of test samples for each class.

    Returns
    -------
    x : np.ndarray
        Combined labeled and unlabeled data (shape: (n_l + n_u, 2)).
    y : np.ndarray
        Labels for training data (1 for positive, -1 for negative, 0 for unlabeled).
    x_t : np.ndarray
        Test data (shape: (2 * n_t, 2)).
    y_t : np.ndarray
        Labels for test data (1 for positive, -1 for negative).
    """
    mu_p = np.array([1.0, 1.0])
    mu_n = np.array([-1.0, -1.0])

    # Labeled data
    n_p_l = np.random.binomial(n_l, prior_l)
    n_n_l = n_l - n_p_l
    x_pos_l = np.random.randn(n_p_l, 2) + mu_p
    x_neg_l = np.random.randn(n_n_l, 2) + mu_n

    # Unlabeled data
    n_p_u = np.random.binomial(n_u, prior_u)
    n_n_u = n_u - n_p_u
    x_pos_u = np.random.randn(n_p_u, 2) + mu_p
    x_neg_u = np.random.randn(n_n_u, 2) + mu_n

    # Combine data
    x = np.vstack((x_pos_l, x_neg_l, x_pos_u, x_neg_u))
    y_labeled = np.hstack((np.ones(n_p_l), -np.ones(n_n_l)))
    y_unlabeled = np.zeros(n_u)
    y = np.hstack((y_labeled, y_unlabeled))

    # Test data
    x_tp = np.random.randn(n_t, 2) + mu_p
    x_tn = np.random.randn(n_t, 2) + mu_n
    x_t = np.vstack((x_tp, x_tn))
    y_t = np.hstack((np.ones(n_t), -np.ones(n_t)))

    return x, y, x_t, y_t


def gen_twonorm_pu(n_p: int, n_u: int, prior_u: float, n_t: int):
    """
    Generate synthetic data for positive-unlabeled learning (PU).

    Parameters
    ----------
    n_p : int
        Number of positive samples.
    n_u : int
        Number of unlabeled samples.
    prior_u : float
        Probability that an unlabeled sample is positive.
    n_t : int
        Number of test samples for each class.

    Returns
    -------
    x : np.ndarray
        Combined positive and unlabeled data (shape: (n_p + n_u, 2)).
    y : np.ndarray
        Labels for training data (1 for positive, 0 for unlabeled).
    x_t : np.ndarray
        Test data (shape: (2 * n_t, 2)).
    y_t : np.ndarray
        Labels for test data (1 for positive, -1 for negative).
    """
    mu_p = np.array([1.0, 1.0])
    mu_n = np.array([-1.0, -1.0])

    # Positive data
    x_pos = np.random.randn(n_p, 2) + mu_p

    # Unlabeled data
    n_p_u = np.random.binomial(n_u, prior_u)
    n_n_u = n_u - n_p_u
    x_pos_u = np.random.randn(n_p_u, 2) + mu_p
    x_neg_u = np.random.randn(n_n_u, 2) + mu_n

    # Combine data
    x = np.vstack((x_pos, x_pos_u, x_neg_u))
    y = np.hstack((np.ones(n_p), np.zeros(n_u)))

    # Test data
    x_tp = np.random.randn(n_t, 2) + mu_p
    x_tn = np.random.randn(n_t, 2) + mu_n
    x_t = np.vstack((x_tp, x_tn))
    y_t = np.hstack((np.ones(n_t), -np.ones(n_t)))

    return x, y, x_t, y_t


def gen_twonorm_pumil(n_p: int, n_u: int, prior_u: float, n_t: int,
                      bag_size_lo: int = 3, bag_size_hi: int = 10):
    """
    Generate synthetic data for multiple instance learning (MIL) with
    positive-unlabeled bags.

    Parameters
    ----------
    n_p : int
        Number of positive bags.
    n_u : int
        Number of unlabeled bags.
    prior_u : float
        Probability that an unlabeled bag is positive.
    n_t : int
        Number of test bags for each class.
    bag_size_lo : int, optional
        Minimum number of instances per bag.
    bag_size_hi : int, optional
        Maximum number of instances per bag.

    Returns
    -------
    x : list of np.ndarray
        Training bags (each bag is an array of shape (bag_size, 2)).
    y : np.ndarray
        Labels for training bags (1 for positive, 0 for unlabeled).
    x_t : list of np.ndarray
        Test bags.
    y_t : np.ndarray
        Labels for test bags (1 for positive, -1 for negative).
    """
    mu_p = np.array([1.0, 1.0])
    mu_n = np.array([-1.0, -1.0])

    def _sample_bags(n_bags: int, size_dist: np.ndarray, mu: np.ndarray):
        bags = []
        for size in size_dist:
            bag = np.random.randn(size, 2) + mu
            bags.append(bag)
        return bags

    # Sample bag sizes
    sizes_p = np.random.randint(bag_size_lo, bag_size_hi + 1, size=n_p)
    n_up = np.random.binomial(n_u, prior_u)
    n_un = n_u - n_up
    sizes_up = np.random.randint(bag_size_lo, bag_size_hi + 1, size=n_up)
    sizes_un = np.random.randint(bag_size_lo, bag_size_hi + 1, size=n_un)

    # Generate positive bags
    x_pos_bags = _sample_bags(n_p, sizes_p, mu_p)
    x_up_bags = _sample_bags(n_up, sizes_up, mu_p)

    # Generate negative bags
    x_un_bags = _sample_bags(n_un, sizes_un, mu_n)

    # Combine bags and labels
    x = x_pos_bags + x_up_bags + x_un_bags
    y = np.hstack((np.ones(n_p + n_up), np.zeros(n_un)))

    # Test bags
    sizes_tp = np.random.randint(bag_size_lo, bag_size_hi + 1, size=n_t)
    sizes_tn = np.random.randint(bag_size_lo, bag_size_hi + 1, size=n_t)
    x_tp_bags = _sample_bags(n_t, sizes_tp, mu_p)
    x_tn_bags = _sample_bags(n_t, sizes_tn, mu_n)
    x_t = x_tp_bags + x_tn_bags
    y_t = np.hstack((np.ones(n_t), -np.ones(n_t)))

    return x, y, x_t, y_t
