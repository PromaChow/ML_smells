import os
import gym
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.distributions.categorical as cat
from machin.env import Env
from machin import World
from machin.contrib import grad_server_helper
from machin.algorithms import A3C
from torch.multiprocessing import spawn

class Actor(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(4, 128)
        self.fc2 = nn.Linear(128, 128)
        self.out = nn.Linear(128, 2)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        logits = self.out(x)
        dist = cat.Categorical(logits=logits)
        action = dist.sample()
        logp = dist.log_prob(action)
        entropy = dist.entropy()
        return action, logp, entropy

class Critic(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(4, 128)
        self.fc2 = nn.Linear(128, 128)
        self.out = nn.Linear(128, 1)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        value = self.out(x)
        return value

def main(rank, world_size):
    world = World()
    actor = Actor()
    critic = Critic()
    grad_servers = grad_server_helper(Actor, Critic, lr=5e-3)
    loss_fn = nn.MSELoss(reduction="sum")
    a3c = A3C(actor, critic, loss_fn, grad_servers, sync_on_update=False, manual_sync=True)

    env = gym.make("CartPole-v0")
    smoothed_reward = 0.0
    solved_counter = 0

    episode = 0
    while True:
        # synchronize parameters before each episode
        world.sync_parameters()
        state = env.reset()
        episode_reward = 0.0
        trajectories = []

        for step in range(200):
            state_tensor = torch.tensor(state, dtype=torch.float32)
            action, logp, entropy = actor(state_tensor)
            next_state, reward, done, _ = env.step(action.item())
            trajectories.append({
                "state": state,
                "action": action.item(),
                "reward": reward,
                "next_state": next_state,
                "done": done
            })
            state = next_state
            episode_reward += reward
            if done:
                break

        # prepare batch for A3C
        states = torch.tensor([t["state"] for t in trajectories], dtype=torch.float32)
        actions = torch.tensor([t["action"] for t in trajectories], dtype=torch.int64)
        rewards = torch.tensor([t["reward"] for t in trajectories], dtype=torch.float32)
        next_states = torch.tensor([t["next_state"] for t in trajectories], dtype=torch.float32)
        dones = torch.tensor([t["done"] for t in trajectories], dtype=torch.float32)

        values = critic(states).squeeze()
        next_values = critic(next_states).squeeze()
        td_targets = rewards + 0.99 * next_values * (1 - dones)
        advantages = td_targets - values

        actor_loss = -(logp * advantages.detach()).sum()
        critic_loss = F.mse_loss(values, td_targets.detach(), reduction="sum")
        a3c.update(
            actor_loss=actor_loss,
            critic_loss=critic_loss,
            gradients=None  # gradients will be computed by A3C internally
        )

        smoothed_reward = 0.9 * smoothed_reward + 0.1 * episode_reward
        if smoothed_reward > 190:
            solved_counter += 1
        else:
            solved_counter = 0

        if solved_counter >= 5:
            print(f"Rank {rank}: Solved at episode {episode}")
            world.barrier()
            break

        episode += 1
        if episode % 10 == 0 and rank == 0:
            print(f"Rank {rank}: Episode {episode}, Smoothed Reward {smoothed_reward:.2f}")

if __name__ == "__main__":
    world_size = 3
    spawn(main, args=(world_size,), nprocs=world_size, join=True)