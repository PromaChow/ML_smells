import torch
import torch.nn.functional as F

class VAT(ConsistencyRegularization):
    def __init__(self, eps, xi, n_iter, obj_func, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.eps = eps
        self.xi = xi
        self.n_iter = n_iter
        self.obj_func = obj_func

    def __normalize(self, v):
        # Scale to avoid overflow
        idx_list = list(range(1, v.dim()))
        v = v / self.__reduce_max(v, idx_list=idx_list).clamp(min=1e-12)
        # L2 normalization
        return v / (torch.norm(v) + 1e-12)

    def __reduce_max(self, v, idx_list):
        return torch.max(v, dim=idx_list, keepdim=True)[0]

    def __repr__(self):
        return f"VAT(eps={self.eps}, xi={self.xi}, n_iter={self.n_iter}, tau={self.tau})"

    def compute(self, w_data, stu_forward, tea_logits):
        mask = self.gen_mask(tea_logits)
        targets = self.adjust_target(tea_logits)

        d = torch.randn_like(w_data, requires_grad=True)
        for _ in range(self.n_iter):
            x_hat = w_data + self.xi * d
            y = stu_forward(x_hat)
            loss = self.obj_func(y, targets)
            loss.backward(retain_graph=True)
            grad = d.grad
            d = self.__normalize(grad.detach()).requires_grad_(True)
            d.grad.zero_()

        x_hat = w_data + self.eps * d.detach()
        y = stu_forward(x_hat)
        return y, targets, mask