import random
import numpy as np
from dataclasses import dataclass, field
from typing import List

@dataclass
class Entity:
    name: str = ""
    pos: np.ndarray = field(default_factory=lambda: np.zeros(2))
    vel: np.ndarray = field(default_factory=lambda: np.zeros(2))
    color: np.ndarray = field(default_factory=lambda: np.zeros(3))
    collide: bool = False
    movable: bool = True
    size: float = 0.0
    ad: bool = False  # adversary flag
    silent: bool = False
    c: np.ndarray = field(default_factory=lambda: np.zeros(2))

@dataclass
class World:
    dim_c: int = 2
    agents: List[Entity] = field(default_factory=list)
    landmarks: List[Entity] = field(default_factory=list)

class MultiAgentEnvironment:
    def __init__(self, shaped=True, goal_radius=0.1):
        self.world = World(dim_c=2)
        self.shaped = shaped
        self.goal_radius = goal_radius
        self._initialize_world()
        self.reset()

    def _initialize_world(self):
        # Agents
        for i in range(3):
            agent = Entity(
                name=f"agent_{i}",
                collide=False,
                silent=True,
                size=0.15,
                ad=(i == 0)  # first is adversary
            )
            self.world.agents.append(agent)
        # Landmarks
        for i in range(2):
            landmark = Entity(
                name=f"landmark_{i}",
                collide=False,
                movable=False,
                size=0.08
            )
            self.world.landmarks.append(landmark)

    def reset(self):
        # Colors
        self.world.agents[0].color = np.array([0.85, 0.35, 0.35])  # red
        for agent in self.world.agents[1:]:
            agent.color = np.array([0.35, 0.35, 0.85])  # blue
        for landmark in self.world.landmarks:
            landmark.color = np.array([0.15, 0.15, 0.15])  # gray
        goal_landmark = random.choice(self.world.landmarks)
        goal_landmark.color = np.array([0.15, 0.65, 0.15])  # green
        # Assign goal to each agent
        for agent in self.world.agents:
            agent.goal = goal_landmark
        # Random positions
        for entity in self.world.agents + self.world.landmarks:
            entity.pos = np.random.uniform(-1, 1, 2)
            entity.vel = np.zeros(2)
            entity.c = np.zeros(self.world.dim_c)

    def good_agents(self):
        return [a for a in self.world.agents if not a.ad]

    def adversaries(self):
        return [a for a in self.world.agents if a.ad]

    def step(self):
        # Dummy physics: no movement
        pass

    def get_reward(self, agent):
        if agent.ad:
            dist_sq = np.sum((agent.pos - agent.goal.pos) ** 2)
            if self.shaped:
                return -dist_sq
            else:
                return 1.0 if np.sqrt(dist_sq) < self.goal_radius else 0.0
        else:
            # Distance to goal
            dist = np.linalg.norm(agent.pos - agent.goal.pos)
            reward = -dist
            # Penalize if any adversary is close to goal
            for adv in self.adversaries():
                adv_dist = np.linalg.norm(adv.pos - agent.goal.pos)
                if adv_dist < self.goal_radius:
                    reward -= 1.0
            return reward

    def get_observation(self, agent):
        # Relative positions of all landmarks
        rel_landmarks = [landmark.pos - agent.pos for landmark in self.world.landmarks]
        rel_landmark_pos = np.concatenate(rel_landmarks).flatten()
        landmark_colors = np.concatenate([landmark.color for landmark in self.world.landmarks]).flatten()
        # Relative positions of other agents
        other_agents = [a for a in self.world.agents if a is not agent]
        rel_other = [a.pos - agent.pos for a in other_agents]
        rel_other_pos = np.concatenate(rel_other).flatten()
        obs = np.concatenate([rel_landmark_pos, landmark_colors, rel_other_pos])
        if not agent.ad:
            # Include relative goal position
            goal_rel = agent.goal.pos - agent.pos
            obs = np.concatenate([obs, goal_rel])
        return obs

    def episode_reward(self):
        return sum(self.get_reward(a) for a in self.world.agents)

    def episode_observations(self):
        return [self.get_observation(a) for a in self.world.agents]
