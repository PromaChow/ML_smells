import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla
from scipy.sparse.csgraph import laplacian
from sklearn.cluster import SpectralClustering, AgglomerativeClustering as SkAgglomerative
from sklearn.metrics.pairwise import pairwise_kernels
from sklearn.metrics import calinski_harabasz_score
from sklearn.neighbors import kneighbors_graph
from sklearn.utils import check_random_state
from typing import Any, Callable, Iterable, Optional, Union


def boundary_fraction(labels: np.ndarray, W: np.ndarray) -> float:
    """Fraction of weighted edges that cross cluster boundaries."""
    n = labels.size
    mask = labels.reshape(-1, 1) != labels.reshape(1, -1)
    cross_edges = np.sum(W[mask])
    total_edges = np.sum(W)
    return float(cross_edges / total_edges) if total_edges > 0 else 0.0


def _deterministic_vector_sign_flip(vectors: np.ndarray) -> np.ndarray:
    """Flip signs of eigenvectors so that the first non-zero element is positive."""
    for i in range(vectors.shape[1]):
        vec = vectors[:, i]
        idx = np.flatnonzero(vec)
        if idx.size > 0 and vec[idx[0]] < 0:
            vectors[:, i] = -vec
    return vectors


class SPENC(SpectralClustering):
    def __init__(
        self,
        n_clusters: int = 2,
        affinity: str = "rbf",
        gamma: Optional[float] = None,
        kernel_params: Optional[dict] = None,
        spatial_weight: Optional[np.ndarray] = None,
        n_neighbors: int = 5,
        cut_method: str = "median",
        floor: int = 2,
        floor_weights: Optional[float] = None,
        delta: float = 0.5,
        random_state: Optional[Union[int, np.random.RandomState]] = None,
        **kwargs: Any,
    ):
        super().__init__(n_clusters=n_clusters, affinity="precomputed", **kwargs)
        self.affinity = affinity
        self.gamma = gamma
        self.kernel_params = kernel_params or {}
        self.spatial_weight = spatial_weight
        self.n_neighbors = n_neighbors
        self.cut_method = cut_method
        self.floor = floor
        self.floor_weights = floor_weights
        self.delta = delta
        self.random_state = check_random_state(random_state)

    def _build_affinity(self, X: np.ndarray) -> sp.csr_matrix:
        if self.affinity == "nearest_neighbors":
            aff = kneighbors_graph(X, self.n_neighbors, mode="connectivity", include_self=True)
            aff = sp.csr_matrix(aff)
        elif self.affinity == "precomputed":
            aff = sp.csr_matrix(X)
        else:
            aff = pairwise_kernels(X, metric=self.affinity, gamma=self.gamma, **self.kernel_params)
            aff = sp.csr_matrix(aff)

        if self.spatial_weight is not None:
            W = sp.csr_matrix(self.spatial_weight)
            aff = aff.multiply(W)
        return aff

    def _embed(self, A: sp.csr_matrix) -> np.ndarray:
        L = laplacian(A, normed=True)
        n_samples = A.shape[0]
        k = self.n_clusters
        try:
            eigvals, eigvecs = spla.eigsh(L, k=k, which="SM")
        except Exception:
            eigvals, eigvecs = spla.eigsh(L, k=k, which="LA")
        # Normalize rows
        norm = np.linalg.norm(eigvecs, axis=1, keepdims=True)
        norm[norm == 0] = 1
        embedding = eigvecs / norm
        embedding = _deterministic_vector_sign_flip(embedding)
        return embedding

    def _spectral_bipartition(self, A: sp.csr_matrix, labels: np.ndarray, depth: int = 0) -> np.ndarray:
        if depth >= self.n_clusters - 1 or A.shape[0] <= self.floor:
            return labels
        L = laplacian(A, normed=True)
        try:
            _, eigvecs = spla.eigsh(L, k=2, which="SM")
        except Exception:
            _, eigvecs = spla.eigsh(L, k=2, which="LA")
        vec = eigvecs[:, 1]
        if self.cut_method == "zero":
            threshold = 0.0
        elif self.cut_method == "median":
            threshold = np.median(vec)
        else:  # gridsearch placeholder
            threshold = np.median(vec)
        part1 = vec >= threshold
        part2 = ~part1
        if part1.sum() < self.floor or part2.sum() < self.floor:
            return labels
        new_labels = labels.copy()
        new_labels[part1] = self.n_clusters + depth
        new_labels[part2] = self.n_clusters + depth
        idx1 = np.where(part1)[0]
        idx2 = np.where(part2)[0]
        A1 = A[idx1][:, idx1]
        A2 = A[idx2][:, idx2]
        new_labels = self._spectral_bipartition(A1, new_labels[idx1], depth + 1)
        new_labels = self._spectral_bipartition(A2, new_labels[idx2], depth + 1)
        return new_labels

    def fit(self, X: np.ndarray, y: Optional[np.ndarray] = None) -> "SPENC":
        self.A_ = self._build_affinity(X)
        embedding = self._embed(self.A_)
        # Use KMeans on embedding as in SpectralClustering
        from sklearn.cluster import KMeans

        kmeans = KMeans(n_clusters=self.n_clusters, random_state=self.random_state)
        self.labels_ = kmeans.fit_predict(embedding)
        return self

    def score(self, X: np.ndarray, y: Optional[np.ndarray] = None) -> float:
        attr_score = calinski_harabasz_score(X, self.labels_)
        spatial_score = boundary_fraction(self.labels_, self.spatial_weight or np.ones((X.shape[0], X.shape[0])))
        return self.delta * attr_score + (1 - self.delta) * spatial_score

    def sample(
        self,
        X: np.ndarray,
        n_samples: int = 10,
        dist_func: Callable[[int, np.random.RandomState], np.ndarray] = None,
    ) -> Iterable[np.ndarray]:
        dist_func = dist_func or (lambda n, rs: rs.normal(size=n))
        for _ in range(n_samples):
            weights = dist_func(X.shape[0], self.random_state)
            W_rand = sp.diags(weights)
            A_rand = self._build_affinity(X).multiply(W_rand)
            self.A_ = A_rand
            embedding = self._embed(A_rand)
            from sklearn.cluster import KMeans

            kmeans = KMeans(n_clusters=self.n_clusters, random_state=self.random_state)
            labels = kmeans.fit_predict(embedding)
            yield labels

    def _sample_gen(self, X: np.ndarray, n_samples: int = 10) -> Iterable[np.ndarray]:
        return self.sample(X, n_samples)


class AgglomerativeClustering(SkAgglomerative):
    def __init__(
        self,
        n_clusters: int = 2,
        affinity: str = "euclidean",
        linkage: str = "ward",
        random_state: Optional[Union[int, np.random.RandomState]] = None,
        **kwargs: Any,
    ):
        super().__init__(
            n_clusters=n_clusters, affinity=affinity, linkage=linkage, **kwargs
        )
        self.random_state = check_random_state(random_state)

    def sample(
        self,
        X: np.ndarray,
        n_samples: int = 10,
        dist_func: Callable[[int, np.random.RandomState], np.ndarray] = None,
    ) -> Iterable[np.ndarray]:
        dist_func = dist_func or (lambda n, rs: rs.normal(size=n))
        for _ in range(n_samples):
            weights = dist_func(X.shape[0], self.random_state)
            W_rand = sp.diags(weights)
            A_rand = W_rand @ X
            # Recreate clusterer with perturbed data
            clusterer = SkAgglomerative(
                n_clusters=self.n_clusters,
                affinity=self.affinity,
                linkage=self.linkage,
            )
            clusterer.fit(A_rand)
            yield clusterer.labels_

    def _sample_gen(self, X: np.ndarray, n_samples: int = 10) -> Iterable[np.ndarray]:
        return self.sample(X, n_samples)