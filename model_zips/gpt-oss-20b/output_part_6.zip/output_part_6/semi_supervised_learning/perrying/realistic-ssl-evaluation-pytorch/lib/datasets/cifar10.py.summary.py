import numpy as np
from pathlib import Path
from typing import Any, Tuple

class Cifar10Dataset:
    """
    Dataset loader for a preprocessed CIFAR-10 NumPy file.
    The file is expected to be located at <root>/cifar10/<split>.npy
    and contain a dictionary with keys "images" and "labels".
    """

    def __init__(self, root: str, split: str = "l_train") -> None:
        """
        Initialize the dataset.

        Parameters
        ----------
        root : str
            The base directory containing the "cifar10" subdirectory.
        split : str, default "l_train"
            The dataset split name, used to form the .npy filename.
        """
        file_path = Path(root) / "cifar10" / f"{split}.npy"
        self.dataset: dict[str, Any] = np.load(file_path, allow_pickle=True)

    def __len__(self) -> int:
        """Return the number of samples in the dataset."""
        return len(self.dataset["images"])

    def __getitem__(self, index: int) -> Tuple[Any, Any]:
        """Retrieve the image and label at the given index."""
        image = self.dataset["images"][index]
        label = self.dataset["labels"][index]
        return image, label

if __name__ == "__main__":
    # Example usage
    dataset = Cifar10Dataset(root="data", split="l_train")
    print(f"Dataset size: {len(dataset)}")
    sample_image, sample_label = dataset[0]
    print(f"Sample label: {sample_label}")