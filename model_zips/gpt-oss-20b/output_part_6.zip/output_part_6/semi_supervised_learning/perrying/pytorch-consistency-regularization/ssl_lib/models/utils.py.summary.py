import math
import torch
import torch.nn as nn
import torch.nn.functional as F


def conv3x3(in_channels, out_channels, stride=1, bias=False):
    return nn.Conv2d(
        in_channels,
        out_channels,
        kernel_size=3,
        stride=stride,
        padding=1,
        bias=bias
    )


def leaky_relu():
    return nn.LeakyReLU(negative_slope=0.1, inplace=True)


class BatchNorm2d(nn.BatchNorm2d):
    def __init__(self, num_features, eps=1e-5, momentum=0.1, affine=True, track_running_stats=True):
        super().__init__(num_features, eps, momentum, affine, track_running_stats)
        self.update_batch_stats = True

    def forward(self, input):
        if self.update_batch_stats:
            return super().forward(input)
        else:
            return F.batch_norm(
                input,
                self.running_mean,
                self.running_var,
                self.weight,
                self.bias,
                training=False,
                momentum=0.0
            )


class BaseModel(nn.Module):
    def __init__(self, feature_extractor, classifier):
        super().__init__()
        self.feature_extractor = feature_extractor
        self.classifier = classifier

    def forward(self, x):
        features = self.feature_extractor(x)
        pooled = F.adaptive_avg_pool2d(features, (1, 1))
        pooled = pooled.view(pooled.size(0), -1)
        logits = self.classifier(pooled)
        return logits

    def logits_with_feature(self, x):
        features = self.feature_extractor(x)
        pooled = F.adaptive_avg_pool2d(features, (1, 1))
        pooled = pooled.view(pooled.size(0), -1)
        logits = self.classifier(pooled)
        return logits, features

    def update_batch_stats(self, flag: bool):
        for m in self.modules():
            if isinstance(m, BatchNorm2d):
                m.update_batch_stats = flag


def apply_weight_decay(model: nn.Module, weight_decay_factor: float):
    if weight_decay_factor == 0.0:
        return
    for m in model.modules():
        if isinstance(m, (nn.Conv2d, nn.Linear)):
            m.weight.data.mul_(1.0 - weight_decay_factor)


def param_init(model: nn.Module):
    for m in model.modules():
        if isinstance(m, nn.Conv2d):
            k = m.kernel_size[0]
            f = m.in_channels
            std = 1.0 / math.sqrt(0.5 * k * k * f)
            nn.init.normal_(m.weight, mean=0.0, std=std)
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, nn.Linear):
            nn.init.xavier_uniform_(m.weight)
            if m.bias is not None:
                nn.init.zeros_(m.bias)


def __ema(x, y, factor):
    return factor * x + (1.0 - factor) * y


def __param_update(ema_model: nn.Module, raw_model: nn.Module, factor: float):
    for ema_param, raw_param in zip(ema_model.parameters(), raw_model.parameters()):
        ema_param.data.copy_(__ema(ema_param.data, raw_param.data, factor))


def __buffer_update(ema_model: nn.Module, raw_model: nn.Module, factor: float):
    for ema_buffer, raw_buffer in zip(ema_model.buffers(), raw_model.buffers()):
        if ema_buffer is None:
            continue
        ema_buffer.data.copy_(__ema(ema_buffer.data, raw_buffer.data, factor))


def ema_update(
    ema_model: nn.Module,
    raw_model: nn.Module,
    global_step: int,
    ema_factor: float,
    weight_decay_factor: float = 0.0
):
    """
    Update EMA model parameters and buffers.

    Args:
        ema_model: The model holding the EMA weights.
        raw_model: The model being trained.
        global_step: Current training step.
        ema_factor: The maximum EMA factor.
        weight_decay_factor: Optional weight decay to apply to EMA weights.
    """
    # Adjust EMA factor based on global step
    step_factor = 1.0 - 1.0 / (global_step + 1)
    factor = min(ema_factor, step_factor)

    __param_update(ema_model, raw_model, factor)
    __buffer_update(ema_model, raw_model, factor)

    if weight_decay_factor > 0.0:
        apply_weight_decay(ema_model, weight_decay_factor)