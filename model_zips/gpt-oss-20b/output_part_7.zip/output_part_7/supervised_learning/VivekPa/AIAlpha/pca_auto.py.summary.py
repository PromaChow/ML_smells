import os
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier
from tensorflow.keras import Input, Model
from tensorflow.keras.layers import Dense

class DataProcessing:
    def __init__(self, window_size):
        self.window_size = window_size

    def generate_features(self, df):
        if 'label' not in df.columns:
            raise ValueError("DataFrame must contain a 'label' column.")
        feature_cols = [c for c in df.columns if c != 'label']
        X = []
        y = []
        for i in range(len(df) - self.window_size + 1):
            window = df.iloc[i:i + self.window_size]
            X.append(window[feature_cols].values.flatten())
            y.append(window['label'].iloc[-1])
        return np.array(X), np.array(y)

    def split_train_test(self, X, y, test_ratio=0.2):
        split = int(len(X) * (1 - test_ratio))
        return X[:split], y[:split], X[split:], y[split:]

    def process_and_save(self, df, method):
        X, y = self.generate_features(df)
        X_train, y_train, X_test, y_test = self.split_train_test(X, y)
        out_dir = Path('autoencoder_data')
        out_dir.mkdir(parents=True, exist_ok=True)
        np.savetxt(out_dir / f'{method}_full_x.csv', X, delimiter=',')
        np.savetxt(out_dir / f'{method}_full_y.csv', y, delimiter=',', fmt='%d')
        np.savetxt(out_dir / f'{method}_train_x.csv', X_train, delimiter=',')
        np.savetxt(out_dir / f'{method}_train_y.csv', y_train, delimiter=',', fmt='%d')
        np.savetxt(out_dir / f'{method}_test_x.csv', X_test, delimiter=',')
        np.savetxt(out_dir / f'{method}_test_y.csv', y_test, delimiter=',', fmt='%d')

class AutoEncoder:
    def __init__(self, input_dim, latent_dim=20):
        self.input_dim = input_dim
        self.latent_dim = latent_dim
        self.model = None
        self.encoder = None

    def build(self):
        inputs = Input(shape=(self.input_dim,))
        x = Dense(100, activation='relu')(inputs)
        x = Dense(50, activation='relu')(x)
        latent = Dense(self.latent_dim, activation='relu')(x)
        x = Dense(50, activation='relu')(latent)
        x = Dense(100, activation='relu')(x)
        outputs = Dense(self.input_dim, activation='linear')(x)
        self.model = Model(inputs, outputs)
        self.encoder = Model(inputs, latent)
        self.model.compile(optimizer='adam', loss='mse')

    def train(self, X, epochs=20, batch_size=32):
        self.model.fit(X, X, epochs=epochs, batch_size=batch_size, verbose=0)

    def encode(self, X):
        return self.encoder.predict(X)

class RFModel:
    def __init__(self, n_estimators=100):
        self.model = RandomForestClassifier(n_estimators=n_estimators, random_state=42)

    def train(self, X, y):
        self.model.fit(X, y)

    def predict(self, X):
        return self.model.predict(X)

def scale_data(X, scaler=None):
    if scaler is None:
        scaler = MinMaxScaler(feature_range=(-1, 1))
        X_scaled = X.copy()
        if X.shape[1] > 1:
            X_scaled[:, 1:] = scaler.fit_transform(X[:, 1:])
        else:
            X_scaled[:, 0] = scaler.fit_transform(X[:, 0].reshape(-1, 1)).flatten()
        return X_scaled, scaler
    else:
        X_scaled = X.copy()
        if X.shape[1] > 1:
            X_scaled[:, 1:] = scaler.transform(X[:, 1:])
        else:
            X_scaled[:, 0] = scaler.transform(X[:, 0].reshape(-1, 1)).flatten()
        return X_scaled

def main():
    methods = ['tick', 'volume', 'dollar']
    preprocess_results = {}
    scalers = {}

    for method in methods:
        df_path = Path('price_bars') / f'{method}_bars.csv'
        df = pd.read_csv(df_path)
        dp = DataProcessing(window_size=20)
        dp.process_and_save(df, method)

        train_x = np.loadtxt(Path('autoencoder_data') / f'{method}_train_x.csv', delimiter=',')
        train_y = np.loadtxt(Path('autoencoder_data') / f'{method}_train_y.csv', delimiter=',')
        test_x = np.loadtxt(Path('autoencoder_data') / f'{method}_test_x.csv', delimiter=',')
        test_y = np.loadtxt(Path('autoencoder_data') / f'{method}_test_y.csv', delimiter=',')

        train_x_scaled, scaler = scale_data(train_x)
        test_x_scaled = scale_data(test_x, scaler=scaler)
        scalers[method] = scaler

        pca = PCA(n_components=20)
        train_pca = pca.fit_transform(train_x_scaled)
        test_pca = pca.transform(test_x_scaled)

        pca_scaler = MinMaxScaler(feature_range=(-1, 1))
        train_pca_scaled = pca_scaler.fit_transform(train_pca)
        test_pca_scaled = pca_scaler.transform(test_pca)

        preprocess_results[method] = {
            'train_pca': train_pca_scaled,
            'test_pca': test_pca_scaled
        }

        ae = AutoEncoder(input_dim=train_x_scaled.shape[1], latent_dim=20)
        ae.build()
        ae.train(train_x_scaled)

        full_x_path = Path('autoencoder_data') / f'{method}_full_x.csv'
        full_y_path = Path('autoencoder_data') / f'{method}_full_y.csv'
        full_x = np.loadtxt(full_x_path, delimiter=',')
        full_x_scaled = scale_data(full_x, scaler=scaler)
        encoded_full = ae.encode(full_x_scaled)

        nn_dir = Path('nn_data')
        nn_dir.mkdir(parents=True, exist_ok=True)
        np.savetxt(nn_dir / f'{method}_full_x_encoded.csv', encoded_full, delimiter=',')

        full_y = np.loadtxt(full_y_path, delimiter=',')

        dp2 = DataProcessing(window_size=1)
        X_train_rf, y_train_rf, X_test_rf, y_test_rf = dp2.split_train_test(encoded_full, full_y)

        rf_dir = Path('rf_data')
        rf_dir.mkdir(parents=True, exist_ok=True)
        np.savetxt(rf_dir / f'{method}_train_x.csv', X_train_rf, delimiter=',')
        np.savetxt(rf_dir / f'{method}_train_y.csv', y_train_rf, delimiter=',', fmt='%d')
        np.savetxt(rf_dir / f'{method}_test_x.csv', X_test_rf, delimiter=',')
        np.savetxt(rf_dir / f'{method}_test_y.csv', y_test_rf, delimiter=',', fmt='%d')

    for method in methods:
        X_train_rf = np.loadtxt(Path('rf_data') / f'{method}_train_x.csv', delimiter=',')
        y_train_rf = np.loadtxt(Path('rf_data') / f'{method}_train_y.csv', delimiter=',')
        X_test_rf = np.loadtxt(Path('rf_data') / f'{method}_test_x.csv', delimiter=',')
        y_test_rf = np.loadtxt(Path('rf_data') / f'{method}_test_y.csv', delimiter=',')

        scaler_rf = MinMaxScaler(feature_range=(-1, 1))
        X_train_rf_scaled = scale_data(X_train_rf, scaler=scaler_rf)
        X_test_rf_scaled = scale_data(X_test_rf, scaler=scaler_rf)

        n_estimators = 300 if method == 'dollar' else 100
        rf_encoded = RFModel(n_estimators=n_estimators)
        rf_encoded.train(X_train_rf_scaled, y_train_rf)
        y_pred_encoded = rf_encoded.predict(X_test_rf_scaled)
        acc_encoded = (y_pred_encoded == y_test_rf).mean()

        X_train_pca = preprocess_results[method]['train_pca']
        X_test_pca = preprocess_results[method]['test_pca']
        rf_pca = RFModel(n_estimators=n_estimators)
        rf_pca.train(X_train_pca, y_train_rf)
        y_pred_pca = rf_pca.predict(X_test_pca)
        acc_pca = (y_pred_pca == y_test_rf).mean()

        print(f'Method: {method}')
        print(f'  RF on encoded data accuracy: {acc_encoded:.4f}')
        print(f'  RF on PCA data accuracy:    {acc_pca:.4f}')

if __name__ == "__main__":
    main()
