import numpy as np
import gym
from gym import ActionWrapper

class ClipAction(ActionWrapper):
    def action(self, action):
        return np.clip(action, self.action_space.low, self.action_space.high)

def test_clip_action():
    env_orig = gym.make("MountainCarContinuous-v0")
    env_wrapped = gym.make("MountainCarContinuous-v0")
    env_wrapped = ClipAction(env_wrapped)

    # Reset environments
    try:
        env_orig.reset()
    except TypeError:
        env_orig.reset()
    try:
        env_wrapped.reset()
    except TypeError:
        env_wrapped.reset()

    action = [10000.0]
    _, reward_orig, _, _ = env_orig.step(action)
    _, reward_clipped, _, _ = env_wrapped.step(action)

    assert abs(reward_clipped) < abs(reward_orig), "Clipped reward should have smaller magnitude"

    env_orig.close()
    env_wrapped.close()

if __name__ == "__main__":
    test_clip_action()
