import numpy as np
from sklearn.feature_extraction.text import CountVectorizer


def _combine_embeddings(embeddings, operation, friend_val=None):
    arr = np.vstack(embeddings)
    if operation == "sum":
        combined = np.sum(arr, axis=0)
    elif operation == "max":
        combined = np.max(arr, axis=0)
    elif operation == "min":
        combined = np.min(arr, axis=0)
    elif operation == "avg":
        combined = np.mean(arr, axis=0)
    elif operation == "conc":
        combined = np.concatenate(
            (np.max(arr, axis=0), np.min(arr, axis=0), np.mean(arr, axis=0))
        )
    else:
        raise ValueError(f"Unsupported operation: {operation}")

    if friend_val is not None:
        friend_arr = np.array(friend_val)
        if friend_arr.ndim == 0:
            friend_arr = friend_arr.reshape(1)
        combined = np.concatenate([combined, friend_arr])
    return combined


def transformTextForTraining(
    embed_dictionary,
    length_threshold,
    documents,
    y_O,
    y_C,
    y_E,
    y_A,
    y_N,
    operation,
    FastText=False,
    friends=None,
):
    if isinstance(documents, str):
        documents = [documents]
        single_input = True
    else:
        single_input = False

    vectorizer = CountVectorizer()
    analyzer = vectorizer.build_analyzer()

    text_embeddings = []
    y_O_keep = []
    y_C_keep = []
    y_E_keep = []
    y_A_keep = []
    y_N_keep = []
    friends_keep = []

    for idx, doc in enumerate(documents):
        tokens = analyzer(doc)
        if len(tokens) < length_threshold and not single_input:
            continue

        doc_embeddings = []
        for token in tokens:
            embed = embed_dictionary.get(token)
            if embed is None:
                continue
            if FastText and isinstance(embed, str):
                parts = embed.split()
                if len(parts) <= 1:
                    continue
                values = np.array([float(p) for p in parts[:-1]])
                doc_embeddings.append(values)
            else:
                doc_embeddings.append(np.array(embed))

        if not doc_embeddings:
            if single_input:
                return False
            continue

        combined = _combine_embeddings(
            doc_embeddings,
            operation,
            friend_val=friends[idx] if friends is not None else None,
        )
        text_embeddings.append(combined)
        y_O_keep.append(y_O[idx])
        y_C_keep.append(y_C[idx])
        y_E_keep.append(y_E[idx])
        y_A_keep.append(y_A[idx])
        y_N_keep.append(y_N[idx])
        if friends is not None:
            friends_keep.append(friends[idx])

    if not text_embeddings:
        if single_input:
            return False
        else:
            return np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([]), np.array([])

    text_embeddings = np.vstack(text_embeddings)
    y_O_keep = np.array(y_O_keep)
    y_C_keep = np.array(y_C_keep)
    y_E_keep = np.array(y_E_keep)
    y_A_keep = np.array(y_A_keep)
    y_N_keep = np.array(y_N_keep)
    if friends is not None:
        friends_keep = np.array(friends_keep)
        return text_embeddings, y_O_keep, y_C_keep, y_E_keep, y_A_keep, y_N_keep, friends_keep
    else:
        return text_embeddings, y_O_keep, y_C_keep, y_E_keep, y_A_keep, y_N_keep


def transformTextForTesting(
    embed_dictionary,
    length_threshold,
    documents,
    operation,
    FastText=False,
):
    if isinstance(documents, str):
        documents = [documents]

    vectorizer = CountVectorizer()
    analyzer = vectorizer.build_analyzer()

    text_embeddings = []

    for doc in documents:
        tokens = analyzer(doc)
        if len(tokens) < length_threshold:
            continue

        doc_embeddings = []
        for token in tokens:
            embed = embed_dictionary.get(token)
            if embed is None:
                continue
            if FastText and isinstance(embed, str):
                parts = embed.split()
                if len(parts) <= 1:
                    continue
                values = np.array([float(p) for p in parts[:-1]])
                doc_embeddings.append(values)
            else:
                doc_embeddings.append(np.array(embed))

        if not doc_embeddings:
            continue

        combined = _combine_embeddings(doc_embeddings, operation)
        text_embeddings.append(combined)

    if not text_embeddings:
        raise ValueError("No valid embeddings generated for any document.")

    return np.vstack(text_embeddings)