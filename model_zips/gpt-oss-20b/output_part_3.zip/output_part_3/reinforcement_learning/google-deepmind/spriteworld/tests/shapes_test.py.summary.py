import math
from PIL import Image, ImageDraw
from absl.testing import absltest, parameterized
import spriteworld.shapes as shapes


class TestShapeAreas(parameterized.TestCase):
    IMAGE_SIZE = 1000
    DESIRED_AREA = 0.25 * (IMAGE_SIZE ** 2) * 3
    TOLERANCE = 1e-2

    def _test_area(self, path):
        img = Image.new("L", (self.IMAGE_SIZE, self.IMAGE_SIZE), 0)
        draw = ImageDraw.Draw(img)
        draw.polygon(path, fill=1)
        true_area = sum(img.getdata())
        ratio = self.DESIRED_AREA / true_area
        self.assertAlmostEqual(ratio, 1.0, delta=self.TOLERANCE)

    def testPolygon(self):
        for num_sides in range(3, 11):
            with self.subTest(num_sides=num_sides):
                path = shapes.polygon(num_sides)
                self._test_area(path)

    @parameterized.named_parameters(
        ("star_5_0.5", 5, 0.5),
        ("star_6_0.6", 6, 0.6),
        ("star_7_0.4", 7, 0.4),
    )
    def testStar(self, num_sides, point_height):
        path = shapes.star(num_sides, point_height)
        self._test_area(path)

    @parameterized.named_parameters(
        ("spokes_5_0.4", 5, 0.4),
        ("spokes_6_0.5", 6, 0.5),
        ("spokes_7_0.6", 7, 0.6),
    )
    def testSpokes(self, num_sides, spoke_height):
        path = shapes.star(num_sides, spoke_height)
        self._test_area(path)


if __name__ == "__main__":
    absltest.main()
