import tensorflow as tf


class StreamingMean:
    def __init__(self, shape, dtype):
        self._shape = shape
        self._dtype = dtype
        self._sum = tf.Variable(tf.zeros(shape, dtype=dtype), trainable=False, dtype=dtype)
        self._count = tf.Variable(0, dtype=tf.int64, trainable=False)

    def submit(self, value: tf.Tensor):
        if value.shape.rank == len(self._shape):
            value = tf.expand_dims(value, axis=0)
        sum_batch = tf.reduce_sum(value, axis=0)
        self._sum.assign_add(sum_batch)
        batch_count = tf.shape(value)[0]
        self._count.assign_add(tf.cast(batch_count, tf.int64))

    @property
    def value(self) -> tf.Tensor:
        return self._sum / tf.cast(self._count, dtype=self._dtype)

    def clear(self):
        mean_val = self.value
        with tf.control_dependencies([mean_val]):
            self._sum.assign(tf.zeros_like(self._sum))
            self._count.assign(0)
        return mean_val
