import numpy as np

def compute_returns_and_advantages(buffer, last_value):
    """
    Computes returns and advantages for a rollout buffer using GAE.
    
    Parameters
    ----------
    buffer : object
        An object containing the following attributes:
            - values (np.ndarray): Value estimates for each timestep.
            - advantages (np.ndarray): Array to store computed advantages.
            - returns (np.ndarray): Array to store computed returns.
            - dones (np.ndarray of bool): Done flags for each timestep.
            - rewards (np.ndarray): Rewards received at each timestep.
            - gamma (float): Discount factor.
            - gae_lambda (float): GAE lambda parameter.
            - use_gae (bool): Flag indicating whether to use GAE.
            - buffer_size (int): Number of timesteps in the buffer.
    last_value : np.ndarray or scalar
        Value estimate for the state following the last transition in the buffer.
    """
    # 1. Initialization
    last_value = np.reshape(last_value, (-1,))
    gae_lambda = buffer.gae_lambda if buffer.use_gae else 1.0

    # 2. Variable Setup
    next_values = last_value
    next_non_terminal = 1.0 - buffer.dones.astype(float)

    running_advantage = 0.0

    # 3. Reverse Iteration Over Buffer
    for step in reversed(range(buffer.buffer_size)):
        reward = buffer.rewards[step]
        gamma = buffer.gamma
        current_value = buffer.values[step]
        delta = reward + gamma * next_non_terminal * next_values - current_value

        # 5. Running Advantage Update
        running_advantage = delta + gamma * gae_lambda * running_advantage

        # 6. State Updates
        next_non_terminal = 1.0 - buffer.dones[step]
        next_values = buffer.values[step]

        # 7. Storing Advantages
        buffer.advantages[step] = running_advantage

    # 8. Returns Calculation
    buffer.returns = buffer.advantages + buffer.values
    return buffer
