import os
import re
from typing import List, Tuple

import nltk
from nltk import sent_tokenize, word_tokenize
from nltk.stem.snowball import SnowballStemmer
from gensim import corpora, models
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Ensure necessary NLTK data is available
nltk.download("punkt")
nltk.download("stopwords")


def read_sentiment_words(folder_path: str) -> Tuple[List[str], List[str]]:
    """Load positive and negative words from text files."""
    positive_path = os.path.join(folder_path, "positive.txt")
    negative_path = os.path.join(folder_path, "negative.txt")

    with open(positive_path, "r", encoding="utf-8") as f:
        positive_words = [line.strip() for line in f if line.strip()]

    with open(negative_path, "r", encoding="utf-8") as f:
        negative_words = [line.strip() for line in f if line.strip()]

    return positive_words, negative_words


def filter_sentiment_words(
    book_word_list: List[List[str]],
    positive_words: List[str],
    negative_words: List[str],
) -> Tuple[List[str], List[str]]:
    """Filter positive and negative words from a list of books."""
    positive_filtered = []
    negative_filtered = []

    positive_set = set(positive_words)
    negative_set = set(negative_words)

    for book in book_word_list:
        for word in book:
            if word in positive_set:
                positive_filtered.append(word)
            if word in negative_set:
                negative_filtered.append(word)

    return positive_filtered, negative_filtered


def lda_topic_modeling(content: List[List[str]], topic_count: int):
    """Build an LDA model from tokenized documents."""
    dictionary = corpora.Dictionary(content)
    corpus = [dictionary.doc2bow(doc) for doc in content]
    lda_model = models.LdaModel(
        corpus,
        id2word=dictionary,
        num_topics=topic_count,
        passes=10,
        random_state=42,
    )
    return lda_model


def tokenize_and_stem(text: str) -> List[str]:
    """Tokenize, filter non-alphabetic tokens, and stem."""
    stemmer = SnowballStemmer("english")
    tokens = []

    for sentence in sent_tokenize(text):
        words = word_tokenize(sentence)
        for word in words:
            word = word.lower()
            if re.search("[a-zA-Z]", word):
                stemmed = stemmer.stem(word)
                tokens.append(stemmed)

    return tokens


def compute_cosine_similarity(
    content_as_str: List[str],
) -> Tuple:
    """Generate TF-IDF matrix and cosine similarity matrix."""
    vectorizer = TfidfVectorizer(
        max_df=0.8,
        min_df=0.2,
        max_features=200000,
        stop_words="english",
        use_idf=True,
        ngram_range=(1, 3),
        tokenizer=tokenize_and_stem,
    )
    tfidf_matrix = vectorizer.fit_transform(content_as_str)
    similarity_matrix = cosine_similarity(tfidf_matrix)
    return similarity_matrix, tfidf_matrix


# Example usage (uncomment to run):
# if __name__ == "__main__":
#     folder = "sentiment_files"
#     pos_words, neg_words = read_sentiment_words(folder)
#     books = [
#         ["happy", "sad", "joyful"],
#         ["terrible", "good", "bad"],
#     ]
#     pos_filtered, neg_filtered = filter_sentiment_words(books, pos_words, neg_words)
#     lda = lda_topic_modeling(books, topic_count=5)
#     texts = ["This is a happy day.", "I feel sad."]
#     sim_matrix, tfidf = compute_cosine_similarity(texts)