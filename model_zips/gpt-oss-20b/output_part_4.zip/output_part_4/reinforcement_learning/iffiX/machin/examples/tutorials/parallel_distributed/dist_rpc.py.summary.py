import time
import torch.multiprocessing as mp

# Assume the `machin` library provides the following API
# from machin import World, Group
import machin

class WorkerService:
    def __init__(self, counter):
        self.counter = counter

    def increment(self):
        with self.counter.get_lock():
            self.counter.value += 1
            return self.counter.value

    def get_count(self):
        with self.counter.get_lock():
            return self.counter.value

def worker(rank, world_size, counter):
    if rank == 0:
        world = machin.World(world_size=world_size, rank=rank, name=f"world_{rank}")
        service = WorkerService(counter)
        service.counter.value = 20

        group = world.create_group(name="group", ranks=[0, 1])
        group.pair(key="value", value=service.counter)
        group.register("count", service.increment)
        group.register("get_count", service.get_count)

        time.sleep(4)
        assert service.counter.value == 23, f"Counter is {service.counter.value}, expected 23"

        group.unregister("count")
        group.unregister("get_count")
        group.unpair("value")
        time.sleep(4)
        group.destroy()

    elif rank == 1:
        world = machin.World(world_size=world_size, rank=rank, name=f"world_{rank}")
        group = world.create_group(name="group", ranks=[0, 1])

        time.sleep(0.5)
        assert group.is_registered("count"), "Method 'count' not registered"
        assert group.is_registered("get_count"), "Method 'get_count' not registered"

        # Synchronous call
        val_sync = group.call("count", sync=True)
        assert val_sync == 21, f"Sync call returned {val_sync}, expected 21"

        # Asynchronous call
        async_future = group.call("count", sync=False)
        val_async = async_future.result()
        assert val_async == 22, f"Async call returned {val_async}, expected 22"

        # Remote call
        val_remote = group.call_remote("count")
        assert val_remote == 23, f"Remote call returned {val_remote}, expected 23"

        time.sleep(4)
        assert not group.is_registered("count"), "Method 'count' still registered after cleanup"
        group.destroy()

    else:
        # Rank 2 does nothing in this example
        pass

if __name__ == "__main__":
    world_size = 3
    counter = mp.Value("i", 0)
    mp.spawn(
        worker,
        args=(world_size, counter),
        nprocs=world_size,
        join=True
    )