import pandas as pd

df = pd.read_csv('HollywoodMovies.csv')

# Filter movies with Story equal to 'Quest'
quest_movies = df[df['Story'] == 'Quest']

# Find the maximum RottenTomatoes score among Quest movies
max_rating = quest_movies['RottenTomatoes'].max()

# Find all movies in the entire dataset with this maximum score
top_movies = df[df['RottenTomatoes'] == max_rating]

print(top_movies)