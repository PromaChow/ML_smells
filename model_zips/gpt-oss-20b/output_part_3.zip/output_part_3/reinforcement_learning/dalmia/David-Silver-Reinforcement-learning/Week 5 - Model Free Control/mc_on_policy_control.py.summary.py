import gym
import numpy as np
import matplotlib.pyplot as plt
from collections import defaultdict

def make_epsilon_greedy_policy(Q, epsilon, nA):
    """
    Return a function that takes a state and returns a probability distribution over actions.
    """
    def policy_fn(state):
        if state not in Q:
            Q[state] = np.zeros(nA)
        action_probabilities = np.ones(nA) * epsilon / nA
        best_action = np.argmax(Q[state])
        action_probabilities[best_action] += (1.0 - epsilon)
        return action_probabilities
    return policy_fn

def mc_control_epsilon_greedy(env, num_episodes, gamma=1.0, epsilon_start=0.1, epsilon_min=0.01):
    """
    First-visit MC control with epsilon-greedy policy and GLIE epsilon schedule.
    """
    nA = env.action_space.n
    Q = defaultdict(lambda: np.zeros(nA))
    returns_count = defaultdict(int)

    # Initial policy
    epsilon = epsilon_start
    policy = make_epsilon_greedy_policy(Q, epsilon, nA)

    for episode in range(num_episodes):
        # GLIE schedule
        epsilon = max(epsilon_min, epsilon_start / (episode + 1))
        policy = make_epsilon_greedy_policy(Q, epsilon, nA)

        # Reset environment
        state = env.reset()
        if isinstance(state, tuple):
            state = state[0]
        episode_history = []
        done = False

        while not done:
            action_probs = policy(state)
            action = np.random.choice(np.arange(nA), p=action_probs)
            step_result = env.step(action)
            if len(step_result) == 5:  # gymnasium
                next_state, reward, terminated, truncated, _ = step_result
                done = terminated or truncated
            else:  # older gym
                next_state, reward, done, _ = step_result
            episode_history.append((state, action, reward))
            state = next_state
            if isinstance(state, tuple):
                state = state[0]

        # Compute returns
        G = 0.0
        visited = set()
        for t in reversed(range(len(episode_history))):
            state_t, action_t, reward_t = episode_history[t]
            G = gamma * G + reward_t
            if (state_t, action_t) not in visited:
                visited.add((state_t, action_t))
                returns_count[(state_t, action_t)] += 1
                alpha = 1.0 / returns_count[(state_t, action_t)]
                Q[state_t][action_t] += alpha * (G - Q[state_t][action_t])

    return Q

def find_optimal_policy(env, num_episodes, gamma=1.0, epsilon_start=0.1, epsilon_min=0.01):
    """
    Runs MC control and returns the optimal value function V and the optimal policy.
    """
    Q = mc_control_epsilon_greedy(env, num_episodes, gamma, epsilon_start, epsilon_min)
    V = {}
    for state, action_values in Q.items():
        V[state] = np.max(action_values)
    return V, Q

def plot_value_function(V, env, title='Value Function'):
    """
    Plot the value function for Blackjack.
    """
    # Create a grid of states: player_sum 12-21, dealer_card 1-10, usable_ace False/True
    player_sums = np.arange(12, 22)
    dealer_cards = np.arange(1, 11)
    usable_aces = [False, True]

    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    for idx, usable_ace in enumerate(usable_aces):
        values = np.zeros((len(player_sums), len(dealer_cards)))
        for i, player_sum in enumerate(player_sums):
            for j, dealer_card in enumerate(dealer_cards):
                state = (player_sum, dealer_card, usable_ace)
                values[i, j] = V.get(state, 0.0)
        im = axes[idx].imshow(values, origin='lower',
                              extent=[dealer_cards[0]-0.5, dealer_cards[-1]+0.5,
                                      player_sums[0]-0.5, player_sums[-1]+0.5],
                              aspect='auto')
        axes[idx].set_title(f'Usable Ace = {usable_ace}')
        axes[idx].set_xlabel('Dealer showing')
        axes[idx].set_ylabel('Player sum')
        fig.colorbar(im, ax=axes[idx])

    fig.suptitle(title)
    plt.tight_layout()
    plt.show()

if __name__ == '__main__':
    env = gym.make('Blackjack-v1')
    num_episodes = 50000
    gamma = 1.0
    epsilon_start = 0.1
    epsilon_min = 0.01

    V, Q = find_optimal_policy(env, num_episodes, gamma, epsilon_start, epsilon_min)
    plot_value_function(V, env, title='Optimal Value Function for Blackjack')
