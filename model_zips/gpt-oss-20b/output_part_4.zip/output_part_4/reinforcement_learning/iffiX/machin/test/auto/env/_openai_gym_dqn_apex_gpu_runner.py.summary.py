import os
import pickle
import torch
import torch.distributed as dist
import torch.nn as nn
from machin import train
from machin.train import launch, generate_training_config, generate_algorithm_config
from machin.utils import DDPInspectCallback
# from machin.utils import LoggerDebugCallback  # Debug logger (commented out)

# 1. Environment and Configuration Setup
os.environ["WORLD_SIZE"] = "3"

root_dir = os.getcwd()
env_config = {
    "train_env": "CartPole-v0",
    "test_env": "CartPole-v0",
}

training_cfg = generate_training_config(
    root_dir=root_dir,
    env_config=env_config,
    gpus=[0, 0, 0],  # 3 processes, one GPU per process
)

# 2. Algorithm Configuration
class QNet(nn.Module):
    def __init__(self, state_dim: int, action_num: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, 128),
            nn.ReLU(),
            nn.Linear(128, action_num),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)

algorithm_cfg = generate_algorithm_config(
    algo="DQNApex",
    model=QNet,
    model_params={"state_dim": 4, "action_num": 2},
    target_model_params={"state_dim": 4, "action_num": 2},
)

# 3. Callback Initialization
ddp_callback = DDPInspectCallback(
    max_total_reward_threshold=150,
    track_max_total_reward=True,
)

# logger_debug_callback = LoggerDebugCallback(level="debug")  # Debug logger (commented out)

# 4. Training Launch
if __name__ == "__main__":
    launch(
        training_cfg,
        algorithm_cfg,
        callbacks=[ddp_callback],  # pass callbacks list
    )

    # 5. Post-Training Save
    if dist.is_available() and dist.is_initialized():
        rank = dist.get_rank()
    else:
        rank = 0

    if rank == 0:
        avg_max_total_reward = getattr(ddp_callback, "avg_max_total_reward", None)
        save_path = os.getenv("TEST_SAVE_PATH", "avg_max_total_reward.pkl")
        with open(save_path, "wb") as f:
            pickle.dump(avg_max_total_reward, f)