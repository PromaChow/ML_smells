import tensorflow as tf
from typing import Any, Dict, Iterable, List, Sequence, Tuple, Union

# ----------------------------------------------------------------------
# Helper utilities
# ----------------------------------------------------------------------
def nested_map(func, data):
    if isinstance(data, dict):
        return {k: nested_map(func, v) for k, v in data.items()}
    elif isinstance(data, (list, tuple)):
        return type(data)(nested_map(func, v) for v in data)
    else:
        return func(data)


def nested_assert(data, assertion_func):
    if isinstance(data, dict):
        for v in data.values():
            nested_assert(v, assertion_func)
    elif isinstance(data, (list, tuple)):
        for v in data:
            nested_assert(v, assertion_func)
    else:
        assertion_func(data)


# ----------------------------------------------------------------------
# EpisodeMemory implementation
# ----------------------------------------------------------------------
class EpisodeMemory:
    def __init__(
        self,
        capacity: int,
        max_length: int,
        template: Dict[str, tf.TensorSpec],
    ):
        """
        Args:
            capacity: Number of episodes that can be stored.
            max_length: Maximum length of an episode.
            template: Nested dictionary mapping keys to tf.TensorSpec objects
                      describing the shape and dtype of each transition component.
        """
        self._capacity = capacity
        self._max_length = max_length

        # Track current length of each episode.
        self._length = tf.Variable(
            initial_value=tf.zeros([capacity], dtype=tf.int32),
            trainable=False,
            name="episode_length",
        )

        # Create buffers for each transition component.
        def create_buffer(spec: tf.TensorSpec):
            shape = tf.concat(
                [[capacity, max_length], tf.constant(spec.shape, dtype=tf.int32)],
                axis=0,
            )
            return tf.Variable(
                initial_value=tf.zeros(shape, dtype=spec.dtype),
                trainable=False,
            )

        self.buffers = nested_map(create_buffer, template)

    # ------------------------------------------------------------------
    # Length retrieval
    # ------------------------------------------------------------------
    def length(self, rows: Sequence[int]) -> tf.Tensor:
        """
        Retrieve current lengths for specified episode indices.
        """
        rows_tensor = tf.convert_to_tensor(rows, dtype=tf.int32)
        tf.debugging.assert_less_equal(
            rows_tensor, tf.constant(self._capacity - 1, dtype=tf.int32),
            message="Episode index out of bounds in length()",
        )
        return tf.gather(self._length, rows_tensor)

    # ------------------------------------------------------------------
    # Append transitions
    # ------------------------------------------------------------------
    def append(
        self,
        rows: Sequence[int],
        transitions: Dict[str, tf.Tensor],
    ) -> None:
        """
        Append a single transition to each specified episode.
        `transitions` must match the template shape with an additional
        leading batch dimension equal to len(rows).
        """
        rows_tensor = tf.convert_to_tensor(rows, dtype=tf.int32)
        tf.debugging.assert_less_equal(
            rows_tensor, tf.constant(self._capacity - 1, dtype=tf.int32),
            message="Episode index out of bounds in append()",
        )

        current_lengths = tf.gather(self._length, rows_tensor)
        tf.debugging.assert_less(
            current_lengths,
            tf.constant(self._max_length, dtype=tf.int32),
            message="Episode exceeds maximum length in append()",
        )

        indices = tf.stack([rows_tensor, current_lengths], axis=1)  # shape [B, 2]

        # Update buffers
        def update_buffer(buffer, data):
            return buffer.scatter_nd_update(indices, data)

        nested_map(update_buffer, self.buffers)
        nested_map(lambda d: tf.stop_gradient(d), transitions)  # silence lint

        # Increment lengths
        self._length.scatter_nd_add(
            tf.expand_dims(rows_tensor, 1), tf.ones_like(rows_tensor, dtype=tf.int32)
        )

    # ------------------------------------------------------------------
    # Replace episodes
    # ------------------------------------------------------------------
    def replace(
        self,
        rows: Sequence[int],
        episode_data: Dict[str, tf.Tensor],
        episode_lengths: Sequence[int],
    ) -> None:
        """
        Replace entire episodes at specified indices.
        `episode_data` should be a nested dict of tensors with shape
        [num_rows, episode_length, *shape], where all episode_length are
        equal and <= max_length.
        """
        rows_tensor = tf.convert_to_tensor(rows, dtype=tf.int32)
        lengths_tensor = tf.convert_to_tensor(episode_lengths, dtype=tf.int32)

        tf.debugging.assert_less_equal(
            rows_tensor, tf.constant(self._capacity - 1, dtype=tf.int32),
            message="Episode index out of bounds in replace()",
        )
        tf.debugging.assert_less_equal(
            lengths_tensor,
            tf.constant(self._max_length, dtype=tf.int32),
            message="Episode length exceeds maximum in replace()",
        )

        # Assume all episode lengths are the same
        L = tf.shape(lengths_tensor)[0]
        tf.debugging.assert_equal(
            tf.reduce_all(tf.equal(lengths_tensor, lengths_tensor[0])),
            True,
            message="All provided episode lengths must be equal in replace()",
        )
        single_len = lengths_tensor[0]

        # Build indices for all (row, time) pairs
        time_range = tf.range(single_len)
        repeated_rows = tf.repeat(rows_tensor, repeats=single_len)
        tiled_time = tf.tile(time_range, [L])
        indices = tf.stack([repeated_rows, tiled_time], axis=1)  # shape [B*L, 2]

        # Flatten data tensors
        def flatten_and_update(buffer, data):
            flat_data = tf.reshape(
                data,
                [tf.shape(data)[0] * single_len]
                + buffer.shape[2:].as_list(),
            )
            return buffer.scatter_nd_update(indices, flat_data)

        nested_map(flatten_and_update, self.buffers)

        # Update lengths
        self._length.scatter_nd_update(
            tf.expand_dims(rows_tensor, 1), lengths_tensor
        )

    # ------------------------------------------------------------------
    # Retrieve data
    # ------------------------------------------------------------------
    def data(
        self,
        rows: Sequence[int],
    ) -> Tuple[Dict[str, tf.Tensor], tf.Tensor]:
        """
        Retrieve buffered data and lengths for specified episodes.
        Returns a tuple (buffer_data, lengths) where buffer_data is a nested
        dictionary matching the template.
        """
        rows_tensor = tf.convert_to_tensor(rows, dtype=tf.int32)
        tf.debugging.assert_less_equal(
            rows_tensor, tf.constant(self._capacity - 1, dtype=tf.int32),
            message="Episode index out of bounds in data()",
        )

        def gather_buffer(buffer):
            return tf.gather(buffer, rows_tensor)

        buffer_data = nested_map(gather_buffer, self.buffers)
        lengths = tf.gather(self._length, rows_tensor)
        return buffer_data, lengths

    # ------------------------------------------------------------------
    # Clear episodes
    # ------------------------------------------------------------------
    def clear(self, rows: Sequence[int]) -> None:
        """
        Reset the lengths of specified episodes to zero.
        """
        rows_tensor = tf.convert_to_tensor(rows, dtype=tf.int32)
        tf.debugging.assert_less_equal(
            rows_tensor, tf.constant(self._capacity - 1, dtype=tf.int32),
            message="Episode index out of bounds in clear()",
        )
        zeros = tf.zeros_like(rows_tensor, dtype=tf.int32)
        self._length.scatter_nd_update(tf.expand_dims(rows_tensor, 1), zeros)