import torch
from abc import ABC, abstractmethod
from typing import List, Tuple, Any


class DataBasedBandit(ABC):
    """
    Base class for contextual bandits that operate on a fixed dataset.
    Subclasses must implement reward computation, context retrieval,
    and reset logic.
    """

    def __init__(self, device: str = "cpu") -> None:
        if device == "cuda" and torch.cuda.is_available():
            self.device = torch.device("cuda")
        else:
            self.device = torch.device("cpu")
        self._reset()

    def _reset(self) -> None:
        """
        Reset all tracking metrics and histories.
        """
        self.idx: int = 0
        self._cum_regret: float = 0.0
        self._cum_reward: float = 0.0
        self._reward_hist: List[float] = []
        self._regret_hist: List[float] = []
        self._cum_regret_hist: List[float] = []
        self._cum_reward_hist: List[float] = []

    @abstractmethod
    def _compute_reward(self, action: int) -> Tuple[float, float]:
        """
        Compute the reward for the given action and the maximum achievable reward.
        Should return a tuple (reward, max_reward).
        """
        raise NotImplementedError

    @abstractmethod
    def _get_context(self) -> Any:
        """
        Retrieve the current context vector.
        """
        raise NotImplementedError

    @abstractmethod
    def reset(self) -> None:
        """
        Shuffle indices and reset the bandit state. Must be implemented by subclasses.
        """
        raise NotImplementedError

    def step(self, action: int) -> Tuple[Any, float]:
        """
        Execute one step of the bandit algorithm.

        Parameters
        ----------
        action : int
            The chosen action.

        Returns
        -------
        context : Any
            The next context vector after performing the action.
        reward : float
            The reward received for the chosen action.
        """
        reward, max_reward = self._compute_reward(action)
        regret = max_reward - reward

        self._cum_regret += regret
        self._cum_reward += reward

        self._reward_hist.append(reward)
        self._regret_hist.append(regret)
        self._cum_regret_hist.append(self._cum_regret)
        self._cum_reward_hist.append(self._cum_reward)

        self.idx += 1
        if hasattr(self, "len") and self.idx >= self.len:
            self.idx = 0

        context = self._get_context()
        return context, reward

    @property
    def reward_hist(self) -> List[float]:
        return list(self._reward_hist)

    @property
    def regret_hist(self) -> List[float]:
        return list(self._regret_hist)

    @property
    def cum_reward_hist(self) -> List[float]:
        return list(self._cum_reward_hist)

    @property
    def cum_regret_hist(self) -> List[float]:
        return list(self._cum_regret_hist)

    @property
    def cum_reward(self) -> float:
        return self._cum_reward

    @property
    def cum_regret(self) -> float:
        return self._cum_regret
