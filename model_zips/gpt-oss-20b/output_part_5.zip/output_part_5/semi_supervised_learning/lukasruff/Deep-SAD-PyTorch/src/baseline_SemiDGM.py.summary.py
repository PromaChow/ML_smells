import argparse
import json
import logging
import os
import random
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import torch.utils.data as data
import torch.backends.cudnn as cudnn
import matplotlib.pyplot as plt
from torchvision import utils

# --------------------------------------------------------------------------- #
# Helper functions and placeholders
# --------------------------------------------------------------------------- #

def set_seed(seed: int):
    if seed >= 0:
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        cudnn.deterministic = True
        cudnn.benchmark = False


def load_dataset(
    dataset_name: str,
    normal_class: int,
    known_outlier_class: int,
    ratio_known_normal: float,
    ratio_known_outlier: float,
    pollution_ratio: float,
    random_seed: int,
):
    """
    Placeholder function. Replace with actual dataset loader.
    Should return train_dataset, val_dataset, test_dataset.
    """
    from torchvision import datasets, transforms

    transform = transforms.Compose([transforms.ToTensor()])
    if dataset_name.lower() in ["mnist", "fmnist", "cifar10"]:
        if dataset_name.lower() == "mnist":
            dataset_cls = datasets.MNIST
        elif dataset_name.lower() == "fmnist":
            dataset_cls = datasets.FashionMNIST
        else:
            dataset_cls = datasets.CIFAR10
        train_set = dataset_cls(root="./data", train=True, download=True, transform=transform)
        test_set = dataset_cls(root="./data", train=False, download=True, transform=transform)
    else:
        # For non-image datasets, use a synthetic random dataset
        train_set = data.TensorDataset(torch.randn(1000, 20), torch.randint(0, 2, (1000,)))
        test_set = data.TensorDataset(torch.randn(200, 20), torch.randint(0, 2, (200,)))

    # TODO: split train_set into labeled/unlabeled based on ratios
    return train_set, None, test_set


def plot_images_grid(
    images,
    title,
    save_path,
    nrow=8,
    padding=2,
    normalize=False,
):
    grid = utils.make_grid(images, nrow=nrow, padding=padding, normalize=normalize)
    npimg = grid.numpy()
    plt.figure(figsize=(8, 8))
    plt.imshow(np.transpose(npimg, (1, 2, 0)))
    plt.title(title)
    plt.axis("off")
    plt.savefig(save_path)
    plt.close()


# --------------------------------------------------------------------------- #
# Model definition (placeholder)
# --------------------------------------------------------------------------- #

class SemiDeepGenerativeModel(nn.Module):
    def __init__(self, architecture: str, alpha: float):
        super().__init__()
        # Simple MLP placeholder
        self.alpha = alpha
        if architecture == "mlp":
            self.net = nn.Sequential(
                nn.Flatten(),
                nn.Linear(784, 512),
                nn.ReLU(),
                nn.Linear(512, 256),
                nn.ReLU(),
                nn.Linear(256, 1),
            )
        else:
            self.net = nn.Sequential(
                nn.Flatten(),
                nn.Linear(32 * 32 * 3, 1024),
                nn.ReLU(),
                nn.Linear(1024, 512),
                nn.ReLU(),
                nn.Linear(512, 1),
            )

    def forward(self, x):
        return self.net(x)

    def pretrain_vae(
        self,
        train_loader,
        lr,
        epochs,
        weight_decay,
        result_path,
    ):
        # Dummy pretraining: train for epochs with MSE loss
        optimizer = optim.Adam(self.parameters(), lr=lr, weight_decay=weight_decay)
        criterion = nn.MSELoss()
        for epoch in range(epochs):
            self.train()
            for batch_idx, (data_batch, _) in enumerate(train_loader):
                data_batch = data_batch.to(next(self.parameters()).device)
                optimizer.zero_grad()
                recon = self(data_batch)
                loss = criterion(recon, data_batch)
                loss.backward()
                optimizer.step()
        # Save dummy results
        with open(result_path, "w") as f:
            json.dump({"pretrain_epochs": epochs, "loss": loss.item()}, f)

    def score(self, x):
        with torch.no_grad():
            return self(x).cpu().numpy().squeeze()


# --------------------------------------------------------------------------- #
# Main training pipeline
# --------------------------------------------------------------------------- #

def main():
    parser = argparse.ArgumentParser(description="Semi-supervised DGM for anomaly detection")
    parser.add_argument("--dataset_name", type=str, required=True, help="Dataset name")
    parser.add_argument("--normal_class", type=int, default=0, help="Normal class label")
    parser.add_argument("--known_outlier_class", type=int, default=-1, help="Known outlier class label")
    parser.add_argument("--ratio_known_normal", type=float, default=0.01, help="Ratio of labeled normal")
    parser.add_argument("--ratio_known_outlier", type=float, default=0.01, help="Ratio of labeled outlier")
    parser.add_argument("--pollution_ratio", type=float, default=0.0, help="Noise ratio")
    parser.add_argument("--load_model", type=str, default=None, help="Path to pre-trained model")
    parser.add_argument("--pretrain", action="store_true", help="Run VAE pretraining")
    parser.add_argument("--vae_lr", type=float, default=1e-3, help="VAE learning rate")
    parser.add_argument("--vae_n_epochs", type=int, default=10, help="VAE epochs")
    parser.add_argument("--vae_batch_size", type=int, default=128, help="VAE batch size")
    parser.add_argument("--vae_weight_decay", type=float, default=0.0, help="VAE weight decay")
    parser.add_argument("--lr", type=float, default=1e-3, help="Learning rate")
    parser.add_argument("--n_epochs", type=int, default=50, help="Training epochs")
    parser.add_argument("--batch_size", type=int, default=256, help="Batch size")
    parser.add_argument("--weight_decay", type=float, default=0.0, help="Weight decay")
    parser.add_argument("--device", type=str, default="cpu", help="Device")
    parser.add_argument("--seed", type=int, default=-1, help="Random seed")
    parser.add_argument("--num_threads", type=int, default=4, help="Number of CPU threads")
    parser.add_argument("--experiment_path", type=str, required=True, help="Path to store experiment outputs")
    parser.add_argument("--network_arch", type=str, default="mlp", help="Network architecture")
    args = parser.parse_args()

    # Ensure experiment directory
    exp_path = Path(args.experiment_path)
    exp_path.mkdir(parents=True, exist_ok=True)

    # Logging
    logging.basicConfig(
        filename=exp_path / "log.txt",
        filemode="w",
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
    )
    logging.info(f"Arguments: {args}")

    # Seed
    set_seed(args.seed)

    # Device
    if args.device.lower() == "cuda" and torch.cuda.is_available():
        device = torch.device("cuda")
    else:
        device = torch.device("cpu")
    logging.info(f"Using device: {device}")

    # CPU threads
    torch.set_num_threads(args.num_threads)
    logging.info(f"Set number of CPU threads to {args.num_threads}")

    # Load dataset
    train_set, val_set, test_set = load_dataset(
        dataset_name=args.dataset_name,
        normal_class=args.normal_class,
        known_outlier_class=args.known_outlier_class,
        ratio_known_normal=args.ratio_known_normal,
        ratio_known_outlier=args.ratio_known_outlier,
        pollution_ratio=args.pollution_ratio,
        random_seed=args.seed,
    )
    train_loader = data.DataLoader(train_set, batch_size=args.batch_size, shuffle=True, num_workers=0)
    test_loader = data.DataLoader(test_set, batch_size=args.batch_size, shuffle=False, num_workers=0)

    # Compute alpha
    ratio_sum = args.ratio_known_normal + args.ratio_known_outlier
    if ratio_sum == 0:
        alpha = 0.1
    else:
        alpha = 0.1 * (1 - ratio_sum) / ratio_sum
    logging.info(f"Computed alpha: {alpha}")

    # Model
    model = SemiDeepGenerativeModel(architecture=args.network_arch, alpha=alpha).to(device)
    if args.load_model:
        model.load_state_dict(torch.load(args.load_model, map_location=device))
        logging.info(f"Loaded model from {args.load_model}")

    # Pretraining
    if args.pretrain:
        vae_result_path = exp_path / "vae_results.json"
        model.pretrain_vae(
            train_loader,
            lr=args.vae_lr,
            epochs=args.vae_n_epochs,
            weight_decay=args.vae_weight_decay,
            result_path=vae_result_path,
        )
        logging.info(f"Pretraining completed. Results saved to {vae_result_path}")

    # Training
    optimizer = optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    criterion = nn.MSELoss()
    for epoch in range(1, args.n_epochs + 1):
        model.train()
        epoch_loss = 0.0
        for batch_idx, (data_batch, _) in enumerate(train_loader):
            data_batch = data_batch.to(device)
            optimizer.zero_grad()
            outputs = model(data_batch)
            loss = criterion(outputs, data_batch)
            loss.backward()
            optimizer.step()
            epoch_loss += loss.item()
        avg_loss = epoch_loss / len(train_loader)
        logging.info(f"Epoch {epoch}/{args.n_epochs} - Loss: {avg_loss:.4f}")

    # Testing
    model.eval()
    all_scores = []
    all_labels = []
    all_indices = []
    with torch.no_grad():
        for idx, (data_batch, labels_batch) in enumerate(test_loader):
            data_batch = data_batch.to(device)
            scores = model.score(data_batch)
            all_scores.extend(scores)
            all_labels.extend(labels_batch.cpu().numpy())
            all_indices.extend(list(range(idx * args.batch_size, idx * args.batch_size + len(data_batch))))
    results = {
        "scores": all_scores,
        "labels": all_labels,
        "indices": all_indices,
    }
    results_path = exp_path / "results.json"
    with open(results_path, "w") as f:
        json.dump(results, f)
    logging.info(f"Test results saved to {results_path}")

    # Save model
    model_path = exp_path / "model.tar"
    torch.save(model.state_dict(), model_path)
    logging.info(f"Model checkpoint saved to {model_path}")

    # Save config
    config_path = exp_path / "config.json"
    with open(config_path, "w") as f:
        json.dump(vars(args), f, indent=4)
    logging.info(f"Configuration saved to {config_path}")

    # Visualization for image datasets
    if args.dataset_name.lower() in ["mnist", "fmnist", "cifar10"]:
        # Extract tensors from test_set
        all_imgs = test_set.data if hasattr(test_set, "data") else None
        if all_imgs is None:
            # Assume test_set is a TensorDataset
            all_imgs = torch.stack([t[0] for t in test_set])
        # Convert to PIL images if necessary
        if isinstance(all_imgs, torch.Tensor):
            if all_imgs.ndim == 4:  # (N, C, H, W)
                imgs_tensor = all_imgs
            else:  # (N, H, W)
                imgs_tensor = all_imgs.unsqueeze(1).repeat(1, 3, 1, 1)
        else:
            imgs_tensor = None

        # Create tensors for plotting
        if imgs_tensor is not None:
            scores_array = np.array(all_scores)
            # Sort by scores
            sorted_idx = np.argsort(scores_array)
            # Most normal
            normals_low_idx = sorted_idx[:64]
            # Most anomalous
            normals_high_idx = sorted_idx[-64:]
            # For all low and high, we can just use top 64
            low_imgs = imgs_tensor[normals_low_idx]
            high_imgs = imgs_tensor[normals_high_idx]
            # Plot
            plot_images_grid(
                low_imgs,
                title="Most Normal Images",
                save_path=exp_path / "all_low.png",
                nrow=8,
            )
            plot_images_grid(
                high_imgs,
                title="Most Anomalous Images",
                save_path=exp_path / "all_high.png",
                nrow=8,
            )
            logging.info(f"Visualization images saved to {exp_path}")

if __name__ == "__main__":
    main()
