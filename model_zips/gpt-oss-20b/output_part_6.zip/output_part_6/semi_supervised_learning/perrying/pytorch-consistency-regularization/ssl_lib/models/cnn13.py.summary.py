import torch
import torch.nn as nn
import torch.nn.init as init


class BaseModel(nn.Module):
    """Placeholder base class."""
    pass


def conv3x3(in_channels: int, out_channels: int) -> nn.Sequential:
    return nn.Sequential(
        nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=1, padding=1, bias=False),
        nn.LeakyReLU(inplace=True),
        nn.BatchNorm2d(out_channels)
    )


class CNN13(BaseModel):
    def __init__(self, filters: int, num_classes: int):
        super().__init__()

        features = []

        # Stage 1
        for _ in range(3):
            features.append(conv3x3(filters if _ else 3, filters))
        features.append(nn.MaxPool2d(kernel_size=2, stride=2))

        # Stage 2
        for _ in range(3):
            in_ch = filters if _ == 0 else 2 * filters
            features.append(conv3x3(in_ch, 2 * filters))
        features.append(nn.MaxPool2d(kernel_size=2, stride=2))

        # Stage 3
        features.append(conv3x3(2 * filters, 4 * filters))
        features.append(nn.Sequential(
            nn.Conv2d(4 * filters, 2 * filters, kernel_size=1, bias=False),
            nn.LeakyReLU(inplace=True),
            nn.BatchNorm2d(2 * filters)
        ))
        features.append(nn.Sequential(
            nn.Conv2d(2 * filters, filters, kernel_size=1, bias=False),
            nn.LeakyReLU(inplace=True),
            nn.BatchNorm2d(filters)
        ))

        self.feature_extractor = nn.Sequential(*features)
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.classifier = nn.Linear(filters, num_classes)

        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d) or isinstance(m, nn.Linear):
                init.xavier_normal_(m.weight)
                if m.bias is not None:
                    init.constant_(m.bias, 0)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.feature_extractor(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.classifier(x)
        return x

# Example usage:
# model = CNN13(filters=64, num_classes=10)
# input_tensor = torch.randn(8, 3, 32, 32)
# output = model(input_tensor)
# print(output.shape)  # torch.Size([8, 10])