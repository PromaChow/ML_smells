import numpy as np
from qtrader.utils.preprocessor import rolling2d

def generator(num_samples, data, optimizer, window, short_sales=False):
    """
    Generates a supervised learning dataset for portfolio optimization.

    Parameters
    ----------
    num_samples : int
        Total number of time points in the input data.
    data : np.ndarray
        Input matrix of shape (N, M) where N is the number of time points and M is the number of assets.
    optimizer : callable
        Function that computes optimal portfolio weights. It must accept arguments
        (mu_r, Sigma_r, w0, short_sales) and return a 1‑D array of length M.
    window : int
        Length of the rolling window.
    short_sales : bool, optional
        Whether short selling is allowed. Default is False.

    Returns
    -------
    X : np.ndarray
        3‑D array of shape (num_samples - window + 1, window, M) containing rolling windows.
    y : np.ndarray
        2‑D array of shape (num_samples - window + 1, M) containing optimal portfolio weights.
    """
    if not isinstance(data, np.ndarray):
        raise TypeError("data must be a NumPy array")

    N, M = data.shape
    if N < window:
        raise ValueError("Data length must be at least as long as the rolling window")

    num_windows = N - window + 1

    # Prepare data structures
    X = rolling2d(data, window)  # shape (num_windows, window, M)
    y = np.zeros((num_windows, M), dtype=float)

    for i, window_data in enumerate(X):
        try:
            # Empirical mean vector
            mu_r = np.mean(window_data, axis=0)

            # Empirical covariance matrix (across assets)
            Sigma_r = np.cov(window_data.T)

            # Random initial weight vector normalized to sum to 1
            w0 = np.random.uniform(0, 1, size=M)
            w0 /= w0.sum()

            # Compute optimal portfolio weights
            y[i] = optimizer(mu_r, Sigma_r, w0, short_sales)
        except Exception as e:
            print(f"Error at window index {i}: {e}")

    return X, y