import sys
import os
import time
import gym
import numpy as np
import pybulletgym.envs  # noqa: F401

# Add parent directory to the Python path for package discovery
sys.path.append(os.path.abspath('..'))

def relu(x: np.ndarray) -> np.ndarray:
    """Element-wise ReLU activation."""
    return np.maximum(x, 0)


class SmallReactivePolicy:
    """Fixed 3-layer MLP policy for the Inverted Pendulum Swingup environment."""

    def __init__(
        self,
        obs_dim: int,
        act_dim: int,
        weights_dense1_w: np.ndarray,
        weights_dense1_b: np.ndarray,
        weights_dense2_w: np.ndarray,
        weights_dense2_b: np.ndarray,
        weights_final_w: np.ndarray,
        weights_final_b: np.ndarray,
    ) -> None:
        # Validate weight shapes
        if weights_dense1_w.shape != (obs_dim, 64):
            raise ValueError(
                f"weights_dense1_w shape mismatch: expected {(obs_dim, 64)}, got {weights_dense1_w.shape}"
            )
        if weights_dense1_b.shape != (64,):
            raise ValueError(
                f"weights_dense1_b shape mismatch: expected {(64,)}, got {weights_dense1_b.shape}"
            )
        if weights_dense2_w.shape != (64, 32):
            raise ValueError(
                f"weights_dense2_w shape mismatch: expected {(64, 32)}, got {weights_dense2_w.shape}"
            )
        if weights_dense2_b.shape != (32,):
            raise ValueError(
                f"weights_dense2_b shape mismatch: expected {(32,)}, got {weights_dense2_b.shape}"
            )
        if weights_final_w.shape != (32, act_dim):
            raise ValueError(
                f"weights_final_w shape mismatch: expected {(32, act_dim)}, got {weights_final_w.shape}"
            )
        if weights_final_b.shape != (act_dim,):
            raise ValueError(
                f"weights_final_b shape mismatch: expected {(act_dim,)}, got {weights_final_b.shape}"
            )

        self.w1 = weights_dense1_w
        self.b1 = weights_dense1_b
        self.w2 = weights_dense2_w
        self.b2 = weights_dense2_b
        self.w3 = weights_final_w
        self.b3 = weights_final_b

    def act(self, obs: np.ndarray) -> np.ndarray:
        """Compute action for a given observation."""
        x = relu(obs @ self.w1 + self.b1)
        x = relu(x @ self.w2 + self.b2)
        action = x @ self.w3 + self.b3
        return action


def main() -> None:
    env_name = "InvertedPendulumSwingupPyBulletEnv-v0"
    env = gym.make(env_name)

    obs_dim = env.observation_space.shape[0]
    act_dim = env.action_space.shape[0]

    # Hardcoded weights (deterministic values)
    rng = np.random.default_rng(seed=42)
    weights_dense1_w = rng.standard_normal((obs_dim, 64))
    weights_dense1_b = rng.standard_normal((64,))
    weights_dense2_w = rng.standard_normal((64, 32))
    weights_dense2_b = rng.standard_normal((32,))
    weights_final_w = rng.standard_normal((32, act_dim))
    weights_final_b = rng.standard_normal((act_dim,))

    policy = SmallReactivePolicy(
        obs_dim=obs_dim,
        act_dim=act_dim,
        weights_dense1_w=weights_dense1_w,
        weights_dense1_b=weights_dense1_b,
        weights_dense2_w=weights_dense2_w,
        weights_dense2_b=weights_dense2_b,
        weights_final_w=weights_final_w,
        weights_final_b=weights_final_b,
    )

    while True:
        obs = env.reset()
        score = 0.0
        frame = 0
        done = False

        while not done:
            time.sleep(0.02)  # wait for 20 ms
            action = policy.act(obs)
            obs, reward, done, info = env.step(action)
            score += reward
            frame += 1
            env.render(mode="human")

        print(f"Episode finished. Score: {score:.2f}, Frames: {frame}")
        time.sleep(2.0)


if __name__ == "__main__":
    main()
