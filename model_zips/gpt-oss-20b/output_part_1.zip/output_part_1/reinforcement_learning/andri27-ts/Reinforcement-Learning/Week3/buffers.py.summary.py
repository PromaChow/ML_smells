import random
import collections
import numpy as np


class ReplayBuffer:
    def __init__(self, max_size: int, n_multi_step: int = 1, gamma: float = 0.99):
        self.buffer: collections.deque = collections.deque(maxlen=max_size)
        self.n_multi_step: int = n_multi_step
        self.gamma: float = gamma

    def append(self, memory: dict):
        """
        memory should be a dict with keys:
        'obs', 'action', 'reward', 'new_obs', 'done'
        """
        self.buffer.append(memory)

    def sample(self, batch_size: int):
        if batch_size > len(self.buffer):
            raise ValueError("Batch size larger than buffer size")
        indices = random.sample(range(len(self.buffer)), batch_size)

        obs_list = []
        action_list = []
        next_obs_list = []
        reward_list = []
        done_list = []

        for idx in indices:
            current = self.buffer[idx]
            obs = current['obs']
            action = current['action']

            sum_reward = 0.0
            discount = 1.0
            next_obs = current['new_obs']
            done = current['done']

            for n in range(self.n_multi_step):
                if idx + n >= len(self.buffer):
                    break
                step = self.buffer[idx + n]
                sum_reward += discount * step['reward']
                discount *= self.gamma
                if step['done']:
                    next_obs = step['new_obs']
                    done = True
                    break

            obs_list.append(obs)
            action_list.append(action)
            next_obs_list.append(next_obs)
            reward_list.append(sum_reward)
            done_list.append(done)

        states = np.array(obs_list, dtype=object)
        actions = np.array(action_list, dtype=object)
        next_states = np.array(next_obs_list, dtype=object)
        rewards = np.array(reward_list, dtype=np.float32)
        dones = np.array(done_list, dtype=bool)

        return states, actions, next_states, rewards, dones

    def __len__(self):
        return len(self.buffer)