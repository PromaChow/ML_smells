import os
import sys
import numpy as np
import gym
import pybullet as p

# Ensure external assets can be found
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PARENT_DIR = os.path.abspath(os.path.join(BASE_DIR, os.pardir))
if PARENT_DIR not in sys.path:
    sys.path.append(PARENT_DIR)


class PoseHelper:
    @staticmethod
    def get_position_orientation(body_id, link_index=-1):
        pos, orn = p.getLinkState(body_id, link_index, computeForwardKinematics=True)[:2]
        return np.array(pos), np.array(orn)

    @staticmethod
    def get_rotation_matrix(orientation):
        return np.array(p.getMatrixFromQuaternion(orientation)).reshape(3, 3)


class BodyPart:
    def __init__(self, body_id, link_index, name):
        self.body_id = body_id
        self.link_index = link_index
        self.name = name

    def reset_pose(self, position, orientation):
        p.resetBasePositionAndOrientation(self.body_id, position, orientation)

    def reset_velocity(self, linear_vel, angular_vel):
        p.resetBaseVelocity(self.body_id, linearVelocity=linear_vel, angularVelocity=angular_vel)

    def contact_list(self):
        contacts = p.getContactPoints(bodyA=self.body_id, linkIndexA=self.link_index)
        return contacts


class Joint:
    def __init__(self, body_id, joint_index, name, joint_type, limits):
        self.body_id = body_id
        self.joint_index = joint_index
        self.name = name
        self.joint_type = joint_type
        self.limits = limits

    def set_motor_position(self, target_position, max_force, max_velocity=0):
        p.setJointMotorControl2(
            bodyIndex=self.body_id,
            jointIndex=self.joint_index,
            controlMode=p.POSITION_CONTROL,
            targetPosition=target_position,
            force=max_force,
            maxVelocity=max_velocity,
        )

    def set_motor_velocity(self, target_velocity, max_force):
        p.setJointMotorControl2(
            bodyIndex=self.body_id,
            jointIndex=self.joint_index,
            controlMode=p.VELOCITY_CONTROL,
            targetVelocity=target_velocity,
            force=max_force,
        )

    def set_motor_torque(self, torque):
        p.setJointMotorControl2(
            bodyIndex=self.body_id,
            jointIndex=self.joint_index,
            controlMode=p.TORQUE_CONTROL,
            force=torque,
        )


class XmlBasedRobot:
    def __init__(self, use_self_collision=True):
        self.parts = []
        self.joints = []
        self.ordered_joints = []
        self.action_space = None
        self.observation_space = None
        self.robot_id = None
        self.use_self_collision = use_self_collision

    def add_to_scene(self):
        body_count = p.getNumBodies()
        for body_index in range(body_count):
            body_info = p.getBodyInfo(body_index)
            body_name = body_info[0].decode()
            self.parts.append(BodyPart(body_index, -1, body_name))

            num_joints = p.getNumJoints(body_index)
            for j in range(num_joints):
                joint_info = p.getJointInfo(body_index, j)
                joint_name = joint_info[1].decode()
                joint_type = joint_info[2]
                lower_limit = joint_info[8]
                upper_limit = joint_info[9]
                limits = (lower_limit, upper_limit)
                joint = Joint(body_index, j, joint_name, joint_type, limits)
                self.joints.append(joint)
                self.ordered_joints.append(joint)

    def reset(self):
        self.parts.clear()
        self.joints.clear()
        self.ordered_joints.clear()
        self.robot_id = self.load_model()
        self.add_to_scene()
        self.initialize_spaces()
        self.robot_specific_reset()

    def load_model(self):
        raise NotImplementedError

    def initialize_spaces(self):
        actuated_joints = [j for j in self.ordered_joints if j.joint_type in [p.JOINT_REVOLUTE, p.JOINT_PRISMATIC]]
        low = np.array([-1.0] * len(actuated_joints))
        high = np.array([1.0] * len(actuated_joints))
        self.action_space = gym.spaces.Box(low=low, high=high, dtype=np.float32)
        obs_dim = len(actuated_joints) * 2
        self.observation_space = gym.spaces.Box(low=-np.inf, high=np.inf, shape=(obs_dim,), dtype=np.float32)

    def robot_specific_reset(self):
        pass

    def reset_pose(self, body_name, position, orientation):
        part = next((p for p in self.parts if p.name == body_name), None)
        if part:
            part.reset_pose(position, orientation)

    def set_position(self, body_name, position):
        part = next((p for p in self.parts if p.name == body_name), None)
        if part:
            part.reset_pose(position, part.orientation)


class MJCFBasedRobot(XmlBasedRobot):
    def __init__(self, mjcf_path, use_self_collision=True):
        super().__init__(use_self_collision)
        self.mjcf_path = mjcf_path

    def load_model(self):
        flags = 0
        if self.use_self_collision:
            flags |= p.MJCF_FLAGS_ENABLE_SELF_COLLISION
        body_ids = p.loadMJCF(self.mjcf_path, flags=flags)
        return body_ids[0] if isinstance(body_ids, list) else body_ids

    def robot_specific_reset(self):
        # Example: set all revolute joints to zero
        for joint in self.ordered_joints:
            if joint.joint_type == p.JOINT_REVOLUTE:
                joint.set_motor_position(0.0, max_force=0)


class URDFBasedRobot(XmlBasedRobot):
    def __init__(self, urdf_path, base_position=None, base_orientation=None, use_self_collision=True):
        super().__init__(use_self_collision)
        self.urdf_path = urdf_path
        self.base_position = base_position or [0, 0, 0]
        self.base_orientation = base_orientation or [0, 0, 0, 1]

    def load_model(self):
        flags = 0
        if self.use_self_collision:
            flags |= p.URDF_USE_SELF_COLLISION
        body_id = p.loadURDF(
            self.urdf_path,
            basePosition=self.base_position,
            baseOrientation=self.base_orientation,
            flags=flags,
        )
        return body_id

    def robot_specific_reset(self):
        for joint in self.ordered_joints:
            if joint.joint_type == p.JOINT_REVOLUTE:
                joint.set_motor_position(0.0, max_force=0)


class SDFBasedRobot(XmlBasedRobot):
    def __init__(self, sdf_path, base_position=None, base_orientation=None, use_self_collision=True):
        super().__init__(use_self_collision)
        self.sdf_path = sdf_path
        self.base_position = base_position or [0, 0, 0]
        self.base_orientation = base_orientation or [0, 0, 0, 1]

    def load_model(self):
        flags = 0
        if self.use_self_collision:
            flags |= p.SDF_FLAGS_ENABLE_SELF_COLLISION
        body_ids = p.loadSDF(
            self.sdf_path,
            flags=flags,
            basePosition=self.base_position,
            baseOrientation=self.base_orientation,
        )
        return body_ids[0] if isinstance(body_ids, list) else body_ids

    def robot_specific_reset(self):
        for joint in self.ordered_joints:
            if joint.joint_type == p.JOINT_REVOLUTE:
                joint.set_motor_position(0.0, max_force=0)
```