import torch
import torch.nn as nn
import torch.nn.functional as F
import random
import numpy as np

# ---------- Helper Functions ----------
def weak_augment(images: torch.Tensor) -> torch.Tensor:
    """Placeholder weak augmentation (random horizontal flip)."""
    if random.random() < 0.5:
        return torch.flip(images, dims=[-1])
    return images

def strong_augment(images: torch.Tensor) -> torch.Tensor:
    """Placeholder strong augmentation (random crop + flip)."""
    b, c, h, w = images.shape
    size = int(min(h, w) * 0.8)
    start_h = random.randint(0, h - size)
    start_w = random.randint(0, w - size)
    crop = images[:, :, start_h:start_h+size, start_w:start_w+size]
    if random.random() < 0.5:
        crop = torch.flip(crop, dims=[-1])
    return F.interpolate(crop, size=(h, w), mode="bilinear", align_corners=False)

def sharpening(p: torch.Tensor, T: float = 0.5) -> torch.Tensor:
    """Sharpen probability distribution."""
    p_power = p ** (1.0 / T)
    return p_power / p_power.sum(dim=1, keepdim=True)

def mixup(x: torch.Tensor, y: torch.Tensor, alpha: float = 0.75) -> (torch.Tensor, torch.Tensor):
    """Apply Mixup to data and labels."""
    lam = np.random.beta(alpha, alpha)
    batch_size = x.size(0)
    index = torch.randperm(batch_size).to(x.device)
    mixed_x = lam * x + (1 - lam) * x[index]
    mixed_y = lam * y + (1 - lam) * y[index]
    return mixed_x, mixed_y

# ---------- Core Functions ----------
def compute_rot_loss(
    model: nn.Module,
    images: torch.Tensor,
    w_rot: float = 1.0,
    rot_classifier: nn.Module = None
) -> torch.Tensor:
    """
    Compute rotation loss for a batch of images rotated by 0°, 90°, 180°, or 270°.
    """
    if w_rot <= 0:
        return torch.tensor(0.0, device=images.device, dtype=torch.float32)

    batch_size = images.size(0)
    # Randomly rotate each image and generate rotation labels
    angles = torch.randint(0, 4, (batch_size,), device=images.device)
    rot_images = torch.stack(
        [torch.rot90(images[i], k=int(angles[i]), dims=(2, 3)) for i in range(batch_size)],
        dim=0
    )
    rot_labels = angles

    # Forward pass through rotation classifier
    if rot_classifier is None:
        # Default linear layer for rotation
        rot_classifier = nn.Linear(images.shape[1] * images.shape[2] * images.shape[3], 4).to(images.device)
    logits = rot_classifier(rot_images.view(batch_size, -1))

    # Cross entropy loss
    loss = F.cross_entropy(logits, rot_labels)
    return loss * w_rot

def compute_kl_loss(
    model: nn.Module,
    u_aug: torch.Tensor,
    pseudo_labels: torch.Tensor,
    w_kl: float = 1.0
) -> torch.Tensor:
    """
    Compute KL loss between model predictions and pseudo labels for unlabeled data.
    """
    if w_kl <= 0:
        return torch.tensor(0.0, device=u_aug.device, dtype=torch.float32)

    logits = model(u_aug)
    probs = F.softmax(logits, dim=1)
    loss = F.kl_div(F.log_softmax(logits, dim=1), pseudo_labels, reduction="batchmean")
    return loss * w_kl

def remixmatch(
    model: nn.Module,
    x: torch.Tensor,
    y: torch.Tensor,
    u: torch.Tensor,
    K: int = 2,
    T: float = 0.5,
    w_kl: float = 1.0
) -> (torch.Tensor, torch.Tensor, torch.Tensor):
    """
    RemixMatch algorithm.
    Returns transformed labeled data X_prime, unlabeled data U_prime, and KL loss.
    """
    device = x.device
    batch_size = x.size(0)

    # Weak augmentation for labeled data
    x_aug = weak_augment(x)

    # Generate K weakly augmented batches for unlabeled data
    u_aug_list = [weak_augment(u) for _ in range(K)]

    # Pseudo-label generation (guessed labels)
    with torch.no_grad():
        u_logits_list = [model(u_aug) for u_aug in u_aug_list]
        u_probs_list = [F.softmax(logits, dim=1) for logits in u_logits_list]
        # Sharpen
        u_sharpened = [sharpening(p, T) for p in u_probs_list]

    # KL loss on first augmented batch
    kl_loss = compute_kl_loss(model, u_aug_list[0], u_sharpened[0], w_kl)

    # Concatenate all unlabeled augmented batches and labels
    U = torch.cat(u_aug_list, dim=0)
    u_labels = torch.cat(u_sharpened, dim=0)

    # Combine labeled and unlabeled data
    X_U = torch.cat([x_aug, U], dim=0)
    y_U = torch.cat([F.one_hot(y, num_classes=y.max()+1).float(), u_labels], dim=0)

    # Shuffle
    idx = torch.randperm(X_U.size(0)).to(device)
    X_U = X_U[idx]
    y_U = y_U[idx]

    # Mixup
    X_U_mix, y_U_mix = mixup(X_U, y_U)

    # Split into K+1 parts
    part_size = batch_size
    segments = [X_U_mix[i*part_size:(i+1)*part_size] for i in range(K+1)]
    label_segments = [y_U_mix[i*part_size:(i+1)*part_size] for i in range(K+1)]

    # Interleave segments: first segment is labeled
    X_prime = segments[0]
    U_prime = torch.cat(segments[1:], dim=0)
    return X_prime, U_prime, kl_loss

def ssl_loss_remixmatch(
    model: nn.Module,
    labels_x: torch.Tensor,
    logits_x: torch.Tensor,
    labels_u: torch.Tensor,
    logits_u: torch.Tensor,
    use_xeu: bool = True
) -> (float, float):
    """
    Compute labeled and unlabeled loss (CE or MSE).
    """
    # Labeled loss (cross-entropy)
    loss_x = F.cross_entropy(logits_x, labels_x)

    if use_xeu:
        # Unlabeled loss (cross-entropy with pseudo labels)
        loss_xeu = F.cross_entropy(logits_u, labels_u.argmax(dim=1))
    else:
        # MSE between softmax predictions and pseudo labels
        preds = F.softmax(logits_u, dim=1)
        loss_xeu = F.mse_loss(preds, labels_u)

    return loss_x.item(), loss_xeu.item()
