import pandas as pd
import matplotlib.pyplot as plt

def main():
    df = pd.read_csv("CityTemps.csv")
    print(df)

    moscow_temps = df.loc[df["City"] == "Moscow", "Temperature"].values
    sf_temps = df.loc[df["City"] == "San Francisco", "Temperature"].values

    plt.hist(moscow_temps, bins=len(moscow_temps), color="blue", alpha=0.5, label="Moscow")
    plt.hist(sf_temps, bins=len(sf_temps), color="red", alpha=0.5, label="San Francisco")

    plt.xlabel("Temperature")
    plt.ylabel("Frequency")
    plt.title("Temperatures of Moscow and San Francisco")
    plt.xticks(rotation=90)
    plt.legend()
    plt.show()

if __name__ == "__main__":
    main()