import gym
import torch
import torch.nn as nn
import torch.optim as optim
import random
import numpy as np
from collections import deque

# Neural network definition
class QNet(nn.Module):
    def __init__(self, input_dim=4, hidden_dim=16, output_dim=2):
        super(QNet, self).__init__()
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.fc3 = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return self.fc3(x)

# Prioritized Experience Replay buffer
class PrioritizedReplayBuffer:
    def __init__(self, capacity=10000, alpha=0.6, epsilon=1e-5):
        self.capacity = capacity
        self.alpha = alpha
        self.epsilon = epsilon
        self.buffer = []
        self.priorities = []
        self.position = 0
        self.max_priority = 1.0

    def push(self, state, action, next_state, reward, done):
        data = (state, action, next_state, reward, done)
        if len(self.buffer) < self.capacity:
            self.buffer.append(data)
            self.priorities.append(self.max_priority)
        else:
            self.buffer[self.position] = data
            self.priorities[self.position] = self.max_priority
            self.position = (self.position + 1) % self.capacity

    def sample(self, batch_size):
        if len(self.buffer) == self.capacity:
            prios = np.array(self.priorities)
        else:
            prios = np.array(self.priorities[:len(self.buffer)])
        probs = prios ** self.alpha
        probs /= probs.sum()
        indices = np.random.choice(len(self.buffer), batch_size, p=probs)
        samples = [self.buffer[idx] for idx in indices]
        total = len(self.buffer)
        weights = (total * probs[indices]) ** -1
        weights /= weights.max()
        return samples, indices, torch.tensor(weights, dtype=torch.float32, device=device)

    def update_priorities(self, indices, errors):
        for idx, err in zip(indices, errors):
            self.priorities[idx] = abs(err) + self.epsilon
            self.max_priority = max(self.max_priority, self.priorities[idx])

    def __len__(self):
        return len(self.buffer)

# DQN with Prioritized Experience Replay
class DQNPer:
    def __init__(self, q_net, q_net_target, optimizer, loss_fn,
                 replay_buffer, gamma=0.99, tau=0.01,
                 batch_size=64, epsilon=0.1):
        self.q_net = q_net
        self.q_net_target = q_net_target
        self.optimizer = optimizer
        self.loss_fn = loss_fn
        self.replay_buffer = replay_buffer
        self.gamma = gamma
        self.tau = tau
        self.batch_size = batch_size
        self.epsilon = epsilon

    def act_discrete_with_noise(self, state):
        if random.random() < self.epsilon:
            return random.randrange(action_space)
        with torch.no_grad():
            q_values = self.q_net(state)
            return q_values.argmax().item()

    def store_episode(self, episode):
        for transition in episode:
            state, action, next_state, reward, done = transition
            self.replay_buffer.push(state, action, next_state, reward, done)

    def step(self):
        if len(self.replay_buffer) < self.batch_size:
            return
        batch, indices, weights = self.replay_buffer.sample(self.batch_size)

        states, actions, next_states, rewards, dones = zip(*batch)

        states = torch.tensor(states, dtype=torch.float32, device=device)
        actions = torch.tensor(actions, dtype=torch.int64, device=device).unsqueeze(1)
        next_states = torch.tensor(next_states, dtype=torch.float32, device=device)
        rewards = torch.tensor(rewards, dtype=torch.float32, device=device).unsqueeze(1)
        dones = torch.tensor(dones, dtype=torch.float32, device=device).unsqueeze(1)
        weights = weights.unsqueeze(1)

        q_values = self.q_net(states).gather(1, actions)
        with torch.no_grad():
            next_q_values = self.q_net_target(next_states).max(1)[0].unsqueeze(1)
            target_q = rewards + self.gamma * next_q_values * (1 - dones)

        td_errors = target_q - q_values
        loss = (weights * self.loss_fn(q_values, target_q, reduction='sum')).mean()

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        errors = td_errors.detach().cpu().numpy()
        self.replay_buffer.update_priorities(indices, errors)

        # Soft update target network
        for target_param, param in zip(self.q_net_target.parameters(), self.q_net.parameters()):
            target_param.data.copy_(self.tau * param.data + (1.0 - self.tau) * target_param.data)

# Main training script
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

env = gym.make("CartPole-v0")
observation_dim = env.observation_space.shape[0]
action_space = env.action_space.n

max_episodes = 1000
max_steps = 200
solved_reward = 190
solved_repeat = 5

q_net = QNet(input_dim=observation_dim, hidden_dim=16, output_dim=action_space).to(device)
q_net_target = QNet(input_dim=observation_dim, hidden_dim=16, output_dim=action_space).to(device)
q_net_target.load_state_dict(q_net.state_dict())

optimizer = optim.Adam(q_net.parameters(), lr=1e-3)
loss_fn = nn.MSELoss(reduction='sum')
buffer = PrioritizedReplayBuffer(capacity=10000, alpha=0.6, epsilon=1e-5)

dqn_per = DQNPer(q_net, q_net_target, optimizer, loss_fn,
                 buffer, gamma=0.99, tau=0.01,
                 batch_size=64, epsilon=0.1)

smoothed_reward = 0.0
solved_count = 0

for episode in range(max_episodes):
    state_np = env.reset()
    state = torch.tensor(state_np, dtype=torch.float32).unsqueeze(0).to(device)
    total_reward = 0
    episode_transitions = []

    for step in range(max_steps):
        action = dqn_per.act_discrete_with_noise(state)
        next_state_np, reward, done, _ = env.step(action)
        next_state = torch.tensor(next_state_np, dtype=torch.float32).unsqueeze(0).to(device)

        episode_transitions.append((state.cpu().numpy(), action, next_state.cpu().numpy(), reward, done))
        total_reward += reward
        state = next_state

        if done:
            break

    dqn_per.store_episode(episode_transitions)

    if episode > 100:
        for _ in range(len(episode_transitions)):
            dqn_per.step()

    smoothed_reward = 0.9 * smoothed_reward + 0.1 * total_reward
    print(f"Episode {episode} | Total Reward: {total_reward:.2f} | Smoothed Reward: {smoothed_reward:.2f}")

    if smoothed_reward >= solved_reward:
        solved_count += 1
        if solved_count >= solved_repeat:
            print(f"Solved CartPole in {episode} episodes!")
            break
    else:
        solved_count = 0

env.close()