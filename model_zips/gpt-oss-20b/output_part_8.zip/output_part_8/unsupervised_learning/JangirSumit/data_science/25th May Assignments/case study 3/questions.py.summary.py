import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
import numpy as np

def main():
    # 1. Data Loading
    df_fyntra = pd.read_csv("FyntraCustomerData.csv")

    # 2. Exploratory Data Analysis (EDA)
    sns.set_style("whitegrid")
    plt.figure(figsize=(8, 6))
    sns.jointplot(x="Time_on_Website", y="Yearly_Amount_Spent", data=df_fyntra, kind="scatter")
    plt.show()

    plt.figure(figsize=(4, 4))
    corr = df_fyntra[["Time_on_Website", "Yearly_Amount_Spent"]].corr()
    sns.heatmap(corr, annot=True, cmap="coolwarm", fmt=".2f")
    plt.title("Correlation between Time on Website and Yearly Amount Spent")
    plt.show()

    # 3. Repeat EDA for App Usage
    plt.figure(figsize=(8, 6))
    sns.jointplot(x="Time_on_App", y="Yearly_Amount_Spent", data=df_fyntra, kind="scatter")
    plt.show()

    plt.figure(figsize=(4, 4))
    corr = df_fyntra[["Time_on_App", "Yearly_Amount_Spent"]].corr()
    sns.heatmap(corr, annot=True, cmap="coolwarm", fmt=".2f")
    plt.title("Correlation between Time on App and Yearly Amount Spent")
    plt.show()

    # 4. Pairplot for Global Relationships
    sns.pairplot(df_fyntra, corner=True)
    plt.show()

    # 5. Data Splitting
    X = df_fyntra[["Length_of_Membership"]]
    Y = df_fyntra["Yearly_Amount_Spent"]
    train_x, test_x, train_y, test_y = train_test_split(
        X, Y, test_size=0.3, random_state=85
    )

    # 6. Linear Regression Model Training
    model = LinearRegression()
    model.fit(train_x, train_y)

    # 7. Model Evaluation
    predicted_values = model.predict(test_x)

    plt.figure(figsize=(6, 6))
    plt.scatter(test_y, predicted_values, alpha=0.7)
    plt.plot([test_y.min(), test_y.max()], [test_y.min(), test_y.max()], "r--")
    plt.xlabel("Actual Yearly Amount Spent")
    plt.ylabel("Predicted Yearly Amount Spent")
    plt.title("Predicted vs Actual Values")
    plt.show()

    # 8. Error Calculation
    rmse = np.sqrt(mean_squared_error(test_y, predicted_values))
    print(f"Root Mean Squared Error (RMSE): {rmse:.2f}")

if __name__ == "__main__":
    main()
