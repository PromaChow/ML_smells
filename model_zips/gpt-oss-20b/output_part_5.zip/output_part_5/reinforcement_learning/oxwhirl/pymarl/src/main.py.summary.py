import os
import sys
import copy
import argparse
import yaml
import numpy as np
import torch
from sacred import Experiment
from sacred.observers import FileStorageObserver
from run import run

ex = Experiment('pymarl')

def recursive_dict_update(d, u):
    for k, v in u.items():
        if isinstance(v, dict) and isinstance(d.get(k), dict):
            recursive_dict_update(d[k], v)
        else:
            d[k] = copy.deepcopy(v)
    return d

def load_yaml(path):
    if not os.path.exists(path):
        return {}
    with open(path, 'r') as f:
        return yaml.safe_load(f) or {}

def _get_config(env_cfg_name, algo_cfg_name):
    base_cfg = load_yaml('config/default.yaml')
    env_cfg_path = os.path.join('config', 'envs', env_cfg_name)
    env_cfg = load_yaml(env_cfg_path)
    algo_cfg_path = os.path.join('config', 'algs', algo_cfg_name)
    algo_cfg = load_yaml(algo_cfg_path)
    cfg = recursive_dict_update(base_cfg, env_cfg)
    cfg = recursive_dict_update(cfg, algo_cfg)
    return cfg

@ex.main
def my_main(run, config):
    config_copy = copy.deepcopy(config)
    seed = config_copy.get('seed', 0)
    np.random.seed(seed)
    torch.manual_seed(seed)
    env_args = config_copy.get('env_args', {})
    env_args['seed'] = seed
    config_copy['env_args'] = env_args
    logger = run.get_logger()
    run.run(run, config_copy, logger)

if __name__ == '__main__':
    original_args = sys.argv[1:]
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--env-config', default='default.yaml')
    parser.add_argument('--config', default='default.yaml')
    known_args, unknown_args = parser.parse_known_args(original_args)

    config = _get_config(known_args.env_config, known_args.config)
    ex.add_config(config)

    results_path = os.path.join('results', 'sacred')
    os.makedirs(results_path, exist_ok=True)
    ex.observers.append(FileStorageObserver.create(results_path))

    ex.run_commandline(unknown_args)