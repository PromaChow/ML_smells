import random
import numpy as np
import torch


def set_global_seeds(seed: int) -> None:
    """Synchronize random number generators across random, numpy, and torch."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


class Seeder:
    def __init__(self, init_seed: int = 0) -> None:
        self.rng = np.random.RandomState(init_seed)
        self.max = np.iinfo(np.int32).max

    def __call__(self, size: int = 1) -> list[int]:
        seeds = self.rng.randint(0, self.max, size=size)
        return list(seeds) if size > 1 else [int(seeds[0])] if size == 1 else []