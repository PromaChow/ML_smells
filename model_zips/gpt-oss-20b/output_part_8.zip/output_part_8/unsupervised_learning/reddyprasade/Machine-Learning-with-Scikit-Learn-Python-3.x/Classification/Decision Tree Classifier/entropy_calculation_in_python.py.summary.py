import numpy as np
import pandas as pd
from scipy import stats

def entropy1(labels, base=np.e):
    _, counts = np.unique(labels, return_counts=True)
    return stats.entropy(counts, base=base)

def entropy2(labels, base=np.e):
    n = len(labels)
    if n <= 1:
        return 0.0
    _, counts = np.unique(labels, return_counts=True)
    probs = counts / n
    if np.count_nonzero(probs) <= 1:
        return 0.0
    log_probs = np.log(probs) / np.log(base)
    return -np.sum(probs * log_probs)

def entropy3(labels, base=np.e):
    s = pd.Series(labels)
    probs = s.value_counts(normalize=True).values
    log_probs = np.log(probs) / np.log(base)
    return -np.sum(probs * log_probs)

def entropy4(labels, base=np.e):
    _, counts = np.unique(labels, return_counts=True)
    probs = counts / counts.sum()
    log_probs = np.log(probs) / np.log(base)
    return -np.sum(probs * log_probs)

if __name__ == "__main__":
    labels = [1, 2, 1, 3, 2, 1, 4, 5, 5, 5]
    print("entropy1:", entropy1(labels))
    print("entropy2:", entropy2(labels))
    print("entropy3:", entropy3(labels))
    print("entropy4:", entropy4(labels))