import numpy as np
from core.augment.randaugment.policies import randaug_policies
from core.augment import transform


class RandAugmentPipeline:
    def __init__(self):
        self.policies = randaug_policies()
        self.mean, self.std = transform.get_mean_and_std()

    def augment(self, image: np.ndarray) -> np.ndarray:
        # Convert to float32 and scale to [0, 1]
        img = image.astype(np.float32) / 255.0

        # Normalize
        mean = self.mean.reshape(1, 1, -1)
        std = self.std.reshape(1, 1, -1)
        img = (img - mean) / std

        # Randomly select a policy and apply it
        policy = np.random.choice(self.policies)
        img = transform.apply_policy(img, policy)

        # Apply cutout
        img = transform.cutout_numpy(img)

        # Denormalize
        img = img * std + mean
        img = img * 255.0
        img = np.clip(img, 0, 255)

        return img.astype(np.uint8)