import numpy as np


class MultiArmedBandit:
    def __init__(self, bandits, arms, context_type="tensor"):
        self.bandits = bandits
        self.arms = arms
        self.context_type = context_type
        self.curr_bandit = 0

    def set_current_bandit(self, idx):
        if not (0 <= idx < self.bandits):
            raise ValueError("Bandit index out of range")
        self.curr_bandit = idx


class GaussianMAB(MultiArmedBandit):
    def __init__(self, bandits, arms, reward_means=None, context_type="tensor"):
        if reward_means is None:
            reward_means = np.random.random((bandits, arms))
        else:
            reward_means = np.array(reward_means)
            if reward_means.shape != (bandits, arms):
                raise ValueError("reward_means shape must be (bandits, arms)")
        self.reward_means = reward_means
        super().__init__(bandits, arms, context_type)

    def _compute_reward(self, action):
        if not (0 <= action < self.arms):
            raise ValueError("Action out of range")
        mean = self.reward_means[self.curr_bandit, action]
        reward = np.random.normal(mean)
        max_mean = np.max(self.reward_means[self.curr_bandit, :])
        return reward, max_mean

