import torch
import torch.nn as nn


class ConvPosDepBias(nn.Module):
    """
    Convolution with position-dependent bias.
    If activation is provided, it is applied after adding the bias.
    """
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int,
                 board_size: int, activation: nn.Module = None):
        super().__init__()
        padding = kernel_size // 2
        self.conv = nn.Conv2d(in_channels, out_channels,
                              kernel_size=kernel_size,
                              padding=padding,
                              bias=False)
        self.pos_bias = nn.Parameter(torch.zeros(1, out_channels, board_size, board_size))
        self.activation = activation

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = self.conv(x) + self.pos_bias
        if self.activation is not None:
            out = self.activation(out)
        return out


class Conv4PosDep(nn.Module):
    def __init__(self, N: int, Nfeat: int):
        super().__init__()
        self.N = N
        self.Nfeat = Nfeat
        self.train_dir = f"./train_N{N}_Nfeat{Nfeat}"
        NKfirst = 16
        NK = 16
        self.l1 = ConvPosDepBias(Nfeat, NKfirst, kernel_size=5,
                                 board_size=N, activation=nn.ELU())
        self.l2 = ConvPosDepBias(NKfirst, NK, kernel_size=3,
                                 board_size=N, activation=nn.ELU())
        self.l3 = ConvPosDepBias(NK, NK, kernel_size=3,
                                 board_size=N, activation=nn.ELU())
        self.l4 = ConvPosDepBias(NK, 1, kernel_size=3,
                                 board_size=N, activation=None)

    def forward(self, feature_planes: torch.Tensor) -> torch.Tensor:
        x = self.l1(feature_planes)
        x = self.l2(x)
        x = self.l3(x)
        conv4 = self.l4(x)
        logits = conv4.view(-1, self.N * self.N)
        return logits


class Conv12PosDepELU(nn.Module):
    def __init__(self, N: int, Nfeat: int):
        super().__init__()
        self.N = N
        self.Nfeat = Nfeat
        self.train_dir = f"./train_N{N}_Nfeat{Nfeat}"
        NKfirst = 192
        NK = 192
        self.l1 = ConvPosDepBias(Nfeat, NKfirst, kernel_size=5,
                                 board_size=N, activation=nn.ELU())
        self.middle_layers = nn.ModuleList([
            ConvPosDepBias(NK, NK, kernel_size=3,
                           board_size=N, activation=nn.ELU())
            for _ in range(10)
        ])
        self.l12 = ConvPosDepBias(NK, 1, kernel_size=3,
                                  board_size=N, activation=None)

    def forward(self, feature_planes: torch.Tensor) -> torch.Tensor:
        x = self.l1(feature_planes)
        for layer in self.middle_layers:
            x = layer(x)
        conv12 = self.l12(x)
        logits = conv12.view(-1, self.N * self.N)
        return logits

