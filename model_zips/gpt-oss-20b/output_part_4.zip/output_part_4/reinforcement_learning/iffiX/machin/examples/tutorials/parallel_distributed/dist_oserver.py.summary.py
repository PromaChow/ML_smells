import time
from machin import World, OrderedServerSimpleImpl

def main():
    world = World(world_size=3, name=None, rpc_timeout=20)
    world.set_name(str(world.rank))
    group = world.create_group("group", [0, 1, 2])

    if world.rank == 0:
        server = OrderedServerSimpleImpl(name="server", group=group)
        time.sleep(5)
    else:
        time.sleep(2)
        server = world.get_group("group").get_paired("server").to_here()

    if world.rank != 0:
        assert server.push("a", "value", 1), "Push 1 failed"
        assert server.push("a", "value2", 2), "Push 2 failed"
        assert server.push("a", "value3", 3), "Push 3 failed"

        assert server.pull("a", 3) == "value3", "Pull 3 failed"
        assert server.pull("a", 2) == "value2", "Pull 2 failed"
        assert server.pull("a", 1) is None, "Pull 1 should be None"
        assert server.pull("b", 1) is None, "Pull b should be None"

        print("Ordered server check passed")

    world.wait_for_all()
    world.destroy_group("group")
    world.shutdown()

if __name__ == "__main__":
    main()
