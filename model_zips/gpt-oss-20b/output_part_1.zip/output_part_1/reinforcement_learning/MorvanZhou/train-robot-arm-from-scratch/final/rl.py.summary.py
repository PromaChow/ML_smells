import numpy as np
import tensorflow as tf

# Hyperparameters
LR_A = 0.001
LR_C = 0.001
GAMMA = 0.9
TAU = 0.01
MEMORY_CAPACITY = 30000
BATCH_SIZE = 32

class DDPG:
    def __init__(self, s_dim, a_dim, a_bound):
        self.s_dim = s_dim
        self.a_dim = a_dim
        self.a_bound = a_bound

        # Memory buffer
        self.memory = np.zeros((MEMORY_CAPACITY, s_dim * 2 + a_dim + 1))
        self.pointer = 0
        self.memory_full = False

        # TensorFlow graph
        self.s = tf.placeholder(tf.float32, [None, s_dim], name='state')
        self.a = tf.placeholder(tf.float32, [None, a_dim], name='action')
        self.r = tf.placeholder(tf.float32, [None, 1], name='reward')
        self.s_ = tf.placeholder(tf.float32, [None, s_dim], name='next_state')

        # Actor networks
        self.actor_eval = self._build_actor(self.s, scope='actor_eval')
        self.actor_target = self._build_actor(self.s_, scope='actor_target')
        # Critic networks
        self.q_eval = self._build_critic(self.s, self.a, scope='critic_eval')
        self.q_target = self._build_critic(self.s_, self.a_, scope='critic_target')

        # Parameters
        self.actor_eval_params = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES,
                                                   scope='actor_eval')
        self.actor_target_params = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES,
                                                     scope='actor_target')
        self.critic_eval_params = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES,
                                                    scope='critic_eval')
        self.critic_target_params = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES,
                                                      scope='critic_target')

        # Losses and optimizers
        q_target_ = self.r + GAMMA * self.q_target
        self.critic_loss = tf.reduce_mean(tf.squared_difference(q_target_, self.q_eval))
        self.actor_loss = -tf.reduce_mean(self.q_eval)

        self.critic_optimizer = tf.train.AdamOptimizer(LR_C)
        self.actor_optimizer = tf.train.AdamOptimizer(LR_A)

        self.critic_train_op = self.critic_optimizer.minimize(self.critic_loss,
                                                              var_list=self.critic_eval_params)
        self.actor_train_op = self.actor_optimizer.minimize(self.actor_loss,
                                                            var_list=self.actor_eval_params)

        # Soft updates
        self.update_actor_target_op = self._update_target(self.actor_eval_params,
                                                          self.actor_target_params)
        self.update_critic_target_op = self._update_target(self.critic_eval_params,
                                                           self.critic_target_params)

        # Saver
        self.saver = tf.train.Saver()

        # Session
        self.sess = tf.Session()
        self.sess.run(tf.global_variables_initializer())

    def _build_actor(self, state, scope, reuse=False):
        with tf.variable_scope(scope, reuse=reuse):
            l1 = tf.layers.dense(state, 300, activation=tf.nn.relu,
                                 kernel_initializer=tf.random_normal_initializer(0., .1))
            out = tf.layers.dense(l1, self.a_dim, activation=tf.nn.tanh,
                                  kernel_initializer=tf.random_normal_initializer(0., .1))
            return out * self.a_bound

    def _build_critic(self, state, action, scope, reuse=False):
        with tf.variable_scope(scope, reuse=reuse):
            sa = tf.concat([state, action], axis=1)
            l1 = tf.layers.dense(sa, 300, activation=tf.nn.relu,
                                 kernel_initializer=tf.random_normal_initializer(0., .1))
            out = tf.layers.dense(l1, 1,
                                  kernel_initializer=tf.random_normal_initializer(0., .1))
            return out

    def _update_target(self, source_params, target_params):
        update_ops = []
        for source, target in zip(source_params, target_params):
            op = target.assign((1 - TAU) * target + TAU * source)
            update_ops.append(op)
        return tf.group(*update_ops)

    def choose_action(self, state):
        state = state[np.newaxis, :]
        action = self.sess.run(self.actor_eval, feed_dict={self.s: state})
        return action[0]

    def store_transition(self, s, a, r, s_):
        transition = np.hstack((s, a, [r], s_))
        self.memory[self.pointer, :] = transition
        self.pointer = (self.pointer + 1) % MEMORY_CAPACITY
        if self.pointer == 0:
            self.memory_full = True

    def learn(self):
        if not self.memory_full and self.pointer < BATCH_SIZE:
            return
        indices = np.random.choice(MEMORY_CAPACITY if self.memory_full else self.pointer,
                                   BATCH_SIZE, replace=False)
        batch = self.memory[indices, :]
        s_batch = batch[:, :self.s_dim]
        a_batch = batch[:, self.s_dim:self.s_dim + self.a_dim]
        r_batch = batch[:, self.s_dim + self.a_dim:self.s_dim + self.a_dim + 1]
        s_batch_ = batch[:, -self.s_dim:]

        feed_dict = {self.s: s_batch,
                     self.a: a_batch,
                     self.r: r_batch,
                     self.s_: s_batch_}

        self.sess.run([self.actor_train_op, self.critic_train_op,
                       self.update_actor_target_op, self.update_critic_target_op],
                      feed_dict=feed_dict)

    def save(self, path):
        self.saver.save(self.sess, path)

    def restore(self, path):
        self.saver.restore(self.sess, path)