import os
import glob
import cv2
import numpy as np
from skimage.feature import hog
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import joblib
from collections import deque
from scipy.ndimage.measurements import label
from moviepy.editor import VideoFileClip

# ---------- Feature extraction helpers ----------
def convert_color(img, conv='RGB2YCrCb'):
    if conv == 'RGB2YCrCb':
        return cv2.cvtColor(img, cv2.COLOR_RGB2YCrCb)
    elif conv == 'RGB2HLS':
        return cv2.cvtColor(img, cv2.COLOR_RGB2HLS)
    elif conv == 'RGB2HSV':
        return cv2.cvtColor(img, cv2.COLOR_RGB2HSV)
    else:
        return img

def bin_spatial(img, size=(32, 32)):
    return cv2.resize(img, size).ravel()

def color_hist(img, nbins=32, bins_range=(0, 256)):
    channel1_hist = np.histogram(img[:, :, 0], bins=nbins, range=bins_range)
    channel2_hist = np.histogram(img[:, :, 1], bins=nbins, range=bins_range)
    channel3_hist = np.histogram(img[:, :, 2], bins=nbins, range=bins_range)
    hist_features = np.concatenate(
        (channel1_hist[0], channel2_hist[0], channel3_hist[0]))
    return hist_features

def get_hog_features(img, orient=9, pix_per_cell=8,
                     cell_per_block=2, feature_vec=True, vis=False):
    if vis:
        features, hog_image = hog(img,
                                  orientations=orient,
                                  pixels_per_cell=(pix_per_cell, pix_per_cell),
                                  cells_per_block=(cell_per_block, cell_per_block),
                                  transform_sqrt=True,
                                  visualize=True,
                                  feature_vector=feature_vec)
        return features, hog_image
    else:
        features = hog(img,
                       orientations=orient,
                       pixels_per_cell=(pix_per_cell, pix_per_cell),
                       cells_per_block=(cell_per_block, cell_per_block),
                       transform_sqrt=True,
                       feature_vector=feature_vec)
        return features

def single_img_features(img, color_space='RGB', spatial_size=(32, 32),
                        hist_bins=32, orient=9, pix_per_cell=8,
                        cell_per_block=2, hog_channel=0,
                        spatial_feat=True, hist_feat=True, hog_feat=True):
    feature_image = convert_color(img, conv=f'RGB2{color_space}')
    features = []
    if spatial_feat:
        spatial_features = bin_spatial(feature_image, size=spatial_size)
        features.append(spatial_features)
    if hist_feat:
        hist_features = color_hist(feature_image, nbins=hist_bins)
        features.append(hist_features)
    if hog_feat:
        if hog_channel == 'ALL':
            hog_features = []
            for channel in range(feature_image.shape[2]):
                hog_features.append(
                    get_hog_features(feature_image[:, :, channel],
                                     orient, pix_per_cell,
                                     cell_per_block, feature_vec=True))
            hog_features = np.ravel(hog_features)
        else:
            hog_features = get_hog_features(feature_image[:, :, hog_channel],
                                            orient, pix_per_cell,
                                            cell_per_block, feature_vec=True)
        features.append(hog_features)
    return np.concatenate(features)

# ---------- Sliding window ----------
def slide_window(img, x_start_stop=[None, None], y_start_stop=[None, None],
                 xy_window=(64, 64), xy_overlap=(0.5, 0.5)):
    if x_start_stop[0] is None:
        x_start_stop[0] = 0
    if x_start_stop[1] is None:
        x_start_stop[1] = img.shape[1]
    if y_start_stop[0] is None:
        y_start_stop[0] = 0
    if y_start_stop[1] is None:
        y_start_stop[1] = img.shape[0]
    xspan = x_start_stop[1] - x_start_stop[0]
    yspan = y_start_stop[1] - y_start_stop[0]
    nx_pix_per_step = int(xy_window[0] * (1 - xy_overlap[0]))
    ny_pix_per_step = int(xy_window[1] * (1 - xy_overlap[1]))
    nx_windows = int((xspan - xy_window[0]) / nx_pix_per_step) + 1
    ny_windows = int((yspan - xy_window[1]) / ny_pix_per_step) + 1
    window_list = []
    for ys in range(ny_windows):
        for xs in range(nx_windows):
            startx = xs * nx_pix_per_step + x_start_stop[0]
            endx = startx + xy_window[0]
            starty = ys * ny_pix_per_step + y_start_stop[0]
            endy = starty + xy_window[1]
            window_list.append(((int(startx), int(starty)), (int(endx), int(endy))))
    return window_list

# ---------- Window search ----------
def search_windows(img, windows, clf, scaler,
                   color_space='RGB', spatial_size=(32, 32),
                   hist_bins=32, orient=9, pix_per_cell=8,
                   cell_per_block=2, hog_channel=0,
                   spatial_feat=True, hist_feat=True, hog_feat=True):
    hot_windows = []
    for window in windows:
        test_img = cv2.resize(img[window[0][1]:window[1][1],
                                 window[0][0]:window[1][0]], (64, 64))
        features = single_img_features(test_img, color_space=color_space,
                                       spatial_size=spatial_size,
                                       hist_bins=hist_bins, orient=orient,
                                       pix_per_cell=pix_per_cell,
                                       cell_per_block=cell_per_block,
                                       hog_channel=hog_channel,
                                       spatial_feat=spatial_feat,
                                       hist_feat=hist_feat, hog_feat=hog_feat)
        scaled_features = scaler.transform(np.array(features).reshape(1, -1))
        prediction = clf.predict(scaled_features)
        if prediction == 1:
            hot_windows.append(window)
    return hot_windows

# ---------- Heatmap utilities ----------
def add_heat(heatmap, bbox_list):
    for box in bbox_list:
        heatmap[box[0][1]:box[1][1], box[0][0]:box[1][0]] += 1
    return heatmap

def apply_threshold(heatmap, threshold):
    heatmap[heatmap <= threshold] = 0
    return heatmap

def draw_labeled_bboxes(img, labels):
    for car_number in range(1, labels[1]+1):
        nonzero = (labels[0] == car_number).nonzero()
        nonzeroy = np.array(nonzero[0])
        nonzerox = np.array(nonzero[1])
        bbox = ((np.min(nonzerox), np.min(nonzeroy)),
                (np.max(nonzerox), np.max(nonzeroy)))
        cv2.rectangle(img, bbox[0], bbox[1], (0, 0, 255), 6)
    return img

def find_windows_from_heatmap(heatmap, labels):
    bbox_list = []
    for car_number in range(1, labels[1]+1):
        nonzero = (labels[0] == car_number).nonzero()
        nonzeroy = np.array(nonzero[0])
        nonzerox = np.array(nonzero[1])
        bbox = ((np.min(nonzerox), np.min(nonzeroy)),
                (np.max(nonzerox), np.max(nonzeroy)))
        bbox_list.append(bbox)
    return bbox_list

def combine_boxes(boxes, overlap_thresh=0.5):
    if len(boxes) == 0:
        return []
    boxes = np.array(boxes)
    x1 = boxes[:,0,0]
    y1 = boxes[:,0,1]
    x2 = boxes[:,1,0]
    y2 = boxes[:,1,1]
    area = (x2 - x1 + 1) * (y2 - y1 + 1)
    idxs = np.argsort(y2)
    pick = []
    while len(idxs) > 0:
        last = len(idxs) - 1
        i = idxs[last]
        pick.append(i)
        xx1 = np.maximum(x1[i], x1[idxs[:last]])
        yy1 = np.maximum(y1[i], y1[idxs[:last]])
        xx2 = np.minimum(x2[i], x2[idxs[:last]])
        yy2 = np.minimum(y2[i], y2[idxs[:last]])
        w = np.maximum(0, xx2 - xx1 + 1)
        h = np.maximum(0, yy2 - yy1 + 1)
        overlap = (w * h) / area[idxs[:last]]
        idxs = np.delete(idxs, np.concatenate(([last],
                                                np.where(overlap > overlap_thresh)[0])))
    return boxes[pick].astype(int).tolist()

# ---------- Detection tracking ----------
class VehicleTracker:
    def __init__(self, max_frames=10, conf_threshold=8, miss_threshold=4, margin=50):
        self.max_frames = max_frames
        self.conf_threshold = conf_threshold
        self.miss_threshold = miss_threshold
        self.margin = margin
        self.detections = []

    def is_within_margin(self, box, other_box):
        cx, cy = (box[0][0]+box[1][0])//2, (box[0][1]+box[1][1])//2
        ocx, ocy = (other_box[0][0]+other_box[1][0])//2, (other_box[0][1]+other_box[1][1])//2
        return abs(cx-ocx) <= self.margin and abs(cy-ocy) <= self.margin

    def update(self, new_boxes):
        updated = []
        for det in self.detections:
            matched = False
            for nb in new_boxes:
                if self.is_within_margin(nb, det['bbox']):
                    det['bbox'] = nb
                    det['frames_seen'] += 1
                    det['frames_missed'] = 0
                    matched = True
                    break
            if not matched:
                det['frames_missed'] += 1
            if det['frames_missed'] <= self.miss_threshold:
                updated.append(det)
        for nb in new_boxes:
            if not any(self.is_within_margin(nb, d['bbox']) for d in updated):
                updated.append({'bbox': nb, 'frames_seen': 1, 'frames_missed': 0})
        self.detections = updated

    def get_active_boxes(self):
        return [d['bbox'] for d in self.detections if d['frames_seen'] >= self.conf_threshold]

# ---------- Drawing ----------
def draw_boxes(img, bbox_list, color=(0, 0, 255), thick=6):
    for box in bbox_list:
        cv2.rectangle(img, box[0], box[1], color, thick)
    return img

# ---------- Video processing ----------
def process_image(img, clf, scaler, tracker,
                  color_space='YCrCb', spatial_size=(32, 32),
                  hist_bins=32, orient=9, pix_per_cell=8,
                  cell_per_block=2, hog_channel=0,
                  spatial_feat=True, hist_feat=True, hog_feat=True,
                  window_scale=1.0):
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    windows = slide_window(img, x_start_stop=[None, None],
                           y_start_stop=[400, 640],
                           xy_window=(96, 96), xy_overlap=(0.75, 0.75))
    hot_windows = search_windows(img, windows, clf, scaler,
                                 color_space=color_space, spatial_size=spatial_size,
                                 hist_bins=hist_bins, orient=orient,
                                 pix_per_cell=pix_per_cell, cell_per_block=cell_per_block,
                                 hog_channel=hog_channel, spatial_feat=spatial_feat,
                                 hist_feat=hist_feat, hog_feat=hog_feat)
    heat = np.zeros_like(img[:, :, 0]).astype(np.float)
    heat = add_heat(heat, hot_windows)
    heat = apply_threshold(heat, threshold=2)
    labels = label(heat)
    boxes = find_windows_from_heatmap(heat, labels)
    boxes = combine_boxes(boxes)
    tracker.update(boxes)
    final_boxes = tracker.get_active_boxes()
    result = draw_boxes(img, final_boxes)
    result = cv2.cvtColor(result, cv2.COLOR_RGB2BGR)
    return result

# ---------- Main training ----------
def main():
    car_images = glob.glob('./images/vehicles/vehicles/*/*png')
    notcar_images = glob.glob('./images/non-vehicles/non-vehicles/*/*png')
    cars = [cv2.cvtColor(cv2.imread(p), cv2.COLOR_BGR2RGB) for p in car_images]
    notcars = [cv2.cvtColor(cv2.imread(p), cv2.COLOR_BGR2RGB) for p in notcar_images]
    color_space = 'YCrCb'
    spatial_size = (32, 32)
    hist_bins = 32
    orient = 9
    pix_per_cell = 8
    cell_per_block = 2
    hog_channel = 'ALL'
    spatial_feat = True
    hist_feat = True
    hog_feat = True
    car_features = [single_img_features(img, color_space=color_space,
                                        spatial_size=spatial_size,
                                        hist_bins=hist_bins,
                                        orient=orient,
                                        pix_per_cell=pix_per_cell,
                                        cell_per_block=cell_per_block,
                                        hog_channel=hog_channel,
                                        spatial_feat=spatial_feat,
                                        hist_feat=hist_feat,
                                        hog_feat=hog_feat)
                    for img in cars]
    notcar_features = [single_img_features(img, color_space=color_space,
                                           spatial_size=spatial_size,
                                           hist_bins=hist_bins,
                                           orient=orient,
                                           pix_per_cell=pix_per_cell,
                                           cell_per_block=cell_per_block,
                                           hog_channel=hog_channel,
                                           spatial_feat=spatial_feat,
                                           hist_feat=hist_feat,
                                           hog_feat=hog_feat)
                       for img in notcars]
    X = np.vstack((car_features, notcar_features)).astype(np.float64)
    y = np.hstack((np.ones(len(car_features)), np.zeros(len(notcar_features))))
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y)
    X_scaler = StandardScaler().fit(X_train)
    scaled_X_train = X_scaler.transform(X_train)
    scaled_X_test = X_scaler.transform(X_test)
    svc = SVC(kernel='linear', C=0.001, gamma=0.001, probability=False)
    svc.fit(scaled_X_train, y_train)
    print('Test Accuracy:', svc.score(scaled_X_test, y_test))
    joblib.dump(svc, 'svc_model.pkl')
    joblib.dump(X_scaler, 'scaler.pkl')
    # ---------- Video ----------
    clf = joblib.load('svc_model.pkl')
    scaler = joblib.load('scaler.pkl')
    tracker = VehicleTracker()
    def make_movie_clip():
        clip = VideoFileClip('./video-tracking-output.mp4')
        processed_clip = clip.fl_image(lambda frame: process_image(frame, clf, scaler, tracker))
        processed_clip.write_videofile('./project_video_class_full.mp4', audio=False)
    make_movie_clip()

if __name__ == "__main__":
    main()
