import pygame
import numpy as np
import abc
from typing import List, Tuple, Optional, Dict, Any


class PyGameWrapper(abc.ABC):
    def __init__(
        self,
        width: int = 640,
        height: int = 480,
        actions: Optional[List[int]] = None,
        reward_values: Optional[Dict[str, float]] = None,
        draw_screen: bool = True,
    ) -> None:
        self.width = width
        self.height = height
        self.actions = actions or [
            pygame.K_LEFT,
            pygame.K_RIGHT,
            pygame.K_UP,
            pygame.K_DOWN,
            pygame.K_SPACE,
        ]
        default_rewards = {
            "positive": 1.0,
            "negative": -1.0,
            "tick": 0.0,
            "loss": -10.0,
            "win": 10.0,
        }
        self.rewards: Dict[str, float] = default_rewards.copy()
        if reward_values:
            for key, value in reward_values.items():
                if key in self.rewards:
                    self.rewards[key] = value
        self.draw_screen = draw_screen
        self.screen: Optional[pygame.Surface] = None
        self.clock: Optional[pygame.time.Clock] = None
        self.rng = None

    def setRNG(self, rng) -> None:
        self.rng = rng

    def _setup(self) -> None:
        pygame.init()
        self.screen = pygame.display.set_mode((self.width, self.height))
        self.clock = pygame.time.Clock()

    def _setAction(self, action: Optional[int]) -> None:
        key = action if action is not None else pygame.K_F15
        keydown_event = pygame.event.Event(pygame.KEYDOWN, key=key)
        keyup_event = pygame.event.Event(pygame.KEYUP, key=key)
        pygame.event.post(keydown_event)
        pygame.event.post(keyup_event)

    def _draw_frame(self) -> None:
        if self.draw_screen and self.screen is not None:
            pygame.display.flip()

    def getScreenRGB(self) -> np.ndarray:
        if self.screen is None:
            raise RuntimeError("Screen not initialized. Call _setup() before capturing.")
        array = pygame.surfarray.array3d(self.screen)
        return array.astype(np.uint8)

    def tick(self, fps: int) -> None:
        if self.clock is None:
            raise RuntimeError("Clock not initialized. Call _setup() before ticking.")
        self.clock.tick_busy_loop(fps)

    def adjustRewards(self, **kwargs: float) -> None:
        for key, value in kwargs.items():
            if key in self.rewards:
                self.rewards[key] = value

    def getScreenDims(self) -> Tuple[int, int]:
        return (self.width, self.height)

    def getActions(self) -> List[int]:
        return self.actions

    def init(self) -> None:
        pass

    def reset(self) -> None:
        pass

    @abc.abstractmethod
    def getScore(self) -> Any:
        pass

    @abc.abstractmethod
    def game_over(self) -> bool:
        pass

    @abc.abstractmethod
    def step(self, dt: float) -> None:
        pass

    def getGameState(self) -> Optional[Dict[str, Any]]:
        return None
