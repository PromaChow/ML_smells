import tensorflow as tf
from external_module import medium_augment

def mean_teacher(x: tf.Tensor,
                 u: tf.Tensor,
                 height: int,
                 width: int,
                 seed: int = None) -> tuple[tf.Tensor, tf.Tensor, tf.Tensor]:
    """
    Apply medium-level data augmentations to labeled and unlabeled images.

    Parameters
    ----------
    x : tf.Tensor
        Labeled images, shape [batch, H, W, C].
    u : tf.Tensor
        Unlabeled images, shape [batch, H, W, C].
    height : int
        Target height for augmentations.
    width : int
        Target width for augmentations.
    seed : int, optional
        Random seed for reproducibility.

    Returns
    -------
    x_aug : tf.Tensor
        Augmented labeled images.
    u_t : tf.Tensor
        First augmented version of unlabeled images.
    u_s : tf.Tensor
        Second augmented version of unlabeled images.
    """
    x_aug = medium_augment(x, height=height, width=width, seed=seed)
    u_t = medium_augment(u, height=height, width=width, seed=seed)
    u_s = medium_augment(u, height=height, width=width, seed=seed)
    return x_aug, u_t, u_s


def ssl_loss_mean_teacher(labels_x: tf.Tensor,
                          logits_x: tf.Tensor,
                          logits_teacher: tf.Tensor,
                          logits_student: tf.Tensor) -> tuple[tf.Tensor, tf.Tensor]:
    """
    Compute the labeled cross‑entropy loss and the teacher‑student MSE loss.

    Parameters
    ----------
    labels_x : tf.Tensor
        Ground‑truth one‑hot labels for labeled data, shape [batch, num_classes].
    logits_x : tf.Tensor
        Student model logits for labeled data, shape [batch, num_classes].
    logits_teacher : tf.Tensor
        Teacher model logits for unlabeled data, shape [batch, num_classes].
    logits_student : tf.Tensor
        Student model logits for unlabeled data, shape [batch, num_classes].

    Returns
    -------
    x_loss : tf.Tensor
        Mean cross‑entropy loss over the labeled batch.
    loss_mt : tf.Tensor
        Mean squared error between teacher and student softmax outputs.
    """
    # Labeled cross‑entropy loss
    ce = tf.nn.softmax_cross_entropy_with_logits(labels=labels_x, logits=logits_x)
    x_loss = tf.reduce_mean(ce)

    # Softmax outputs
    prob_teacher = tf.nn.softmax(logits_teacher)
    prob_student = tf.nn.softmax(logits_student)

    # MSE loss between teacher and student predictions
    mse = tf.square(prob_teacher - prob_student)
    loss_mt = tf.reduce_mean(mse, axis=-1)  # mean over classes
    loss_mt = tf.reduce_mean(loss_mt)        # mean over batch

    return x_loss, loss_mt