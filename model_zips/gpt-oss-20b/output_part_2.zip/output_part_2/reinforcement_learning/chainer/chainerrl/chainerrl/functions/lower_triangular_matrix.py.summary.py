import numpy as np
import cupy as cp
import chainer
import chainer.backend

# CPU implementations
def _get_batch_diagonal_cpu(x):
    batch, n = x.shape[0], x.shape[1]
    rows, cols = np.diag_indices(n)
    return x[:, rows, cols]

def _set_batch_diagonal_cpu(x, diag_vals):
    batch, n = x.shape[0], x.shape[1]
    rows, cols = np.diag_indices(n)
    x[:, rows, cols] = diag_vals

def _get_batch_non_diagonal_cpu(x):
    batch, n = x.shape[0], x.shape[1]
    rows, cols = np.tril_indices(n, -1)
    return x[:, rows, cols]

def _set_batch_non_diagonal_cpu(x, non_diag_vals):
    batch, n = x.shape[0], x.shape[1]
    rows, cols = np.tril_indices(n, -1)
    x[:, rows, cols] = non_diag_vals

# GPU index array generation
def _diagonal_idx_array(batch, n):
    rows, cols = np.diag_indices(n)
    flat = np.ravel_multi_index((rows, cols), (n, n))
    offsets = np.arange(batch, dtype=np.int64)[:, None] * n * n
    idx = (flat[None, :] + offsets).ravel()
    return cp.array(idx, dtype=cp.int64)

def _non_diagonal_idx_array(batch, n):
    rows, cols = np.tril_indices(n, -1)
    flat = np.ravel_multi_index((rows, cols), (n, n))
    offsets = np.arange(batch, dtype=np.int64)[:, None] * n * n
    idx = (flat[None, :] + offsets).ravel()
    return cp.array(idx, dtype=cp.int64)

# GPU kernels
_set_batch_diagonal_gpu_kernel = cp.ElementwiseKernel(
    "int* idx, const float* src, float* dst",
    "",
    "dst[idx[i]] = src[i]",
    name="set_batch_diagonal_gpu"
)

_get_batch_diagonal_gpu_kernel = cp.ElementwiseKernel(
    "int* idx, const float* src",
    "float out",
    "out = src[idx[i]]",
    name="get_batch_diagonal_gpu"
)

_set_batch_non_diagonal_gpu_kernel = cp.ElementwiseKernel(
    "int* idx, const float* src, float* dst",
    "",
    "dst[idx[i]] = src[i]",
    name="set_batch_non_diagonal_gpu"
)

_get_batch_non_diagonal_gpu_kernel = cp.ElementwiseKernel(
    "int* idx, const float* src",
    "float out",
    "out = src[idx[i]]",
    name="get_batch_non_diagonal_gpu"
)

# GPU implementations
def _set_batch_diagonal_gpu(x, diag_vals):
    batch, n = x.shape[0], x.shape[1]
    idx = _diagonal_idx_array(batch, n)
    _set_batch_diagonal_gpu_kernel(idx, diag_vals.ravel(), x)

def _get_batch_diagonal_gpu(x):
    batch, n = x.shape[0], x.shape[1]
    idx = _diagonal_idx_array(batch, n)
    return _get_batch_diagonal_gpu_kernel(idx, x)

def _set_batch_non_diagonal_gpu(x, non_diag_vals):
    batch, n = x.shape[0], x.shape[1]
    idx = _non_diagonal_idx_array(batch, n)
    _set_batch_non_diagonal_gpu_kernel(idx, non_diag_vals.ravel(), x)

def _get_batch_non_diagonal_gpu(x):
    batch, n = x.shape[0], x.shape[1]
    idx = _non_diagonal_idx_array(batch, n)
    return _get_batch_non_diagonal_gpu_kernel(idx, x)

# Unified wrappers
def _get_batch_diagonal(x):
    if isinstance(x, cp.ndarray):
        return _get_batch_diagonal_gpu(x)
    else:
        return _get_batch_diagonal_cpu(x)

def _set_batch_diagonal(x, diag_vals):
    if isinstance(x, cp.ndarray):
        _set_batch_diagonal_gpu(x, diag_vals)
    else:
        _set_batch_diagonal_cpu(x, diag_vals)

def _get_batch_non_diagonal(x):
    if isinstance(x, cp.ndarray):
        return _get_batch_non_diagonal_gpu(x)
    else:
        return _get_batch_non_diagonal_cpu(x)

def _set_batch_non_diagonal(x, non_diag_vals):
    if isinstance(x, cp.ndarray):
        _set_batch_non_diagonal_gpu(x, non_diag_vals)
    else:
        _set_batch_non_diagonal_cpu(x, non_diag_vals)

# Chainer Function for lower triangular matrix
class LowerTriangularMatrix(chainer.Function):
    def forward(self, inputs):
        diag, non_diag = inputs
        xp = chainer.backend.get_array_module(diag)
        batch, n = diag.shape[0], diag.shape[1]
        out = xp.zeros((batch, n, n), dtype=diag.dtype)
        _set_batch_non_diagonal(out, non_diag)
        _set_batch_diagonal(out, diag)
        return (out,)

    def backward(self, inputs, grads):
        grad_output, = grads
        grad_diag = _get_batch_diagonal(grad_output)
        grad_non_diag = _get_batch_non_diagonal(grad_output)
        return (grad_diag, grad_non_diag)

def lower_triangular_matrix(diagonal, non_diagonal):
    return LowerTriangularMatrix()(diagonal, non_diagonal)