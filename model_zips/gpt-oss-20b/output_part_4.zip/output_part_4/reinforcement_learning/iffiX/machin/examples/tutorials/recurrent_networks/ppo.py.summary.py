import gym
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from collections import deque

# --------------------------------------------------------------------------- #
# Utility functions and classes
# --------------------------------------------------------------------------- #

def disable_view_window():
    """Placeholder to disable rendering; no operation needed for gym env."""
    pass

def convert(state):
    """Convert RAM state (numpy array) to torch tensor."""
    return torch.tensor(state, dtype=torch.float32, device=device)

class History:
    def __init__(self, depth, state_size):
        self.depth = depth
        self.state_size = state_size
        self.states = deque(maxlen=depth)
        # Initialize with zero states
        for _ in range(depth):
            self.states.append(torch.zeros(state_size, device=device))

    def append(self, state):
        self.states.append(state)

    def get_tensor(self):
        # Concatenate along first dimension
        return torch.stack(list(self.states)).view(1, -1)

# --------------------------------------------------------------------------- #
# Network definitions
# --------------------------------------------------------------------------- #

class Actor(nn.Module):
    def __init__(self, input_size, action_num):
        super().__init__()
        self.fc1 = nn.Linear(input_size, 256)
        self.fc2 = nn.Linear(256, 128)
        self.fc3 = nn.Linear(128, action_num)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        logits = self.fc3(x)
        probs = F.softmax(logits, dim=-1)
        log_probs = F.log_softmax(logits, dim=-1)
        entropy = -(probs * log_probs).sum(-1, keepdim=True)
        return probs, log_probs, entropy

class Critic(nn.Module):
    def __init__(self, input_size):
        super().__init__()
        self.fc1 = nn.Linear(input_size, 256)
        self.fc2 = nn.Linear(256, 128)
        self.fc3 = nn.Linear(128, 1)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        value = self.fc3(x)
        return value

# --------------------------------------------------------------------------- #
# PPO implementation
# --------------------------------------------------------------------------- #

class PPO:
    def __init__(self, actor, critic, actor_lr=1e-5, critic_lr=1e-4, gamma=0.99,
                 lam=0.95, clip_epsilon=0.2, entropy_coef=0.01, device='cpu'):
        self.actor = actor
        self.critic = critic
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=actor_lr)
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=critic_lr)
        self.gamma = gamma
        self.lam = lam
        self.clip_epsilon = clip_epsilon
        self.entropy_coef = entropy_coef
        self.device = device
        self.episode_buffer = []

    def store_episode(self, episode_data):
        self.episode_buffer.append(episode_data)

    def update(self):
        if not self.episode_buffer:
            return
        # Flatten all episodes
        obs = []
        for ep in self.episode_buffer:
            obs.extend(ep)
        self.episode_buffer = []

        states = torch.cat([o['state'] for o in obs], dim=0)
        actions = torch.cat([o['action'] for o in obs], dim=0)
        rewards = torch.tensor([o['reward'] for o in obs], dtype=torch.float32, device=self.device)
        dones = torch.tensor([o['done'] for o in obs], dtype=torch.float32, device=self.device)
        old_log_probs = torch.cat([o['log_prob'] for o in obs], dim=0)
        old_values = torch.cat([o['value'] for o in obs], dim=0)

        # Compute returns and advantages
        returns = []
        gae = 0
        next_value = 0
        for i in reversed(range(len(rewards))):
            mask = 1.0 - dones[i]
            delta = rewards[i] + self.gamma * next_value * mask - old_values[i]
            gae = delta + self.gamma * self.lam * mask * gae
            returns.insert(0, gae + old_values[i])
            next_value = old_values[i]
        returns = torch.stack(returns)

        advantages = returns - old_values.detach()
        advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

        # Actor loss
        probs, log_probs, entropy = self.actor(states)
        action_log_probs = log_probs.gather(1, actions.unsqueeze(-1)).squeeze(-1)
        ratio = torch.exp(action_log_probs - old_log_probs.squeeze(-1))
        surr1 = ratio * advantages
        surr2 = torch.clamp(ratio, 1.0 - self.clip_epsilon, 1.0 + self.clip_epsilon) * advantages
        actor_loss = -torch.min(surr1, surr2).mean() - self.entropy_coef * entropy.mean()

        # Critic loss
        values = self.critic(states).squeeze(-1)
        critic_loss = F.mse_loss(values, returns)

        # Optimize
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        self.actor_optimizer.step()

        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        self.critic_optimizer.step()

# --------------------------------------------------------------------------- #
# Main training loop
# --------------------------------------------------------------------------- #

device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
env = gym.make('Frostbite-ram-v0')
action_num = env.action_space.n
max_episodes = 20000
history_depth = 4
state_size = env.observation_space.shape[0]  # 128 for RAM
input_size = state_size * history_depth

disable_view_window()

actor = Actor(input_size, action_num).to(device)
critic = Critic(input_size).to(device)
ppo = PPO(actor, critic, device=device)

smoothed_reward = 0.0
alpha = 0.99

for episode in range(1, max_episodes + 1):
    obs = env.reset()
    state = convert(obs)
    history = History(history_depth, state_size)
    history.append(state)
    episode_data = []
    total_reward = 0.0
    done = False

    while not done:
        input_tensor = history.get_tensor()
        probs, log_probs, _ = actor(input_tensor)
        dist = torch.distributions.Categorical(probs)
        action = dist.sample()
        log_prob = dist.log_prob(action)
        next_obs, reward, done, _ = env.step(action.item())
        next_state = convert(next_obs)
        history.append(next_state)

        episode_data.append({
            'state': input_tensor.detach(),
            'action': action.unsqueeze(0).detach(),
            'reward': reward,
            'done': done,
            'log_prob': log_prob.unsqueeze(0).detach(),
            'value': critic(input_tensor).detach()
        })

        total_reward += reward

    ppo.store_episode(episode_data)
    ppo.update()

    smoothed_reward = alpha * smoothed_reward + (1 - alpha) * total_reward
    print(f'Episode {episode}\tReward {total_reward:.2f}\tSmoothed {smoothed_reward:.2f}')

env.close()