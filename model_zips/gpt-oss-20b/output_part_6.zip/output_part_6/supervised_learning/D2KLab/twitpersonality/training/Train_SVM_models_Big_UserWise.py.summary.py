import os
import numpy as np
import pandas as pd
from pathlib import Path
from sklearn.svm import SVR
from sklearn.model_selection import KFold
import joblib
import datasetUtils
import embeddings

def load_data(file_path):
    training_samples = []
    yO, yC, yE, yA, yN = [], [], [], [], []
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            parts = line.strip().split(',')
            if len(parts) < 6:
                continue
            # Skip user ID
            traits = list(map(float, parts[1:6]))
            yO.append(traits[0])
            yC.append(traits[1])
            yE.append(traits[2])
            yA.append(traits[3])
            yN.append(traits[4])
            embedding = list(map(float, parts[6:]))
            training_samples.append(embedding)
    return (
        np.array(training_samples),
        np.array(yO),
        np.array(yC),
        np.array(yE),
        np.array(yA),
        np.array(yN)
    )

def subset_and_shuffle(X, yO, yC, yE, yA, yN, subset_size=30000, random_state=42):
    X_subset = X[:subset_size]
    yO_subset = yO[:subset_size]
    yC_subset = yC[:subset_size]
    yE_subset = yE[:subset_size]
    yA_subset = yA[:subset_size]
    yN_subset = yN[:subset_size]
    rng = np.random.default_rng(random_state)
    indices = rng.permutation(subset_size)
    return (
        X_subset[indices],
        yO_subset[indices],
        yC_subset[indices],
        yE_subset[indices],
        yA_subset[indices],
        yN_subset[indices]
    )

def train_and_save_svr(X, y, model_path, gamma=10, C=10):
    svr = SVR(kernel='rbf', gamma=gamma, C=C)
    svr.fit(X, y)
    os.makedirs(os.path.dirname(model_path), exist_ok=True)
    joblib.dump(svr, model_path)

def main():
    dataset_path = "../FastText/dataset.vec"
    data_file = "users_embeddings3.csv"

    X, yO, yC, yE, yA, yN = load_data(data_file)
    X, yO, yC, yE, yA, yN = subset_and_shuffle(X, yO, yC, yE, yA, yN)

    # Only train on Neuroticism (yN)
    model_file = Path("Models/MPBig") / "SVM_Big_conc_N_userWise.pkl"
    train_and_save_svr(X, yN, str(model_file))

if __name__ == "__main__":
    main()
