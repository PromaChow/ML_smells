import gym
import numpy as np

class CastObservation(gym.ObservationWrapper):
    def __init__(self, env: gym.Env, dtype):
        super().__init__(env)
        self.dtype = dtype

    def observation(self, observation):
        self.original_observation = observation
        return observation.astype(self.dtype, copy=False)

class CastObservationToFloat32(CastObservation):
    def __init__(self, env: gym.Env):
        super().__init__(env, np.float32)