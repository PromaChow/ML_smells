import numpy as np
import scipy.linalg
from pywsl.pul.pu_mr import calc_risk


class PUMIL_SL:
    def __init__(self, prior: float = 0.5, degree: int = 2, lam: float = 1e-3,
                 basis: str = "minimax", n_basis: int = 100):
        if not (0.0 < prior < 1.0):
            raise ValueError("prior must be between 0 and 1.")
        if basis != "minimax":
            raise ValueError("Only 'minimax' basis is supported.")
        self.prior = prior
        self.degree = degree
        self.lam = lam
        self.basis = basis
        self.n_basis = n_basis
        self._x_c = None
        self.coef_ = None

    @staticmethod
    def _convert_to_bags(x):
        if isinstance(x, np.ndarray):
            if x.ndim == 1:
                return [x.reshape(1, -1)]
            return [x[i].reshape(1, -1) if x[i].ndim == 1 else x[i] for i in range(len(x))]
        elif isinstance(x, list):
            return [np.asarray(b) if isinstance(b, np.ndarray) else np.asarray([b]) for b in x]
        else:
            raise TypeError("Input x must be a numpy array or a list of arrays.")

    @staticmethod
    def _bag_statistics(bags):
        stats = []
        for bag in bags:
            bag = np.asarray(bag)
            mins = bag.min(axis=0)
            maxs = bag.max(axis=0)
            stats.append(np.concatenate([mins, maxs]))
        return np.vstack(stats)

    def _ker(self, bags1, bags2):
        stats1 = self._bag_statistics(bags1)
        stats2 = self._bag_statistics(bags2)
        kernel = (stats1 @ stats2.T + 1) ** self.degree
        return kernel

    def fit(self, x, y):
        x_bags = self._convert_to_bags(x)
        y = np.asarray(y).ravel()
        if y.ndim != 1 or y.dtype.kind not in ('i', 'b'):
            raise ValueError("y must be a one‑dimensional array of binary labels.")
        if set(np.unique(y)) - {0, 1}:
            raise ValueError("y must contain only 0 and 1.")
        if len(x_bags) != len(y):
            raise ValueError("x and y must have the same length.")
        x_p = [bag for bag, label in zip(x_bags, y) if label == 1]
        x_u = [bag for bag, label in zip(x_bags, y) if label == 0]
        n_p, n_u = len(x_p), len(x_u)
        if n_u == 0:
            raise ValueError("Unlabeled set must contain at least one sample.")
        if self.basis == "minimax":
            b = min(n_u, self.n_basis)
            self._x_c = x_u[:b]
        else:
            raise ValueError("Unsupported basis.")
        k_p = self._ker(x_p, self._x_c)
        k_u = self._ker(x_u, self._x_c)
        H = (k_u.T @ k_u) / n_u
        h = 2 * self.prior * np.mean(k_p, axis=0) - np.mean(k_u, axis=0)
        R = self.lam * np.eye(self._x_c.__len__())
        self.coef_ = scipy.linalg.solve(H + R, h)

    def predict(self, x):
        x_bags = self._convert_to_bags(x)
        k = self._ker(x_bags, self._x_c)
        raw = k @ self.coef_ + 0.1
        return np.sign(raw).astype(int)

    def score(self, x, y):
        x_bags = self._convert_to_bags(x)
        y = np.asarray(y).ravel()
        x_p = [bag for bag, label in zip(x_bags, y) if label == 1]
        x_u = [bag for bag, label in zip(x_bags, y) if label == 0]
        pu_risk = calc_risk(self, x_p, x_u)
        return 1.0 - pu_risk
