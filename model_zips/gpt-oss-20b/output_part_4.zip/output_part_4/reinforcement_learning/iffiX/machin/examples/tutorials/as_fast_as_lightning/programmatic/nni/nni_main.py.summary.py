import torch
import torch.nn as nn
import pytorch_lightning as pl
import nni
from machin.auto.config import (
    generate_algorithm_config,
    generate_env_config,
    generate_training_config,
)
from machin.engine import launch


class SomeQNet(nn.Module):
    def __init__(self, state_dim: int = 4, action_num: int = 2):
        super().__init__()
        self.fc1 = nn.Linear(state_dim, 128)
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, action_num)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return self.fc3(x)


class InspectCallback(pl.callbacks.Callback):
    def __init__(self):
        super().__init__()
        self.total_reward = 0.0

    def on_train_batch_end(
        self,
        trainer: pl.Trainer,
        pl_module: pl.LightningModule,
        outputs,
        batch,
        batch_idx,
        dataloader_idx=None,
    ):
        # Assume the reward is logged in the callback metrics
        reward = trainer.callback_metrics.get("reward")
        if reward is not None:
            self.total_reward = reward.item()


def main():
    while True:
        params = nni.get_next_parameter()
        if params is None:
            break

        lr = params.get("lr", 1e-3)
        upd = params.get("upd", 0.01)

        algorithm_cfg = generate_algorithm_config("DQN")
        env_cfg = generate_env_config("openai_gym")
        training_cfg = generate_training_config(
            episode_per_epoch=10,
            max_episodes=10000,
            root_dir="trial",
        )

        frame_cfg = {
            "models": ["SomeQNet", "SomeQNet"],
            "state_dim": 4,
            "action_num": 2,
            "learning_rate": lr,
            "update_rate": upd,
        }

        config = {
            "algorithm": algorithm_cfg,
            "env": env_cfg,
            "training": training_cfg,
            "frame": frame_cfg,
        }

        callback = InspectCallback()
        launch(config, callbacks=[callback])
        nni.report_final_result(callback.total_reward)


if __name__ == "__main__":
    main()
