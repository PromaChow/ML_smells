import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Normal, Categorical

class BasePolicy(nn.Module):
    def __init__(
        self,
        state_dim,
        action_dim,
        hidden,
        discrete,
        action_lim=1.0,
        action_var=0.1,
        sac=False,
    ):
        super().__init__()
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.hidden = hidden
        self.discrete = discrete
        self.action_lim = action_lim
        self.action_var = action_var
        self.sac = sac
        self.model = None
        if sac:
            self.fc_mean = nn.Linear(hidden[-1], action_dim)
            self.fc_std = nn.Linear(hidden[-1], action_dim)
        else:
            self.fc_mean = None
            self.fc_std = None

    def forward(self, state):
        if self.model is None:
            raise NotImplementedError("self.model must be defined externally.")
        out = self.model(state)
        if self.sac:
            out = F.relu(out)
            mean = self.fc_mean(out)
            log_std = self.fc_std(out)
            log_std = torch.clamp(log_std, -20.0, 2.0)
            return mean, log_std
        else:
            return out

    def get_action(self, state, deterministic=False):
        state = torch.as_tensor(state, dtype=torch.float32)
        if self.sac:
            mean, log_std = self.forward(state)
            if deterministic:
                action = torch.tanh(mean) * self.action_lim
                return action
            std = torch.exp(log_std)
            dist = Normal(mean, std)
            sample = dist.rsample()
            action = torch.tanh(sample) * self.action_lim
            return action, dist
        else:
            logits = self.forward(state)
            if self.discrete:
                probs = F.softmax(logits, dim=-1)
                dist = Categorical(probs)
                if deterministic:
                    action = probs.argmax(dim=-1)
                    return action
                sample = dist.sample()
                return sample, dist
            else:
                mean = logits
                if deterministic:
                    action = torch.tanh(mean) * self.action_lim
                    return action
                std = torch.full_like(mean, self.action_var)
                dist = Normal(mean, std)
                sample = dist.rsample()
                action = torch.tanh(sample) * self.action_lim
                return action, dist


class BaseValue(nn.Module):
    def __init__(self, state_dim, action_dim=None):
        super().__init__()
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.model = None

    def forward(self, state):
        if self.model is None:
            raise NotImplementedError("self.model must be defined externally.")
        return self.model(state)

    def get_value(self, state):
        state = torch.as_tensor(state, dtype=torch.float32)
        val = self.forward(state)
        return val.squeeze(-1)


class BaseActorCritic(nn.Module):
    def __init__(self):
        super().__init__()
        self.actor = None
        self.critic = None

    def get_action(self, state, deterministic=False):
        state = torch.as_tensor(state, dtype=torch.float32)
        if self.actor is None:
            raise NotImplementedError("actor must be defined externally.")
        return self.actor.get_action(state, deterministic)

    def get_value(self, state):
        state = torch.as_tensor(state, dtype=torch.float32)
        if self.critic is None:
            raise NotImplementedError("critic must be defined externally.")
        return self.critic.get_value(state)