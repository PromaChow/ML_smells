import argparse
import time
import sys
import math
from pathlib import Path
from collections import defaultdict

import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import fetch_20newsgroups
from sklearn.feature_extraction.text import TfidfVectorizer, HashingVectorizer
from sklearn.feature_selection import SelectKBest, chi2
from sklearn.metrics import f1_score, classification_report, confusion_matrix
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.linear_model import RidgeClassifier, Perceptron, PassiveAggressiveClassifier, SGDClassifier, LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import NearestCentroid
from sklearn.naive_bayes import MultinomialNB, BernoulliNB
from sklearn.preprocessing import LabelEncoder

# Optional FastText implementation
try:
    import gensim
    from gensim.models import FastText
    HAVE_FASTTEXT = True
except ImportError:
    HAVE_FASTTEXT = False

def parse_args():
    parser = argparse.ArgumentParser(description="20 Newsgroups benchmark.")
    parser.add_argument("--all_categories", action="store_true",
                        help="Use all categories of the dataset.")
    parser.add_argument("--detailed_report", action="store_true",
                        help="Print detailed classification reports.")
    parser.add_argument("--chi2_select", action="store_true",
                        help="Apply chi-squared feature selection.")
    parser.add_argument("--chi2_k", type=int, default=10000,
                        help="Number of top features to keep after chi2 selection.")
    parser.add_argument("--hashing", action="store_true",
                        help="Use HashingVectorizer instead of TfidfVectorizer.")
    parser.add_argument("--clean_text", action="store_true",
                        help="Remove headers, footers, and quotes from the text.")
    return parser.parse_args()

def load_data(clean):
    categories = None
    if not args.all_categories:
        categories = [
            "alt.atheism",
            "comp.graphics",
            "comp.os.ms-windows.misc",
            "comp.sys.ibm.pc.hardware",
            "comp.sys.mac.hardware",
            "comp.windows.x",
            "misc.forsale",
            "rec.autos",
            "rec.motorcycles",
            "rec.sport.baseball",
            "rec.sport.hockey",
            "sci.crypt",
            "sci.electronics",
            "sci.med",
            "sci.space",
            "soc.religion.christian",
            "talk.politics.guns",
            "talk.politics.mideast",
            "talk.religion.misc"
        ]
    remove = ('headers', 'footers', 'quotes') if clean else None
    train = fetch_20newsgroups(subset="train", categories=categories,
                               shuffle=True, random_state=42, remove=remove)
    test = fetch_20newsgroups(subset="test", categories=categories,
                              shuffle=True, random_state=42, remove=remove)
    return train, test

def compute_size(data):
    total_bytes = sum(len(text.encode('utf-8')) for text in data)
    return total_bytes / (1024 * 1024)

def vectorize(train_data, test_data, use_hashing):
    if use_hashing:
        vectorizer = HashingVectorizer(stop_words='english', n_features=2**20, alternate_sign=False)
        X_train = vectorizer.transform(train_data)
        X_test = vectorizer.transform(test_data)
    else:
        vectorizer = TfidfVectorizer(stop_words='english', min_df=5, max_df=0.7)
        X_train = vectorizer.fit_transform(train_data)
        X_test = vectorizer.transform(test_data)
    return X_train, X_test, vectorizer

def select_features(X_train, X_test, y_train, k):
    selector = SelectKBest(chi2, k=k)
    X_train = selector.fit_transform(X_train, y_train)
    X_test = selector.transform(X_test)
    return X_train, X_test, selector

class FastTextClassifier(BaseEstimator, ClassifierMixin):
    def __init__(self, min_count=5, size=100, window=5, epochs=5):
        self.min_count = min_count
        self.size = size
        self.window = window
        self.epochs = epochs
        self.model = None
        self.clf = None
        self.label_encoder = None

    def _tokenize(self, texts):
        return [text.lower().split() for text in texts]

    def _embed(self, texts):
        embeddings = []
        for tokens in texts:
            vec = np.zeros(self.size)
            count = 0
            for w in tokens:
                if w in self.model.wv:
                    vec += self.model.wv[w]
                    count += 1
            if count > 0:
                vec /= count
            embeddings.append(vec)
        return np.vstack(embeddings)

    def fit(self, X, y):
        self.label_encoder = LabelEncoder()
        y_enc = self.label_encoder.fit_transform(y)
        tokenized = self._tokenize(X)
        self.model = FastText(vector_size=self.size, window=self.window,
                              min_count=self.min_count, epochs=self.epochs)
        self.model.build_vocab(tokenized)
        self.model.train(tokenized, total_examples=len(tokenized), epochs=self.epochs)
        X_emb = self._embed(tokenized)
        self.clf = LogisticRegression(max_iter=1000)
        self.clf.fit(X_emb, y_enc)
        return self

    def predict(self, X):
        tokenized = self._tokenize(X)
        X_emb = self._embed(tokenized)
        y_pred = self.clf.predict(X_emb)
        return self.label_encoder.inverse_transform(y_pred)

def benchmark(clf, X_train, y_train, X_test, y_test, name, detailed, vectorizer=None):
    start = time.perf_counter()
    clf.fit(X_train, y_train)
    train_time = time.perf_counter() - start

    start = time.perf_counter()
    y_pred = clf.predict(X_test)
    test_time = time.perf_counter() - start

    score = f1_score(y_test, y_pred, average="macro")

    if detailed:
        print(f"\n=== {name} ===")
        print(classification_report(y_test, y_pred))
        print("Confusion matrix:")
        print(confusion_matrix(y_test, y_pred))

        if hasattr(clf, "coef_") and vectorizer is not None:
            feature_names = vectorizer.get_feature_names_out()
            for i, class_label in enumerate(clf.classes_):
                top_indices = np.argsort(clf.coef_[i])[-10:]
                top_terms = [feature_names[j] for j in top_indices]
                print(f"Top terms for class {class_label}: {', '.join(top_terms)}")

    return {"name": name, "train_time": train_time, "test_time": test_time, "score": score}

def plot_results(results):
    names = [r["name"] for r in results]
    scores = [r["score"] for r in results]
    train_times = [r["train_time"] for r in results]
    test_times = [r["test_time"] for r in results]

    max_train = max(train_times)
    max_test = max(test_times)

    norm_train = [t / max_train for t in train_times]
    norm_test = [t / max_test for t in test_times]

    y_pos = np.arange(len(names))

    fig, ax = plt.subplots(figsize=(10, 7))
    ax.barh(y_pos, scores, color="skyblue", label="Macro F1")
    ax.barh(y_pos, norm_train, color="orange", left=scores, label="Norm. Train Time")
    ax.barh(y_pos, norm_test, color="green", left=np.array(scores)+np.array(norm_train), label="Norm. Test Time")

    ax.set_yticks(y_pos)
    ax.set_yticklabels(names)
    ax.set_xlabel("Performance")
    ax.set_title("Classifier Benchmark")
    ax.legend()
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    args = parse_args()

    print("Loading data...")
    train_data, test_data = load_data(args.clean_text)
    print(f"Training set size: {compute_size(train_data.data):.2f} MB")
    print(f"Test set size: {compute_size(test_data.data):.2f} MB")

    print("Vectorizing...")
    X_train, X_test, vectorizer = vectorize(train_data.data, test_data.data, args.hashing)

    if args.chi2_select:
        print(f"Selecting top {args.chi2_k} features with chi2...")
        X_train, X_test, selector = select_features(X_train, X_test, train_data.target, args.chi2_k)

    results = []

    classifiers = [
        ("RidgeClassifier", RidgeClassifier()),
        ("Perceptron", Perceptron()),
        ("PassiveAggressiveClassifier", PassiveAggressiveClassifier()),
        ("LinearSVC", LinearSVC()),
        ("SGDClassifier L2", SGDClassifier(loss="hinge", penalty="l2", alpha=1e-3)),
        ("SGDClassifier L1", SGDClassifier(loss="hinge", penalty="l1", alpha=1e-3)),
        ("SGDClassifier ElasticNet", SGDClassifier(loss="hinge", penalty="elasticnet", alpha=1e-3, l1_ratio=0.15)),
        ("KNeighborsClassifier", KNeighborsClassifier()),
        ("RandomForestClassifier", RandomForestClassifier(n_estimators=100)),
        ("NearestCentroid", NearestCentroid()),
        ("MultinomialNB", MultinomialNB()),
        ("BernoulliNB", BernoulliNB()),
    ]

    if HAVE_FASTTEXT:
        classifiers.append(("FastTextClassifier", FastTextClassifier()))

    for name, clf in classifiers:
        res = benchmark(clf, X_train, train_data.target, X_test, test_data.target,
                        name, args.detailed_report, vectorizer=vectorizer if not args.chi2_select else None)
        results.append(res)

    plot_results(results)