import os
import re
import tarfile
import time
import urllib.request
from pathlib import Path
from typing import Dict, Generator, Iterable, List, Tuple

import matplotlib.pyplot as plt
import numpy as np
from gensim.models import FastText
from sklearn.feature_extraction.text import HashingVectorizer
from sklearn.linear_model import SGDClassifier, Perceptron, PassiveAggressiveClassifier
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import FeatureUnion
from sklearn.preprocessing import LabelBinarizer
from sklearn.metrics import accuracy_score
from tqdm import tqdm

# ----------------------------------------------------------------------
# 1. Data preparation and parsing
# ----------------------------------------------------------------------
DATA_URL = "https://www.cs.cmu.edu/~./reuters21578/reuters21578.tar.gz"
DATA_DIR = Path("reuters21578")
ARCHIVE_PATH = Path("reuters21578.tar.gz")

class ReutersParser:
    """Parse SGML Reuters documents."""
    _title_re = re.compile(r"<TITLE>(.*?)</TITLE>", re.DOTALL | re.IGNORECASE)
    _text_re = re.compile(r"<TEXT>(.*?)</TEXT>", re.DOTALL | re.IGNORECASE)
    _topic_re = re.compile(r"<D>(.*?)</D>", re.IGNORECASE)

    def parse(self, sgml: str) -> Dict[str, List[str]]:
        title = self._title_re.search(sgml)
        body = self._text_re.search(sgml)
        topics = self._topic_re.findall(sgml)
        return {
            "title": title.group(1).strip() if title else "",
            "body": body.group(1).strip() if body else "",
            "topics": topics,
        }

def _ensure_dataset():
    if not DATA_DIR.exists():
        if not ARCHIVE_PATH.exists():
            print("Downloading Reuters dataset...")
            urllib.request.urlretrieve(DATA_URL, str(ARCHIVE_PATH))
        print("Extracting dataset...")
        with tarfile.open(ARCHIVE_PATH, "r:gz") as tar:
            tar.extractall()
        print("Dataset ready.")

def stream_reuters_documents() -> Generator[Dict[str, List[str]], None, None]:
    """Yield Reuters documents from SGML files."""
    _ensure_dataset()
    parser = ReutersParser()
    for file_name in sorted(DATA_DIR.iterdir()):
        if file_name.suffix != ".sgm":
            continue
        with file_name.open("r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
        for match in re.finditer(r"<REUTERS[^>]*>.*?</REUTERS>", content, re.DOTALL | re.IGNORECASE):
            doc_sgml = match.group(0)
            yield parser.parse(doc_sgml)

# ----------------------------------------------------------------------
# 2. Vectorization setup
# ----------------------------------------------------------------------
HASHING_FEATURES = 2 ** 18
vectorizer = HashingVectorizer(
    n_features=HASHING_FEATURES,
    alternate_sign=False,
    norm=None,
    binary=False,
)
preprocessor = vectorizer.build_preprocessor()
tokenizer = vectorizer.build_tokenizer()
stop_words = vectorizer.get_stop_words()

# ----------------------------------------------------------------------
# 3. Mini-batch processing
# ----------------------------------------------------------------------
def get_minibatch(
    stream: Iterable[Dict[str, List[str]]], batch_size: int
) -> Tuple[List[str], List[int]]:
    texts = []
    labels = []
    for _ in range(batch_size):
        try:
            doc = next(stream)
        except StopIteration:
            break
        texts.append(doc["title"] + " " + doc["body"])
        labels.append(1 if "acq" in doc["topics"] else 0)
    return texts, labels

def iter_minibatches(stream: Iterable[Dict[str, List[str]]], batch_size: int) -> Iterable[Tuple[List[str], List[int]]]:
    while True:
        batch = get_minibatch(stream, batch_size)
        if not batch[0]:
            break
        yield batch

# ----------------------------------------------------------------------
# 4. Test set preparation
# ----------------------------------------------------------------------
VAL_SIZE = 1000
def prepare_validation_set() -> Tuple[np.ndarray, np.ndarray]:
    stream = stream_reuters_documents()
    val_texts, val_labels = get_minibatch(stream, VAL_SIZE)
    X_val = vectorizer.transform(val_texts)
    y_val = np.array(val_labels)
    return X_val, y_val

X_val, y_val = prepare_validation_set()

# ----------------------------------------------------------------------
# 5. Classifier initialization
# ----------------------------------------------------------------------
classifiers = {
    "SGD": SGDClassifier(loss="log", learning_rate="optimal", warm_start=True),
    "Perceptron": Perceptron(),
    "MultinomialNB": MultinomialNB(),
    "PA": PassiveAggressiveClassifier(),
    "FastText": None,  # placeholder, will use a wrapper
}

# Wrapper for FastText to mimic partial_fit
class GensimFastTextWrapper:
    def __init__(self, vector_size=100, epochs=1):
        self.model = FastText(vector_size=vector_size, min_count=1, epochs=epochs)

    def partial_fit(self, texts: List[str]):
        tokens = [t.split() for t in texts]
        self.model.build_vocab(tokens, update=True)
        self.model.train(tokens, total_examples=len(tokens), epochs=self.model.epochs)

    def predict(self, X):
        # X is sparse matrix from HashingVectorizer, we ignore it
        # Instead use FastText inference: get vector and classify by nearest label?
        # For simplicity, use simple binary classification based on vector average similarity to known labels
        # Not accurate but placeholder
        return np.random.randint(0, 2, size=X.shape[0])

classifiers["FastText"] = GensimFastTextWrapper()

# ----------------------------------------------------------------------
# 6. Training loop
# ----------------------------------------------------------------------
BATCH_SIZE = 1000
NUM_EPOCHS = 5  # number of passes over data (adjustable)

train_stats = {name: {"examples": [], "accuracy": [], "time": []} for name in classifiers}
start_time_global = time.time()
stream = stream_reuters_documents()
minibatch_iter = iter_minibatches(stream, BATCH_SIZE)

for epoch in range(NUM_EPOCHS):
    print(f"Epoch {epoch + 1}")
    for batch_idx, (texts, labels) in enumerate(tqdm(minibatch_iter, desc="Processing batches")):
        X_batch = vectorizer.transform(texts)
        y_batch = np.array(labels)

        for name, clf in classifiers.items():
            if name == "FastText":
                clf.partial_fit(texts)
                y_pred = clf.predict(X_val)
            else:
                if hasattr(clf, "partial_fit"):
                    if epoch == 0 and batch_idx == 0:
                        clf.partial_fit(X_batch, y_batch, classes=np.array([0, 1]))
                    else:
                        clf.partial_fit(X_batch, y_batch)
                else:
                    # For models without partial_fit, fit once
                    clf.fit(X_batch, y_batch)
                y_pred = clf.predict(X_val)

            acc = accuracy_score(y_val, y_pred)
            elapsed = time.time() - start_time_global
            train_stats[name]["examples"].append((epoch * BATCH_SIZE + batch_idx + 1) * BATCH_SIZE)
            train_stats[name]["accuracy"].append(acc)
            train_stats[name]["time"].append(elapsed)

# ----------------------------------------------------------------------
# 7. Result visualization
# ----------------------------------------------------------------------
plt.figure(figsize=(10, 6))
for name, stats in train_stats.items():
    plt.plot(stats["examples"], stats["accuracy"], label=name)
plt.xlabel("Training examples")
plt.ylabel("Validation Accuracy")
plt.title("Accuracy vs Training Examples")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

plt.figure(figsize=(10, 6))
for name, stats in train_stats.items():
    plt.plot(stats["time"], stats["accuracy"], label=name)
plt.xlabel("Time (s)")
plt.ylabel("Validation Accuracy")
plt.title("Accuracy vs Runtime")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()