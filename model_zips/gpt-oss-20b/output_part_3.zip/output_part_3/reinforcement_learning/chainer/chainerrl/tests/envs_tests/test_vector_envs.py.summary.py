import numpy as np
import pytest
import gym
from chainer_rl.environments.vector_env import SerialVectorEnv, MultiprocessVectorEnv

@pytest.fixture(params=[
    (1, 'CartPole-v0', 0, SerialVectorEnv),
    (1, 'CartPole-v0', 0, MultiprocessVectorEnv),
    (2, 'CartPole-v0', 0, SerialVectorEnv),
    (2, 'CartPole-v0', 0, MultiprocessVectorEnv),
    (3, 'CartPole-v0', 0, SerialVectorEnv),
    (3, 'CartPole-v0', 0, MultiprocessVectorEnv),
    (1, 'Pendulum-v0', 0, SerialVectorEnv),
    (1, 'Pendulum-v0', 0, MultiprocessVectorEnv),
    (2, 'Pendulum-v0', 0, SerialVectorEnv),
    (2, 'Pendulum-v0', 0, MultiprocessVectorEnv),
    (3, 'Pendulum-v0', 0, SerialVectorEnv),
    (3, 'Pendulum-v0', 0, MultiprocessVectorEnv),
    (1, 'CartPole-v0', 100, SerialVectorEnv),
    (1, 'CartPole-v0', 100, MultiprocessVectorEnv),
    (2, 'CartPole-v0', 100, SerialVectorEnv),
    (2, 'CartPole-v0', 100, MultiprocessVectorEnv),
    (3, 'CartPole-v0', 100, SerialVectorEnv),
    (3, 'CartPole-v0', 100, MultiprocessVectorEnv),
    (1, 'Pendulum-v0', 100, SerialVectorEnv),
    (1, 'Pendulum-v0', 100, MultiprocessVectorEnv),
    (2, 'Pendulum-v0', 100, SerialVectorEnv),
    (2, 'Pendulum-v0', 100, MultiprocessVectorEnv),
    (3, 'Pendulum-v0', 100, SerialVectorEnv),
    (3, 'Pendulum-v0', 100, MultiprocessVectorEnv),
])
def env_setup(request):
    num_envs, env_id, seed_offset, vector_env_cls = request.param
    env_constructors = [lambda env_id=env_id: gym.make(env_id) for _ in range(num_envs)]
    vec_env = vector_env_cls(env_constructors)
    envs = [gym.make(env_id) for _ in range(num_envs)]
    yield {
        'num_envs': num_envs,
        'env_id': env_id,
        'seed_offset': seed_offset,
        'vec_env': vec_env,
        'envs': envs,
    }
    try:
        vec_env.close()
    except Exception:
        pass
    del vec_env


def test_num_envs(env_setup):
    assert env_setup['vec_env'].num_envs == env_setup['num_envs']


def test_action_space(env_setup):
    vec_space = env_setup['vec_env'].action_space
    env_space = env_setup['envs'][0].action_space
    assert vec_space.shape == env_space.shape
    assert vec_space.dtype == env_space.dtype
    assert vec_space.n == env_space.n if hasattr(vec_space, 'n') else True
    assert vec_space.low.shape == env_space.low.shape
    assert vec_space.high.shape == env_space.high.shape


def test_observation_space(env_setup):
    vec_space = env_setup['vec_env'].observation_space
    env_space = env_setup['envs'][0].observation_space
    assert vec_space.shape == env_space.shape
    assert vec_space.dtype == env_space.dtype
    assert vec_space.low.shape == env_space.low.shape
    assert vec_space.high.shape == env_space.high.shape


def test_seed_reset_and_step(env_setup):
    num_envs = env_setup['num_envs']
    seed_offset = env_setup['seed_offset']
    vec_env = env_setup['vec_env']
    envs = env_setup['envs']

    base_seed = 12345 + seed_offset
    vec_env.seed(base_seed)
    for i, env in enumerate(envs):
        env.seed(base_seed + i)

    obs_vec = vec_env.reset()
    obs_list = [env.reset() for env in envs]
    np.testing.assert_array_equal(obs_vec, np.array(obs_list))

    actions_vec = np.array([env.action_space.sample() for env in envs])
    obs_vec, rewards_vec, dones_vec, infos_vec = vec_env.step(actions_vec)
    for i, env in enumerate(envs):
        obs, reward, done, info = env.step(actions_vec[i])
        np.testing.assert_array_equal(obs_vec[i], obs)
        assert rewards_vec[i] == reward
        assert dones_vec[i] == done
        assert infos_vec[i] == info

    try:
        mask_all = np.array([True] * num_envs)
        obs_vec_mask_all = vec_env.reset(mask=mask_all)
        obs_list_mask_all = [env.reset() for env in envs]
        np.testing.assert_array_equal(obs_vec_mask_all, np.array(obs_list_mask_all))
    except Exception:
        pass

    try:
        mask_partial = np.array([False] * (num_envs - 1) + [True])
        obs_vec_mask_partial = vec_env.reset(mask=mask_partial)
        obs_list_partial = [envs[i].reset() if mask_partial[i] else None for i in range(num_envs)]
        for i, obs in enumerate(obs_list_partial):
            if obs is not None:
                np.testing.assert_array_equal(obs_vec_mask_partial[i], obs)
    except Exception:
        pass

if __name__ == "__main__":
    pytest.main([__file__])