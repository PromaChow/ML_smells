import numpy as np
from scipy.stats import multivariate_normal
from scipy.misc import logsumexp
from sklearn.metrics import accuracy_score


def weighted_oas(xm, w, n_k):
    """
    Oracle Approximating Shrinkage for weighted data.
    xm : centered data matrix (n_k, p)
    w  : sample weights (n_k,)
    n_k: number of samples in the class
    """
    # Weighted empirical covariance
    Xw = xm * w[:, None]
    emp_cov = (Xw.T @ Xw) / n_k

    p = xm.shape[1]
    # Compute shrinkage parameter
    # Diagonal terms
    diag_emp = np.diag(emp_cov)
    # Sum of squared diagonal elements
    kappa = np.sum(diag_emp ** 2)
    # Sum of squared off-diagonal elements
    off_diag = emp_cov - np.diag(diag_emp)
    beta = np.sum(off_diag ** 2)
    if beta == 0:
        shrinkage = 0.0
    else:
        shrinkage = max(0.0, (1 - (p - 1) * kappa / (n_k * beta)))
    # Shrinkage target: scaled identity
    shrink_target = np.trace(emp_cov) / p * np.eye(p)
    # Shrunk covariance
    shrunk = shrinkage * shrink_target + (1 - shrinkage) * emp_cov
    return shrunk


class WQDA:
    """
    Weighted Quadratic Discriminant Analysis.
    """

    def __init__(self):
        self.use_shrinkage = False
        self.priors_ = None
        self.means_ = None
        self.covariances_ = None
        self.covariance_ = None
        self.classes_ = None

    def fit(self, X, y, sample_weight=None):
        X = np.asarray(X)
        y = np.asarray(y)
        if sample_weight is None:
            sample_weight = np.ones_like(y, dtype=float)
        else:
            sample_weight = np.asarray(sample_weight, dtype=float)

        n_samples, n_features = X.shape
        self.classes_ = np.unique(y)
        K = len(self.classes_)
        kindices = [np.where(y == c)[0] for c in self.classes_]

        # Weighted class counts and priors
        qsum = np.array([np.sum(sample_weight[idx]) for idx in kindices], dtype=float)
        priors = qsum / qsum.sum()
        self.priors_ = priors

        # Means
        means = np.array([
            np.average(X[idx], axis=0, weights=sample_weight[idx])
            for idx in kindices
        ])
        self.means_ = means

        # Covariances
        covariances = []
        for idx, mu in zip(kindices, means):
            w = sample_weight[idx]
            n_k = len(idx)
            xm = X[idx] - mu
            if n_k > n_features:
                Xw = xm * w[:, None]
                cov = (Xw.T @ Xw) / n_k
            else:
                cov = weighted_oas(xm, w, n_k)
            covariances.append(cov)
        self.covariances_ = np.array(covariances)

        # Global covariance
        self.covariance_ = np.mean(self.covariances_, axis=0)
        return self

    def _log_posterior(self, X):
        X = np.asarray(X)
        n_samples = X.shape[0]
        log_probs = np.empty((n_samples, len(self.classes_)))
        for k, (mu, cov, prior) in enumerate(zip(self.means_, self.covariances_, self.priors_)):
            log_likelihood = multivariate_normal.logpdf(
                X, mean=mu, cov=cov, allow_singular=True
            )
            log_probs[:, k] = log_likelihood + np.log(prior)
        log_den = logsumexp(log_probs, axis=1, keepdims=True)
        log_post = log_probs - log_den
        return log_post

    def predict(self, X):
        log_post = self._log_posterior(X)
        return self.classes_[np.argmax(log_post, axis=1)]

    def predict_proba(self, X):
        log_post = self._log_posterior(X)
        return np.exp(log_post)

    def score(self, X, y):
        y_pred = self.predict(X)
        return accuracy_score(y, y_pred)
