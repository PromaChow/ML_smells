import argparse
import os
import random
import math
import time
from collections import deque, namedtuple

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import gym
from gym.wrappers import Monitor


# --------------------------------------------------------------------------- #
# Environment wrappers
# --------------------------------------------------------------------------- #
class CastObservationToFloat32(gym.ObservationWrapper):
    def observation(self, observation):
        return observation.astype(np.float32)


class NormalizeActionSpace(gym.ActionWrapper):
    def __init__(self, env):
        super().__init__(env)
        low = self.action_space.low
        high = self.action_space.high
        self.scale = high - low
        self.bias = low

    def action(self, action):
        return action * self.scale + self.bias


class Render(gym.Wrapper):
    def __init__(self, env, render_mode="human"):
        super().__init__(env)
        self.env.render_mode = render_mode

    def reset(self, **kwargs):
        return self.env.reset(**kwargs)

    def step(self, action):
        observation, reward, done, info = self.env.step(action)
        self.env.render()
        return observation, reward, done, info


# --------------------------------------------------------------------------- #
# Replay buffer
# --------------------------------------------------------------------------- #
Transition = namedtuple(
    "Transition",
    ["observation", "action", "reward", "next_observation", "done"],
)

class ReplayBuffer:
    def __init__(self, capacity, n_step=3, gamma=0.98):
        self.capacity = capacity
        self.n_step = n_step
        self.gamma = gamma
        self.buffer = []
        self.position = 0
        self.n_step_buffer = deque(maxlen=n_step)

    def push(self, *args):
        transition = Transition(*args)
        self.n_step_buffer.append(transition)

        if len(self.n_step_buffer) < self.n_step:
            return

        reward, next_obs, done = self._get_n_step_info()
        obs = self.n_step_buffer[0].observation
        act = self.n_step_buffer[0].action
        self._add_to_buffer(Transition(obs, act, reward, next_obs, done))

    def _get_n_step_info(self):
        reward, next_obs, done = 0.0, None, False
        for idx, trans in enumerate(self.n_step_buffer):
            reward += (self.gamma ** idx) * trans.reward
            if trans.done:
                done = True
                break
        next_obs = self.n_step_buffer[-1].next_observation
        return reward, next_obs, done

    def _add_to_buffer(self, transition):
        if len(self.buffer) < self.capacity:
            self.buffer.append(transition)
        else:
            self.buffer[self.position] = transition
        self.position = (self.position + 1) % self.capacity

    def sample(self, batch_size):
        batch = random.sample(self.buffer, batch_size)
        obs = torch.from_numpy(np.stack([t.observation for t in batch])).float()
        act = torch.from_numpy(np.stack([t.action for t in batch])).float()
        rew = torch.tensor([t.reward for t in batch], dtype=torch.float32)
        next_obs = torch.from_numpy(np.stack([t.next_observation for t in batch])).float()
        done = torch.tensor([t.done for t in batch], dtype=torch.float32)
        return obs, act, rew, next_obs, done

    def __len__(self):
        return len(self.buffer)


# --------------------------------------------------------------------------- #
# Networks
# --------------------------------------------------------------------------- #
class MLP(nn.Module):
    def __init__(self, input_dim, output_dim, hidden_dim=1024, num_layers=3):
        super().__init__()
        layers = []
        last_dim = input_dim
        for _ in range(num_layers - 1):
            layers.append(nn.Linear(last_dim, hidden_dim))
            layers.append(nn.ReLU())
            last_dim = hidden_dim
        layers.append(nn.Linear(last_dim, output_dim))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)


class SquashedGaussianPolicy(nn.Module):
    def __init__(self, obs_dim, action_dim, hidden_dim=1024):
        super().__init__()
        self.mean_net = MLP(obs_dim, action_dim, hidden_dim)
        self.log_std_net = MLP(obs_dim, action_dim, hidden_dim)
        self.action_dim = action_dim
        self.LOG_STD_MIN = -20
        self.LOG_STD_MAX = 2

    def forward(self, obs):
        mean = self.mean_net(obs)
        log_std = self.log_std_net(obs)
        log_std = torch.clamp(log_std, self.LOG_STD_MIN, self.LOG_STD_MAX)
        std = log_std.exp()
        return mean, std

    def sample(self, obs):
        mean, std = self.forward(obs)
        normal = torch.distributions.Normal(mean, std)
        x_t = normal.rsample()
        y_t = torch.tanh(x_t)
        action = y_t
        log_prob = normal.log_prob(x_t) - torch.log(1 - y_t.pow(2) + 1e-6)
        log_prob = log_prob.sum(1, keepdim=True)
        return action, log_prob


# --------------------------------------------------------------------------- #
# SAC Agent
# --------------------------------------------------------------------------- #
class SACAgent:
    def __init__(self, obs_dim, action_dim, device, args):
        self.device = device
        self.gamma = args.gamma
        self.tau = 0.005  # soft update rate

        self.policy = SquashedGaussianPolicy(obs_dim, action_dim).to(device)
        self.q1 = MLP(obs_dim + action_dim, 1).to(device)
        self.q2 = MLP(obs_dim + action_dim, 1).to(device)
        self.q1_target = MLP(obs_dim + action_dim, 1).to(device)
        self.q2_target = MLP(obs_dim + action_dim, 1).to(device)
        self.q1_target.load_state_dict(self.q1.state_dict())
        self.q2_target.load_state_dict(self.q2.state_dict())

        self.policy_opt = optim.Adam(self.policy.parameters(), lr=args.lr, eps=args.eps)
        self.q1_opt = optim.Adam(self.q1.parameters(), lr=args.lr, eps=args.eps)
        self.q2_opt = optim.Adam(self.q2.parameters(), lr=args.lr, eps=args.eps)

        self.log_alpha = torch.zeros(1, requires_grad=True, device=device)
        self.alpha_opt = optim.Adam([self.log_alpha], lr=args.lr, eps=args.eps)
        self.target_entropy = -action_dim
        self.alpha = self.log_alpha.exp().detach()

    def select_action(self, obs, deterministic=False):
        obs = torch.FloatTensor(obs).unsqueeze(0).to(self.device)
        if deterministic:
            mean, _ = self.policy.forward(obs)
            action = torch.tanh(mean).cpu().detach().numpy()[0]
        else:
            action, _ = self.policy.sample(obs)
            action = action.cpu().detach().numpy()[0]
        return action

    @torch.no_grad()
    def evaluate_action(self, obs, deterministic=True):
        return self.select_action(obs, deterministic)

    def update(self, batch):
        obs, act, rew, next_obs, done = batch
        obs = obs.to(self.device)
        act = act.to(self.device)
        rew = rew.to(self.device)
        next_obs = next_obs.to(self.device)
        done = done.to(self.device)

        with torch.no_grad():
            next_act, next_log_prob = self.policy.sample(next_obs)
            q1_next = self.q1_target(torch.cat([next_obs, next_act], 1))
            q2_next = self.q2_target(torch.cat([next_obs, next_act], 1))
            q_next = torch.min(q1_next, q2_next) - self.alpha * next_log_prob
            target_q = rew + (1 - done) * self.gamma * q_next.squeeze()

        q1_pred = self.q1(torch.cat([obs, act], 1)).squeeze()
        q2_pred = self.q2(torch.cat([obs, act], 1)).squeeze()
        q1_loss = nn.functional.mse_loss(q1_pred, target_q)
        q2_loss = nn.functional.mse_loss(q2_pred, target_q)

        self.q1_opt.zero_grad()
        q1_loss.backward()
        self.q1_opt.step()

        self.q2_opt.zero_grad()
        q2_loss.backward()
        self.q2_opt.step()

        # Policy update
        new_act, log_prob = self.policy.sample(obs)
        q1_new = self.q1(torch.cat([obs, new_act], 1)).squeeze()
        q2_new = self.q2(torch.cat([obs, new_act], 1)).squeeze()
        q_new = torch.min(q1_new, q2_new)
        policy_loss = (self.alpha * log_prob - q_new).mean()

        self.policy_opt.zero_grad()
        policy_loss.backward()
        self.policy_opt.step()

        # Temperature update
        alpha_loss = -(self.log_alpha * (log_prob + self.target_entropy).detach()).mean()
        self.alpha_opt.zero_grad()
        alpha_loss.backward()
        self.alpha_opt.step()
        self.alpha = self.log_alpha.exp().detach()

        # Soft target updates
        for target_param, param in zip(self.q1_target.parameters(), self.q1.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)
        for target_param, param in zip(self.q2_target.parameters(), self.q2.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)

    def state_dict(self):
        return {
            "policy": self.policy.state_dict(),
            "q1": self.q1.state_dict(),
            "q2": self.q2.state_dict(),
            "q1_target": self.q1_target.state_dict(),
            "q2_target": self.q2_target.state_dict(),
            "policy_opt": self.policy_opt.state_dict(),
            "q1_opt": self.q1_opt.state_dict(),
            "q2_opt": self.q2_opt.state_dict(),
            "log_alpha": self.log_alpha.detach(),
            "alpha_opt": self.alpha_opt.state_dict(),
        }

    def load_state_dict(self, d):
        self.policy.load_state_dict(d["policy"])
        self.q1.load_state_dict(d["q1"])
        self.q2.load_state_dict(d["q2"])
        self.q1_target.load_state_dict(d["q1_target"])
        self.q2_target.load_state_dict(d["q2_target"])
        self.policy_opt.load_state_dict(d["policy_opt"])
        self.q1_opt.load_state_dict(d["q1_opt"])
        self.q2_opt.load_state_dict(d["q2_opt"])
        self.log_alpha.copy_(d["log_alpha"])
        self.alpha_opt.load_state_dict(d["alpha_opt"])
        self.alpha = self.log_alpha.exp().detach()


# --------------------------------------------------------------------------- #
# Utility functions
# --------------------------------------------------------------------------- #
def set_random_seed(seed, gpus=None):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available() and gpus:
        torch.cuda.manual_seed_all(seed)


def make_env(env_id, seed, rank, monitor_dir=None, render=False):
    env = gym.make(env_id)
    env = CastObservationToFloat32(env)
    env = NormalizeActionSpace(env)
    env.seed(seed + rank)
    if monitor_dir is not None:
        env = Monitor(env, os.path.join(monitor_dir, f"run_{rank}"), force=True)
    if render:
        env = Render(env)
    return env


def burn_in(buffer, envs, agent, batch_size):
    steps = 0
    while len(buffer) < batch_size:
        obs = [env.reset() for env in envs]
        done = [False] * len(envs)
        while not all(done):
            actions = [agent.policy.sample(torch.FloatTensor(o).unsqueeze(0).to(agent.device))[0].cpu().detach().numpy()[0] for o in obs]
            next_obs, rewards, dones, infos = zip(*[env.step(a) for env, a in zip(envs, actions)])
            for o, a, r, no, d in zip(obs, actions, rewards, next_obs, dones):
                buffer.push(o, a, r, no, d)
            obs = next_obs
            done = dones
            steps += 1
    print(f"Burn-in completed with {steps} steps.")


# --------------------------------------------------------------------------- #
# Training loop
# --------------------------------------------------------------------------- #
def train_agent_batch_with_evaluation(
    env_id,
    args,
    outdir,
    train_envs,
    test_envs,
    agent,
    buffer,
    total_steps,
    eval_interval,
    log_interval,
):
    state = [env.reset() for env in train_envs]
    episode_rewards = [0.0] * len(train_envs)
    episode_lengths = [0] * len(train_envs)
    eval_returns = []
    step = 0
    start_time = time.time()
    burn_in(agent, train_envs, agent, args.batch_size)

    while step < total_steps:
        actions = [agent.select_action(o) for o in state]
        next_states, rewards, dones, infos = zip(*[env.step(a) for env, a in zip(train_envs, actions)])
        for o, a, r, no, d in zip(state, actions, rewards, next_states, dones):
            buffer.push(o, a, r, no, d)

        state = list(next_states)
        for i, d in enumerate(dones):
            episode_rewards[i] += rewards[i]
            episode_lengths[i] += 1
            if d:
                state[i] = train_envs[i].reset()
                episode_rewards[i] = 0.0
                episode_lengths[i] = 0

        if len(buffer) >= args.batch_size:
            batch = buffer.sample(args.batch_size)
            agent.update(batch)

        step += 1

        if step % log_interval == 0:
            elapsed = time.time() - start_time
            print(
                f"Step: {step}, Avg Return: {np.mean(eval_returns) if eval_returns else 0:.2f}, "
                f"Elapsed: {elapsed:.2f}s"
            )

        if step % eval_interval == 0:
            returns = evaluate(agent, test_envs, args.eval_n_runs, args.eval_render)
            avg_ret = np.mean(returns)
            eval_returns.append(avg_ret)
            print(f"Evaluation at step {step}: avg return {avg_ret:.2f}")

    # Save final model
    torch.save(agent.state_dict(), os.path.join(outdir, "sac_agent.pt"))


def evaluate(agent, envs, n_episodes, render):
    returns = []
    for _ in range(n_episodes):
        for env in envs:
            obs = env.reset()
            done = False
            ep_ret = 0.0
            while not done:
                action = agent.evaluate_action(obs, deterministic=True)
                obs, reward, done, info = env.step(action)
                ep_ret += reward
            returns.append(ep_ret)
    return returns


# --------------------------------------------------------------------------- #
# Main
# --------------------------------------------------------------------------- #
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--total_steps", type=int, default=int(1e7))
    parser.add_argument("--num_envs", type=int, default=4)
    parser.add_argument("--gamma", type=float, default=0.98)
    parser.add_argument("--n_step", type=int, default=3)
    parser.add_argument("--lr", type=float, default=3e-4)
    parser.add_argument("--eps", type=float, default=1e-1)
    parser.add_argument("--batch_size", type=int, default=256)
    parser.add_argument("--buffer_size", type=int, default=int(1e6))
    parser.add_argument("--action_size", type=int, default=81)
    parser.add_argument("--eval_n_runs", type=int, default=10)
    parser.add_argument("--eval_interval", type=int, default=10000)
    parser.add_argument("--log_interval", type=int, default=1000)
    parser.add_argument("--outdir", type=str, default="output")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--demo", action="store_true")
    parser.add_argument("--render", action="store_true")
    parser.add_argument("--eval_render", action="store_true")
    parser.add_argument("--gpu", type=int, default=None)
    args = parser.parse_args()

    os.makedirs(args.outdir, exist_ok=True)
    set_random_seed(args.seed, gpus=(args.gpu,) if args.gpu is not None else None)
    device = torch.device("cuda" if args.gpu is not None and torch.cuda.is_available() else "cpu")

    env_id = "RoboschoolAtlasForwardWalk-v1"

    process_seeds = np.arange(args.num_envs) + args.seed * args.num_envs
    train_envs = [make_env(env_id, args.seed, i, monitor_dir=args.outdir, render=args.render) for i in range(args.num_envs)]
    test_envs = [make_env(env_id, 2**32 - 1 - args.seed, i, monitor_dir=None, render=args.eval_render) for i in range(args.num_envs)]

    obs_space = train_envs[0].observation_space
    action_space = train_envs[0].action_space
    obs_dim = obs_space.shape[0]
    action_dim = action_space.shape[0]

    agent = SACAgent(obs_dim, action_dim, device, args)
    buffer = ReplayBuffer(args.buffer_size, n_step=args.n_step, gamma=args.gamma)

    if args.demo:
        returns = evaluate(agent, test_envs, args.eval_n_runs, args.eval_render)
        print(f"Demo returns: {returns}")
    else:
        train_agent_batch_with_evaluation(
            env_id,
            args,
            args.outdir,
            train_envs,
            test_envs,
            agent,
            buffer,
            args.total_steps,
            args.eval_interval,
            args.log_interval,
        )


if __name__ == "__main__":
    main()
