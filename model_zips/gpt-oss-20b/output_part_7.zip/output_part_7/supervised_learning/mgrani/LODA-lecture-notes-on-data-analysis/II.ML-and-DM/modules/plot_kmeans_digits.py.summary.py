import numpy as np
import time
import matplotlib.pyplot as plt
from sklearn.datasets import load_digits
from sklearn.preprocessing import scale
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.metrics import (
    homogeneity_score,
    completeness_score,
    v_measure_score,
    adjusted_rand_score,
    adjusted_mutual_info_score,
    silhouette_score,
)

def bench_k_means(X, y, init, n_init, name):
    kmeans = KMeans(
        n_clusters=len(np.unique(y)),
        init=init,
        n_init=n_init,
        random_state=42,
    )
    start = time.time()
    kmeans.fit(X)
    elapsed = time.time() - start
    inertia = kmeans.inertia_
    homogeneity = homogeneity_score(y, kmeans.labels_)
    completeness = completeness_score(y, kmeans.labels_)
    v_measure = v_measure_score(y, kmeans.labels_)
    ari = adjusted_rand_score(y, kmeans.labels_)
    ami = adjusted_mutual_info_score(y, kmeans.labels_)
    sil = silhouette_score(X, kmeans.labels_)
    print(f"\n{name} (n_init={n_init}):")
    print(f"  Time elapsed: {elapsed:.4f}s")
    print(f"  Inertia: {inertia:.4f}")
    print(f"  Homogeneity: {homogeneity:.4f}")
    print(f"  Completeness: {completeness:.4f}")
    print(f"  V-Measure: {v_measure:.4f}")
    print(f"  Adjusted Rand Index: {ari:.4f}")
    print(f"  Adjusted Mutual Information: {ami:.4f}")
    print(f"  Silhouette Score: {sil:.4f}")

def main():
    # Data Preparation
    np.random.seed(42)
    digits = load_digits()
    X_raw = digits.data
    y = digits.target
    X = scale(X_raw)
    n_samples, n_features = X.shape
    n_digits = len(np.unique(y))
    print("Dataset Summary")
    print(f"  Samples: {n_samples}")
    print(f"  Features: {n_features}")
    print(f"  Unique digits: {n_digits}")

    # Benchmarking Clustering Algorithms
    bench_k_means(X, y, init="k-means++", n_init=10, name="k-means++")
    bench_k_means(X, y, init="random", n_init=10, name="Random")

    # PCA-based initialization
    pca = PCA(n_components=n_digits, random_state=42)
    pca.fit(X)
    init_centroids = pca.components_.T
    bench_k_means(X, y, init=init_centroids, n_init=1, name="PCA-based")

    # Dimensionality Reduction and Visualization
    pca2 = PCA(n_components=2, random_state=42)
    X_pca = pca2.fit_transform(X)
    kmeans_2d = KMeans(
        n_clusters=n_digits, init="k-means++", n_init=10, random_state=42
    )
    kmeans_2d.fit(X_pca)

    # Mesh grid for decision boundary
    x_min, x_max = X_pca[:, 0].min() - 1, X_pca[:, 0].max() + 1
    y_min, y_max = X_pca[:, 1].min() - 1, X_pca[:, 1].max() + 1
    xx, yy = np.meshgrid(
        np.linspace(x_min, x_max, 500), np.linspace(y_min, y_max, 500)
    )
    grid_points = np.c_[xx.ravel(), yy.ravel()]
    Z = kmeans_2d.predict(grid_points)
    Z = Z.reshape(xx.shape)

    plt.figure(figsize=(8, 6))
    plt.contourf(xx, yy, Z, cmap=plt.cm.tab10, alpha=0.3)
    scatter = plt.scatter(
        X_pca[:, 0], X_pca[:, 1], c=kmeans_2d.labels_, cmap=plt.cm.tab10, s=30, edgecolor='k'
    )
    plt.scatter(
        kmeans_2d.cluster_centers_[:, 0],
        kmeans_2d.cluster_centers_[:, 1],
        marker='x',
        s=200,
        linewidths=3,
        color='white',
        zorder=10
    )
    plt.title("K-Means Clustering on PCA-reduced Digits Data")
    plt.xlabel("PCA Component 1")
    plt.ylabel("PCA Component 2")
    plt.colorbar(scatter, ticks=range(n_digits))
    plt.show()

if __name__ == "__main__":
    main()
