import abc
import os
import pickle
import random
from dataclasses import dataclass
from typing import Any, Callable, Iterable, List, Sequence, Tuple, Dict

import numpy as np


@dataclass
class Transition:
    state: Any
    action: Any
    reward: float
    next_state: Any
    terminal: bool
    recurrent_state: Any = None
    next_recurrent_state: Any = None


class AbstractReplayBuffer(abc.ABC):
    @abc.abstractmethod
    def append(self, transition: Transition) -> None:
        pass

    @abc.abstractmethod
    def sample(self, n: int) -> List[Transition]:
        pass

    @abc.abstractmethod
    def __len__(self) -> int:
        pass

    @abc.abstractmethod
    def save(self, filepath: str) -> None:
        pass

    @abc.abstractmethod
    def load(self, filepath: str) -> None:
        pass


class AbstractEpisodicReplayBuffer(AbstractReplayBuffer):
    @abc.abstractmethod
    def sample_episodes(self, n_episodes: int, max_len: int = None) -> List[List[Transition]]:
        pass

    @property
    @abc.abstractmethod
    def n_episodes(self) -> int:
        pass

    @abc.abstractmethod
    def stop_current_episode(self, env_id: Any) -> None:
        pass


class ReplayBuffer(AbstractReplayBuffer):
    def __init__(self, capacity: int = None) -> None:
        self.capacity = capacity
        self._buffer: List[Transition] = []

    def append(self, transition: Transition) -> None:
        if self.capacity is not None and len(self._buffer) >= self.capacity:
            self._buffer.pop(0)
        self._buffer.append(transition)

    def sample(self, n: int) -> List[Transition]:
        return random.sample(self._buffer, min(n, len(self._buffer)))

    def __len__(self) -> int:
        return len(self._buffer)

    def save(self, filepath: str) -> None:
        with open(filepath, "wb") as f:
            pickle.dump(self._buffer, f)

    def load(self, filepath: str) -> None:
        with open(filepath, "rb") as f:
            self._buffer = pickle.load(f)


class EpisodicReplayBuffer(AbstractEpisodicReplayBuffer):
    def __init__(self, capacity: int = None) -> None:
        self.capacity = capacity
        self._episodes: List[List[Transition]] = []
        self._current_episode: Dict[Any, List[Transition]] = {}

    def append(self, transition: Transition) -> None:
        env_id = getattr(transition, "env_id", None)
        if env_id is None:
            raise ValueError("Transition must have an 'env_id' attribute for episodic buffer.")
        if env_id not in self._current_episode:
            self._current_episode[env_id] = []
        self._current_episode[env_id].append(transition)
        if transition.terminal:
            self.stop_current_episode(env_id)

    def stop_current_episode(self, env_id: Any) -> None:
        episode = self._current_episode.pop(env_id, None)
        if episode:
            if self.capacity is not None and len(self._episodes) >= self.capacity:
                self._episodes.pop(0)
            self._episodes.append(episode)

    def sample(self, n: int) -> List[Transition]:
        transitions = [t for episode in self._episodes for t in episode]
        return random.sample(transitions, min(n, len(transitions)))

    def sample_episodes(self, n_episodes: int, max_len: int = None) -> List[List[Transition]]:
        selected = random.sample(self._episodes, min(n_episodes, len(self._episodes)))
        if max_len is not None:
            return [random_subseq(ep, max_len) for ep in selected]
        return selected

    @property
    def n_episodes(self) -> int:
        return len(self._episodes)

    def __len__(self) -> int:
        return sum(len(ep) for ep in self._episodes)

    def save(self, filepath: str) -> None:
        with open(filepath, "wb") as f:
            pickle.dump(self._episodes, f)

    def load(self, filepath: str) -> None:
        with open(filepath, "rb") as f:
            self._episodes = pickle.load(f)


def random_subseq(seq: Sequence[Transition], subseq_len: int) -> List[Transition]:
    if len(seq) <= subseq_len:
        return list(seq)
    start = random.randint(0, len(seq) - subseq_len)
    return list(seq[start : start + subseq_len])


def batch_experiences(
    experiences: List[List[Transition]],
    xp: np.ndarray,
    phi: Callable[[Any], Any],
    gamma: float,
    batch_states: List[Any] = None,
) -> Dict[str, np.ndarray]:
    states, actions, rewards, next_states, terminals, discounts = [], [], [], [], [], []

    for episode in experiences:
        discount = 1.0
        for t in reversed(episode):
            states.append(phi(t.state))
            actions.append(t.action)
            rewards.append(t.reward * discount)
            next_states.append(phi(t.next_state))
            terminals.append(t.terminal)
            discounts.append(discount)
            discount *= gamma

    return {
        "states": np.array(states, dtype=object),
        "actions": np.array(actions, dtype=object),
        "rewards": np.array(rewards, dtype=np.float32),
        "next_states": np.array(next_states, dtype=object),
        "terminals": np.array(terminals, dtype=bool),
        "discounts": np.array(discounts, dtype=np.float32),
    }


def batch_recurrent_experiences(
    experiences: List[List[Transition]],
    xp: np.ndarray,
    phi: Callable[[Any], Any],
    gamma: float,
    model: Any,
    batch_states: List[Any] = None,
) -> Dict[str, np.ndarray]:
    states, actions, rewards, next_states, terminals, discounts, rec_states, next_rec_states = (
        [],
        [],
        [],
        [],
        [],
        [],
        [],
        [],
    )

    for episode in experiences:
        discount = 1.0
        for t in reversed(episode):
            states.append(phi(t.state))
            actions.append(t.action)
            rewards.append(t.reward * discount)
            next_states.append(phi(t.next_state))
            terminals.append(t.terminal)
            discounts.append(discount)
            rec_states.append(t.recurrent_state)
            next_rec_states.append(t.next_recurrent_state)
            discount *= gamma

    rec_states = model.concatenate_recurrent_states(np.array(rec_states, dtype=object))
    next_rec_states = model.concatenate_recurrent_states(
        np.array(next_rec_states, dtype=object)
    )

    return {
        "states": np.array(states, dtype=object),
        "actions": np.array(actions, dtype=object),
        "rewards": np.array(rewards, dtype=np.float32),
        "next_states": np.array(next_states, dtype=object),
        "terminals": np.array(terminals, dtype=bool),
        "discounts": np.array(discounts, dtype=np.float32),
        "recurrent_states": rec_states,
        "next_recurrent_states": next_rec_states,
    }


class ReplayUpdater:
    def __init__(
        self,
        replay_buffer: AbstractReplayBuffer,
        update_func: Callable[[Dict[str, np.ndarray]], None],
        batchsize: int,
        episodic_update: bool = False,
        replay_start_size: int = 1000,
        update_interval: int = 10,
        episodic_update_len: int = None,
        n_times_update: int = 1,
    ) -> None:
        self.replay_buffer = replay_buffer
        self.update_func = update_func
        self.batchsize = batchsize
        self.episodic_update = episodic_update
        self.replay_start_size = replay_start_size
        self.update_interval = update_interval
        self.episodic_update_len = episodic_update_len
        self.n_times_update = n_times_update
        self.iteration = 0

    def step(self) -> None:
        self.iteration += 1
        if len(self.replay_buffer) < self.replay_start_size:
            return
        if self.episodic_update:
            if isinstance(self.replay_buffer, AbstractEpisodicReplayBuffer):
                if self.replay_buffer.n_episodes < self.batchsize:
                    return
            else:
                return
        if self.iteration % self.update_interval != 0:
            return

        for _ in range(self.n_times_update):
            if self.episodic_update and isinstance(self.replay_buffer, AbstractEpisodicReplayBuffer):
                samples = self.replay_buffer.sample_episodes(
                    self.batchsize, self.episodic_update_len
                )
                batch = batch_experiences(samples, xp=None, phi=lambda x: x, gamma=0.99)
            else:
                samples = self.replay_buffer.sample(self.batchsize)
                # Wrap single transitions into episodes of length 1 for batch_experiences
                batch = batch_experiences([[t] for t in samples], xp=None, phi=lambda x: x, gamma=0.99)
            self.update_func(batch)


# Example usage:

class DummyModel:
    @staticmethod
    def concatenate_recurrent_states(states: np.ndarray) -> np.ndarray:
        return np.stack(states, axis=0)


def dummy_update_func(batch: Dict[str, np.ndarray]) -> None:
    # Placeholder for training logic
    pass


if __name__ == "__main__":
    buffer = EpisodicReplayBuffer(capacity=5000)
    updater = ReplayUpdater(
        replay_buffer=buffer,
        update_func=dummy_update_func,
        batchsize=32,
        episodic_update=True,
        replay_start_size=100,
        update_interval=5,
        episodic_update_len=10,
        n_times_update=2,
    )

    # Simulate adding transitions
    for i in range(200):
        t = Transition(
            state=i,
            action=i % 2,
            reward=1.0,
            next_state=i + 1,
            terminal=(i % 20 == 19),
            env_id="env_1",
        )
        buffer.append(t)
        updater.step()
```