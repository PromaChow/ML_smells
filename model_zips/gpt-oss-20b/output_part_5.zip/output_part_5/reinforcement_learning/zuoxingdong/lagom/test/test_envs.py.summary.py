import collections
import numpy as np
import pytest
import gymnasium as gym
from gymnasium.wrappers import (
    RecordEpisodeStatistics,
    NormalizeObservation,
    NormalizeReward,
    TimeStepEnv,
)

@pytest.mark.parametrize(
    "env_id,deque_size",
    [
        ("CartPole-v0", 2),
        ("CartPole-v0", 5),
        ("Pendulum-v0", 2),
        ("Pendulum-v0", 5),
    ],
)
def test_record_episode_statistics(env_id, deque_size):
    env = gym.make(env_id)
    wrapped = RecordEpisodeStatistics(env, deque_size=deque_size)
    max_steps = wrapped.unwrapped._max_episode_steps

    for _ in range(5):
        wrapped.reset()
        assert wrapped.episode_return == 0.0
        assert wrapped.episode_horizon == 0
        done = False
        steps = 0
        while not done and steps < max_steps:
            action = wrapped.action_space.sample()
            _, _, done, info = wrapped.step(action)
            steps += 1
        assert "return" in info
        assert "horizon" in info
        assert "time" in info

    assert len(wrapped.return_queue) == deque_size
    assert len(wrapped.horizon_queue) == deque_size


@pytest.mark.parametrize(
    "env_id",
    [
        "CartPole-v1",
        "Pendulum-v0",
    ],
)
def test_normalize_observation(env_id):
    env_orig = gym.make(env_id)
    env_wrap = NormalizeObservation(gym.make(env_id))

    env_orig.reset(seed=0)
    env_wrap.reset(seed=0)

    max_steps = env_orig.unwrapped._max_episode_steps
    obs_list = []

    for _ in range(max_steps):
        action = env_orig.action_space.sample()
        obs_orig, _, done, _ = env_orig.step(action)
        obs_wrap, _, _, _ = env_wrap.step(action)

        obs_list.append(obs_orig)
        mean = np.mean(obs_list, axis=0)
        var = np.var(obs_list, axis=0)

        assert np.allclose(env_wrap.obs_moments["mean"], mean, atol=1e-5)
        assert np.allclose(env_wrap.obs_moments["var"], var, atol=1e-5)

        if done:
            break


@pytest.mark.parametrize(
    "env_id,gamma",
    [
        ("CartPole-v1", 0.5),
        ("CartPole-v1", 0.99),
        ("Pendulum-v0", 0.5),
        ("Pendulum-v0", 0.99),
    ],
)
def test_normalize_reward(env_id, gamma):
    env_orig = gym.make(env_id)
    env_wrap = NormalizeReward(gym.make(env_id), gamma=gamma)

    env_orig.reset(seed=0)
    env_wrap.reset(seed=0)

    max_steps = env_orig.unwrapped._max_episode_steps
    returns = []

    for _ in range(10):
        env_orig.reset()
        env_wrap.reset()
        done = False
        steps = 0
        G = 0.0
        discount = 1.0

        while not done and steps < max_steps:
            action = env_orig.action_space.sample()
            _, reward, done, _ = env_orig.step(action)
            _, reward_wrapped, done, _ = env_wrap.step(action)
            G += discount * reward
            discount *= gamma
            steps += 1

        returns.append(G)
        assert np.isclose(env_wrap.all_returns[-1], G, atol=1e-5)

        mean_ret = np.mean(returns)
        var_ret = np.var(returns)
        assert np.isclose(env_wrap.reward_moments["mean"], mean_ret, atol=1e-5)
        assert np.isclose(env_wrap.reward_moments["var"], var_ret, atol=1e-5)


@pytest.mark.parametrize(
    "env_id",
    [
        "CartPole-v1",
        "Pendulum-v0",
    ],
)
def test_timestep_env(env_id):
    env_orig = gym.make(env_id)
    env_wrap = TimeStepEnv(gym.make(env_id))

    obs_orig, _ = env_orig.reset(seed=0)
    timestep = env_wrap.reset(seed=0)
    assert timestep.first() is True
    assert np.allclose(timestep.observation, obs_orig)

    max_steps = env_orig.unwrapped._max_episode_steps

    for _ in range(max_steps):
        action = env_orig.action_space.sample()
        obs_orig, reward_orig, done, info_orig = env_orig.step(action)
        timestep = env_wrap.step(action)

        assert np.allclose(timestep.observation, obs_orig)
        assert np.isclose(timestep.reward, reward_orig)
        assert timestep.done == done
        assert timestep.info == info_orig

        if done:
            if info_orig.get("TimeLimit.truncated", False):
                assert timestep.time_limit() is True
            else:
                assert timestep.terminal() is True
            assert timestep.last() is True
        else:
            assert timestep.mid() is True
        if done:
            break
```