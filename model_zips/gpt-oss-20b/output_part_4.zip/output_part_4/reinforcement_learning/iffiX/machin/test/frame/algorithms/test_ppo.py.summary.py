import json
import os
import gym
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import pytest
from dataclasses import dataclass, field
from typing import List, Tuple


@dataclass
class Config:
    env_name: str = "CartPole-v0"
    max_episodes: int = 1000
    max_steps: int = 200
    target_reward: float = 150.0
    actor_hidden: int = 64
    critic_hidden: int = 64
    gae_lambda: float = 0.95
    gamma: float = 0.99
    clip_eps: float = 0.2
    lr: float = 3e-4
    update_epochs: int = 10
    batch_size: int = 64
    ent_coef: float = 0.01
    value_coef: float = 0.5
    max_grad_norm: float = 0.5
    use_replay_buffer: bool = True
    logging: bool = False


class ActorNet(nn.Module):
    def __init__(self, obs_dim: int, action_dim: int, hidden_dim: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, action_dim),
            nn.Softmax(dim=-1)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class CriticNet(nn.Module):
    def __init__(self, obs_dim: int, hidden_dim: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class ReplayBuffer:
    def __init__(self):
        self.states: List[np.ndarray] = []
        self.actions: List[int] = []
        self.rewards: List[float] = []
        self.dones: List[bool] = []
        self.log_probs: List[float] = []

    def store(self, state, action, reward, done, log_prob):
        self.states.append(state)
        self.actions.append(action)
        self.rewards.append(reward)
        self.dones.append(done)
        self.log_probs.append(log_prob)

    def clear(self):
        self.states.clear()
        self.actions.clear()
        self.rewards.clear()
        self.dones.clear()
        self.log_probs.clear()

    def __len__(self):
        return len(self.states)


class PPO:
    def __init__(self, config: Config, device: torch.device = torch.device("cpu")):
        self.config = config
        env = gym.make(config.env_name)
        self.obs_dim = env.observation_space.shape[0]
        self.action_dim = env.action_space.n
        env.close()

        self.actor = ActorNet(self.obs_dim, self.action_dim, config.actor_hidden).to(device)
        self.critic = CriticNet(self.obs_dim, config.critic_hidden).to(device)

        self.optimizer = optim.Adam(
            list(self.actor.parameters()) + list(self.critic.parameters()), lr=config.lr
        )
        self.buffer = ReplayBuffer() if config.use_replay_buffer else None
        self.device = device

    def act(self, state: np.ndarray) -> Tuple[int, float, float]:
        state_t = torch.tensor(state, dtype=torch.float32, device=self.device).unsqueeze(0)
        with torch.no_grad():
            probs = self.actor(state_t)
            dist = torch.distributions.Categorical(probs)
            action = dist.sample()
            log_prob = dist.log_prob(action)
            entropy = dist.entropy()
        return int(action.item()), log_prob.item(), entropy.item()

    def store_episode(self, state, action, reward, done, log_prob):
        if self.buffer:
            self.buffer.store(state, action, reward, done, log_prob)

    def compute_advantages(self, states, rewards, dones, values, next_values):
        advantages = []
        advantage = 0.0
        for t in reversed(range(len(rewards))):
            delta = rewards[t] + self.config.gamma * next_values[t] * (1 - dones[t]) - values[t]
            advantage = delta + self.config.gamma * self.config.gae_lambda * (1 - dones[t]) * advantage
            advantages.insert(0, advantage)
        return np.array(advantages, dtype=np.float32)

    def update(self):
        if not self.buffer or len(self.buffer) == 0:
            return
        states = torch.tensor(np.array(self.buffer.states), dtype=torch.float32, device=self.device)
        actions = torch.tensor(np.array(self.buffer.actions), dtype=torch.int64, device=self.device)
        rewards = np.array(self.buffer.rewards, dtype=np.float32)
        dones = np.array(self.buffer.dones, dtype=np.float32)
        old_log_probs = torch.tensor(np.array(self.buffer.log_probs), dtype=torch.float32, device=self.device)

        with torch.no_grad():
            values = self.critic(states).squeeze().cpu().numpy()
            next_values = np.append(values[1:], 0)
        advantages = self.compute_advantages(states.cpu().numpy(), rewards, dones, values, next_values)
        returns = advantages + values

        advantages = torch.tensor(advantages, dtype=torch.float32, device=self.device)
        returns = torch.tensor(returns, dtype=torch.float32, device=self.device)

        dataset = torch.utils.data.TensorDataset(states, actions, old_log_probs, advantages, returns)
        loader = torch.utils.data.DataLoader(dataset, batch_size=self.config.batch_size, shuffle=True)

        for _ in range(self.config.update_epochs):
            for batch_states, batch_actions, batch_old_log_probs, batch_advantages, batch_returns in loader:
                probs = self.actor(batch_states)
                dist = torch.distributions.Categorical(probs)
                entropy = dist.entropy().mean()
                new_log_probs = dist.log_prob(batch_actions)
                ratio = torch.exp(new_log_probs - batch_old_log_probs)
                surr1 = ratio * batch_advantages
                surr2 = torch.clamp(ratio, 1.0 - self.config.clip_eps, 1.0 + self.config.clip_eps) * batch_advantages
                policy_loss = -torch.min(surr1, surr2).mean()
                value_pred = self.critic(batch_states).squeeze()
                value_loss = nn.functional.mse_loss(value_pred, batch_returns)
                loss = policy_loss + self.config.value_coef * value_loss - self.config.ent_coef * entropy

                self.optimizer.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(list(self.actor.parameters()) + list(self.critic.parameters()), self.config.max_grad_norm)
                self.optimizer.step()

        if self.buffer:
            self.buffer.clear()


def moving_average(values, window=5):
    return np.convolve(values, np.ones(window)/window, mode='valid')


@pytest.fixture
def ppo_vis():
    cfg = Config(logging=True)
    return PPO(cfg)


@pytest.fixture
def ppo_train():
    cfg = Config(logging=False)
    return PPO(cfg)


def test_update_mechanism(ppo_train):
    # synthetic episode with zero rewards
    for _ in range(3):
        state = np.zeros(4, dtype=np.float32)
        action = 0
        reward = 0.0
        done = False
        log_prob = 0.0
        ppo_train.store_episode(state, action, reward, done, log_prob)
    ppo_train.update()
    # After update, buffers should be cleared
    assert len(ppo_train.buffer) == 0


def test_configuration_initialization(tmp_path):
    config_data = {
        "env_name": "CartPole-v0",
        "max_episodes": 10,
        "max_steps": 100,
        "target_reward": 150,
        "actor_hidden": 32,
        "critic_hidden": 32,
        "gae_lambda": 0.95,
        "gamma": 0.99,
        "clip_eps": 0.2,
        "lr": 1e-4,
        "update_epochs": 5,
        "batch_size": 32,
        "ent_coef": 0.01,
        "value_coef": 0.5,
        "max_grad_norm": 0.5,
        "use_replay_buffer": True,
        "logging": False
    }
    cfg_path = tmp_path / "config.json"
    with open(cfg_path, "w") as f:
        json.dump(config_data, f)

    with open(cfg_path) as f:
        cfg_dict = json.load(f)
    cfg = Config(**cfg_dict)
    ppo = PPO(cfg)
    assert isinstance(ppo.actor, ActorNet)
    assert isinstance(ppo.critic, CriticNet)


@pytest.mark.parametrize("gae_lambda", [0.0, 0.5, 1.0])
def test_training_loop(ppo_train, gae_lambda):
    ppo_train.config.gae_lambda = gae_lambda
    env = gym.make(ppo_train.config.env_name)
    episode_rewards = []
    solved_counter = 0
    smoothed_rewards = []

    for episode in range(ppo_train.config.max_episodes):
        state = env.reset(seed=episode)
        ep_reward = 0.0
        for t in range(ppo_train.config.max_steps):
            action, log_prob, _ = ppo_train.act(state)
            next_state, reward, done, _ = env.step(action)
            ep_reward += reward
            ppo_train.store_episode(state, action, reward, done, log_prob)
            state = next_state
            if done:
                break
        ppo_train.update()
        episode_rewards.append(ep_reward)
        smoothed = np.mean(episode_rewards[-5:]) if len(episode_rewards) >= 5 else np.mean(episode_rewards)
        smoothed_rewards.append(smoothed)
        if smoothed >= ppo_train.config.target_reward:
            solved_counter += 1
            if solved_counter >= 5:
                break
        else:
            solved_counter = 0
        if episode % 100 == 0:
            print(f"Episode {episode} - Reward: {ep_reward:.2f} - Smoothed: {smoothed:.2f}")
    env.close()
    assert len(episode_rewards) > 0


@pytest.mark.skip(reason="Identical to A2C, skipped for brevity.")
def test_placeholder_skipped():
    pass
