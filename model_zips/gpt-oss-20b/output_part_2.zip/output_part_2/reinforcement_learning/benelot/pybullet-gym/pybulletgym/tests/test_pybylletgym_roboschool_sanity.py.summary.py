import gym
import numpy as np
import traceback
import pybulletgym  # ensure Bullet environments are registered


def main():
    bullet_env_ids = [eid for eid in gym.envs.registry.env_specs if "Bullet" in eid]
    bugged_envs = []

    for env_id in bullet_env_ids:
        try:
            env = gym.make(env_id)
            env.reset()
            if hasattr(env.action_space, "shape"):
                action = np.random.random(env.action_space.shape)
            else:
                action = env.action_space.sample()
            env.step(action)
            env.close()
            print(f"✅ {env_id} succeeded")
        except Exception:
            traceback.print_exc()
            bugged_envs.append(env_id)
            print(f"❌ {env_id} failed")

    print("\nEnvironments with issues:", bugged_envs)


if __name__ == "__main__":
    main()
