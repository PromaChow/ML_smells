import numpy as np
import pandas as pd

class KNN:
    def __init__(self, k=10):
        self.k = k
        self.X_train = None
        self.y_train = None

    def fit(self, X, y):
        self.X_train = X
        self.y_train = y

    def predict(self, X):
        y_pred = np.empty(X.shape[0], dtype=self.y_train.dtype)
        for i, sample in enumerate(X):
            distances = np.linalg.norm(self.X_train - sample, axis=1)
            distances_neg = -distances
            neighbor_idxs = np.argsort(distances_neg)[:self.k]
            neighbor_labels = self.y_train[neighbor_idxs]
            counts = np.bincount(neighbor_labels)
            y_pred[i] = np.argmax(counts)
        return y_pred

def load_csv_data(filepath, mode='clf'):
    df = pd.read_csv(filepath, header=None)
    X = df.iloc[:, :-1].values.astype(float)
    y_str = df.iloc[:, -1].astype(str).values
    label_mapping = {label: idx for idx, label in enumerate(sorted(set(y_str)))}
    y = np.array([label_mapping[label] for label in y_str], dtype=int)
    if mode == 'clf':
        if X.ndim != 2 or y.ndim != 1 or X.shape[0] != y.shape[0]:
            raise ValueError('Data shape mismatch for classification mode')
    return X, y

if __name__ == "__main__":
    X, y = load_csv_data('iris.data.txt', mode='clf')
    model = KNN(k=5)
    model.fit(X, y)
    y_pred = model.predict(X)
    accuracy = np.mean(y_pred == y)
    print(f'Accuracy: {accuracy:.4f}')