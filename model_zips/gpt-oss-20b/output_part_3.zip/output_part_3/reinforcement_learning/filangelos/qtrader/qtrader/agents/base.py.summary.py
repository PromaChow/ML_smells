from qtrader.utils.gym import run

class Agent:
    def __init__(self, *args, **kwargs):
        raise NotImplementedError("Subclasses must implement __init__")

    def begin_episode(self, observation):
        pass

    def act(self, observation):
        raise NotImplementedError("Subclasses must implement act")

    def observe(self, observation, action, reward, done, next_observation):
        pass

    def end_episode(self):
        pass

    def fit(self, env, num_episodes=1, verbose=False):
        run(self, env, num_episodes=num_episodes, verbose=verbose)