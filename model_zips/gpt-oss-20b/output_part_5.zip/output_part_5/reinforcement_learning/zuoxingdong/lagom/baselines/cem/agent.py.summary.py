import numpy as np
import torch
import torch.nn as nn
from gym.spaces import Discrete, Box

from lagom.agent import BaseAgent
from lagom.module import Module
from lagom.networks import make_fc, CategoricalHead, DiagGaussianHead
from lagom.utils import tensorify, numpify, pickle_dump


class MLP(Module):
    def __init__(self, config, env, device):
        super().__init__()
        self.device = device
        obs_shape = env.observation_space.shape
        input_dim = int(np.prod(obs_shape))
        sizes = config["nn.sizes"]
        self.feature_layers = make_fc(input_dim, sizes)
        self.norm_layers = nn.ModuleList(
            [nn.LayerNorm(size) for size in sizes]
        )

    def forward(self, x):
        for fc, norm in zip(self.feature_layers, self.norm_layers):
            x = fc(x)
            x = nn.functional.relu(x)
            x = norm(x)
        return x


class Agent(BaseAgent):
    def __init__(self, config, env, device="cpu"):
        super().__init__()
        self.config = config
        self.env = env
        self.device = device

        self.feature_network = MLP(config, env, device).to(device)
        self.feature_dim = config["nn.sizes"][-1]

        if isinstance(env.action_space, Discrete):
            self.action_head = CategoricalHead(
                self.feature_dim, env.action_space.n
            ).to(device)
        elif isinstance(env.action_space, Box):
            std0 = config["agent"]["std0"]
            self.action_head = DiagGaussianHead(
                self.feature_dim, env.action_space.shape[0], std0
            ).to(device)
        else:
            raise NotImplementedError(
                f"Unsupported action space: {type(env.action_space)}"
            )

    def choose_action(self, observation):
        obs_tensor = tensorify(observation).to(self.device).unsqueeze(0)
        features = self.feature_network(obs_tensor)
        action_dist = self.action_head(features)
        action = action_dist.sample()
        return numpify(action.squeeze(0), dtype=self.env.action_space.dtype)

    def learn(self, *args, **kwargs):
        pass

    def checkpoint(self, num_iter):
        state = {
            "feature_network": self.feature_network.state_dict(),
            "action_head": self.action_head.state_dict(),
        }
        torch.save(state, f"agent_{num_iter}.pth")

        if self.config.get("agent", {}).get("obs_norm", False):
            obs_norm_state = {
                "mean": self.obs_norm.mean.cpu(),
                "var": self.obs_norm.var.cpu(),
            }
            torch.save(obs_norm_state, f"obs_moments_{num_iter}.pth")