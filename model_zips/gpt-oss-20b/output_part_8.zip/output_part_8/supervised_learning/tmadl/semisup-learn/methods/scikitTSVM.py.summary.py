import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

# Assume QN_S3VM is available from the QN_S3VM package
# If not, replace this import with the correct one
from QN_S3VM import QN_S3VM


class SKTSVM:
    def __init__(self, kernel='RBF', C=1e-4, gamma=0.5, lamU=1.0, probability=True):
        self.kernel = kernel
        self.C = C
        self.gamma = gamma
        self.lamU = lamU
        self.probability = probability
        self.qn_s3vm = None
        self.plattlr = None

    def _prepare_data(self, X, y):
        # Convert y to numpy array
        y = np.asarray(y)
        # Identify labeled and unlabeled data
        labeled_mask = y != -1
        unlabeled_mask = y == -1

        labeledX = X[labeled_mask]
        unlabeledX = X[unlabeled_mask]

        # Convert labels: 0 -> -1, 1 -> 1
        labeledy = np.where(labeledX == 0, -1, 1) if unlabeledX.size == 0 else np.where(y[labeled_mask] == 0, -1, 1)
        return labeledX, labeledy, unlabeledX

    def fit(self, X, y):
        X = np.asarray(X)
        y = np.asarray(y)

        # Split data
        labeledX, labeledy, unlabeledX = self._prepare_data(X, y)

        # Set kernel type
        kernel_type = 'RBF' if self.kernel.lower() == 'rbf' else self.kernel

        # Compute sigma for RBF kernel
        sigma = np.sqrt(1 / (2 * self.gamma))

        # Initialize and train QN_S3VM
        self.qn_s3vm = QN_S3VM(labeledX, labeledy, unlabeledX, self.C, self.lamU,
                               kernel_type=kernel_type, sigma=sigma)
        self.qn_s3vm.train()

        # Platt scaling
        if self.probability:
            preds = self.qn_s3vm.mygetPreds()
            preds = preds.reshape(-1, 1)
            self.plattlr = LogisticRegression()
            self.plattlr.fit(preds, labeledy)

        return self

    def predict(self, X):
        X = np.asarray(X)
        preds = self.qn_s3vm.getPredictions(X)
        preds = np.where(preds == -1, 0, 1)
        return preds

    def predict_proba(self, X):
        if not self.probability:
            raise ValueError("Probability estimates were not enabled during training.")
        X = np.asarray(X)
        preds = self.qn_s3vm.mygetPreds(X)
        preds = preds.reshape(-1, 1)
        proba = self.plattlr.predict_proba(preds)
        return proba

    def score(self, X, y):
        y_true = np.asarray(y)
        y_pred = self.predict(X)
        return accuracy_score(y_true, y_pred)