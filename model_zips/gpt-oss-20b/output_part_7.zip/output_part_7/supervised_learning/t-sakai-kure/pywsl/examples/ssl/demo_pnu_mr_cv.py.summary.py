import numpy as np
import scipy
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
sns.set_context('paper')
sns.set(font_scale=1.2)
sns.set_style('ticks')
sns.set_style('whitegrid', {'axes.linewidth': 1.0, 'axes.edgecolor': 'black'})
sns.set_style('ticks', {'lines.linewidth': 1.5})

from pywsl import gen_twonorm_ssl, cpe, PNU_SL, PNU_SL_FastCV, calc_etab, pnu_risk, bin_clf_err
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import make_scorer
import time

# Data generation parameters
n_l = 20
n_u = 1000
n_t = 1000
prior_l = 0.5
prior_u = 0.3

# Generate synthetic data
x_l, y_l, x_u, x_t, y_t = gen_twonorm_ssl(n_l=n_l, n_u=n_u, n_t=n_t,
                                            prior_l=prior_l, prior_u=prior_u)

# Prior estimation
priorh = cpe(x_l, y_l, x_u)

# Model initialization
model = PNU_SL(prior=priorh, basis='lm')

# Hyperparameter grid
eta_list = np.logspace(-3, 1, 5)
lambda_list = [0.1]
param_grid = {'eta': eta_list, 'lambda': lambda_list}

# Adjusted eta
etah = calc_etab(x_l, y_l, x_u, priorh)

# Scorer
scorer = make_scorer(pnu_risk, prior=priorh, eta=etah)

# Prepare training data
x_train = np.vstack([x_l, x_u])
y_train = np.concatenate([y_l, np.full(x_u.shape[0], -1)])

# Grid search
grid_search = GridSearchCV(estimator=model,
                           param_grid=param_grid,
                           scoring=scorer,
                           cv=3,
                           n_jobs=-1)

start_time = time.perf_counter()
grid_search.fit(x_train, y_train)
pnu_time = time.perf_counter() - start_time

# Evaluation on test set
y_pred_pnu = grid_search.best_estimator_.predict(x_t)
err_pnu = bin_clf_err(y_pred_pnu, y_t, prior_u)
print(f'PNU_SL error: {err_pnu:.4f}, time: {pnu_time:.2f}s')

# FastCV model
fast_model = PNU_SL_FastCV(x=x_train,
                           y=y_train,
                           prior=priorh,
                           eta_list=eta_list,
                           lambda_list=lambda_list,
                           cv=3,
                           basis='lm')

start_time = time.perf_counter()
fast_model.fit()
fast_time = time.perf_counter() - start_time

# Evaluation on test set
y_pred_fast = fast_model.predict(x_t)
err_fast = bin_clf_err(y_pred_fast, y_t, prior_u)
print(f'PNU_SL_FastCV error: {err_fast:.4f}, time: {fast_time:.2f}s')