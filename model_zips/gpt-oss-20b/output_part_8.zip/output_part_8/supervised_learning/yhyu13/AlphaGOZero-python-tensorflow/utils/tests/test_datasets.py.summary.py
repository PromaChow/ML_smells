import os
import unittest
import numpy as np
import random

from GoPositionTestCase import GoPositionTestCase
import load_data_sets

TEST_DIR = 'test_data'
TEMP_FILE_NAME = 'temp_dataset.bin'


class TestDataSets(GoPositionTestCase):
    def tearDown(self):
        if os.path.exists(TEMP_FILE_NAME):
            os.remove(TEMP_FILE_NAME)

    def test_dataset_serialization(self):
        sgf_files = load_data_sets.find_sgf_files(TEST_DIR)
        for sgf_file in sgf_files:
            positions = load_data_sets.get_positions_from_sgf(sgf_file)
            dataset = load_data_sets.DataSet.from_positions_w_context(positions)
            dataset.write(TEMP_FILE_NAME)
            recovered = load_data_sets.DataSet.read(TEMP_FILE_NAME)

            # Compare boolean and scalar attributes
            self.assertEqual(dataset.is_test, recovered.is_test)
            self.assertEqual(dataset.data_size, recovered.data_size)
            self.assertEqual(dataset.board_size, recovered.board_size)
            self.assertEqual(dataset.input_planes, recovered.input_planes)

            # Compare array shapes
            self.assertEqual(dataset.pos_features.shape, recovered.pos_features.shape)
            self.assertEqual(dataset.next_moves.shape, recovered.next_moves.shape)

            # Compare array contents
            self.assertEqualNPArray(dataset.pos_features, recovered.pos_features)
            self.assertEqualNPArray(dataset.next_moves, recovered.next_moves)


class TestDataSetHelpers(unittest.TestCase):
    def test_onehot(self):
        board_size = 9
        coords = np.array([[1, 2], [3, 4]])
        expected = np.zeros((2, board_size * board_size), dtype=np.int32)
        for i, (x, y) in enumerate(coords):
            idx = y * board_size + x
            expected[i, idx] = 1
        actual = load_data_sets.make_onehot(coords, board_size=board_size)
        np.testing.assert_array_equal(expected, actual)
