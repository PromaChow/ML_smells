import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# 1. Data Collection and Initial Exploration
df = pd.read_csv("middle_tn_schools.csv")
print(df.head())

print("\nSummary statistics for numerical columns:")
print(df.describe())

# 2. Grouping Data by School Ratings
grouped = df.groupby("school_rating")[["reduced_lunch", "stu_teach_ratio"]]
group_stats = grouped.describe()
print("\nGroup-wise summary statistics:")
print(group_stats)

# 3. Correlation Analysis
corr_matrix = df[["school_rating", "reduced_lunch", "stu_teach_ratio"]].corr()
print("\nCorrelation matrix:")
print(corr_matrix)

plt.figure(figsize=(6, 4))
sns.heatmap(corr_matrix, annot=True, cmap="coolwarm", vmin=-1, vmax=1)
plt.title("Correlation Matrix")
plt.tight_layout()
plt.show()

# 4. Visualization of Relationship Between School Rating and Reduced Lunch
plt.figure(figsize=(8, 6))
sns.regplot(
    x="reduced_lunch",
    y="school_rating",
    data=df,
    scatter_kws={"alpha": 0.6},
    line_kws={"color": "red"}
)
plt.xlabel("Percentage of Students Eligible for Reduced-Price Lunch")
plt.ylabel("School Rating")
plt.title("School Rating vs. Reduced Lunch Percentage")
plt.grid(True)
plt.tight_layout()
plt.show()