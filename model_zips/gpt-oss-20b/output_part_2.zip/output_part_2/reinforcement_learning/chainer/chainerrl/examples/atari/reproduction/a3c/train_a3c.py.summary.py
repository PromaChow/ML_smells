import argparse
import os
import numpy as np
import chainerrl
import chainerrl.agents.a3c
import chainerrl.optimizers.rmsprop_async
import chainerrl.functions
import chainerrl.wrappers
import chainerrl.misc
import chainerrl.experiments
from chainerrl import utils
from chainerrl.links import NIPSDQNHead, FCSoftmaxPolicy, FCVFunction

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--processes", type=int, default=4)
    parser.add_argument("--env", type=str, default="BreakoutNoFrameskip-v4")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--outdir", type=str, default="./experiments")
    parser.add_argument("--t-max", type=int, default=5)
    parser.add_argument("--beta", type=float, default=1e-2)
    parser.add_argument("--lr", type=float, default=7e-4)
    parser.add_argument("--steps", type=int, default=8_000_0000)
    parser.add_argument("--eval-interval", type=int, default=250_000)
    parser.add_argument("--eval-n-steps", type=int, default=125_000)
    parser.add_argument("--demo", action="store_true")
    parser.add_argument("--load-pretrained", action="store_true")
    parser.add_argument("--load", type=str, default=None)
    parser.add_argument("--monitor", action="store_true")
    parser.add_argument("--render", action="store_true")
    parser.add_argument("--weight-decay", type=float, default=0.0)
    return parser.parse_args()

class A3CFF(chainerrl.chainerrl.Chain):
    def __init__(self):
        super().__init__()
        with self.init_scope():
            self.feature = NIPSDQNHead()
            self.policy = FCSoftmaxPolicy(128, 4)  # 4 actions for Breakout
            self.value = FCVFunction(128, 1)
    def pi_and_v(self, x):
        h = self.feature(x)
        pi = self.policy(h)
        v = self.value(h)
        return pi, v

def phi(x):
    return x.astype(np.float32) / 255.0

def make_env(process_idx, test=False):
    env = chainerrl.env.make_atari_env(
        args.env,
        process_idx=process_idx,
        seed=args.seed * args.processes + process_idx,
        is_test=test,
    )
    if test:
        env = chainerrl.wrappers.wrap_deepmind(
            env,
            episode_life=False,
            clip_rewards=False,
            frame_stack=True,
            scale=True,
        )
    else:
        env = chainerrl.wrappers.wrap_deepmind(
            env,
            episode_life=True,
            clip_rewards=True,
            frame_stack=True,
            scale=True,
        )
    if args.monitor:
        env = chainerrl.wrappers.Monitor(env, os.path.join(args.outdir, f"monitor_{process_idx}"))
    if args.render:
        env = chainerrl.wrappers.Render(env)
    return env

if __name__ == "__main__":
    args = parse_args()
    chainerrl.misc.set_random_seed(args.seed)
    process_seeds = np.arange(args.processes) + args.seed * args.processes
    chainerrl.experiments.prepare_output_dir(args.outdir)
    model = A3CFF()
    optimizer = chainerrl.optimizers.rmsprop_async.RMSpropAsync(
        lr=args.lr,
        epsilon=1e-1,
        alpha=0.99,
    )
    optimizer.setup(model)
    if args.weight_decay > 0:
        chainerrl.optimizer.add_hook(optimizer, chainerrl.optimizer.NonbiasWeightDecay(args.weight_decay))
    chainerrl.optimizer.add_hook(optimizer, chainerrl.optimizer.GradientClipping(40.0))
    agent = chainerrl.agents.a3c.A3C(
        model,
        optimizer,
        t_max=args.t_max,
        gamma=0.99,
        beta=args.beta,
        phi=phi,
    )
    if args.load_pretrained:
        agent.load("pretrained.a3c")
    elif args.load:
        agent.load(args.load)
    if args.demo:
        results = chainerrl.experiments.eval_performance(
            agent,
            make_env,
            steps=args.eval_n_steps,
            num_runs=5,
        )
        print(f"Demo results: mean={np.mean(results):.2f}, median={np.median(results):.2f}, std={np.std(results):.2f}")
    else:
        lr_hook = chainerrl.experiments.LinearInterpolationHook(
            args.lr, 0.0, args.steps
        )
        chainerrl.experiments.train_agent_async(
            agent,
            args.processes,
            make_env,
            steps=args.steps,
            eval_interval=args.eval_interval,
            eval_n_steps=args.eval_n_steps,
            hooks=[lr_hook],
            outdir=args.outdir,
            monitor=args.monitor,
            render=args.render,
        )
    fake_obs = np.zeros((84, 84), dtype=np.uint8)
    utils.visualize_model(agent.model, phi(fake_obs), output_path=os.path.join(args.outdir, "model"))