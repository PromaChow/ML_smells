import numpy as np


class EmpiricalNormalization:
    def __init__(
        self,
        input_shape,
        batch_axis=0,
        eps=1e-8,
        dtype=np.float32,
        until=None,
        clip_threshold=None,
    ):
        self.input_shape = tuple(input_shape)
        self.batch_axis = batch_axis
        self.eps = eps
        self.dtype = np.dtype(dtype)
        self.until = until
        self.clip_threshold = clip_threshold

        self._mean = np.zeros(self.input_shape, dtype=self.dtype)
        self._var = np.ones(self.input_shape, dtype=self.dtype)
        self.count = 0
        self._cached_std_inverse = None

    def experience(self, x):
        if self.until is not None and self.count >= self.until:
            return
        x = np.asarray(x, dtype=self.dtype)
        batch_size = x.shape[self.batch_axis]
        if batch_size == 0:
            return

        m1 = np.mean(x, axis=self.batch_axis, keepdims=False)
        v1 = np.var(x, axis=self.batch_axis, keepdims=False)

        n0 = self.count
        n1 = batch_size
        new_count = n0 + n1

        if n0 == 0:
            self._mean = m1
            self._var = v1
        else:
            m0 = self._mean
            v0 = self._var

            m_combined = (n0 * m0 + n1 * m1) / new_count

            v_combined = (
                n0 * (v0 + m0**2)
                + n1 * (v1 + m1**2)
            ) / new_count - m_combined**2

            self._mean = m_combined
            self._var = v_combined

        self.count = new_count
        self._cached_std_inverse = None

    def _get_std_inverse(self):
        if self._cached_std_inverse is None:
            self._cached_std_inverse = 1.0 / np.sqrt(self._var + self.eps)
        return self._cached_std_inverse

    def __call__(self, x, update=True):
        x = np.asarray(x, dtype=self.dtype)
        if update:
            self.experience(x)
        std_inv = self._get_std_inverse()
        y = (x - self._mean) * std_inv
        if self.clip_threshold is not None:
            y = np.clip(y, -self.clip_threshold, self.clip_threshold)
        return y

    def inverse(self, y):
        y = np.asarray(y, dtype=self.dtype)
        std = np.sqrt(self._var + self.eps)
        return y * std + self._mean

    def __getstate__(self):
        return {
            "input_shape": self.input_shape,
            "batch_axis": self.batch_axis,
            "eps": self.eps,
            "dtype": self.dtype,
            "until": self.until,
            "clip_threshold": self.clip_threshold,
            "_mean": self._mean,
            "_var": self._var,
            "count": self.count,
        }

    def __setstate__(self, state):
        self.input_shape = state["input_shape"]
        self.batch_axis = state["batch_axis"]
        self.eps = state["eps"]
        self.dtype = np.dtype(state["dtype"])
        self.until = state["until"]
        self.clip_threshold = state["clip_threshold"]
        self._mean = state["_mean"]
        self._var = state["_var"]
        self.count = state["count"]
        self._cached_std_inverse = None
