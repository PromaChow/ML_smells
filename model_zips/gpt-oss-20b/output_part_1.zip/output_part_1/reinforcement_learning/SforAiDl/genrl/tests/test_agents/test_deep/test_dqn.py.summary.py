import os
import shutil

from genrl.env import VectorEnv
from genrl.agents import (
    DQN,
    DoubleDQN,
    DuelingDQN,
    PrioritizedReplayDQN,
    NoisyDQN,
    CategoricalDQN,
)
from genrl.models import (
    MlpValue,
    MlpDuelingValue,
    MlpNoisyValue,
    MlpCategoricalValue,
)
from genrl.buffers import PrioritizedBuffer
from genrl.trainers import OffPolicyTrainer


def _cleanup_logs():
    if os.path.isdir("./logs"):
        shutil.rmtree("./logs")


def test_vanilla_dqn():
    env = VectorEnv("CartPole-v0")
    algo = DQN(
        env=env,
        network_type="mlp",
        batch_size=5,
        replay_size=100,
        value_layers=[1, 1],
    )
    assert isinstance(algo.model, MlpValue)

    trainer = OffPolicyTrainer(
        algo=algo,
        env=env,
        log_mode="csv",
        log_dir="./logs",
        max_ep_len=200,
        epochs=4,
        warmup_steps=10,
        start_update=10,
    )
    trainer.train()
    trainer.evaluate()
    _cleanup_logs()


def test_double_dqn():
    env = VectorEnv("CartPole-v0")
    algo = DoubleDQN(
        env=env,
        network_type="mlp",
        batch_size=5,
        replay_size=100,
        value_layers=[1, 1],
    )
    assert isinstance(algo.model, MlpValue)

    trainer = OffPolicyTrainer(
        algo=algo,
        env=env,
        log_mode="csv",
        log_dir="./logs",
        max_ep_len=200,
        epochs=4,
        warmup_steps=10,
        start_update=10,
    )
    trainer.train()
    _cleanup_logs()


def test_dueling_dqn():
    env = VectorEnv("CartPole-v0")
    algo = DuelingDQN(
        env=env,
        network_type="mlp",
        batch_size=5,
        replay_size=100,
        value_layers=[1, 1],
    )
    assert algo.dqn_type == "dueling"
    assert isinstance(algo.model, MlpDuelingValue)

    trainer = OffPolicyTrainer(
        algo=algo,
        env=env,
        log_mode="csv",
        log_dir="./logs",
        max_ep_len=200,
        epochs=4,
        warmup_steps=10,
        start_update=10,
    )
    trainer.train()
    _cleanup_logs()


def test_prioritized_dqn():
    env = VectorEnv("CartPole-v0")
    algo = PrioritizedReplayDQN(
        env=env,
        network_type="mlp",
        batch_size=5,
        replay_size=100,
        value_layers=[1, 1],
    )
    assert isinstance(algo.model, MlpValue)
    assert isinstance(algo.buffer, PrioritizedBuffer)

    trainer = OffPolicyTrainer(
        algo=algo,
        env=env,
        log_mode="csv",
        log_dir="./logs",
        max_ep_len=200,
        epochs=4,
        warmup_steps=10,
        start_update=10,
        log_interval=1,
    )
    trainer.train()
    trainer.evaluate()
    _cleanup_logs()


def test_noisy_dqn():
    env = VectorEnv("CartPole-v0")
    algo = NoisyDQN(
        env=env,
        network_type="mlp",
        batch_size=5,
        replay_size=100,
        value_layers=[1, 1],
    )
    assert algo.dqn_type == "noisy"
    assert algo.noisy is True
    assert isinstance(algo.model, MlpNoisyValue)

    trainer = OffPolicyTrainer(
        algo=algo,
        env=env,
        log_mode="csv",
        log_dir="./logs",
        max_ep_len=200,
        epochs=4,
        warmup_steps=10,
        start_update=10,
    )
    trainer.train()
    _cleanup_logs()


def test_categorical_dqn():
    env = VectorEnv("CartPole-v0")
    algo = CategoricalDQN(
        env=env,
        network_type="mlp",
        batch_size=5,
        replay_size=100,
        value_layers=[1, 1],
    )
    assert algo.dqn_type == "categorical"
    assert algo.noisy is True
    assert isinstance(algo.model, MlpCategoricalValue)

    trainer = OffPolicyTrainer(
        algo=algo,
        env=env,
        log_mode="csv",
        log_dir="./logs",
        max_ep_len=200,
        epochs=4,
        warmup_steps=10,
        start_update=10,
    )
    trainer.train()
    trainer.evaluate()
    _cleanup_logs()
