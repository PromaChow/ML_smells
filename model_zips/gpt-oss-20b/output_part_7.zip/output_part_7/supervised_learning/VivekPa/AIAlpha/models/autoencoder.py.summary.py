import os
import numpy as np
import pandas as pd
from tensorflow.keras import layers, models, optimizers
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Dense, Input


class AutoEncoder:
    def __init__(self, encoding_dim: int, input_shape: int):
        self.encoding_dim = encoding_dim
        self.input_shape = input_shape
        self.autoencoder: Model | None = None
        self.encoder_model: Model | None = None
        self.build_model()

    def build_model(self) -> None:
        input_layer = Input(shape=(1, self.input_shape))
        # Encoder
        encoded = Dense(self.encoding_dim, activation='relu')(input_layer)
        # Decoder
        decoded = Dense(self.input_shape, activation='sigmoid')(encoded)
        # Autoencoder model
        self.autoencoder = Model(inputs=input_layer, outputs=decoded)
        # Encoder model
        self.encoder_model = Model(inputs=input_layer, outputs=encoded)

    def train_model(
        self,
        X_train: np.ndarray,
        epochs: int = 50,
        batch_size: int = 32,
        save_model: bool = False,
        model_name: str = "autoencoder.h5",
    ) -> None:
        if self.autoencoder is None:
            raise ValueError("Autoencoder model has not been built.")
        # Compile
        self.autoencoder.compile(
            optimizer=optimizers.Adam(),
            loss="mse",
            metrics=["accuracy", "mae"],
        )
        # Reshape input
        X = X_train.reshape((-1, 1, self.input_shape))
        # Train
        self.autoencoder.fit(
            X,
            X,
            epochs=epochs,
            batch_size=batch_size,
            shuffle=True,
            verbose=0,
        )
        # Save if requested
        if save_model:
            os.makedirs("models/saved_models", exist_ok=True)
            self.autoencoder.save(f"models/saved_models/{model_name}")

    def test_model(self, X_test: np.ndarray) -> None:
        if self.autoencoder is None:
            raise ValueError("Autoencoder model has not been built.")
        X = X_test.reshape((-1, 1, self.input_shape))
        loss, accuracy, mae = self.autoencoder.evaluate(X, X, verbose=0)
        print(f"Test Loss: {loss:.4f}")
        print(f"Test Accuracy: {accuracy:.4f}")
        print(f"Test MAE: {mae:.4f}")

    def encode_data(
        self,
        X: np.ndarray,
        save_csv: bool = False,
        csv_path: str = "encoded.csv",
    ) -> pd.DataFrame:
        if self.encoder_model is None:
            raise ValueError("Encoder model has not been built.")
        encoded_rows = []
        for row in X:
            sample = row.reshape((1, 1, self.input_shape))
            encoded = self.encoder_model.predict(sample, verbose=0)
            flat_encoded = encoded.flatten()
            # Resize to 20 dimensions regardless of actual encoding_dim
            flat_encoded = np.resize(flat_encoded, (20,))
            encoded_rows.append(flat_encoded)
        df = pd.DataFrame(encoded_rows)
        if save_csv:
            df.to_csv(csv_path, index=False)
        return df
