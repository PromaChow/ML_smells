import numpy as np

def batch_states(states, xp, phi):
    """
    Batch heterogeneous state components after applying a transformation function.

    Parameters
    ----------
    states : list of tuples
        Each tuple contains (a, b, c) where
        - a : 2x2 array
        - b : integer
        - c : 1D array of shape (1,)
    xp : module
        Execution context, e.g. numpy or cupy.
    phi : callable
        Transformation function applied to each state tuple. Should return a tuple
        (a, b, c) with the same structure.

    Returns
    -------
    tuple
        (batch_a, batch_b, batch_c) where
        - batch_a : xp.ndarray of shape (N, 2, 2)
        - batch_b : xp.ndarray of shape (N,)
        - batch_c : xp.ndarray of shape (N, 1)
    """
    transformed = [phi(state) for state in states]

    a_list = []
    b_list = []
    c_list = []

    for a, b, c in transformed:
        a_list.append(xp.asarray(a))
        b_list.append(xp.asarray(b))
        c_list.append(xp.asarray(c))

    batch_a = xp.stack(a_list, axis=0)
    batch_b = xp.stack(b_list, axis=0).reshape(-1)
    batch_c = xp.stack(c_list, axis=0)

    return batch_a, batch_b, batch_c
