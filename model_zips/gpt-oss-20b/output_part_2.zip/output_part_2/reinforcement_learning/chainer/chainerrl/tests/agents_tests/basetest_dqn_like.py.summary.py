import abc
import numpy as np
import gym
from gym import spaces
from chainerrl import agents, explorers, optimizers, replay_buffers, q_functions, links
from chainerrl.agents import dqn
from chainerrl.explorers import linear_decay_epsilon_greedy
from chainerrl.links import elu, stateless_recurrent_sequential
from chainerrl.q_functions import FCStateQFunctionWithDiscreteAction, FCQuadraticStateQFunction
from chainerrl.replay_buffers import ReplayBuffer, EpisodicReplayBuffer
from chainerrl.optimizers import Adam


# Dummy environments
class DummyDiscreteEnv(gym.Env):
    def __init__(self):
        super().__init__()
        self.action_space = spaces.Discrete(2)
        self.observation_space = spaces.Box(0, 1, shape=(1,), dtype=np.float32)

    def reset(self):
        return np.array([0.0], dtype=np.float32)

    def step(self, action):
        return np.array([0.0], dtype=np.float32), 1.0, True, {}


class DummyPODiscreteEnv(gym.Env):
    def __init__(self):
        super().__init__()
        self.action_space = spaces.Discrete(2)
        self.observation_space = spaces.Box(0, 1, shape=(1,), dtype=np.float32)

    def reset(self):
        return np.array([0.0], dtype=np.float32)

    def step(self, action):
        return np.array([0.0], dtype=np.float32), 1.0, True, {}


class DummyContinuousEnv(gym.Env):
    def __init__(self):
        super().__init__()
        self.action_space = spaces.Box(-1, 1, shape=(2,), dtype=np.float32)
        self.observation_space = spaces.Box(0, 1, shape=(2,), dtype=np.float32)

    def reset(self):
        return np.array([0.0, 0.0], dtype=np.float32)

    def step(self, action):
        return np.array([0.0, 0.0], dtype=np.float32), 1.0, True, {}


# Base test class
class _TestDQNLike(abc.ABC):
    @abc.abstractmethod
    def make_q_func(self):
        pass

    @abc.abstractmethod
    def make_optimizer(self, q_func):
        pass

    @abc.abstractmethod
    def make_explorer(self, env):
        pass

    @abc.abstractmethod
    def make_replay_buffer(self):
        pass

    def make_agent(self, env):
        q_func = self.make_q_func()
        optimizer = self.make_optimizer(q_func)
        explorer = self.make_explorer(env)
        replay_buffer = self.make_replay_buffer()
        agent = dqn.DQN(
            q_func,
            optimizer,
            explorer,
            replay_buffer,
            target_update_interval=1000,
            gamma=0.99,
            grad_clip=10,
            update_interval=1,
            batch_size=32,
        )
        return agent


# Concrete DQN on abstract base
class _TestDQNOnABC(_TestDQNLike):
    def make_explorer(self, env):
        def random_action():
            return env.action_space.sample()
        return linear_decay_epsilon_greedy.LinearDecayEpsilonGreedy(
            random_action,
            start_epsilon=1.0,
            end_epsilon=0.5,
            decay_steps=1000,
        )

    def make_optimizer(self, q_func):
        return Adam(
            q_func,
            lr=1e-2,
        )

    def make_replay_buffer(self):
        return ReplayBuffer(capacity=100000)

    @abc.abstractmethod
    def make_q_func(self):
        pass


# Discrete action space test
class _TestDQNOnDiscreteABC(_TestDQNOnABC):
    def make_q_func(self):
        return FCStateQFunctionWithDiscreteAction(
            1,
            2,
            hidden_sizes=(10, 10),
            activation=elu.elu,
        )

    def make_env_and_successful_return(self):
        return DummyDiscreteEnv(), 1


# Partially observable discrete test
class _TestDQNOnDiscretePOABC(_TestDQNOnABC):
    def make_q_func(self):
        return stateless_recurrent_sequential.StatelessRecurrentSequential(
            el.elu,
            1,
            n_steps=2,
            hidden_size=10,
            action_size=2,
        )

    def make_optimizer(self, q_func):
        return Adam(
            q_func,
            lr=1e-2,
            eps=1e-2,
        )

    def make_replay_buffer(self):
        return EpisodicReplayBuffer(capacity=100000)

    def make_env_and_successful_return(self):
        return DummyPODiscreteEnv(), 1


# N-step DQN base
class _TestNStepDQNOnABC(_TestDQNLike):
    def make_q_func(self):
        return FCStateQFunctionWithDiscreteAction(
            1,
            2,
            hidden_sizes=(10, 10),
            activation=elu.elu,
        )

    def make_optimizer(self, q_func):
        return Adam(
            q_func,
            lr=1e-2,
        )

    def make_explorer(self, env):
        def random_action():
            return env.action_space.sample()
        return linear_decay_epsilon_greedy.LinearDecayEpsilonGreedy(
            random_action,
            start_epsilon=1.0,
            end_epsilon=0.5,
            decay_steps=1000,
        )

    def make_replay_buffer(self):
        return ReplayBuffer(capacity=100000, num_steps=3)

    def make_agent(self, env):
        q_func = self.make_q_func()
        optimizer = self.make_optimizer(q_func)
        explorer = self.make_explorer(env)
        replay_buffer = self.make_replay_buffer()
        agent = dqn.DQN(
            q_func,
            optimizer,
            explorer,
            replay_buffer,
            target_update_interval=1000,
            gamma=0.99,
            grad_clip=10,
            update_interval=1,
            batch_size=32,
            n_step=3,
        )
        return agent


class _TestNStepDQNOnDiscreteABC(_TestNStepDQNOnABC):
    def make_q_func(self):
        return FCStateQFunctionWithDiscreteAction(
            1,
            2,
            hidden_sizes=(10, 10),
            activation=elu.elu,
        )

    def make_env_and_successful_return(self):
        return DummyDiscreteEnv(), 1


# Continuous action space test
class _TestDQNOnContinuousABC(_TestDQNOnABC):
    def make_q_func(self):
        return FCQuadraticStateQFunction(
            2,
            hidden_sizes=(20, 20),
            activation=elu.elu,
        )

    def make_env_and_successful_return(self):
        return DummyContinuousEnv(), 1
