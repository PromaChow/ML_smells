import abc
import numpy as np
import pandas as pd
import gym
from gym import spaces
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

try:
    from qtrader.utils.summary import stats as qtrader_stats
    from qtrader.utils.summary import figure as qtrader_figure
except Exception:
    def qtrader_stats(df):
        # Simple placeholder statistics
        mean = df.mean()
        std = df.std()
        sharpe = mean / std if std != 0 else np.nan
        max_drawdown = df.cummax() - df
        max_dd = max_drawdown.min()
        return pd.Series(
            {
                "mean": mean,
                "std": std,
                "sharpe_ratio": sharpe,
                "max_drawdown": max_dd,
            }
        )

    def qtrader_figure(df, title=""):
        plt.figure(figsize=(6, 4))
        df.plot()
        plt.title(title)
        plt.tight_layout()
        plt.show()


class BaseEnv(gym.Env, metaclass=abc.ABCMeta):
    """
    A quantitative trading environment compatible with OpenAI Gym.
    """

    metadata = {"render.modes": ["human"]}

    def __init__(
        self,
        *,
        universe: list | None = None,
        prices: pd.DataFrame | None = None,
        trading_period: str = "W-FRI",
        include_cash: bool = True,
    ):
        if universe is None and prices is None:
            raise ValueError("Either universe or prices must be provided.")
        if universe is not None and prices is not None:
            raise ValueError("Provide only one of universe or prices.")

        self.trading_period = trading_period
        self.include_cash = include_cash

        if prices is not None:
            self.prices = prices.copy()
        else:
            self.prices = self._get_prices(universe)

        if not isinstance(self.prices.index, pd.DatetimeIndex):
            self.prices.index = pd.to_datetime(self.prices.index)

        # Clean and resample
        self.prices = (
            self.prices.resample(self.trading_period)
            .last()
            .dropna()
            .sort_index()
        )

        if self.include_cash:
            self.prices["CASH"] = 1.0

        self.returns = self.prices.pct_change().dropna()

        self._universe = list(self.prices.columns)

        self.observation_space = spaces.Box(
            low=-np.inf,
            high=np.inf,
            shape=(len(self._universe),),
            dtype=np.float32,
        )
        self.action_space = spaces.Box(
            low=0.0,
            high=1.0,
            shape=(len(self._universe),),
            dtype=np.float32,
        )

        self.counter = 0
        self.agents = {}
        self.agent_actions = {}
        self.agent_rewards = {}
        self.agent_pnl = {}
        self.pnl = pd.DataFrame(index=self.dates)

        # Rendering components
        self._fig = None
        self._ax_prices = None
        self._ax_pnl = None
        self._price_lines = {}
        self._pnl_lines = {}

    @property
    def universe(self):
        return self._universe

    @property
    def dates(self):
        return self.prices.index

    @property
    def index(self):
        return self.dates[self.counter] if self.counter < len(self.dates) else self.dates[-1]

    @property
    def _max_episode_steps(self):
        return len(self.dates)

    @abc.abstractmethod
    def _get_prices(self, universe: list) -> pd.DataFrame:
        """Return a DataFrame of historical prices for the given universe."""
        pass

    def _get_observation(self) -> dict:
        current_prices = self.prices.loc[self.index]
        current_returns = self.returns.loc[self.index] if self.index in self.returns.index else pd.Series(
            0.0, index=self.prices.columns
        )
        return {"prices": current_prices.values, "returns": current_returns.values}

    def _get_done(self) -> bool:
        return self.counter >= len(self.dates) - 1

    def _get_info(self) -> dict:
        return {}

    def _validate_agents(self):
        if not self.agents:
            raise ValueError("No agents registered in the environment.")

    def register(self, agent):
        if not hasattr(agent, "name"):
            raise AttributeError("Agent must have a 'name' attribute.")
        name = agent.name
        if name in self.agents:
            raise ValueError(f"Agent with name '{name}' already registered.")
        self.agents[name] = agent
        self.agent_actions[name] = pd.DataFrame(
            np.nan, index=self.dates, columns=self.prices.columns
        )
        self.agent_rewards[name] = pd.Series(index=self.dates, dtype=np.float64)
        self.agent_pnl[name] = pd.Series(index=self.dates, dtype=np.float64)
        self.agent_pnl[name].iloc[0] = 1.0
        self.pnl[name] = pd.Series(index=self.dates, dtype=np.float64)
        self.pnl[name].iloc[0] = 1.0

    def unregister(self, agent=None):
        if agent is None:
            self.agents.clear()
            self.agent_actions.clear()
            self.agent_rewards.clear()
            self.agent_pnl.clear()
            self.pnl = pd.DataFrame(index=self.dates)
        else:
            name = agent.name if hasattr(agent, "name") else agent
            self.agents.pop(name, None)
            self.agent_actions.pop(name, None)
            self.agent_rewards.pop(name, None)
            self.agent_pnl.pop(name, None)
            self.pnl.pop(name, None)

    def step(self, action):
        """
        Parameters
        ----------
        action : dict or ndarray
            If dict, keys are agent names and values are ndarray of weights.
            If ndarray, it applies to all registered agents.
        """
        self._validate_agents()

        if isinstance(action, dict):
            actions = action
        else:
            actions = {name: action for name in self.agents}

        # Record actions and compute rewards
        rewards = []
        for name, act in actions.items():
            if name not in self.agents:
                raise ValueError(f"Unknown agent '{name}'.")
            act = np.asarray(act)
            if act.shape != (len(self.prices.columns),):
                raise ValueError(f"Action shape mismatch for agent '{name}'.")
            self.agent_actions[name].iloc[self.counter] = act
            current_ret = self.returns.loc[self.index] if self.index in self.returns.index else pd.Series(
                0.0, index=self.prices.columns
            )
            reward = float(np.dot(act, current_ret.values))
            self.agent_rewards[name].iloc[self.counter] = reward
            rewards.append(reward)

        # Update PnL
        for name in self.agents:
            prev_pnl = self.agent_pnl[name].iloc[self.counter]
            reward = self.agent_rewards[name].iloc[self.counter]
            new_pnl = prev_pnl * (1 + reward)
            self.agent_pnl[name].iloc[self.counter + 1] = new_pnl
            self.pnl[name].iloc[self.counter + 1] = new_pnl

        total_reward = sum(rewards)
        self.counter += 1
        done = self._get_done()
        obs = self._get_observation()
        info = self._get_info()
        return obs, total_reward, done, info

    def reset(self):
        self.counter = 0
        return self._get_observation()

    def render(self, mode="human"):
        if self._fig is None:
            self._fig, (self._ax_prices, self._ax_pnl) = plt.subplots(2, 1, figsize=(10, 8))
            for col in self.prices.columns:
                line, = self._ax_prices.plot(
                    self.dates, self.prices[col], label=col, alpha=0.7
                )
                self._price_lines[col] = line
            self._ax_prices.set_title("Market Prices")
            self._ax_prices.set_ylabel("Price")
            self._ax_prices.legend(loc="upper left", bbox_to_anchor=(1, 1))
            for name in self.agents:
                line, = self._ax_pnl.plot(
                    self.dates,
                    self.agent_pnl[name].reindex(self.dates),
                    label=name,
                    linewidth=2,
                )
                self._pnl_lines[name] = line
            self._ax_pnl.set_title("Agent PnL")
            self._ax_pnl.set_ylabel("Wealth")
            self._ax_pnl.legend(loc="upper left", bbox_to_anchor=(1, 1))
            plt.tight_layout()
        else:
            # Update lines
            for col in self.prices.columns:
                self._price_lines[col].set_ydata(self.prices[col])
            for name in self.agents:
                self._pnl_lines[name].set_ydata(
                    self.agent_pnl[name].reindex(self.dates).values
                )
            self._fig.canvas.draw()
            self._fig.canvas.flush_events()

    def summary(self):
        """
        Compute statistical summaries for each agent's performance.
        Returns
        -------
        summary_df : pd.DataFrame
            Contains statistics like Sharpe ratio, max drawdown, etc.
        """
        stats_dict = {}
        for name in self.agents:
            agent_ret = self.agent_rewards[name].dropna()
            stats = qtrader_stats(agent_ret)
            stats_dict[name] = stats
        summary_df = pd.DataFrame(stats_dict).T
        # Plotting
        qtrader_figure(
            self.prices,
            title="Market Prices",
        )
        qtrader_figure(
            self.pnl,
            title="Agents PnL",
        )
        return summary_df

    def close(self):
        if self._fig:
            plt.close(self._fig)
        self._fig = None
        self._ax_prices = None
        self._ax_pnl = None
        self._price_lines.clear()
        self._pnl_lines.clear()
