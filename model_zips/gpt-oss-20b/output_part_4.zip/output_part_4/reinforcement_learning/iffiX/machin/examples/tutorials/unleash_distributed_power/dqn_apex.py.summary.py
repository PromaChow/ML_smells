import time
import gym
import torch
import torch.nn as nn
import torch.optim as optim
import torch.multiprocessing as mp
from torch.nn.parallel import DistributedDataParallel as DDP
from machin.world import World
from machin.utils.model_server import model_server_helper
from machin.algorithms.dqn.apex import DQNApex

class QNet(nn.Module):
    def __init__(self, input_dim: int, output_dim: int) -> None:
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, output_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


def worker_process(world: World, dqn_apex: DQNApex, env: gym.Env) -> None:
    smoothed_reward = 0.0
    consecutive = 0
    for episode in range(2000):
        dqn_apex.manual_sync()
        state = env.reset()
        total_reward = 0.0
        for _ in range(200):
            action = dqn_apex.act_discrete_with_noise(state)
            next_state, reward, done, _ = env.step(action)
            dqn_apex.store(state, action, reward, next_state, done)
            state = next_state
            total_reward += reward
            if done:
                break
        smoothed_reward = 0.9 * smoothed_reward + 0.1 * total_reward
        print(
            f"Rank {world.rank} Episode {episode} Reward {total_reward:.2f} "
            f"Smoothed {smoothed_reward:.2f}"
        )
        if smoothed_reward > 190.0:
            consecutive += 1
            if consecutive >= 5:
                print(f"Rank {world.rank} solved!")
                break
        else:
            consecutive = 0
    env.close()


def learner_process(world: World, dqn_apex: DQNApex) -> None:
    while dqn_apex.replay_buffer.size() < 500:
        time.sleep(1)
    while True:
        dqn_apex.update()


def main(rank: int) -> None:
    world = World(size=4, rank=rank)
    servers = model_server_helper(world)
    apex_group = world.group("apex", ranks=[0, 1, 2, 3])
    learner_group = world.group("learner", ranks=[2, 3])

    env = gym.make("CartPole-v1")
    obs_dim = env.observation_space.shape[0]
    act_dim = env.action_space.n

    q_net = QNet(obs_dim, act_dim)
    q_net_t = QNet(obs_dim, act_dim)

    if rank in [2, 3]:
        q_net = DDP(q_net)
        q_net_t = DDP(q_net_t)

    optimizer = optim.Adam(q_net.parameters(), lr=1e-3)
    loss_fn = nn.MSELoss()

    dqn_apex = DQNApex(
        q_net,
        q_net_t,
        optimizer,
        loss_fn,
        apex_group,
        servers,
        batch_size=50,
    )

    apex_group.barrier()
    dqn_apex.set_sync(False)

    if rank in [0, 1]:
        worker_process(world, dqn_apex, env)
    else:
        learner_process(world, dqn_apex)


if __name__ == "__main__":
    mp.set_start_method("spawn")
    mp.spawn(main, nprocs=4, join=True)