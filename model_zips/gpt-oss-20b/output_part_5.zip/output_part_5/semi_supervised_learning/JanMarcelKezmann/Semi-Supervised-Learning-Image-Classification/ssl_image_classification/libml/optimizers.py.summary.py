import tensorflow as tf

def get_optimizer(
    opt_name: str,
    lr: float,
    momentum: float,
    beta1: float,
    beta2: float,
    rho: float,
    eps: float,
) -> tf.keras.optimizers.Optimizer:
    """
    Return a TensorFlow Keras optimizer based on the provided name and hyperparameters.

    Parameters
    ----------
    opt_name : str
        Name of the optimizer. Must be one of the supported options.
    lr : float
        Learning rate.
    momentum : float
        Momentum for optimizers that support it.
    beta1 : float
        First beta value for Adam-like optimizers.
    beta2 : float
        Second beta value for Adam-like optimizers.
    rho : float
        Rho parameter for Adadelta and RMSprop.
    eps : float
        Epsilon value for numerical stability.

    Returns
    -------
    tf.keras.optimizers.Optimizer
        Instantiated optimizer.

    Raises
    ------
    ValueError
        If ``opt_name`` is not a recognized optimizer.
    """
    if opt_name == "Adadelta":
        return tf.keras.optimizers.Adadelta(
            learning_rate=lr, rho=rho, epsilon=eps
        )
    if opt_name == "Adagrad":
        return tf.keras.optimizers.Adagrad(
            learning_rate=lr, initial_accumulator_value=0.1, epsilon=eps
        )
    if opt_name == "Adam":
        return tf.keras.optimizers.Adam(
            learning_rate=lr,
            beta_1=beta1,
            beta_2=beta1,  # Note: beta2 is set to beta1 as specified
            epsilon=eps,
            amsgrad=False,
        )
    if opt_name == "Adamax":
        return tf.keras.optimizers.Adamax(
            learning_rate=lr, beta_1=beta1, beta_2=beta2, epsilon=eps
        )
    if opt_name == "Nadam":
        return tf.keras.optimizers.Nadam(
            learning_rate=lr, beta_1=beta1, beta_2=beta2, epsilon=eps
        )
    if opt_name == "RMSProp":
        return tf.keras.optimizers.RMSprop(
            learning_rate=lr,
            rho=rho,
            momentum=momentum,
            epsilon=eps,
            centered=False,
        )
    if opt_name == "SGD":
        return tf.keras.optimizers.SGD(
            learning_rate=lr, momentum=momentum, nesterov=True
        )

    valid_names = [
        "Adadelta",
        "Adagrad",
        "Adam",
        "Adamax",
        "Nadam",
        "RMSProp",
        "SGD",
    ]
    raise ValueError(
        f"Invalid optimizer name: {opt_name}. Valid options are: {', '.join(valid_names)}"
    )