import gym
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from torch.distributions import Categorical, Normal
from collections import deque


def orthogonal_(tensor, gain=1.0):
    flat = tensor.reshape(tensor.size(0), -1)
    a = torch.randn_like(flat)
    u, _, v = torch.svd(a, some=False)
    q = u if u.size(0) == flat.size(0) else v
    flat.copy_(gain * q[:flat.size(0), :flat.size(1)])
    return tensor


def bootstrapped_returns(rewards, dones, gamma, last_value=0.0):
    """Compute discounted returns with bootstrapping."""
    returns = []
    R = last_value
    for r, d in zip(reversed(rewards), reversed(dones)):
        R = r + gamma * R * (1 - d)
        returns.insert(0, R)
    return torch.tensor(returns, dtype=torch.float32, device=returns[0].device)


def gae(rewards, values, dones, gamma, lam):
    """Generalized Advantage Estimation."""
    advantages = []
    gae_ = 0.0
    for t in reversed(range(len(rewards))):
        delta = rewards[t] + gamma * values[t + 1] * (1 - dones[t]) - values[t]
        gae_ = delta + gamma * lam * gae_ * (1 - dones[t])
        advantages.insert(0, gae_)
    return torch.tensor(advantages, dtype=torch.float32, device=values.device)


class FeatureNet(nn.Module):
    def __init__(self, obs_dim, hidden_size, device):
        super().__init__()
        self.lstm = nn.LSTM(input_size=obs_dim,
                            hidden_size=hidden_size,
                            batch_first=True)
        self.hidden_size = hidden_size
        self.device = device
        self.lstm.to(device)

    def forward(self, x, h, c):
        out, (h, c) = self.lstm(x, (h, c))
        return out[:, -1, :], h, c


class CategoricalHead(nn.Module):
    def __init__(self, feature_dim, action_dim):
        super().__init__()
        self.linear = nn.Linear(feature_dim, action_dim)

    def forward(self, features):
        logits = self.linear(features)
        return logits


class DiagGaussianHead(nn.Module):
    def __init__(self, feature_dim, action_dim, std0):
        super().__init__()
        self.mean_linear = nn.Linear(feature_dim, action_dim)
        self.log_std = nn.Parameter(torch.full((action_dim,), np.log(std0)))

    def forward(self, features):
        mean = self.mean_linear(features)
        std = torch.exp(self.log_std)
        return mean, std


class Agent:
    def __init__(self, config, env, device):
        self.config = config
        self.env = env
        self.device = device

        obs_space = env.observation_space
        if hasattr(obs_space, "shape"):
            obs_dim = np.prod(obs_space.shape)
        else:
            raise ValueError("Unsupported observation space")
        self.feature_net = FeatureNet(obs_dim,
                                      config['rnn.size'],
                                      device).to(device)

        if isinstance(env.action_space, gym.spaces.Discrete):
            action_dim = env.action_space.n
            self.action_head = CategoricalHead(config['rnn.size'], action_dim).to(device)
            self.distribution = Categorical
        elif isinstance(env.action_space, gym.spaces.Box):
            action_dim = env.action_space.shape[0]
            self.action_head = DiagGaussianHead(config['rnn.size'],
                                                action_dim,
                                                config['agent.std0']).to(device)
            self.distribution = Normal
        else:
            raise ValueError("Unsupported action space")

        self.value_head = nn.Linear(config['rnn.size'], 1).to(device)
        orthogonal_(self.value_head.weight, np.sqrt(2))
        orthogonal_(self.value_head.bias, 0)

        self.optimizer = optim.Adam(self.parameters(),
                                    lr=config['agent.lr'])
        if config.get('agent.use_lr_scheduler', False):
            self.scheduler = optim.lr_scheduler.LinearLR(self.optimizer,
                                                         start_factor=1.0,
                                                         end_factor=0.0,
                                                         total_iters=config.get('agent.total_iters', 1))
        else:
            self.scheduler = None

        self.reset()

    def parameters(self):
        return list(self.feature_net.parameters()) + \
               list(self.action_head.parameters()) + \
               list(self.value_head.parameters())

    def reset(self, batch_size=1):
        self.h = torch.zeros(1, batch_size, self.config['rnn.size'],
                             device=self.device)
        self.c = torch.zeros(1, batch_size, self.config['rnn.size'],
                             device=self.device)

    def act(self, observation, new_episode=False):
        if new_episode:
            self.reset(batch_size=1)

        obs = torch.tensor(observation, dtype=torch.float32,
                           device=self.device).unsqueeze(0).unsqueeze(0)
        features, self.h, self.c = self.feature_net(obs, self.h, self.c)

        if isinstance(self.env.action_space, gym.spaces.Discrete):
            logits = self.action_head(features)
            action_dist = Categorical(logits=logits)
            action = action_dist.sample()
            action_logprob = action_dist.log_prob(action)
            entropy = action_dist.entropy()
            raw_action = action.item()
            V = self.value_head(features).squeeze(-1)
        else:
            mean, std = self.action_head(features)
            action_dist = Normal(mean, std)
            action = action_dist.sample()
            action_logprob = action_dist.log_prob(action).sum(-1)
            entropy = action_dist.entropy().sum(-1)
            raw_action = action.cpu().numpy().flatten()
            V = self.value_head(features).squeeze(-1)

        return {
            'action_dist': action_dist,
            'V': V,
            'entropy': entropy,
            'action': action,
            'action_logprob': action_logprob,
            'raw_action': raw_action
        }

    def learn(self, D):
        rewards = torch.tensor(D['rewards'], dtype=torch.float32, device=self.device)
        dones = torch.tensor(D['dones'], dtype=torch.float32, device=self.device)
        logprobs = torch.tensor(D['logprobs'], dtype=torch.float32, device=self.device)
        entropies = torch.tensor(D['entropies'], dtype=torch.float32, device=self.device)
        values = torch.tensor(D['values'], dtype=torch.float32, device=self.device)

        last_value = values[-1]
        Qs = bootstrapped_returns(rewards, dones,
                                  self.config['agent.gamma'],
                                  last_value)

        As = gae(rewards, values, dones,
                 self.config['agent.gamma'],
                 self.config['agent.gae_lambda'])

        if self.config.get('agent.standardize_adv', False):
            As = (As - As.mean()) / (As.std() + 1e-8)

        policy_loss = -(logprobs * As.detach()).mean()
        entropy_loss = -entropies.mean()
        value_loss = ((values - Qs) ** 2).mean()

        total_loss = policy_loss + \
                     self.config['agent.value_coef'] * value_loss + \
                     self.config['agent.entropy_coef'] * entropy_loss

        self.optimizer.zero_grad()
        total_loss.backward()
        grad_norm = torch.nn.utils.clip_grad_norm_(self.parameters(),
                                                   self.config['agent.max_grad_norm'])
        self.optimizer.step()
        if self.scheduler:
            self.scheduler.step()

        explained_variance = 1.0 - torch.var(values - Qs).item() / (torch.var(values).item() + 1e-8)

        return {
            'total_loss': total_loss.item(),
            'policy_loss': policy_loss.item(),
            'entropy_loss': entropy_loss.item(),
            'value_loss': value_loss.item(),
            'grad_norm': grad_norm,
            'explained_variance': explained_variance
        }

    def checkpoint(self, num_iter):
        state = {
            'agent_state': self.state_dict(),
            'optimizer_state': self.optimizer.state_dict()
        }
        if hasattr(self.env, 'obs_moments'):
            state['obs_moments'] = self.env.obs_moments
        torch.save(state, f"agent_{num_iter}.pth")

    def state_dict(self):
        return {
            'feature_net': self.feature_net.state_dict(),
            'action_head': self.action_head.state_dict(),
            'value_head': self.value_head.state_dict()
        }

    def load_state_dict(self, state_dict):
        self.feature_net.load_state_dict(state_dict['feature_net'])
        self.action_head.load_state_dict(state_dict['action_head'])
        self.value_head.load_state_dict(state_dict['value_head'])


# Example usage (requires a compatible environment and config):
# env = gym.make('CartPole-v1')
# config = {
#     'rnn.size': 128,
#     'agent': {
#         'std0': 0.5,
#         'lr': 3e-4,
#         'gamma': 0.99,
#         'gae_lambda': 0.95,
#         'value_coef': 0.5,
#         'entropy_coef': 0.01,
#         'max_grad_norm': 0.5,
#         'use_lr_scheduler': False,
#         'standardize_adv': True
#     }
# }
# device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
# agent = Agent(config, env, device)
# obs = env.reset()
# action_info = agent.act(obs)
# next_obs, reward, done, _ = env.step(action_info['raw_action'])
# ...
```