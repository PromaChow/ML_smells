import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.utils.rnn import PackedSequence, rnn_utils


class LayerNormLSTMCell(nn.Module):
    def __init__(self, input_size: int, hidden_size: int):
        super().__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        # Weight matrices
        self.weight_ih = nn.Parameter(torch.Tensor(4 * hidden_size, input_size))
        self.weight_hh = nn.Parameter(torch.Tensor(4 * hidden_size, hidden_size))
        # LayerNorm layers
        self.layernorm_i = nn.LayerNorm(4 * hidden_size)
        self.layernorm_h = nn.LayerNorm(4 * hidden_size)
        self.layernorm_c = nn.LayerNorm(hidden_size)
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1.0 / (self.hidden_size ** 0.5)
        for w in self.parameters():
            nn.init.uniform_(w, -stdv, stdv)

    def forward(self, x: torch.Tensor, h: torch.Tensor, c: torch.Tensor):
        # Linear transformations
        i = self.layernorm_i(F.linear(x, self.weight_ih))
        h_l = self.layernorm_h(F.linear(h, self.weight_hh))
        gates = i + h_l
        ingate, forgetgate, cellgate, outgate = gates.chunk(4, 1)
        ingate = torch.sigmoid(ingate)
        forgetgate = torch.sigmoid(forgetgate)
        cellgate = torch.tanh(cellgate)
        outgate = torch.sigmoid(outgate)
        c_next = forgetgate * c + ingate * cellgate
        c_norm = self.layernorm_c(c_next)
        h_next = outgate * torch.tanh(c_norm)
        return h_next, c_next


class LSTMLayer(nn.Module):
    def __init__(self, input_size: int, hidden_size: int):
        super().__init__()
        self.hidden_size = hidden_size
        self.cell = LayerNormLSTMCell(input_size, hidden_size)

    def forward_packed(self, packed_input: PackedSequence):
        batch_sizes = packed_input.batch_sizes
        max_batch_size = batch_sizes[0]
        device = packed_input.data.device
        dtype = packed_input.data.dtype

        h = torch.zeros(max_batch_size, self.hidden_size, device=device, dtype=dtype)
        c = torch.zeros(max_batch_size, self.hidden_size, device=device, dtype=dtype)

        outputs = []
        offset = 0
        for batch_size_t in batch_sizes:
            x_t = packed_input.data[offset : offset + batch_size_t]
            h_t, c_t = self.cell(x_t, h[:batch_size_t], c[:batch_size_t])
            h[:batch_size_t] = h_t
            c[:batch_size_t] = c_t
            outputs.append(h_t)
            offset += batch_size_t

        output_data = torch.cat(outputs, dim=0)
        packed_output = PackedSequence(output_data, batch_sizes,
                                       sorted_indices=packed_input.sorted_indices,
                                       unsorted_indices=packed_input.unsorted_indices)

        # Reorder states if unsorted indices are provided
        if packed_input.unsorted_indices is not None:
            h = h[packed_input.unsorted_indices]
            c = c[packed_input.unsorted_indices]

        return packed_output, (h, c)

    def forward_tensor(self, input: torch.Tensor):
        seq_len, batch_size, _ = input.size()
        device = input.device
        dtype = input.dtype

        h = torch.zeros(batch_size, self.hidden_size, device=device, dtype=dtype)
        c = torch.zeros(batch_size, self.hidden_size, device=device, dtype=dtype)

        outputs = []
        for t in range(seq_len):
            x_t = input[t]
            h, c = self.cell(x_t, h, c)
            outputs.append(h.unsqueeze(0))
        output = torch.cat(outputs, dim=0)
        return output, (h, c)

    def forward(self, input):
        if isinstance(input, PackedSequence):
            return self.forward_packed(input)
        else:
            return self.forward_tensor(input)


class StackedLSTM(nn.Module):
    def __init__(self, layers: list[nn.Module]):
        super().__init__()
        self.layers = nn.ModuleList(layers)

    def forward_packed(self, packed_input: PackedSequence):
        states = []
        output = packed_input
        for layer in self.layers:
            output, state = layer.forward_packed(output)
            states.append(state)
        return output, states

    def forward_tensor(self, input: torch.Tensor):
        states = []
        output = input
        for layer in self.layers:
            output, state = layer.forward_tensor(output)
            states.append(state)
        return output, states

    def forward(self, input):
        if isinstance(input, PackedSequence):
            return self.forward_packed(input)
        else:
            return self.forward_tensor(input)


def make_lnlstm(input_size: int, hidden_size: int, num_layers: int) -> StackedLSTM:
    layers = []
    for i in range(num_layers):
        if i == 0:
            layers.append(LSTMLayer(input_size, hidden_size))
        else:
            layers.append(LSTMLayer(hidden_size, hidden_size))
    return StackedLSTM(layers)