import tkinter as tk
from tkinter import PhotoImage
from PIL import Image, ImageTk

class Environment(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Grid Navigation Environment")
        self.pixels = 20
        self.size = 25
        self.width = self.size * self.pixels
        self.height = self.size * self.pixels
        self.geometry(f"{self.width}x{self.height}")
        self.resizable(False, False)

        self.canvas = tk.Canvas(self, width=self.width, height=self.height)
        self.canvas.pack()

        # Background image
        try:
            bg = Image.open("bg.png")
            bg = bg.resize((self.width, self.height), Image.ANTIALIAS)
            self.bg_image = ImageTk.PhotoImage(bg)
            self.canvas.create_image(0, 0, anchor="nw", image=self.bg_image)
        except Exception:
            self.canvas.create_rectangle(0, 0, self.width, self.height, fill="white")

        # Grid lines
        for i in range(0, self.width + 1, self.pixels):
            self.canvas.create_line(i, 0, i, self.height, fill="#cccccc")
        for j in range(0, self.height + 1, self.pixels):
            self.canvas.create_line(0, j, self.width, j, fill="#cccccc")

        # Obstacles
        self.o = [10, 10]
        self.obstacle_coords = []
        self.obstacle_ids = []

        # Predefined obstacle offsets (50 obstacles)
        offsets = [
            (2, 3), (4, 5), (6, 7), (8, 9), (10, 11), (12, 13), (14, 15), (16, 17), (18, 19), (20, 21),
            (22, 23), (1, 2), (3, 4), (5, 6), (7, 8), (9, 10), (11, 12), (13, 14), (15, 16), (17, 18),
            (19, 20), (21, 22), (23, 0), (0, 1), (2, 4), (3, 5), (4, 6), (5, 7), (6, 8), (7, 9),
            (8, 10), (9, 11), (10, 12), (11, 13), (12, 14), (13, 15), (14, 16), (15, 17), (16, 18),
            (17, 19), (18, 20), (19, 21), (20, 22), (21, 23), (22, 24), (23, 0), (24, 1), (0, 0),
            (1, 1), (2, 2)
        ]

        for idx, (ci, cj) in enumerate(offsets[:50]):
            cx = self.o[0] + ci * self.pixels
            cy = self.o[1] + cj * self.pixels
            x1 = cx - self.pixels // 2
            y1 = cy - self.pixels // 2
            x2 = cx + self.pixels // 2
            y2 = cy + self.pixels // 2
            rect_id = self.canvas.create_rectangle(x1, y1, x2, y2, fill="black")
            self.obstacle_ids.append(rect_id)
            self.obstacle_coords.append((x1, y1, x2, y2))

        # Goal
        goal_i, goal_j = 20, 20
        self.goal_center = (self.o[0] + goal_i * self.pixels, self.o[1] + goal_j * self.pixels)
        gx1 = self.goal_center[0] - self.pixels // 2
        gy1 = self.goal_center[1] - self.pixels // 2
        gx2 = self.goal_center[0] + self.pixels // 2
        gy2 = self.goal_center[1] + self.pixels // 2
        self.goal_id = self.canvas.create_rectangle(gx1, gy1, gx2, gy2, fill="yellow")

        # Agent
        self.agent_radius = 8
        self.agent_start = (self.o[0] + 12 * self.pixels, self.o[1] + 12 * self.pixels)
        ax1 = self.agent_start[0] - self.agent_radius
        ay1 = self.agent_start[1] - self.agent_radius
        ax2 = self.agent_start[0] + self.agent_radius
        ay2 = self.agent_start[1] + self.agent_radius
        self.agent_id = self.canvas.create_oval(ax1, ay1, ax2, ay2, fill="red")

        # Tracking
        self.step_count = 0
        self.path = []
        self.shortest_path = None
        self.longest_path = None
        self.d = {}
        self.f = []

    def reset(self):
        self.step_count = 0
        self.path = []
        self.d.clear()
        self.f.clear()
        self.canvas.coords(self.agent_id,
                           self.agent_start[0] - self.agent_radius,
                           self.agent_start[1] - self.agent_radius,
                           self.agent_start[0] + self.agent_radius,
                           self.agent_start[1] + self.agent_radius)
        return self.agent_start

    def step(self, action):
        x, y = self.path[-1] if self.path else self.agent_start
        if action == "up":
            y -= self.pixels
        elif action == "down":
            y += self.pixels
        elif action == "left":
            x -= self.pixels
        elif action == "right":
            x += self.pixels

        # Boundary check
        if x < self.pixels // 2 or x > self.width - self.pixels // 2 or \
           y < self.pixels // 2 or y > self.height - self.pixels // 2:
            x, y = self.path[-1] if self.path else self.agent_start

        self.path.append((x, y))
        self.d[self.step_count] = (x, y)
        self.step_count += 1

        reward = 0
        done = False

        # Collision with obstacles
        for ox1, oy1, ox2, oy2 in self.obstacle_coords:
            if ox1 <= x <= ox2 and oy1 <= y <= oy2:
                reward = -1
                done = True
                break

        # Reached goal
        if not done:
            gx1 = self.goal_center[0] - self.pixels // 2
            gy1 = self.goal_center[1] - self.pixels // 2
            gx2 = self.goal_center[0] + self.pixels // 2
            gy2 = self.goal_center[1] + self.pixels // 2
            if gx1 <= x <= gx2 and gy1 <= y <= gy2:
                reward = 1
                done = True

        self.render()
        info = {}
        return (x, y), reward, done, info

    def render(self):
        if self.path:
            x, y = self.path[-1]
            self.canvas.coords(self.agent_id,
                               x - self.agent_radius,
                               y - self.agent_radius,
                               x + self.agent_radius,
                               y + self.agent_radius)
        self.update_idletasks()

    def final(self):
        if not self.f:
            return
        for pos in self.f:
            x, y = pos
            r = 3
            self.canvas.create_oval(x - r, y - r, x + r, y + r, fill="blue")

    def store_final_path(self):
        global a
        a = {"final_path": self.f}

def main():
    env = Environment()
    env.mainloop()

if __name__ == "__main__":
    main()