import inspect
import sys
import importlib
import types
from typing import Any, Iterable, Tuple, Union, Callable

import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim.lr_scheduler import _LRScheduler

__all__ = [
    "soft_update",
    "hard_update",
    "determine_device",
    "safe_call",
    "safe_import",
    "get_globals_from_stack",
    "assert_output_is_probs",
    "assert_and_get_valid_models",
    "assert_and_get_valid_optimizer",
    "assert_and_get_valid_lr_scheduler",
    "assert_and_get_valid_criterion",
    "FakeOptimizer",
]


def soft_update(target_net: nn.Module, source_net: nn.Module, update_rate: float) -> None:
    """Gradually updates target_net parameters towards source_net."""
    for target_param, source_param in zip(target_net.parameters(), source_net.parameters()):
        target_param.data.copy_(
            (1.0 - update_rate) * target_param.data + update_rate * source_param.data
        )


def hard_update(target_net: nn.Module, source_net: nn.Module) -> None:
    """Copies source_net parameters to target_net."""
    for target_param, source_param in zip(target_net.parameters(), source_net.parameters()):
        target_param.data.copy_(source_param.data)


def determine_device(model: nn.Module) -> torch.device:
    """Returns the single device that all parameters of a model reside on."""
    devices = {p.device for p in model.parameters()}
    if len(devices) != 1:
        raise RuntimeError(
            f"Model parameters are on multiple devices: {devices}. "
            "Please ensure all parameters are on the same device."
        )
    return next(iter(devices))


def _move_to_device(obj: Any, device: torch.device) -> Any:
    if isinstance(obj, torch.Tensor):
        return obj.to(device)
    if isinstance(obj, (list, tuple)):
        return type(obj)(_move_to_device(o, device) for o in obj)
    if isinstance(obj, dict):
        return {k: _move_to_device(v, device) for k, v in obj.items()}
    return obj


def safe_call(
    model: nn.Module,
    *args,
    method: str = "__call__",
    **kwargs,
) -> Tuple[Any, ...]:
    """Calls a model method ensuring all inputs are on the model's device."""
    device = determine_device(model)
    args = tuple(_move_to_device(a, device) for a in args)
    kwargs = {k: _move_to_device(v, device) for k, v in kwargs.items()}

    target = getattr(model, method)
    output = target(*args, **kwargs)

    if not isinstance(output, (tuple, list)):
        output = (output,)
    return tuple(output)


def safe_import(name: str) -> Any:
    """Imports a module or attribute from a dotted path."""
    parts = name.split(".")
    for i in range(len(parts), 0, -1):
        module_name = ".".join(parts[:i])
        attr_name = ".".join(parts[i:])
        try:
            module = importlib.import_module(module_name)
            if attr_name:
                return getattr(module, attr_name)
            return module
        except (ImportError, AttributeError):
            continue
    raise ImportError(f"Could not import '{name}'.")


def get_globals_from_stack() -> dict:
    """Aggregates globals from the current call stack."""
    globals_dict = {}
    for frame_record in inspect.stack():
        globals_dict.update(frame_record.frame.f_globals)
    return globals_dict


def assert_output_is_probs(tensor: torch.Tensor) -> None:
    """Asserts tensor is a valid probability distribution."""
    if not torch.is_tensor(tensor):
        raise TypeError("Output is not a torch.Tensor.")
    if tensor.ndim != 2:
        raise ValueError(f"Tensor must be 2D, got shape {tensor.shape}.")
    if (tensor < 0).any():
        raise ValueError("Tensor contains negative values.")
    row_sums = tensor.sum(dim=1)
    if not torch.allclose(row_sums, torch.ones_like(row_sums), atol=1e-6):
        raise ValueError("Rows do not sum to 1.")


def _validate_importable(cls_path: str, base_cls: type) -> type:
    cls = safe_import(cls_path)
    if not issubclass(cls, base_cls):
        raise TypeError(f"{cls_path} is not a subclass of {base_cls.__name__}.")
    return cls


def assert_and_get_valid_models(models: Union[Iterable[Any], Any]) -> Iterable[type]:
    """Returns an iterable of nn.Module subclasses."""
    if not isinstance(models, Iterable) or isinstance(models, (str, bytes)):
        models = [models]
    validated = []
    for m in models:
        if isinstance(m, type) and issubclass(m, nn.Module):
            validated.append(m)
        elif isinstance(m, str):
            cls = safe_import(m)
            if not issubclass(cls, nn.Module):
                raise TypeError(f"Imported {m} is not an nn.Module subclass.")
            validated.append(cls)
        else:
            raise TypeError(f"Model {m} is not a valid type.")
    return validated


def assert_and_get_valid_optimizer(optimizer: Union[type, str, optim.Optimizer]) -> type:
    if isinstance(optimizer, type) and issubclass(optimizer, optim.Optimizer):
        return optimizer
    if isinstance(optimizer, str):
        return _validate_importable(optimizer, optim.Optimizer)
    if isinstance(optimizer, optim.Optimizer):
        return type(optimizer)
    raise TypeError("Invalid optimizer type.")


def assert_and_get_valid_lr_scheduler(lr_scheduler: Union[type, str, _LRScheduler]) -> type:
    if isinstance(lr_scheduler, type) and issubclass(lr_scheduler, _LRScheduler):
        return lr_scheduler
    if isinstance(lr_scheduler, str):
        return _validate_importable(lr_scheduler, _LRScheduler)
    if isinstance(lr_scheduler, _LRScheduler):
        return type(lr_scheduler)
    raise TypeError("Invalid LR scheduler type.")


def assert_and_get_valid_criterion(criterion: Union[type, Callable[..., Any], nn.Module]) -> Callable[..., Any]:
    if isinstance(criterion, type) and issubclass(criterion, nn.Module):
        return criterion
    if callable(criterion):
        return criterion
    if isinstance(criterion, nn.Module):
        return type(criterion)
    raise TypeError("Invalid criterion.")


class FakeOptimizer(optim.Optimizer):
    """A no-op optimizer that does nothing on step."""

    def __init__(self, params, defaults=None):
        super().__init__(params, defaults or {})

    def step(self, closure: Callable[[], float] | None = None) -> None:
        pass

    def zero_grad(self, set_to_none: bool = False) -> None:
        for p in self.param_groups[0]["params"]:
            if p.grad is not None:
                p.grad.zero_()
        if set_to_none:
            for p in self.param_groups[0]["params"]:
                p.grad = None
    