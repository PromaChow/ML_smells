import numpy as np

class MultiArmedBandit:
    """
    Simple bandit with independent reward distributions per context and arm.
    Rewards are drawn from a normal distribution centered at a true mean.
    """
    def __init__(self, num_contexts: int, num_arms: int, reward_means: np.ndarray | None = None):
        self.num_contexts = num_contexts
        self.num_arms = num_arms
        if reward_means is None:
            # Random true means in [0, 1]
            self.reward_means = np.random.rand(num_contexts, num_arms)
        else:
            self.reward_means = reward_means

    def get_reward(self, context: int, action: int) -> float:
        """
        Draw a reward from the distribution for the given context and action.
        """
        mean = self.reward_means[context, action]
        # Standard deviation 0.1 for noise
        return np.random.normal(mean, 0.1)


class UCBAgent:
    """
    Multi-armed bandit solver using Upper Confidence Bound (UCB) strategy.
    """
    def __init__(self, bandit: MultiArmedBandit, c: float = 2.0):
        self.bandit = bandit
        self.c = c

        # Estimated action values and selection counts
        self.quality = np.zeros((bandit.num_contexts, bandit.num_arms))
        self.counts = np.zeros((bandit.num_contexts, bandit.num_arms), dtype=int)

        # Global step counter
        self.t = 0

        # Histories
        self.action_history = []   # List of tuples (context, action)
        self.reward_history = []   # List of rewards
        self.regret_history = []   # List of regrets

    def select_action(self, context: int) -> int:
        """
        Select an action for the given context using the UCB formula.
        """
        self.t += 1
        exploration = self.c * np.sqrt(
            2 * np.log(self.t + 1) / (self.counts[context] + 1)
        )
        ucb_values = self.quality[context] + exploration
        action = int(np.argmax(ucb_values))
        self.action_history.append((context, action))
        return action

    def update(self, context: int, action: int, reward: float) -> None:
        """
        Update internal estimates after receiving a reward.
        """
        self.reward_history.append(reward)

        # Regret: difference between best estimated value and selected action's value
        best_estimated = np.max(self.quality[context])
        regret = best_estimated - self.quality[context, action]
        self.regret_history.append(regret)

        # Incremental update of the estimated quality
        self.quality[context, action] += (
            reward - self.quality[context, action]
        ) / (self.counts[context, action] + 1)

        # Increment count for the selected action
        self.counts[context, action] += 1

    def run(self, steps_per_context: dict[int, int] | None = None) -> None:
        """
        Run the agent for a specified number of steps per context.
        """
        if steps_per_context is None:
            steps_per_context = {c: 100 for c in range(self.bandit.num_contexts)}

        for context, steps in steps_per_context.items():
            for _ in range(steps):
                action = self.select_action(context)
                reward = self.bandit.get_reward(context, action)
                self.update(context, action, reward)


# Example usage
if __name__ == "__main__":
    num_contexts = 3
    num_arms = 5
    bandit = MultiArmedBandit(num_contexts, num_arms)
    agent = UCBAgent(bandit, c=2.0)
    agent.run(steps_per_context={c: 200 for c in range(num_contexts)})

    # Access histories
    print("Action history length:", len(agent.action_history))
    print("Reward history length:", len(agent.reward_history))
    print("Regret history length:", len(agent.regret_history))
    print("Final quality estimates:\n", agent.quality)