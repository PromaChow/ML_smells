import random
from typing import List, Tuple, Set, Dict, Optional

# Basic stone colors and empty
EMPTY = 0
BLACK = 1
WHITE = 2

# Helper to flip color
def opposite(color: int) -> int:
    return BLACK if color == WHITE else WHITE

class GameState:
    def __init__(self, size: int = 9, komi: float = 6.5):
        self.size: int = size
        self.komi: float = komi
        self.board: List[List[int]] = [[EMPTY for _ in range(size)] for _ in range(size)]
        self.current_player: int = BLACK
        self.pass_count: int = 0
        self.is_end: bool = False
        self.prisoners: Dict[int, int] = {BLACK: 0, WHITE: 0}
        # Group management
        self.group_map: Dict[Tuple[int, int], int] = {}
        self.groups: Dict[int, Dict] = {}
        self.next_group_id: int = 1
        # Neighbors cache
        self.neighbors_cache: List[List[List[Tuple[int, int]]]] = self._build_neighbors_cache()
        # Zobrist hashing
        self.zobrist_table: List[List[List[int]]] = self._init_zobrist()
        self.current_hash: int = self._compute_hash()
        self.previous_hashes: Set[int] = {self.current_hash}

    def _build_neighbors_cache(self) -> List[List[List[Tuple[int, int]]]]:
        cache: List[List[List[Tuple[int, int]]]] = [[[] for _ in range(self.size)] for _ in range(self.size)]
        for y in range(self.size):
            for x in range(self.size):
                neighbors: List[Tuple[int, int]] = []
                if x > 0:
                    neighbors.append((x - 1, y))
                if x < self.size - 1:
                    neighbors.append((x + 1, y))
                if y > 0:
                    neighbors.append((x, y - 1))
                if y < self.size - 1:
                    neighbors.append((x, y + 1))
                cache[y][x] = neighbors
        return cache

    def _init_zobrist(self) -> List[List[List[int]]]:
        zobrist: List[List[List[int]]] = [[[random.getrandbits(64) for _ in range(3)] for _ in range(self.size)] for _ in range(self.size)]
        return zobrist

    def _compute_hash(self) -> int:
        h: int = 0
        for y in range(self.size):
            for x in range(self.size):
                stone = self.board[y][x]
                if stone != EMPTY:
                    h ^= self.zobrist_table[y][x][stone]
        return h

    def get_neighbors(self, pos: Tuple[int, int]) -> List[Tuple[int, int]]:
        x, y = pos
        return self.neighbors_cache[y][x]

    def get_group(self, pos: Tuple[int, int]) -> Set[Tuple[int, int]]:
        if pos not in self.group_map:
            return set()
        group_id = self.group_map[pos]
        return self.groups[group_id]["stones"]

    def get_groups_around(self, pos: Tuple[int, int]) -> Set[int]:
        neighbor_groups: Set[int] = set()
        for n in self.get_neighbors(pos):
            if n in self.group_map:
                neighbor_groups.add(self.group_map[n])
        return neighbor_groups

    def _update_neighbors(self, pos: Tuple[int, int]):
        x, y = pos
        color = self.board[y][x]
        # Create new group
        new_group_id = self.next_group_id
        self.next_group_id += 1
        new_group = {
            "color": color,
            "stones": {pos},
            "liberties": set(),
        }
        # Initial liberties are empty neighbors
        for n in self.get_neighbors(pos):
            nx, ny = n
            if self.board[ny][nx] == EMPTY:
                new_group["liberties"].add(n)
        self.groups[new_group_id] = new_group
        self.group_map[pos] = new_group_id

        # Merge with same-color neighbors
        neighbors = self.get_neighbors(pos)
        for n in neighbors:
            if self.board[n[1]][n[0]] == color and n in self.group_map:
                other_id = self.group_map[n]
                if other_id == new_group_id:
                    continue
                # Merge groups
                other_group = self.groups[other_id]
                # Combine stones
                for s in other_group["stones"]:
                    self.group_map[s] = new_group_id
                new_group["stones"].update(other_group["stones"])
                # Combine liberties, remove self
                new_group["liberties"].update(other_group["liberties"])
                if pos in new_group["liberties"]:
                    new_group["liberties"].discard(pos)
                # Remove old group
                del self.groups[other_id]

        # Update liberties of adjacent opponent groups
        for n in neighbors:
            nx, ny = n
            if self.board[ny][nx] == opposite(color) and n in self.group_map:
                opp_id = self.group_map[n]
                opp_group = self.groups[opp_id]
                if pos in opp_group["liberties"]:
                    opp_group["liberties"].discard(pos)

        # Capture any opponent group with no liberties
        for n in neighbors:
            nx, ny = n
            if self.board[ny][nx] == opposite(color) and n in self.group_map:
                opp_id = self.group_map[n]
                opp_group = self.groups[opp_id]
                if not opp_group["liberties"]:
                    self._remove_group(opp_id)

    def _remove_group(self, group_id: int):
        group = self.groups[group_id]
        color = group["color"]
        for s in group["stones"]:
            x, y = s
            self.board[y][x] = EMPTY
            del self.group_map[s]
        # Update liberties of adjacent groups
        for s in group["stones"]:
            for n in self.get_neighbors(s):
                if n in self.group_map:
                    other_id = self.group_map[n]
                    if other_id != group_id:
                        self.groups[other_id]["liberties"].add(s)
        self.prisoners[opposite(color)] += len(group["stones"])
        del self.groups[group_id]

    def is_legal(self, pos: Tuple[int, int]) -> bool:
        if pos is None:
            return True
        x, y = pos
        if self.board[y][x] != EMPTY:
            return False
        # Temporarily place stone
        original = self.board[y][x]
        self.board[y][x] = self.current_player
        temp_hash = self.current_hash ^ self.zobrist_table[y][x][self.current_player]
        # Update groups temporarily
        temp_group_map = self.group_map.copy()
        temp_groups = {k: v.copy() for k, v in self.groups.items()}
        temp_next_group_id = self.next_group_id
        self._update_neighbors(pos)
        # Check suicide
        group_id = self.group_map[pos]
        if not self.groups[group_id]["liberties"]:
            legal = False
        else:
            legal = temp_hash not in self.previous_hashes
        # Restore state
        self.board[y][x] = original
        self.group_map = temp_group_map
        self.groups = temp_groups
        self.next_group_id = temp_next_group_id
        self.current_hash = temp_hash ^ self.zobrist_table[y][x][self.current_player]
        return legal

    def get_legal_moves(self) -> List[Tuple[int, int]]:
        moves: List[Tuple[int, int]] = []
        for y in range(self.size):
            for x in range(self.size):
                if self.is_legal((x, y)):
                    moves.append((x, y))
        return moves

    def is_eye(self, pos: Tuple[int, int]) -> bool:
        if self.board[pos[1]][pos[0]] != EMPTY:
            return False
        color = self.current_player
        neighbors = self.get_neighbors(pos)
        for n in neighbors:
            nx, ny = n
            if self.board[ny][nx] != color:
                return False
        return True

    def do_move(self, pos: Optional[Tuple[int, int]]):
        if self.is_end:
            raise ValueError("Game has ended")
        if pos is None:
            self.pass_count += 1
            if self.pass_count >= 2:
                self.is_end = True
            else:
                self.current_player = opposite(self.current_player)
            return
        if not self.is_legal(pos):
            raise ValueError("Illegal move")
        x, y = pos
        self.board[y][x] = self.current_player
        self.current_hash ^= self.zobrist_table[y][x][self.current_player]
        self._update_neighbors(pos)
        self.previous_hashes.add(self.current_hash)
        self.pass_count = 0
        self.current_player = opposite(self.current_player)

    def get_winner(self) -> Tuple[int, float]:
        black_score = 0
        white_score = self.komi
        visited_eyes: Set[Tuple[int, int]] = set()
        for y in range(self.size):
            for x in range(self.size):
                stone = self.board[y][x]
                if stone == BLACK:
                    black_score += 1
                elif stone == WHITE:
                    white_score += 1
        # Count eyes
        for y in range(self.size):
            for x in range(self.size):
                if self.board[y][x] != EMPTY:
                    continue
                if (x, y) in visited_eyes:
                    continue
                if self.is_eye((x, y)):
                    # Determine surrounding color
                    neighbors = self.get_neighbors((x, y))
                    colors = set(self.board[ny][nx] for nx, ny in neighbors)
                    if len(colors) == 1 and next(iter(colors)) == BLACK:
                        black_score += 1
                        visited_eyes.add((x, y))
                    elif len(colors) == 1 and next(iter(colors)) == WHITE:
                        white_score += 1
                        visited_eyes.add((x, y))
        winner = BLACK if black_score > white_score else WHITE
        return winner, black_score - white_score

    def is_end_of_game(self) -> bool:
        return self.is_end

    def __str__(self):
        lines: List[str] = []
        for y in range(self.size):
            line = ""
            for x in range(self.size):
                stone = self.board[y][x]
                if stone == EMPTY:
                    line += ". "
                elif stone == BLACK:
                    line += "X "
                else:
                    line += "O "
            lines.append(line.strip())
        return "\n".join(lines) + f"\nCurrent player: {'BLACK' if self.current_player == BLACK else 'WHITE'}"

# Example usage:
# gs = GameState(size=9)
# gs.do_move((2, 2))
# gs.do_move((3, 2))
# print(gs)
# print(gs.get_winner())
# print(gs.is_end_of_game())
