import random
import torch
import torch.nn.functional as F


class Pad:
    def __init__(self, pad_length, mode='constant', value=0, pad_position='center'):
        self.pad_length = pad_length
        self.mode = mode
        self.value = value
        self.pad_position = pad_position

    def __call__(self, wav):
        current_len = wav.shape[1]
        delta = self.pad_length - current_len
        if delta <= 0:
            return wav
        if self.pad_position == 'center':
            left = delta // 2
            right = delta - left
        elif self.pad_position == 'right':
            left = 0
            right = delta
        elif self.pad_position == 'left':
            left = delta
            right = 0
        elif self.pad_position == 'random':
            left = int(delta * random.random())
            right = delta - left
        else:
            raise ValueError(f"Invalid pad_position: {self.pad_position}")
        padded = F.pad(wav, (left, right), mode=self.mode, value=self.value)
        return padded


class Crop:
    def __init__(self, crop_length, crop_position='center'):
        self.crop_length = crop_length
        self.crop_position = crop_position

    def __call__(self, wav):
        current_len = wav.shape[1]
        delta = current_len - self.crop_length
        if delta <= 0:
            return wav
        if self.crop_position == 'center':
            start = delta // 2
        elif self.crop_position == 'left':
            start = 0
        elif self.crop_position == 'right':
            start = delta
        elif self.crop_position == 'random':
            start = random.randint(0, delta)
        else:
            raise ValueError(f"Invalid crop_position: {self.crop_position}")
        cropped = wav[:, start:start + self.crop_length]
        return cropped


class PadCrop:
    def __init__(
        self,
        pad_crop_length,
        crop_position='center',
        pad_mode='constant',
        pad_value=0,
        pad_position='center',
    ):
        self.pad_crop_length = pad_crop_length
        self.crop_transform = Crop(crop_length=pad_crop_length, crop_position=crop_position)
        self.pad_transform = Pad(
            pad_length=pad_crop_length,
            mode=pad_mode,
            value=pad_value,
            pad_position=pad_position,
        )

    def __call__(self, wav):
        current_len = wav.shape[1]
        delta = current_len - self.pad_crop_length
        if delta > 0:
            return self.crop_transform(wav)
        elif delta < 0:
            return self.pad_transform(wav)
        else:
            return wav
