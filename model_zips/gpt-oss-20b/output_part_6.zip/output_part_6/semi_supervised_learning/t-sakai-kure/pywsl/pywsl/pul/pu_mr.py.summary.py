import numpy as np
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.model_selection import KFold
from numpy.linalg import solve

class PU_SL(BaseEstimator, ClassifierMixin):
    def __init__(self, prior=0.5, sigma=1.0, lam=1e-3, basis='gauss', n_basis=100):
        self.prior = prior
        self.sigma = sigma
        self.lam = lam
        self.basis = basis
        self.n_basis = n_basis

    def _ker(self, X1, X2):
        if self.basis == 'gauss':
            d2 = np.sum((X1[:, None, :] - X2[None, :, :]) ** 2, axis=2)
            return np.exp(-d2 / (2 * self.sigma ** 2))
        else:  # linear
            return np.dot(X1, X2.T)

    def fit(self, X, y):
        X = np.asarray(X)
        y = np.asarray(y)
        pos_mask = y == 1
        unl_mask = y == 0
        X_p = X[pos_mask]
        X_u = X[unl_mask]
        if self.basis == 'gauss':
            idx = np.random.choice(len(X_u), size=self.n_basis, replace=False)
            self.centers_ = X_u[idx]
        else:
            self.centers_ = X_u  # use all unlabeled as basis
        k_p = self._ker(X_p, self.centers_)
        k_u = self._ker(X_u, self.centers_)
        H = (k_u.T @ k_u) / len(X_u)
        h = k_p.mean(axis=0) - self.prior * k_u.mean(axis=0)
        self.coef_ = solve(H + self.lam * np.eye(H.shape[0]), h)
        return self

    def decision_function(self, X):
        X = np.asarray(X)
        K = self._ker(X, self.centers_)
        return K @ self.coef_

    def predict(self, X):
        scores = self.decision_function(X)
        return np.sign(scores)

    def score(self, X, y):
        X = np.asarray(X)
        y = np.asarray(y)
        pos_mask = y == 1
        unl_mask = y == 0
        X_p = X[pos_mask]
        X_u = X[unl_mask]
        scores_p = self.decision_function(X_p)
        scores_u = self.decision_function(X_u)
        fn = np.mean(scores_p < 0)
        fp = np.mean(scores_u > 0)
        risk = self.prior * fn + max(fp + self.prior * fn - self.prior, 0)
        return 1.0 - risk

def calc_risk(gp, gu, prior):
    fn = np.mean(gp < 0)
    fp = np.mean(gu > 0)
    risk = prior * fn + max(fp + prior * fn - prior, 0)
    return 1.0 - risk

def ker(d, sigma, model):
    if model == 'gauss':
        return np.exp(-d ** 2 / (2 * sigma ** 2))
    else:
        return d

def make_func(w, x_c, sigma, model, x_t):
    if model == 'gauss':
        d2 = np.sum((x_t[:, None, :] - x_c[None, :, :]) ** 2, axis=2)
        K = np.exp(-d2 / (2 * sigma ** 2))
    else:
        K = np.dot(x_t, x_c.T)
    return K @ w

def pu_sl(x_p, x_u, prior=0.5, n_fold=5, basis='gauss', sigma_list=None, lambda_list=None):
    if sigma_list is None:
        sigma_list = [0.1, 0.5, 1.0, 5.0]
    if lambda_list is None:
        lambda_list = [1e-4, 1e-3, 1e-2, 1e-1]
    best_score = -np.inf
    best_params = {}
    X = np.vstack((x_p, x_u))
    y = np.hstack((np.ones(len(x_p)), np.zeros(len(x_u))))
    kf = KFold(n_splits=n_fold, shuffle=True, random_state=42)
    for sigma in sigma_list:
        for lam in lambda_list:
            scores = []
            for train_idx, test_idx in kf.split(X):
                X_tr, X_te = X[train_idx], X[test_idx]
                y_tr, y_te = y[train_idx], y[test_idx]
                model = PU_SL(prior=prior, sigma=sigma, lam=lam, basis=basis, n_basis=min(100, len(x_u)))
                model.fit(X_tr, y_tr)
                y_pred = model.decision_function(X_te)
                pos_mask = y_te == 1
                unl_mask = y_te == 0
                gp = y_pred[pos_mask]
                gu = y_pred[unl_mask]
                scores.append(calc_risk(gp, gu, prior))
            mean_score = np.mean(scores)
            if mean_score > best_score:
                best_score = mean_score
                best_params = {'sigma': sigma, 'lam': lam}
    # Train final model with best parameters
    final_model = PU_SL(prior=prior,
                       sigma=best_params['sigma'],
                       lam=best_params['lam'],
                       basis=basis,
                       n_basis=min(100, len(x_u)))
    final_model.fit(np.vstack((x_p, x_u)), np.hstack((np.ones(len(x_p)), np.zeros(len(x_u))))
    return final_model, best_params, best_score

if __name__ == "__main__":
    # Example usage
    rng = np.random.default_rng(0)
    x_pos = rng.normal(size=(50, 2))
    x_unl = rng.normal(scale=1.5, size=(200, 2))
    model, params, score = pu_sl(x_pos, x_unl, prior=0.3)
    print("Best params:", params)
    print("Cross-validated score:", score)