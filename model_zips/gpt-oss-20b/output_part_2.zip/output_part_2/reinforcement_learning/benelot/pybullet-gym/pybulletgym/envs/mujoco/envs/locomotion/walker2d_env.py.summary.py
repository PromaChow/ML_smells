import numpy as np
from walker_base_mujoco_env import WalkerBaseMuJoCoEnv
from walker2d import Walker2D

class Walker2DMuJoCoEnv(WalkerBaseMuJoCoEnv):
    debugmode = 0

    def __init__(self, *args, **kwargs):
        self.robot = Walker2D()
        WalkerBaseMuJoCoEnv.__init__(self, self.robot)
        self.reward = 0.0
        self.rewards = []

    def step(self, a):
        if not getattr(self.scene, "multiplayer", False):
            self.robot.apply_action(a)
            self.scene.global_step()

        alive_bonus = 1.0
        potential = self.robot.calc_potential()
        power_cost = -1e-3 * np.square(a).sum()

        state = self.robot.calc_state()
        done = False

        if not np.isfinite(state).all():
            done = True
        elif np.any(np.abs(state[2:]) > 100):
            done = True
        elif not (-0.2 < state[0] < 1.0):
            done = True
        elif not (-1.0 < state[1] < 1.0):
            done = True

        self.rewards = [potential, alive_bonus, power_cost]
        total_reward = sum(self.rewards)
        self.reward += total_reward

        if self.debugmode:
            print("Potential:", potential)
            print("Power Cost:", power_cost)
            print("Rewards:", self.rewards)

        return state, total_reward, bool(done), {}