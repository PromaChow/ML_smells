import numpy as np
import matplotlib.pyplot as plt

def parse_fasttext(filename, max_words=1500):
    with open(filename, 'r', encoding='utf-8', errors='ignore') as f:
        header = f.readline()
        parts = header.strip().split()
        if len(parts) == 2:
            _, dim = parts
            dim = int(dim)
        else:
            dim = int(parts[1])
        words = []
        vectors = []
        for line in f:
            if len(words) >= max_words:
                break
            parts = line.rstrip().split()
            if len(parts) != dim + 1:
                continue
            words.append(parts[0])
            vectors.append([float(x) for x in parts[1:]])
        X = np.array(vectors, dtype=np.float32)
    return X, words

def pca(X, k=50):
    X_centered = X - np.mean(X, axis=0)
    cov = np.dot(X_centered.T, X_centered) / X.shape[0]
    eigvals, eigvecs = np.linalg.eigh(cov)
    idx = np.argsort(eigvals)[::-1]
    eigvecs = eigvecs[:, idx[:k]]
    return np.dot(X_centered, eigvecs)

def Hbeta(D, beta):
    P = np.exp(-D * beta)
    sumP = np.sum(P)
    if sumP == 0:
        H = 0.0
    else:
        P /= sumP
        H = -np.sum(P * np.log(P + 1e-10))
    return H, P

def x2p(X, perplexity=30.0, tol=1e-5):
    (n, _) = X.shape
    sum_X = np.sum(X * X, axis=1)
    D = -2.0 * np.dot(X, X.T) + sum_X[:, None] + sum_X[None, :]
    D[np.diag_indices_from(D)] = 0.0
    P = np.zeros((n, n))
    for i in range(n):
        beta = 1.0
        beta_min = None
        beta_max = None
        Di = D[i, np.arange(n) != i]
        H, thisP = Hbeta(Di, beta)
        while abs(H - perplexity) > tol and np.iterable:
            if H > perplexity:
                beta_min = beta
                beta = beta_max if beta_max is not None else beta * 2
            else:
                beta_max = beta
                beta = beta_min if beta_min is not None else beta / 2
            H, thisP = Hbeta(Di, beta)
        P[i, np.arange(n) != i] = thisP
    P = (P + P.T) / (2 * n)
    P *= 4.0
    return P

def tsne(X, dims=2, perplexity=30.0, max_iter=1000,
         learning_rate=500.0, initial_momentum=0.5,
         final_momentum=0.8, early_exaggeration_iters=100):
    n, _ = X.shape
    Y = np.random.randn(n, dims) * 1e-4
    iY = np.zeros((n, dims))
    gains = np.ones((n, dims))
    P = x2p(X, perplexity)
    for iter in range(max_iter):
        sum_Y = np.sum(Y * Y, axis=1)
        num = 1.0 / (1.0 + -2.0 * np.dot(Y, Y.T) + sum_Y[:, None] + sum_Y[None, :])
        np.fill_diagonal(num, 0.0)
        denom = np.sum(num)
        Q = num / denom
        np.fill_diagonal(Q, 0.0)
        PQ = P - Q
        grad = 4.0 * np.sum((PQ * num)[:, :, None] * (Y[:, None, :] - Y[None, :, :]), axis=1)
        gains = (gains + 0.2) * ((grad > 0) != (iY > 0)) + (gains * 0.8) * ((grad > 0) == (iY > 0))
        gains[gains < 0.01] = 0.01
        momentum = initial_momentum if iter < 20 else final_momentum
        iY = momentum * iY - learning_rate * (gains * grad)
        Y += iY
        Y -= np.mean(Y, axis=0)
        if iter == early_exaggeration_iters:
            P /= 4.0
        if iter % 10 == 0:
            cost = np.sum(P * np.log((P + 1e-10) / (Q + 1e-10)))
            print(f"Iteration {iter:04d} KL-divergence: {cost:.4f}")
    return Y

def main():
    X_raw, words = parse_fasttext('dataset.vec', max_words=1500)
    X = pca(X_raw, k=300)
    Y = tsne(X, dims=2, perplexity=20.0, max_iter=1000)
    plt.figure(figsize=(10, 10))
    plt.scatter(Y[:, 0], Y[:, 1], s=10, alpha=0.6)
    for i, word in enumerate(words):
        plt.text(Y[i, 0], Y[i, 1], word, fontsize=8)
    plt.title('t-SNE embedding of word vectors')
    plt.xlabel('Dimension 1')
    plt.ylabel('Dimension 2')
    plt.grid(False)
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()
