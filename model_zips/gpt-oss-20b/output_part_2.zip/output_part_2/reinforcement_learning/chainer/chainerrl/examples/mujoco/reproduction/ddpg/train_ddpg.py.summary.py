import argparse
import os
import random
import gym
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from gym.wrappers import Monitor
from rlkit.envs import CastObservationToFloat32
from rlkit.envs import Render
from rlkit.torch.ddpg.ddpg_trainer import DDPGTrainer
from rlkit.torch.ddpg.ddpg_agent import DDPGAgent
from rlkit.data_management.obs_dict_replay_buffer import ReplayBuffer
from rlkit.torch.networks import ContinuousDeterministicDistribution
from rlkit.torch.policies import Policy
from rlkit.torch.core import np_to_pytorch_batch
from torchviz import make_dot
from collections import deque

class MLP(nn.Module):
    def __init__(self, input_dim, output_dim, hidden_dims, activation, out_activation=None):
        super().__init__()
        dims = [input_dim] + list(hidden_dims) + [output_dim]
        layers = []
        for i in range(len(dims)-1):
            lin = nn.Linear(dims[i], dims[i+1])
            # LeCun uniform scaled by 3^{-0.5}
            nn.init.lecun_uniform_(lin.weight, a=3**-0.5)
            nn.init.constant_(lin.bias, 0)
            layers.append(lin)
            if i < len(dims)-2:
                layers.append(activation())
            else:
                if out_activation is not None:
                    layers.append(out_activation())
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)

class QFunction(nn.Module):
    def __init__(self, obs_dim, act_dim):
        super().__init__()
        self.net = MLP(obs_dim + act_dim, 1, [400, 300], nn.ReLU)

    def forward(self, obs, act):
        inp = torch.cat([obs, act], dim=-1)
        return self.net(inp)

class PolicyNetwork(nn.Module):
    def __init__(self, obs_dim, act_dim, act_limit):
        super().__init__()
        self.net = MLP(obs_dim, act_dim, [400, 300], nn.ReLU)
        self.act_limit = act_limit

    def forward(self, obs):
        raw = self.net(obs)
        act = torch.tanh(raw) * self.act_limit
        return ContinuousDeterministicDistribution(act)

def visualize_graph(net, dummy_input, out_dir, name):
    dummy_input = torch.tensor(dummy_input, dtype=torch.float32).unsqueeze(0)
    if isinstance(net, PolicyNetwork):
        dummy_act = net.forward(dummy_input)
        dot = make_dot(dummy_act.sample(), params=dict(net.named_parameters()))
    else:
        dummy_act = torch.randn_like(dummy_input)
        dot = make_dot(net(dummy_input, dummy_act), params=dict(net.named_parameters()))
    dot.format = 'pdf'
    dot.render(os.path.join(out_dir, name), cleanup=True)

def burnin_action_func(env, replay_buffer, buffer_capacity):
    while len(replay_buffer) < buffer_capacity:
        obs = env.reset()
        done = False
        while not done and len(replay_buffer) < buffer_capacity:
            action = env.action_space.sample()
            next_obs, reward, done, _ = env.step(action)
            replay_buffer.add(
                {'observation': obs,
                 'action': action,
                 'reward': reward,
                 'next_observation': next_obs,
                 'done': done})
            obs = next_obs

def evaluate_agent(agent, env, n_episodes, max_episode_length):
    returns = []
    for _ in range(n_episodes):
        obs = env.reset()
        episode_return = 0.0
        for _ in range(max_episode_length):
            act = agent.policy(np_to_pytorch_batch(obs)).sample().cpu().numpy()
            obs, reward, done, _ = env.step(act)
            episode_return += reward
            if done:
                break
        returns.append(episode_return)
    return np.mean(returns)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--outdir', type=str, default='results')
    parser.add_argument('--env', type=str, required=True)
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--gpu', type=int, default=0)
    parser.add_argument('--replay_size', type=int, default=10**6)
    parser.add_argument('--batch_size', type=int, default=100)
    parser.add_argument('--steps', type=int, default=1_000_000)
    parser.add_argument('--eval_interval', type=int, default=50_000)
    parser.add_argument('--eval_n_runs', type=int, default=10)
    parser.add_argument('--monitor', action='store_true')
    parser.add_argument('--render', action='store_true')
    parser.add_argument('--demo', action='store_true')
    parser.add_argument('--load', type=str, default=None)
    parser.add_argument('--load_pretrained', action='store_true')
    args = parser.parse_args()

    os.makedirs(args.outdir, exist_ok=True)
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    random.seed(args.seed)

    env = gym.make(args.env)
    if isinstance(env, gym.wrappers.TimeLimit):
        env.env.seed(args.seed)
        env.seed(args.seed)
    env = CastObservationToFloat32(env)
    if args.monitor:
        env = Monitor(env, os.path.join(args.outdir, 'monitor'))
    if args.render:
        env = Render(env)

    obs_dim = env.observation_space.shape[0]
    act_dim = env.action_space.shape[0]
    act_limit = env.action_space.high[0]

    q_func = QFunction(obs_dim, act_dim)
    policy_net = PolicyNetwork(obs_dim, act_dim, act_limit)
    q_optimizer = optim.Adam(q_func.parameters())
    a_optimizer = optim.Adam(policy_net.parameters())

    visualize_graph(policy_net, env.observation_space.sample(), args.outdir, 'policy')
    visualize_graph(q_func, env.observation_space.sample(), args.outdir, 'q_function')

    replay_buffer = ReplayBuffer(replay_size=args.replay_size, observation_space=env.observation_space,
                                 action_space=env.action_space)

    burnin_action_func(env, replay_buffer, buffer_capacity=10**4)

    trainer = DDPGTrainer(
        actor=policy_net,
        critic=q_func,
        actor_optimizer=a_optimizer,
        critic_optimizer=q_optimizer,
        discount=0.99,
        tau=5e-3,
        actor_update_interval=1,
        critic_update_interval=1,
        replay_buffer=replay_buffer,
        batch_size=args.batch_size,
        start_steps=10**4,
        device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    )

    agent = DDPGAgent(
        env=env,
        policy=policy_net,
        trainer=trainer,
        device=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    )

    if args.load:
        agent.restore_parameters(args.load)
    elif args.load_pretrained:
        # Placeholder: actual download logic omitted
        pretrained_path = os.path.join(args.outdir, 'pretrained')
        agent.restore_parameters(pretrained_path)

    max_episode_length = env._max_episode_steps if hasattr(env, '_max_episode_steps') else 1000

    if args.demo:
        mean_return = evaluate_agent(agent, env, args.eval_n_runs, max_episode_length)
        print(f'Demo mean return: {mean_return}')
        return

    for step in range(args.steps):
        obs = env.reset()
        done = False
        episode_return = 0.0
        while not done and step < args.steps:
            action = agent.policy(np_to_pytorch_batch(obs)).sample().cpu().numpy()
            next_obs, reward, done, _ = env.step(action)
            replay_buffer.add(
                {'observation': obs,
                 'action': action,
                 'reward': reward,
                 'next_observation': next_obs,
                 'done': done})
            obs = next_obs
            episode_return += reward
            step += 1
            if step % 1 == 0:
                trainer.update()
        if step % args.eval_interval == 0:
            mean_return = evaluate_agent(agent, env, args.eval_n_runs, max_episode_length)
            print(f'Step {step}: Eval mean return {mean_return}')

    agent.save_parameters(os.path.join(args.outdir, 'final.pt'))

if __name__ == "__main__":
    main()
