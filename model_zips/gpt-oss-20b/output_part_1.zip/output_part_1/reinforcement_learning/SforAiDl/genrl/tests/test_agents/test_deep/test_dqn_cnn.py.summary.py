import os
import shutil
import unittest

from genrl.envs import VectorEnv
from genrl.algorithms import (
    DQN,
    DoubleDQN,
    DuelingDQN,
    PrioritizedDQN,
    NoisyDQN,
    CategoricalDQN,
)
from genrl.algorithms.value import (
    CnnDuelingValue,
    CnnNoisyValue,
    CnnCategoricalValue,
)
from genrl.train import OffPolicyTrainer
from genrl.logger import CSVLogger


class TestDQNVariants(unittest.TestCase):
    LOG_DIR = "./logs"

    def _create_env(self):
        return VectorEnv("Pong-v0", env_type="atari", num_env=1)

    def _cleanup_logs(self):
        if os.path.exists(self.LOG_DIR):
            shutil.rmtree(self.LOG_DIR)

    def _train_and_evaluate(self, algo, evaluate=False):
        self._cleanup_logs()
        logger = CSVLogger(save_dir=self.LOG_DIR)
        trainer = OffPolicyTrainer(
            algo=algo,
            env=self._create_env(),
            logger=logger,
            max_episode_len=200,
            epochs=4,
            warmup_steps=10,
            start_updates_at_step=10,
        )
        trainer.train()
        if evaluate:
            trainer.evaluate()
        self._cleanup_logs()

    def test_vanilla_dqn(self):
        algo = DQN(
            model_type="cnn",
            batch_size=5,
            replay_buffer_size=100,
            value_layers=[1, 1],
        )
        self.assertEqual(algo.dqn_type, "vanilla")
        self._train_and_evaluate(algo)

    def test_double_dqn(self):
        algo = DoubleDQN(
            model_type="cnn",
            batch_size=5,
            replay_buffer_size=100,
            value_layers=[1, 1],
        )
        self.assertEqual(algo.dqn_type, "double")
        self._train_and_evaluate(algo, evaluate=True)

    def test_dueling_dqn(self):
        algo = DuelingDQN(
            model_type="cnn",
            batch_size=5,
            replay_buffer_size=100,
            value_layers=[1, 1],
        )
        self.assertEqual(algo.dqn_type, "dueling")
        self.assertIsInstance(algo.value, CnnDuelingValue)
        self._train_and_evaluate(algo, evaluate=True)

    def test_prioritized_dqn(self):
        algo = PrioritizedDQN(
            model_type="cnn",
            batch_size=5,
            replay_buffer_size=100,
            value_layers=[1, 1],
        )
        self.assertEqual(algo.dqn_type, "prioritized")
        self._train_and_evaluate(algo)

    def test_noisy_dqn(self):
        algo = NoisyDQN(
            model_type="cnn",
            batch_size=5,
            replay_buffer_size=100,
            value_layers=[1, 1],
            noisy=True,
        )
        self.assertEqual(algo.dqn_type, "noisy")
        self.assertTrue(algo.noisy)
        self.assertIsInstance(algo.value, CnnNoisyValue)
        self._train_and_evaluate(algo)

    def test_categorical_dqn(self):
        algo = CategoricalDQN(
            model_type="cnn",
            batch_size=5,
            replay_buffer_size=100,
            value_layers=[1, 1],
            noisy=True,
        )
        self.assertEqual(algo.dqn_type, "categorical")
        self.assertTrue(algo.noisy)
        self.assertIsInstance(algo.value, CnnCategoricalValue)
        self._train_and_evaluate(algo)


if __name__ == "__main__":
    unittest.main()
