import torch
import torch.nn.functional as F
from torch import nn


def enumerate_discrete(batch_size: int, y_dim: int) -> torch.Tensor:
    """Return a batch of all possible one‑hot label vectors."""
    return torch.arange(y_dim, device=batch_size.device).unsqueeze(0).expand(batch_size, y_dim)


def log_standard_categorical(y: torch.Tensor, y_dim: int) -> torch.Tensor:
    """Return the log probability of a uniform categorical distribution."""
    return torch.full_like(y, torch.log(torch.tensor(y_dim, dtype=y.dtype, device=y.device)))


class ImportanceWeightedSampler:
    def __init__(self, mc: int, iw: int):
        self.mc = mc
        self.iw = iw
        self.n_samples = mc * iw

    def resample(self, tensor: torch.Tensor) -> torch.Tensor:
        """Repeat each element of tensor n_samples times along the batch dimension."""
        return tensor.repeat_interleave(self.n_samples, dim=0)

    def __call__(self, elbo: torch.Tensor) -> torch.Tensor:
        """Compute the importance weighted ELBO."""
        shape = elbo.shape
        elbo = elbo.view(self.mc, self.iw, -1)
        lse = torch.logsumexp(elbo, dim=1)
        elbo = lse.mean(dim=0)
        return elbo


class SVI(nn.Module):
    def __init__(
        self,
        model: nn.Module,
        likelihood: nn.Module,
        beta: float,
        sampler: ImportanceWeightedSampler | None = None,
    ):
        super().__init__()
        self.model = model
        self.likelihood = likelihood
        self.beta = beta
        self.sampler = sampler or ImportanceWeightedSampler(mc=5, iw=5)

    def forward(self, x: torch.Tensor, y: torch.Tensor | None = None) -> torch.Tensor:
        batch_size, y_dim = x.shape[0], self.model.y_dim

        # Handle unlabeled data
        if y is None:
            y = enumerate_discrete(batch_size, y_dim)

        # Resample inputs
        xs = self.sampler.resample(x)
        ys = self.sampler.resample(y)

        # Model reconstructions and KL divergence
        recon_x, recon_y, kl_div = self.model(xs, ys)

        # Likelihood terms
        ll_x = -self.likelihood(recon_x, x, reduction="sum")
        ll_y = -self.likelihood(recon_y, y, reduction="sum")
        likelihood_term = ll_x + ll_y

        # Prior term
        prior_term = -log_standard_categorical(y, y_dim)

        # ELBO before weighting
        elbo = likelihood_term + prior_term - self.beta * kl_div

        # Importance weighted ELBO
        L = self.sampler(elbo)

        if y is not None and y.shape[-1] == y_dim:
            # Labeled data
            return L.mean()

        # Unlabeled data
        logits = self.model.classify(x)  # shape (batch, y_dim)
        L = L.view(batch_size, y_dim)
        U = (L * logits).sum(dim=1)

        probs = F.softmax(logits, dim=1)
        H = -(probs * torch.log(probs + 1e-20)).sum(dim=1)

        return (U + H).mean()