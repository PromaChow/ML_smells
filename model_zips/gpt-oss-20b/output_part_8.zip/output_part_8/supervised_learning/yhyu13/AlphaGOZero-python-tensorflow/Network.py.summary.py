import os
import datetime
import numpy as np
import tensorflow as tf
import daiquiri

# ------------------------------------------------------------
# Flags and hyperparameters
# ------------------------------------------------------------
class Flags:
    def __init__(self):
        self.n_batch = 32
        self.model = 'original'          # 'elu', 'full', or 'original'
        self.load_model_path = None
        self.MODE = 'train'              # used only for inference mode
        self.batch_size = 64

class HyperParameters:
    def __init__(self):
        self.optimizer = 'adam'
        self.learning_rate = 1e-3

# ------------------------------------------------------------
# Dummy model implementations
# ------------------------------------------------------------
def _conv_block(inputs, filters, name):
    return tf.layers.conv2d(inputs, filters, kernel_size=3, padding='same',
                            activation=tf.nn.relu, name=name)

def build_original_model(imgs, training):
    x = _conv_block(imgs, 32, 'conv1')
    for i in range(2):
        residual = x
        x = _conv_block(x, 32, f'res1_conv{i}')
        x = tf.layers.batch_normalization(x, training=training, name=f'res1_bn{i}')
        x = tf.nn.relu(x)
        x = x + residual
    logits = tf.layers.dense(x, 10, name='logits')
    probs = tf.nn.softmax(logits, name='probs')
    value = tf.layers.dense(x, 1, name='value')
    return probs, value

def build_elu_model(imgs, training):
    x = tf.nn.elu(tf.layers.conv2d(imgs, 32, 3, padding='same', name='conv1'))
    for i in range(2):
        residual = x
        x = tf.nn.elu(tf.layers.conv2d(x, 32, 3, padding='same', name=f'res1_conv{i}'))
        x = tf.layers.batch_normalization(x, training=training, name=f'res1_bn{i}')
        x = x + residual
    logits = tf.layers.dense(x, 10, name='logits')
    probs = tf.nn.softmax(logits, name='probs')
    value = tf.layers.dense(x, 1, name='value')
    return probs, value

def build_full_model(imgs, training):
    x = tf.layers.conv2d(imgs, 32, 3, padding='same', name='conv1')
    for i in range(2):
        residual = x
        x = tf.layers.conv2d(x, 32, 3, padding='same', name=f'res1_conv{i}')
        x = tf.layers.batch_normalization(x, training=training, name=f'res1_bn{i}')
        x = tf.nn.relu(x)
        x = x + residual
    x = tf.layers.global_average_pooling2d(x, name='gap')
    logits = tf.layers.dense(x, 10, name='logits')
    probs = tf.nn.softmax(logits, name='probs')
    value = tf.layers.dense(x, 1, name='value')
    return probs, value

# ------------------------------------------------------------
# Network class
# ------------------------------------------------------------
class Network:
    def __init__(self, flags=Flags(), hps=HyperParameters()):
        tf.reset_default_graph()
        config = tf.ConfigProto(
            inter_op_parallelism_threads=4,
            intra_op_parallelism_threads=4,
            allow_soft_placement=True,
            gpu_options=tf.GPUOptions(allow_growth=True,
                                      per_process_gpu_memory_fraction=0.4))
        self.sess = tf.Session(config=config)

        self.flags = flags
        self.hps = hps

        # placeholders
        self.imgs = tf.placeholder(tf.float32, shape=[None, None, None, 19], name='imgs')
        self.labels = tf.placeholder(tf.float32, shape=[None, 10], name='labels')
        self.results = tf.placeholder(tf.float32, shape=[None, 1], name='results')
        self.training = tf.placeholder(tf.bool, name='training')

        # build model
        if flags.model == 'elu':
            probs, value = build_elu_model(self.imgs, self.training)
        elif flags.model == 'full':
            probs, value = build_full_model(self.imgs, self.training)
        else:
            probs, value = build_original_model(self.imgs, self.training)

        # losses
        cross_entropy = tf.nn.softmax_cross_entropy_with_logits_v2(
            logits=tf.layers.dense(probs, 10, name='logits_dummy'), labels=self.labels)
        value_loss = tf.losses.mean_squared_error(self.results, value)
        self.cost = tf.reduce_mean(cross_entropy) + value_loss

        # metrics
        correct_pred = tf.equal(tf.argmax(probs, 1), tf.argmax(self.labels, 1))
        self.acc = tf.reduce_mean(tf.cast(correct_pred, tf.float32))
        result_pred = tf.sign(value - 0.0)
        self.result_acc = tf.reduce_mean(tf.cast(tf.equal(result_pred, self.results), tf.float32))

        # optimizer
        global_step = tf.Variable(0, trainable=False, name='global_step')
        self.global_step = global_step
        optimizer = tf.train.AdamOptimizer(learning_rate=self.hps.learning_rate)
        grads, _ = optimizer.compute_gradients(self.cost)
        self.norm = tf.global_norm(grads)
        self.train_op = optimizer.apply_gradients(grads, global_step=global_step)

        # temperature placeholder
        self.temp = tf.placeholder(tf.float32, shape=(), name='temp')

        # summaries
        tf.summary.scalar('cost', self.cost)
        tf.summary.scalar('accuracy', self.acc)
        tf.summary.scalar('result_accuracy', self.result_acc)
        tf.summary.scalar('learning_rate', self.hps.learning_rate)
        tf.summary.scalar('global_norm', self.norm)
        tf.summary.scalar('temperature', self.temp)
        self.summary_op = tf.summary.merge_all()

        # summary writers
        self.train_writer = tf.summary.FileWriter('./train_log', self.sess.graph)
        self.test_writer = tf.summary.FileWriter('./test_log', self.sess.graph)

        # saver
        trainable_vars = tf.trainable_variables()
        self.saver = tf.train.Saver(trainable_vars)

        # initialize
        self.initialize()

        # load model if path provided
        if self.flags.load_model_path:
            self.restore_model(self.flags.load_model_path)

    def close(self):
        self.sess.close()
        daiquiri.debug('Session closed.')

    def initialize(self):
        self.sess.run(tf.global_variables_initializer())
        daiquiri.debug('Global variables initialized.')

    def restore_model(self, checkpoint_dir):
        if not checkpoint_dir:
            return
        ckpt = tf.train.get_checkpoint_state(checkpoint_dir)
        if ckpt and ckpt.model_checkpoint_path:
            try:
                self.saver.restore(self.sess, ckpt.model_checkpoint_path)
                daiquiri.info(f'Restored model from {ckpt.model_checkpoint_path}')
            except Exception as e:
                daiquiri.error(f'Failed to restore model: {e}')
        else:
            daiquiri.warning('No checkpoint found.')

    def save_model(self, name):
        ckpt_dir = './savedmodels/large20/'
        os.makedirs(ckpt_dir, exist_ok=True)
        checkpoint_path = os.path.join(ckpt_dir, f'model-{name}.ckpt')
        self.saver.save(self.sess, checkpoint_path, global_step=self.global_step)
        daiquiri.info(f'Model saved to {checkpoint_path}')

    def _normalize_channel(self, imgs):
        channel = imgs[..., 15]
        normalized = (channel / 127.5) - 1.0
        imgs[..., 15] = normalized
        return imgs

    def run_many(self, imgs):
        imgs = self._normalize_channel(np.copy(imgs))
        feed = {
            self.imgs: imgs,
            self.training: False,
            self.temp: 1.0
        }
        probs, value = self.sess.run([self.probs, self.value], feed_dict=feed)
        return probs, value

    def train(self, training_data, direction=1.0, use_sparse=True, lrn_rate=1e-3):
        num_batches = int(np.ceil(len(training_data) / self.flags.n_batch))
        for i in range(num_batches):
            batch = training_data[i * self.flags.n_batch:(i + 1) * self.flags.n_batch]
            imgs = np.array([b['imgs'] for b in batch])
            labels = np.array([b['labels'] for b in batch])
            results = np.array([b['results'] for b in batch])
            imgs = self._normalize_channel(imgs)
            results = (results / 127.5) - 1.0
            feed = {
                self.imgs: imgs,
                self.labels: labels,
                self.results: results,
                self.training: True,
                self.temp: direction
            }
            try:
                _, loss, acc, norm, summary = self.sess.run(
                    [self.train_op, self.cost, self.acc, self.norm, self.summary_op],
                    feed_dict=feed)
                step = self.sess.run(self.global_step)
                self.train_writer.add_summary(summary, step)
                daiquiri.debug(f'Batch {i+1}/{num_batches} - Loss: {loss:.4f}, Acc: {acc:.4f}, Norm: {norm:.4f}')
            except tf.errors.InvalidArgumentError as e:
                daiquiri.warning(f'Skipping batch due to error: {e}')
            except KeyboardInterrupt:
                daiquiri.info('Training interrupted by user.')
                break

    def test(self, test_data, proportion=0.1, force_save_model=False, no_save=False):
        num_samples = int(len(test_data) * proportion)
        test_subset = test_data[:num_samples]
        total_loss = 0.0
        total_acc = 0.0
        total_res_acc = 0.0
        steps = 0
        for i in range(0, len(test_subset), self.flags.n_batch):
            batch = test_subset[i:i + self.flags.n_batch]
            imgs = np.array([b['imgs'] for b in batch])
            labels = np.array([b['labels'] for b in batch])
            results = np.array([b['results'] for b in batch])
            imgs = self._normalize_channel(imgs)
            results = (results / 127.5) - 1.0
            feed = {
                self.imgs: imgs,
                self.labels: labels,
                self.results: results,
                self.training: False,
                self.temp: 1.0
            }
            try:
                loss, acc, res_acc, summary = self.sess.run(
                    [self.cost, self.acc, self.result_acc, self.summary_op],
                    feed_dict=feed)
                step = self.sess.run(self.global_step)
                self.test_writer.add_summary(summary, step)
                total_loss += loss
                total_acc += acc
                total_res_acc += res_acc
                steps += 1
                daiquiri.debug(f'Test batch {i//self.flags.n_batch + 1} - Loss: {loss:.4f}, Acc: {acc:.4f}, ResAcc: {res_acc:.4f}')
            except tf.errors.InvalidArgumentError as e:
                daiquiri.warning(f'Skipping batch due to error: {e}')

        if steps == 0:
            daiquiri.warning('No test batches processed.')
            return

        avg_loss = total_loss / steps
        avg_acc = total_acc / steps
        avg_res_acc = total_res_acc / steps
        daiquiri.info(f'Avg Test Loss: {avg_loss:.4f}, Avg Acc: {avg_acc:.4f}, Avg ResAcc: {avg_res_acc:.4f}')

        if (force_save_model or avg_acc > 0.4) and not no_save:
            self.save_model(f'{avg_acc:.3f}')

# ------------------------------------------------------------
# Example usage (not part of the module)
# ------------------------------------------------------------
if __name__ == '__main__':
    daiquiri.setup(level=daiquiri.DEBUG)
    net = Network()
    # Dummy data for demonstration
    dummy_imgs = np.random.randint(0, 256, (64, 19, 19, 19)).astype(np.float32)
    dummy_labels = np.eye(10)[np.random.randint(0, 10, 64)]
    dummy_results = np.random.randn(64, 1)
    training_examples = [{'imgs': dummy_imgs[i], 'labels': dummy_labels[i], 'results': dummy_results[i]} for i in range(64)]
    net.train(training_examples, proportion=0.1)
    net.close()
