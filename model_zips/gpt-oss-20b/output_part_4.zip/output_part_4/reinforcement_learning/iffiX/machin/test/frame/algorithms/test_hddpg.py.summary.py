import logging
import os
import tempfile
from typing import Dict, Tuple

import gym
import pytest
import torch
import torch.nn as nn
import torch.optim as optim
from machin.algorithms.hddpg import HDDPG
from machin.data import ReplayBuffer
from torch.nn.functional import relu, tanh

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class Actor(nn.Module):
    def __init__(self, state_dim: int, action_dim: int, action_range: float):
        super().__init__()
        self.fc1 = nn.Linear(state_dim, 256)
        self.fc2 = nn.Linear(256, 256)
        self.out = nn.Linear(256, action_dim)
        self.action_range = action_range

    def forward(self, state: torch.Tensor) -> torch.Tensor:
        x = relu(self.fc1(state))
        x = relu(self.fc2(x))
        action = tanh(self.out(x)) * self.action_range
        return action

class Critic(nn.Module):
    def __init__(self, state_dim: int, action_dim: int):
        super().__init__()
        self.fc1 = nn.Linear(state_dim + action_dim, 256)
        self.fc2 = nn.Linear(256, 256)
        self.out = nn.Linear(256, 1)

    def forward(self, state: torch.Tensor, action: torch.Tensor) -> torch.Tensor:
        x = torch.cat([state, action], dim=-1)
        x = relu(self.fc1(x))
        x = relu(self.fc2(x))
        q = self.out(x)
        return q

@pytest.fixture
def train_config() -> Dict:
    env_name = "Pendulum-v0"
    env = gym.make(env_name)
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.shape[0]
    action_range = float(env.action_space.high[0])
    config = {
        "env": env,
        "state_dim": state_dim,
        "action_dim": action_dim,
        "action_range": action_range,
        "max_episodes": 200,
        "max_steps": 200,
        "replay_size": 100000,
        "batch_size": 64,
        "gamma": 0.99,
        "tau": 0.005,
        "actor_lr": 1e-4,
        "critic_lr": 1e-3,
        "reward_threshold": -200.0,
        "device": torch.device("cpu"),
    }
    return config

@pytest.fixture
def hddpg(train_config: Dict) -> HDDPG:
    actor = Actor(
        state_dim=train_config["state_dim"],
        action_dim=train_config["action_dim"],
        action_range=train_config["action_range"],
    )
    critic = Critic(
        state_dim=train_config["state_dim"],
        action_dim=train_config["action_dim"],
    )
    target_actor = Actor(
        state_dim=train_config["state_dim"],
        action_dim=train_config["action_dim"],
        action_range=train_config["action_range"],
    )
    target_critic = Critic(
        state_dim=train_config["state_dim"],
        action_dim=train_config["action_dim"],
    )
    target_actor.load_state_dict(actor.state_dict())
    target_critic.load_state_dict(critic.state_dict())

    actor_opt = optim.Adam(actor.parameters(), lr=train_config["actor_lr"])
    critic_opt = optim.Adam(critic.parameters(), lr=train_config["critic_lr"])

    agent = HDDPG(
        actor=actor,
        critic=critic,
        target_actor=target_actor,
        target_critic=target_critic,
        actor_optimizer=actor_opt,
        critic_optimizer=critic_opt,
        gamma=train_config["gamma"],
        tau=train_config["tau"],
        device=train_config["device"],
        replay_buffer=ReplayBuffer(max_size=train_config["replay_size"]),
    )
    return agent

@pytest.fixture
def hddpg_vis(tmp_path: tempfile.TemporaryDirectory) -> HDDPG:
    config = hddpg
    config.env = gym.make("Pendulum-v0")
    config.env.render(mode="human")
    # Assume HDDPG can accept a logger path or similar
    return config

@pytest.fixture
def hddpg_train(train_config: Dict) -> HDDPG:
    return hddpg(train_config)

def add_synthetic_episode(buffer: ReplayBuffer, steps: int = 10):
    for _ in range(steps):
        state = torch.zeros(3)
        action = torch.zeros(1)
        reward = torch.tensor(0.0)
        next_state = torch.zeros(3)
        done = torch.tensor(False)
        buffer.add(state, action, reward, next_state, done)

def test_update(hddpg: HDDPG):
    add_synthetic_episode(hddpg.replay_buffer, steps=10)
    # Update value network only
    hddpg.update(
        steps=1,
        batch_size=hddpg.replay_buffer.batch_size,
        value_update=True,
        policy_update=False,
        target_update=False,
    )
    # Update policy network only
    hddpg.update(
        steps=1,
        batch_size=hddpg.replay_buffer.batch_size,
        value_update=False,
        policy_update=True,
        target_update=False,
    )
    # Update both networks
    hddpg.update(
        steps=1,
        batch_size=hddpg.replay_buffer.batch_size,
        value_update=True,
        policy_update=True,
        target_update=True,
    )

def test_config_init():
    config = {
        "state_dim": 3,
        "action_dim": 1,
        "action_range": 2.0,
        "gamma": 0.99,
        "tau": 0.005,
        "actor_lr": 1e-4,
        "critic_lr": 1e-3,
        "replay_buffer": ReplayBuffer(max_size=10000),
    }
    actor = Actor(
        state_dim=config["state_dim"],
        action_dim=config["action_dim"],
        action_range=config["action_range"],
    )
    critic = Critic(
        state_dim=config["state_dim"],
        action_dim=config["action_dim"],
    )
    target_actor = Actor(
        state_dim=config["state_dim"],
        action_dim=config["action_dim"],
        action_range=config["action_range"],
    )
    target_critic = Critic(
        state_dim=config["state_dim"],
        action_dim=config["action_dim"],
    )
    target_actor.load_state_dict(actor.state_dict())
    target_critic.load_state_dict(critic.state_dict())
    actor_opt = optim.Adam(actor.parameters(), lr=config["actor_lr"])
    critic_opt = optim.Adam(critic.parameters(), lr=config["critic_lr"])
    agent = HDDPG(
        actor=actor,
        critic=critic,
        target_actor=target_actor,
        target_critic=target_critic,
        actor_optimizer=actor_opt,
        critic_optimizer=critic_opt,
        gamma=config["gamma"],
        tau=config["tau"],
        device=torch.device("cpu"),
        replay_buffer=config["replay_buffer"],
    )
    add_synthetic_episode(agent.replay_buffer, steps=5)
    agent.update(
        steps=1,
        batch_size=agent.replay_buffer.batch_size,
        value_update=True,
        policy_update=True,
        target_update=True,
    )

def test_full_train(train_config: Dict, hddpg_train: HDDPG):
    env = train_config["env"]
    max_episodes = train_config["max_episodes"]
    max_steps = train_config["max_steps"]
    solved_reward = train_config["reward_threshold"]
    gamma = train_config["gamma"]
    device = train_config["device"]

    recent_rewards = []

    for episode in range(1, max_episodes + 1):
        state = env.reset()
        episode_reward = 0.0
        for step in range(max_steps):
            state_t = torch.tensor(state, dtype=torch.float32, device=device).unsqueeze(0)
            with torch.no_grad():
                action = hddpg_train.actor(state_t).cpu().numpy().squeeze()
            # Add exploration noise
            if step % 10 == 0:
                action += 0.2 * np.random.randn(*action.shape)
            action = np.clip(action, env.action_space.low, env.action_space.high)
            next_state, reward, done, _ = env.step(action)
            episode_reward += reward
            # Store transition
            hddpg_train.replay_buffer.add(
                torch.tensor(state, dtype=torch.float32, device=device),
                torch.tensor(action, dtype=torch.float32, device=device),
                torch.tensor(reward, dtype=torch.float32, device=device),
                torch.tensor(next_state, dtype=torch.float32, device=device),
                torch.tensor(done, dtype=torch.float32, device=device),
            )
            state = next_state
            if done:
                break
        recent_rewards.append(episode_reward)
        if len(recent_rewards) > 10:
            recent_rewards.pop(0)
        avg_reward = sum(recent_rewards) / len(recent_rewards)
        logger.info(f"Episode {episode} - Reward: {episode_reward:.2f}, Avg: {avg_reward:.2f}")

        if episode > 100:
            hddpg_train.update(
                steps=1,
                batch_size=hddpg_train.replay_buffer.batch_size,
                value_update=True,
                policy_update=True,
                target_update=True,
            )

        if avg_reward >= solved_reward:
            logger.info(f"Solved after {episode} episodes!")
            break
    else:
        pytest.fail("HDDPG did not solve the Pendulum-v0 environment within the episode budget.")
```