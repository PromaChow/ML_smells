import numpy as np
import torch

def process_mem(mem: np.ndarray) -> torch.Tensor:
    """
    Processes the input NumPy array through reshaping, type conversion,
    normalization, and conversion to a PyTorch tensor.

    Parameters
    ----------
    mem : np.ndarray
        Input array to be processed.

    Returns
    -------
    torch.Tensor
        The processed tensor with shape (1, 128) and dtype torch.float32.
    """
    # Convert to NumPy array with float32 dtype
    arr = np.asarray(mem, dtype=np.float32)

    # Reshape to (1, 128)
    arr = arr.reshape(1, 128)

    # Normalize by dividing by 255
    arr = arr / 255.0

    # Convert to PyTorch tensor
    return torch.from_numpy(arr)