import copy
import multiprocessing
import numpy as np
import chainer
import chainer.functions as F
import chainer.links as L
import chainer.optimizers as O
from chainer import Variable, Chain, ChainList

class EpsilonGreedyExplorer:
    def __init__(self, n_actions, epsilon=0.1):
        self.n_actions = n_actions
        self.epsilon = epsilon

    def select_action(self, q_values):
        if np.random.rand() < self.epsilon:
            return np.random.randint(self.n_actions)
        return int(q_values.argmax())


class FeatureExtractor:
    def __init__(self, input_dim, output_dim):
        self.net = L.Linear(input_dim, output_dim)

    def __call__(self, obs):
        return Variable(self.net(obs))


class NStepQLearning:
    def __init__(self,
                 shared_q_function,
                 optimizer,
                 t_max,
                 gamma,
                 i_target,
                 explorer,
                 phi,
                 average_q_decay=0.99,
                 n_actions=4):
        self.shared_q_function = shared_q_function
        self.q_function = copy.deepcopy(shared_q_function)
        self.target_q_function = copy.deepcopy(shared_q_function)
        self.optimizer = optimizer
        self.optimizer.setup(self.q_function)
        self.t_max = t_max
        self.gamma = gamma
        self.i_target = i_target
        self.explorer = explorer
        self.phi = phi
        self.average_q_decay = average_q_decay
        self.n_actions = n_actions

        self.t_global = multiprocessing.Value('i', 0)
        self.t = 0
        self.t_start = 0
        self.past_action_values = {}
        self.past_states = {}
        self.past_rewards = {}
        self.average_q = 0.0

        self.recurrent = hasattr(self.q_function, "reset_state")

    def batch_states(self, states):
        return np.array(states)

    def act_and_train(self, obs, reward):
        # feature extraction
        state = self.phi(obs)

        if self.t > 0:
            self.past_rewards[self.t - 1] = reward

        if self.t - self.t_start >= self.t_max:
            self.update(statevar=None)

        self.past_states[self.t] = state

        if self.recurrent:
            # Assume target_q_function can be evaluated to update internal states
            self.target_q_function.cleargrads()
            self.target_q_function(state)

        q_values = self.q_function(state)
        q_values_np = q_values.data
        action = self.explorer.select_action(q_values_np)

        self.past_action_values[self.t] = q_values_np[action]
        self.average_q = self.average_q * self.average_q_decay + q_values_np[action] * (1 - self.average_q_decay)

        self.t += 1
        with self.t_global.get_lock():
            self.t_global.value += 1

        if self.t_global.value % self.i_target == 0:
            # sync target network
            for param_src, param_dst in zip(self.q_function.params(), self.target_q_function.params()):
                param_dst.data = param_src.data.copy()

        return action

    def update(self, statevar):
        if statevar is None:
            R = 0.0
        else:
            R = F.max(self.target_q_function(statevar)).data.item()

        for i in range(self.t - 1, self.t_start - 1, -1):
            R = self.gamma * R + self.past_rewards.get(i, 0.0)
            q_val = self.past_action_values[i]
            loss = F.huber_loss(Variable(np.array([q_val])), Variable(np.array([R])))
            self.optimizer.update(loss)

        # copy gradients to shared network
        for param_local, param_shared in zip(self.q_function.params(), self.shared_q_function.params()):
            param_shared.grad = param_local.grad.copy() if param_local.grad is not None else None

        self.optimizer.update(self.shared_q_function)

        # clear buffers
        self.past_action_values.clear()
        self.past_states.clear()
        self.past_rewards.clear()
        self.t_start = self.t

    def stop_episode_and_train(self, final_reward, done):
        if self.t > 0:
            self.past_rewards[self.t - 1] = final_reward

        if done:
            self.update(statevar=None)
        else:
            # dummy next state; in practice you would pass the actual next state
            self.update(statevar=None)

        if self.recurrent:
            for net in (self.q_function, self.shared_q_function, self.target_q_function):
                if hasattr(net, "reset_state"):
                    net.reset_state()

    def act(self, obs):
        state = self.phi(obs)
        q_values = self.q_function(state)
        action = int(q_values.argmax())
        return action

    def stop_episode(self):
        if self.recurrent:
            for net in (self.q_function, self.shared_q_function, self.target_q_function):
                if hasattr(net, "reset_state"):
                    net.reset_state()

    def load(self, path):
        self.shared_q_function.load_npz(path)

    def get_statistics(self):
        return self.average_q


# Example usage
if __name__ == "__main__":
    # Dummy Q-network
    class DummyQNet(Chain):
        def __init__(self, input_dim, n_actions):
            super().__init__()
            with self.init_scope():
                self.l1 = L.Linear(input_dim, 128)
                self.l2 = L.Linear(128, n_actions)

        def __call__(self, x):
            h = F.relu(self.l1(x))
            return self.l2(h)

    input_dim = 10
    n_actions = 4
    q_net = DummyQNet(input_dim, n_actions)
    opt = O.Adam()
    explorer = EpsilonGreedyExplorer(n_actions, epsilon=0.1)
    phi = FeatureExtractor(input_dim, input_dim)

    nsq = NStepQLearning(
        shared_q_function=q_net,
        optimizer=opt,
        t_max=5,
        gamma=0.99,
        i_target=10,
        explorer=explorer,
        phi=phi,
        average_q_decay=0.95,
        n_actions=n_actions
    )

    # Dummy loop
    for step in range(20):
        obs = np.random.randn(input_dim).astype(np.float32)
        reward = np.random.randn()
        done = (step == 19)
        action = nsq.act_and_train(obs, reward)
        if done:
            nsq.stop_episode_and_train(reward, done)
    print("Average Q:", nsq.get_statistics())