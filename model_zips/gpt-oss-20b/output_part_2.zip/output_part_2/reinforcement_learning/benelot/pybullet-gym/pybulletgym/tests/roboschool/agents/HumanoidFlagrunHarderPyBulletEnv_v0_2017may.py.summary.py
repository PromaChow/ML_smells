import numpy as np

# Define weight matrices and bias vectors (placeholder values)
weights_dense1_w = np.random.randn(32, 128)
weights_dense1_b = np.random.randn(32)
weights_dense2_w = np.random.randn(32, 32)
weights_dense2_b = np.random.randn(32)
weights_final_w = np.random.randn(10, 32)
weights_final_b = np.random.randn(10)

def dense_layer(x: np.ndarray, w: np.ndarray, b: np.ndarray) -> np.ndarray:
    """
    Apply a linear transformation: y = x @ w.T + b
    """
    return x @ w.T + b

def forward_pass(x: np.ndarray) -> np.ndarray:
    """
    Perform a forward pass through the three dense layers.
    """
    out1 = dense_layer(x, weights_dense1_w, weights_dense1_b)
    out2 = dense_layer(out1, weights_dense2_w, weights_dense2_b)
    out3 = dense_layer(out2, weights_final_w, weights_final_b)
    return out3

if __name__ == "__main__":
    # Example input: batch of 128-dimensional vectors
    batch_size = 5
    input_batch = np.random.randn(batch_size, 128)
    logits = forward_pass(input_batch)
    print("Logits shape:", logits.shape)
    print(logits)