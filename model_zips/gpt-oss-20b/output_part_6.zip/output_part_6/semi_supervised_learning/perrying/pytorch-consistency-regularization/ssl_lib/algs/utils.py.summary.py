import math
import torch
import torch.nn.functional as F
from torch.distributions import Beta


def make_pseudo_label(logits: torch.Tensor, threshold: float):
    """
    Generate hard pseudo-labels and a validity mask based on a confidence threshold.
    Args:
        logits: Tensor of shape (N, C) containing class logits.
        threshold: Confidence threshold for accepting a pseudo-label.
    Returns:
        hard_labels: Tensor of shape (N,) with the most probable class indices.
        mask: Boolean Tensor of shape (N,) indicating samples whose maximum
              probability is >= threshold.
    """
    probs = F.softmax(logits, dim=1)
    max_probs, hard_labels = probs.max(dim=1)
    mask = max_probs >= threshold
    return hard_labels, mask


def sharpening(soft_labels: torch.Tensor, temp: float):
    """
    Sharpen soft labels by raising to a temperature and renormalizing.
    Args:
        soft_labels: Tensor of shape (N, C) containing soft labels (probabilities).
        temp: Temperature parameter for sharpening (>=0).
    Returns:
        Tensor of shape (N, C) containing sharpened probabilities.
    """
    sharpened = soft_labels.pow(temp)
    denom = sharpened.abs().sum(dim=1, keepdim=True)
    sharpened = sharpened / denom
    return sharpened


def temperature_softmax(logits: torch.Tensor, tau: float):
    """
    Apply temperature scaling before softmax.
    Args:
        logits: Tensor of shape (N, C) containing class logits.
        tau: Temperature parameter (>=0). Larger values produce smoother distributions.
    Returns:
        Tensor of shape (N, C) containing temperature-adjusted probabilities.
    """
    scaled_logits = logits / tau
    return F.softmax(scaled_logits, dim=1)


def mixup(x: torch.Tensor, y: torch.Tensor, alpha: float = 1.0):
    """
    Perform mixup augmentation on inputs and labels.
    Args:
        x: Input tensor of shape (N, ...).
        y: Label tensor. Can be class indices of shape (N,) or one‑hot of shape (N, C).
        alpha: Hyper‑parameter for the Beta distribution.
    Returns:
        x_mix: Mixed input tensor.
        y_mix: Mixed label tensor.
    """
    N = x.size(0)
    perm = torch.randperm(N, device=x.device)
    lam = Beta(alpha, alpha).sample().item()
    lam_x = lam
    # Expand lam to match dimensions of x
    for _ in range(1, x.dim()):
        lam_x = lam_x.unsqueeze(-1)
    x_mix = lam_x * x + (1 - lam_x) * x[perm]

    if y.dim() == 1:  # class indices
        y_mix = lam * y + (1 - lam) * y[perm]
    else:  # one‑hot or probability vector
        y_mix = lam * y + (1 - lam) * y[perm]
    return x_mix, y_mix


def get_tsa_threshold(
    global_step: int,
    max_iter: int,
    schedule: str,
    num_classes: int,
):
    """
    Compute the current threshold for TSA (Training Signal Annealing).
    Args:
        global_step: Current training step.
        max_iter: Total number of training iterations.
        schedule: One of 'linear', 'exp', 'log' for the schedule type.
        num_classes: Number of target classes.
    Returns:
        threshold: Current threshold value.
    """
    step_ratio = global_step / max_iter
    if schedule == "linear":
        coef = step_ratio
    elif schedule == "exp":
        coef = math.exp((step_ratio - 1) * 5)
    elif schedule == "log":
        coef = 1 - math.exp(-step_ratio * 5)
    else:
        raise ValueError(f"Unsupported schedule '{schedule}'")

    start = 1.0 / num_classes
    end = 1.0
    threshold = coef * (end - start) + start
    return threshold


def anneal_loss(
    loss: torch.Tensor,
    logits: torch.Tensor,
    labels: torch.Tensor,
    global_step: int,
    max_iter: int,
    schedule: str,
    num_classes: int,
):
    """
    Anneal loss based on TSA threshold.
    Args:
        loss: Tensor of shape (N,) containing per‑sample loss values.
        logits: Tensor of shape (N, C) containing class logits.
        labels: Tensor of shape (N,) containing ground‑truth class indices.
        global_step: Current training step.
        max_iter: Total number of training iterations.
        schedule: Schedule type for threshold calculation.
        num_classes: Number of target classes.
    Returns:
        mean_loss: Scalar Tensor containing the mean of the masked losses.
    """
    threshold = get_tsa_threshold(global_step, max_iter, schedule, num_classes)
    probs = F.softmax(logits, dim=1)
    true_probs = probs.gather(1, labels.unsqueeze(1)).squeeze(1)
    mask = true_probs < threshold
    masked_loss = loss * mask.float()
    mean_loss = masked_loss.mean()
    return mean_loss
