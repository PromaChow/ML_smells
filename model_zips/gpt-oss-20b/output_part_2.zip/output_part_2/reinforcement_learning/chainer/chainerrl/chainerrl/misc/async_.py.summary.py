import warnings
import multiprocessing
import numpy as np
import chainer
import copy
from typing import Dict, Any, Callable, Sequence, Tuple

# 1. Custom Warning
class AbnormalExitWarning(UserWarning):
    """Warning raised when a subprocess exits with a non-zero exit code."""
    pass

# 2. Ensure Update Rule Initialization
def ensure_initialized_update_rule(update_rule: chainer.links.Chain):
    """Ensure that the update rule has initialized state."""
    if getattr(update_rule, 'states', None) is None:
        if hasattr(update_rule, 'init_state'):
            update_rule.init_state()

# Helper: map numpy dtype to multiprocessing typecode
def _dtype_to_typecode(dtype: np.dtype) -> str:
    if np.issubdtype(dtype, np.integer):
        if dtype.itemsize == 1:
            return 'b'
        elif dtype.itemsize == 2:
            return 'h'
        elif dtype.itemsize == 4:
            return 'i'
        elif dtype.itemsize == 8:
            return 'l'
    elif np.issubdtype(dtype, np.floating):
        if dtype.itemsize == 4:
            return 'f'
        elif dtype.itemsize == 8:
            return 'd'
    raise TypeError(f"Unsupported dtype for shared array: {dtype}")

# 3. Recursive Persistent Value Assignment
def _set_persistent_values_recursively(link: chainer.Link, persistent_values: Dict[str, np.ndarray]):
    for name, value in persistent_values.items():
        if hasattr(link, name):
            setattr(link, name, value)
    for name, sublink in link.named_children():
        if isinstance(sublink, chainer.Link):
            _set_persistent_values_recursively(sublink, persistent_values)

# 4. Set Shared Parameters
def set_shared_params(link: chainer.Link, shared_params: Dict[str, multiprocessing.RawArray]):
    for name, param in link.named_params():
        if name in shared_params:
            buf = shared_params[name]
            dtype = param.data.dtype
            shape = param.data.shape
            param.data[:] = np.frombuffer(buf, dtype=dtype, count=np.prod(shape)).reshape(shape)
    # persistent values
    persistent_attrs = {k: v for k, v in link.__dict__.items() if isinstance(v, np.ndarray) and k not in link.params}
    for name, array in persistent_attrs.items():
        if name in shared_params:
            buf = shared_params[name]
            dtype = array.dtype
            shape = array.shape
            setattr(link, name, np.frombuffer(buf, dtype=dtype, count=np.prod(shape)).reshape(shape))

# 5. Make Parameters Not Shared
def make_params_not_shared(link: chainer.Link):
    for name, param in link.named_params():
        param.data[:] = np.copy(param.data)
    persistent_attrs = {k: v for k, v in link.__dict__.items() if isinstance(v, np.ndarray) and k not in link.params}
    for name, array in persistent_attrs.items():
        setattr(link, name, np.copy(array))

# 6. Check Non-Shared Parameters
def assert_params_not_shared(link_a: chainer.Link, link_b: chainer.Link):
    for name, param_a in link_a.named_params():
        param_b = link_b.get(name)
        if param_b is None:
            continue
        if param_a.data.ctypes.data == param_b.data.ctypes.data:
            raise AssertionError(f"Parameters '{name}' are shared between links.")

# 7. Set Shared States for Optimizers
def set_shared_states(optimizer: chainer.Optimizer, shared_states: Dict[str, multiprocessing.RawArray]):
    for name, states in optimizer.states.items():
        for key, state in states.items():
            if key in shared_states:
                buf = shared_states[key]
                dtype = state.dtype
                shape = state.shape
                optimizer.states[name][key] = np.frombuffer(buf, dtype=dtype, count=np.prod(shape)).reshape(shape)

# 8. Extract Parameters as Shared Arrays
def extract_params_as_shared_arrays(link: chainer.Link) -> Dict[str, multiprocessing.RawArray]:
    shared = {}
    for name, param in link.named_params():
        dtype = param.data.dtype
        shape = param.data.shape
        size = param.data.size * param.data.itemsize
        typecode = _dtype_to_typecode(dtype)
        raw = multiprocessing.RawArray(typecode, np.frombuffer(param.data, dtype=dtype).flatten())
        shared[name] = raw
    # persistent values
    persistent_attrs = {k: v for k, v in link.__dict__.items() if isinstance(v, np.ndarray) and k not in link.params}
    for name, array in persistent_attrs.items():
        dtype = array.dtype
        shape = array.shape
        typecode = _dtype_to_typecode(dtype)
        raw = multiprocessing.RawArray(typecode, np.frombuffer(array, dtype=dtype).flatten())
        shared[name] = raw
    return shared

# 9. Share Parameters via Shared Arrays
def share_params_as_shared_arrays(link: chainer.Link):
    shared = extract_params_as_shared_arrays(link)
    set_shared_params(link, shared)

# 10. Extract States as Shared Arrays
def extract_states_as_shared_arrays(optimizer: chainer.Optimizer) -> Dict[str, multiprocessing.RawArray]:
    shared = {}
    for name, states in optimizer.states.items():
        for key, state in states.items():
            dtype = state.dtype
            shape = state.shape
            typecode = _dtype_to_typecode(dtype)
            raw = multiprocessing.RawArray(typecode, np.frombuffer(state, dtype=dtype).flatten())
            shared[key] = raw
    return shared

# 11. Share States via Shared Arrays
def share_states_as_shared_arrays(optimizer: chainer.Optimizer):
    shared = extract_states_as_shared_arrays(optimizer)
    set_shared_states(optimizer, shared)

# 12. Asynchronous Process Execution
def run_async(func: Callable[..., Any], args: Sequence[Any] = (), kwargs: Dict[str, Any] = {}, processes: int = 1, base_seed: int = 1234):
    def worker(seed: int, *a, **kw):
        np.random.seed(seed)
        func(*a, **kw)

    procs = []
    for i in range(processes):
        seed = base_seed + i
        p = multiprocessing.Process(target=worker, args=(seed, *args), kwargs=kwargs)
        p.start()
        procs.append(p)
    for p in procs:
        p.join()
        if p.exitcode != 0:
            warnings.warn(f"Process {p.pid} exited with code {p.exitcode}", AbnormalExitWarning)

# 13. Convert Objects to Shared Memory
def as_shared_objects(obj: Any) -> Any:
    if isinstance(obj, chainer.Link):
        share_params_as_shared_arrays(obj)
        return obj
    if isinstance(obj, chainer.Optimizer):
        share_states_as_shared_arrays(obj)
        return obj
    if isinstance(obj, (multiprocessing.Value, multiprocessing.Array)):
        return obj
    return obj

# 14. Synchronize Objects with Shared Memory
def synchronize_to_shared_objects(obj: Any) -> Any:
    if isinstance(obj, chainer.Link):
        shared = extract_params_as_shared_arrays(obj)
        set_shared_params(obj, shared)
        return obj
    if isinstance(obj, chainer.Optimizer):
        shared = extract_states_as_shared_arrays(obj)
        set_shared_states(obj, shared)
        return obj
    return obj
