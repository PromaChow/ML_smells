import unittest
import numpy as np

# Simple Go game state representation
class GameState:
    def __init__(self, board, next_player, turn_number=0):
        self.board = np.array(board)  # 0 empty, 1 black, 2 white
        self.next_player = next_player  # 1 or 2
        self.turn_number = turn_number
        self.size = self.board.shape[0]
        # last move turn per point for turns_since (not used in tests)
        self.last_move_turn = np.full((self.size, self.size), -1)

    def copy(self):
        gs = GameState(self.board.copy(), self.next_player, self.turn_number)
        gs.last_move_turn = self.last_move_turn.copy()
        return gs

    def apply_move(self, point):
        x, y = point
        if self.board[x, y] != 0:
            raise ValueError("Illegal move: point occupied")
        color = self.next_player
        opp = 3 - color
        self.board[x, y] = color
        self.turn_number += 1
        self.last_move_turn[x, y] = self.turn_number
        # Capture opponent stones with no liberties
        captured = []
        for nx, ny in self._neighbors(x, y):
            if self.board[nx, ny] == opp:
                group, lib = self._group_and_liberties(nx, ny)
                if lib == 0:
                    for gx, gy in group:
                        self.board[gx, gy] = 0
                        captured.append((gx, gy))
        self.next_player = opp

    def _neighbors(self, x, y):
        for nx, ny in [(x-1,y),(x+1,y),(x,y-1),(x,y+1)]:
            if 0 <= nx < self.size and 0 <= ny < self.size:
                yield nx, ny

    def _group_and_liberties(self, x, y):
        color = self.board[x, y]
        visited = set()
        stack = [(x, y)]
        group = []
        liberties = 0
        while stack:
            cx, cy = stack.pop()
            if (cx, cy) in visited:
                continue
            visited.add((cx, cy))
            group.append((cx, cy))
            for nx, ny in self._neighbors(cx, cy):
                if self.board[nx, ny] == 0:
                    liberties += 1
                elif self.board[nx, ny] == color and (nx, ny) not in visited:
                    stack.append((nx, ny))
        return group, liberties

# Preprocessing class
class Preprocess:
    def __init__(self, feature):
        self.feature = feature

    def state_to_tensor(self, gs):
        size = gs.size
        if self.feature == "board":
            tensor = np.zeros((3, size, size), dtype=np.float32)
            tensor[0] = (gs.board == 1).astype(np.float32)
            tensor[1] = (gs.board == 2).astype(np.float32)
            tensor[2] = (gs.board == 0).astype(np.float32)
            return tensor
        if self.feature == "liberties":
            tensor = np.zeros((8, size, size), dtype=np.float32)
            for x in range(size):
                for y in range(size):
                    if gs.board[x, y] != 0:
                        _, lib = gs._group_and_liberties(x, y)
                        idx = min(lib, 7)
                        tensor[idx, x, y] = 1.0
            return tensor
        if self.feature == "legal_moves":
            tensor = np.zeros((1, size, size), dtype=np.float32)
            for x in range(size):
                for y in range(size):
                    if gs.board[x, y] == 0:
                        tmp = gs.copy()
                        try:
                            tmp.apply_move((x, y))
                            tensor[0, x, y] = 1.0
                        except Exception:
                            pass
            return tensor
        raise ValueError(f"Unknown feature {self.feature}")

# Helper board creation functions
def simple_board():
    # 3x3 board, black stone at center
    board = [
        [0,0,0],
        [0,1,0],
        [0,0,0]
    ]
    return GameState(board, next_player=2)  # White to play

def self_atari_board():
    # 3x3 board with a potential self-atari for black at (2,1)
    board = [
        [0,2,0],
        [2,1,0],
        [0,0,0]
    ]
    return GameState(board, next_player=1)  # Black to play

def capture_board():
    # 3x3 board where white at (0,1) will be captured by black at (1,1)
    board = [
        [0,2,0],
        [0,0,0],
        [0,0,0]
    ]
    return GameState(board, next_player=1)  # Black to play

class TestPreprocessingFeatures(unittest.TestCase):
    def test_board_representation(self):
        gs = simple_board()
        pre = Preprocess("board")
        tensor = pre.state_to_tensor(gs)
        expected = np.zeros((3,3,3), dtype=np.float32)
        expected[0,1,1] = 1.0  # black center
        expected[2,0,0] = 1.0  # empty
        expected[2,0,1] = 1.0
        expected[2,0,2] = 1.0
        expected[2,1,0] = 1.0
        expected[2,1,2] = 1.0
        expected[2,2,0] = 1.0
        expected[2,2,1] = 1.0
        expected[2,2,2] = 1.0
        self.assertTrue(np.allclose(tensor, expected))

    def test_liberties(self):
        gs = simple_board()
        pre = Preprocess("liberties")
        tensor = pre.state_to_tensor(gs)
        # Center black stone has 4 liberties
        expected = np.zeros((8,3,3), dtype=np.float32)
        expected[4,1,1] = 1.0
        self.assertTrue(np.allclose(tensor, expected))

    def test_legal_moves(self):
        gs = simple_board()
        pre = Preprocess("legal_moves")
        tensor = pre.state_to_tensor(gs)
        expected = np.ones((1,3,3), dtype=np.float32)
        expected[0,1,1] = 0.0  # occupied
        self.assertTrue(np.allclose(tensor, expected))

    def test_self_atari_detection(self):
        gs = self_atari_board()
        pre = Preprocess("legal_moves")
        tensor = pre.state_to_tensor(gs)
        # All empty positions are legal except (2,1) which would be self-atari
        expected = np.ones((1,3,3), dtype=np.float32)
        expected[0,2,1] = 0.0
        self.assertTrue(np.allclose(tensor, expected))

    def test_capture_size(self):
        gs = capture_board()
        pre = Preprocess("legal_moves")
        tensor = pre.state_to_tensor(gs)
        # All empty positions are legal; capture logic not tested here
        expected = np.ones((1,3,3), dtype=np.float32)
        self.assertTrue(np.allclose(tensor, expected))

    def test_feature_concatenation(self):
        gs = simple_board()
        pre_board = Preprocess("board")
        pre_lib = Preprocess("liberties")
        board_tensor = pre_board.state_to_tensor(gs)
        lib_tensor = pre_lib.state_to_tensor(gs)
        concat = np.concatenate([board_tensor, lib_tensor], axis=0)
        # Check shape
        self.assertEqual(concat.shape, (3+8,3,3))
        # Verify channel mapping
        np.testing.assert_array_equal(concat[:3], board_tensor)
        np.testing.assert_array_equal(concat[3:], lib_tensor)

if __name__ == "__main__":
    unittest.main()