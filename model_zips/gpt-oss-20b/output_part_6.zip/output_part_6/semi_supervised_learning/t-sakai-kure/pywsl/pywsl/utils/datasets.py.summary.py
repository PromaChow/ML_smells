import numpy as np
from sklearn.datasets import fetch_openml

def load_and_split_mnist(
    data_id=0,
    prior=0.1,
    n_p=10,
    n_n=10,
    n_vp=None,
    n_vn=None,
    n_vu=None,
    n_t=100,
    random_state=42
):
    # Load MNIST
    if data_id == 0:
        mnist = fetch_openml("mnist_784", version=1, as_frame=False, cache=True)
        X = mnist["data"].astype(np.float32) / 255.0
        y_raw = mnist["target"].astype(int)
        dataset_name = "mnist"
    else:
        raise ValueError("Unsupported data_id")

    # Binarize labels: even digits -> +1, odd digits -> -1
    y_bin = np.where(y_raw % 2 == 0, 1, -1)

    # Separate indices by class
    pos_idx = np.where(y_bin == 1)[0]
    neg_idx = np.where(y_bin == -1)[0]

    rng = np.random.RandomState(random_state)

    def split_indices(total_indices, unlabeled_cnt, labeled_cnt, val_cnt, test_cnt, vu_cnt=None):
        perm = rng.permutation(total_indices)
        unlabeled_idx = perm[:unlabeled_cnt]
        remaining_idx = perm[unlabeled_cnt:]

        if vu_cnt is not None and vu_cnt > 0:
            unlabeled_val_idx = unlabeled_idx[:vu_cnt]
            unlabeled_train_idx = unlabeled_idx[vu_cnt:]
        else:
            unlabeled_val_idx = np.array([], dtype=int)
            unlabeled_train_idx = unlabeled_idx

        perm_rem = rng.permutation(remaining_idx)
        labeled_idx = perm_rem[:labeled_cnt]
        val_idx = perm_rem[labeled_cnt:labeled_cnt + val_cnt]
        test_idx = perm_rem[labeled_cnt + val_cnt:labeled_cnt + val_cnt + test_cnt]

        return {
            "unlabeled_train": unlabeled_train_idx,
            "unlabeled_val": unlabeled_val_idx,
            "labeled": labeled_idx,
            "val": val_idx,
            "test": test_idx
        }

    # Compute unlabeled counts
    unlabeled_pos_cnt = int(prior * len(pos_idx))
    unlabeled_neg_cnt = int(prior * len(neg_idx))

    # Validation counts
    val_pos_cnt = n_vp if n_vp is not None else 0
    val_neg_cnt = n_vn if n_vn is not None else 0
    val_unlabeled_cnt = n_vu if n_vu is not None else 0

    # Split positive class
    pos_split = split_indices(
        pos_idx,
        unlabeled_pos_cnt,
        n_p,
        val_pos_cnt,
        n_t,
        val_unlabeled_cnt
    )

    # Split negative class
    neg_split = split_indices(
        neg_idx,
        unlabeled_neg_cnt,
        n_n,
        val_neg_cnt,
        n_t,
        val_unlabeled_cnt
    )

    # Gather samples
    x_p = X[pos_split["labeled"]]
    y_p = y_bin[pos_split["labeled"]]

    x_n = X[neg_split["labeled"]]
    y_n = y_bin[neg_split["labeled"]]

    x_u = np.concatenate((X[pos_split["unlabeled_train"]],
                           X[neg_split["unlabeled_train"]]), axis=0)
    y_u = np.concatenate((y_bin[pos_split["unlabeled_train"]],
                           y_bin[neg_split["unlabeled_train"]]), axis=0)

    x_t = np.concatenate((X[pos_split["test"]], X[neg_split["test"]]), axis=0)
    y_t = np.concatenate((y_bin[pos_split["test"]], y_bin[neg_split["test"]]), axis=0)

    x_vp = None
    x_vn = None
    x_vu = None
    y_vu = None

    if n_vp is not None:
        x_vp = X[pos_split["val"]]
    if n_vn is not None:
        x_vn = X[neg_split["val"]]
    if n_vu is not None and n_vu > 0:
        x_vu = np.concatenate((X[pos_split["unlabeled_val"]],
                               X[neg_split["unlabeled_val"]]), axis=0)
        y_vu = np.concatenate((y_bin[pos_split["unlabeled_val"]],
                               y_bin[neg_split["unlabeled_val"]]), axis=0)

    return {
        "dataset": dataset_name,
        "x_p": x_p,
        "x_n": x_n,
        "x_u": x_u,
        "y_u": y_u,
        "x_t": x_t,
        "y_t": y_t,
        "x_vp": x_vp,
        "x_vn": x_vn,
        "x_vu": x_vu,
        "y_vu": y_vu
    }

# Example usage:
# result = load_and_split_mnist(prior=0.2, n_p=50, n_n=50, n_vp=10, n_vn=10, n_vu=20, n_t=200)
# print(result["dataset"])
# print(result["x_p"].shape, result["x_n"].shape, result["x_u"].shape, result["x_t"].shape)
# print(result["x_vp"].shape if result["x_vp"] is not None else "No validation positives")
# print(result["x_vu"].shape if result["x_vu"] is not None else "No unlabeled validation")
