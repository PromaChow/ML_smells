import abc
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import torch.optim.lr_scheduler as lr_scheduler
from typing import Callable, Iterable, Tuple, Any


class BayesianNeuralNetworkBandit(nn.Module, metaclass=abc.ABCMeta):
    def __init__(
        self,
        context_dim: int,
        hidden_dims: Iterable[int],
        n_actions: int,
        learning_rate: float = 1e-3,
        max_grad_norm: float = 1.0,
        lr_decay: bool = False,
        lr_decay_rate: float = 0.99,
        dropout_p: float = 0.0,
        noise_std: float = 1e-6,
        layer_fn: Callable[[int, int], nn.Module] = nn.Linear,
    ) -> None:
        super().__init__()
        self.context_dim = context_dim
        self.hidden_dims = list(hidden_dims)
        self.n_actions = n_actions
        self.learning_rate = learning_rate
        self.max_grad_norm = max_grad_norm
        self.lr_decay = lr_decay
        self.lr_decay_rate = lr_decay_rate
        self.dropout_p = dropout_p
        self.noise_std = noise_std

        # Build network
        dims = [context_dim] + self.hidden_dims + [n_actions]
        layers = []
        for in_dim, out_dim in zip(dims[:-1], dims[1:]):
            layers.append(layer_fn(in_dim, out_dim))
            if out_dim != n_actions and dropout_p > 0.0:
                layers.append(nn.Dropout(dropout_p))
        self.network = nn.Sequential(*layers)

        # Optimizer and scheduler
        self.optimizer = optim.Adam(self.parameters(), lr=learning_rate)
        self.scheduler = (
            lr_scheduler.ExponentialLR(self.optimizer, gamma=lr_decay_rate)
            if lr_decay
            else None
        )
        self.initial_lr = learning_rate

    def forward(self, context: torch.Tensor) -> torch.Tensor:
        return self.network(context)

    @abc.abstractmethod
    def _compute_loss(
        self,
        predictions: torch.Tensor,
        actions_onehot: torch.Tensor,
        rewards: torch.Tensor,
    ) -> torch.Tensor:
        """
        Subclasses must implement the loss computation.
        """
        pass

    def _reset_learning_rate(self) -> None:
        for param_group in self.optimizer.param_groups:
            param_group["lr"] = self.initial_lr
        if self.scheduler is not None:
            self.scheduler = lr_scheduler.ExponentialLR(
                self.optimizer, gamma=self.lr_decay_rate
            )

    def train_from_db(
        self,
        db: Any,
        epochs: int,
        lr_reset: bool = False,
    ) -> None:
        """
        Train the network using data from a TransitionDB-like object.
        The db object must provide an iterable over batches of
        (context, actions, rewards). Each batch is expected to be a
        tuple of tensors: context of shape (batch, context_dim),
        actions of shape (batch,) containing action indices, and
        rewards of shape (batch,) containing scalar rewards.
        """
        self.train()
        if lr_reset:
            self._reset_learning_rate()

        for epoch in range(epochs):
            for batch in db:
                context, actions, rewards = batch
                actions_onehot = F.one_hot(actions, num_classes=self.n_actions).float()
                rewards = rewards.unsqueeze(1)  # shape (batch, 1)
                predictions = self.forward(context)  # shape (batch, n_actions)

                loss = self._compute_loss(predictions, actions_onehot, rewards)

                self.optimizer.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.parameters(), self.max_grad_norm)
                self.optimizer.step()
                if self.scheduler is not None:
                    self.scheduler.step()
        self.eval()
```