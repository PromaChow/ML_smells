import gym
import multiprocessing
from typing import Any, Callable, Iterable, List, Tuple, Union

class GymTerminationError(RuntimeError):
    """Raised when an action is attempted on a terminated environment."""


class ParallelWrapperDummy:
    def __init__(self, env_creators: List[Callable[[int], gym.Env]]) -> None:
        self._envs: List[gym.Env] = [creator(idx) for idx, creator in enumerate(env_creators)]
        self._terminal: List[bool] = [False] * len(self._envs)

    def _select_envs(self, idx: Union[int, Iterable[int], None]) -> List[int]:
        if idx is None:
            return list(range(len(self._envs)))
        if isinstance(idx, int):
            return [idx]
        return list(idx)

    def reset(self, idx: Union[int, Iterable[int], None] = None) -> List[Any]:
        selected = self._select_envs(idx)
        observations = []
        for i in selected:
            obs = self._envs[i].reset()
            self._terminal[i] = False
            observations.append(obs)
        return observations

    def step(self, actions: List[Any], idx: Union[int, Iterable[int], None] = None
             ) -> Tuple[List[Any], List[float], List[bool], List[dict]]:
        selected = self._select_envs(idx)
        if len(actions) != len(selected):
            raise ValueError("Number of actions must match number of selected environments")
        observations, rewards, dones, infos = [], [], [], []
        for i, action in zip(selected, actions):
            if self._terminal[i]:
                raise GymTerminationError(f"Environment {i} has terminated")
            obs, rew, done, info = self._envs[i].step(action)
            observations.append(obs)
            rewards.append(rew)
            dones.append(done)
            infos.append(info)
            self._terminal[i] = done
        return observations, rewards, dones, infos

    def seed(self, seed: Union[int, List[int]]) -> List[int]:
        seeds = []
        for i, env in enumerate(self._envs):
            s = seed[i] if isinstance(seed, list) else seed
            env.seed(s)
            seeds.append(s)
        return seeds

    def render(self, idx: Union[int, Iterable[int], None] = None) -> List[Any]:
        selected = self._select_envs(idx)
        frames = []
        for i in selected:
            if self._terminal[i]:
                raise GymTerminationError(f"Environment {i} has terminated")
            frames.append(self._envs[i].render())
        return frames

    def close(self) -> None:
        for env in self._envs:
            env.close()

    def active(self) -> List[int]:
        return [i for i, t in enumerate(self._terminal) if not t]

    def size(self) -> int:
        return len(self._envs)

    @property
    def action_space(self) -> gym.Space:
        return self._envs[0].action_space

    @property
    def observation_space(self) -> gym.Space:
        return self._envs[0].observation_space


class ParallelWrapperSubProc:
    def __init__(self, env_creators: List[Callable[[int], gym.Env]]) -> None:
        self._ctx = multiprocessing.get_context("spawn")
        self._cmd_queues: List[multiprocessing.Queue] = []
        self._res_queues: List[multiprocessing.Queue] = []
        self._processes: List[multiprocessing.Process] = []

        # Create a dummy env to expose spaces
        dummy_env = env_creators[0](0)
        self._action_space = dummy_env.action_space
        self._observation_space = dummy_env.observation_space
        dummy_env.close()

        self._terminal: List[bool] = [False] * len(env_creators)

        for idx, creator in enumerate(env_creators):
            cmd_q = self._ctx.Queue()
            res_q = self._ctx.Queue()
            p = self._ctx.Process(
                target=self._worker,
                args=(cmd_q, res_q, creator, idx),
                daemon=True
            )
            p.start()
            self._cmd_queues.append(cmd_q)
            self._res_queues.append(res_q)
            self._processes.append(p)

    def _select_envs(self, idx: Union[int, Iterable[int], None]) -> List[int]:
        if idx is None:
            return list(range(len(self._cmd_queues)))
        if isinstance(idx, int):
            return [idx]
        return list(idx)

    def _call_gym_env_method(self, method: str,
                             idx: Union[int, Iterable[int], None],
                             *args: Any,
                             **kwargs: Any) -> List[Any]:
        selected = self._select_envs(idx)
        for i in selected:
            self._cmd_queues[i].put({'method': method, 'args': args, 'kwargs': kwargs})
        results = []
        for i in selected:
            res = self._res_queues[i].get()
            if isinstance(res, Exception):
                raise res
            results.append(res)
        return results

    @staticmethod
    def _worker(cmd_q: multiprocessing.Queue,
                res_q: multiprocessing.Queue,
                env_creator: Callable[[int], gym.Env],
                idx: int) -> None:
        env = env_creator(idx)
        while True:
            try:
                msg = cmd_q.get()
            except EOFError:
                break
            if msg is None:
                break
            method = msg.get('method')
            args = msg.get('args', ())
            kwargs = msg.get('kwargs', {})
            try:
                if method == 'reset':
                    obs = env.reset(**kwargs)
                    res_q.put(obs)
                elif method == 'step':
                    action = args[0] if args else None
                    obs, rew, done, info = env.step(action)
                    res_q.put((obs, rew, done, info))
                elif method == 'render':
                    frame = env.render(**kwargs)
                    res_q.put(frame)
                elif method == 'seed':
                    seeds = env.seed(**kwargs)
                    res_q.put(seeds)
                elif method == 'close':
                    env.close()
                    res_q.put(None)
                else:
                    res_q.put(None)
            except Exception as e:
                res_q.put(e)
        env.close()

    def reset(self, idx: Union[int, Iterable[int], None] = None) -> List[Any]:
        selected = self._select_envs(idx)
        for i in selected:
            self._terminal[i] = False
        observations = self._call_gym_env_method('reset', idx)
        return observations

    def step(self, actions: List[Any], idx: Union[int, Iterable[int], None] = None
             ) -> Tuple[List[Any], List[float], List[bool], List[dict]]:
        selected = self._select_envs(idx)
        if len(actions) != len(selected):
            raise ValueError("Number of actions must match number of selected environments")
        for i in selected:
            if self._terminal[i]:
                raise GymTerminationError(f"Environment {i} has terminated")
        results = self._call_gym_env_method('step', idx, actions)
        observations, rewards, dones, infos = [], [], [], []
        for i, (obs, rew, done, info) in zip(selected, results):
            observations.append(obs)
            rewards.append(rew)
            dones.append(done)
            infos.append(info)
            self._terminal[i] = done
        return observations, rewards, dones, infos

    def seed(self, seed: Union[int, List[int]]) -> List[int]:
        selected = self._select_envs(None)
        seeds = []
        for i in selected:
            s = seed[i] if isinstance(seed, list) else seed
            result = self._call_gym_env_method('seed', i, seed=s)[0]
            seeds.append(result)
        return seeds

    def render(self, idx: Union[int, Iterable[int], None] = None) -> List[Any]:
        frames = self._call_gym_env_method('render', idx, mode='rgb_array')
        return frames

    def close(self) -> None:
        for cmd_q in self._cmd_queues:
            cmd_q.put('close')
        for cmd_q in self._cmd_queues:
            cmd_q.put(None)
        for p in self._processes:
            p.join()

    def active(self) -> List[int]:
        return [i for i, t in enumerate(self._terminal) if not t]

    def size(self) -> int:
        return len(self._cmd_queues)

    @property
    def action_space(self) -> gym.Space:
        return self._action_space

    @property
    def observation_space(self) -> gym.Space:
        return self._observation_space
