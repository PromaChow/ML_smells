import random
import math
import numpy as np
from PIL import Image, ImageOps, ImageEnhance, ImageFilter
import tensorflow as tf

PARAMETER_MAX = 10

def get_mean_and_std():
    # CIFAR-10 mean and std
    mean = np.array([0.4914, 0.4822, 0.4465], dtype=np.float32)
    std = np.array([0.2470, 0.2435, 0.2616], dtype=np.float32)
    return mean, std

def float_parameter(level, maxval):
    return float(level) * maxval / PARAMETER_MAX

def int_parameter(level, maxval):
    return int(round(float_parameter(level, maxval)))

def random_flip(img):
    if random.random() < 0.5:
        return ImageOps.mirror(img)
    return img

def zero_pad_and_crop(img, pad, target_size):
    w, h = img.size
    padded = ImageOps.expand(img, border=pad, fill=0)
    left = random.randint(0, pad * 2)
    top = random.randint(0, pad * 2)
    right = left + target_size[0]
    bottom = top + target_size[1]
    return padded.crop((left, top, right, bottom))

def cutout_numpy(img_np, size):
    h, w, _ = img_np.shape
    y = random.randint(0, h - size)
    x = random.randint(0, w - size)
    img_np[y:y+size, x:x+size] = 0
    return img_np

def pil_wrap(img_np):
    mean, std = get_mean_and_std()
    img_np = img_np.astype(np.float32)
    if img_np.max() <= 1.0:
        img_np = img_np * 255.0
    img_np = np.clip(img_np, 0, 255).astype(np.uint8)
    return Image.fromarray(img_np)

def pil_unwrap(img):
    img_np = np.asarray(img).astype(np.float32) / 255.0
    mean, std = get_mean_and_std()
    return img_np

class TransformT:
    def __init__(self, name, func):
        self.name = name
        self.func = func

    def __call__(self, img):
        return self.func(img)

def flip_lr(img):
    return ImageOps.mirror(img)

def flip_ud(img):
    return ImageOps.flip(img)

def rotate(img, level):
    degrees = int_parameter(level, 30)
    if random.random() < 0.5:
        degrees = -degrees
    return img.rotate(degrees, resample=Image.BILINEAR)

def shear_x(img, level):
    shear = float_parameter(level, 0.3)
    if random.random() < 0.5:
        shear = -shear
    return img.transform(img.size, Image.AFFINE,
                        (1, shear, 0, 0, 1, 0),
                        resample=Image.BILINEAR)

def shear_y(img, level):
    shear = float_parameter(level, 0.3)
    if random.random() < 0.5:
        shear = -shear
    return img.transform(img.size, Image.AFFINE,
                        (1, 0, 0, shear, 1, 0),
                        resample=Image.BILINEAR)

def translate_x(img, level):
    max_trans = img.size[0] * 0.45
    trans = int_parameter(level, max_trans)
    if random.random() < 0.5:
        trans = -trans
    return img.transform(img.size, Image.AFFINE,
                        (1, 0, trans, 0, 1, 0),
                        resample=Image.BILINEAR)

def translate_y(img, level):
    max_trans = img.size[1] * 0.45
    trans = int_parameter(level, max_trans)
    if random.random() < 0.5:
        trans = -trans
    return img.transform(img.size, Image.AFFINE,
                        (1, 0, 0, 0, 1, trans),
                        resample=Image.BILINEAR)

def crop(img, level):
    crop_factor = float_parameter(level, 0.45)
    w, h = img.size
    new_w = int(w * (1 - crop_factor))
    new_h = int(h * (1 - crop_factor))
    return zero_pad_and_crop(img, pad=int(max(w, h) * 0.45), target_size=(new_w, new_h))

def brightness(img, level):
    factor = float_parameter(level, 1.8) + 0.1
    return ImageEnhance.Brightness(img).enhance(factor)

def contrast(img, level):
    factor = float_parameter(level, 1.8) + 0.1
    return ImageEnhance.Contrast(img).enhance(factor)

def color(img, level):
    factor = float_parameter(level, 1.8) + 0.1
    return ImageEnhance.Color(img).enhance(factor)

def sharpness(img, level):
    factor = float_parameter(level, 1.8) + 0.1
    return ImageEnhance.Sharpness(img).enhance(factor)

def solarize(img, level):
    threshold = int_parameter(level, 256)
    return ImageOps.solarize(img, threshold)

def autocontrast(img, level):
    return ImageOps.autocontrast(img, cutoff=int_parameter(level, 10))

def equalize(img, level):
    return ImageOps.equalize(img)

def invert(img, level):
    return ImageOps.invert(img)

def blur(img, level):
    radius = float_parameter(level, 1.5)
    return img.filter(ImageFilter.GaussianBlur(radius))

def smooth(img, level):
    radius = float_parameter(level, 1.5)
    return img.filter(ImageFilter.GaussianBlur(radius))

def cutout(img, level):
    size = int_parameter(level, min(img.size))
    img_np = np.asarray(img).copy()
    img_np = cutout_numpy(img_np, size)
    return Image.fromarray(img_np)

def identity(img, level=None):
    return img

ALL_TRANSFORMS = [
    TransformT('flip_lr', flip_lr),
    TransformT('flip_ud', flip_ud),
    TransformT('rotate', rotate),
    TransformT('shear_x', shear_x),
    TransformT('shear_y', shear_y),
    TransformT('translate_x', translate_x),
    TransformT('translate_y', translate_y),
    TransformT('crop', crop),
    TransformT('brightness', brightness),
    TransformT('contrast', contrast),
    TransformT('color', color),
    TransformT('sharpness', sharpness),
    TransformT('solarize', solarize),
    TransformT('autocontrast', autocontrast),
    TransformT('equalize', equalize),
    TransformT('invert', invert),
    TransformT('blur', blur),
    TransformT('smooth', smooth),
    TransformT('cutout', cutout),
    TransformT('identity', identity),
]

NAME_TO_TRANSFORM = {t.name: t for t in ALL_TRANSFORMS}

def apply_policy(img_np, policy):
    img = pil_wrap(img_np)
    for op in policy:
        name = op['name']
        prob = op.get('prob', 1.0)
        level = op.get('level', 0)
        if random.random() < prob:
            transform = NAME_TO_TRANSFORM.get(name)
            if transform:
                img = transform.func(img, level) if transform.func != identity else transform(img)
    return pil_unwrap(img)

# Example usage
if __name__ == "__main__":
    # Dummy image
    img_np = np.random.rand(32, 32, 3).astype(np.float32)
    policy = [
        {'name': 'rotate', 'prob': 0.9, 'level': 5},
        {'name': 'shear_x', 'prob': 0.8, 'level': 3},
        {'name': 'cutout', 'prob': 0.5, 'level': 4},
    ]
    augmented = apply_policy(img_np, policy)
    print(augmented.shape, augmented.dtype)
