import copy
import multiprocessing as mp
import os
import signal
import sys
import warnings

import chainer
import chainer.functions as F
import chainer.links as L
import chainer.optimizers as optimizers
import numpy as np
import pytest

import chainerrl.utils.async_ as async_


class LinearModel(chainer.Chain):
    def __init__(self, in_size, out_size):
        super().__init__()
        with self.init_scope():
            self.linear = L.Linear(in_size, out_size)

    def __call__(self, x):
        return self.linear(x)


class BatchNormModel(chainer.Chain):
    def __init__(self, in_size, out_size):
        super().__init__()
        with self.init_scope():
            self.bn = L.BatchNormalization(in_size)
            self.linear = L.Linear(in_size, out_size)

    def __call__(self, x):
        y = self.bn(x)
        return self.linear(y)


class ChainListModel(chainer.Chain):
    def __init__(self, in_size, hidden_size, out_size):
        super().__init__()
        with self.init_scope():
            self.chain = chainer.ChainList(
                L.BatchNormalization(in_size),
                L.Linear(in_size, hidden_size),
                L.BatchNormalization(hidden_size),
                L.Linear(hidden_size, out_size),
            )

    def __call__(self, x):
        h = x
        for layer in self.chain:
            h = layer(h)
        return h


class HeadTailModel(chainer.Chain):
    def __init__(self, head, tail_in, tail_out):
        super().__init__()
        with self.init_scope():
            self.head = head
            self.tail = L.Linear(tail_in, tail_out)

    def __call__(self, x):
        h = self.head(x)
        return self.tail(h)


def _forward_and_backward(model, x):
    y = model(x)
    loss = F.mean_squared_error(y, F.zeros_like(y))
    loss.backward()


@pytest.fixture
def rng():
    return np.random.default_rng(0)


def test_shared_parameters_linear(rng):
    in_size, out_size = 10, 5
    model_a = LinearModel(in_size, out_size)
    # Initialize parameters
    _forward_and_backward(model_a, chainer.Variable(rng.standard_normal((1, in_size)).astype(np.float32)))
    # Share parameters
    shared = async_.share_params_as_shared_arrays(model_a)
    model_b = LinearModel(in_size, out_size)
    async_.set_params_from_shared_arrays(model_b, shared)
    model_c = LinearModel(in_size, out_size)
    async_.set_params_from_shared_arrays(model_c, shared)
    # Check pointer equality for parameters
    assert id(model_a.linear.W.data) == id(model_b.linear.W.data) == id(model_c.linear.W.data)
    assert id(model_a.linear.b.data) == id(model_b.linear.b.data) == id(model_c.linear.b.data)
    # Gradients should be distinct
    _forward_and_backward(model_b, chainer.Variable(rng.standard_normal((1, in_size)).astype(np.float32)))
    _forward_and_backward(model_c, chainer.Variable(rng.standard_normal((1, in_size)).astype(np.float32)))
    assert id(model_a.linear.W.grad) != id(model_b.linear.W.grad) != id(model_c.linear.W.grad)
    assert id(model_a.linear.b.grad) != id(model_b.linear.b.grad) != id(model_c.linear.b.grad)


def test_shared_parameters_batchnorm(rng):
    in_size, out_size = 10, 5
    model_a = BatchNormModel(in_size, out_size)
    _forward_and_backward(model_a, chainer.Variable(rng.standard_normal((1, in_size)).astype(np.float32)))
    shared = async_.share_params_as_shared_arrays(model_a)
    model_b = BatchNormModel(in_size, out_size)
    async_.set_params_from_shared_arrays(model_b, shared)
    model_c = BatchNormModel(in_size, out_size)
    async_.set_params_from_shared_arrays(model_c, shared)
    # Parameters
    assert id(model_a.bn.gamma.data) == id(model_b.bn.gamma.data) == id(model_c.bn.gamma.data)
    assert id(model_a.bn.beta.data) == id(model_b.bn.beta.data) == id(model_c.bn.beta.data)
    # Persistent values
    assert id(model_a.bn.avg_mean) == id(model_b.bn.avg_mean) == id(model_c.bn.avg_mean)
    assert id(model_a.bn.avg_var) == id(model_b.bn.avg_var) == id(model_c.bn.avg_var)
    assert id(model_a.bn.N) == id(model_b.bn.N) == id(model_c.bn.N)
    # Gradients distinct
    _forward_and_backward(model_b, chainer.Variable(rng.standard_normal((1, in_size)).astype(np.float32)))
    _forward_and_backward(model_c, chainer.Variable(rng.standard_normal((1, in_size)).astype(np.float32)))
    assert id(model_a.bn.gamma.grad) != id(model_b.bn.gamma.grad) != id(model_c.bn.gamma.grad)
    # Persistent values update consistently
    x = chainer.Variable(rng.standard_normal((1, in_size)).astype(np.float32))
    _forward_and_backward(model_b, x)
    _forward_and_backward(model_c, x)
    assert model_b.bn.N == model_c.bn.N == model_a.bn.N


def test_shared_parameters_chainer_list(rng):
    in_size, hidden_size, out_size = 10, 8, 5
    model_a = ChainListModel(in_size, hidden_size, out_size)
    _forward_and_backward(model_a, chainer.Variable(rng.standard_normal((1, in_size)).astype(np.float32)))
    shared = async_.share_params_as_shared_arrays(model_a)
    model_b = ChainListModel(in_size, hidden_size, out_size)
    async_.set_params_from_shared_arrays(model_b, shared)
    model_c = ChainListModel(in_size, hidden_size, out_size)
    async_.set_params_from_shared_arrays(model_c, shared)
    # Parameters and persistent values share pointers
    for layer_a, layer_b, layer_c in zip(
        model_a.chain, model_b.chain, model_c.chain
    ):
        if isinstance(layer_a, L.BatchNormalization):
            assert id(layer_a.gamma.data) == id(layer_b.gamma.data) == id(layer_c.gamma.data)
            assert id(layer_a.beta.data) == id(layer_b.beta.data) == id(layer_c.beta.data)
            assert id(layer_a.avg_mean) == id(layer_b.avg_mean) == id(layer_c.avg_mean)
            assert id(layer_a.avg_var) == id(layer_b.avg_var) == id(layer_c.avg_var)
        elif isinstance(layer_a, L.Linear):
            assert id(layer_a.W.data) == id(layer_b.W.data) == id(layer_c.W.data)
            assert id(layer_a.b.data) == id(layer_b.b.data) == id(layer_c.b.data)
    # Gradients distinct
    _forward_and_backward(model_b, chainer.Variable(rng.standard_normal((1, in_size)).astype(np.float32)))
    _forward_and_backward(model_c, chainer.Variable(rng.standard_normal((1, in_size)).astype(np.float32)))
    for layer_a, layer_b, layer_c in zip(
        model_a.chain, model_b.chain, model_c.chain
    ):
        if isinstance(layer_a, L.Linear):
            assert id(layer_a.W.grad) != id(layer_b.W.grad) != id(layer_c.W.grad)


def test_shared_optimizer_states(rng):
    in_size, out_size = 10, 5
    model_a = LinearModel(in_size, out_size)
    opt_a = optimizers.RMSprop(lr=0.001)
    opt_a.setup(model_a)
    # Forward to initialize state
    _forward_and_backward(model_a, chainer.Variable(rng.standard_normal((1, in_size)).astype(np.float32)))
    opt_a.update()
    # Extract shared state for the linear link
    linear_link = model_a.linear
    shared_momentum = opt_a.states[linear_link]["momentum"]
    # Create new model and optimizer
    model_b = LinearModel(in_size, out_size)
    opt_b = optimizers.RMSprop(lr=0.001)
    opt_b.setup(model_b)
    # Assign shared state
    opt_b.states[model_b.linear]["momentum"] = shared_momentum
    # Verify shared pointer
    assert id(opt_a.states[linear_link]["momentum"]) == id(opt_b.states[model_b.linear]["momentum"])


def test_shared_link_and_deepcopy(rng):
    in_size, hidden_size, out_size_a, out_size_b = 10, 8, 5, 4
    shared_head = L.Linear(in_size, hidden_size)
    model_a = HeadTailModel(shared_head, hidden_size, out_size_a)
    model_b = HeadTailModel(shared_head, hidden_size, out_size_b)
    # Verify head parameters share pointers
    assert id(model_a.head.W.data) == id(model_b.head.W.data)
    assert id(model_a.head.b.data) == id(model_b.head.b.data)
    # Tail parameters distinct
    assert id(model_a.tail.W.data) != id(model_b.tail.W.data)
    assert id(model_a.tail.b.data) != id(model_b.tail.b.data)
    # Deepcopy each model separately
    dcopy_a = copy.deepcopy(model_a)
    dcopy_b = copy.deepcopy(model_b)
    # After deepcopy, head no longer shares parameters
    assert id(dcopy_a.head.W.data) != id(dcopy_b.head.W.data)
    # Deepcopy as ChainList retains sharing
    chain_list_a = chainer.ChainList(model_a)
    chain_list_b = chainer.ChainList(model_b)
    dcopy_chain_a = copy.deepcopy(chain_list_a)
    dcopy_chain_b = copy.deepcopy(chain_list_b)
    # Heads still share within each chain
    assert id(dcopy_chain_a[0].head.W.data) == id(dcopy_chain_b[0].head.W.data)


def _increment_counter(counter, n):
    for _ in range(n):
        with counter.get_lock():
            counter.value += 1


def test_multiprocessing_counter():
    counter = mp.Value("i", 0)
    processes = []
    for _ in range(4):
        p = async_.run_async(_increment_counter, counter, 1000)
        processes.append(p)
    for p in processes:
        p.join()
    assert counter.value == 4000


def _exit_code_0():
    sys.exit(0)


def _segfault():
    os.kill(os.getpid(), signal.SIGSEGV)


def test_exit_code_warning():
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        async_.run_async(_exit_code_0)
    assert any(
        issubclass(warning.message.__class__, async_.AbnormalExitWarning)
        for warning in w
    )
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        async_.run_async(_segfault)
    assert any(
        issubclass(warning.message.__class__, async_.AbnormalExitWarning)
        for warning in w
    )
```