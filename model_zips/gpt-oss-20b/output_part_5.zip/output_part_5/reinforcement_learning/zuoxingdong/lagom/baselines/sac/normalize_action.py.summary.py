import gym
import numpy as np
from gym import spaces

class NormalizeAction(gym.ActionWrapper):
    def __init__(self, env):
        super().__init__(env)
        if not isinstance(env.action_space, spaces.Box):
            raise TypeError(
                f"NormalizeAction wrapper requires a continuous Box action space, "
                f"but received {type(env.action_space).__name__}"
            )
        self.low = np.array(env.action_space.low, dtype=np.float32)
        self.high = np.array(env.action_space.high, dtype=np.float32)

    def action(self, action):
        action = np.asarray(action, dtype=np.float32)
        if action.shape != self.low.shape:
            raise ValueError(
                f"Expected action shape {self.low.shape}, but got {action.shape}"
            )
        # Transform from [-1, 1] to [low, high]
        scaled = self.low + (1.0 + action) * (self.high - self.low) / 2.0
        # Clip to avoid numerical issues
        clipped = np.clip(scaled, self.low, self.high)
        return clipped

    def reverse_action(self, action):
        # Optional: transform from env space back to [-1, 1] if needed
        scaled = (action - self.low) * 2.0 / (self.high - self.low) - 1.0
        return np.clip(scaled, -1.0, 1.0)