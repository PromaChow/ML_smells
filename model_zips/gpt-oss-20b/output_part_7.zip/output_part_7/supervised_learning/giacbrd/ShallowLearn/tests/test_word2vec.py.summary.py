import pickle
import random
from dataclasses import dataclass
from typing import List, Iterable, Dict, Tuple

import numpy as np
import pytest


@dataclass
class LabeledWord2Vec:
    iter: int = 5
    size: int = 100
    min_count: int = 1
    negative: int = 5
    seed: int = 123
    loss: str = "hs"

    vocab: Dict[str, int] = None
    lvocab: Dict[str, int] = None
    syn0: np.ndarray = None
    syn1: np.ndarray = None

    def __post_init__(self):
        random.seed(self.seed)
        np.random.seed(self.seed)

    def build_vocab(self, samples: Iterable[List[str]], labels: Iterable[Iterable[str]]) -> None:
        vocab_set = set()
        lvocab_set = set()
        for sample in samples:
            vocab_set.update(sample)
        for lbls in labels:
            lvocab_set.update(lbls)
        self.vocab = {word: i for i, word in enumerate(sorted(vocab_set))}
        self.lvocab = {lbl: i for i, lbl in enumerate(sorted(lvocab_set))}
        self.syn0 = np.random.randn(len(self.vocab), self.size)
        self.syn1 = np.random.randn(len(self.lvocab), self.size)

    def train(self, data: Iterable[Tuple[List[str], Iterable[str]]]) -> None:
        # Dummy training: just shuffles syn0 a bit
        for _ in range(self.iter):
            np.random.shuffle(self.syn0)

    def score_document_labeled_cbow(self, doc: List[str], labels: Iterable[str]) -> List[float]:
        indices = [self.vocab[w] for w in doc if w in self.vocab]
        if not indices:
            avg_vec = np.zeros(self.size)
        else:
            avg_vec = np.mean(self.syn0[indices], axis=0)
        logits = self.syn1.dot(avg_vec)
        probs = np.exp(logits - np.max(logits))
        probs /= probs.sum()
        return probs.tolist()


# Sample dataset
dataset_samples = [
    ["the", "quick", "brown", "fox"],
    ["jumps", "over", "the", "lazy", "dog"],
    ["hello", "world"],
    ["foo", "bar", "baz"],
]
dataset_targets = [
    ["aa", "b"],
    ["b", "cc"],
    ["aa", "cc"],
    ["b"],
]

@pytest.fixture(scope="module")
def small_model():
    model = LabeledWord2Vec(iter=1, size=30, min_count=1, negative=5, seed=42)
    model.build_vocab(dataset_samples, dataset_targets)
    model.train(zip(dataset_samples, dataset_targets))
    return model


@pytest.fixture(scope="module")
def bunch_of_models():
    configs = [
        {"iter": 1, "size": 30, "loss": "hs", "negative": 5, "bucket": 0, "min_count": 1},
        {"iter": 2, "size": 50, "loss": "ns", "negative": 10, "bucket": 1, "min_count": 2},
        {"iter": 3, "size": 20, "loss": "hs", "negative": 0, "bucket": 2, "min_count": 1},
    ]
    models = []
    for cfg in configs:
        m = LabeledWord2Vec(**cfg)
        m.build_vocab(dataset_samples, dataset_targets)
        m.train(zip(dataset_samples, dataset_targets))
        models.append(m)
    return models


def test_init():
    a = LabeledWord2Vec(iter=5, size=100, seed=1)
    b = LabeledWord2Vec(iter=5, size=100, seed=2)
    c = LabeledWord2Vec(iter=10, size=100, seed=1)
    assert a is not b
    assert a is not c
    assert b is not c


def test_vocabulary(small_model):
    assert "to" not in small_model.vocab
    assert "the" in small_model.vocab
    assert small_model.lvocab.get("aa") is not None
    assert small_model.lvocab.get("b") is not None
    assert small_model.lvocab.get("cc") is not None
    assert sorted(small_model.lvocab.keys()) == ["aa", "b", "cc"]


def test_matrices(small_model):
    assert small_model.syn1.shape == (3, 30)
    assert not hasattr(small_model, "syn1neg")


def test_serializzation(small_model):
    stream = pickle.dumps(small_model)
    loaded = pickle.loads(stream)
    assert loaded.vocab == small_model.vocab
    assert loaded.lvocab == small_model.lvocab
    np.testing.assert_array_equal(loaded.syn0, small_model.syn0)
    np.testing.assert_array_equal(loaded.syn1, small_model.syn1)


def test_learning_functions(bunch_of_models):
    for model in bunch_of_models:
        probs = model.score_document_labeled_cbow(dataset_samples[0], dataset_targets[0])
        assert abs(sum(probs) - 1.0) < 1e-6
        assert len(probs) == len(model.lvocab)
        assert all(p >= 0 for p in probs)
```