import numpy as np
import random

class Entity:
    def __init__(self, name=""):
        self.name = name
        self.size = 0.05
        self.max_speed = 1.0
        self.max_accel = 1.0
        self.color = np.array([1, 1, 1])
        self.collide = True
        self.movable = True
        self.pos = np.zeros(2)
        self.vel = np.zeros(2)
        self.accel = np.zeros(2)
        self.comms = np.zeros(0)

class Agent(Entity):
    def __init__(self, name="", adversary=False, dim_c=0):
        super().__init__(name)
        self.adversary = adversary
        self.comms = np.zeros(dim_c)

class Landmark(Entity):
    def __init__(self, name=""):
        super().__init__(name)
        self.movable = False

class Food(Entity):
    def __init__(self, name=""):
        super().__init__(name)
        self.collide = False

class Forest(Entity):
    def __init__(self, name=""):
        super().__init__(name)
        self.collide = False

class World:
    def __init__(self):
        self.dim_c = 4
        self.agents = []
        self.landmarks = []
        self.foods = []
        self.forests = []

        # Create good agents
        for i in range(2):
            a = Agent(name=f"good_{i}", adversary=False, dim_c=self.dim_c)
            a.size = 0.05
            a.max_speed = 1.0
            a.max_accel = 1.0
            a.color = np.array([0.0, 1.0, 0.0])
            self.agents.append(a)

        # Create adversary agents
        for i in range(4):
            a = Agent(name=f"adversary_{i}", adversary=True, dim_c=self.dim_c)
            a.size = 0.08
            a.max_speed = 0.8
            a.max_accel = 0.5
            a.color = np.array([1.0, 0.0, 0.0])
            self.agents.append(a)

        # Create landmark
        l = Landmark(name="landmark")
        l.size = 0.05
        l.color = np.array([0.5, 0.5, 0.5])
        self.landmarks.append(l)

        # Create foods
        for i in range(2):
            f = Food(name=f"food_{i}")
            f.size = 0.04
            f.color = np.array([0.0, 0.0, 1.0])
            self.foods.append(f)

        # Create forests
        for i in range(2):
            f = Forest(name=f"forest_{i}")
            f.size = 0.1
            f.color = np.array([0.2, 0.8, 0.2])
            self.forests.append(f)

        self.reset()

    def reset(self):
        for a in self.agents:
            a.pos = np.random.uniform(-1, 1, 2)
            a.vel = np.zeros(2)
        for l in self.landmarks:
            l.pos = np.random.uniform(-0.9, 0.9, 2)
        for f in self.foods:
            f.pos = np.random.uniform(-0.9, 0.9, 2)
        for fs in self.forests:
            fs.pos = np.random.uniform(-0.9, 0.9, 2)

def dist(a, b):
    return np.linalg.norm(a.pos - b.pos)

def is_collision(a, b):
    return dist(a, b) < (a.size + b.size)

def outside_boundary(a):
    return np.any(np.abs(a.pos) > 1.0)

def reward(world, agent):
    r = 0.0
    # Good agents
    if not agent.adversary:
        # Proximity to food
        for f in world.foods:
            r += 1.0 / (dist(agent, f) + 1e-4)
        # Collision with food
        for f in world.foods:
            if is_collision(agent, f):
                r += 10.0
        # Boundary penalty
        if outside_boundary(agent):
            r -= 5.0
        # Adversary proximity penalty
        for a in world.agents:
            if a.adversary:
                r -= 0.5 / (dist(agent, a) + 1e-4)
    else:
        # Adversary reward: collision with good agents
        for a in world.agents:
            if not a.adversary:
                if is_collision(agent, a):
                    r += 10.0
                else:
                    r -= 0.5 / (dist(agent, a) + 1e-4)
    return r

def observation(world, agent):
    obs = []
    # Relative positions to landmarks
    for l in world.landmarks:
        obs.append(l.pos - agent.pos)
    # Relative positions to food
    for f in world.foods:
        obs.append(f.pos - agent.pos)
    # Other agents
    for a in world.agents:
        if a is agent:
            continue
        # For non-leader adversaries inside forest, omit positions
        if a.adversary and a.name != world.agents[2].name:  # leader is adversary_2
            in_forest = any(is_collision(a, fs) for fs in world.forests)
            if in_forest:
                continue
        obs.append(a.pos - agent.pos)
        obs.append(a.vel)
    # Forest presence
    in_forest = any(is_collision(agent, fs) for fs in world.forests)
    obs.append(np.array([1.0 if in_forest else 0.0]))
    # Communication states
    for a in world.agents:
        if a is agent:
            continue
        obs.append(a.comms)
    return np.concatenate(obs)

def good_agents(world):
    return [a for a in world.agents if not a.adversary]

def adversaries(world):
    return [a for a in world.agents if a.adversary]

def benchmark_data(world):
    data = {}
    for a in adversaries(world):
        collisions = 0
        for g in good_agents(world):
            if is_collision(a, g):
                collisions += 1
        data[a.name] = collisions
    return data

if __name__ == "__main__":
    world = World()
    for step in range(10):
        for agent in world.agents:
            # Dummy random actions
            agent.vel = np.random.uniform(-agent.max_speed, agent.max_speed, 2)
            agent.pos += agent.vel
        rewards = {agent.name: reward(world, agent) for agent in world.agents}
        observations = {agent.name: observation(world, agent) for agent in world.agents}
        print(f"Step {step}")
        for name, r in rewards.items():
            print(f"  {name} reward: {r:.2f}")
        print(f"  Benchmark: {benchmark_data(world)}")