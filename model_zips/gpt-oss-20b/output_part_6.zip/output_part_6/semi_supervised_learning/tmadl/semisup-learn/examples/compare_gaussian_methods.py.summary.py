import numpy as np
import matplotlib.pyplot as plt
from sklearn.discriminant_analysis import QuadraticDiscriminantAnalysis
from sklearn.semi_supervised import SelfTrainingClassifier
from sklearn.metrics import accuracy_score

np.random.seed(42)

# -----------------------------
# Data Generation
# -----------------------------
n_points = 120
n_per_class = n_points // 2
n_labeled_per_class = 2

meandistance = 3.0
s = np.random.uniform(0, 1)
cov = np.array([[s, 0], [0, s]])

# Generate clusters
mean0 = np.array([-s * meandistance, -s * meandistance])
mean1 = np.array([s * meandistance, s * meandistance])

X0 = np.random.multivariate_normal(mean0, cov, n_per_class)
X1 = np.random.multivariate_normal(mean1, cov, n_per_class)

X = np.vstack([X0, X1])
y_true = np.array([0] * n_per_class + [1] * n_per_class)

# -----------------------------
# Label Assignment
# -----------------------------
y_labeled = -1 * np.ones_like(y_true)

# Randomly pick labeled indices
indices0 = np.random.choice(n_per_class, n_labeled_per_class, replace=False)
indices1 = np.random.choice(n_per_class, n_labeled_per_class, replace=False)

y_labeled[indices0] = 0
y_labeled[n_per_class + indices1] = 1

# -----------------------------
# Helper Functions
# -----------------------------
def evaluate_and_plot(model, X, y_true, label, ax):
    y_pred = model.predict(X)
    acc = accuracy_score(y_true, y_pred)
    ax.set_title(f"{label} (Acc: {acc:.3f})")
    plt.scatter(X[:, 0], X[:, 1], c=y_true, cmap='coolwarm', edgecolor='k', s=40, alpha=0.6)
    # Decision boundary
    x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx, yy = np.meshgrid(np.linspace(x_min, x_max, 200), np.linspace(y_min, y_max, 200))
    Z = model.predict(np.c_[xx.ravel(), yy.ravel()]).reshape(xx.shape)
    ax.contourf(xx, yy, Z, alpha=0.2, levels=[-0.5, 0.5, 1.5], colors=['blue', 'red'])
    ax.set_xlim(x_min, x_max)
    ax.set_ylim(y_min, y_max)
    ax.set_xlabel('x1')
    ax.set_ylabel('x2')
    return acc

# -----------------------------
# Purely Supervised WQDA
# -----------------------------
# Select only labeled points
X_sup = X[y_labeled != -1]
y_sup = y_labeled[y_labeled != -1]

qda = QuadraticDiscriminantAnalysis()
qda.fit(X_sup, y_sup)

# -----------------------------
# Self-Learning WQDA
# -----------------------------
self_learning = SelfTrainingClassifier(base_estimator=QuadraticDiscriminantAnalysis())
self_learning.fit(X, y_labeled)

# -----------------------------
# CPLE Learning Model (simplified)
# -----------------------------
class CPLELearningModel:
    def __init__(self, base_estimator, pessimistic=True, predict_from_probs=True):
        self.base_estimator = base_estimator
        self.pessimistic = pessimistic
        self.predict_from_probs = predict_from_probs
        self.self_trainer = SelfTrainingClassifier(base_estimator=self.base_estimator)

    def fit(self, X, y):
        self.self_trainer.fit(X, y)

    def predict(self, X):
        if not self.predict_from_probs:
            return self.self_trainer.predict(X)
        probs = self.self_trainer.predict_proba(X)
        if self.pessimistic:
            # pessimistic: choose class with lower probability
            return np.argmin(probs, axis=1)
        else:
            # optimistic: choose class with higher probability
            return np.argmax(probs, axis=1)

    def predict_proba(self, X):
        return self.self_trainer.predict_proba(X)

# Pessimistic CPLE
cple_pessimistic = CPLELearningModel(base_estimator=QuadraticDiscriminantAnalysis(),
                                     pessimistic=True, predict_from_probs=True)
cple_pessimistic.fit(X, y_labeled)

# Optimistic CPLE
cple_optimistic = CPLELearningModel(base_estimator=QuadraticDiscriminantAnalysis(),
                                    pessimistic=False, predict_from_probs=True)
cple_optimistic.fit(X, y_labeled)

# -----------------------------
# Evaluation and Plotting
# -----------------------------
fig, axes = plt.subplots(2, 2, figsize=(12, 10))

evaluate_and_plot(qda, X, y_true, "Purely Supervised WQDA", axes[0, 0])
evaluate_and_plot(self_learning, X, y_true, "Self-Learning WQDA", axes[0, 1])
evaluate_and_plot(cple_pessimistic, X, y_true, "CPLE (Pessimistic) WQDA", axes[1, 0])
evaluate_and_plot(cple_optimistic, X, y_true, "CPLE (Optimistic) WQDA", axes[1, 1])

plt.tight_layout()
plt.show(block=True)