import unittest
import tempfile
import os
import numpy as np
from chainer_rl.replay_buffer import (
    ReplayBuffer,
    EpisodicReplayBuffer,
    PrioritizedReplayBuffer,
    PrioritizedEpisodicReplayBuffer,
    ReplayBufferWithEnvID,
    EpisodicReplayBufferWithEnvID,
)
from chainer_rl.replay_buffer import batch_experiences


class ReplayBufferTest(unittest.TestCase):
    def setUp(self):
        np.random.seed(0)

    def _make_transition(self, state_id, env_id=0):
        state = np.full((4,), state_id, dtype=np.float32)
        action = np.array([state_id % 3], dtype=np.int32)
        reward = float(state_id)
        next_state = np.full((4,), state_id + 1, dtype=np.float32)
        terminal = state_id % 5 == 4
        return state, action, reward, next_state, terminal, env_id

    def test_append_and_sample(self):
        for capacity in [None, 100]:
            for num_steps in [1, 3]:
                with self.subTest(capacity=capacity, num_steps=num_steps):
                    buffer = ReplayBuffer(capacity=capacity, num_steps=num_steps)
                    # Append transitions
                    for i in range(10):
                        t = self._make_transition(i)
                        buffer.append(*t)
                    self.assertEqual(len(buffer), 10)
                    # Sample
                    batch_size = 5
                    states, actions, rewards, next_states, terminals, _ = buffer.sample(batch_size)
                    self.assertEqual(len(states), batch_size)
                    self.assertTrue(isinstance(states, np.ndarray))
                    # Validate sampled values
                    for idx, s in enumerate(states):
                        self.assertTrue(np.all(s == np.full((4,), idx, dtype=np.float32)))

    def test_terminal_handling(self):
        buffer = ReplayBuffer(capacity=20, num_steps=1)
        for i in range(10):
            t = self._make_transition(i)
            buffer.append(*t)
        # Find terminal indices
        terminals = [t[4] for t in buffer.buffer]
        self.assertTrue(any(terminals))
        # Sample terminal transitions
        indices = [i for i, t in enumerate(buffer.buffer) if t[4]]
        if indices:
            st, act, rew, nxt, term, _ = buffer._get_transition(indices[0])
            self.assertTrue(term)

    def test_stop_current_episode(self):
        buffer = ReplayBuffer(capacity=20, num_steps=1)
        for i in range(5):
            t = self._make_transition(i, env_id=0)
            buffer.append(*t)
        # Incomplete episode
        buffer.stop_current_episode()
        self.assertEqual(len(buffer), 5)

    def test_save_and_load(self):
        buffer = ReplayBuffer(capacity=50, num_steps=1)
        for i in range(15):
            t = self._make_transition(i)
            buffer.append(*t)
        with tempfile.NamedTemporaryFile(delete=False) as fp:
            path = fp.name
        buffer.save(path)
        new_buffer = ReplayBuffer(capacity=50, num_steps=1)
        new_buffer.load(path)
        os.remove(path)
        self.assertEqual(len(new_buffer), len(buffer))
        for i in range(len(buffer)):
            orig = buffer._get_transition(i)
            new = new_buffer._get_transition(i)
            self.assertTrue(all(np.allclose(a, b) for a, b in zip(orig, new)))


class EpisodicReplayBufferTest(unittest.TestCase):
    def setUp(self):
        np.random.seed(1)

    def _make_transition(self, state_id, env_id=0):
        state = np.full((4,), state_id, dtype=np.float32)
        action = np.array([state_id % 3], dtype=np.int32)
        reward = float(state_id)
        next_state = np.full((4,), state_id + 1, dtype=np.float32)
        terminal = state_id % 7 == 6
        return state, action, reward, next_state, terminal, env_id

    def test_append_and_sample(self):
        buffer = EpisodicReplayBuffer(capacity=50)
        # Append episodes of varying lengths
        episode_lengths = [10, 15, 5]
        idx = 0
        for length in episode_lengths:
            for _ in range(length):
                t = self._make_transition(idx)
                buffer.append(*t)
                idx += 1
        self.assertEqual(len(buffer), sum(episode_lengths))
        self.assertEqual(len(buffer.episodes), 3)
        # Sample a transition
        st, act, rew, nxt, term, _ = buffer.sample(1)
        self.assertEqual(len(st), 1)
        # Sample an episode
        episode = buffer.sample_episode()
        self.assertTrue(isinstance(episode, list))
        self.assertEqual(len(episode), episode_lengths[episode[0][0].astype(int)])

    def test_save_and_load(self):
        buffer = EpisodicReplayBuffer(capacity=50)
        for i in range(20):
            t = self._make_transition(i)
            buffer.append(*t)
        with tempfile.NamedTemporaryFile(delete=False) as fp:
            path = fp.name
        buffer.save(path)
        new_buffer = EpisodicReplayBuffer(capacity=50)
        new_buffer.load(path)
        os.remove(path)
        self.assertEqual(len(new_buffer), len(buffer))
        for i in range(len(buffer)):
            orig = buffer._get_transition(i)
            new = new_buffer._get_transition(i)
            self.assertTrue(all(np.allclose(a, b) for a, b in zip(orig, new)))


class PrioritizedReplayBufferTest(unittest.TestCase):
    def setUp(self):
        np.random.seed(2)

    def _make_transition(self, state_id):
        state = np.full((4,), state_id, dtype=np.float32)
        action = np.array([state_id % 3], dtype=np.int32)
        reward = float(state_id)
        next_state = np.full((4,), state_id + 1, dtype=np.float32)
        terminal = state_id % 4 == 3
        return state, action, reward, next_state, terminal

    def test_append_and_sample_with_errors(self):
        buffer = PrioritizedReplayBuffer(capacity=30, num_steps=1, normalization='batch')
        for i in range(10):
            t = self._make_transition(i)
            buffer.append(*t)
        self.assertEqual(len(buffer), 10)
        batch_size = 5
        indices, states, actions, rewards, next_states, terminals, weights = buffer.sample(batch_size)
        self.assertEqual(len(weights), batch_size)
        # Update errors
        errors = np.random.rand(batch_size)
        buffer.update_errors(indices, errors)
        # Weights should reflect errors
        new_weights = buffer.get_weights()
        self.assertTrue(np.all(new_weights >= 0))

    def test_normalization(self):
        buffer = PrioritizedReplayBuffer(capacity=30, num_steps=1, normalization='memory')
        for i in range(10):
            t = self._make_transition(i)
            buffer.append(*t)
        # Assign errors proportional to state
        errors = np.array([t[0][0] for t in buffer.buffer])
        buffer.update_errors(np.arange(10), errors)
        weights = buffer.get_weights()
        self.assertTrue(np.all(weights <= 1.0))

    def test_capacity(self):
        buffer = PrioritizedReplayBuffer(capacity=5, num_steps=1)
        for i in range(10):
            t = self._make_transition(i)
            buffer.append(*t)
        self.assertEqual(len(buffer), 5)

    def test_save_and_load(self):
        buffer = PrioritizedReplayBuffer(capacity=20, num_steps=1)
        for i in range(15):
            t = self._make_transition(i)
            buffer.append(*t)
        with tempfile.NamedTemporaryFile(delete=False) as fp:
            path = fp.name
        buffer.save(path)
        new_buffer = PrioritizedReplayBuffer(capacity=20, num_steps=1)
        new_buffer.load(path)
        os.remove(path)
        self.assertEqual(len(new_buffer), len(buffer))
        for i in range(len(buffer)):
            orig = buffer._get_transition(i)
            new = new_buffer._get_transition(i)
            self.assertTrue(all(np.allclose(a, b) for a, b in zip(orig, new)))


class PrioritizedEpisodicReplayBufferTest(unittest.TestCase):
    def setUp(self):
        np.random.seed(3)

    def _make_transition(self, state_id):
        state = np.full((4,), state_id, dtype=np.float32)
        action = np.array([state_id % 3], dtype=np.int32)
        reward = float(state_id)
        next_state = np.full((4,), state_id + 1, dtype=np.float32)
        terminal = state_id % 6 == 5
        return state, action, reward, next_state, terminal

    def test_append_and_sample(self):
        buffer = PrioritizedEpisodicReplayBuffer(capacity=50, normalization='batch')
        # Append episodes
        lengths = [8, 12, 5]
        idx = 0
        for length in lengths:
            for _ in range(length):
                t = self._make_transition(idx)
                buffer.append(*t)
                idx += 1
        self.assertEqual(len(buffer), sum(lengths))
        # Sample an episode
        episode = buffer.sample_episode()
        self.assertTrue(isinstance(episode, list))
        self.assertEqual(len(episode), episode[0][0].astype(int))

    def test_priority_updates_and_weights(self):
        buffer = PrioritizedEpisodicReplayBuffer(capacity=30, normalization='memory')
        for i in range(15):
            t = self._make_transition(i)
            buffer.append(*t)
        # Update errors
        errors = np.arange(15, dtype=np.float32)
        buffer.update_errors(np.arange(15), errors)
        weights = buffer.get_weights()
        self.assertTrue(np.all(weights >= 0))

    def test_save_and_load(self):
        buffer = PrioritizedEpisodicReplayBuffer(capacity=20, normalization='batch')
        for i in range(10):
            t = self._make_transition(i)
            buffer.append(*t)
        with tempfile.NamedTemporaryFile(delete=False) as fp:
            path = fp.name
        buffer.save(path)
        new_buffer = PrioritizedEpisodicReplayBuffer(capacity=20, normalization='batch')
        new_buffer.load(path)
        os.remove(path)
        self.assertEqual(len(new_buffer), len(buffer))
        for i in range(len(buffer)):
            orig = buffer._get_transition(i)
            new = new_buffer._get_transition(i)
            self.assertTrue(all(np.allclose(a, b) for a, b in zip(orig, new)))


class ReplayBufferWithEnvIDTest(unittest.TestCase):
    def setUp(self):
        np.random.seed(4)

    def _make_transition(self, state_id, env_id):
        state = np.full((4,), state_id, dtype=np.float32)
        action = np.array([state_id % 3], dtype=np.int32)
        reward = float(state_id)
        next_state = np.full((4,), state_id + 1, dtype=np.float32)
        terminal = state_id % 5 == 4
        return state, action, reward, next_state, terminal, env_id

    def test_env_id_tracking(self):
        buffer = ReplayBufferWithEnvID(capacity=50, num_steps=1)
        # Append transitions for env 0 and 1
        for i in range(10):
            t = self._make_transition(i, env_id=0)
            buffer.append(*t)
        for i in range(5):
            t = self._make_transition(i + 10, env_id=1)
            buffer.append(*t)
        self.assertEqual(len(buffer), 15)
        # Stop current episode for env 0
        buffer.stop_current_episode(env_id=0)
        self.assertEqual(len(buffer), 15)  # no change for full episodes

    def test_save_and_load(self):
        buffer = ReplayBufferWithEnvID(capacity=20, num_steps=1)
        for i in range(8):
            t = self._make_transition(i, env_id=0)
            buffer.append(*t)
        with tempfile.NamedTemporaryFile(delete=False) as fp:
            path = fp.name
        buffer.save(path)
        new_buffer = ReplayBufferWithEnvID(capacity=20, num_steps=1)
        new_buffer.load(path)
        os.remove(path)
        self.assertEqual(len(new_buffer), len(buffer))


class EpisodicReplayBufferWithEnvIDTest(unittest.TestCase):
    def setUp(self):
        np.random.seed(5)

    def _make_transition(self, state_id, env_id):
        state = np.full((4,), state_id, dtype=np.float32)
        action = np.array([state_id % 3], dtype=np.int32)
        reward = float(state_id)
        next_state = np.full((4,), state_id + 1, dtype=np.float32)
        terminal = state_id % 4 == 3
        return state, action, reward, next_state, terminal, env_id

    def test_env_id_episode_tracking(self):
        buffer = EpisodicReplayBufferWithEnvID(capacity=50)
        for i in range(6):
            t = self._make_transition(i, env_id=0)
            buffer.append(*t)
        for i in range(4):
            t = self._make_transition(i + 6, env_id=1)
            buffer.append(*t)
        self.assertEqual(len(buffer.episodes), 2)
        self.assertEqual(len(buffer), 10)

    def test_save_and_load(self):
        buffer = EpisodicReplayBufferWithEnvID(capacity=20)
        for i in range(10):
            t = self._make_transition(i, env_id=0)
            buffer.append(*t)
        with tempfile.NamedTemporaryFile(delete=False) as fp:
            path = fp.name
        buffer.save(path)
        new_buffer = EpisodicReplayBufferWithEnvID(capacity=20)
        new_buffer.load(path)
        os.remove(path)
        self.assertEqual(len(new_buffer), len(buffer))


class TestReplayBufferFail(unittest.TestCase):
    def setUp(self):
        self.buffer = ReplayBuffer(capacity=10, num_steps=1)

    def test_update_errors_without_sampling(self):
        with self.assertRaises(RuntimeError):
            self.buffer.update_errors([0], [1.0])

    def test_multiple_updates(self):
        self.buffer.append(np.array([0.0]), np.array([0]), 0.0, np.array([1.0]), False, 0)
        indices, _, _, _, _, _, _ = self.buffer.sample(1)
        self.buffer.update_errors(indices, [1.0])
        with self.assertRaises(RuntimeError):
            self.buffer.update_errors(indices, [0.5])


class TestBatchExperiences(unittest.TestCase):
    def test_batch_experiences(self):
        # Create episodes
        episodes = []
        for ep in range(3):
            ep_len = 5 + ep
            ep_data = []
            for t in range(ep_len):
                state = np.full((4,), t, dtype=np.float32)
                action = np.array([t % 2], dtype=np.int32)
                reward = float(t)
                next_state = np.full((4,), t + 1, dtype=np.float32)
                terminal = t == ep_len - 1
                ep_data.append((state, action, reward, next_state, terminal))
            episodes.append(ep_data)
        batch = batch_experiences(episodes, gamma=0.99)
        self.assertIn('states', batch)
        self.assertIn('discount', batch)
        self.assertIn('next_states', batch)
        self.assertIn('is_state_terminal', batch)
        # Verify discount calculation
        discounts = batch['discount']
        self.assertTrue(np.all(discounts <= 1.0))
        self.assertTrue(np.all(discounts >= 0.0))


if __name__ == '__main__':
    unittest.main()
