import torch
import torch.nn as nn
import torch.nn.functional as F


class PL(nn.Module):
    def __init__(self, threshold: float = 0.5):
        super().__init__()
        self.th = threshold

    def __make_one_hot(self, labels: torch.Tensor) -> torch.Tensor:
        """Convert class indices to one‑hot encoded tensor."""
        num_classes = 10
        device = labels.device
        dtype = torch.float32
        one_hot = torch.eye(num_classes, device=device, dtype=dtype)[labels]
        return one_hot

    def forward(
        self,
        x: torch.Tensor,
        y: torch.Tensor,
        model: nn.Module,
        mask: torch.Tensor,
    ) -> torch.Tensor:
        # 1. Softmax probabilities
        y_probs = F.softmax(y, dim=1)

        # 2. One‑hot labels
        _, preds = y_probs.max(dim=1)
        onehot_label = self.__make_one_hot(preds)

        # 3. Threshold masks
        gt_mask = (y_probs > self.th).max(dim=1)[0]  # shape: (batch,)
        lt_mask = ~gt_mask

        # 4. Target probability construction
        p_target = torch.where(
            gt_mask.unsqueeze(1),
            onehot_label * 10.0,
            y_probs,
        )

        # 5. Model execution with batch stats disabled
        if hasattr(model, "update_batch_stats"):
            model.update_batch_stats(False)
        output = model(x)
        if hasattr(model, "update_batch_stats"):
            model.update_batch_stats(True)

        # 6. Loss calculation
        log_probs = F.log_softmax(output, dim=1)
        loss_per_sample = (log_probs * p_target.detach()).sum(dim=1) * mask
        denom = mask.sum()
        loss = loss_per_sample.sum() / (denom + 1e-8)

        return loss

# Example usage (requires a model with update_batch_stats method):
# model = SomeModel()
# criterion = PL(threshold=0.7)
# loss = criterion(input_tensor, logits, model, mask_tensor)