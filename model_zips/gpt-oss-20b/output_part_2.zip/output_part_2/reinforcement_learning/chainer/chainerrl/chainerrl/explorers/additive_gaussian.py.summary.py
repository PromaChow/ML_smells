import numpy as np


class AdditiveGaussian:
    def __init__(self, scale, low=None, high=None):
        """
        Initialize the additive Gaussian noise explorer.

        Parameters
        ----------
        scale : float
            Standard deviation of the Gaussian noise.
        low : scalar or array-like, optional
            Lower bound for clipping actions. If None, no lower bound is applied.
        high : scalar or array-like, optional
            Upper bound for clipping actions. If None, no upper bound is applied.
        """
        self.scale = float(scale)
        self.low = np.array(low) if low is not None else None
        self.high = np.array(high) if high is not None else None

    def select_action(self, greedy_action_func):
        """
        Generate an action by adding Gaussian noise to the greedy action.

        Parameters
        ----------
        greedy_action_func : callable
            Function that returns the greedy action (without noise).

        Returns
        -------
        numpy.ndarray or scalar
            The noisy action, clipped to the specified bounds if provided.
        """
        greedy_action = greedy_action_func()
        noise = np.random.normal(loc=0.0, scale=self.scale, size=np.shape(greedy_action))
        noisy_action = greedy_action + noise

        if self.low is not None or self.high is not None:
            low_bound = self.low if self.low is not None else -np.inf
            high_bound = self.high if self.high is not None else np.inf
            noisy_action = np.clip(noisy_action, low=low_bound, high=high_bound)

        return noisy_action

    def __repr__(self):
        return f"AdditiveGaussian(scale={self.scale}, low={self.low}, high={self.high})"