import random
import numpy as np
import matplotlib.pyplot as plt
from collections import deque


class ClassicalTrainer:
    def __init__(
        self,
        agent,
        env,
        mode="learn",
        *,
        n_episodes=1000,
        planning_steps=10,
        start_steps=1000,
        start_plan=5000,
        evaluate_frequency=100,
        window_size=10,
        seed=42,
        model_class=None,
    ):
        self.agent = agent
        self.env = env
        self.mode = mode.lower()
        self.learn = self.mode in ("learn", "dyna")
        self.plan = self.mode in ("plan", "dyna")
        self.n_episodes = n_episodes
        self.planning_steps = planning_steps
        self.start_steps = start_steps
        self.start_plan = start_plan
        self.evaluate_frequency = evaluate_frequency
        self.window_size = window_size
        self.seed = seed
        self.model = None

        if self.plan and model_class is not None:
            self.model = model_class()

        random.seed(self.seed)
        np.random.seed(self.seed)

        self.total_steps = 0
        self.episode_rewards = []

    def train(self):
        for episode in range(1, self.n_episodes + 1):
            state = self.env.reset()
            episode_reward = 0
            done = False
            while not done:
                if self.total_steps < self.start_steps:
                    action = self.env.action_space.sample()
                else:
                    action = self.agent.get_action(state, exploration=False)

                next_state, reward, done, _ = self.env.step(action)
                episode_reward += reward

                if self.learn:
                    self.agent.update(state, action, reward, next_state)

                if self.plan and self.model is not None:
                    self.model.update(state, action, reward, next_state)
                    if self.total_steps > self.start_plan:
                        for _ in range(self.planning_steps):
                            s, a, r, s_next = self.model.sample()
                            self.agent.update(s, a, r, s_next)
                            self.model.step()

                state = next_state
                self.total_steps += 1

            self.episode_rewards.append(episode_reward)

            if episode % self.evaluate_frequency == 0:
                mean, std = self.evaluate()
                print(
                    f"Episode {episode}: Eval mean {mean:.2f} +/- {std:.2f}"
                )

        self.plot()

    def evaluate(self, n_eval_episodes=100):
        rewards = []
        for _ in range(n_eval_episodes):
            state = self.env.reset()
            done = False
            episode_reward = 0
            while not done:
                action = self.agent.get_action(state, exploration=False)
                next_state, reward, done, _ = self.env.step(action)
                episode_reward += reward
                state = next_state
            rewards.append(episode_reward)

        mean = np.mean(rewards)
        std = np.std(rewards)
        self.agent.mean_reward = mean
        return mean, std

    def plot(self):
        rewards = np.array(self.episode_rewards)
        if len(rewards) >= self.window_size:
            smoothed = np.convolve(
                rewards, np.ones(self.window_size) / self.window_size, mode="valid"
            )
            plt.figure(figsize=(10, 5))
            plt.plot(smoothed, label="Smoothed Reward")
            plt.xlabel("Episode")
            plt.ylabel("Reward")
            plt.title("Training Performance")
            plt.legend()
            plt.tight_layout()
            plt.show()