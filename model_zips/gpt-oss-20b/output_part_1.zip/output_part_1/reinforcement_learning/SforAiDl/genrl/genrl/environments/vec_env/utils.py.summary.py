import numpy as np

class RunningMeanStd:
    def __init__(self, epsilon: float, shape: tuple):
        self.epsilon = epsilon
        self.mean = np.zeros(shape, dtype=np.float64)
        self.var = np.ones(shape, dtype=np.float64)
        self.count = epsilon

    def update(self, batch: np.ndarray) -> None:
        batch_mean = np.mean(batch, axis=0)
        batch_var = np.var(batch, axis=0, ddof=0)
        batch_count = batch.shape[0]
        total_count = self.count + batch_count

        delta = batch_mean - self.mean
        new_mean = self.mean + delta * batch_count / total_count

        M2 = (
            self.var * self.count
            + batch_var * batch_count
            + (delta ** 2) * self.count * batch_count / total_count
        )
        new_var = M2 / (total_count - 1)

        self.mean = new_mean
        self.var = new_var
        self.count = total_count
