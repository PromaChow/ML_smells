import os
import glob
import numpy as np
import tensorflow as tf
import importlib

tf.compat.v1.disable_eager_execution()

def parse_tfrecord_tf(example_proto):
    features = {
        'image_raw': tf.io.FixedLenFeature([], tf.string),
        'height': tf.io.FixedLenFeature([], tf.int64),
        'width': tf.io.FixedLenFeature([], tf.int64),
        'channels': tf.io.FixedLenFeature([], tf.int64),
        'label': tf.io.FixedLenFeature([], tf.int64)
    }
    parsed = tf.io.parse_single_example(example_proto, features)
    image = tf.io.decode_raw(parsed['image_raw'], tf.uint8)
    shape = tf.stack([parsed['height'], parsed['width'], parsed['channels']])
    image = tf.reshape(image, shape)
    label = parsed['label']
    return image, label

class TFRecordDataset:
    def __init__(self, data_dir, label_file=None, resolution=None, minibatch_size=32, lod=0):
        self.data_dir = data_dir
        if not os.path.isdir(data_dir):
            raise ValueError(f"Directory {data_dir} does not exist")
        self.tfrecord_files = sorted(glob.glob(os.path.join(data_dir, '*.tfrecords')))
        if not self.tfrecord_files:
            raise ValueError("No tfrecords files found")
        self.label_file = label_file
        self.labels = None
        self.label_tf = None
        if label_file is None:
            label_candidates = sorted(glob.glob(os.path.join(data_dir, '*.labels')))
            if label_candidates:
                self.label_file = label_candidates[0]
        if self.label_file:
            with open(self.label_file, 'r') as f:
                self.labels = np.array([line.strip() for line in f if line.strip()], dtype=np.int64)
            self.label_tf = tf.constant(self.labels)
        self._detect_shapes_and_resolution(resolution)
        self.minibatch_size = minibatch_size
        self.lod = lod
        self._build_pipelines()
        self.session = tf.compat.v1.Session()
        self.session.run(tf.compat.v1.global_variables_initializer())
        self.session.run(self.iterator.initializer)

    def _detect_shapes_and_resolution(self, resolution):
        self.file_shapes = {}
        max_height = 0
        max_width = 0
        with tf.compat.v1.Session() as sess:
            for file_path in self.tfrecord_files:
                dataset = tf.data.TFRecordDataset(file_path)
                iterator = tf.compat.v1.data.make_one_shot_iterator(dataset)
                example = iterator.get_next()
                image, _ = parse_tfrecord_tf(example)
                shape = sess.run(tf.shape(image))
                h, w, _ = shape
                self.file_shapes[file_path] = (h, w)
                max_height = max(max_height, h)
                max_width = max(max_width, w)
        self.max_resolution = max(max_height, max_width)
        if resolution is None:
            self.resolution = self.max_resolution
        else:
            self.resolution = resolution
        for h, w in self.file_shapes.values():
            if max(h, w) != self.resolution:
                raise ValueError("All tfrecord files must match the resolution hierarchy")

    def _build_pipelines(self):
        ds = tf.data.TFRecordDataset(self.tfrecord_files)
        ds = ds.map(parse_tfrecord_tf, num_parallel_calls=tf.data.AUTOTUNE)
        ds = ds.shuffle(buffer_size=1000)
        ds = ds.repeat()
        if self.labels is not None:
            label_ds = tf.data.Dataset.from_tensor_slices(self.label_tf)
            label_ds = label_ds.shuffle(buffer_size=1000).repeat()
            ds = tf.data.Dataset.zip((ds, label_ds))
        ds = ds.batch(self.minibatch_size)
        ds = ds.prefetch(tf.data.AUTOTUNE)
        self.final_ds = ds
        self.iterator = tf.compat.v1.data.make_initializable_iterator(self.final_ds)
        self.next_element = self.iterator.get_next()

    def configure(self, minibatch_size=None, lod=None):
        if minibatch_size is not None:
            self.minibatch_size = minibatch_size
        if lod is not None:
            self.lod = lod
        self._build_pipelines()
        self.session.run(self.iterator.initializer)

    def get_minibatch_tf(self):
        return self.next_element

    def get_minibatch_np(self):
        return self.session.run(self.next_element)

    def get_random_labels_tf(self, num_samples):
        if self.label_tf is None:
            raise ValueError("No labels loaded")
        indices = tf.random.uniform([num_samples], minval=0, maxval=tf.shape(self.label_tf)[0], dtype=tf.int64)
        return tf.gather(self.label_tf, indices)

    def get_random_labels_np(self, num_samples):
        return self.session.run(self.get_random_labels_tf(num_samples))

class SyntheticDataset:
    def __init__(self, resolution=64, shape=None, dtype=tf.uint8, num_classes=10, minibatch_size=32, lod=0):
        self.resolution = resolution
        self.shape = shape if shape else (resolution, resolution, 3)
        self.dtype = dtype
        self.num_classes = num_classes
        self.minibatch_size = tf.Variable(minibatch_size, dtype=tf.int32, trainable=False)
        self.lod = tf.Variable(lod, dtype=tf.int32, trainable=False)

    def configure(self, minibatch_size=None, lod=None):
        if minibatch_size is not None:
            self.minibatch_size.assign(minibatch_size)
        if lod is not None:
            self.lod.assign(lod)

    def get_minibatch_tf(self):
        batch_size = self.minibatch_size
        images = self._generate_images(batch_size)
        labels = self._generate_labels(batch_size)
        return images, labels

    def _generate_images(self, batch_size):
        shape = tf.concat([[batch_size], tf.constant(self.shape, dtype=tf.int32)], axis=0)
        return tf.random.uniform(shape, minval=0, maxval=256, dtype=tf.float32)

    def _generate_labels(self, batch_size):
        return tf.random.uniform([batch_size], minval=0, maxval=self.num_classes, dtype=tf.int32)

def load_dataset(data_dir, dataset_class_name, **kwargs):
    if not os.path.isdir(data_dir):
        raise ValueError(f"Data directory {data_dir} does not exist")
    module = importlib.import_module(__name__)
    cls = getattr(module, dataset_class_name)
    return cls(data_dir=data_dir, **kwargs)