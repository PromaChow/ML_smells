import numpy as np
import chainer.functions as F
from chainerrl.explorer import Explorer
from chainerrl.action_value import DiscreteActionValue


class Boltzmann(Explorer):
    def __init__(self, T=1.0):
        super().__init__()
        self.T = T

    def select_action(self, action_value):
        assert isinstance(action_value, DiscreteActionValue)
        n_actions = action_value.q_values.shape[1]
        probs = F.softmax(action_value.q_values / self.T).array
        probs = probs.ravel()
        return np.random.choice(n_actions, p=probs)

    def __repr__(self):
        return f'Boltzmann(T={self.T})'