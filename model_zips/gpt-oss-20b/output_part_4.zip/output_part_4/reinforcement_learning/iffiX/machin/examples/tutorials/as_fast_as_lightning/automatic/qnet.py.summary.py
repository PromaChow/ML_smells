import torch
import torch.nn as nn
import torch.nn.functional as F

class QNet(nn.Module):
    def __init__(self, state_dim: int, action_num: int):
        super().__init__()
        self.fc1 = nn.Linear(state_dim, 16)
        self.fc2 = nn.Linear(16, 16)
        self.fc3 = nn.Linear(16, action_num)

    def forward(self, state: torch.Tensor) -> torch.Tensor:
        x = self.fc1(state)
        x = F.relu(x)
        x = self.fc2(x)
        x = F.relu(x)
        x = self.fc3(x)
        return x

if __name__ == "__main__":
    # Example usage
    net = QNet(state_dim=10, action_num=4)
    sample_state = torch.randn(1, 10)
    output = net(sample_state)
    print(output.shape)