import unittest
import torch
import torch.nn as nn
from machin import check_shape, check_nan, check_model, TensorBoard, mark_as_atom_module, mark_module_output, CheckError

# Global flag for parameter check hook
param_checked = False

def param_check_hook(params):
    global param_checked
    param_checked = True

def p_chk_nan(params):
    for name, p in params:
        check_nan(p)

def p_chk_range(params):
    for name, p in params:
        if torch.any(p < -10) or torch.any(p > 10):
            raise CheckError(f"Parameter {name} out of range")

@mark_as_atom_module
@mark_module_output
class SubModule1(nn.Module):
    def __init__(self):
        super().__init__()
        self.linear1 = nn.Linear(5, 5)
        self.linear2 = nn.Linear(5, 5)

    def forward(self, x):
        x = self.linear1(x)
        return self.linear2(x)

class SubModule2(nn.Module):
    def __init__(self):
        super().__init__()
        self.linear = nn.Linear(5, 5)

    def forward(self, x):
        return self.linear(x)

class CheckedModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.sub1 = SubModule1()
        self.sub2 = SubModule2()

    def forward(self, x):
        x = self.sub1(x)
        return self.sub2(x)

class TestMachinTensorChecks(unittest.TestCase):
    def test_shape_check(self):
        tensor = torch.randn(10, 10)
        with self.assertRaises(CheckError) as cm:
            check_shape(tensor, [5, 5])
        self.assertIn("has invalid shape", str(cm.exception))

    def test_nan_check(self):
        tensor = torch.full((10, 10), float('nan'))
        with self.assertRaises(CheckError) as cm:
            check_nan(tensor)
        self.assertIn("contains nan", str(cm.exception))

    def test_parameter_monitoring(self):
        tb = TensorBoard()
        model = CheckedModel()
        cancel = check_model(
            model,
            check_param_interval=1,
            hooks=[param_check_hook, p_chk_nan, p_chk_range],
            logger=tb
        )
        x = torch.ones(1, 5)
        out = model(x)
        out.sum().backward()
        cancel()
        self.assertTrue(param_checked)

if __name__ == "__main__":
    unittest.main()