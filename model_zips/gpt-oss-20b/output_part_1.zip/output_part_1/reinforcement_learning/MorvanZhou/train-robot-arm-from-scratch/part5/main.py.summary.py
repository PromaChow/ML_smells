import gym
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import random
from collections import deque

# Hyperparameters
MAX_EPISODES = 500
MAX_EP_STEPS = 200
MEMORY_SIZE = 100000
BATCH_SIZE = 64
GAMMA = 0.99
TAU = 0.005
LR_ACTOR = 1e-4
LR_CRITIC = 1e-3
NOISE_STD = 0.2
NOISE_SEED = 0

# Actor network
class Actor(nn.Module):
    def __init__(self, s_dim, a_dim, a_bound):
        super(Actor, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(s_dim, 400),
            nn.ReLU(),
            nn.Linear(400, 300),
            nn.ReLU(),
            nn.Linear(300, a_dim),
            nn.Tanh()
        )
        self.a_bound = a_bound

    def forward(self, s):
        return self.net(s) * self.a_bound

# Critic network
class Critic(nn.Module):
    def __init__(self, s_dim, a_dim):
        super(Critic, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(s_dim + a_dim, 400),
            nn.ReLU(),
            nn.Linear(400, 300),
            nn.ReLU(),
            nn.Linear(300, 1)
        )

    def forward(self, s, a):
        return self.net(torch.cat([s, a], dim=1))

# Ornstein-Uhlenbeck noise
class OUNoise:
    def __init__(self, size, seed=NOISE_SEED, mu=0.0, theta=0.15, sigma=0.2):
        self.size = size
        self.mu = mu * np.ones(self.size)
        self.theta = theta
        self.sigma = sigma
        self.seed = random.seed(seed)
        self.reset()

    def reset(self):
        self.state = np.copy(self.mu)

    def sample(self):
        dx = self.theta * (self.mu - self.state) + self.sigma * np.random.randn(self.size)
        self.state += dx
        return self.state

# DDPG Agent
class DDPG:
    def __init__(self, s_dim, a_dim, a_bound):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.actor = Actor(s_dim, a_dim, a_bound).to(self.device)
        self.actor_target = Actor(s_dim, a_dim, a_bound).to(self.device)
        self.actor_target.load_state_dict(self.actor.state_dict())
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=LR_ACTOR)

        self.critic = Critic(s_dim, a_dim).to(self.device)
        self.critic_target = Critic(s_dim, a_dim).to(self.device)
        self.critic_target.load_state_dict(self.critic.state_dict())
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=LR_CRITIC)

        self.memory = deque(maxlen=MEMORY_SIZE)
        self.noise = OUNoise(a_dim)

    def get_action(self, state, noise=True):
        state = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        self.actor.eval()
        with torch.no_grad():
            action = self.actor(state).cpu().numpy().flatten()
        self.actor.train()
        if noise:
            action += self.noise.sample()
        return np.clip(action, -self.actor.a_bound, self.actor.a_bound)

    def remember(self, s, a, r, s_):
        self.memory.append((s, a, r, s_))

    def learn(self):
        if len(self.memory) < BATCH_SIZE:
            return
        batch = random.sample(self.memory, BATCH_SIZE)
        s_batch = torch.FloatTensor([b[0] for b in batch]).to(self.device)
        a_batch = torch.FloatTensor([b[1] for b in batch]).to(self.device)
        r_batch = torch.FloatTensor([b[2] for b in batch]).unsqueeze(1).to(self.device)
        s_next_batch = torch.FloatTensor([b[3] for b in batch]).to(self.device)

        with torch.no_grad():
            target_q = self.critic_target(s_next_batch, self.actor_target(s_next_batch))
            y = r_batch + GAMMA * target_q

        current_q = self.critic(s_batch, a_batch)
        critic_loss = nn.MSELoss()(current_q, y)

        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        self.critic_optimizer.step()

        actor_loss = -self.critic(s_batch, self.actor(s_batch)).mean()
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        self.actor_optimizer.step()

        for target_param, param in zip(self.actor_target.parameters(), self.actor.parameters()):
            target_param.data.copy_(TAU * param.data + (1.0 - TAU) * target_param.data)
        for target_param, param in zip(self.critic_target.parameters(), self.critic.parameters()):
            target_param.data.copy_(TAU * param.data + (1.0 - TAU) * target_param.data)

    def save(self, path):
        torch.save({
            'actor': self.actor.state_dict(),
            'critic': self.critic.state_dict()
        }, path)

    def load(self, path):
        checkpoint = torch.load(path, map_location=self.device)
        self.actor.load_state_dict(checkpoint['actor'])
        self.critic.load_state_dict(checkpoint['critic'])
        self.actor_target.load_state_dict(self.actor.state_dict())
        self.critic_target.load_state_dict(self.critic.state_dict())

def main():
    env = gym.make('ArmEnv-v0')
    s_dim = env.observation_space.shape[0]
    a_dim = env.action_space.shape[0]
    a_bound = env.action_space.high[0]

    agent = DDPG(s_dim, a_dim, a_bound)
    model_path = 'ddpg_arm.pth'

    # Training
    for episode in range(1, MAX_EPISODES + 1):
        s = env.reset()
        ep_r = 0.0
        agent.noise.reset()
        for step in range(1, MAX_EP_STEPS + 1):
            env.render()
            a = agent.get_action(s)
            s_, r, done, _ = env.step(a)
            agent.remember(s, a, r, s_)
            ep_r += r
            agent.learn()
            s = s_
            if done:
                break
        print(f"Episode {episode} | Done: {done} | Reward: {ep_r:.2f} | Steps: {step}")
    agent.save(model_path)

    # Evaluation
    agent.load(model_path)
    env.render()
    while True:
        s = env.reset()
        for step in range(1, MAX_EP_STEPS + 1):
            env.render()
            a = agent.get_action(s, noise=False)
            s, _, done, _ = env.step(a)
            if done:
                break

if __name__ == "__main__":
    main()
