import numpy as np

def cpe(xl, y, xu, alpha):
    xl = np.asarray(xl, dtype=float)
    y = np.asarray(y)
    xu = np.asarray(xu, dtype=float)

    classes = np.unique(y)
    n_classes = len(classes)
    x = [xl[y == c] for c in classes]

    def alpha_dist(A, B):
        diff = A[:, None, :] - B[None, :, :]
        dist2 = np.sum(diff**2, axis=2)
        if alpha == 1:
            return np.sqrt(dist2)
        return dist2**(alpha / 2)

    b = np.array([2.0 * np.mean(alpha_dist(xi, xu)) for xi in x])

    A = np.empty((n_classes, n_classes))
    for i in range(n_classes):
        for j in range(n_classes):
            A[i, j] = -np.mean(alpha_dist(x[i], x[j]))

    if n_classes == 1:
        return 1.0

    As = A[:-1, :-1]
    a = A[:-1, -1]
    Ac = A[-1, -1]
    bs = b[:-1]
    bc = b[-1]

    Anew = As - a[:, None] - a[None, :] + Ac
    Anew = (Anew + Anew.T) / 2.0

    bnew = 2 * a - 2 * Ac + bs - bc

    try:
        x0 = np.linalg.solve(2 * Anew, bnew)
    except np.linalg.LinAlgError:
        x0 = np.linalg.lstsq(2 * Anew, bnew, rcond=None)[0]

    x = np.clip(x0, 0.0, 1.0)
    theta = 1.0 - np.sum(x)
    return theta

if __name__ == "__main__":
    # Example usage
    xl = np.random.randn(100, 5)
    y = np.random.choice([0, 1, 2], size=100)
    xu = np.random.randn(10, 5)
    alpha = 1.5
    print(cpe(xl, y, xu, alpha))