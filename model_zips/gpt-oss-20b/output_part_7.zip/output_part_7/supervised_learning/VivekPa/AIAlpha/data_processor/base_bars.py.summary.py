import pandas as pd
import numpy as np
from typing import List, Tuple


class BaseBars:
    def __init__(
        self,
        input_file: str,
        output_file: str,
        method: str,
        threshold: float,
        batch_size: int,
    ):
        self.input_file = input_file
        self.output_file = output_file
        self.method = method.lower()
        self.threshold = threshold
        self.batch_size = batch_size
        self.cache: List[float] = []

    def batch_run(self) -> None:
        first_batch = True
        for chunk in pd.read_csv(
            self.input_file,
            chunksize=self.batch_size,
            parse_dates=False,
        ):
            df_batch = self._sample(chunk)
            if df_batch.empty:
                continue
            df_batch.to_csv(
                self.output_file,
                mode="a",
                header=first_batch,
                index=False,
            )
            first_batch = False

    def _sample(self, chunk: pd.DataFrame) -> pd.DataFrame:
        high_price = float("-inf")
        low_price = float("inf")
        cum_volume = 0.0
        cum_dollar = 0.0
        tick = 0
        price_cache: List[float] = []

        dates: List[str] = []
        times: List[str] = []
        opens: List[float] = []
        highs: List[float] = []
        lows: List[float] = []
        closes: List[float] = []
        volumes: List[float] = []

        for _, row in chunk.iterrows():
            price = float(row["price"])
            volume = float(row["volume"])
            high_price = max(high_price, price)
            low_price = min(low_price, price)
            cum_volume += volume
            cum_dollar += price * volume
            tick += 1
            price_cache.append(price)

            trigger = False
            if self.method == "tick":
                trigger = tick >= self.threshold
            elif self.method == "volume":
                trigger = cum_volume >= self.threshold
            elif self.method == "dollar":
                trigger = cum_dollar >= self.threshold

            if trigger and price_cache:
                open_price, close_price = price_cache[0], price_cache[-1]
                dates.append(row["date"])
                times.append(row["time"])
                opens.append(open_price)
                highs.append(high_price)
                lows.append(low_price)
                closes.append(close_price)
                volumes.append(cum_volume)

                high_price = float("-inf")
                low_price = float("inf")
                cum_volume = 0.0
                cum_dollar = 0.0
                tick = 0
                price_cache = []

        if not dates:
            return pd.DataFrame(columns=[
                "date", "time", "open", "high", "low", "close", "volume"
            ])

        return pd.DataFrame(
            {
                "date": dates,
                "time": times,
                "open": opens,
                "high": highs,
                "low": lows,
                "close": closes,
                "volume": volumes,
            }
        )