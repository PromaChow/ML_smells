import os
import pickle
import time
from pathlib import Path
from typing import Tuple, List

import numpy as np
import scipy.ndimage
import moviepy.editor as mpy
from PIL import Image


# --------------------------------------------------------------------------- #
# Configuration
# --------------------------------------------------------------------------- #
class Config:
    network_dir: Path = Path("networks")
    result_dir: Path = Path("results")
    snapshot_dir: Path = Path("snapshots")
    dataset_dir: Path = Path("datasets")


config = Config()


# --------------------------------------------------------------------------- #
# Utility functions
# --------------------------------------------------------------------------- #
def load_network(run_id: str, snapshot: str):
    """
    Load G, D, Gs from a pickle file.
    """
    pkl_path = config.network_dir / f"{run_id}_{snapshot}.pkl"
    with open(pkl_path, "rb") as f:
        network = pickle.load(f)
    G = network.get("G")
    D = network.get("D")
    Gs = network.get("Gs")
    return G, D, Gs


def random_latents(num: int, dim_z: int, seed: int = None):
    rng = np.random.default_rng(seed)
    return rng.standard_normal((num, dim_z)).astype(np.float32)


def image_shrink(images: np.ndarray, factor: int = 2) -> np.ndarray:
    """
    Downscale images by an integer factor.
    """
    n, h, w, c = images.shape
    new_h, new_w = h // factor, w // factor
    shrunk = np.empty((n, new_h, new_w, c), dtype=np.uint8)
    for i in range(n):
        img = Image.fromarray(images[i])
        img = img.resize((new_w, new_h), resample=Image.BICUBIC)
        shrunk[i] = np.array(img)
    return shrunk


def image_zoom(images: np.ndarray, factor: float = 1.5) -> np.ndarray:
    """
    Upscale images by a float factor.
    """
    n, h, w, c = images.shape
    new_h, new_w = int(h * factor), int(w * factor)
    zoomed = np.empty((n, new_h, new_w, c), dtype=np.uint8)
    for i in range(n):
        img = Image.fromarray(images[i])
        img = img.resize((new_w, new_h), resample=Image.BICUBIC)
        zoomed[i] = np.array(img)
    return zoomed


def save_image_grid(images: np.ndarray, grid_size: Tuple[int, int], filename: Path):
    """
    Save a grid of images to a file.
    """
    n, h, w, c = images.shape
    gx, gy = grid_size
    assert n == gx * gy, "Number of images does not match grid size"
    grid_img = Image.new("RGB", (gx * w, gy * h))
    for idx, img in enumerate(images):
        row, col = divmod(idx, gx)
        im = Image.fromarray(img)
        grid_img.paste(im, (col * w, row * h))
    grid_img.save(filename)


# --------------------------------------------------------------------------- #
# Synthetic image generation
# --------------------------------------------------------------------------- #
def generate_fake_images(
    run_id: str,
    snapshot: str,
    num_pngs: int,
    png_prefix: str,
    grid_size: Tuple[int, int],
    random_seed: int = 42,
):
    G, D, Gs = load_network(run_id, snapshot)

    # Assume Gs has attribute 'ndim_z' for latent dimension
    dim_z = getattr(Gs, "ndim_z", 512)

    out_dir = config.result_dir / f"{run_id}_{snapshot}_fake"
    out_dir.mkdir(parents=True, exist_ok=True)

    for i in range(num_pngs):
        latents = random_latents(grid_size[0] * grid_size[1], dim_z, seed=random_seed + i)
        labels = np.zeros((latents.shape[0], Gs.get("nlabels", 0)), dtype=np.float32)
        # Gs.run is assumed to return images as np.ndarray
        images = Gs.run(latents, labels)
        images = np.clip(images, -1, 1)
        images = ((images + 1) * 127.5).astype(np.uint8)
        images = image_shrink(images, factor=2)
        out_path = out_dir / f"{png_prefix}_{i:03d}.png"
        save_image_grid(images, grid_size, out_path)

    # Completion marker
    (out_dir / "_done.txt").touch()


# --------------------------------------------------------------------------- #
# Interpolation video generation
# --------------------------------------------------------------------------- #
def generate_interpolation_video(
    run_id: str,
    snapshot: str,
    duration_sec: float,
    mp4_fps: int,
    grid_size: Tuple[int, int],
    random_seed: int = 42,
    codec: str = "libx264",
    bitrate: str = "5000k",
):
    G, D, Gs = load_network(run_id, snapshot)
    dim_z = getattr(Gs, "ndim_z", 512)
    num_frames = int(duration_sec * mp4_fps)

    # Generate base latent tensor
    latents_base = random_latents(num_frames * grid_size[0] * grid_size[1], dim_z, seed=random_seed)
    latents_base = latents_base.reshape(num_frames, -1, dim_z)

    # Smooth over time
    sigma = 1.0
    smoothed = scipy.ndimage.gaussian_filter(latents_base, sigma=(sigma, 0, 0))

    # Normalize
    norms = np.linalg.norm(smoothed, axis=2, keepdims=True) + 1e-12
    smoothed /= norms

    out_dir = config.result_dir / f"{run_id}_{snapshot}_video"
    out_dir.mkdir(parents=True, exist_ok=True)

    def make_frame(t):
        frame_idx = int(t * mp4_fps)
        frame_idx = min(frame_idx, num_frames - 1)
        latents = smoothed[frame_idx]
        labels = np.zeros((latents.shape[0], Gs.get("nlabels", 0)), dtype=np.float32)
        images = Gs.run(latents, labels)
        images = np.clip(images, -1, 1)
        images = ((images + 1) * 127.5).astype(np.uint8)
        images = image_shrink(images, factor=2)
        images = image_zoom(images, factor=1.5)
        # Convert to RGB if grayscale
        if images.shape[-1] == 1:
            images = np.repeat(images, 3, axis=-1)
        # Combine into single frame image
        gx, gy = grid_size
        h, w, _ = images.shape[1:]
        canvas = Image.new("RGB", (gx * w, gy * h))
        for idx, img in enumerate(images):
            row, col = divmod(idx, gx)
            canvas.paste(Image.fromarray(img), (col * w, row * h))
        return np.array(canvas)

    clip = mpy.VideoClip(make_frame, duration=duration_sec)
    video_path = out_dir / f"{run_id}_{snapshot}_interp.mp4"
    clip.write_videofile(str(video_path), fps=mp4_fps, codec=codec, bitrate=bitrate)

    # Completion marker
    (out_dir / "_done.txt").touch()


# --------------------------------------------------------------------------- #
# Metrics evaluation
# --------------------------------------------------------------------------- #
class DummyMetric:
    def __init__(self, name, num_images, image_shape, minibatch_size):
        self.name = name
        self.num_images = num_images
        self.image_shape = image_shape
        self.minibatch_size = minibatch_size
        self.values = []

    def warmup(self, num=100):
        for _ in range(num):
            dummy = np.random.rand(self.minibatch_size, *self.image_shape).astype(np.float32)
            self.update(dummy)

    def update(self, images: np.ndarray):
        # Dummy update: store mean pixel value
        self.values.append(images.mean())

    def compute(self):
        return np.mean(self.values)


def evaluate_metrics(run_id: str, metrics: List[str] = None, real_passes: int = 10):
    if metrics is None:
        metrics = ["FID", "IS", "SWD"]

    run_dir = config.result_dir / run_id
    dataset_path = config.dataset_dir / f"{run_id}.pkl"
    # Load dataset placeholder
    with open(dataset_path, "rb") as f:
        dataset_obj = pickle.load(f)

    minibatch_size = getattr(dataset_obj, "minibatch_size", 64)
    image_shape = dataset_obj.get("image_shape", (64, 64, 3))
    num_images = dataset_obj.get("num_images", 5000)

    metric_objs = []
    for name in metrics:
        m = DummyMetric(name, num_images, image_shape, minibatch_size)
        m.warmup()
        metric_objs.append(m)

    log_file = run_dir / "metrics_log.txt"
    with open(log_file, "w") as lf:
        header = "Iteration".ljust(12) + "".join([f"{m.name}".ljust(12) for m in metric_objs]) + "\n"
        lf.write(header)

        # Real image evaluation
        for it in range(real_passes):
            # Dummy real batch
            real_batch = np.random.rand(minibatch_size, *image_shape).astype(np.float32)
            for m in metric_objs:
                m.update(real_batch)
            line = f"{it:<12}" + "".join([f"{m.compute():.4f}".ljust(12) for m in metric_objs]) + "\n"
            lf.write(line)

        # Snapshot evaluation
        snapshot_files = sorted(run_dir.glob("*.pkl"))
        for snap_file in snapshot_files:
            with open(snap_file, "rb") as f:
                net = pickle.load(f)
            Gs = net.get("Gs")
            dim_z = getattr(Gs, "ndim_z", 512)
            latents = random_latents(minibatch_size, dim_z, seed=42)
            labels = np.zeros((latents.shape[0], Gs.get("nlabels", 0)), dtype=np.float32)
            images = Gs.run(latents, labels)
            images = np.clip(images, -1, 1)
            images = ((images + 1) * 127.5).astype(np.uint8)
            for m in metric_objs:
                m.update(images)
            line = f"{snap_file.stem:<12}" + "".join([f"{m.compute():.4f}".ljust(12) for m in metric_objs]) + "\n"
            lf.write(line)

    # Completion marker
    (run_dir / "_done.txt").touch()


# --------------------------------------------------------------------------- #
# Example usage (uncomment to run)
# --------------------------------------------------------------------------- #
# if __name__ == "__main__":
#     generate_fake_images("run1", "snapshot_100k", num_pngs=5, png_prefix="fake", grid_size=(4, 4))
#     generate_interpolation_video("run1", "snapshot_100k", duration_sec=5, mp4_fps=30, grid_size=(4, 4))
#     evaluate_metrics("run1")
