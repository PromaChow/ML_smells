import glob
import os
import pickle
import random

import cv2
import numpy as np


def get_data(file_path):
    """Load a pickle file and return the deserialized data."""
    with open(file_path, "rb") as f:
        return pickle.load(f, encoding="bytes")


def get_dataset_cifar10(n_label, valid_size=500):
    """
    Generate labeled, unlabeled, validation, and test datasets from CIFAR-10.

    Parameters
    ----------
    n_label : int
        Total number of labeled examples (evenly distributed across 10 classes).
    valid_size : int, optional
        Number of validation examples per class.

    Returns
    -------
    train_labeled_dataset : list of tuples
        Each tuple is (image, one_hot_label).
    train_unlabeled_dataset : list
        Images only (numpy arrays).
    valid_dataset : list of tuples
        Each tuple is (image, one_hot_label).
    test_dataset : list of tuples
        Each tuple is (image, one_hot_label).
    """
    # 1. Load and process training data
    train_dic = {i: [] for i in range(10)}
    train_files = glob.glob(os.path.join("dataset", "data_batch_*"))
    for file_path in train_files:
        batch = get_data(file_path)
        images = batch[b"data"]
        labels = batch[b"labels"]
        for img_flat, lbl in zip(images, labels):
            # Split channels
            r = img_flat[0:1024].reshape((32, 32)).astype(np.uint8)
            g = img_flat[1024:2048].reshape((32, 32)).astype(np.uint8)
            b = img_flat[2048:3072].reshape((32, 32)).astype(np.uint8)
            # Merge into RGB image
            rgb = cv2.merge([r, g, b])
            train_dic[lbl].append(rgb)

    # 2. Split each class into labeled, unlabeled, and validation sets
    n_label_per_class = n_label // 10
    train_labeled_dataset = []
    train_unlabeled_dataset = []
    valid_dataset = []

    for cls in range(10):
        imgs = train_dic[cls]
        random.shuffle(imgs)
        # Labeled
        labeled_imgs = imgs[:n_label_per_class]
        for img in labeled_imgs:
            one_hot = np.eye(10)[cls]
            train_labeled_dataset.append((img, one_hot))
        # Unlabeled
        start_unlabeled = n_label_per_class
        end_unlabeled = len(imgs) - valid_size
        unlabeled_imgs = imgs[start_unlabeled:end_unlabeled]
        train_unlabeled_dataset.extend(unlabeled_imgs)
        # Validation
        valid_imgs = imgs[-valid_size:]
        for img in valid_imgs:
            one_hot = np.eye(10)[cls]
            valid_dataset.append((img, one_hot))

    # 3. Load and process test data
    test_batch = get_data(os.path.join("dataset", "test_batch"))
    test_images = test_batch[b"data"]
    test_labels = test_batch[b"labels"]
    test_dataset = []
    for img_flat, lbl in zip(test_images, test_labels):
        r = img_flat[0:1024].reshape((32, 32)).astype(np.uint8)
        g = img_flat[1024:2048].reshape((32, 32)).astype(np.uint8)
        b = img_flat[2048:3072].reshape((32, 32)).astype(np.uint8)
        rgb = cv2.merge([r, g, b])
        one_hot = np.eye(10)[lbl]
        test_dataset.append((rgb, one_hot))

    return (
        train_labeled_dataset,
        train_unlabeled_dataset,
        valid_dataset,
        test_dataset,
    )


if __name__ == "__main__":
    labeled, unlabeled, valid, test = get_dataset_cifar10(n_label=500, valid_size=500)
    print(f"Labeled set size: {len(labeled)}")
    print(f"Unlabeled set size: {len(unlabeled)}")
    print(f"Validation set size: {len(valid)}")
    print(f"Test set size: {len(test)}")