import gym
import numpy as np
import random

class QLearningAgent:
    def __init__(self, env: gym.Env, epsilon: float = 0.1, gamma: float = 0.99, lr: float = 0.1):
        """
        Initialize the Q-learning agent.

        Parameters:
            env (gym.Env): The OpenAI Gym environment.
            epsilon (float): Exploration coefficient.
            gamma (float): Discount factor.
            lr (float): Learning rate.
        """
        if not isinstance(env.observation_space, gym.spaces.Discrete):
            raise ValueError("The environment's observation space must be discrete.")
        if not isinstance(env.action_space, gym.spaces.Discrete):
            raise ValueError("The environment's action space must be discrete.")

        self.env = env
        self.epsilon = epsilon
        self.gamma = gamma
        self.lr = lr

        n_states = env.observation_space.n
        n_actions = env.action_space.n
        self.q_table = np.zeros((n_states, n_actions))

    def get_action(self, state: int, explore: bool = True) -> int:
        """
        Select an action using epsilon-greedy exploration.

        Parameters:
            state (int): Current state index.
            explore (bool): Whether exploration is enabled.

        Returns:
            int: Selected action index.
        """
        if explore and random.random() < (1 - self.epsilon):
            return random.randrange(self.env.action_space.n)
        else:
            return int(np.argmax(self.q_table[state]))

    def update(self, state: int, action: int, reward: float, next_state: int) -> None:
        """
        Update the Q-table using the Bellman equation.

        Parameters:
            state (int): Current state index.
            action (int): Action taken.
            reward (float): Reward received.
            next_state (int): Next state index.
        """
        best_next_action = np.max(self.q_table[next_state])
        td_error = reward + self.gamma * best_next_action - self.q_table[state, action]
        self.q_table[state, action] += self.lr * td_error

    def get_hyperparams(self) -> dict:
        """
        Retrieve the current hyperparameters.

        Returns:
            dict: Dictionary containing epsilon, gamma, and lr.
        """
        return {"epsilon": self.epsilon, "gamma": self.gamma, "lr": self.lr}
