import argparse
import numpy as np
import tensorflow as tf
import tensorlayer as tl

# Disable eager execution for TensorFlow 2.x compatibility
tf.compat.v1.disable_eager_execution()


class CNNEnv:
    def __init__(self, train_x, train_y, test_x, test_y, n_batch):
        self.train_x = train_x
        self.train_y = train_y
        self.test_x = test_x
        self.test_y = test_y
        self.n_batch = n_batch
        self.train_size = train_x.shape[0]
        self.batch_index = 0
        self.shuffle = np.arange(self.train_size)
        np.random.shuffle(self.shuffle)

    def next_batch(self):
        if self.batch_index + self.n_batch > self.train_size:
            np.random.shuffle(self.shuffle)
            self.batch_index = 0
        idx = self.shuffle[self.batch_index : self.batch_index + self.n_batch]
        self.batch_index += self.n_batch
        return self.train_x[idx], self.train_y[idx]

    def train(self, hps, n_epoch, lr_schedule, lr_factor, summary_dir="log"):
        X = tf.compat.v1.placeholder(tf.float32, shape=[None, hps.input_height, hps.input_width, hps.input_channel], name="input")
        Y = tf.compat.v1.placeholder(tf.int32, shape=[None, hps.n_classes], name="label")

        lr = tf.compat.v1.placeholder(tf.float32, shape=[], name="learning_rate")

        # Build ResNet graph
        model = resnet_model.ResNet(X, hps)
        logits = model.get_logits()
        loss = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits_v2(logits=logits, labels=Y))
        optimizer = tf.compat.v1.train.MomentumOptimizer(lr, 0.9).minimize(loss)

        correct_pred = tf.equal(tf.argmax(logits, 1), tf.argmax(Y, 1))
        acc = tf.reduce_mean(tf.cast(correct_pred, tf.float32))

        # Summaries
        tf.compat.v1.summary.scalar("loss", loss)
        tf.compat.v1.summary.scalar("accuracy", acc)
        tf.compat.v1.summary.scalar("learning_rate", lr)
        merged_summary = tf.compat.v1.summary.merge_all()

        init = tf.compat.v1.global_variables_initializer()

        config = tf.compat.v1.ConfigProto()
        config.gpu_options.allow_growth = True
        sess = tf.compat.v1.Session(config=config)

        sess.run(init)

        writer = tf.compat.v1.summary.FileWriter(summary_dir, sess.graph)

        current_lr = hps.learning_rate
        for epoch in range(1, n_epoch + 1):
            if epoch % lr_schedule == 0:
                current_lr *= lr_factor
                print(f"Epoch {epoch}: Adjusted learning rate to {current_lr}")

            num_batches = self.train_size // self.n_batch
            for step in range(1, num_batches + 1):
                batch_x, batch_y = self.next_batch()
                feed_dict = {X: batch_x, Y: batch_y, lr: current_lr}
                _, loss_val, acc_val, summary = sess.run([optimizer, loss, acc, merged_summary], feed_dict=feed_dict)

                if step % 200 == 0:
                    writer.add_summary(summary, epoch * num_batches + step)
                    print(f"Epoch {epoch} Step {step} | Loss: {loss_val:.4f} Acc: {acc_val:.4f}")

            # Evaluation on test set
            test_loss, test_acc = self.evaluate(sess, X, Y, logits, loss, acc)
            print(f"Epoch {epoch} Test Loss: {test_loss:.4f} Test Acc: {test_acc:.4f}")

        writer.close()
        sess.close()

    def evaluate(self, sess, X, Y, logits, loss, acc):
        test_size = self.test_x.shape[0]
        num_batches = test_size // self.n_batch
        total_loss = 0.0
        total_acc = 0.0
        for i in range(num_batches):
            batch_x = self.test_x[i * self.n_batch : (i + 1) * self.n_batch]
            batch_y = self.test_y[i * self.n_batch : (i + 1) * self.n_batch]
            feed_dict = {X: batch_x, Y: batch_y}
            loss_val, acc_val = sess.run([loss, acc], feed_dict=feed_dict)
            total_loss += loss_val
            total_acc += acc_val
        return total_loss / num_batches, total_acc / num_batches


def load_and_preprocess_data():
    train_x, train_y, test_x, test_y = tl.files.load_cifar10_dataset()
    # Convert labels to one-hot
    train_y = tl.one_hot(train_y, 10)
    test_y = tl.one_hot(test_y, 10)

    # Per-channel normalization
    mean = np.mean(train_x, axis=(0, 1, 2), keepdims=True)
    std = np.std(train_x, axis=(0, 1, 2), keepdims=True) + 1e-7
    train_x = (train_x - mean) / std
    test_x = (test_x - mean) / std

    print(f"Train data shape: {train_x.shape}, Train labels shape: {train_y.shape}")
    print(f"Test data shape: {test_x.shape}, Test labels shape: {test_y.shape}")

    return train_x, train_y, test_x, test_y


def parse_args():
    parser = argparse.ArgumentParser(description="ResNet training on CIFAR-10")
    parser.add_argument("--n_epoch", type=int, default=100, help="Number of epochs")
    parser.add_argument("--n_batch", type=int, default=128, help="Batch size")
    parser.add_argument("--n_img_row", type=int, default=32, help="Image height")
    parser.add_argument("--n_img_col", type=int, default=32, help="Image width")
    parser.add_argument("--n_img_channels", type=int, default=3, help="Number of image channels")
    parser.add_argument("--n_classes", type=int, default=10, help="Number of classes")
    parser.add_argument("--lr", type=float, default=0.1, help="Initial learning rate")
    parser.add_argument("--n_resid_units", type=int, default=5, help="Number of residual units")
    parser.add_argument("--lr_schedule", type=int, default=20, help="Learning rate schedule epoch interval")
    parser.add_argument("--lr_factor", type=float, default=0.5, help="Learning rate decay factor")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()

    train_x, train_y, test_x, test_y = load_and_preprocess_data()

    env = CNNEnv(train_x, train_y, test_x, test_y, args.n_batch)

    hps = resnet_model.HParams(
        input_height=args.n_img_row,
        input_width=args.n_img_col,
        input_channel=args.n_img_channels,
        n_classes=args.n_classes,
        learning_rate=args.lr,
        residual_units=args.n_resid_units,
        weight_decay=1e-4,
        optimizer="mom",
        lr_decay=True,
        lr_decay_factor=0.1,
        lr_decay_steps=200,
    )

    env.train(
        hps,
        n_epoch=args.n_epoch,
        lr_schedule=args.lr_schedule,
        lr_factor=args.lr_factor,
    )