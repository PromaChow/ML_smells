import unittest
import numpy as np

try:
    from alpha_go_ai import ProbabilisticPolicyPlayer
except ImportError:
    # Placeholder implementation for testing purposes
    class ProbabilisticPolicyPlayer:
        def __init__(self, temperature: float):
            self.temperature = temperature

        def apply_temperature(self, distribution: np.ndarray) -> np.ndarray:
            if self.temperature <= 0:
                raise ValueError("Temperature must be positive")
            # Adjust probabilities by raising to the power of 1/temperature and renormalize
            adjusted = np.power(distribution, 1.0 / self.temperature)
            return adjusted / adjusted.sum()

def entropy(probs: np.ndarray) -> float:
    eps = 1e-12
    probs_safe = np.clip(probs, eps, None)
    return -np.sum(probs_safe * np.log(probs_safe))

class TestProbabilisticPolicyPlayer(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        rng = np.random.default_rng(42)
        cls.random_distribution = rng.random(361)
        cls.random_distribution /= cls.random_distribution.sum()

    def test_temperature_increases_entropy(self):
        low_temp_player = ProbabilisticPolicyPlayer(temperature=0.9)
        high_temp_player = ProbabilisticPolicyPlayer(temperature=1.1)

        base_entropy = entropy(self.random_distribution)
        low_entropy = entropy(low_temp_player.apply_temperature(self.random_distribution))
        high_entropy = entropy(high_temp_player.apply_temperature(self.random_distribution))

        self.assertLess(low_entropy, base_entropy, "Low temperature should reduce entropy")
        self.assertGreater(high_entropy, base_entropy, "High temperature should increase entropy")

    def test_extreme_temperature_is_numerically_stable(self):
        extreme_low_temp_player = ProbabilisticPolicyPlayer(temperature=1e-12)
        extreme_high_temp_player = ProbabilisticPolicyPlayer(temperature=1e12)

        low_result = extreme_low_temp_player.apply_temperature(self.random_distribution)
        high_result = extreme_high_temp_player.apply_temperature(self.random_distribution)

        self.assertFalse(np.any(np.isnan(low_result)), "NaNs found at low extreme temperature")
        self.assertFalse(np.any(np.isnan(high_result)), "NaNs found at high extreme temperature")

if __name__ == "__main__":
    unittest.main()