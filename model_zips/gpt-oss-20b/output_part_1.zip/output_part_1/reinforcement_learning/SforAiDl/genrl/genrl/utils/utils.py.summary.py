import importlib
import random
from typing import Any, Dict, List, Tuple, Union

import gym
import numpy as np
import torch
import torch.nn as nn
from genrl.core.noise import NoisyLinear


def get_model(model_type: str, name: str):
    """
    Dynamically import and return a model class from the genrl library.

    Parameters
    ----------
    model_type : str
        Type of the model module (e.g., "models.actor_critic").
    name : str
        Name of the class to import.

    Returns
    -------
    type
        The requested class.
    """
    module_name = f"genrl.{model_type}"
    try:
        module = importlib.import_module(module_name)
    except ImportError as exc:
        raise ValueError(f"Module '{module_name}' not found.") from exc
    try:
        model_cls = getattr(module, name)
    except AttributeError as exc:
        raise ValueError(f"Model '{name}' not found in '{module_name}'.") from exc
    return model_cls


def mlp(
    input_dim: int,
    output_dim: int,
    hidden_sizes: List[int],
    activation: str = "relu",
    is_sac: bool = False,
):
    """
    Build a fully connected neural network.

    Parameters
    ----------
    input_dim : int
        Size of the input layer.
    output_dim : int
        Size of the output layer.
    hidden_sizes : list[int]
        Sizes of hidden layers.
    activation : str, optional
        Activation function: "relu" or "tanh".
    is_sac : bool, optional
        If True, append a final Tanh to bound outputs in SAC.

    Returns
    -------
    nn.Sequential
        The constructed network.
    """
    layers = []
    in_dim = input_dim
    for h in hidden_sizes:
        layers.append(nn.Linear(in_dim, h))
        if activation.lower() == "relu":
            layers.append(nn.ReLU())
        elif activation.lower() == "tanh":
            layers.append(nn.Tanh())
        else:
            raise ValueError(f"Unsupported activation: {activation}")
        in_dim = h
    layers.append(nn.Linear(in_dim, output_dim))
    if is_sac:
        layers.append(nn.Tanh())
    return nn.Sequential(*layers)


def _conv_output_dim(size: int, kernel: int, stride: int, padding: int = 0) -> int:
    return (size - kernel + 2 * padding) // stride + 1


def cnn(
    input_shape: Tuple[int, int, int],
    output_dim: int,
    channels: List[int],
    kernel_sizes: List[int],
    strides: List[int],
    activation: str = "relu",
):
    """
    Build a convolutional neural network.

    Parameters
    ----------
    input_shape : tuple[int, int, int]
        (channels, height, width) of the input.
    output_dim : int
        Size of the final output layer.
    channels : list[int]
        Number of output channels for each conv layer.
    kernel_sizes : list[int]
        Kernel sizes for each conv layer.
    strides : list[int]
        Strides for each conv layer.
    activation : str, optional
        Activation function: "relu" or "tanh".

    Returns
    -------
    nn.Sequential
        The constructed network.
    """
    layers = []
    in_channels, h, w = input_shape
    for out_c, k, s in zip(channels, kernel_sizes, strides):
        layers.append(nn.Conv2d(in_channels, out_c, kernel_size=k, stride=s))
        if activation.lower() == "relu":
            layers.append(nn.ReLU())
        elif activation.lower() == "tanh":
            layers.append(nn.Tanh())
        else:
            raise ValueError(f"Unsupported activation: {activation}")
        h = _conv_output_dim(h, k, s)
        w = _conv_output_dim(w, k, s)
        in_channels = out_c
    layers.append(nn.Flatten())
    in_features = in_channels * h * w
    layers.append(nn.Linear(in_features, output_dim))
    return nn.Sequential(*layers)


def noisy_mlp(
    input_dim: int,
    output_dim: int,
    hidden_sizes: List[int],
    activation: str = "relu",
):
    """
    Build a noisy fully connected network.

    Parameters
    ----------
    input_dim : int
        Size of the input layer.
    output_dim : int
        Size of the output layer.
    hidden_sizes : list[int]
        Sizes of hidden layers.
    activation : str, optional
        Activation function: "relu" or "tanh".

    Returns
    -------
    nn.Sequential
        The constructed noisy network.
    """
    layers = []
    in_dim = input_dim
    for h in hidden_sizes:
        layers.append(NoisyLinear(in_dim, h))
        if activation.lower() == "relu":
            layers.append(nn.ReLU())
        elif activation.lower() == "tanh":
            layers.append(nn.Tanh())
        else:
            raise ValueError(f"Unsupported activation: {activation}")
        in_dim = h
    layers.append(NoisyLinear(in_dim, output_dim))
    return nn.Sequential(*layers)


def get_env_properties(env: Any, network_type: str):
    """
    Extract environment properties for network construction.

    Parameters
    ----------
    env : gym.Env or vectorized env
        The environment instance.
    network_type : str
        Type of network ("mlp" or "cnn").

    Returns
    -------
    dict
        Dictionary containing state_dim, action_dim, action_type,
        action_low, action_high, input_shape.
    """
    # Unwrap vectorized environments
    if hasattr(env, "envs"):
        env = env.envs[0]

    # Observation space
    if isinstance(env.observation_space, gym.spaces.Box):
        state_dim = env.observation_space.shape
    elif isinstance(env.observation_space, gym.spaces.Discrete):
        state_dim = env.observation_space.n
    else:
        raise ValueError("Unsupported observation space type")

    # Action space
    if isinstance(env.action_space, gym.spaces.Box):
        action_dim = env.action_space.shape[0]
        action_low = env.action_space.low
        action_high = env.action_space.high
        action_type = "continuous"
    elif isinstance(env.action_space, gym.spaces.Discrete):
        action_dim = env.action_space.n
        action_low = None
        action_high = None
        action_type = "discrete"
    else:
        raise ValueError("Unsupported action space type")

    # Input shape for CNN
    if network_type.lower() == "cnn":
        if len(env.observation_space.shape) == 3:
            input_shape = (
                env.observation_space.shape[0],
                env.observation_space.shape[1],
                env.observation_space.shape[2],
            )
        else:
            raise ValueError("CNN requires 3D observation space")
    else:
        input_shape = state_dim if isinstance(state_dim, int) else state_dim

    return {
        "state_dim": state_dim,
        "action_dim": action_dim,
        "action_type": action_type,
        "action_low": action_low,
        "action_high": action_high,
        "input_shape": input_shape,
    }


def set_seeds(seed: int, env: Any = None):
    """
    Set random seeds for reproducibility.

    Parameters
    ----------
    seed : int
        Seed value.
    env : gym.Env, optional
        Environment to seed if possible.
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

    if env is not None:
        if hasattr(env, "seed"):
            env.seed(seed)
        elif hasattr(env, "reset") and hasattr(env, "step"):
            try:
                env.reset(seed=seed)
            except TypeError:
                # Older gym versions
                env.reset()


def safe_mean(values: Union[List[float], torch.Tensor]):
    """
    Compute mean of a list or tensor, return 0 if empty.

    Parameters
    ----------
    values : list[float] or torch.Tensor
        Values to average.

    Returns
    -------
    float or torch.Tensor
        Mean value or zero if input is empty.
    """
    if torch.is_tensor(values):
        if values.numel() == 0:
            return torch.tensor(0.0, dtype=values.dtype)
        return torch.mean(values)
    elif isinstance(values, list):
        if len(values) == 0:
            return 0.0
        return sum(values) / len(values)
    else:
        raise TypeError("Input must be a list or torch.Tensor")