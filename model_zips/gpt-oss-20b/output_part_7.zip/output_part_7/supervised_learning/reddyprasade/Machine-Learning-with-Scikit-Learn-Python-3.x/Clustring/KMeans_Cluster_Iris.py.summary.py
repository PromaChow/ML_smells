import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from sklearn.cluster import KMeans
from sklearn import datasets

np.random.seed(5)

iris = datasets.load_iris()
X = iris.data
y = iris.target

k_means_iris_8 = KMeans(n_clusters=8, random_state=5)
k_means_iris_3 = KMeans(n_clusters=3, random_state=5)
k_means_iris_bad_init = KMeans(n_clusters=3, n_init=1, init='random', random_state=5)

estimators = [
    (k_means_iris_8, "8 clusters"),
    (k_means_iris_3, "3 clusters"),
    (k_means_iris_bad_init, "3 clusters, bad initialization")
]

for est, title in estimators:
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    est.fit(X)
    labels = est.labels_
    scatter = ax.scatter(X[:, 3], X[:, 0], X[:, 2], c=labels, cmap='viridis', marker='o')
    ax.set_xlabel('Petal width')
    ax.set_ylabel('Sepal length')
    ax.set_zlabel('Petal length')
    ax.set_title(title)

# Compute mapping from true labels to cluster labels using the 3-cluster KMeans
cluster_labels = k_means_iris_3.labels_
mapping = {}
for cluster in np.unique(cluster_labels):
    indices = np.where(cluster_labels == cluster)[0]
    true_labels = y[indices]
    majority_label = np.bincount(true_labels).argmax()
    mapping[majority_label] = cluster

# Reorder true labels to match cluster colors
y_reordered = np.vectorize(mapping.get)(y)

fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
scatter = ax.scatter(X[:, 3], X[:, 0], X[:, 2], c=y_reordered, cmap='viridis', marker='o')

# Add text labels at class centroids
class_names = ["Setosa", "Versicolour", "Virginica"]
for i, name in enumerate(class_names):
    centroid = X[y == i].mean(axis=0)
    ax.text3D(centroid[3], centroid[0], centroid[2], name, color='black', fontsize=12)

ax.set_xlabel('Petal width')
ax.set_ylabel('Sepal length')
ax.set_zlabel('Petal length')
ax.set_title('Ground truth')

plt.show()