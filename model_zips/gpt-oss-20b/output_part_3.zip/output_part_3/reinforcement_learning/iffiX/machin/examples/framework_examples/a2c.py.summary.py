import gym
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np

class ActorNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(4, 16)
        self.fc2 = nn.Linear(16, 16)
        self.fc3 = nn.Linear(16, 2)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        logits = self.fc3(x)
        probs = torch.softmax(logits, dim=0)
        return probs

class CriticNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(4, 16)
        self.fc2 = nn.Linear(16, 16)
        self.fc3 = nn.Linear(16, 1)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        value = self.fc3(x)
        return value

class A2CAgent:
    def __init__(self, actor, critic, lr=1e-3, gamma=0.99, entropy_coef=0.01):
        self.actor = actor
        self.critic = critic
        self.gamma = gamma
        self.entropy_coef = entropy_coef
        self.optimizer = optim.Adam(list(actor.parameters()) + list(critic.parameters()), lr=lr)
        self.buffer = []

    def act(self, state):
        state_tensor = torch.tensor(state, dtype=torch.float32)
        probs = self.actor(state_tensor)
        m = torch.distributions.Categorical(probs)
        action = m.sample()
        log_prob = m.log_prob(action)
        entropy = m.entropy()
        return action.item(), log_prob, entropy

    def store_episode(self, transitions):
        self.buffer.append(transitions)

    def update(self):
        if not self.buffer:
            return
        states = []
        actions = []
        rewards = []
        next_states = []
        dones = []
        log_probs = []
        entropies = []
        for episode in self.buffer:
            for (s, a, r, s_next, d, lpo, ent) in episode:
                states.append(torch.tensor(s, dtype=torch.float32))
                actions.append(a)
                rewards.append(r)
                next_states.append(torch.tensor(s_next, dtype=torch.float32))
                dones.append(d)
                log_probs.append(lpo)
                entropies.append(ent)
        states_tensor = torch.stack(states)
        next_states_tensor = torch.stack(next_states)
        values = self.critic(states_tensor).squeeze()
        next_values = self.critic(next_states_tensor).squeeze()
        returns = []
        G = 0
        for r, d in zip(reversed(rewards), reversed(dones)):
            if d:
                G = 0
            G = r + self.gamma * G
            returns.insert(0, G)
        returns = torch.tensor(returns, dtype=torch.float32)
        advantage = returns - values
        policy_loss = -(torch.stack(log_probs) * advantage.detach()).mean()
        entropy_loss = -self.entropy_coef * torch.stack(entropies).mean()
        value_loss = nn.functional.mse_loss(returns, values, reduction='sum')
        loss = policy_loss + value_loss + entropy_loss
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        self.buffer = []

def main():
    env = gym.make('CartPole-v0')
    actor = ActorNet()
    critic = CriticNet()
    agent = A2CAgent(actor, critic)
    max_episodes = 1000
    max_steps = 200
    solved_reward = 190
    moving_avg = 0.0
    success_count = 0
    for episode in range(1, max_episodes + 1):
        state = env.reset()
        if isinstance(state, tuple):
            state = state[0]
        episode_reward = 0.0
        transitions = []
        for t in range(max_steps):
            action, log_prob, entropy = agent.act(state)
            step_res = env.step(action)
            if len(step_res) == 5:
                next_state, reward, terminated, truncated, _ = step_res
                done = terminated or truncated
            else:
                next_state, reward, done, _ = step_res
            transitions.append((state, action, reward, next_state, done, log_prob, entropy))
            state = next_state
            episode_reward += reward
            if done:
                break
        agent.store_episode(transitions)
        agent.update()
        moving_avg = 0.9 * moving_avg + 0.1 * episode_reward
        print(f'Episode {episode:3d}  reward: {episode_reward:6.2f}  smoothed: {moving_avg:6.2f}')
        if moving_avg >= solved_reward:
            success_count += 1
            if success_count >= 5:
                print("Solved environment! Training terminated.")
                break
        else:
            success_count = 0
    env.close()

if __name__ == "__main__":
    main()
