import abc
import copy
import multiprocessing as mp
import numpy as np
import torch
import gym

def worker(remote, env):
    """
    Worker process that handles commands for a single environment.
    """
    while True:
        cmd, data = remote.recv()
        if cmd == "step":
            action = data
            obs, reward, done, info = env.step(action)
            remote.send((obs, reward, done, info))
        elif cmd == "reset":
            obs = env.reset()
            remote.send(obs)
        elif cmd == "close":
            env.close()
            remote.close()
            break
        elif cmd == "seed":
            seed = data
            env.seed(seed)
            remote.send(None)
        elif cmd == "get_spaces":
            remote.send((env.observation_space, env.action_space))
        else:
            raise NotImplementedError(f"Unknown command {cmd}")

class VecEnv(abc.ABC):
    """
    Abstract base class for vectorized environments.
    """
    def __init__(self, envs):
        self.envs = envs
        self.num_envs = len(envs)
        self.episode_rewards = [0.0] * self.num_envs
        self.observation_space = self.envs[0].observation_space
        self.action_space = self.envs[0].action_space

    @abc.abstractmethod
    def step(self, actions):
        pass

    @abc.abstractmethod
    def reset(self):
        pass

    @abc.abstractmethod
    def close(self):
        pass

    def seed(self, seed=None):
        seeds = [seed + i if seed is not None else None for i in range(self.num_envs)]
        for env, s in zip(self.envs, seeds):
            env.seed(s)

    @property
    def obs_shape(self):
        return self.observation_space.shape

    @property
    def act_shape(self):
        return self.action_space.shape

    def sample(self):
        return self.action_space.sample()

class SerialVecEnv(VecEnv):
    """
    Serial implementation of vectorized environments.
    """
    def __init__(self, env_fns):
        envs = [fn() for fn in env_fns]
        super().__init__(envs)
        self.states = None
        self.rewards = None
        self.dones = None
        self.infos = None

    def reset(self):
        observations = []
        for i, env in enumerate(self.envs):
            obs = env.reset()
            observations.append(obs)
        self.states = torch.as_tensor(np.array(observations))
        return self.states.clone()

    def step(self, actions):
        observations = []
        rewards = []
        dones = []
        infos = []
        for i, (env, action) in enumerate(zip(self.envs, actions)):
            obs, reward, done, info = env.step(action)
            observations.append(obs)
            rewards.append(reward)
            dones.append(done)
            infos.append(info)
            if done:
                self.episode_rewards[i] += reward
        self.states = torch.as_tensor(np.array(observations))
        self.rewards = torch.tensor(rewards, dtype=torch.float32)
        self.dones = torch.tensor(dones, dtype=torch.bool)
        self.infos = copy.deepcopy(infos)
        return self.states.clone(), self.rewards.clone(), self.dones.clone(), self.infos

    def close(self):
        for env in self.envs:
            env.close()

    def render(self, mode="rgb_array"):
        frames = []
        for env in self.envs:
            frames.append(env.render(mode=mode))
        return frames

class SubProcessVecEnv(VecEnv):
    """
    Parallel implementation using subprocesses.
    """
    def __init__(self, env_fns):
        self.env_fns = env_fns
        self.num_envs = len(env_fns)
        self.parent_conns, self.child_conns = zip(*[mp.Pipe() for _ in range(self.num_envs)])
        self.processes = []
        for i, (parent_conn, child_conn, fn) in enumerate(zip(self.parent_conns, self.child_conns, self.env_fns)):
            p = mp.Process(target=worker, args=(child_conn, fn()))
            p.daemon = True
            p.start()
            child_conn.close()
            self.processes.append(p)
        super().__init__(self.env_fns)

    def reset(self):
        for conn in self.parent_conns:
            conn.send(("reset", None))
        observations = [conn.recv() for conn in self.parent_conns]
        self.states = torch.as_tensor(np.array(observations))
        return self.states.clone()

    def step(self, actions):
        for conn, action in zip(self.parent_conns, actions):
            conn.send(("step", action))
        results = [conn.recv() for conn in self.parent_conns]
        observations, rewards, dones, infos = zip(*results)
        for i, done in enumerate(dones):
            if done:
                self.episode_rewards[i] += rewards[i]
        self.states = torch.as_tensor(np.array(observations))
        self.rewards = torch.tensor(rewards, dtype=torch.float32)
        self.dones = torch.tensor(dones, dtype=torch.bool)
        self.infos = copy.deepcopy(infos)
        return self.states.clone(), self.rewards.clone(), self.dones.clone(), self.infos

    def seed(self, seed=None):
        seeds = [seed + i if seed is not None else None for i in range(self.num_envs)]
        for conn, s in zip(self.parent_conns, seeds):
            conn.send(("seed", s))

    def close(self):
        for conn in self.parent_conns:
            conn.send(("close", None))
        for p in self.processes:
            p.join()

    def get_spaces(self):
        self.parent_conns[0].send(("get_spaces", None))
        obs_space, act_space = self.parent_conns[0].recv()
        return obs_space, act_space

    def render(self, mode="rgb_array"):
        frames = []
        for conn in self.parent_conns:
            conn.send(("render", mode))
        for conn in self.parent_conns:
            frames.append(conn.recv())
        return frames
