import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, KFold, cross_val_score, GridSearchCV
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, mean_squared_error

def main():
    # 1. Load dataset
    df = pd.read_csv('glass.csv')
    print("First five rows of the dataset:")
    print(df.head())

    # 2. EDA
    print("\nUnique values in 'Type' column:")
    print(df['Type'].unique())

    plt.figure(figsize=(8, 4))
    sns.countplot(x='Type', data=df)
    plt.title('Class Distribution')
    plt.show()

    # 3. Feature and target separation
    X = df.iloc[:, :9]
    Y = df['Type']

    # 4. Train-test split
    X_train, X_test, Y_train, Y_test = train_test_split(
        X, Y, test_size=0.3, random_state=5, stratify=Y
    )

    # 5. Decision Tree training and evaluation
    dt_clf = DecisionTreeClassifier(random_state=5)
    dt_clf.fit(X_train, Y_train)
    y_pred = dt_clf.predict(X_test)

    rmse = mean_squared_error(Y_test, y_pred, squared=False)
    acc = accuracy_score(Y_test, y_pred)

    print(f"\nDecision Tree RMSE: {rmse:.4f}")
    print(f"Decision Tree Accuracy: {acc:.4f}")

    # 6. Cross-validation with KFold
    kf = KFold(n_splits=3, shuffle=True, random_state=5)
    fold_accuracies = []
    print("\n3-fold CV using KFold:")
    for fold, (train_idx, test_idx) in enumerate(kf.split(X), 1):
        X_fold_train, X_fold_test = X.iloc[train_idx], X.iloc[test_idx]
        Y_fold_train, Y_fold_test = Y.iloc[train_idx], Y.iloc[test_idx]
        clf_fold = DecisionTreeClassifier(random_state=5)
        clf_fold.fit(X_fold_train, Y_fold_train)
        y_fold_pred = clf_fold.predict(X_fold_test)
        fold_acc = accuracy_score(Y_fold_test, y_fold_pred)
        fold_accuracies.append(fold_acc)
        print(f"  Fold {fold} accuracy: {fold_acc:.4f}")

    cv_scores = cross_val_score(dt_clf, X, Y, cv=3, scoring='accuracy')
    print(f"Mean 3‑fold CV accuracy (cross_val_score): {cv_scores.mean():.4f}")

    # 7. Random Forest initialization
    rf_clf = RandomForestClassifier(
        n_estimators=50,
        max_features='sqrt',
        n_jobs=-1,
        oob_score=True,
        random_state=5
    )

    # 8. Hyperparameter tuning with GridSearchCV
    param_grid = {
        'n_estimators': [100, 200],
        'max_features': ['auto', 'sqrt', 'log2']
    }
    grid = GridSearchCV(
        estimator=rf_clf,
        param_grid=param_grid,
        cv=5,
        n_jobs=-1,
        scoring='accuracy'
    )
    grid.fit(X, Y)
    print("\nBest hyperparameters from GridSearchCV:")
    print(grid.best_params_)

    # 9. Final Random Forest evaluation
    best_rf = RandomForestClassifier(
        n_estimators=grid.best_params_['n_estimators'],
        max_features=grid.best_params_['max_features'],
        n_jobs=-1,
        random_state=5
    )
    final_scores = cross_val_score(best_rf, X, Y, cv=10, scoring='accuracy')
    print(f"\n10‑fold CV accuracy of the best Random Forest: {final_scores.mean():.4f}")

if __name__ == "__main__":
    main()