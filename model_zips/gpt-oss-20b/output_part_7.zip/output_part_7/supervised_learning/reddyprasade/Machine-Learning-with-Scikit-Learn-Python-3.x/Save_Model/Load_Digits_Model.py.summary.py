import joblib
from sklearn.datasets import load_digits

filename = 'digits_classifier.joblib.pkl'

digits = load_digits()
X, y = digits.data, digits.target

model = joblib.load(filename)

accuracy = model.score(X, y)
print(f'Accuracy on digits dataset: {accuracy:.4f}')