import time
import collections
import torch
import torch.nn as nn
import torch.optim as optim
import torch.distributed as dist
import torch.distributed.rpc as rpc
import torch.distributed.distributed_c10d as c10d
import torch.multiprocessing as mp
import gym

# Simple Actor and Critic networks
class Actor(nn.Module):
    def __init__(self, state_dim=4, action_dim=2):
        super().__init__()
        self.fc = nn.Linear(state_dim, 128)
        self.head = nn.Linear(128, action_dim)

    def forward(self, x):
        x = torch.relu(self.fc(x))
        return self.head(x)

class Critic(nn.Module):
    def __init__(self, state_dim=4):
        super().__init__()
        self.fc = nn.Linear(state_dim, 128)
        self.head = nn.Linear(128, 1)

    def forward(self, x):
        x = torch.relu(self.fc(x))
        return self.head(x)

# Combined model to be stored on the server
class CombinedModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.actor = Actor()
        self.critic = Critic()

    def forward(self, x):
        return self.actor(x), self.critic(x)

# RPC server that holds the shared model and optimizer
class ModelServer(nn.Module):
    def __init__(self, model: CombinedModel, lr: float = 1e-3):
        super().__init__()
        self.model = model
        self.optimizer = optim.Adam(self.model.parameters(), lr=lr)

    def get_state_dict(self):
        return self.model.state_dict()

    def apply_gradients(self, grad_dict):
        # Apply gradients to local model
        for name, grad in grad_dict.items():
            param = dict(self.model.named_parameters())[name]
            param.grad = grad
        self.optimizer.step()
        self.optimizer.zero_grad()
        return True

# IMPALA algorithm implementation
class IMPALA:
    def __init__(self, actor: nn.Module, critic: nn.Module, rpc_group, model_server_name, batch_size=2):
        self.actor = actor
        self.critic = critic
        self.rpc_group = rpc_group
        self.model_server_name = model_server_name
        self.batch_size = batch_size
        self.replay_buffer = collections.deque()
        self.sync = True
        self.gamma = 0.99

    def set_sync(self, sync: bool):
        self.sync = sync

    def act(self, state: torch.Tensor):
        with torch.no_grad():
            logits, _ = self.actor(state)
            probs = torch.softmax(logits, dim=-1)
            action = torch.multinomial(probs, 1).item()
        return action

    def store(self, episode):
        self.replay_buffer.append(episode)
        if len(self.replay_buffer) > 1000:
            self.replay_buffer.popleft()

    def _sample_batch(self):
        batch = []
        for _ in range(self.batch_size):
            if self.replay_buffer:
                batch.append(self.replay_buffer.popleft())
        return batch

    def _compute_returns(self, rewards):
        R = 0.0
        returns = []
        for r in reversed(rewards):
            R = r + self.gamma * R
            returns.insert(0, R)
        return returns

    def update(self):
        if len(self.replay_buffer) < self.batch_size:
            return
        batch = self._sample_batch()
        policy_grads = {}
        value_grads = {}
        for episode in batch:
            states = torch.tensor([s[0] for s in episode], dtype=torch.float32)
            actions = torch.tensor([s[1] for s in episode], dtype=torch.long)
            rewards = [s[2] for s in episode]
            dones = [s[3] for s in episode]

            logits, values = self.actor(states), self.critic(states).squeeze(-1)
            probs = torch.softmax(logits, dim=-1)
            log_probs = torch.log(probs.gather(1, actions.unsqueeze(1)).squeeze(1))

            returns = self._compute_returns(rewards)
            returns = torch.tensor(returns, dtype=torch.float32)

            advantage = returns - values.detach()
            policy_loss = -(log_probs * advantage).mean()
            value_loss = nn.functional.mse_loss(values, returns)
            loss = policy_loss + value_loss

            # Backward
            loss.backward()

            # Collect gradients
            for name, param in self.actor.named_parameters():
                if param.grad is not None:
                    grad_name = f"actor.{name}"
                    policy_grads[grad_name] = param.grad.clone()
            for name, param in self.critic.named_parameters():
                if param.grad is not None:
                    grad_name = f"critic.{name}"
                    value_grads[grad_name] = param.grad.clone()

            self.actor.zero_grad()
            self.critic.zero_grad()

        # Combine gradients
        grad_dict = {**policy_grads, **value_grads}

        # Send gradients to server
        rpc.rpc_sync(self.model_server_name, ModelServer.apply_gradients, args=(grad_dict,))

        # Pull updated parameters from server
        new_state_dict = rpc.rpc_sync(self.model_server_name, ModelServer.get_state_dict)
        self.actor.load_state_dict(new_state_dict['actor'])
        self.critic.load_state_dict(new_state_dict['critic'])

# Helper to initialize RPC and run processes
def main_worker(rank, world_size):
    node_names = [f'worker{rank}' if rank < 2 else f'learner{rank}' for rank in range(world_size)]
    rpc.init_rpc(node_names[rank], rank=rank, world_size=world_size,
                 rpc_backend_options=rpc.TensorPipeRpcBackendOptions(num_worker_threads=16))

    # Create collective group for learners
    learner_ranks = [2, 3]
    learner_group = None
    if rank in learner_ranks:
        learner_group = c10d.new_group(ranks=learner_ranks, backend='gloo')

    # Initialize shared model on rank 0
    if rank == 0:
        combined_model = CombinedModel()
        # Register server
        rpc.remote(node_names[0], ModelServer, combined_model)

    # Allow some time for server to start
    time.sleep(1)

    # Load initial parameters from server
    def get_initial_state():
        return rpc.rpc_sync(node_names[0], ModelServer.get_state_dict)

    state_dict = get_initial_state()
    # Instantiate local actor and critic
    actor = Actor()
    critic = Critic()
    actor.load_state_dict(state_dict['actor'])
    critic.load_state_dict(state_dict['critic'])

    # Wrap with DDP if learner
    if rank in learner_ranks:
        actor = nn.parallel.DistributedDataParallel(actor, process_group=learner_group)
        critic = nn.parallel.DistributedDataParallel(critic, process_group=learner_group)

    impala = IMPALA(actor, critic, rpc_group=None, model_server_name=node_names[0], batch_size=2)
    impala.set_sync(False)

    # Synchronize all ranks
    dist.barrier()

    if rank < 2:  # Worker
        env = gym.make('CartPole-v0')
        smoothed_rewards = collections.deque(maxlen=5)
        solved = False
        for episode_idx in range(2000):
            state = env.reset()
            episode = []
            total_reward = 0.0
            for step in range(200):
                state_tensor = torch.tensor(state, dtype=torch.float32)
                action = impala.act(state_tensor)
                next_state, reward, done, _ = env.step(action)
                episode.append((state, action, reward, done))
                state = next_state
                total_reward += reward
                if done:
                    break
            impala.store(episode)
            smoothed_rewards.append(total_reward)
            if len(smoothed_rewards) == 5 and all(r > 190 for r in smoothed_rewards):
                solved = True
                print(f"Worker {rank} solved at episode {episode_idx}")
                break
        env.close()
    else:  # Learner
        # Wait until enough data
        while len(impala.replay_buffer) < 5:
            time.sleep(0.1)
        while True:
            impala.update()
            time.sleep(0.01)

    rpc.shutdown()

if __name__ == "__main__":
    world_size = 4
    mp.spawn(main_worker, args=(world_size,), nprocs=world_size, join=True)