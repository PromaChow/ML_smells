import unittest
import numpy as np
import chainer
import chainer.functions as F
import chainer.links as L
from chainer import Variable
from chainer.backends import cuda
from chainer.utils import split_one_step_batch_input, split_batched_sequences, concatenate_sequences
from chainer.links import StatelessRecurrentChainList, NStepLSTM, NStepGRU, NStepRNN, NStepRNNTanh, NStepRNNReLU
from chainer.functions.recurrent import call_recurrent_link, get_recurrent_states, mask_recurrent_states, concatenate_recurrent_states

class TestSplitOneStepBatchInput(unittest.TestCase):
    def test_array_input(self):
        x = np.arange(12).reshape(4, 3).astype(np.float32)
        res = split_one_step_batch_input(x)
        self.assertIsInstance(res, list)
        self.assertEqual(len(res), 4)
        for i, arr in enumerate(res):
            np.testing.assert_allclose(arr, x[i:i+1])

    def test_tuple_input(self):
        a = np.arange(12).reshape(4, 3).astype(np.float32)
        b = np.arange(12, 24).reshape(4, 3).astype(np.float32)
        res = split_one_step_batch_input((a, b))
        self.assertIsInstance(res, list)
        self.assertEqual(len(res), 4)
        for i, tup in enumerate(res):
            self.assertIsInstance(tup, tuple)
            self.assertEqual(len(tup), 2)
            np.testing.assert_allclose(tup[0], a[i:i+1])
            np.testing.assert_allclose(tup[1], b[i:i+1])

class TestSplitBatchedSequences(unittest.TestCase):
    def test_array_input(self):
        seq = np.arange(24).reshape(8, 3).astype(np.float32)
        indices = [4, 1, 3]
        res = split_batched_sequences(seq, indices)
        self.assertIsInstance(res, list)
        self.assertEqual(len(res), 3)
        lengths = [4, 1, 3]
        start = 0
        for r, l in zip(res, lengths):
            np.testing.assert_allclose(r, seq[start:start+l])
            start += l

    def test_tuple_input(self):
        a = np.arange(24).reshape(8, 3).astype(np.float32)
        b = np.arange(24, 48).reshape(8, 3).astype(np.float32)
        indices = [4, 1, 3]
        res = split_batched_sequences((a, b), indices)
        self.assertIsInstance(res, list)
        self.assertEqual(len(res), 3)
        lengths = [4, 1, 3]
        start = 0
        for r, l in zip(res, lengths):
            self.assertIsInstance(r, tuple)
            self.assertEqual(len(r), 2)
            np.testing.assert_allclose(r[0], a[start:start+l])
            np.testing.assert_allclose(r[1], b[start:start+l])
            start += l

class TestConcatenateSequences(unittest.TestCase):
    def test_array_input(self):
        seqs = [np.arange(12).reshape(4, 3).astype(np.float32),
                np.arange(3).reshape(1, 3).astype(np.float32),
                np.arange(9, 18).reshape(3, 3).astype(np.float32)]
        res = concatenate_sequences(seqs)
        expected = np.vstack(seqs)
        np.testing.assert_allclose(res, expected)

    def test_tuple_input(self):
        seqs = [(np.arange(12).reshape(4, 3).astype(np.float32),
                 np.arange(12, 24).reshape(4, 3).astype(np.float32)),
                (np.arange(3).reshape(1, 3).astype(np.float32),
                 np.arange(3, 6).reshape(1, 3).astype(np.float32)),
                (np.arange(9, 18).reshape(3, 3).astype(np.float32),
                 np.arange(9, 18).reshape(3, 3).astype(np.float32))]
        res = concatenate_sequences(seqs)
        expected0 = np.vstack([s[0] for s in seqs])
        expected1 = np.vstack([s[1] for s in seqs])
        self.assertIsInstance(res, tuple)
        self.assertEqual(len(res), 2)
        np.testing.assert_allclose(res[0], expected0)
        np.testing.assert_allclose(res[1], expected1)

class TestStatelessRecurrentChainList(unittest.TestCase):
    def test_recurrent_chain_detection(self):
        lstm = NStepLSTM(1, 3, 4, 4)
        gru = NStepGRU(1, 3, 4, 4)
        chain = StatelessRecurrentChainList([lstm, gru])
        self.assertEqual(len(chain.recurrent_links), 2)
        self.assertIsInstance(chain.recurrent_links[0], L.NStepLSTM)
        self.assertIsInstance(chain.recurrent_links[1], L.NStepGRU)

        nested_chain = StatelessRecurrentChainList([chain])
        self.assertEqual(len(nested_chain.recurrent_links), 2)

class TestCallRecurrentLink(unittest.TestCase):
    @staticmethod
    def _run_call(link, x, mode):
        return call_recurrent_link(link, x, mode)

    def _test_lstm(self, use_gpu=False):
        np.random.seed(0)
        xs = np.random.randn(4, 3).astype(np.float32)
        hs = np.random.randn(1, 4).astype(np.float32)
        cs = np.random.randn(1, 4).astype(np.float32)
        lstm = NStepLSTM(1, 3, 4, 4)
        lstm.initialize()
        x_var = Variable(xs)
        h_var = Variable(hs)
        c_var = Variable(cs)
        if use_gpu:
            x_var.to_gpu()
            h_var.to_gpu()
            c_var.to_gpu()
        res_split = self._run_call(lstm, (x_var, h_var, c_var), 'split')
        res_concat = self._run_call(lstm, (x_var, h_var, c_var), 'concat')
        if use_gpu:
            res_split = cuda.to_cpu(res_split)
            res_concat = cuda.to_cpu(res_concat)
        np.testing.assert_allclose(res_split[0], res_concat[0])
        np.testing.assert_allclose(res_split[1], res_concat[1])

    def _test_non_lstm(self, use_gpu=False):
        np.random.seed(1)
        xs = np.random.randn(4, 3).astype(np.float32)
        hs = np.random.randn(1, 4).astype(np.float32)
        gru = NStepGRU(1, 3, 4, 4)
        gru.initialize()
        x_var = Variable(xs)
        h_var = Variable(hs)
        if use_gpu:
            x_var.to_gpu()
            h_var.to_gpu()
        res_split = call_recurrent_link(gru, (x_var, h_var), 'split')
        res_concat = call_recurrent_link(gru, (x_var, h_var), 'concat')
        if use_gpu:
            res_split = cuda.to_cpu(res_split)
            res_concat = cuda.to_cpu(res_concat)
        np.testing.assert_allclose(res_split[0], res_concat[0])

    def test_lstm_cpu(self):
        self._test_lstm(use_gpu=False)

    def test_lstm_gpu(self):
        if cuda.available:
            self._test_lstm(use_gpu=True)

    def test_non_lstm_cpu(self):
        self._test_non_lstm(use_gpu=False)

    def test_non_lstm_gpu(self):
        if cuda.available:
            self._test_non_lstm(use_gpu=True)

class TestRecurrentStateFunctions(unittest.TestCase):
    def _test_lstm(self, use_gpu=False):
        np.random.seed(2)
        xs = np.random.randn(4, 3).astype(np.float32)
        h0 = np.random.randn(1, 4).astype(np.float32)
        c0 = np.random.randn(1, 4).astype(np.float32)
        lstm = NStepLSTM(1, 3, 4, 4)
        lstm.initialize()
        x_var = Variable(xs)
        h_var = Variable(h0)
        c_var = Variable(c0)
        if use_gpu:
            x_var.to_gpu()
            h_var.to_gpu()
            c_var.to_gpu()
        # mask example: mask out last time step
        mask = np.array([1, 1, 1, 0], dtype=np.float32)
        if use_gpu:
            mask = cuda.to_gpu(mask)
        masked_states = mask_recurrent_states(lstm, (x_var, h_var, c_var), mask)
        if use_gpu:
            masked_states = [cuda.to_cpu(s) for s in masked_states]
        # The last hidden state should be zero
        np.testing.assert_allclose(masked_states[1][-1], 0.0, atol=1e-6)

    def _test_non_lstm(self, use_gpu=False):
        np.random.seed(3)
        xs = np.random.randn(4, 3).astype(np.float32)
        h0 = np.random.randn(1, 4).astype(np.float32)
        gru = NStepGRU(1, 3, 4, 4)
        gru.initialize()
        x_var = Variable(xs)
        h_var = Variable(h0)
        if use_gpu:
            x_var.to_gpu()
            h_var.to_gpu()
        mask = np.array([1, 0, 1, 1], dtype=np.float32)
        if use_gpu:
            mask = cuda.to_gpu(mask)
        masked_states = mask_recurrent_states(gru, (x_var, h_var), mask)
        if use_gpu:
            masked_states = [cuda.to_cpu(s) for s in masked_states]
        np.testing.assert_allclose(masked_states[0][1], 0.0, atol=1e-6)

    def test_lstm_cpu(self):
        self._test_lstm(use_gpu=False)

    def test_lstm_gpu(self):
        if cuda.available:
            self._test_lstm(use_gpu=True)

    def test_non_lstm_cpu(self):
        self._test_non_lstm(use_gpu=False)

    def test_non_lstm_gpu(self):
        if cuda.available:
            self._test_non_lstm(use_gpu=True)

if __name__ == '__main__':
    unittest.main()