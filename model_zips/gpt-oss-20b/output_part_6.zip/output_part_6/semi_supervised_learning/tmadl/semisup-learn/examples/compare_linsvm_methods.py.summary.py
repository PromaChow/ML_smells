import numpy as np
import random
from sklearn.svm import SVC
from CPLELearningModel import CPLELearningModel
from scikitTSVM import SKTSVM
from evaluate_and_plot import evaluate_and_plot
import matplotlib.pyplot as plt

def main():
    # Parameters
    kernel_type = "linear"
    N = 60
    supevised_data_points = 2
    noise_probability = 0.1

    # Reproducibility
    np.random.seed(42)
    random.seed(42)

    # Data Generation
    mean = [0.5, 0.5]
    cov = [[0.5, 0.0], [0.0, 0.5]]
    Xs = np.random.multivariate_normal(mean, cov, size=N)

    # True labels with noise
    ytrue = (Xs.sum(axis=1) >= 1).astype(int)
    flip_mask = np.random.rand(N) < noise_probability
    ytrue[flip_mask] = 1 - ytrue[flip_mask]

    # Pseudo-label creation
    ys = -np.ones(N, dtype=int)
    half = supevised_data_points // 2
    for cls in [0, 1]:
        idx_cls = np.where(ytrue == cls)[0]
        selected = random.sample(list(idx_cls), half)
        ys[selected] = ytrue[selected]

    # Supervised data extraction
    mask_labeled = ys != -1
    Xsupervised = Xs[mask_labeled]
    ysupervised = ys[mask_labeled]

    # Model training
    svc = SVC(kernel=kernel_type)
    svc.fit(Xsupervised, ysupervised)

    s3vm = SKTSVM(kernel=kernel_type)
    s3vm.fit(Xs, ys)

    cple_pess = CPLELearningModel(base_classifier=SVC, pessimistic=True)
    cple_pess.fit(Xs, ys)

    cple_opt = CPLELearningModel(base_classifier=SVC, pessimistic=False)
    cple_opt.fit(Xs, ys)

    # Evaluation and visualization
    evaluate_and_plot(svc, Xs, ytrue, title="Supervised SVM")
    evaluate_and_plot(s3vm, Xs, ytrue, title="S3VM")
    evaluate_and_plot(cple_pess, Xs, ytrue, title="CPLE Pessimistic")
    evaluate_and_plot(cple_opt, Xs, ytrue, title="CPLE Optimistic")

    plt.show(block=True)

if __name__ == "__main__":
    main()