import gym
import numpy as np
from gym import spaces


class ABC(gym.Env):
    metadata = {"render_modes": []}

    def __init__(
        self,
        size: int,
        discrete: bool = True,
        partially_observable: bool = False,
        episodic: bool = True,
        deterministic: bool = True,
    ):
        super().__init__()
        self.size = size
        self.discrete = discrete
        self.partially_observable = partially_observable
        self.episodic = episodic
        self.deterministic = deterministic

        self.observation_space = spaces.Box(
            low=-np.inf, high=np.inf, shape=(self.size + 2,), dtype=np.float32
        )

        if self.discrete:
            self.action_space = spaces.Discrete(self.size)
        else:
            self.action_space = spaces.Box(
                low=-1.0, high=1.0, shape=(self.size,), dtype=np.float32
            )

        self.state = None
        self.offset = 0
        self.episode_counter = 0

    def observe(self):
        obs = np.zeros(self.size + 2, dtype=np.float32)
        if self.state == self.size:
            obs[self.size] = 1.0
        else:
            idx = (self.state + self.offset) % self.size
            obs[idx] = 1.0
        return obs

    def reset(self, seed=None, options=None):
        self.state = 0
        if self.partially_observable:
            if self.deterministic:
                self.episode_counter = (self.episode_counter + 1) % self.size
                self.offset = self.episode_counter
            else:
                self.offset = np.random.randint(self.size)
        else:
            self.offset = 0
        return self.observe(), {}

    def step(self, action):
        done = False
        reward = 0.0

        if not self.discrete:
            action = np.clip(action, -1.0, 1.0)
            if self.deterministic:
                act = int(np.argmax(action))
            else:
                logits = action - np.min(action)
                probs = np.exp(logits) / np.sum(np.exp(logits))
                act = int(np.random.choice(self.size, p=probs))
        else:
            act = int(action)

        if act == self.state:
            if self.state == self.size - 1:
                reward = 1.0
                if self.episodic:
                    self.state = self.size
                    done = True
                else:
                    self.state = 0
            else:
                self.state += 1
        else:
            if self.episodic:
                self.state = self.size
                done = True

        return self.observe(), reward, done, {}

    def close(self):
        pass
