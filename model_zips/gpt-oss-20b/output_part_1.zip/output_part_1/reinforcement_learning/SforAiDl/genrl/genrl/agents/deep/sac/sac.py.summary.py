import os
import math
import copy
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from collections import deque, namedtuple

# Replay buffer for experience replay
class ReplayBuffer:
    def __init__(self, capacity, state_dim, action_dim):
        self.capacity = capacity
        self.ptr = 0
        self.size = 0
        self.states = np.zeros((capacity, state_dim), dtype=np.float32)
        self.actions = np.zeros((capacity, action_dim), dtype=np.float32)
        self.rewards = np.zeros((capacity, 1), dtype=np.float32)
        self.next_states = np.zeros((capacity, state_dim), dtype=np.float32)
        self.dones = np.zeros((capacity, 1), dtype=np.float32)

    def push(self, state, action, reward, next_state, done):
        self.states[self.ptr] = state
        self.actions[self.ptr] = action
        self.rewards[self.ptr] = reward
        self.next_states[self.ptr] = next_state
        self.dones[self.ptr] = done
        self.ptr = (self.ptr + 1) % self.capacity
        self.size = min(self.size + 1, self.capacity)

    def sample(self, batch_size):
        idx = np.random.choice(self.size, batch_size, replace=False)
        batch = dict(
            state=torch.FloatTensor(self.states[idx]),
            action=torch.FloatTensor(self.actions[idx]),
            reward=torch.FloatTensor(self.rewards[idx]),
            next_state=torch.FloatTensor(self.next_states[idx]),
            done=torch.FloatTensor(self.dones[idx])
        )
        return batch

    def __len__(self):
        return self.size

# Simple MLP network
class MLP(nn.Module):
    def __init__(self, input_dim, output_dim, hidden_sizes=(256, 256), activation=nn.ReLU):
        super().__init__()
        layers = []
        last_dim = input_dim
        for h in hidden_sizes:
            layers.append(nn.Linear(last_dim, h))
            layers.append(activation())
            last_dim = h
        layers.append(nn.Linear(last_dim, output_dim))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)

# Actor network
class Actor(nn.Module):
    def __init__(self, state_dim, action_dim, action_scale, action_bias):
        super().__init__()
        self.base = MLP(state_dim, 256)
        self.mean_linear = nn.Linear(256, action_dim)
        self.log_std_linear = nn.Linear(256, action_dim)
        self.action_scale = action_scale
        self.action_bias = action_bias

    def forward(self, state, deterministic=False, with_logprob=True):
        x = self.base(state)
        mean = self.mean_linear(x)
        log_std = self.log_std_linear(x)
        log_std = torch.clamp(log_std, -20, 2)
        std = log_std.exp()
        if deterministic:
            action = torch.tanh(mean)
            logp = None
        else:
            normal = torch.distributions.Normal(mean, std)
            raw_action = normal.rsample()
            action = torch.tanh(raw_action)
            if with_logprob:
                logp = normal.log_prob(raw_action).sum(-1, keepdim=True)
                logp -= torch.log(1 - action.pow(2) + 1e-6).sum(-1, keepdim=True)
            else:
                logp = None
        scaled_action = action * self.action_scale + self.action_bias
        return scaled_action, logp

# Critic network with two Q-functions
class Critic(nn.Module):
    def __init__(self, state_dim, action_dim):
        super().__init__()
        self.q1 = MLP(state_dim + action_dim, 1)
        self.q2 = MLP(state_dim + action_dim, 1)

    def forward(self, state, action):
        sa = torch.cat([state, action], dim=-1)
        q1 = self.q1(sa)
        q2 = self.q2(sa)
        return q1, q2

    def q1(self, state, action):
        return self.q1(torch.cat([state, action], dim=-1))

    def q2(self, state, action):
        return self.q2(torch.cat([state, action], dim=-1))

# Soft Actor-Critic implementation
class SAC:
    def __init__(
        self,
        env,
        gamma=0.99,
        alpha=0.2,
        polyak=0.995,
        entropy_tuning=True,
        target_entropy=None,
        create_model=True,
        architecture="mlp",
        shared_layers=False,
        device="cpu",
        learning_rate=3e-4,
        buffer_capacity=1000000,
    ):
        self.env = env
        self.device = torch.device(device)
        self.gamma = gamma
        self.alpha = torch.tensor(alpha, device=self.device, requires_grad=False)
        self.polyak = polyak
        self.entropy_tuning = entropy_tuning
        self.create_model = create_model
        self.architecture = architecture
        self.shared_layers = shared_layers
        self.target_entropy = target_entropy
        if self.target_entropy is None:
            self.target_entropy = -env.action_space.shape[0]
        self.learning_rate = learning_rate

        self.state_dim = env.observation_space.shape[0]
        self.action_dim = env.action_space.shape[0]
        self.action_scale = torch.tensor((env.action_space.high - env.action_space.low) / 2.0, device=self.device)
        self.action_bias = torch.tensor((env.action_space.high + env.action_space.low) / 2.0, device=self.device)

        self.replay_buffer = ReplayBuffer(buffer_capacity, self.state_dim, self.action_dim)

        if self.create_model:
            self._build_model()
            self.optimizer_policy = optim.Adam(self.actor.parameters(), lr=self.learning_rate)
            self.optimizer_value = optim.Adam(list(self.critic.parameters()), lr=self.learning_rate)
            if self.entropy_tuning:
                self.optimizer_alpha = optim.Adam([self.alpha], lr=self.learning_rate)

    def _build_model(self):
        self.actor = Actor(self.state_dim, self.action_dim, self.action_scale, self.action_bias).to(self.device)
        self.critic = Critic(self.state_dim, self.action_dim).to(self.device)
        self.critic_target = copy.deepcopy(self.critic).to(self.device)
        for p in self.critic_target.parameters():
            p.requires_grad = False

    def select_action(self, state, deterministic=False):
        state = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        with torch.no_grad():
            action, _ = self.actor(state, deterministic=deterministic, with_logprob=False)
        return action.cpu().numpy()[0]

    def get_target_q_values(self, next_state, reward, done):
        with torch.no_grad():
            next_action, next_logp = self.actor(next_state, deterministic=False, with_logprob=True)
            q1_next, q2_next = self.critic_target(next_state, next_action)
            min_q_next = torch.min(q1_next, q2_next)
            target_q = reward + (1 - done) * self.gamma * (min_q_next - self.alpha * next_logp)
        return target_q

    def update(self, batch_size=256, update_interval=1):
        if len(self.replay_buffer) < batch_size:
            return
        for _ in range(update_interval):
            batch = self.replay_buffer.sample(batch_size)
            state = batch["state"].to(self.device)
            action = batch["action"].to(self.device)
            reward = batch["reward"].to(self.device)
            next_state = batch["next_state"].to(self.device)
            done = batch["done"].to(self.device)

            # Critic update
            with torch.no_grad():
                target_q = self.get_target_q_values(next_state, reward, done)
            q1, q2 = self.critic(state, action)
            critic_loss = F.mse_loss(q1, target_q) + F.mse_loss(q2, target_q)

            self.optimizer_value.zero_grad()
            critic_loss.backward()
            self.optimizer_value.step()

            # Actor update
            new_action, logp = self.actor(state, deterministic=False, with_logprob=True)
            q1_new, q2_new = self.critic(state, new_action)
            min_q_new = torch.min(q1_new, q2_new)
            actor_loss = (self.alpha * logp - min_q_new).mean()

            self.optimizer_policy.zero_grad()
            actor_loss.backward()
            self.optimizer_policy.step()

            # Entropy coefficient update
            if self.entropy_tuning:
                alpha_loss = -(self.alpha * (logp + self.target_entropy).detach()).mean()
                self.optimizer_alpha.zero_grad()
                alpha_loss.backward()
                self.optimizer_alpha.step()
                self.alpha.data.clamp_(min=1e-8)

            # Soft update of target network
            for target_param, param in zip(self.critic_target.parameters(), self.critic.parameters()):
                target_param.data.copy_(self.polyak * target_param.data + (1 - self.polyak) * param.data)

            # Logging
            print(f"Actor Loss: {actor_loss.item():.4f}, Critic Loss: {critic_loss.item():.4f}, Alpha: {self.alpha.item():.4f}")

    def train(self, num_episodes, batch_size=256, update_interval=1):
        for episode in range(num_episodes):
            state = self.env.reset()
            done = False
            episode_reward = 0
            while not done:
                action = self.select_action(state, deterministic=False)
                next_state, reward, done, _ = self.env.step(action)
                self.replay_buffer.push(state, action, reward, next_state, float(done))
                state = next_state
                episode_reward += reward
                self.update(batch_size, update_interval)
            print(f"Episode {episode+1} Reward: {episode_reward:.2f}")

    def save(self, path):
        os.makedirs(path, exist_ok=True)
        torch.save(self.actor.state_dict(), os.path.join(path, "actor.pth"))
        torch.save(self.critic.state_dict(), os.path.join(path, "critic.pth"))
        torch.save(self.critic_target.state_dict(), os.path.join(path, "critic_target.pth"))
        torch.save({
            "alpha": self.alpha.item(),
            "gamma": self.gamma,
            "polyak": self.polyak,
            "target_entropy": self.target_entropy,
        }, os.path.join(path, "hyperparams.pth"))

    def load(self, path):
        self.actor.load_state_dict(torch.load(os.path.join(path, "actor.pth"), map_location=self.device))
        self.critic.load_state_dict(torch.load(os.path.join(path, "critic.pth"), map_location=self.device))
        self.critic_target.load_state_dict(torch.load(os.path.join(path, "critic_target.pth"), map_location=self.device))
        hyper = torch.load(os.path.join(path, "hyperparams.pth"), map_location=self.device)
        self.alpha = torch.tensor(hyper["alpha"], device=self.device, requires_grad=False)
        self.gamma = hyper["gamma"]
        self.polyak = hyper["polyak"]
        self.target_entropy = hyper["target_entropy"]
        if self.entropy_tuning:
            self.optimizer_alpha = optim.Adam([self.alpha], lr=self.learning_rate)

if __name__ == "__main__":
    import gym
    env = gym.make("Pendulum-v1")
    sac_agent = SAC(env, entropy_tuning=True)
    sac_agent.train(num_episodes=100)