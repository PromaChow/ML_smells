import shutil
from genrl.environments import VectorEnv
from genrl.algorithms import VPG
from genrl.trainers import OnPolicyTrainer

def test_vpg_discrete():
    env = VectorEnv("CartPole-v0")
    agent = VPG(env=env, policy_network="mlp")
    trainer = OnPolicyTrainer(agent, env, log_mode=["csv"], logdir="./logs", epochs=1)
    trainer.train()
    shutil.rmtree("./logs")

def test_vpg_continuous():
    env = VectorEnv("CartPole-v0")
    agent = VPG(env=env, policy_network="mlp")
    trainer = OnPolicyTrainer(agent, env, log_mode=["csv"], logdir="./logs", epochs=1)
    trainer.train()
    shutil.rmtree("./logs")

def test_vpg_cnn():
    env = VectorEnv("Pong-v0", env_type="atari")
    agent = VPG(env=env, policy_network="cnn", rollout_size=128)
    trainer = OnPolicyTrainer(agent, env, log_mode=["csv"], logdir="./logs", epochs=1)
    trainer.train()
    shutil.rmtree("./logs")