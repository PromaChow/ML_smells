import torch
import torch.nn as nn
import torch.nn.functional as F

class MixMatch:
    def __init__(self, model: nn.Module, T: float = 0.5, K: int = 2, alpha: float = 0.75, device: str | torch.device = "cpu"):
        self.model = model
        self.T = T
        self.K = K
        self.alpha = alpha
        self.device = device

    @staticmethod
    def _set_bn_mode(module: nn.Module, mode: bool) -> None:
        """Set BatchNorm layers to eval (mode=False) or train (mode=True)."""
        if isinstance(module, nn.modules.batchnorm._BatchNorm):
            module.eval() if not mode else module.train()

    def sharpen(self, y: torch.Tensor) -> torch.Tensor:
        """Apply temperature scaling and normalize."""
        y = y.pow(1.0 / self.T)
        return y / y.sum(dim=1, keepdim=True)

    def forward(self, x: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        """Compute MixMatch loss on unlabeled data."""
        # Disable batch norm updates
        self.model.apply(lambda m: self._set_bn_mode(m, False))

        # Isolate unlabeled samples
        u_x = x[mask == 1]
        if u_x.numel() == 0:
            self.model.apply(lambda m: self._set_bn_mode(m, True))
            return torch.tensor(0.0, device=self.device, requires_grad=True)

        u_x = u_x.to(self.device)

        # Augmentations and predictions
        with torch.no_grad():
            preds = [self.model(u_x) for _ in range(self.K)]
            y_hat = torch.stack(preds, dim=0).mean(dim=0)
        y_hat_sharpen = self.sharpen(y_hat.detach())

        # Expand predictions to match augmented data
        y_hat_exp = y_hat_sharpen.unsqueeze(1).repeat(1, self.K, 1).reshape(-1, y_hat_sharpen.size(1))
        u_x_stack = u_x.unsqueeze(1).repeat(1, self.K, 1, 1, 1).reshape(-1, *u_x.shape[1:])

        # Mixup
        batch_size = u_x_stack.size(0)
        indices = torch.randperm(batch_size, device=self.device)
        u_x_shuffled = u_x_stack[indices]
        y_shuffled = y_hat_exp[indices]

        lam = torch.distributions.Beta(self.alpha, self.alpha).sample((batch_size,)).to(self.device)
        lam_x = lam.view(-1, 1, 1, 1)
        lam_y = lam.view(-1, 1)

        mixed_x = lam_x * u_x_stack + (1 - lam_x) * u_x_shuffled
        mixed_y = lam_y * y_hat_exp + (1 - lam_y) * y_shuffled

        # Predict on mixed data and compute loss
        preds_mix = self.model(mixed_x)
        loss = F.mse_loss(preds_mix, mixed_y)

        # Re-enable batch norm updates
        self.model.apply(lambda m: self._set_bn_mode(m, True))

        return loss

# Example usage (requires a PyTorch model and data):
# model = SomeModel()
# mixmatch = MixMatch(model, T=0.5, K=2, alpha=0.75, device='cuda')
# loss = mixmatch.forward(x_batch, mask_tensor)
# loss.backward()