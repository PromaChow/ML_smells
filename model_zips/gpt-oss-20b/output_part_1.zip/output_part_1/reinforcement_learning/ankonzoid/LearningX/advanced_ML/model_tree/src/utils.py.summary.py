import copy
import numpy as np
import pandas as pd
from typing import Tuple, List


def load_csv_data(
    file_path: str,
    mode: str = "clf",
    verbose: bool = False,
) -> Tuple[np.ndarray, np.ndarray, List[str]]:
    """
    Load a CSV file into a NumPy array and perform validation based on the task mode.

    Parameters
    ----------
    file_path : str
        Path to the CSV file.
    mode : str, optional
        Either "clf" for classification or "regr" for regression. Default is "clf".
    verbose : bool, optional
        If True, prints header, shapes, and unique class count.

    Returns
    -------
    X : np.ndarray
        Feature matrix of shape (N, d).
    y : np.ndarray
        Label vector of shape (N,).
    header : list
        List of column names.
    """
    df = pd.read_csv(file_path)
    header = df.columns.tolist()

    if "y" not in df.columns:
        raise ValueError("The CSV must contain a 'y' column for labels.")

    X = df.drop(columns=["y"]).values
    y = df["y"].to_numpy()

    if X.shape[0] != y.shape[0]:
        raise ValueError("Number of samples in X and y must be equal.")

    if mode == "clf":
        if y.dtype != np.int64:
            raise TypeError("For classification, y must be of dtype int64.")
    elif mode == "regr":
        if y.dtype not in (np.int64, np.float64):
            raise TypeError(
                "For regression, y must be of dtype int64 or float64."
            )
    else:
        raise ValueError("Mode must be either 'clf' or 'regr'.")

    if verbose:
        print(f"Header: {header}")
        print(f"X shape: {X.shape}")
        print(f"y shape: {y.shape}")
        unique_classes = np.unique(y)
        print(f"Number of unique classes in y: {unique_classes.size}")

    return X, y, header


def cross_validate(
    model,
    X: np.ndarray,
    y: np.ndarray,
    kfold: int,
    seed: int = 42,
    verbose: bool = False,
) -> Tuple[float, float]:
    """
    Perform k-fold cross-validation on the provided model.

    Parameters
    ----------
    model : object
        The model to be trained. Must have `train`, `predict`, and `loss` methods.
    X : np.ndarray
        Feature matrix.
    y : np.ndarray
        Label vector.
    kfold : int
        Number of folds.
    seed : int, optional
        Random seed for reproducibility. Default is 42.
    verbose : bool, optional
        If True, prints average training and validation losses.

    Returns
    -------
    avg_train_loss : float
        Average training loss across folds.
    avg_val_loss : float
        Average validation loss across folds.
    """
    def make_crossval_folds(num_samples: int, kfold: int, seed: int):
        rng = np.random.RandomState(seed)
        permuted = rng.permutation(num_samples)
        fold_sizes = np.full(kfold, num_samples // kfold, dtype=int)
        fold_sizes[: num_samples % kfold] += 1
        current = 0
        folds = []
        for fold_size in fold_sizes:
            start, stop = current, current + fold_size
            folds.append(permuted[start:stop])
            current = stop
        return folds

    num_samples = X.shape[0]
    folds = make_crossval_folds(num_samples, kfold, seed)

    total_train_loss = 0.0
    total_val_loss = 0.0

    for i, test_idx in enumerate(folds):
        train_idx = np.setdiff1d(np.arange(num_samples), test_idx)

        X_train, y_train = X[train_idx], y[train_idx]
        X_val, y_val = X[test_idx], y[test_idx]

        # Copy the model to avoid side effects
        model_copy = copy.deepcopy(model)

        # Train the model
        model_copy.train(X_train, y_train)

        # Predictions
        y_train_pred = model_copy.predict(X_train)
        y_val_pred = model_copy.predict(X_val)

        # Losses
        train_loss = model_copy.loss(X_train, y_train, y_train_pred)
        val_loss = model_copy.loss(X_val, y_val, y_val_pred)

        total_train_loss += train_loss
        total_val_loss += val_loss

    avg_train_loss = total_train_loss / kfold
    avg_val_loss = total_val_loss / kfold

    if verbose:
        print(f"Average training loss: {avg_train_loss}")
        print(f"Average validation loss: {avg_val_loss}")

    return avg_train_loss, avg_val_loss