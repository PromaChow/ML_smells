import torch
from torch import nn
from torch.autograd import Function

class CenterlossFunc(Function):
    @staticmethod
    def forward(ctx, feat, centers, labels, batch_size):
        # Select the center for each sample
        centers_batch = centers.index_select(0, labels)
        diff = feat - centers_batch
        loss = (diff.pow(2).sum() / 2.0) / batch_size

        ctx.save_for_backward(feat, centers_batch, diff, labels, centers)
        # Count occurrences of each class in the batch
        num_classes = centers.size(0)
        counts = torch.zeros(num_classes, device=feat.device, dtype=torch.float)
        ones = torch.ones_like(labels, dtype=torch.float)
        counts.scatter_add_(0, labels, ones)
        ctx.counts = counts
        ctx.batch_size = batch_size

        return loss

    @staticmethod
    def backward(ctx, grad_output):
        feat, centers_batch, diff, labels, centers = ctx.saved_tensors
        batch_size = ctx.batch_size
        counts = ctx.counts

        # Gradient w.r.t features
        grad_feat = -grad_output * diff / batch_size

        # Gradient w.r.t centers
        diff_cent = centers_batch - feat
        grad_cent = torch.zeros_like(centers)
        grad_cent.scatter_add_(0, labels.unsqueeze(1).expand(-1, centers.size(1)), diff_cent)

        inv_counts = counts.unsqueeze(1).clamp(min=1.0)
        grad_cent = grad_cent / inv_counts
        grad_cent = grad_cent / batch_size

        return grad_feat, grad_cent, None, None


class CenterLoss(nn.Module):
    def __init__(self, num_classes: int, feat_dim: int):
        super().__init__()
        self.centers = nn.Parameter(torch.randn(num_classes, feat_dim))

    def forward(self, feat: torch.Tensor, label: torch.Tensor) -> torch.Tensor:
        if feat.dim() > 2:
            feat = feat.view(feat.size(0), -1)
        if feat.size(1) != self.centers.size(1):
            raise ValueError(
                f"Feature dimension {feat.size(1)} does not match center dimension {self.centers.size(1)}"
            )
        batch_size = torch.tensor(feat.size(0), dtype=feat.dtype, device=feat.device)
        return CenterlossFunc.apply(feat, self.centers, label, batch_size)
