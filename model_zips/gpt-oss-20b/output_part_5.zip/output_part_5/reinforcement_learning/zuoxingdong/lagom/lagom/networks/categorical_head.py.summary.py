import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.distributions import Categorical

def ortho_init(layer: nn.Linear, weight_scale: float = 1.0, constant_bias: float = 0.0) -> None:
    """Initialize a linear layer with orthogonal weights and constant bias."""
    nn.init.orthogonal_(layer.weight, gain=weight_scale)
    if layer.bias is not None:
        nn.init.constant_(layer.bias, constant_bias)

class CategoricalHead(nn.Module):
    def __init__(self, feature_dim: int, num_action: int, device: torch.device) -> None:
        super().__init__()
        self.action_head = nn.Linear(feature_dim, num_action)
        ortho_init(self.action_head, weight_scale=0.01, constant_bias=0.0)
        self.to(device)

    def forward(self, x: torch.Tensor) -> Categorical:
        scores = self.action_head(x)
        probs = F.softmax(scores, dim=-1)
        return Categorical(probs=probs)