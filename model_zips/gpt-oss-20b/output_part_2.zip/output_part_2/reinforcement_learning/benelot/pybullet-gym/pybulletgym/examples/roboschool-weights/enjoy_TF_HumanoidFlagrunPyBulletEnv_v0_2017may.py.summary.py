import numpy as np

def relu(x: np.ndarray) -> np.ndarray:
    return np.maximum(0, x)

def softmax(x: np.ndarray) -> np.ndarray:
    exp_shift = np.exp(x - np.max(x, axis=1, keepdims=True))
    return exp_shift / np.sum(exp_shift, axis=1, keepdims=True)

def forward_pass(
    X: np.ndarray,
    weights_dense1_w: np.ndarray,
    weights_dense1_b: np.ndarray,
    weights_dense2_w: np.ndarray,
    weights_dense2_b: np.ndarray,
    weights_final_w: np.ndarray,
    weights_final_b: np.ndarray,
) -> np.ndarray:
    # First dense layer
    z1 = X @ weights_dense1_w + weights_dense1_b
    a1 = relu(z1)

    # Second dense layer
    z2 = a1 @ weights_dense2_w + weights_dense2_b
    a2 = relu(z2)

    # Final output layer
    z3 = a2 @ weights_final_w + weights_final_b
    output = softmax(z3)

    return output

# Example usage
if __name__ == "__main__":
    batch_size = 8
    input_features = 1024
    hidden1 = 512
    hidden2 = 256
    output_classes = 50

    # Randomly initialize weights and biases for demonstration
    np.random.seed(42)
    weights_dense1_w = np.random.randn(input_features, hidden1)
    weights_dense1_b = np.random.randn(hidden1)
    weights_dense2_w = np.random.randn(hidden1, hidden2)
    weights_dense2_b = np.random.randn(hidden2)
    weights_final_w = np.random.randn(hidden2, output_classes)
    weights_final_b = np.random.randn(output_classes)

    # Random input data
    X = np.random.randn(batch_size, input_features)

    predictions = forward_pass(
        X,
        weights_dense1_w,
        weights_dense1_b,
        weights_dense2_w,
        weights_dense2_b,
        weights_final_w,
        weights_final_b,
    )

    print("Predictions shape:", predictions.shape)
    print("Predictions:", predictions)