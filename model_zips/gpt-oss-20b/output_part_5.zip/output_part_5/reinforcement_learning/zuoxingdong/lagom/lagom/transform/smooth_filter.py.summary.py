import numpy as np
from scipy.signal import savgol_filter

def smooth_filter(x, window_length, polyorder, **kwargs):
    data = np.asarray(x)
    assert data.ndim == 1, "Input must be one-dimensional"
    return savgol_filter(data, window_length=window_length, polyorder=polyorder, **kwargs)