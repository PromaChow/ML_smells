import gym
import gymnasium as gymnasium
import numpy as np
import torch
import torch.multiprocessing as mp
import torch.nn as nn
import torch.optim as optim
import logging
import os
import time
from dataclasses import dataclass, field
from typing import List, Dict, Any

# -----------------------------
# Configuration
# -----------------------------
@dataclass
class Config:
    env_name: str = "Hopper-v3"
    hidden_sizes: List[int] = field(default_factory=lambda: [64, 64])
    lr: float = 7e-4
    gamma: float = 0.99
    ent_coef: float = 0.01
    vf_coef: float = 0.5
    train_timesteps: int = 1_000_000
    batch_size: int = 64
    num_actors: int = 2
    num_checkpoints: int = 3
    log_freq: int = 1000
    eval_freq: int = 5000
    eval_num_episodes: int = 5
    use_gpu: bool = True
    seed: int = 1770966829
    checkpoint_dir: str = "logs/default/checkpoints"
    log_dir: str = "logs/default"

cfg = Config()

# -----------------------------
# Utilities
# -----------------------------
def set_global_seeds(seed: int):
    np.random.seed(seed)
    torch.manual_seed(seed)
    if cfg.use_gpu and torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

def get_device():
    return torch.device("cuda") if cfg.use_gpu and torch.cuda.is_available() else torch.device("cpu")

# -----------------------------
# Environment Wrappers
# -----------------------------
class ClipAction(gym.ActionWrapper):
    def __init__(self, env, clip_bounds=(-1.0, 1.0)):
        super().__init__(env)
        self.clip_bounds = clip_bounds

    def action(self, action):
        return np.clip(action, *self.clip_bounds)

class VecMonitor(gym.Wrapper):
    def __init__(self, env):
        super().__init__(env)
        self.episode_returns = []
        self.episode_lengths = []
        self.current_return = 0.0
        self.current_length = 0

    def step(self, action):
        obs, reward, terminated, truncated, info = self.env.step(action)
        self.current_return += reward
        self.current_length += 1
        if terminated or truncated:
            self.episode_returns.append(self.current_return)
            self.episode_lengths.append(self.current_length)
            self.current_return = 0.0
            self.current_length = 0
        return obs, reward, terminated, truncated, info

    def get_running_stats(self):
        if self.episode_returns:
            return np.mean(self.episode_returns[-100:]), np.mean(self.episode_lengths[-100:])
        return 0.0, 0.0

class VecStandardizeObservation(gym.ObservationWrapper):
    def __init__(self, env, clip=5.0):
        super().__init__(env)
        self.clip = clip
        self.mean = np.zeros(env.observation_space.shape)
        self.var = np.ones(env.observation_space.shape)
        self.count = 1e-4

    def observation(self, observation):
        self.mean = (self.mean * self.count + observation) / (self.count + 1)
        self.var = (self.var * self.count + (observation - self.mean)**2) / (self.count + 1)
        self.count += 1
        std = np.sqrt(self.var) + 1e-8
        return np.clip((observation - self.mean) / std, -self.clip, self.clip)

class VecStandardizeReward(gym.RewardWrapper):
    def __init__(self, env, clip=5.0):
        super().__init__(env)
        self.clip = clip
        self.mean = 0.0
        self.var = 1.0
        self.count = 1e-4

    def reward(self, reward):
        self.mean = (self.mean * self.count + reward) / (self.count + 1)
        self.var = (self.var * self.count + (reward - self.mean)**2) / (self.count + 1)
        self.count += 1
        std = np.sqrt(self.var) + 1e-8
        return np.clip((reward - self.mean) / std, -self.clip, self.clip)

class VecStepInfo(gym.Wrapper):
    def __init__(self, env):
        super().__init__(env)

    def step(self, action):
        obs, reward, terminated, truncated, info = self.env.step(action)
        info["step_info"] = {"reward": reward, "terminated": terminated, "truncated": truncated}
        return obs, reward, terminated, truncated, info

# -----------------------------
# Policy Network
# -----------------------------
class PolicyNetwork(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden_sizes):
        super().__init__()
        layers = []
        input_dim = obs_dim
        for h in hidden_sizes:
            layers.append(nn.Linear(input_dim, h))
            layers.append(nn.ReLU())
            input_dim = h
        self.shared = nn.Sequential(*layers)
        self.actor = nn.Linear(input_dim, act_dim)
        self.critic = nn.Linear(input_dim, 1)

    def forward(self, x):
        h = self.shared(x)
        logits = self.actor(h)
        value = self.critic(h)
        return logits, value

# -----------------------------
# Engine
# -----------------------------
class Engine:
    def __init__(self, model, lr, gamma, ent_coef, vf_coef, device):
        self.model = model.to(device)
        self.optimizer = optim.Adam(self.model.parameters(), lr=lr)
        self.gamma = gamma
        self.ent_coef = ent_coef
        self.vf_coef = vf_coef
        self.device = device

    def train_batch(self, batch):
        obs = torch.tensor(batch["obs"], dtype=torch.float32, device=self.device)
        actions = torch.tensor(batch["actions"], dtype=torch.long, device=self.device)
        rewards = torch.tensor(batch["rewards"], dtype=torch.float32, device=self.device)
        dones = torch.tensor(batch["dones"], dtype=torch.float32, device=self.device)

        # compute returns
        returns = []
        R = 0
        for r, d in zip(reversed(rewards.tolist()), reversed(dones.tolist())):
            if d:
                R = 0
            R = r + self.gamma * R
            returns.insert(0, R)
        returns = torch.tensor(returns, dtype=torch.float32, device=self.device)

        logits, values = self.model(obs)
        log_probs = torch.log_softmax(logits, dim=-1)
        action_log_probs = log_probs.gather(1, actions.unsqueeze(-1)).squeeze(-1)

        advantage = returns - values.squeeze(-1)

        policy_loss = -(action_log_probs * advantage.detach()).mean()
        value_loss = advantage.pow(2).mean()
        entropy = -(log_probs * torch.exp(log_probs)).sum(-1).mean()

        loss = policy_loss + self.vf_coef * value_loss - self.ent_coef * entropy

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        return {
            "policy_loss": policy_loss.item(),
            "value_loss": value_loss.item(),
            "entropy": entropy.item(),
            "total_loss": loss.item(),
        }

# -----------------------------
# Episode Runner
# -----------------------------
class EpisodeRunner:
    def __init__(self, env, model, device, max_steps):
        self.env = env
        self.model = model
        self.device = device
        self.max_steps = max_steps

    def run(self):
        obs = self.env.reset()[0]
        traj = {"obs": [], "actions": [], "rewards": [], "dones": []}
        for _ in range(self.max_steps):
            obs_tensor = torch.tensor(obs, dtype=torch.float32, device=self.device).unsqueeze(0)
            logits, _ = self.model(obs_tensor)
            probs = torch.softmax(logits, dim=-1)
            action = probs.multinomial(num_samples=1).item()
            next_obs, reward, terminated, truncated, _ = self.env.step(action)
            traj["obs"].append(obs)
            traj["actions"].append(action)
            traj["rewards"].append(reward)
            traj["dones"].append(terminated or truncated)
            obs = next_obs
            if terminated or truncated:
                break
        return traj

# -----------------------------
# make_env
# -----------------------------
def make_env():
    env = gymnasium.make(cfg.env_name)
    env = ClipAction(env)
    env = VecMonitor(env)
    env = VecStandardizeObservation(env)
    env = VecStandardizeReward(env)
    env = VecStepInfo(env)
    return env

# -----------------------------
# Actor Process
# -----------------------------
def actor_process(actor_id, queue, shared_state, total_timesteps):
    set_global_seeds(cfg.seed + actor_id)
    env = make_env()
    obs_dim = env.observation_space.shape[0]
    act_dim = env.action_space.n
    device = get_device()
    model = PolicyNetwork(obs_dim, act_dim, cfg.hidden_sizes).to(device)
    engine = Engine(model, cfg.lr, cfg.gamma, cfg.ent_coef, cfg.vf_coef, device)

    while True:
        # sync model
        state_dict = shared_state.get("state_dict")
        if state_dict is not None:
            model.load_state_dict(state_dict)
        # collect trajectory
        runner = EpisodeRunner(env, model, device, max_steps=2048)
        traj = runner.run()
        queue.put(traj)
        # update shared counter
        with total_timesteps.get_lock():
            total_timesteps.value += len(traj["rewards"])
        # exit condition
        if total_timesteps.value >= cfg.train_timesteps:
            break

# -----------------------------
# Learner Process
# -----------------------------
def learner_process(queue, shared_state, total_timesteps):
    set_global_seeds(cfg.seed)
    env = make_env()
    obs_dim = env.observation_space.shape[0]
    act_dim = env.action_space.n
    device = get_device()
    model = PolicyNetwork(obs_dim, act_dim, cfg.hidden_sizes).to(device)
    engine = Engine(model, cfg.lr, cfg.gamma, cfg.ent_coef, cfg.vf_coef, device)

    os.makedirs(cfg.checkpoint_dir, exist_ok=True)
    logger = logging.getLogger("learner")
    logger.setLevel(logging.INFO)
    fh = logging.FileHandler(os.path.join(cfg.log_dir, "learner.log"))
    logger.addHandler(fh)

    batch = {"obs": [], "actions": [], "rewards": [], "dones": []}
    steps_since_log = 0
    checkpoints_saved = 0

    while True:
        traj = queue.get()
        batch["obs"].extend(traj["obs"])
        batch["actions"].extend(traj["actions"])
        batch["rewards"].extend(traj["rewards"])
        batch["dones"].extend(traj["dones"])
        steps_since_log += len(traj["rewards"])

        if len(batch["obs"]) >= cfg.batch_size:
            metrics = engine.train_batch(batch)
            logger.info(f"Timesteps:{total_timesteps.value} Metrics:{metrics}")
            # update shared state
            shared_state["state_dict"] = model.state_dict()
            # reset batch
            batch = {"obs": [], "actions": [], "rewards": [], "dones": []}
            steps_since_log = 0

        if total_timesteps.value >= cfg.train_timesteps:
            break

    # save final checkpoint
    torch.save(model.state_dict(), os.path.join(cfg.checkpoint_dir, "final.pt"))

# -----------------------------
# Evaluator Process
# -----------------------------
def evaluator_process(shared_state, total_timesteps):
    set_global_seeds(cfg.seed + 100)
    env = make_env()
    obs_dim = env.observation_space.shape[0]
    act_dim = env.action_space.n
    device = get_device()
    model = PolicyNetwork(obs_dim, act_dim, cfg.hidden_sizes).to(device)

    logger = logging.getLogger("evaluator")
    logger.setLevel(logging.INFO)
    fh = logging.FileHandler(os.path.join(cfg.log_dir, "evaluator.log"))
    logger.addHandler(fh)

    last_eval = 0
    while True:
        if total_timesteps.value - last_eval >= cfg.eval_freq:
            state_dict = shared_state.get("state_dict")
            if state_dict is not None:
                model.load_state_dict(state_dict)
            returns = []
            horizons = []
            for _ in range(cfg.eval_num_episodes):
                obs = env.reset()[0]
                done = False
                ep_return = 0.0
                ep_len = 0
                while not done:
                    obs_tensor = torch.tensor(obs, dtype=torch.float32, device=device).unsqueeze(0)
                    logits, _ = model(obs_tensor)
                    probs = torch.softmax(logits, dim=-1)
                    action = probs.argmax().item()
                    obs, reward, terminated, truncated, _ = env.step(action)
                    ep_return += reward
                    ep_len += 1
                    done = terminated or truncated
                returns.append(ep_return)
                horizons.append(ep_len)
            avg_return = np.mean(returns)
            avg_horizon = np.mean(horizons)
            logger.info(f"Eval at {total_timesteps.value} - Return:{avg_return:.2f} Horizon:{avg_horizon:.2f}")
            last_eval = total_timesteps.value
        if total_timesteps.value >= cfg.train_timesteps:
            break
        time.sleep(1)

# -----------------------------
# Run Experiment
# -----------------------------
def run_experiment():
    mp.set_start_method("spawn")
    total_timesteps = mp.Value("i", 0)
    manager = mp.Manager()
    shared_state = manager.dict()
    queue = mp.Queue(maxsize=10)

    processes = []

    # Learner
    learner = mp.Process(target=learner_process, args=(queue, shared_state, total_timesteps))
    learner.start()
    processes.append(learner)

    # Actors
    for i in range(cfg.num_actors):
        actor = mp.Process(target=actor_process, args=(i, queue, shared_state, total_timesteps))
        actor.start()
        processes.append(actor)

    # Evaluator
    evaluator = mp.Process(target=evaluator_process, args=(shared_state, total_timesteps))
    evaluator.start()
    processes.append(evaluator)

    for p in processes:
        p.join()

if __name__ == "__main__":
    os.makedirs(cfg.log_dir, exist_ok=True)
    run_experiment()
