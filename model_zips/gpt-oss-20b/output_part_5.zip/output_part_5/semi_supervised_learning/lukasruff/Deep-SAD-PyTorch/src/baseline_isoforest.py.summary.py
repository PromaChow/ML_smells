import json
import logging
import os
import random
import sys
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, Tuple

import click
import matplotlib.pyplot as plt
import numpy as np
import torch
from sklearn.ensemble import IsolationForest
from torch.utils.data import DataLoader, TensorDataset

# ------------------- Configuration -------------------


@dataclass
class Config:
    dataset: str
    data_path: Path
    exp_path: Path
    normal_class: int
    outlier_class: int
    pollution_ratio: float
    ratio_known_normal: float
    ratio_known_outlier: float
    contamination: float
    n_estimators: int
    max_samples: str
    hybrid: bool
    autoencoder_path: Path | None
    pretrained_model_path: Path | None
    seed: int
    workers: int


# ------------------- Logging -------------------


def init_logging(exp_path: Path) -> None:
    log_file = exp_path / "log.txt"
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(message)s",
        handlers=[logging.FileHandler(log_file), logging.StreamHandler(sys.stdout)],
    )
    logging.info("Logging initialized. Log file at %s", log_file)


# ------------------- Seed Setting -------------------


def set_seed(seed: int) -> None:
    if seed == -1:
        return
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    logging.info("Random seed set to %s", seed)


# ------------------- Data Loading -------------------


def load_dataset(
    dataset_name: str,
    data_path: Path,
    normal_class: int,
    outlier_class: int,
    pollution_ratio: float,
) -> Tuple[TensorDataset, TensorDataset]:
    """
    Dummy implementation: generate random data.
    In practice, load real datasets.
    """
    np.random.seed(0)
    if dataset_name in {"mnist", "fmnist"}:
        img_shape = (1, 28, 28)
    elif dataset_name == "cifar10":
        img_shape = (3, 32, 32)
    else:
        img_shape = (1, 28, 28)

    # Generate 1000 samples per class
    num_samples = 1000
    train_data = np.random.randn(num_samples, *img_shape).astype(np.float32)
    train_labels = np.random.choice([normal_class, outlier_class], num_samples)

    test_data = np.random.randn(num_samples, *img_shape).astype(np.float32)
    test_labels = np.random.choice([normal_class, outlier_class], num_samples)

    # Convert to tensors
    train_dataset = TensorDataset(
        torch.tensor(train_data), torch.tensor(train_labels)
    )
    test_dataset = TensorDataset(
        torch.tensor(test_data), torch.tensor(test_labels)
    )
    logging.info(
        "Loaded %s dataset with %s training samples and %s test samples",
        dataset_name,
        len(train_dataset),
        len(test_dataset),
    )
    return train_dataset, test_dataset


# ------------------- Autoencoder (Placeholder) -------------------


class Autoencoder(torch.nn.Module):
    def __init__(self, input_dim: int, latent_dim: int):
        super().__init__()
        self.encoder = torch.nn.Sequential(
            torch.nn.Flatten(),
            torch.nn.Linear(input_dim, latent_dim),
            torch.nn.ReLU(),
        )
        self.decoder = torch.nn.Sequential(
            torch.nn.Linear(latent_dim, input_dim),
            torch.nn.Sigmoid(),
            torch.nn.Unflatten(1, (1, int(np.sqrt(input_dim)), int(np.sqrt(input_dim)))),
        )

    def forward(self, x):
        z = self.encoder(x)
        recon = self.decoder(z)
        return recon, z


def load_autoencoder(autoencoder_path: Path, device: torch.device) -> Autoencoder:
    # Dummy loading; in practice load model state_dict
    # Assuming input_dim matches dataset
    dummy_input_dim = 28 * 28 if "mnist" in autoencoder_path.name else 3 * 32 * 32
    model = Autoencoder(dummy_input_dim, 64).to(device)
    logging.info("Autoencoder model loaded from %s", autoencoder_path)
    return model


# ------------------- IsoForest Wrapper -------------------


class IsoForest:
    def __init__(
        self,
        n_estimators: int,
        max_samples: str,
        contamination: float,
        hybrid: bool,
        autoencoder: Autoencoder | None,
    ):
        self.hybrid = hybrid
        self.autoencoder = autoencoder
        self.model = IsolationForest(
            n_estimators=n_estimators, max_samples=max_samples, contamination=contamination
        )

    def fit(self, loader: DataLoader, device: torch.device) -> None:
        features = []
        for batch in loader:
            data, _ = batch
            data = data.to(device)
            if self.hybrid and self.autoencoder is not None:
                _, z = self.autoencoder(data)
                features.append(z.cpu().numpy())
            else:
                features.append(data.cpu().numpy())
        features = np.concatenate(features, axis=0)
        self.model.fit(features)
        logging.info("IsoForest training completed")

    def predict(self, loader: DataLoader, device: torch.device) -> np.ndarray:
        scores = []
        for batch in loader:
            data, _ = batch
            data = data.to(device)
            if self.hybrid and self.autoencoder is not None:
                _, z = self.autoencoder(data)
                feat = z.cpu().numpy()
            else:
                feat = data.cpu().numpy()
            scores.extend(self.model.decision_function(feat))
        return np.array(scores)

    def save(self, path: Path) -> None:
        # Save model parameters
        np.save(path / "isoforest.npy", self.model.__dict__)
        logging.info("IsoForest model saved to %s", path)

    def load(self, path: Path) -> None:
        # Load model parameters
        params = np.load(path / "isoforest.npy", allow_pickle=True).item()
        self.model = IsolationForest(**params)
        logging.info("IsoForest model loaded from %s", path)


# ------------------- Visualization -------------------


def plot_images_grid(
    images: np.ndarray,
    title: str,
    save_path: Path,
    rows: int = 8,
    cols: int = 8,
) -> None:
    fig, axes = plt.subplots(rows, cols, figsize=(cols, rows))
    for i, ax in enumerate(axes.flat):
        if i >= len(images):
            ax.axis("off")
            continue
        img = images[i]
        if img.ndim == 3 and img.shape[0] == 1:
            img = img.squeeze(0)
        ax.imshow(img, cmap="gray")
        ax.axis("off")
    plt.suptitle(title)
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close(fig)
    logging.info("Saved image grid to %s", save_path)


# ------------------- Main -------------------


@click.command()
@click.option("--dataset", type=click.Choice(["mnist", "fmnist", "cifar10"]), required=True)
@click.option("--data_path", type=click.Path(), required=True)
@click.option("--exp_path", type=click.Path(), required=True)
@click.option("--normal_class", type=int, required=True)
@click.option("--outlier_class", type=int, required=True)
@click.option("--pollution_ratio", type=float, default=0.0)
@click.option("--ratio_known_normal", type=float, default=1.0)
@click.option("--ratio_known_outlier", type=float, default=1.0)
@click.option("--contamination", type=float, default=0.1)
@click.option("--n_estimators", type=int, default=100)
@click.option("--max_samples", type=str, default="auto")
@click.option("--hybrid", is_flag=True)
@click.option("--autoencoder_path", type=click.Path(), default=None)
@click.option("--pretrained_model_path", type=click.Path(), default=None)
@click.option("--seed", type=int, default=-1)
@click.option("--workers", type=int, default=2)
def main(
    dataset,
    data_path,
    exp_path,
    normal_class,
    outlier_class,
    pollution_ratio,
    ratio_known_normal,
    ratio_known_outlier,
    contamination,
    n_estimators,
    max_samples,
    hybrid,
    autoencoder_path,
    pretrained_model_path,
    seed,
    workers,
):
    exp_path = Path(exp_path)
    exp_path.mkdir(parents=True, exist_ok=True)
    init_logging(exp_path)

    cfg = Config(
        dataset=dataset,
        data_path=Path(data_path),
        exp_path=exp_path,
        normal_class=normal_class,
        outlier_class=outlier_class,
        pollution_ratio=pollution_ratio,
        ratio_known_normal=ratio_known_normal,
        ratio_known_outlier=ratio_known_outlier,
        contamination=contamination,
        n_estimators=n_estimators,
        max_samples=max_samples,
        hybrid=hybrid,
        autoencoder_path=Path(autoencoder_path) if autoencoder_path else None,
        pretrained_model_path=Path(pretrained_model_path) if pretrained_model_path else None,
        seed=seed,
        workers=workers,
    )

    logging.info("Configuration:\n%s", json.dumps(asdict(cfg), indent=2))

    set_seed(cfg.seed)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logging.info("Using device: %s", device)

    train_dataset, test_dataset = load_dataset(
        cfg.dataset,
        cfg.data_path,
        cfg.normal_class,
        cfg.outlier_class,
        cfg.pollution_ratio,
    )

    train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True, num_workers=cfg.workers)
    test_loader = DataLoader(test_dataset, batch_size=64, shuffle=False, num_workers=cfg.workers)

    autoencoder = None
    if cfg.hybrid:
        if cfg.autoencoder_path is None:
            raise ValueError("Autoencoder path must be provided when hybrid mode is enabled")
        autoencoder = load_autoencoder(cfg.autoencoder_path, device)
        autoencoder.to(device)
        autoencoder.eval()

    model = IsoForest(
        n_estimators=cfg.n_estimators,
        max_samples=cfg.max_samples,
        contamination=cfg.contamination,
        hybrid=cfg.hybrid,
        autoencoder=autoencoder,
    )

    if cfg.pretrained_model_path is not None:
        model.load(Path(cfg.pretrained_model_path))
        logging.info("Loaded pre-trained model from %s", cfg.pretrained_model_path)

    model.fit(train_loader, device)

    test_scores = model.predict(test_loader, device)

    # Gather labels and indices
    labels = []
    indices = []
    for i, (_, lbl) in enumerate(test_loader):
        labels.extend(lbl.tolist())
        indices.extend(range(i * 64, i * 64 + len(lbl)))
    labels = np.array(labels)
    indices = np.array(indices)

    results = {
        "scores": test_scores.tolist(),
        "labels": labels.tolist(),
        "indices": indices.tolist(),
    }

    results_path = exp_path / "results.json"
    with open(results_path, "w") as f:
        json.dump(results, f, indent=2)
    logging.info("Results saved to %s", results_path)

    config_path = exp_path / "config.json"
    with open(config_path, "w") as f:
        json.dump(asdict(cfg), f, indent=2)
    logging.info("Configuration saved to %s", config_path)

    # Visualization for image datasets
    if cfg.dataset in {"mnist", "fmnist", "cifar10"}:
        # Sort by scores (higher means more anomalous for IsolationForest)
        sorted_indices = np.argsort(-test_scores)
        top_anomalous = sorted_indices[:32]
        top_normal = sorted_indices[-32:]

        # Retrieve images
        all_images = []
        for data, _ in test_loader:
            all_images.append(data.numpy())
        all_images = np.concatenate(all_images, axis=0)

        anomalous_imgs = all_images[top_anomalous]
        normal_imgs = all_images[top_normal]

        plot_images_grid(
            anomalous_imgs, "Top 32 Anomalous", exp_path / "all_high.png"
        )
        plot_images_grid(
            normal_imgs, "Top 32 Normal", exp_path / "all_low.png"
        )
        plot_images_grid(
            anomalous_imgs, "Anomalous Detail", exp_path / "normals_high.png"
        )
        plot_images_grid(
            normal_imgs, "Normal Detail", exp_path / "normals_low.png"
        )


if __name__ == "__main__":
    main()
