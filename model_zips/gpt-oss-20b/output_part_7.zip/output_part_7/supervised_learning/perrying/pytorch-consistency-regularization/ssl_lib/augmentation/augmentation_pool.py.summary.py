import random
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image, ImageEnhance, ImageOps

def _gen_cutout_coord(image, level, magnitude, max_level):
    """
    Generate cutout coordinates (x1, y1, x2, y2) for an image or tensor.
    """
    if isinstance(image, Image.Image):
        width, height = image.size
    else:
        # Assume tensor shape (..., H, W)
        if image.dim() == 3:
            _, height, width = image.shape
        elif image.dim() == 4:
            _, _, height, width = image.shape
        else:
            raise ValueError("Unsupported tensor shape for cutout coordinates.")
    cutout_size = int((level / magnitude) * max_level)
    cutout_size = min(cutout_size, min(width, height))
    x_center = random.randint(0, width)
    y_center = random.randint(0, height)
    x1 = max(0, x_center - cutout_size // 2)
    y1 = max(0, y_center - cutout_size // 2)
    x2 = min(width, x_center + cutout_size // 2)
    y2 = min(height, y_center + cutout_size // 2)
    return x1, y1, x2, y2

# ---------- PIL Image Transformations ----------
def pil_autocontrast(img, magnitude=1.0, max_level=1.0):
    img = img.convert("RGB")
    img = ImageOps.autocontrast(img)
    return img.convert("RGBA")

def pil_adjust_brightness(img, level, magnitude, max_level, max_brightness=1.8):
    level = (level / magnitude) * max_level + 0.1
    enhancer = ImageEnhance.Brightness(img)
    return enhancer.enhance(max_brightness * level)

def pil_adjust_color(img, level, magnitude, max_level, max_color=1.8):
    level = (level / magnitude) * max_level + 0.1
    enhancer = ImageEnhance.Color(img)
    return enhancer.enhance(max_color * level)

def pil_adjust_contrast(img, level, magnitude, max_level, max_contrast=1.8):
    level = (level / magnitude) * max_level + 0.1
    enhancer = ImageEnhance.Contrast(img)
    return enhancer.enhance(max_contrast * level)

def pil_adjust_sharpness(img, level, magnitude, max_level, max_sharpness=1.8):
    level = (level / magnitude) * max_level + 0.1
    enhancer = ImageEnhance.Sharpness(img)
    return enhancer.enhance(max_sharpness * level)

def pil_equalize(img, magnitude=1.0, max_level=1.0):
    return ImageOps.equalize(img)

def pil_invert(img, magnitude=1.0, max_level=1.0):
    return ImageOps.invert(img)

def pil_posterize(img, magnitude=1.0, max_level=1.0):
    # Use 4-bit depth regardless of magnitude
    return ImageOps.posterize(img, 4)

def pil_solarize(img, level, magnitude, max_level, threshold_max=256):
    level = (level / magnitude) * max_level
    threshold = int(level)
    return ImageOps.solarize(img, threshold)

def pil_rotate(img, level, magnitude, max_level):
    degrees = (level / magnitude) * max_level
    if random.random() < 0.5:
        degrees = -degrees
    return img.rotate(degrees, resample=Image.BILINEAR, expand=False)

def pil_shear(img, level, magnitude, max_level):
    shear = (level / magnitude) * max_level
    if random.random() < 0.5:
        shear = -shear
    return img.transform(
        img.size,
        Image.AFFINE,
        (1, shear, 0, 0, 1, 0),
        resample=Image.BILINEAR
    )

def pil_translate(img, level, magnitude, max_level):
    offset = (level / magnitude) * max_level
    if random.random() < 0.5:
        offset = -offset
    return img.transform(
        img.size,
        Image.AFFINE,
        (1, 0, offset, 0, 1, 0),
        resample=Image.BILINEAR
    )

def pil_cutout(img, level, magnitude, max_level):
    x1, y1, x2, y2 = _gen_cutout_coord(img, level, magnitude, max_level)
    cutout = Image.new("RGBA", (x2 - x1, y2 - y1), (127, 127, 127, 0))
    img.paste(cutout, (x1, y1))
    return img

# ---------- PyTorch Tensor Transformations ----------
class TorchCutout:
    def __init__(self, magnitude=1.0, max_level=1.0, level=1.0):
        self.magnitude = magnitude
        self.max_level = max_level
        self.level = level

    def __call__(self, tensor):
        """
        tensor: [C, H, W] or [B, C, H, W]
        """
        if tensor.dim() == 3:
            C, H, W = tensor.shape
            mask = torch.ones_like(tensor)
            x1, y1, x2, y2 = _gen_cutout_coord(tensor, self.level, self.magnitude, self.max_level)
            mask[:, y1:y2, x1:x2] = 0
            return tensor * mask
        elif tensor.dim() == 4:
            B, C, H, W = tensor.shape
            mask = torch.ones_like(tensor)
            for i in range(B):
                x1, y1, x2, y2 = _gen_cutout_coord(tensor[i], self.level, self.magnitude, self.max_level)
                mask[i, :, y1:y2, x1:x2] = 0
            return tensor * mask
        else:
            raise ValueError("Unsupported tensor shape for TorchCutout.")

class GaussianNoise:
    def __init__(self, std=0.1):
        self.std = std

    def __call__(self, tensor):
        noise = torch.randn_like(tensor) * self.std
        return tensor + noise

class RandomFlip:
    def __init__(self, flip_prob=0.5):
        self.flip_prob = flip_prob

    def __call__(self, tensor):
        if random.random() < self.flip_prob:
            return torch.flip(tensor, dims=[-1])  # horizontal flip
        return tensor

class BatchRandomFlip:
    def __init__(self, flip_prob=0.5):
        self.flip_prob = flip_prob

    def __call__(self, tensor):
        if random.random() < self.flip_prob:
            return torch.flip(tensor, dims=[-1])
        return tensor

class RandomCrop:
    def __init__(self, size, padding=0):
        self.size = size
        self.padding = padding

    def __call__(self, tensor):
        if self.padding > 0:
            tensor = F.pad(tensor, (self.padding, self.padding, self.padding, self.padding))
        _, H, W = tensor.shape
        new_h, new_w = self.size
        top = random.randint(0, H - new_h)
        left = random.randint(0, W - new_w)
        return tensor[:, top:top + new_h, left:left + new_w]

class BatchRandomCrop:
    def __init__(self, size, padding=0):
        self.size = size
        self.padding = padding

    def __call__(self, tensor):
        if self.padding > 0:
            tensor = F.pad(tensor, (self.padding, self.padding, self.padding, self.padding))
        B, C, H, W = tensor.shape
        new_h, new_w = self.size
        crops = []
        for i in range(B):
            top = random.randint(0, H - new_h)
            left = random.randint(0, W - new_w)
            crops.append(tensor[i:i+1, :, top:top+new_h, left:left+new_w])
        return torch.cat(crops, dim=0)

class ZCA:
    def __init__(self, mean, scale):
        self.mean = mean  # Tensor shape [C]
        self.scale = scale  # Tensor shape [C]

    def __call__(self, tensor):
        return (tensor - self.mean[:, None, None]) * self.scale[:, None, None]

class GCN:
    def __init__(self, multiplier=1.0, eps=1e-8):
        self.multiplier = multiplier
        self.eps = eps

    def __call__(self, tensor):
        mean = tensor.mean(dim=[-2, -1], keepdim=True)
        tensor = tensor - mean
        norm = tensor.view(tensor.shape[0], -1).norm(p=2, dim=1, keepdim=True)
        norm = norm.view(-1, 1, 1) + self.eps
        return tensor * (self.multiplier / norm)

# ---------- NumPy Array Transformation ----------
def numpy_batch_gcn(arr, multiplier=1.0, eps=1e-8):
    """
    arr: numpy array of shape [B, C, H, W] or [C, H, W]
    """
    if arr.ndim == 3:
        B = 1
        arr = arr[None, ...]
    else:
        B = arr.shape[0]
    mean = arr.mean(axis=(2, 3), keepdims=True)
    arr = arr - mean
    norm = np.linalg.norm(arr, axis=(2, 3), keepdims=True)
    norm = np.where(norm == 0, eps, norm)
    return arr * (multiplier / norm)
