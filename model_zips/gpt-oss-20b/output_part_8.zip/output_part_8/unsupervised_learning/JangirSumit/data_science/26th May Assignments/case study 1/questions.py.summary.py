import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn import metrics

def main():
    # 1. Data Loading and Preprocessing
    df = pd.read_csv("voice.csv")
    print("First five rows of the dataset:")
    print(df.head())

    # Map target variable to numeric
    df["label"] = df["label"].map({"male": 0, "female": 1})

    # Features and target
    X = df.iloc[:, :19]
    y = df["label"]

    # 2. Train-Test Split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=10
    )

    # 3. Initial Model Training and Evaluation
    model_initial = LogisticRegression(max_iter=1000, random_state=10)
    model_initial.fit(X_train, y_train)
    y_pred_initial = model_initial.predict(X_test)
    accuracy_initial = metrics.accuracy_score(y_test, y_pred_initial)
    print(f"Initial model accuracy: {accuracy_initial:.4f}")

    # 4. Correlation Analysis
    corr_matrix = df.drop(columns="label").corr()
    plt.figure(figsize=(10, 8))
    sns.heatmap(corr_matrix, annot=True, fmt=".2f", cmap="coolwarm")
    plt.title("Correlation Matrix Heatmap")
    plt.tight_layout()
    plt.show()

    # 5. Feature Selection Based on Correlation
    columns_to_drop = ["median", "Q25", "centroid", "dfrange"]
    X_reduced = df.drop(columns=["label"] + columns_to_drop)

    # 6. Refined Model Training and Evaluation
    X_train_r, X_test_r, y_train_r, y_test_r = train_test_split(
        X_reduced, y, test_size=0.2, random_state=10
    )
    model_refined = LogisticRegression(max_iter=1000, random_state=10)
    model_refined.fit(X_train_r, y_train_r)
    y_pred_refined = model_refined.predict(X_test_r)
    accuracy_refined = metrics.accuracy_score(y_test_r, y_pred_refined)
    print(f"Refined model accuracy: {accuracy_refined:.4f}")

    # Compare accuracies
    print(f"Accuracy improvement: {accuracy_refined - accuracy_initial:.4f}")

if __name__ == "__main__":
    main()
