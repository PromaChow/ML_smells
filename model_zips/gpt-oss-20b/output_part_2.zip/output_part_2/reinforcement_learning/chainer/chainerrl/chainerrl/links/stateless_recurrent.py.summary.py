import chainer
from chainer import Chain, ChainList, Variable, functions as F, links as L
from chainer.links.recurrent import NStepLSTM, NStepGRU, NStepRNN
from abc import ABC, abstractmethod
from typing import List, Tuple, Any, Union, Iterable, Sequence, Optional


def split_one_step_batch_input(inputs: Union[Variable, Tuple[Variable, ...]]) -> List[Union[Variable, Tuple[Variable, ...]]]:
    if isinstance(inputs, tuple):
        split_lists = [split_one_step_batch_input(inp) for inp in inputs]
        return list(zip(*split_lists))
    else:
        n = inputs.shape[0]
        return F.split_axis(inputs, n, axis=0)


def is_recurrent_link(layer: Any) -> bool:
    return isinstance(layer, (NStepLSTM, NStepGRU, NStepRNN, StatelessRecurrent))


def split_batched_sequences(seqs: Union[Variable, Tuple[Variable, ...]], sections: Sequence[int]) -> List[Union[Variable, Tuple[Variable, ...]]]:
    if isinstance(seqs, tuple):
        split_lists = [split_batched_sequences(s, sections) for s in seqs]
        return [tuple(items) for items in zip(*split_lists)]
    else:
        return F.split_axis(seqs, sections, axis=0)


def concatenate_sequences(seqs: List[Union[Variable, Tuple[Variable, ...]]]) -> Union[Variable, Tuple[Variable, ...]]:
    if not seqs:
        return None  # or raise error
    if isinstance(seqs[0], tuple):
        return tuple(concatenate_sequences([s[i] for s in seqs]) for i in range(len(seqs[0])))
    else:
        return F.concat(seqs, axis=0)


def call_recurrent_link(link: Any, *sequences: Sequence[Variable], states: Optional[Tuple[Any, ...]] = None) -> Tuple[List[Variable], Optional[Tuple[Any, ...]]]:
    if states is None:
        return link(*sequences)
    else:
        return link(*sequences, *states)


def mask_recurrent_state_at(link: Any, state: Any, indices: Iterable[int]) -> Any:
    if isinstance(link, NStepLSTM):
        h, c = state
        mask = F.where(F.arange(h[0].shape[0])[:, None] == F.array(indices), 0, 1)
        h_masked = [h_i * mask for h_i in h]
        c_masked = [c_i * mask for c_i in c]
        return h_masked, c_masked
    elif isinstance(link, (NStepGRU, NStepRNN)):
        h = state
        mask = F.where(F.arange(h[0].shape[0])[:, None] == F.array(indices), 0, 1)
        h_masked = [h_i * mask for h_i in h]
        return h_masked
    elif isinstance(link, StatelessRecurrent):
        return link.mask_recurrent_state_at(state, indices)
    else:
        return state


def get_recurrent_state_at(link: Any, state: Any, indices: Iterable[int]) -> Any:
    if isinstance(link, NStepLSTM):
        h, c = state
        h_slice = [h_i[indices] for h_i in h]
        c_slice = [c_i[indices] for c_i in c]
        return h_slice, c_slice
    elif isinstance(link, (NStepGRU, NStepRNN)):
        h = state
        h_slice = [h_i[indices] for h_i in h]
        return h_slice
    elif isinstance(link, StatelessRecurrent):
        return link.get_recurrent_state_at(state, indices)
    else:
        return state


def concatenate_recurrent_states(link: Any, state: Any) -> Any:
    if isinstance(link, NStepLSTM):
        h, c = state
        h_concat = concatenate_sequences(h)
        c_concat = concatenate_sequences(c)
        return h_concat, c_concat
    elif isinstance(link, (NStepGRU, NStepRNN)):
        h = state
        return concatenate_sequences(h)
    elif isinstance(link, StatelessRecurrent):
        return link.concatenate_recurrent_states(state)
    else:
        return state


def mask_recurrent_states_of_links_at(links: List[Any], states: List[Any], indices: Iterable[int]) -> List[Any]:
    new_states = []
    for link, state in zip(links, states):
        new_states.append(mask_recurrent_state_at(link, state, indices))
    return new_states


def get_recurrent_states_of_links_at(links: List[Any], states: List[Any], indices: Iterable[int]) -> List[Any]:
    new_states = []
    for link, state in zip(links, states):
        new_states.append(get_recurrent_state_at(link, state, indices))
    return new_states


def concatenate_recurrent_states_of_links(links: List[Any], states: List[Any]) -> List[Any]:
    new_states = []
    for link, state in zip(links, states):
        new_states.append(concatenate_recurrent_states(link, state))
    return new_states


class StatelessRecurrent(ABC):
    @abstractmethod
    def n_step_forward(self, xs: List[Variable], hs: Any, cs: Any) -> Tuple[List[Variable], Any, Any]:
        raise NotImplementedError

    @abstractmethod
    def __call__(self, *xs: Variable, **kwargs) -> Variable:
        raise NotImplementedError

    @abstractmethod
    def mask_recurrent_state_at(self, state: Any, indices: Iterable[int]) -> Any:
        raise NotImplementedError

    @abstractmethod
    def get_recurrent_state_at(self, state: Any, indices: Iterable[int]) -> Any:
        raise NotImplementedError

    @abstractmethod
    def concatenate_recurrent_states(self, state: Any) -> Any:
        raise NotImplementedError


class StatelessRecurrentChainList(ChainList, StatelessRecurrent):
    def __init__(self, *args: Any):
        super().__init__(*args)

    @property
    def recurrent_children(self) -> List[Any]:
        return [link for link in self.links if is_recurrent_link(link)]

    def n_step_forward(self, xs: List[Variable], hs: List[Any], cs: List[Any]) -> Tuple[List[Variable], List[Any], List[Any]]:
        new_xs = xs
        new_hs = hs
        new_cs = cs
        for link in self.links:
            if isinstance(link, StatelessRecurrent):
                new_xs, new_hs, new_cs = link.n_step_forward(new_xs, new_hs, new_cs)
            else:
                new_xs = [link(x) for x in new_xs]
        return new_xs, new_hs, new_cs

    def __call__(self, *xs: Variable) -> List[Variable]:
        results = xs
        for link in self.links:
            if isinstance(link, StatelessRecurrent):
                results, _, _ = link(*results)
            else:
                results = [link(r) for r in results]
        return results

    def mask_recurrent_state_at(self, states: List[Any], indices: Iterable[int]) -> List[Any]:
        return [mask_recurrent_state_at(link, state, indices) for link, state in zip(self.recurrent_children, states)]

    def get_recurrent_state_at(self, states: List[Any], indices: Iterable[int]) -> List[Any]:
        return [get_recurrent_state_at(link, state, indices) for link, state in zip(self.recurrent_children, states)]

    def concatenate_recurrent_states(self, states: List[Any]) -> List[Any]:
        return [concatenate_recurrent_states(link, state) for link, state in zip(self.recurrent_children, states)]