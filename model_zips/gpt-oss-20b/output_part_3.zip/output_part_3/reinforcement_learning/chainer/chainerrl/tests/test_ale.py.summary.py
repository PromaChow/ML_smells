import random
import sys
import tempfile
import unittest
import os
import numpy as np
from PIL import Image
from chainerrl.envs.ale import ALEEnv


class TestALE(unittest.TestCase):
    def test_state(self):
        env = ALEEnv(game="breakout")
        env.reset()
        state = env.state
        self.assertIsInstance(state, list)
        self.assertEqual(len(state), 4)
        for frame in state:
            self.assertIsInstance(frame, np.ndarray)
            self.assertEqual(frame.shape, (84, 84))
            self.assertEqual(frame.dtype, np.uint8)

    def test_episode(self):
        env = ALEEnv(game="breakout")
        env.reset()
        self.assertFalse(env.terminal())
        prev_state = None
        while not env.terminal():
            state = env.state
            for frame in state:
                self.assertIsInstance(frame, np.ndarray)
                self.assertEqual(frame.shape, (84, 84))
                self.assertEqual(frame.dtype, np.uint8)
            print(f"Frame sum: {sum(frame.sum() for frame in state)}")
            action = random.choice(env.available_actions())
            reward, terminal, _ = env.step(action)
            if prev_state is not None:
                for i in range(3):
                    np.testing.assert_array_equal(prev_state[i + 1], state[i])
            prev_state = state

    def test_current_screen(self):
        tmpdir = tempfile.mkdtemp()
        for episode in range(6):
            env = ALEEnv(game="breakout")
            env.reset()
            frame_index = 0
            while not env.terminal():
                state = env.state
                for idx, frame in enumerate(state):
                    img = Image.fromarray(frame, mode="L")
                    filename = f"episode{episode}_frame{frame_index}_idx{idx}.bmp"
                    img.save(os.path.join(tmpdir, filename))
                action = random.choice(env.available_actions())
                _, terminal, _ = env.step(action)
                frame_index += 1

    def test_reward(self):
        env = ALEEnv(game="pong")
        for episode in range(3):
            env.reset()
            total_reward = 0.0
            while not env.terminal():
                action = random.choice(env.available_actions())
                reward, terminal, _ = env.step(action)
                total_reward += reward
            self.assertTrue(-22 < total_reward < -15)
            env.reset()

    def test_seed(self):
        env1 = ALEEnv(game="breakout", seed=0)
        env2 = ALEEnv(game="breakout", seed=2**31 - 1)
        # No further checks required


if __name__ == "__main__":
    unittest.main()