import numpy as np
import chainerrl
import pytest

try:
    import cupy
    HAS_CUPY = True
except ImportError:
    cupy = None
    HAS_CUPY = False


@pytest.mark.parametrize('n', [1, 5])
@pytest.mark.parametrize('dtype', [np.float32, np.float64])
@pytest.mark.parametrize('backend', ['cpu', 'gpu'])
@pytest.mark.flaky(reruns=3, reruns_delay=1)
def test_conjugate_gradient(n, dtype, backend):
    if backend == 'gpu' and not HAS_CUPY:
        pytest.skip('CuPy not available')
    arr_mod = np if backend == 'cpu' else cupy
    np.random.seed(0)
    arr_mod.random.seed(0)

    A = arr_mod.random.rand(n, n).astype(dtype)
    A = arr_mod.dot(A, A.T) + arr_mod.eye(n, dtype=dtype) * 1e-3
    x_ans = arr_mod.random.rand(n).astype(dtype)
    b = arr_mod.dot(A, x_ans)

    def A_product_func(v):
        return arr_mod.dot(A, v)

    x = chainerrl.misc.conjugate_gradient(A_product_func, b)

    assert x.dtype == dtype
    if backend == 'cpu':
        assert isinstance(x, np.ndarray)
    else:
        assert isinstance(x, cupy.ndarray)

    x_np = x.get() if backend == 'gpu' else x
    x_ans_np = x_ans.get() if backend == 'gpu' else x_ans
    assert np.allclose(x_np, x_ans_np, rtol=1e-3, atol=0)