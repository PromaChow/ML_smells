import numpy as np

class Atlas(WalkerBase, URDFBasedRobot):
    random_yaw = False
    foot_list = ["r_foot", "l_foot"]

    def __init__(self):
        WalkerBase.__init__(self, power=2.9)
        URDFBasedRobot.__init__(
            self,
            urdf_path="atlas/atlas_description/atlas_v4_with_multisense.urdf",
            base_body_part="pelvis",
            action_dim=30,
            obs_dim=70,
        )

    def alive_bonus(self):
        # Head position
        head_pos = self.head.get_position()
        z = head_pos[2]
        if z > 1.3:
            # Knee joint positions
            l_knee = self.get_joint_position("l_leg_kny")
            r_knee = self.get_joint_position("r_leg_kny")
            knees_at_limit = int(abs(l_knee) > 0.99) + int(abs(r_knee) > 0.99)
            return 4 - knees_at_limit
        else:
            return -1

    def robot_specific_reset(self):
        WalkerBase.robot_specific_reset(self)
        self.set_initial_orientation()
        self.head = self.get_body_part("head")

    def set_initial_orientation(self):
        yaw_center = 0.0
        yaw_random_spread = np.pi
        if getattr(self, "random_yaw", False):
            # np_random is assumed to be an attribute provided by the simulation environment
            if not hasattr(self, "np_random"):
                self.np_random = np.random.default_rng()
            yaw = yaw_center + self.np_random.uniform(-yaw_random_spread, yaw_random_spread)
        else:
            yaw = yaw_center

        # Default start positions if not defined elsewhere
        start_pos_x = getattr(self, "start_pos_x", 0.0)
        start_pos_y = getattr(self, "start_pos_y", 0.0)
        start_pos_z = getattr(self, "start_pos_z", 0.0)

        position = np.array([start_pos_x, start_pos_y, start_pos_z + 1.0])
        orientation = np.array([0.0, 0.0, yaw])

        self.reset_pose(position, orientation)
        self.initial_z = 1.5

    # Helper methods that are assumed to exist in the base classes
    def get_joint_position(self, joint_name):
        joint = self.get_body_part(joint_name)
        return joint.get_joint_position()

    def get_body_part(self, name):
        return self.body_parts[name]

    def reset_pose(self, position, orientation):
        self.set_position(position)
        self.set_orientation(orientation)