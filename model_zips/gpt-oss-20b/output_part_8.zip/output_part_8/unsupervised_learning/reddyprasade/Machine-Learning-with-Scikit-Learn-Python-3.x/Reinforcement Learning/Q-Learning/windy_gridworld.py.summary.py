import gym
import numpy as np
import sys
from gym.envs.toy_text.discrete import DiscreteEnv

# Action constants
UP = 0
RIGHT = 1
DOWN = 2
LEFT = 3

class WindyGridworldEnv(DiscreteEnv):
    metadata = {"render.modes": ["human", "ansi"]}

    def __init__(self):
        self.rows, self.cols = 7, 10
        nS = self.rows * self.cols
        nA = 4

        # Wind strengths per column (0-indexed)
        self.winds = np.zeros(self.cols, dtype=int)
        self.winds[3:6] = 1  # columns 3,4,5
        self.winds[6:8] = 2  # columns 6,7
        self.winds[8] = 1    # column 8

        self.goal = (3, 7)  # row, col

        # Build transition dictionary
        P = {}
        for s in range(nS):
            pos = np.unravel_index(s, (self.rows, self.cols))
            P[s] = {}
            for a in range(nA):
                prob, next_s, reward, done = self._calculate_transition_prob(pos, a)
                P[s][a] = [(prob, next_s, reward, done)]

        # Initial state distribution: start at (3,0)
        start_pos = (3, 0)
        start_index = np.ravel_multi_index(start_pos, (self.rows, self.cols))
        isd = {start_index: 1.0}

        super().__init__(nS, nA, P, isd)

    def _limit_coordinates(self, row, col):
        row = int(np.clip(row, 0, self.rows - 1))
        col = int(np.clip(col, 0, self.cols - 1))
        return row, col

    def _calculate_transition_prob(self, pos, action):
        row, col = pos
        if action == UP:
            drow, dcol = -1, 0
        elif action == RIGHT:
            drow, dcol = 0, 1
        elif action == DOWN:
            drow, dcol = 1, 0
        elif action == LEFT:
            drow, dcol = 0, -1
        else:
            raise ValueError("Invalid action")

        new_row = row + drow
        new_col = col + dcol

        # Apply wind effect (upward wind reduces row index)
        wind_strength = self.winds[new_col]
        new_row -= wind_strength

        new_row, new_col = self._limit_coordinates(new_row, new_col)
        new_state = np.ravel_multi_index((new_row, new_col), (self.rows, self.cols))

        done = (new_row, new_col) == self.goal
        reward = 0.0 if done else -1.0
        return 1.0, new_state, reward, done

    def render(self, mode='human'):
        if mode not in self.metadata["render.modes"]:
            raise NotImplementedError(f"Render mode {mode} not supported")

        out = sys.stdout
        if mode == "human":
            sys.stdout = out
        output = self._render()
        if mode == "human":
            print(output)
        else:
            return output

    def _render(self):
        lines = []
        agent_row, agent_col = np.unravel_index(self.s, (self.rows, self.cols))
        for r in range(self.rows):
            row_symbols = []
            for c in range(self.cols):
                if (r, c) == (agent_row, agent_col):
                    symbol = " x "
                elif (r, c) == self.goal:
                    symbol = " T "
                else:
                    symbol = " o "
                row_symbols.append(symbol)
            lines.append(''.join(row_symbols))
        return '\n'.join(lines)

    def close(self):
        pass
```