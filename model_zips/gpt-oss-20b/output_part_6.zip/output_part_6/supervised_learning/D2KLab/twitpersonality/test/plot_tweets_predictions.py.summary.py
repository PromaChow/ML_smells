import os
import csv
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error

# Configuration
x_scale = (0, 5.5)
y_scale = (0, 5.5)
plot_path = "./plots"

# Ensure plot directory exists
os.makedirs(plot_path, exist_ok=True)

# Helper function to read trait values from a CSV line
def parse_traits(row, delimiter):
    # Replace comma with dot for numeric conversion
    row = [s.replace(",", ".") for s in row]
    # Convert to float; ignore non-numeric entries
    try:
        values = [float(s) for s in row]
    except ValueError:
        return None
    return values

# Load ground truth labels
ground_truth = {"O": [], "C": [], "E": [], "A": [], "N": []}
with open("questionnaires.csv", newline="", encoding="utf-8") as f:
    for line in f:
        parts = line.strip().split(";")
        traits = parse_traits(parts, ";")
        if traits is None or len(traits) < 6:
            continue
        # Assuming O=1, C=2, E=3, A=4, N=5 (0-indexed)
        ground_truth["O"].append(traits[1])
        ground_truth["C"].append(traits[2])
        ground_truth["E"].append(traits[3])
        ground_truth["A"].append(traits[4])
        ground_truth["N"].append(traits[5])

# Load predictions from three models
def load_predictions(file_path):
    preds = {"O": [], "C": [], "E": [], "A": [], "N": []}
    with open(file_path, newline="", encoding="utf-8") as f:
        for line in f:
            parts = line.strip().split(",")
            traits = parse_traits(parts, ",")
            if traits is None or len(traits) < 6:
                continue
            preds["O"].append(traits[1])
            preds["C"].append(traits[2])
            preds["E"].append(traits[3])
            preds["A"].append(traits[4])
            preds["N"].append(traits[5])
    return preds

preds1 = load_predictions("personality_predictions1.csv")
preds2 = load_predictions("personality_predictions1_big.csv")
preds3 = load_predictions("personality_predictions1_big_userWise.csv")

# Compute MSE for each trait and model
mse_results = []
for trait in ["O", "C", "E", "A", "N"]:
    actual = np.array(ground_truth[trait])
    for idx, preds in enumerate([preds1, preds2, preds3], start=1):
        predicted = np.array(preds[trait])
        mse = mean_squared_error(actual, predicted)
        mse_results.append([trait, str(idx), mse])

# Save MSE results to CSV
with open("twitusers_predictions_benchmark_smallBig.csv", "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["Trait", "Model", "MSE"])
    for row in mse_results:
        writer.writerow(row)

# Generate scatter plots
colors = {"1": "blue", "2": "red", "3": "green"}
for trait in ["O", "C", "E", "A", "N"]:
    plt.figure(figsize=(6, 6))
    actual = np.array(ground_truth[trait])
    plt.scatter(actual, np.array(preds1[trait]), color=colors["1"], label="Model 1")
    plt.scatter(actual, np.array(preds2[trait]), color=colors["2"], label="Model 2")
    plt.scatter(actual, np.array(preds3[trait]), color=colors["3"], label="Model 3")
    plt.xlim(x_scale)
    plt.ylim(y_scale)
    plt.xlabel("Actual")
    plt.ylabel("Predicted")
    plt.title(f"{trait} Trait Comparison")
    plt.legend()
    plt.tight_layout()
    plot_file = os.path.join(plot_path, f"{trait}_comparison.png")
    plt.savefig(plot_file)
    plt.close()