import matplotlib.pyplot as plt
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

def main():
    # 1. Data Loading and Initial Visualization
    digits = load_digits()
    plt.figure(figsize=(2, 2))
    plt.imshow(digits.images[0], cmap='gray')
    plt.title("First sample")
    plt.axis('off')
    plt.show()

    # 2. Data Preparation
    images = digits.images.reshape((len(digits.images), -1))
    labels = digits.target

    # 3. Train-Test Split
    train_x, test_x, train_y, test_y = train_test_split(
        images, labels, test_size=0.2, random_state=10, stratify=labels
    )

    # 4. LDA Transformation
    lda = LinearDiscriminantAnalysis(n_components=5)
    lda.fit(train_x, train_y)
    print("Explained variance ratio by LDA components:")
    print(lda.explained_variance_ratio_)

    # 5. Data Projection
    train_x_lda = lda.transform(train_x)
    test_x_lda = lda.transform(test_x)

    # 6. Logistic Regression on Transformed Data
    logreg = LogisticRegression(max_iter=1000, random_state=10)
    logreg.fit(train_x_lda, train_y)
    predictions = logreg.predict(test_x_lda)

    # 7. Accuracy Evaluation
    acc = accuracy_score(test_y, predictions)
    print(f"Logistic Regression accuracy on LDA-transformed test set: {acc:.4f}")

if __name__ == "__main__":
    main()
