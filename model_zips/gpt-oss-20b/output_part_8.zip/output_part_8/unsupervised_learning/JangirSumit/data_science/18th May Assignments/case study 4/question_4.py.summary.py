import pandas as pd
import matplotlib.pyplot as plt

# Load the dataset
df = pd.read_csv('BigMartSalesData.csv')

# Keep only the relevant columns
df = df[['InvoiceDate', 'Amount']]

# Convert InvoiceDate to datetime
df['InvoiceDate'] = pd.to_datetime(df['InvoiceDate'])

# Aggregate amounts by InvoiceDate
agg = df.groupby('InvoiceDate')['Amount'].sum().reset_index()

# Create scatter plot
plt.figure(figsize=(10, 6))
plt.scatter(agg['InvoiceDate'], agg['Amount'], color='blue', alpha=0.7)
plt.xlabel('Invoice Date')
plt.ylabel('Total Amount')
plt.title('Invoice Amounts Over Time')
plt.ylim(20000, 100000)
# Note: Most amounts fall within the 20,000–30,000 range.
plt.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()