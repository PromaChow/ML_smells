import sys
import random
import logging
import tensorflow as tf
import numpy as np

# External modules assumed to be available
from Features import make_feature_planes_stones_4liberties_4history_ko_4captures_komi
from Normalization import apply_featurewise_normalization_D
from Symmetry import make_symmetry_batch
from Checkpoint import restore_from_checkpoint
from EvalModels import Conv11PosDepFC1ELU
from gtp import GTP  # Assumed GTP implementation


logging.basicConfig(filename='log_engine.txt', level=logging.INFO,
                    format='%(asctime)s %(levelname)s: %(message)s')


def average_probs_over_symmetries(probs, symmetries):
    """Average probabilities over symmetry transformations."""
    # probs shape: (num_symmetries, board_size*board_size)
    return np.mean(probs, axis=0)


class EvalEngine:
    def __init__(self, model, board):
        self.board = board
        self.graph = tf.Graph()
        with self.graph.as_default():
            self.input_placeholder = tf.placeholder(tf.float32,
                                                    shape=[None, 22, 19, 19],
                                                    name='input')
            self.probs_op = model.inference(self.input_placeholder)
            self.sess = tf.Session()
            self.sess.run(tf.global_variables_initializer())

            checkpoint_dir = model.train_dir
            restore_from_checkpoint(self.sess, checkpoint_dir)

    def get_position_eval(self):
        board_state = self.board.get_board_state()  # Assume this returns required state
        feature_planes = make_feature_planes_stones_4liberties_4history_ko_4captures_komi(
            board_state)
        normalized_features = apply_featurewise_normalization_D(feature_planes)

        sym_batch, symmetries = make_symmetry_batch(normalized_features)
        feed_dict = {self.input_placeholder: sym_batch}
        probs = self.sess.run(self.probs_op, feed_dict=feed_dict)

        avg_probs = average_probs_over_symmetries(probs, symmetries)

        if self.board.current_player == 'W':
            avg_probs = -avg_probs

        return avg_probs

    def pick_move(self):
        board_size = self.board.size
        while True:
            x = random.randint(0, board_size - 1)
            y = random.randint(0, board_size - 1)
            if self.board.play_is_legal(x, y):
                return (x, y)
            if self.board.no_legal_moves():
                return None  # Pass


def main():
    model = Conv11PosDepFC1ELU(N=19, Nfeat=22)
    board = None  # Assume board object will be set by GTP engine
    engine = EvalEngine(model, board)

    gtp = GTP()
    gtp.set_engine(engine)

    for cmd in gtp.commands():
        if cmd == 'genmove':
            move = engine.pick_move()
            if move is None:
                gtp.send_response('pass')
            else:
                gtp.send_response(f'{move[0]} {move[1]}')
        elif cmd == 'eval':
            probs = engine.get_position_eval()
            gtp.send_response(' '.join(map(str, probs)))
        else:
            gtp.send_response('unknown command')


if __name__ == '__main__':
    main()
