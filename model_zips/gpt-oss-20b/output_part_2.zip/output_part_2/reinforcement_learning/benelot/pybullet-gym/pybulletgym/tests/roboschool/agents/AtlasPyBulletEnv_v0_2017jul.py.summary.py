import numpy as np

# ------------------------------------------------------------------
# Weight and bias matrices for a three-layer feedforward network.
# Replace the placeholder values with the actual parameters of the model.
# ------------------------------------------------------------------
dense1_w = np.array([
    # Example: 4 input features -> 5 hidden neurons
    [0.2, -0.5, 0.3, 0.1, -0.4],
    [-0.3, 0.8, -0.2, 0.5, 0.0],
    [0.7, -0.1, 0.4, -0.6, 0.2],
    [-0.5, 0.3, -0.7, 0.9, -0.2]
], dtype=float)

dense1_b = np.array([0.1, -0.2, 0.05, 0.0, -0.1], dtype=float)

dense2_w = np.array([
    # Example: 5 hidden neurons -> 3 second-layer neurons
    [0.4, -0.6, 0.1],
    [-0.3, 0.7, -0.2],
    [0.5, -0.1, 0.3],
    [0.2, 0.4, -0.5],
    [-0.4, 0.6, 0.2]
], dtype=float)

dense2_b = np.array([0.05, -0.05, 0.1], dtype=float)

final_w = np.array([
    # Example: 3 second-layer neurons -> 2 output neurons
    [0.3, -0.2],
    [0.6, 0.4],
    [-0.1, 0.5]
], dtype=float)

final_b = np.array([0.0, 0.1], dtype=float)

# ------------------------------------------------------------------
# Activation functions
# ------------------------------------------------------------------
def relu(x: np.ndarray) -> np.ndarray:
    """Rectified Linear Unit activation."""
    return np.maximum(0, x)

# ------------------------------------------------------------------
# Forward propagation
# ------------------------------------------------------------------
def forward(x: np.ndarray) -> np.ndarray:
    """
    Perform a forward pass through the network.
    
    Parameters
    ----------
    x : np.ndarray
        Input data of shape (batch_size, input_features).
    
    Returns
    -------
    np.ndarray
        Output predictions of shape (batch_size, output_features).
    """
    # First dense layer
    dense1_out = x @ dense1_w + dense1_b
    dense1_act = relu(dense1_out)

    # Second dense layer
    dense2_out = dense1_act @ dense2_w + dense2_b
    dense2_act = relu(dense2_out)

    # Final output layer (linear activation)
    output = dense2_act @ final_w + final_b
    return output

# ------------------------------------------------------------------
# Example usage
# ------------------------------------------------------------------
if __name__ == "__main__":
    # Dummy input: 2 samples, each with 4 features
    sample_input = np.array([
        [0.5, -0.1, 0.3, 0.0],
        [-0.2, 0.4, -0.3, 0.8]
    ], dtype=float)

    predictions = forward(sample_input)
    print("Predictions:\n", predictions)