import argparse
import os
import random
import logging
import numpy as np
import gym
import torch
import torch.nn as nn
import torch.nn.functional as F
import chainerrl
from chainerrl import agents, misc, utils, experiments
from chainerrl.misc import draw_computational_graph, download_model, set_random_seed
from chainerrl.utils import EmpiricalNormalization
from chainerrl.agents.trpo import TrpoAgent
from chainerrl.policy import NormalDistPolicy

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--gpu", type=int, default=None, help="GPU device id")
    parser.add_argument("--env-id", type=str, default="Hopper-v2")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--output-dir", type=str, default="results")
    parser.add_argument("--steps", type=int, default=2_000_000)
    parser.add_argument("--eval-interval", type=int, default=100_000)
    parser.add_argument("--eval-n-runs", type=int, default=100)
    parser.add_argument("--render", action="store_true")
    parser.add_argument("--demo", action="store_true")
    parser.add_argument("--monitor", action="store_true")
    parser.add_argument("--load", type=str, default=None)
    parser.add_argument("--load-pretrained", action="store_true")
    parser.add_argument("--pretrained-best", action="store_true")
    parser.add_argument("--log-level", type=str, default="INFO")
    return parser.parse_args()

def make_env(env_id, seed, is_test=False, render=False, monitor=False, output_dir=None):
    def _make():
        env = gym.make(env_id)
        env.seed(seed if not is_test else (2**32 - 1 - seed))
        env.action_space.seed(seed)
        env.observation_space.seed(seed)
        if monitor and output_dir is not None:
            env = gym.wrappers.Monitor(env, os.path.join(output_dir, "video"), video_callable=lambda x: True, force=True)
        if render:
            env.render()
        return env
    return _make

def eval_performance(agent, env, n_runs):
    returns = []
    for _ in range(n_runs):
        obs = env.reset()
        ep_ret = 0.0
        done = False
        while not done:
            act = agent.act(obs, deterministic=True)
            obs, reward, done, _ = env.step(act)
            ep_ret += reward
        returns.append(ep_ret)
    arr = np.array(returns)
    return arr.mean(), np.median(arr), arr.std()

def build_policy_and_vf(obs_dim, act_dim, device):
    mean_net = nn.Sequential(
        nn.Linear(obs_dim, 64), nn.Tanh(),
        nn.Linear(64, 64), nn.Tanh(),
        nn.Linear(64, 64), nn.Tanh(),
        nn.Linear(64, act_dim)
    )
    log_std_net = nn.Sequential(
        nn.Linear(obs_dim, 64), nn.Tanh(),
        nn.Linear(64, 64), nn.Tanh(),
        nn.Linear(64, 64), nn.Tanh(),
        nn.Linear(64, act_dim)
    )
    policy = NormalDistPolicy(mean_net, log_std_net, action_space=None)
    vf = nn.Sequential(
        nn.Linear(obs_dim, 64), nn.Tanh(),
        nn.Linear(64, 64), nn.Tanh(),
        nn.Linear(64, 64), nn.Tanh(),
        nn.Linear(64, 1)
    )
    policy.to(device)
    vf.to(device)
    return policy, vf

def main():
    args = parse_args()
    logging.basicConfig(level=getattr(logging, args.log_level.upper()))
    set_random_seed(args.seed)
    np.random.seed(args.seed)
    random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device(f"cuda:{args.gpu}" if args.gpu is not None and torch.cuda.is_available() else "cpu")

    output_dir = experiments.prepare_output_dir(args.output_dir, args)
    train_env_fn = make_env(args.env_id, args.seed, render=args.render, monitor=args.monitor, output_dir=output_dir)
    test_env_fn = make_env(args.env_id, args.seed, is_test=True, monitor=args.monitor, output_dir=output_dir)

    train_env = train_env_fn()
    test_env = test_env_fn()
    obs_dim = train_env.observation_space.shape[0]
    act_dim = train_env.action_space.shape[0]

    norm = EmpiricalNormalization(train_env.observation_space, clip=5.0, device=device)

    policy, vf = build_policy_and_vf(obs_dim, act_dim, device)
    policy.action_space = train_env.action_space

    vf_optimizer = torch.optim.Adam(vf.parameters(), lr=1e-3)

    dummy_obs = torch.zeros((1, obs_dim), device=device)
    draw_computational_graph(policy, dummy_obs, os.path.join(output_dir, "policy.png"))
    draw_computational_graph(vf, dummy_obs, os.path.join(output_dir, "vf.png"))

    agent = TrpoAgent(
        policy=policy,
        vf=vf,
        vf_optimizer=vf_optimizer,
        norm=norm,
        max_kl=0.01,
        cg_iters=20,
        cg_damping=0.1,
        gamma=0.995,
        lambd=0.97,
        vf_epochs=5,
        entropy_coef=0.0,
        vf_loss_type="mse",
        device=device
    )

    if args.load:
        agent.load(args.load)
    if args.load_pretrained:
        pretrained_path = download_model(
            "https://github.com/rlworkgroup/chainerrl/releases/download/v0.0.0/pretrained.zip",
            args.pretrained_best
        )
        agent.load(pretrained_path)

    if args.demo:
        mean, med, std = eval_performance(agent, test_env, args.eval_n_runs)
        logging.info(f"Demo: mean={mean:.2f}, median={med:.2f}, std={std:.2f}")
        return

    train_max_episode_len = train_env._max_episode_steps
    experiments.train_agent_with_evaluation(
        agent=agent,
        env=train_env,
        test_env=test_env,
        test_n_episodes=args.eval_n_runs,
        test_interval=args.eval_interval,
        output_dir=output_dir,
        max_steps=args.steps,
        eval_n_runs=args.eval_n_runs,
        train_max_episode_len=train_max_episode_len
    )

if __name__ == "__main__":
    main()
