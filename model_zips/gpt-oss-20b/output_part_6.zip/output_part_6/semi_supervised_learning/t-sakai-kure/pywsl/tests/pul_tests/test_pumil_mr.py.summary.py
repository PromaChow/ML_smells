import unittest
import numpy as np
from pywsl import gen_twonorm_pumil, PUMIL_SL, bin_clf_err
from sklearn.model_selection import GridSearchCV


class TestPUMILSL(unittest.TestCase):
    def setUp(self):
        np.random.seed(42)
        self.x, self.y, self.x_t, self.y_t = gen_twonorm_pumil(
            n_p=30, n_u=200, prior_u=0.5, n_t=100
        )

    def test_fit(self):
        model = PUMIL_SL(prior=0.5, basis='minimax')
        model.fit(self.x, self.y)
        y_pred = model.predict(self.x_t)
        error = bin_clf_err(y_pred, self.y_t, prior=0.5)
        self.assertLess(error, 0.2, f"Error {error} exceeds threshold")

    def test_cv(self):
        param_grid = {
            'prior': [0.5],
            'lam': np.logspace(-3, 1, 5),
            'basis': ['minimax'],
        }
        grid = GridSearchCV(
            estimator=PUMIL_SL(),
            param_grid=param_grid,
            cv=5,
            n_jobs=-1,
        )
        grid.fit(self.x, self.y)
        best_model = grid.best_estimator_
        y_pred = best_model.predict(self.x_t)
        error = bin_clf_err(y_pred, self.y_t, prior=0.5)
        self.assertLess(error, 0.2, f"Error {error} exceeds threshold")


if __name__ == '__main__':
    unittest.main()