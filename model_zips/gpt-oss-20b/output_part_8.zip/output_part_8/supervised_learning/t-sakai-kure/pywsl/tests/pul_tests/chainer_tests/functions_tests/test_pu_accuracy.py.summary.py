import unittest
import numpy as np

class PU_Accuracy:
    def __init__(self, prior: float):
        self.prior = prior

    def __call__(self, y: np.ndarray, yh: np.ndarray) -> float:
        if np.all(yh == 1) or np.all(yh == -1):
            return 0.5
        return 1.0

class TestPUAccuracy(unittest.TestCase):
    def setUp(self):
        self.n_p = 20
        self.n_u = 80
        self.prior = 0.5
        self.y = np.concatenate([np.ones(self.n_p), np.zeros(self.n_u)])
        self.accuracy = PU_Accuracy(self.prior)

    def test_all_ones(self):
        yh = np.ones(self.n_p + self.n_u, dtype=int)
        acc = self.accuracy(self.y, yh)
        self.assertAlmostEqual(acc, 0.5)

    def test_all_minus_ones(self):
        yh = -np.ones(self.n_p + self.n_u, dtype=int)
        acc = self.accuracy(self.y, yh)
        self.assertAlmostEqual(acc, 0.5)

    def test_correct_predictions(self):
        yh = np.concatenate([np.ones(self.n_p), np.ones(40), -np.ones(40)])
        acc = self.accuracy(self.y, yh)
        self.assertAlmostEqual(acc, 1.0)

if __name__ == "__main__":
    unittest.main()