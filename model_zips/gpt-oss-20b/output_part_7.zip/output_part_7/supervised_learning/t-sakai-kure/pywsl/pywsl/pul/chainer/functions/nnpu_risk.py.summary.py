import chainer
import chainer.functions as F
import numpy as np


class PU_Risk(chainer.Function):
    def __init__(self, prior, gamma=1.0, beta=0.0, loss_func=None, nnPU=False):
        if not (0.0 <= prior <= 1.0):
            raise ValueError("prior must be in [0, 1]")
        self.prior = prior
        self.gamma = gamma
        self.beta = beta
        self.nnPU = nnPU
        if loss_func is None:
            # non‑increasing function: sigmoid(-x)
            self.loss_func = lambda x: F.sigmoid(-x)
        else:
            self.loss_func = loss_func
        self.loss = None

    def check_type_forward(self, in_types):
        if len(in_types) != 2:
            raise TypeError("PU_Risk expects two inputs (x, t)")
        x_type, t_type = in_types
        if x_type.dtype != np.float32:
            raise TypeError("x must be float32")
        if t_type.dtype != np.int32:
            raise TypeError("t must be int32")
        if x_type.shape[0] != t_type.shape[0]:
            raise ValueError("x and t must have the same first dimension")
        if t_type.ndim != 1:
            raise ValueError("t must be a 1‑D array")

    def forward(self, inputs):
        x, t = inputs
        # Masks for positive and unlabeled samples
        positive_mask = (t == 1)
        unlabeled_mask = (t == 0)

        # Counts (ensure at least 1 to avoid division by zero)
        n_pos = positive_mask.sum().astype(np.float32)
        n_unl = unlabeled_mask.sum().astype(np.float32)
        n_pos = F.max_scalar(n_pos, 1.0)
        n_unl = F.max_scalar(n_unl, 1.0)

        # Losses for positive and unlabeled samples
        loss_pos = self.loss_func(x * positive_mask)
        loss_unl = self.loss_func((-x) * unlabeled_mask)

        # Risks
        positive_risk = self.prior * F.sum(loss_pos) / n_pos
        negative_risk = (1.0 - self.prior) * F.sum(loss_unl) / n_unl

        # Objective
        objective = positive_risk + negative_risk

        # nnPU adjustment
        if self.nnPU:
            cond = negative_risk < -self.beta
            objective = F.where(cond, positive_risk - self.beta, objective)
            x_out = F.where(cond, -self.gamma * negative_risk, objective)
        else:
            x_out = objective

        self.loss = x_out
        return (x_out,)

    def backward(self, inputs, grad_outputs):
        x, t = inputs
        gy, = grad_outputs
        positive_mask = (t == 1)
        unlabeled_mask = (t == 0)

        n_pos = positive_mask.sum().astype(np.float32)
        n_unl = unlabeled_mask.sum().astype(np.float32)
        n_pos = F.max_scalar(n_pos, 1.0)
        n_unl = F.max_scalar(n_unl, 1.0)

        # Derivatives of loss functions
        sig_pos = F.sigmoid(-x)                      # sigmoid(-x)
        grad_sig_pos = -sig_pos * (1.0 - sig_pos)    # derivative w.r.t. x
        sig_unl = F.sigmoid(x)                       # sigmoid(x)
        grad_sig_unl = sig_unl * (1.0 - sig_unl)     # derivative w.r.t. x

        # Gradients for positive and unlabeled risks
        grad_pos = self.prior * grad_sig_pos * positive_mask / n_pos
        grad_unl = (1.0 - self.prior) * grad_sig_unl * unlabeled_mask / n_unl

        # nnPU adjustment
        if self.nnPU:
            cond = (1.0 - self.prior) * F.sum(self.loss_func(-x * unlabeled_mask)) / n_unl < -self.beta
            if cond:
                grad = gy * grad_pos
                grad += gy * (-self.gamma) * grad_unl
            else:
                grad = gy * (grad_pos + grad_unl)
        else:
            grad = gy * (grad_pos + grad_unl)

        return (grad, None)


def pu_risk(x, t, prior, gamma=1.0, beta=0.0, loss_func=None, nnPU=False):
    return PU_Risk(prior, gamma, beta, loss_func, nnPU)(x, t)