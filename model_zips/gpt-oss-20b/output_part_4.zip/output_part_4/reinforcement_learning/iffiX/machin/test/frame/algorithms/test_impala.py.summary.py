import time
import torch
import torch.nn as nn
import torch.optim as optim
import torch.distributed as dist
import torch.distributed.rpc as rpc
import gym
from machin.frameworks.distributed import run_multi, setup_world, linux_only_forall


class Actor(nn.Module):
    def __init__(self, obs_dim: int, act_dim: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 64),
            nn.ReLU(),
            nn.Linear(64, act_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)

    def act(self, state: torch.Tensor) -> torch.Tensor:
        logits = self.forward(state)
        probs = torch.softmax(logits, dim=-1)
        return probs


class Critic(nn.Module):
    def __init__(self, obs_dim: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 64),
            nn.ReLU(),
            nn.Linear(64, 1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x).squeeze(-1)


class IMPALA:
    def __init__(
        self,
        actor: Actor,
        critic: Critic,
        optimizer: optim.Optimizer,
        device: torch.device,
        lr_scheduler: torch.optim.lr_scheduler._LRScheduler | None = None,
    ):
        self.actor = actor.to(device)
        self.critic = critic.to(device)
        self.optimizer = optimizer
        self.device = device
        self.buffer = []
        self.lr_scheduler = lr_scheduler

    def act(self, state: torch.Tensor) -> torch.Tensor:
        state = state.to(self.device)
        with torch.no_grad():
            probs = torch.softmax(self.actor(state), dim=-1)
        return probs

    def _eval_act(self, state: torch.Tensor, action: int) -> torch.Tensor:
        state = state.to(self.device)
        probs = torch.softmax(self.actor(state), dim=-1)
        return probs[action]

    def _criticize(self, state: torch.Tensor) -> torch.Tensor:
        state = state.to(self.device)
        with torch.no_grad():
            return self.critic(state)

    def store_episode(self, episode):
        self.buffer.append(episode)

    def update(self):
        if not self.buffer:
            return
        gamma = 0.99
        loss_actor = 0.0
        loss_critic = 0.0
        for ep in self.buffer:
            states, actions, rewards = zip(*ep)
            states = torch.stack(states).to(self.device)
            actions = torch.tensor(actions, dtype=torch.long, device=self.device)
            rewards = torch.tensor(rewards, dtype=torch.float32, device=self.device)
            returns = torch.zeros_like(rewards)
            R = 0.0
            for t in reversed(range(len(rewards))):
                R = rewards[t] + gamma * R
                returns[t] = R
            values = self.critic(states)
            advantage = returns - values
            probs = torch.softmax(self.actor(states), dim=-1)
            log_probs = torch.log(probs.gather(1, actions.unsqueeze(1)).squeeze())
            loss_actor += -(log_probs * advantage.detach()).mean()
            loss_critic += nn.functional.mse_loss(values.squeeze(), returns)
        self.optimizer.zero_grad()
        (loss_actor + loss_critic).backward()
        self.optimizer.step()
        self.buffer.clear()

    def update_lr_scheduler(self):
        if self.lr_scheduler:
            self.lr_scheduler.step()

    def get_actor_params(self):
        return {k: v.cpu() for k, v in self.actor.state_dict().items()}


def create_impala_from_config(config: dict) -> IMPALA:
    obs_dim = config["obs_dim"]
    act_dim = config["act_dim"]
    lr = config.get("lr", 0.001)
    device = torch.device("cpu")
    actor = Actor(obs_dim, act_dim).to(device)
    critic = Critic(obs_dim).to(device)
    optimizer = optim.Adam(list(actor.parameters()) + list(critic.parameters()), lr=lr)
    return IMPALA(actor, critic, optimizer, device)


@run_multi(n=1)
@linux_only_forall
def test_act(rank_id: int):
    if rank_id != 0:
        return
    device = torch.device("cpu")
    actor = Actor(4, 2).to(device)
    critic = Critic(4).to(device)
    optimizer = optim.Adam(actor.parameters(), lr=0.001)
    impala = IMPALA(actor, critic, optimizer, device)
    state = torch.zeros(4)
    probs = impala.act(state)
    assert probs.shape == torch.Size([2])


@run_multi(n=1)
@linux_only_forall
def test_eval_action(rank_id: int):
    if rank_id != 0:
        return
    device = torch.device("cpu")
    actor = Actor(4, 2).to(device)
    critic = Critic(4).to(device)
    optimizer = optim.Adam(actor.parameters(), lr=0.001)
    impala = IMPALA(actor, critic, optimizer, device)
    state = torch.zeros(4)
    prob = impala._eval_act(state, 0)
    assert prob.item() >= 0.0


@run_multi(n=1)
@linux_only_forall
def test_criticize(rank_id: int):
    if rank_id != 0:
        return
    device = torch.device("cpu")
    actor = Actor(4, 2).to(device)
    critic = Critic(4).to(device)
    optimizer = optim.Adam(critic.parameters(), lr=0.001)
    impala = IMPALA(actor, critic, optimizer, device)
    state = torch.zeros(4)
    value = impala._criticize(state)
    assert value.shape == torch.Size([])


@run_multi(n=1)
@linux_only_forall
def test_store_episode(rank_id: int):
    if rank_id != 0:
        return
    device = torch.device("cpu")
    actor = Actor(4, 2).to(device)
    critic = Critic(4).to(device)
    optimizer = optim.Adam(actor.parameters(), lr=0.001)
    impala = IMPALA(actor, critic, optimizer, device)
    episode = [(torch.zeros(4), 0, 1.0) for _ in range(3)]
    impala.store_episode(episode)
    assert len(impala.buffer) == 1


@run_multi(n=3)
@linux_only_forall
def test_update(rank_id: int):
    world_size = 3
    dist.init_process_group(
        backend="gloo", init_method="tcp://127.0.0.1:29501", rank=rank_id, world_size=world_size
    )
    rpc.init_rpc(
        "trainer" if rank_id == 2 else f"worker{rank_id}",
        rank=rank_id,
        world_size=world_size,
        backend="gloo",
    )
    device = torch.device("cpu")
    if rank_id == 2:
        actor = Actor(4, 2).to(device)
        critic = Critic(4).to(device)
        optimizer = optim.Adam(
            list(actor.parameters()) + list(critic.parameters()), lr=0.001
        )
        impala = IMPALA(actor, critic, optimizer, device)
        rpc.register_function("trainer", impala.store_episode)
        rpc.register_function("trainer", impala.update)
        dist.barrier()
        time.sleep(1)
        impala.update()
        dist.barrier()
    else:
        episode = [
            (torch.zeros(4), 0, 1.0) for _ in range(3 if rank_id == 0 else 2)
        ]
        rpc.remote("trainer", "store_episode", episode)
        dist.barrier()
        if rank_id == 0:
            rpc.remote("trainer", "update")
        dist.barrier()
    rpc.shutdown()
    dist.destroy_process_group()


@run_multi(n=1)
@linux_only_forall
def test_lr_scheduler(rank_id: int):
    if rank_id != 0:
        return
    device = torch.device("cpu")
    actor = Actor(4, 2).to(device)
    critic = Critic(4).to(device)
    optimizer = optim.Adam(actor.parameters(), lr=0.001)
    scheduler = optim.lr_scheduler.LambdaLR(
        optimizer, lr_lambda=lambda epoch: 1.0 if epoch < 5 else 0.5
    )
    impala = IMPALA(actor, critic, optimizer, device, lr_scheduler=scheduler)
    impala.update_lr_scheduler()
    assert optimizer.param_groups[0]["lr"] == 0.001


@run_multi(n=1)
@linux_only_forall
def test_config_init(rank_id: int):
    if rank_id != 0:
        return
    config = {"obs_dim": 4, "act_dim": 2, "lr": 0.001}
    impala = create_impala_from_config(config)
    assert isinstance(impala.actor, Actor)
    assert isinstance(impala.critic, Critic)


@run_multi(n=3)
@linux_only_forall
def test_full_training(rank_id: int):
    world_size = 3
    dist.init_process_group(
        backend="gloo", init_method="tcp://127.0.0.1:29502", rank=rank_id, world_size=world_size
    )
    rpc.init_rpc(
        "trainer" if rank_id == 2 else f"worker{rank_id}",
        rank=rank_id,
        world_size=world_size,
        backend="gloo",
    )
    device = torch.device("cpu")
    solved_flag = torch.tensor([0], dtype=torch.int32)
    solved_repeat = 5
    solved_reward = 150
    if rank_id == 2:
        actor = Actor(4, 2).to(device)
        critic = Critic(4).to(device)
        optimizer = optim.Adam(
            list(actor.parameters()) + list(critic.parameters()), lr=0.001
        )
        impala = IMPALA(actor, critic, optimizer, device)
        rpc.register_function("trainer", impala.store_episode)
        rpc.register_function("trainer", impala.update)
        rpc.register_function("trainer", impala.get_actor_params)
        solved_count = 0
        while True:
            dist.barrier()
            if solved_flag.item() == 1:
                break
            if impala.buffer:
                impala.update()
            # simple convergence check
            if solved_count >= solved_repeat:
                solved_flag.fill_(1)
            dist.broadcast(solved_flag, src=2)
            dist.barrier()
    else:
        env = gym.make("CartPole-v0")
        done = True
        episode = []
        while True:
            if solved_flag.item() == 1:
                break
            if done:
                if episode:
                    rpc.remote("trainer", "store_episode", episode)
                    episode = []
                obs = env.reset()
                done = False
            state = torch.tensor(obs, dtype=torch.float32)
            actor_params = rpc.remote("trainer", "get_actor_params").to_py()
            local_actor = Actor(4, 2)
            local_actor.load_state_dict(actor_params)
            probs = local_actor.act(state)
            action = torch.multinomial(probs, 1).item()
            obs, reward, done, _ = env.step(action)
    rpc.shutdown()
    dist.destroy_process_group()
