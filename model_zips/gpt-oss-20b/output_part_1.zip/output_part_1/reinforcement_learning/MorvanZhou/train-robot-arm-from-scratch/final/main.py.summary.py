import time

from arm_env import ArmEnv
from ddpg import DDPG

MAX_EPISODES = 900
MAX_EP_STEPS = 200

env = ArmEnv()
s_dim = env.state_dim
a_dim = env.action_dim
a_bound = env.action_bound

agent = DDPG(state_dim=s_dim, action_dim=a_dim, action_bound=a_bound)

for episode in range(1, MAX_EPISODES + 1):
    s = env.reset()
    ep_r = 0
    for step in range(1, MAX_EP_STEPS + 1):
        a = agent.select_action(s)
        s_, r, done, _ = env.step(a)
        agent.store_transition(s, a, r, s_)
        if agent.memory.is_full():
            agent.learn()
        s = s_
        ep_r += r
        if done:
            break
    print(f"Episode {episode}/{MAX_EPISODES} | Status: {'Done' if done else 'Continue'} | "
          f"Reward: {ep_r:.2f} | Step: {step}")
agent.save("ddpg_arm.pkl")

agent.load("ddpg_arm.pkl")
env.render()
s = env.reset()
while True:
    a = agent.select_action(s)
    s, r, done, _ = env.step(a)
    env.render()
    if done:
        s = env.reset()
    time.sleep(0.02)