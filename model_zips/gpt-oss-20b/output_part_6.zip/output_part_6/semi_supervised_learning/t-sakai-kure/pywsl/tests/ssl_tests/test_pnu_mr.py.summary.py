import unittest
import numpy as np
from pywsl.ssl import pnu_mr

# ----------------------------------------------------------------------
# Helper functions
# ----------------------------------------------------------------------


def calc_etab(prior: float) -> float:
    """Compute eta based on prior probability."""
    return 0.5 - prior


def calc_err(model, x_tp: np.ndarray, x_tn: np.ndarray, prior: float) -> float:
    """
    Compute weighted error of the model on test data.
    :param model: trained model with predict method.
    :param x_tp: test samples of positive class.
    :param x_tn: test samples of negative class.
    :param prior: prior probability of positive class.
    :return: weighted error.
    """
    y_tp_pred = model.predict(x_tp)
    y_tn_pred = model.predict(x_tn)

    err_tp = np.mean(y_tp_pred != 1)
    err_tn = np.mean(y_tn_pred != -1)

    return prior * err_tp + (1 - prior) * err_tn


def gendata(
    n_l: int,
    prior_l: float,
    n_u: int,
    prior_u: float,
    n_t: int,
) -> tuple:
    """
    Generate synthetic labeled, unlabeled and test data.
    Returns:
        x: feature matrix for training (labeled + unlabeled).
        y: label vector for training (1, -1, 0).
        x_tp: positive class test samples.
        x_tn: negative class test samples.
    """
    # Labeled data
    n_l_pos = int(round(n_l * prior_l))
    n_l_neg = n_l - n_l_pos
    x_l_pos = np.random.randn(n_l_pos, 2) + np.array([1, 1])
    x_l_neg = np.random.randn(n_l_neg, 2) + np.array([-1, -1])
    x_l = np.vstack([x_l_pos, x_l_neg])
    y_l = np.hstack([np.ones(n_l_pos), -np.ones(n_l_neg)])

    # Unlabeled data
    n_u_pos = int(round(n_u * prior_u))
    n_u_neg = n_u - n_u_pos
    x_u_pos = np.random.randn(n_u_pos, 2) + np.array([1, 1])
    x_u_neg = np.random.randn(n_u_neg, 2) + np.array([-1, -1])
    x_u = np.vstack([x_u_pos, x_u_neg])
    y_u = np.zeros(n_u, dtype=int)

    # Training set
    x = np.vstack([x_l, x_u])
    y = np.hstack([y_l, y_u])

    # Test data
    x_tp = np.random.randn(n_t, 2) + np.array([1, 1])
    x_tn = np.random.randn(n_t, 2) + np.array([-1, -1])

    return x, y, x_tp, x_tn


# ----------------------------------------------------------------------
# Test suite
# ----------------------------------------------------------------------


class TestPNU_SL(unittest.TestCase):
    def test_linear_model(self):
        x, y, x_tp, x_tn = gendata(30, 0.3, 200, 0.5, 100)
        etas = np.arange(-0.9, 1.1, 0.1)
        for eta in etas:
            model = pnu_mr.PNU_SL_FastCV(
                x, y, eta=eta, basis="lm", lambda_list=None, nargout=1
            )
            err = calc_err(model, x_tp, x_tn, 0.3)
            self.assertLessEqual(err, 1.0)

    def test_linear_model_one_eta(self):
        x, y, x_tp, x_tn = gendata(30, 0.5, 200, 0.3, 100)
        n_pos = int(round(30 * 0.5))
        eta = calc_etab(0.5)
        model = pnu_mr.PNU_SL_FastCV(
            x, y, eta=eta, basis="lm", lambda_list=None, nargout=1
        )
        err = calc_err(model, x_tp, x_tn, 0.5)
        self.assertLessEqual(err, 1.0)

    def test_model_without_cv(self):
        x, y, x_tp, x_tn = gendata(30, 0.3, 200, 0.5, 100)
        n_pos = int(round(30 * 0.3))
        eta = calc_etab(0.3)
        model = pnu_mr.PNU_SL_FastCV(
            x, y,
            eta=eta,
            basis="lm",
            lambda_list=[0.1],
            nargout=1,
        )
        err = calc_err(model, x_tp, x_tn, 0.3)
        self.assertLessEqual(err, 1.0)

    def test_model_nargout2(self):
        x, y, x_tp, x_tn = gendata(30, 0.5, 200, 0.3, 100)
        n_pos = int(round(30 * 0.5))
        eta = calc_etab(0.5)
        result = pnu_mr.PNU_SL_FastCV(
            x, y,
            eta=eta,
            basis="lm",
            lambda_list=[0.1],
            nargout=2,
        )
        self.assertIsInstance(result, tuple)
        self.assertEqual(len(result), 2)
        model = result[0]
        err = calc_err(model, x_tp, x_tn, 0.5)
        self.assertLessEqual(err, 1.0)

    def test_model_nargout1(self):
        x, y, x_tp, x_tn = gendata(30, 0.5, 200, 0.3, 100)
        eta = calc_etab(0.5)
        model = pnu_mr.PNU_SL_FastCV(
            x, y,
            eta=eta,
            basis="lm",
            lambda_list=[0.1],
            nargout=1,
        )
        err = calc_err(model, x_tp, x_tn, 0.5)
        self.assertLessEqual(err, 1.0)

    def test_gauss_model(self):
        x, y, x_tp, x_tn = gendata(30, 0.3, 200, 0.5, 100)
        etas = np.arange(-0.9, 1.1, 0.1)
        for eta in etas:
            model = pnu_mr.PNU_SL_FastCV(
                x, y, eta=eta, basis="gauss", lambda_list=None, nargout=1
            )
            err = calc_err(model, x_tp, x_tn, 0.3)
            self.assertLessEqual(err, 1.0)

    def test_label_specification_error(self):
        x, y, x_tp, x_tn = gendata(30, 0.3, 200, 0.5, 100)
        y[0] = 2  # invalid label
        with self.assertRaises(ValueError):
            pnu_mr.PNU_SL_FastCV(x, y, eta=0.0, basis="lm", lambda_list=None, nargout=1)

    def test_model_specification_error(self):
        x, y, x_tp, x_tn = gendata(30, 0.3, 200, 0.5, 100)
        with self.assertRaises(ValueError):
            pnu_mr.PNU_SL_FastCV(x, y, eta=0.0, basis="DNN", lambda_list=None, nargout=1)

    def test_calc_etab(self):
        self.assertGreater(calc_etab(0.3), 0)
        self.assertLess(calc_etab(0.7), 0)
        self.assertEqual(calc_etab(0.5), 0)


if __name__ == "__main__":
    unittest.main()
