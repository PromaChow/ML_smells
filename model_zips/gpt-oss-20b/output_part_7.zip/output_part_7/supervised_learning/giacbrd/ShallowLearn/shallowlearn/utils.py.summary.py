import logging
from typing import Any, Iterable, List, Tuple, Union


def argument_alternatives(
    original_value: Any,
    kwargs: dict,
    alternative_names: List[str],
    logger: logging.Logger,
) -> Any:
    """
    Override an original parameter value with alternatives provided in kwargs.
    The last name in alternative_names has priority.
    """
    final_value = original_value
    for name in reversed(alternative_names):
        if name in kwargs and kwargs[name] != final_value:
            logger.warning(
                "Parameter %s overridden: original %r -> new %r",
                name,
                final_value,
                kwargs[name],
            )
            final_value = kwargs[name]
    return final_value


class HashIter:
    """
    Iterator that yields hashed documents.
    """

    def __init__(
        self,
        documents: Iterable[Union[str, Tuple[str, Any]]],
        bucket_size: int,
        with_labels: bool = False,
    ):
        if bucket_size <= 0:
            raise ValueError("bucket_size must be positive")
        self._docs = list(documents)
        self._bucket_size = bucket_size
        self._with_labels = with_labels
        self._index = 0

    def __iter__(self):
        return self

    def __next__(self):
        if self._index >= len(self._docs):
            raise StopIteration
        item = self._docs[self._index]
        self._index += 1

        if self._with_labels:
            if not isinstance(item, tuple) or len(item) != 2:
                raise ValueError(
                    "When with_labels=True, documents must be tuples of (doc, label)"
                )
            doc_text, label = item
        else:
            if not isinstance(item, str):
                raise ValueError("When with_labels=False, documents must be strings")
            doc_text = item
            label = None

        hashed = self.hash_doc(doc_text)
        return (hashed, label) if self._with_labels else hashed

    def hash_doc(self, document: str) -> List[int]:
        """
        Hash each word in the document and apply modulo bucket size.
        """
        hashed_words = []
        for word in document.split():
            hashed_word = self.hash(word) % self._bucket_size
            hashed_words.append(hashed_word)
        return hashed_words

    @staticmethod
    def hash(word: str) -> int:
        """
        Compute a 32-bit unsigned FNV-1a hash for a word.
        """
        h: int = 2166136261
        for c in word.encode("utf-8", errors="ignore"):
            h ^= c
            h = (h * 16777619) & 0xFFFFFFFF
        return h
