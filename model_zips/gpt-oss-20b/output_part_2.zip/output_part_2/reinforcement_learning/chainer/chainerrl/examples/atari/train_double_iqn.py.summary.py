import argparse
import json
import logging
import os
import random
import sys
from pathlib import Path

import gym
import numpy as np
import torch
from torch import nn
from torch import optim

# Garage imports
from garage import misc
from garage.envs import atari_wrappers, Monitor
from garage.buffers import ReplayBuffer, PrioritizedReplayBuffer
from garage.torch.algos import iqn
from garage.torch import nn as torch_nn

# --------------------------------------------
# Argument parsing
# --------------------------------------------
parser = argparse.ArgumentParser(description="IQN / DoubleIQN training on BreakoutNoFrameskip-v4")
parser.add_argument("--env", default="BreakoutNoFrameskip-v4", help="Gym environment name")
parser.add_argument("--output-dir", default="output", help="Directory to save models and logs")
parser.add_argument("--seed", type=int, default=0, help="Random seed")
parser.add_argument("--gpu", action="store_true", help="Use GPU if available")
parser.add_argument("--final-epsilon", type=float, default=0.01, help="Final epsilon value")
parser.add_argument("--exploration-frames", type=int, default=1000000, help="Frames over which to decay epsilon")
parser.add_argument("--steps", type=int, default=50000000, help="Total training steps")
parser.add_argument("--replay-capacity", type=int, default=10**6, help="Replay buffer capacity")
parser.add_argument("--agent-type", choices=["IQN", "DoubleIQN"], default="IQN", help="Agent type")
parser.add_argument("--prioritized", action="store_true", help="Use prioritized replay")
parser.add_argument("--monitor", action="store_true", help="Save video recordings")
parser.add_argument("--render", action="store_true", help="Render the environment")
parser.add_argument("--logging-level", default="INFO", help="Logging level")
parser.add_argument("--load", help="Path to pretrained model weights")
parser.add_argument("--demo", action="store_true", help="Run evaluation only")
parser.add_argument("--eval-interval", type=int, default=10000, help="Evaluation interval (steps)")
parser.add_argument("--eval-n-steps", type=int, default=1000000, help="Steps for demo evaluation")
parser.add_argument("--n-best-episodes", type=int, default=200, help="Number of episodes for best agent evaluation")
parser.add_argument("--max-frames", type=int, default=300000, help="Maximum frames per episode")
args = parser.parse_args()

# --------------------------------------------
# Logging and seed setup
# --------------------------------------------
log_level = getattr(logging, args.logging_level.upper(), logging.INFO)
logging.basicConfig(level=log_level, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger(__name__)

# Set global seeds
misc.set_random_seed(args.seed)
train_seed = args.seed
test_seed = args.seed + 1

# --------------------------------------------
# Environment creation
# --------------------------------------------
def make_env(seed, is_test=False):
    env = gym.make(args.env)
    env = atari_wrappers.wrap_deepmind(env, episode_life=not is_test, clip_rewards=not is_test)
    if args.monitor:
        env = Monitor(env, f"{args.output_dir}/videos", video_callable=lambda _: True, force=True)
    if args.render:
        env = gym.wrappers.Renderer(env)
    env.seed(seed)
    return env

train_env = make_env(train_seed, is_test=False)
eval_env = make_env(test_seed, is_test=True)

# --------------------------------------------
# Q-Function definition
# --------------------------------------------
class ImplicitQuantileQFunction(nn.Module):
    def __init__(self, n_actions, n_quantiles=64):
        super().__init__()
        self.n_actions = n_actions
        self.n_quantiles = n_quantiles

        # Feature extractor ψ
        self.features = nn.Sequential(
            nn.Conv2d(4, 32, kernel_size=8, stride=4),
            nn.ReLU(),
            nn.Conv2d(32, 64, kernel_size=4, stride=2),
            nn.ReLU(),
            nn.Conv2d(64, 64, kernel_size=3, stride=1),
            nn.ReLU(),
            nn.Flatten(),
        )

        # Quantile estimator φ (cosine basis)
        self.quantile_fc = nn.Sequential(
            nn.Linear(64, 64),
            nn.ReLU(),
        )

        # Action head f
        self.action_head = nn.Sequential(
            nn.Linear(3136, 512),
            nn.ReLU(),
            nn.Linear(512, n_actions),
        )

    def forward(self, obs, taus):
        """
        obs: (batch, 4, 84, 84)
        taus: (batch, n_quantiles)
        """
        batch_size = obs.shape[0]
        features = self.features(obs)  # (batch, 3136)

        # Create cosine basis
        tau = taus.unsqueeze(-1)  # (batch, n_quantiles, 1)
        k = torch.arange(1, self.n_quantiles + 1, device=taus.device).view(1, 1, -1)
        basis = torch.cos(k * np.pi * tau)  # (batch, n_quantiles, n_quantiles)

        # Embed quantiles
        phi = self.quantile_fc(basis)  # (batch, n_quantiles, 64)

        # Broadcast features
        features = features.unsqueeze(1)  # (batch, 1, 3136)
        phi = phi.permute(0, 1, 2)  # (batch, n_quantiles, 64)

        # Combine
        x = features + phi  # (batch, n_quantiles, 3136)

        # Compute Q-values
        q = self.action_head(x)  # (batch, n_quantiles, n_actions)
        return q

# Instantiate Q-function
n_actions = train_env.action_space.n
q_func = ImplicitQuantileQFunction(n_actions)

# Visualize computational graph (optional)
try:
    from torchviz import make_dot
    dummy_obs = torch.zeros((1, 4, 84, 84))
    dummy_taus = torch.rand((1, 64))
    q_func(dummy_obs, dummy_taus)
    graph = make_dot(q_func(dummy_obs, dummy_taus).mean())
    graph.format = "pdf"
    graph.directory = args.output_dir
    graph.render("q_func_graph")
except Exception as e:
    logger.warning(f"Graph visualization skipped: {e}")

# --------------------------------------------
# Optimizer and Replay Buffer
# --------------------------------------------
batch_size = 32
optimizer = optim.Adam(
    q_func.parameters(),
    lr=5e-5,
    eps=1e-2 / batch_size
)

if args.prioritized:
    replay_buffer = PrioritizedReplayBuffer(
        capacity=args.replay_capacity,
        alpha=0.5,
        beta0=0.4,
        beta_steps=args.steps // args.eval_interval
    )
else:
    replay_buffer = ReplayBuffer(capacity=args.replay_capacity)

# --------------------------------------------
# Explorer configuration
# --------------------------------------------
class LinearDecayExplorer:
    def __init__(self, start_epsilon, final_epsilon, decay_frames):
        self.start_epsilon = start_epsilon
        self.final_epsilon = final_epsilon
        self.decay_frames = decay_frames
        self.current_frame = 0

    def get_epsilon(self):
        eps = self.final_epsilon + (self.start_epsilon - self.final_epsilon) * \
              max(0, (self.decay_frames - self.current_frame) / self.decay_frames)
        return eps

    def step(self):
        self.current_frame += 1

explorer = LinearDecayExplorer(
    start_epsilon=1.0,
    final_epsilon=args.final_epsilon,
    decay_frames=args.exploration_frames
)

# --------------------------------------------
# Agent instantiation
# --------------------------------------------
device = torch.device("cuda" if args.gpu and torch.cuda.is_available() else "cpu")
q_func.to(device)

if args.agent_type == "DoubleIQN":
    AgentClass = iqn.DoubleIQN
else:
    AgentClass = iqn.IQN

agent = AgentClass(
    q_func=q_func,
    optim=optimizer,
    replay_buffer=replay_buffer,
    explorer=explorer,
    device=device,
    gamma=0.99,
    replay_start_size=50000,
    target_update_interval=10000,
    update_interval=4,
    batch_accumulator="mean",
    quantile_thresholds=dict(N=64, Np=64, K=32)
)

# --------------------------------------------
# Model loading
# --------------------------------------------
if args.load:
    agent.load_state_dict(torch.load(args.load, map_location=device))

# --------------------------------------------
# Helper functions for evaluation
# --------------------------------------------
def evaluate_agent(env, agent, n_steps):
    returns = []
    obs = env.reset()
    for _ in range(n_steps):
        obs_tensor = torch.tensor(obs, dtype=torch.float32).unsqueeze(0).to(device) / 255.0
        with torch.no_grad():
            taus = torch.rand((1, agent.q_func.n_quantiles), device=device)
            q_values = agent.q_func(obs_tensor, taus).mean(1)  # (1, n_actions)
            action = q_values.argmax(-1).item()
        obs, reward, done, _ = env.step(action)
        returns.append(reward)
        if done:
            obs = env.reset()
    total_return = sum(returns)
    return total_return

# --------------------------------------------
# Training or evaluation
# --------------------------------------------
if args.demo:
    logger.info("Running demo evaluation")
    avg_return = evaluate_agent(eval_env, agent, args.eval_n_steps)
    logger.info(f"Demo return: {avg_return}")
else:
    # Main training loop
    total_steps = 0
    episode_return = 0
    obs = train_env.reset()
    while total_steps < args.steps:
        obs_tensor = torch.tensor(obs, dtype=torch.float32).unsqueeze(0).to(device) / 255.0
        with torch.no_grad():
            taus = torch.rand((1, agent.q_func.n_quantiles), device=device)
            q_values = agent.q_func(obs_tensor, taus).mean(1)
            action = q_values.argmax(-1).item()

        next_obs, reward, done, _ = train_env.step(action)
        replay_buffer.add(obs, action, reward, next_obs, done)
        obs = next_obs
        episode_return += reward
        total_steps += 1
        explorer.step()

        if replay_buffer.size >= agent.replay_start_size and total_steps % agent.update_interval == 0:
            agent.update(batch_size)

        if done:
            logger.info(f"Episode finished with return {episode_return}")
            obs = train_env.reset()
            episode_return = 0

        if total_steps % args.eval_interval == 0:
            logger.info("Evaluating agent")
            eval_return = evaluate_agent(eval_env, agent, args.eval_n_steps)
            logger.info(f"Evaluation return: {eval_return}")

    # Save best agent (placeholder: just save current agent)
    best_path = os.path.join(args.output_dir, "best_agent.pt")
    torch.save(agent.state_dict(), best_path)
    logger.info(f"Saved best agent to {best_path}")

    # Final evaluation of best agent
    agent.load_state_dict(torch.load(best_path, map_location=device))
    eval_returns = []
    for _ in range(args.n_best_episodes):
        obs = eval_env.reset()
        done = False
        ep_return = 0
        frame_count = 0
        while not done and frame_count < args.max_frames // 4:
            obs_tensor = torch.tensor(obs, dtype=torch.float32).unsqueeze(0).to(device) / 255.0
            with torch.no_grad():
                taus = torch.rand((1, agent.q_func.n_quantiles), device=device)
                q_values = agent.q_func(obs_tensor, taus).mean(1)
                action = q_values.argmax(-1).item()
            obs, reward, done, _ = eval_env.step(action)
            ep_return += reward
            frame_count += 1
        eval_returns.append(ep_return)

    stats = {
        "mean_return": float(np.mean(eval_returns)),
        "median_return": float(np.median(eval_returns)),
        "std_return": float(np.std(eval_returns)),
        "returns": eval_returns
    }
    json_path = os.path.join(args.output_dir, "bestscores.json")
    with open(json_path, "w") as f:
        json.dump(stats, f, indent=2)
    logger.info(f"Evaluation stats saved to {json_path}")
    logger.info(f"Best agent evaluation stats: {stats}")