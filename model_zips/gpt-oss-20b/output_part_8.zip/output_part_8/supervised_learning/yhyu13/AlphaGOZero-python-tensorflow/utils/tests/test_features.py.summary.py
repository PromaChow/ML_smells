import unittest
import numpy as np

# Minimal Go module stub for the test environment
class GoModule:
    BOARD_SIZE = 9

    @classmethod
    def set_board_size(cls, size):
        cls.BOARD_SIZE = size

    BLACK = 0
    WHITE = 1

    class PlayerMove:
        def __init__(self, color, x, y):
            self.color = color
            self.x = x
            self.y = y

    class Position:
        def __init__(self, board, captured_black, captured_white,
                     ko=None, recent_moves=None, to_play=BLACK, komi=6.5):
            self.board = board  # list of strings
            self.captured_black = captured_black
            self.captured_white = captured_white
            self.ko = ko
            self.recent_moves = recent_moves or ()
            self.to_play = to_play
            self.komi = komi

go = GoModule()
go.set_board_size(9)

# Feature extraction functions
def stone_color_feature(position):
    board = position.board
    size = go.BOARD_SIZE
    tensor = np.zeros((size, size, 3), dtype=int)
    for y in range(size):
        for x in range(size):
            cell = board[y][x]
            if cell == 'B':
                tensor[y, x, 0] = 1
            elif cell == 'W':
                tensor[y, x, 1] = 1
            else:
                tensor[y, x, 2] = 1
    return tensor

def _get_groups(board):
    size = len(board)
    visited = [[False]*size for _ in range(size)]
    groups = []

    def dfs(x, y, color, group):
        stack = [(x, y)]
        while stack:
            cx, cy = stack.pop()
            if visited[cy][cx]:
                continue
            visited[cy][cx] = True
            group.append((cx, cy))
            for nx, ny in [(cx+1,cy),(cx-1,cy),(cx,cy+1),(cx,cy-1)]:
                if 0 <= nx < size and 0 <= ny < size and not visited[ny][nx]:
                    if board[ny][nx] == color:
                        stack.append((nx, ny))

    for y in range(size):
        for x in range(size):
            if not visited[y][x]:
                cell = board[y][x]
                if cell in ('B', 'W'):
                    group = []
                    dfs(x, y, cell, group)
                    groups.append((cell, group))
    return groups

def _count_liberties(board, group):
    size = len(board)
    liberties = set()
    for x, y in group:
        for nx, ny in [(x+1,y),(x-1,y),(x,y+1),(x,y-1)]:
            if 0 <= nx < size and 0 <= ny < size:
                if board[ny][nx] == '.':
                    liberties.add((nx, ny))
    return len(liberties)

def liberty_feature(position):
    board = position.board
    size = go.BOARD_SIZE
    planes = 18
    tensor = np.zeros((size, size, planes), dtype=int)
    groups = _get_groups(board)
    for color, group in groups:
        lib = _count_liberties(board, group)
        if lib > planes:
            lib = planes
        plane_idx = lib - 1
        for x, y in group:
            tensor[y, x, plane_idx] = 1
    return tensor

def recent_move_feature(position):
    size = go.BOARD_SIZE
    planes = 3
    tensor = np.zeros((size, size, planes), dtype=int)
    for i, move in enumerate(position.recent_moves[:planes]):
        tensor[move.y, move.x, i] = 1
    return tensor

def would_capture_feature(position):
    board = [list(row) for row in position.board]
    size = go.BOARD_SIZE
    max_capture = 3
    planes = max_capture + 1  # plane 0 for no capture
    tensor = np.zeros((size, size, planes), dtype=int)

    opponent = go.BLACK if position.to_play == go.WHITE else go.WHITE
    opponent_char = 'B' if opponent == go.BLACK else 'W'
    my_char = 'B' if position.to_play == go.BLACK else 'W'

    for y in range(size):
        for x in range(size):
            if board[y][x] != '.':
                continue
            # Temporarily place the stone
            board[y][x] = my_char
            captured = 0
            # Check adjacent opponent groups for liberties
            for nx, ny in [(x+1,y),(x-1,y),(x,y+1),(x,y-1)]:
                if 0 <= nx < size and 0 <= ny < size and board[ny][nx] == opponent_char:
                    # Find group
                    group = []
                    stack = [(nx, ny)]
                    visited = [[False]*size for _ in range(size)]
                    while stack:
                        cx, cy = stack.pop()
                        if visited[cy][cx]:
                            continue
                        visited[cy][cx] = True
                        if board[cy][cx] == opponent_char:
                            group.append((cx, cy))
                            for gx, gy in [(cx+1,cy),(cx-1,cy),(cx,cy+1),(cx,cy-1)]:
                                if 0 <= gx < size and 0 <= gy < size:
                                    if not visited[gy][gx]:
                                        stack.append((gx, gy))
                    # Count liberties
                    lib = 0
                    for gx, gy in group:
                        for lx, ly in [(gx+1,gy),(gx-1,gy),(gx,gy+1),(gx,gy-1)]:
                            if 0 <= lx < size and 0 <= ly < size:
                                if board[ly][lx] == '.':
                                    lib += 1
                    if lib == 0:
                        captured += len(group)
            # Restore
            board[y][x] = '.'
            plane_idx = captured if captured <= max_capture else max_capture
            tensor[y, x, plane_idx] = 1
    return tensor

# Test board patterns
pattern1 = [
    'B.W......',
    '........B',
    '...W.....'
]
pattern2 = [
    '..B.W....',
    '....B....',
    '........B'
]
empty_row = '.' * go.BOARD_SIZE
TEST_BOARD = pattern1 + [empty_row]*6
TEST_BOARD2 = pattern2 + [empty_row]*6

# Recent moves
recent_moves = (
    go.PlayerMove(go.BLACK, 1, 0),
    go.PlayerMove(go.WHITE, 0, 8),
    go.PlayerMove(go.BLACK, 0, 1)
)

TEST_POSITION = go.Position(
    board=TEST_BOARD,
    captured_black=1,
    captured_white=2,
    ko=None,
    recent_moves=recent_moves,
    to_play=go.BLACK
)

TEST_POSITION2 = go.Position(
    board=TEST_BOARD2,
    captured_black=0,
    captured_white=0,
    ko=None,
    recent_moves=(),
    to_play=go.BLACK
)

class TestGoFeatures(unittest.TestCase):
    def test_stone_color_feature_shape(self):
        tensor = stone_color_feature(TEST_POSITION)
        self.assertEqual(tensor.shape, (9, 9, 3))

    def test_stone_color_feature_values(self):
        tensor = stone_color_feature(TEST_POSITION)
        self.assertEqual(tensor[1, 0, 0], 1)  # Black at (0,1) -> first plane
        self.assertEqual(tensor[8, 0, 1], 1)  # White at (0,8) -> second plane
        self.assertEqual(tensor[5, 0, 2], 1)  # Empty at (0,5) -> third plane

    def test_liberty_feature_shape(self):
        tensor = liberty_feature(TEST_POSITION)
        self.assertEqual(tensor.shape, (9, 9, 18))

    def test_liberty_feature_values(self):
        tensor = liberty_feature(TEST_POSITION)
        self.assertEqual(tensor[1, 0, 2], 1)  # group at (0,1) has 3 liberties -> third plane (index2)
        self.assertEqual(tensor[0, 1, 7], 1)  # group at (1,0) has 18 liberties -> eighth plane (index7)

    def test_recent_move_feature_shape(self):
        tensor = recent_move_feature(TEST_POSITION)
        self.assertEqual(tensor.shape, (9, 9, 3))

    def test_recent_move_feature_values(self):
        tensor = recent_move_feature(TEST_POSITION)
        self.assertEqual(tensor[0, 1, 0], 1)  # most recent move (1,0) in first plane
        self.assertEqual(tensor[8, 0, 1], 1)  # second most recent (0,8) in second plane
        self.assertEqual(tensor[1, 0, 2], 1)  # third most recent (0,1) in third plane
        self.assertTrue(np.all(tensor[:,:,3:] == 0) if tensor.shape[2] > 3 else True)

    def test_would_capture_feature_shape(self):
        tensor = would_capture_feature(TEST_POSITION2)
        self.assertEqual(tensor.shape, (9, 9, 4))  # planes 0-3

    def test_would_capture_feature_values(self):
        tensor = would_capture_feature(TEST_POSITION2)
        self.assertEqual(tensor[2, 1, 1], 1)  # move at (1,2) captures 2 stones -> second plane
        self.assertEqual(tensor[7, 0, 2], 1)  # move at (0,7) captures 3 stones -> third plane
        self.assertEqual(tensor[0, 0, 0], 1)  # move at (0,0) captures 0 stones -> first plane

if __name__ == "__main__":
    unittest.main()