import os
import sys
import glob
import pickle
import numpy as np
import tensorflow as tf
from bokeh.plotting import figure, curdoc

# ----------------------------------------------------------------------
# Environment Setup
# ----------------------------------------------------------------------
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if project_root not in sys.path:
    sys.path.append(project_root)

# ----------------------------------------------------------------------
# Loading Feature Directions
# ----------------------------------------------------------------------
feature_dir_path = "./asset_results/pg_gan_celeba_feature_direction_40"
feature_files = glob.glob(os.path.join(feature_dir_path, "feature_direction_*.pkl"))
if not feature_files:
    raise FileNotFoundError("No feature direction files found.")
latest_feature_file = max(feature_files, key=os.path.getmtime)

with open(latest_feature_file, "rb") as f:
    feature_data = pickle.load(f)
feature_direction = feature_data["feature_direction"]
feature_name = feature_data["feature_name"]

# ----------------------------------------------------------------------
# GAN Model Configuration
# ----------------------------------------------------------------------
gan_code_path = "./src/model/pggan"
gan_model_path = "./asset_model/karras2018iclr-celebahq-1024x1024.pkl"
yn_CPU_only = False  # Change to True to force CPU usage

# GPU configuration
if not yn_CPU_only:
    gpus = tf.config.list_physical_devices("GPU")
    if gpus:
        try:
            for gpu in gpus:
                tf.config.experimental.set_memory_growth(gpu, True)
        except RuntimeError:
            pass

# Load the pretrained model
with open(gan_model_path, "rb") as f:
    Gs = pickle.load(f)

# ----------------------------------------------------------------------
# Latent Space Initialization
# ----------------------------------------------------------------------
latent_dim = Gs.input_shapes[0][1]
batch_size = 1
latent_vector = np.random.randn(batch_size, latent_dim).astype(np.float32)
dummy_labels = np.zeros((batch_size, 0), dtype=np.float32)  # adjust shape if needed

# ----------------------------------------------------------------------
# Image Generation Function
# ----------------------------------------------------------------------
def gen_image(latent, label):
    output = Gs.run(latent, label, **{"dlatent_in": latent, "label": label})
    img = output[0]  # assume shape (1, 3, H, W)
    img = np.clip(img, 0, 255).astype(np.uint8)
    img = np.transpose(img, (1, 2, 0))  # NHWC
    return img

# ----------------------------------------------------------------------
# Initial Image Generation
# ----------------------------------------------------------------------
img_cur = gen_image(latent_vector, dummy_labels)

# ----------------------------------------------------------------------
# Helper: Convert to Bokeh-compatible RGBA image
# ----------------------------------------------------------------------
def get_img_for_bokeh(img):
    h, w, _ = img.shape
    rgba = np.zeros((h, w, 4), dtype=np.uint8)
    rgba[..., :3] = img
    rgba[..., 3] = 255
    return np.flipud(rgba)

# ----------------------------------------------------------------------
# Bokeh Plot Setup
# ----------------------------------------------------------------------
p = figure(width=128, height=128, x_range=(0, 128), y_range=(0, 128), title="PGGAN Image")
p.axis.visible = False
p.grid.visible = False

bokeh_img = get_img_for_bokeh(img_cur)
p.image_rgba(image=[bokeh_img], x=0, y=0, dw=128, dh=128)

# ----------------------------------------------------------------------
# Bokeh Document Integration
# ----------------------------------------------------------------------
curdoc().add_root(p)