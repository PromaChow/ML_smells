import os
import random
import pickle
import multiprocessing
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass, field
from typing import Dict, Tuple, List, Callable

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import torchvision.transforms as T
import torchvision.datasets as D
from torch.utils.data import DataLoader

# ----------------------------------
# Configuration
# ----------------------------------
@dataclass
class Config:
    log: Dict[str, int] = field(default_factory=lambda: {"freq": 100})
    nn: Dict[str, object] = field(default_factory=lambda: {"type": "VAE", "z_dim": 8})
    lr: float = 1e-3
    train: Dict[str, object] = field(default_factory=lambda: {"num_epoch": 100, "batch_size": 128})
    eval: Dict[str, int] = field(default_factory=lambda: {"batch_size": 128})


# ----------------------------------
# Utilities
# ----------------------------------
def set_global_seeds(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


# ----------------------------------
# Dataset
# ----------------------------------
def make_dataset(cfg: Config) -> Tuple[DataLoader, DataLoader]:
    transform = T.ToTensor()
    train_dataset = D.MNIST(root="./data", train=True, download=True, transform=transform)
    test_dataset = D.MNIST(root="./data", train=False, download=True, transform=transform)
    train_loader = DataLoader(train_dataset, batch_size=cfg.train["batch_size"], shuffle=True)
    test_loader = DataLoader(test_dataset, batch_size=cfg.eval["batch_size"], shuffle=False)
    return train_loader, test_loader


# ----------------------------------
# Models
# ----------------------------------
class VAE(nn.Module):
    def __init__(self, z_dim: int = 8):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Flatten(),
            nn.Linear(28 * 28, 400),
            nn.ReLU(),
        )
        self.fc_mu = nn.Linear(400, z_dim)
        self.fc_logvar = nn.Linear(400, z_dim)
        self.decoder = nn.Sequential(
            nn.Linear(z_dim, 400),
            nn.ReLU(),
            nn.Linear(400, 28 * 28),
            nn.Sigmoid(),
            nn.Unflatten(1, (1, 28, 28)),
        )

    def encode(self, x):
        h = self.encoder(x)
        return self.fc_mu(h), self.fc_logvar(h)

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def decode(self, z):
        return self.decoder(z)

    def forward(self, x):
        mu, logvar = self.encode(x)
        z = self.reparameterize(mu, logvar)
        recon = self.decode(z)
        return recon, mu, logvar


class ConvVAE(nn.Module):
    def __init__(self, z_dim: int = 8):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Conv2d(1, 32, 4, 2, 1),  # 14x14
            nn.ReLU(),
            nn.Conv2d(32, 64, 4, 2, 1),  # 7x7
            nn.ReLU(),
            nn.Flatten(),
        )
        self.fc_mu = nn.Linear(64 * 7 * 7, z_dim)
        self.fc_logvar = nn.Linear(64 * 7 * 7, z_dim)
        self.decoder = nn.Sequential(
            nn.Linear(z_dim, 64 * 7 * 7),
            nn.ReLU(),
            nn.Unflatten(1, (64, 7, 7)),
            nn.ConvTranspose2d(64, 32, 4, 2, 1),  # 14x14
            nn.ReLU(),
            nn.ConvTranspose2d(32, 1, 4, 2, 1),  # 28x28
            nn.Sigmoid(),
        )

    def encode(self, x):
        h = self.encoder(x)
        return self.fc_mu(h), self.fc_logvar(h)

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def decode(self, z):
        return self.decoder(z)

    def forward(self, x):
        mu, logvar = self.encode(x)
        z = self.reparameterize(mu, logvar)
        recon = self.decode(z)
        return recon, mu, logvar


# ----------------------------------
# Engine
# ----------------------------------
class Engine:
    def __init__(self, model: nn.Module, optimizer: optim.Optimizer,
                 train_loader: DataLoader, test_loader: DataLoader, device: torch.device):
        self.model = model.to(device)
        self.optimizer = optimizer
        self.train_loader = train_loader
        self.test_loader = test_loader
        self.device = device

    def loss_function(self, recon_x, x, mu, logvar):
        recon_loss = nn.functional.mse_loss(recon_x, x, reduction='sum')
        kl_loss = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
        return recon_loss + kl_loss, recon_loss, kl_loss

    def train(self) -> Dict[str, float]:
        self.model.train()
        train_loss = 0.0
        train_recon = 0.0
        train_kl = 0.0
        for batch, (x, _) in enumerate(self.train_loader):
            x = x.to(self.device)
            self.optimizer.zero_grad()
            recon, mu, logvar = self.model(x)
            loss, recon_loss, kl_loss = self.loss_function(recon, x, mu, logvar)
            loss.backward()
            self.optimizer.step()
            train_loss += loss.item()
            train_recon += recon_loss.item()
            train_kl += kl_loss.item()
        return {
            "loss": train_loss / len(self.train_loader.dataset),
            "recon": train_recon / len(self.train_loader.dataset),
            "kl": train_kl / len(self.train_loader.dataset),
        }

    def eval(self) -> Dict[str, float]:
        self.model.eval()
        eval_loss = 0.0
        eval_recon = 0.0
        eval_kl = 0.0
        with torch.no_grad():
            for batch, (x, _) in enumerate(self.test_loader):
                x = x.to(self.device)
                recon, mu, logvar = self.model(x)
                loss, recon_loss, kl_loss = self.loss_function(recon, x, mu, logvar)
                eval_loss += loss.item()
                eval_recon += recon_loss.item()
                eval_kl += kl_loss.item()
        return {
            "loss": eval_loss / len(self.test_loader.dataset),
            "recon": eval_recon / len(self.test_loader.dataset),
            "kl": eval_kl / len(self.test_loader.dataset),
        }


# ----------------------------------
# Experiment run
# ----------------------------------
def run(seed: int, cfg: Config, log_dir: str, use_gpu: bool):
    set_global_seeds(seed)
    device = torch.device("cuda" if use_gpu and torch.cuda.is_available() else "cpu")
    train_loader, test_loader = make_dataset(cfg)

    if cfg.nn["type"] == "VAE":
        model = VAE(z_dim=cfg.nn["z_dim"])
    elif cfg.nn["type"] == "ConvVAE":
        model = ConvVAE(z_dim=cfg.nn["z_dim"])
    else:
        raise ValueError(f"Unknown model type {cfg.nn['type']}")

    optimizer = optim.Adam(model.parameters(), lr=cfg.lr)

    engine = Engine(model, optimizer, train_loader, test_loader, device)

    train_logs = []
    eval_logs = []

    for epoch in range(1, cfg.train["num_epoch"] + 1):
        train_log = engine.train()
        eval_log = engine.eval()
        train_logs.append(train_log)
        eval_logs.append(eval_log)

    # Save logs
    os.makedirs(log_dir, exist_ok=True)
    with open(os.path.join(log_dir, "train_logs.pkl"), "wb") as f:
        pickle.dump(train_logs, f)
    with open(os.path.join(log_dir, "eval_logs.pkl"), "wb") as f:
        pickle.dump(eval_logs, f)


# ----------------------------------
# Experiment execution
# ----------------------------------
def run_experiment(
    run_fn: Callable[[int, Config, str, bool], None],
    cfg: Config,
    seeds: List[int],
    log_dir: str,
    max_workers: int,
    use_gpu: bool,
):
    def wrapper(seed):
        seed_dir = os.path.join(log_dir, f"seed_{seed}")
        run_fn(seed, cfg, seed_dir, use_gpu)

    with ProcessPoolExecutor(max_workers=max_workers) as executor:
        list(executor.map(wrapper, seeds))


# ----------------------------------
# Main entry
# ----------------------------------
if __name__ == "__main__":
    config = Config()
    seeds = [1770966829]
    logs_directory = "logs/default"
    workers = os.cpu_count()
    run_experiment(
        run_fn=run,
        cfg=config,
        seeds=seeds,
        log_dir=logs_directory,
        max_workers=workers,
        use_gpu=True,
    )
