import cv2
import numpy as np
import gym
from gym import ObservationWrapper
from gym.spaces import Box

class GrayscaleObservationWrapper(ObservationWrapper):
    def __init__(self, env: gym.Env, keep_dim: bool = False):
        super().__init__(env)
        self.keep_dim = keep_dim

        # Assume original observation space is an RGB image with shape (H, W, 3)
        orig_shape = self.env.observation_space.shape
        height, width = orig_shape[0], orig_shape[1]

        # Determine new shape based on keep_dim flag
        if self.keep_dim:
            new_shape = (height, width, 1)
        else:
            new_shape = (height, width)

        # Create a new observation space with the same bounds and dtype
        low = np.zeros(new_shape, dtype=self.env.observation_space.dtype)
        high = np.full(new_shape, 255, dtype=self.env.observation_space.dtype)
        self.observation_space = Box(low=low, high=high, dtype=self.env.observation_space.dtype)

    def observation(self, observation: np.ndarray) -> np.ndarray:
        # Convert RGB image to grayscale
        gray = cv2.cvtColor(observation, cv2.COLOR_RGB2GRAY)

        # Expand dimensions if keep_dim is True
        if self.keep_dim:
            gray = np.expand_dims(gray, -1)

        return gray.astype(self.observation_space.dtype)