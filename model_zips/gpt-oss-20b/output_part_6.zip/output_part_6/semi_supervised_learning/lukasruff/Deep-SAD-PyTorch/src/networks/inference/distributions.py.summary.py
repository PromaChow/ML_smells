import math
import torch
import torch.nn.functional as F

LOG_2PI = math.log(2 * math.pi)

def log_standard_gaussian(x: torch.Tensor) -> torch.Tensor:
    """Compute the log probability density of a standard normal distribution."""
    term = -0.5 * LOG_2PI - 0.5 * x.pow(2)
    return term.sum(dim=-1)

def log_gaussian(x: torch.Tensor, mu: torch.Tensor, log_var: torch.Tensor) -> torch.Tensor:
    """Compute the log probability density of a Gaussian with mean mu and log variance log_var."""
    var = torch.exp(log_var)
    term = -0.5 * LOG_2PI - 0.5 * log_var - 0.5 * (x - mu).pow(2) / var
    return term.sum(dim=-1)

def log_standard_categorical(p: torch.Tensor) -> torch.Tensor:
    """Compute cross‑entropy between a one‑hot distribution p and a uniform prior."""
    prior = F.softmax(torch.ones_like(p), dim=-1)
    cross_entropy = -torch.sum(p * torch.log(prior + 1e-8), dim=-1)
    return cross_entropy"""