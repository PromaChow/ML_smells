import multiprocessing
import time
import numpy as np

class Loader(multiprocessing.Process):
    def __init__(self, main_queue, option):
        super().__init__()
        self.main_queue = main_queue
        self.dataset = option['dataset']
        self.number_of_loading_dataset = option.get('number_of_loading_dataset', -1)
        self.bShuffle = option.get('bShuffle', False)
        self.debug = option.get('debug', False)

        if (self.number_of_loading_dataset > 0 and
                self.number_of_loading_dataset > len(self.dataset)):
            self.number_of_loading_dataset = -1  # no truncation

    def run(self):
        while True:
            if self.debug:
                start_time = time.perf_counter()

            # Copy and shuffle the entire dataset
            data = self.dataset.copy()
            np.random.shuffle(data)

            # Truncate if required
            if self.number_of_loading_dataset > 0:
                truncated_data = data[:self.number_of_loading_dataset]
            else:
                truncated_data = data.copy()

            if self.debug:
                trunc_time = time.perf_counter()
                print(f"Truncation time: {trunc_time - start_time:.6f}s")

            # Optional second shuffle after truncation
            if self.bShuffle:
                np.random.shuffle(truncated_data)

            # Put processed dataset into the main queue
            self.main_queue.put(truncated_data)