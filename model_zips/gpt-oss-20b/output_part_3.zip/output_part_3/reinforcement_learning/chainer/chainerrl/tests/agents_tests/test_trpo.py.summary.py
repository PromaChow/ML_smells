import os
import tempfile
import pytest
import numpy as np
import chainer
import chainer.cuda
from chainer import Variable
import chainerrl
from chainerrl import algo, links, replay_buffer
from chainerrl.envs import abc
from chainerrl.envs.vector_env import VectorEnv
from chainerrl.envs.multiprocess_vector_env import MultiprocessVectorEnv
from chainerrl.training import (
    train_agent_with_evaluation,
    train_agent_batch_with_evaluation,
    run_evaluation_episodes,
    batch_run_evaluation_episodes,
)
from chainerrl.optimizers import Adam
from chainerrl.misc import EmpiricalNormalization


def make_env_and_successful_return(discrete=True, episodic=True, partially_observable=False):
    env = abc.ABC(
        discrete=discrete,
        episodic=episodic,
        partially_observable=partially_observable,
        successful_return=1,
    )
    return env, 1


def make_model(discrete, recurrent=False):
    if recurrent:
        policy_net = links.StatelessRecurrentSequential(
            chainerrl.links.NStepLSTM(64, 64),
            chainerrl.links.NStepLSTM(64, 64),
            chainerrl.links.Linear(64, 64, activation=chainer.functions.tanh),
        )
        vf_net = links.StatelessRecurrentSequential(
            chainerrl.links.NStepLSTM(64, 64),
            chainerrl.links.NStepLSTM(64, 64),
            chainerrl.links.Linear(64, 1, activation=chainer.functions.tanh),
        )
    else:
        policy_net = chainerrl.links.Linear(64, 64, activation=chainer.functions.tanh)
        vf_net = chainerrl.links.Linear(64, 1, activation=chainer.functions.tanh)
    if discrete:
        pi = chainerrl.links.FCSoftmaxPolicy(policy_net)
    else:
        pi = chainerrl.links.FCGaussianPolicy(policy_net, stdev=0.1)
    vf = chainerrl.links.ValueFunction(vf_net)
    return pi, vf


def make_agent(
    pi,
    vf,
    gamma=0.5,
    lambd=0.0,
    entropy_coef=0.0,
    standardize_advantages=False,
    standardize_obs=False,
    recurrent=False,
    gpu=-1,
):
    agent = algo.trpo.TRPO(
        pi,
        vf,
        gamma=gamma,
        lambd=lambd,
        entropy_coef=entropy_coef,
        standardize_advantages=standardize_advantages,
        standardize_obs=standardize_obs,
    )
    vf_optimizer = Adam(chainerrl.optimizers.GradientClipping(agent.vf, 1.0))
    agent.vf_opt = vf_optimizer
    if gpu >= 0:
        with chainer.cuda.get_device_from_id(gpu):
            agent.to_gpu()
    return agent


def compute_hessian_vector_product(agent, env, x, v):
    x_var = Variable(chainer.cuda.to_gpu(x) if agent.device >= 0 else x)
    v_var = Variable(chainer.cuda.to_gpu(v) if agent.device >= 0 else v)
    loss = agent.calc_loss(env, x_var, v_var)
    grads = chainer.grad([loss], [agent.vf], enable_double_backprop=True)
    return grads[0]


def compute_hessian(agent, env, x):
    dim = x.size
    hessian = np.zeros((dim, dim))
    for i in range(dim):
        e_i = np.zeros(dim)
        e_i[i] = 1.0
        hvp = compute_hessian_vector_product(agent, env, x, e_i)
        hessian[:, i] = hvp
    return hessian


class TestTRPOABC:
    @pytest.fixture
    def tmpdir(self):
        with tempfile.TemporaryDirectory() as d:
            yield d

    @pytest.mark.parametrize(
        "discrete,episodic,lambd,entropy_coef,standardize_advantages,standardize_obs,recurrent,fast",
        [
            (True, True, 0.0, 0.0, False, False, False, False),
            (True, True, 0.5, 1e-5, True, True, False, False),
            (False, False, 0.9, 0.0, False, False, False, False),
            (True, False, 0.5, 0.0, True, False, True, False),
        ],
    )
    def test_abc_single(
        self,
        tmpdir,
        discrete,
        episodic,
        lambd,
        entropy_coef,
        standardize_advantages,
        standardize_obs,
        recurrent,
        fast,
    ):
        env, success_return = make_env_and_successful_return(
            discrete=discrete, episodic=episodic, partially_observable=recurrent
        )
        pi, vf = make_model(discrete=discrete, recurrent=recurrent)
        agent = make_agent(
            pi,
            vf,
            gamma=0.5,
            lambd=lambd,
            entropy_coef=entropy_coef,
            standardize_advantages=standardize_advantages,
            standardize_obs=standardize_obs,
            recurrent=recurrent,
        )
        steps = 100 if fast else 100000
        eval_interval = 200
        train_agent_with_evaluation(
            agent,
            env,
            steps=steps,
            outdir=tmpdir,
            eval_interval=eval_interval,
            eval_n_episodes=5,
            max_episode_len=None if episodic else 2,
            successful_score=success_return,
        )
        episode_scores = run_evaluation_episodes(agent, env, n_test_runs=10)
        assert all(score >= success_return for score in episode_scores)

    @pytest.mark.parametrize(
        "discrete,episodic,lambd,entropy_coef,standardize_advantages,standardize_obs,recurrent,fast",
        [
            (True, True, 0.0, 0.0, False, False, False, False),
            (True, False, 0.5, 1e-5, True, True, False, False),
        ],
    )
    def test_abc_batch(
        self,
        tmpdir,
        discrete,
        episodic,
        lambd,
        entropy_coef,
        standardize_advantages,
        standardize_obs,
        recurrent,
        fast,
    ):
        envs = []
        for _ in range(4):
            env, _ = make_env_and_successful_return(
                discrete=discrete, episodic=episodic, partially_observable=recurrent
            )
            envs.append(env)
        vec_env = MultiprocessVectorEnv(envs)
        pi, vf = make_model(discrete=discrete, recurrent=recurrent)
        agent = make_agent(
            pi,
            vf,
            gamma=0.5,
            lambd=lambd,
            entropy_coef=entropy_coef,
            standardize_advantages=standardize_advantages,
            standardize_obs=standardize_obs,
            recurrent=recurrent,
        )
        steps = 100 if fast else 100000
        eval_interval = 200
        train_agent_batch_with_evaluation(
            agent,
            vec_env,
            steps=steps,
            outdir=tmpdir,
            eval_interval=eval_interval,
            eval_n_episodes=40,
            max_episode_len=None if episodic else 2,
            successful_score=1,
        )
        episode_scores = batch_run_evaluation_episodes(agent, vec_env, n_test_runs=10)
        assert all(score >= 1 for score in episode_scores)

    @pytest.mark.parametrize(
        "gpu,discrete,episodic,lambd,entropy_coef,standardize_advantages,standardize_obs,recurrent",
        [
            (0, True, True, 0.0, 0.0, False, False, False),
            (0, True, False, 0.5, 0.0, True, False, True),
        ],
    )
    def test_abc_gpu(
        self,
        tmpdir,
        gpu,
        discrete,
        episodic,
        lambd,
        entropy_coef,
        standardize_advantages,
        standardize_obs,
        recurrent,
    ):
        if not chainer.backends.cuda.available or gpu < 0:
            pytest.skip("GPU not available")
        if recurrent:
            pytest.skip("Recurrent models are skipped on GPU")
        env, success_return = make_env_and_successful_return(
            discrete=discrete, episodic=episodic, partially_observable=recurrent
        )
        pi, vf = make_model(discrete=discrete, recurrent=recurrent)
        agent = make_agent(
            pi,
            vf,
            gamma=0.5,
            lambd=lambd,
            entropy_coef=entropy_coef,
            standardize_advantages=standardize_advantages,
            standardize_obs=standardize_obs,
            recurrent=recurrent,
            gpu=gpu,
        )
        steps = 100
        eval_interval = 200
        train_agent_with_evaluation(
            agent,
            env,
            steps=steps,
            outdir=tmpdir,
            eval_interval=eval_interval,
            eval_n_episodes=5,
            max_episode_len=None if episodic else 2,
            successful_score=success_return,
        )
        episode_scores = run_evaluation_episodes(agent, env, n_test_runs=10)
        assert all(score >= success_return for score in episode_scores)

    def test_load_save(self, tmpdir):
        env, success_return = make_env_and_successful_return(discrete=True, episodic=True)
        pi, vf = make_model(discrete=True, recurrent=False)
        agent = make_agent(pi, vf, gamma=0.5, lambd=0.5)
        train_agent_with_evaluation(
            agent,
            env,
            steps=100,
            outdir=tmpdir,
            eval_interval=200,
            eval_n_episodes=5,
            max_episode_len=None,
            successful_score=success_return,
        )
        # Save
        agent_path = os.path.join(tmpdir, "agent.npz")
        agent.save(agent_path)
        # Load
        loaded_agent = algo.trpo.TRPO.load(agent_path)
        episode_scores = run_evaluation_episodes(loaded_agent, env, n_test_runs=5)
        assert all(score >= success_return for score in episode_scores)

    def test_second_order(self, tmpdir):
        env, _ = make_env_and_successful_return(discrete=True, episodic=True)
        pi, vf = make_model(discrete=True, recurrent=False)
        agent = make_agent(pi, vf, gamma=0.5, lambd=0.5)
        # Use a single step to compute Hessian
        x = np.random.randn(64).astype(np.float32)
        hess = compute_hessian(agent, env, x)
        assert hess.shape == (64, 64)


class TestFindOldStyleFunction:
    def test_missing_double_backprop(self):
        import chainer

        # Dummy check that double backprop is available
        try:
            with chainer.FunctionScope():
                y = chainer.Variable(np.array([1.0], dtype=np.float32))
                y2 = y * y
                grad = chainer.grad([y2], [y], enable_double_backprop=True)
                assert grad[0] is not None
        except Exception as e:
            pytest.fail(f"Double backprop not supported: {e}")
