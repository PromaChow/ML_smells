import gym
import random
from typing import Any, Tuple, Union

class NoopReset(gym.Wrapper):
    """
    Gym wrapper that performs a random number of NOOP actions after resetting the environment.
    """
    def __init__(self, env: gym.Env, max_noops: int = 30):
        super().__init__(env)
        self.max_noops = max_noops

        # Verify that the environment has a NOOP action at index 0
        try:
            action_meanings = self.env.unwrapped.get_action_meanings()
        except AttributeError:
            raise RuntimeError("The wrapped environment does not provide get_action_meanings().")

        if not action_meanings or action_meanings[0] != "NOOP":
            raise ValueError("The first action of the environment must be labeled 'NOOP'.")

    def reset(self, **kwargs: Any) -> Union[Any, Tuple[Any, dict]]:
        """
        Reset the environment and perform a random number of NOOP actions.
        """
        # Handle different Gym reset signatures
        try:
            obs = self.env.reset(**kwargs)
            if isinstance(obs, tuple):
                obs, _ = obs
        except TypeError:
            # Fallback for older Gym versions
            obs = self.env.reset(**kwargs)

        noops = random.randint(1, self.max_noops)
        for _ in range(noops):
            obs, reward, done, info = self.env.step(0)  # NOOP action is 0
            if done:
                # If done during noops, reset again and stop nooping
                try:
                    obs = self.env.reset(**kwargs)
                    if isinstance(obs, tuple):
                        obs, _ = obs
                except TypeError:
                    obs = self.env.reset(**kwargs)
                break

        return obs

    def step(self, action: int) -> Tuple[Any, float, bool, dict]:
        return self.env.step(action)


class FireReset(gym.Wrapper):
    """
    Gym wrapper that ensures a FIRE action is performed during reset if required by the environment.
    """
    def __init__(self, env: gym.Env):
        super().__init__(env)

    def reset(self, **kwargs: Any) -> Union[Any, Tuple[Any, dict]]:
        try:
            obs = self.env.reset(**kwargs)
            if isinstance(obs, tuple):
                obs, _ = obs
        except TypeError:
            obs = self.env.reset(**kwargs)

        # Retrieve action meanings if available
        try:
            action_meanings = self.env.unwrapped.get_action_meanings()
        except AttributeError:
            action_meanings = []

        if len(action_meanings) >= 3 and action_meanings[1] == "FIRE":
            # Execute FIRE action (index 1)
            obs, reward, done, info = self.env.step(1)
            # If not done, execute the next action (index 2)
            if not done:
                obs, reward, done, info = self.env.step(2)
            # If done after either step, we simply return the latest observation

        return obs

    def step(self, action: int) -> Tuple[Any, float, bool, dict]:
        return self.env.step(action)