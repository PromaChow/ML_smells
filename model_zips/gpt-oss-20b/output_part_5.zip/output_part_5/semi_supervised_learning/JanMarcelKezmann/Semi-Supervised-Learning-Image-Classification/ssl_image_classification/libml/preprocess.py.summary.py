import os
import random

import tensorflow as tf
import tensorflow_datasets as tfds


tf.random.set_seed(42)
random.seed(42)


def download_dataset(dataset_name: str):
    train_ds, test_ds = tfds.load(
        dataset_name,
        split=["train", "test"],
        as_supervised=True,
        download=True,
    )
    train_ds = train_ds.map(lambda x, y: {"image": x, "label": y})
    test_ds = test_ds.map(lambda x, y: {"image": x, "label": y})
    return train_ds, test_ds


def _list_to_tf_dataset(data_list):
    return tf.data.Dataset.from_tensor_slices(data_list)


def split_dataset(dataset, num_labeled, num_validations, num_classes):
    data_list = list(dataset.as_numpy_iterator())
    random.shuffle(data_list)

    labeled_per_class = num_labeled // num_classes
    validation_per_class = num_validations // num_classes

    labeled_counts = {i: 0 for i in range(num_classes)}
    validation_counts = {i: 0 for i in range(num_classes)}

    trainX_list = []
    trainU_list = []
    validation_list = []

    for item in data_list:
        label = int(item["label"])
        if labeled_counts[label] < labeled_per_class:
            trainX_list.append(item)
            labeled_counts[label] += 1
        elif validation_counts[label] < validation_per_class:
            validation_list.append(item)
            validation_counts[label] += 1
        else:
            trainU_list.append({"image": item["image"], "label": -1})

    trainX_ds = _list_to_tf_dataset(trainX_list)
    trainU_ds = _list_to_tf_dataset(trainU_list)
    validation_ds = _list_to_tf_dataset(validation_list)

    return trainX_ds, trainU_ds, validation_ds


def export_tfrecord_dataset(dataset, filepath):
    with tf.io.TFRecordWriter(filepath) as writer:
        for elem in dataset.as_numpy_iterator():
            image = elem["image"]
            label = int(elem["label"])
            png_bytes = tf.io.encode_png(image).numpy()
            feature = {
                "image": tf.train.Feature(
                    bytes_list=tf.train.BytesList(value=[png_bytes])
                ),
                "label": tf.train.Feature(
                    int64_list=tf.train.Int64List(value=[label])
                ),
            }
            example = tf.train.Example(features=tf.train.Features(feature=feature))
            writer.write(example.SerializeToString())


def _parse_function(example_proto):
    features = {
        "image": tf.io.FixedLenFeature([], tf.string),
        "label": tf.io.FixedLenFeature([], tf.int64),
    }
    parsed = tf.io.parse_single_example(example_proto, features)
    return parsed


def load_tfrecord_dataset(filepath):
    raw_dataset = tf.data.TFRecordDataset(filepath)
    return raw_dataset.map(_parse_function)


def process_parsed_dataset(dataset, num_classes):
    def _process(example):
        image = tf.io.decode_png(example["image"], channels=3)
        image = tf.cast(image, tf.float32) / 127.5 - 1.0
        label = tf.one_hot(example["label"], depth=num_classes)
        return {"image": image, "label": label}

    return dataset.map(_process)


def fetch_dataset(
    log_dir,
    dataset_name="cifar10",
    num_labeled=500,
    num_validations=1000,
    num_classes=10,
):
    os.makedirs(log_dir, exist_ok=True)

    trainX_path = os.path.join(log_dir, "trainX.tfrecord")
    trainU_path = os.path.join(log_dir, "trainU.tfrecord")
    validation_path = os.path.join(log_dir, "validation.tfrecord")
    test_path = os.path.join(log_dir, "test.tfrecord")

    if not all(
        [
            os.path.exists(trainX_path),
            os.path.exists(trainU_path),
            os.path.exists(validation_path),
            os.path.exists(test_path),
        ]
    ):
        train_ds, test_ds = download_dataset(dataset_name)
        trainX_ds, trainU_ds, validation_ds = split_dataset(
            train_ds, num_labeled, num_validations, num_classes
        )
        export_tfrecord_dataset(trainX_ds, trainX_path)
        export_tfrecord_dataset(trainU_ds, trainU_path)
        export_tfrecord_dataset(validation_ds, validation_path)
        export_tfrecord_dataset(test_ds, test_path)

    trainX_raw = load_tfrecord_dataset(trainX_path)
    trainU_raw = load_tfrecord_dataset(trainU_path)
    validation_raw = load_tfrecord_dataset(validation_path)
    test_raw = load_tfrecord_dataset(test_path)

    trainX = process_parsed_dataset(trainX_raw, num_classes)
    trainU = process_parsed_dataset(trainU_raw, num_classes)
    validation = process_parsed_dataset(validation_raw, num_classes)
    test = process_parsed_dataset(test_raw, num_classes)

    return trainX, trainU, validation, test
