import random
import torch
from torch.utils.data import Subset
from torchvision import datasets, transforms

# Seed for reproducibility
random.seed(42)
torch.manual_seed(42)

class MyFashionMNIST(datasets.FashionMNIST):
    """Custom FashionMNIST dataset with semi-supervised target support."""

    def __init__(self, root, train=True, transform=None, target_transform=None, download=False):
        super().__init__(root, train=train, transform=transform,
                         target_transform=target_transform, download=download)
        # Initialize semi-supervised targets as zeros
        self.semi_targets = torch.zeros(len(self), dtype=torch.long)

    def __getitem__(self, idx):
        image, target = super().__getitem__(idx)
        semi_target = self.semi_targets[idx]
        return image, target, semi_target, idx


def create_semisupervised_setting(targets, normal_class, outlier_classes,
                                  ratio_known_normal, ratio_known_outlier, ratio_pollution):
    """
    Generate semi-supervised indices and labels.
    This is a placeholder implementation. It assigns all samples to the semi-supervised set
    and labels them as 0 for normal, 1 for outliers. Ratios are ignored for simplicity.
    """
    targets = torch.tensor(targets)
    is_normal = (targets == normal_class)
    is_outlier = torch.isin(targets, torch.tensor(outlier_classes))
    semi_targets = torch.where(is_normal, torch.tensor(0), torch.tensor(1))
    idx = torch.arange(len(targets))
    return idx, semi_targets


def main():
    # Configuration
    normal_class = 0
    n_known_outlier_classes = 2
    ratio_known_normal = 0.5
    ratio_known_outlier = 0.5
    ratio_pollution = 0.1

    # Define transformations
    transform = transforms.Compose([transforms.ToTensor()])
    target_transform = lambda y: 0 if y == normal_class else 1

    # Load original training set with binary target transform
    train_full = MyFashionMNIST(root='./data', train=True,
                                transform=transform,
                                target_transform=target_transform,
                                download=True)

    # Determine outlier classes
    all_classes = set(range(10))
    outlier_classes = list(all_classes - {normal_class})
    known_outlier_classes = random.sample(outlier_classes, n_known_outlier_classes)

    # Generate semi-supervised setting
    idx, semi_targets = create_semisupervised_setting(
        targets=train_full.targets.numpy(),
        normal_class=normal_class,
        outlier_classes=known_outlier_classes,
        ratio_known_normal=ratio_known_normal,
        ratio_known_outlier=ratio_known_outlier,
        ratio_pollution=ratio_pollution
    )

    # Update semi_targets in the dataset
    train_full.semi_targets[idx] = semi_targets[idx]
    # Subset to selected indices
    train_set = Subset(train_full, idx.tolist())

    # Load test set (no semi-supervised targets needed)
    test_set = MyFashionMNIST(root='./data', train=False,
                              transform=transform,
                              target_transform=target_transform,
                              download=True)

    # Example usage: iterate over the train set
    for batch in torch.utils.data.DataLoader(train_set, batch_size=32, shuffle=True):
        images, targets, semi_targets, indices = batch
        # Your training logic here
        break  # remove this in real training loop


if __name__ == "__main__":
    main()
