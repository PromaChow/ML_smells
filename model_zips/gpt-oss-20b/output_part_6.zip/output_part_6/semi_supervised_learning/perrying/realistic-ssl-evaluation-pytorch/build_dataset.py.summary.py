import argparse
import os
import numpy as np
import torch
from torchvision import datasets

# ---------- Configuration ----------
COUNTS = {
    "svhn": {"train": 73257, "test": 26032, "valid": 5000, "extra": 531131},
    "cifar10": {"train": 50000, "test": 10000, "valid": 5000}
}
_DATA_DIR = "./data"
EPS = 1e-5


def global_contrast_normalize(img):
    """Apply global contrast normalization to an image."""
    mean = img.mean()
    img = img - mean
    norm = np.linalg.norm(img) + EPS
    return img / norm


def compute_zca_parameters(X):
    """Compute ZCA whitening parameters."""
    X_flat = X.reshape(X.shape[0], -1)
    mean = X_flat.mean(axis=0)
    X_centered = X_flat - mean
    sigma = np.dot(X_centered.T, X_centered) / X.shape[0]
    U, S, _ = np.linalg.svd(sigma, full_matrices=False)
    zca_matrix = U @ np.diag(1.0 / np.sqrt(S + EPS)) @ U.T
    return mean, zca_matrix


def apply_zca(X, mean, zca_matrix):
    """Apply ZCA whitening to a batch of images."""
    X_flat = X.reshape(X.shape[0], -1)
    X_centered = X_flat - mean
    X_white = X_centered @ zca_matrix
    return X_white.reshape(X.shape)


def preprocess_cifar10(train_images, test_images):
    """Preprocess CIFAR10 images: GCN → ZCA → transpose."""
    # Global Contrast Normalization
    train_gcn = np.stack([global_contrast_normalize(img) for img in train_images], axis=0)
    test_gcn = np.stack([global_contrast_normalize(img) for img in test_images], axis=0)

    # ZCA Whitening
    mean, zca_matrix = compute_zca_parameters(train_gcn)
    train_zca = apply_zca(train_gcn, mean, zca_matrix)
    test_zca = apply_zca(test_gcn, mean, zca_matrix)

    # Transpose to (N, C, H, W)
    train_out = train_zca.transpose(0, 3, 1, 2).astype(np.float32)
    test_out = test_zca.transpose(0, 3, 1, 2).astype(np.float32)
    return train_out, test_out


def load_svhn():
    train = datasets.SVHN(root=_DATA_DIR, split="train", download=True)
    test = datasets.SVHN(root=_DATA_DIR, split="test", download=True)
    extra = datasets.SVHN(root=_DATA_DIR, split="extra", download=True)
    train_images = train.data.astype(np.float32)
    train_labels = np.array(train.labels, dtype=np.int64)
    test_images = test.data.astype(np.float32)
    test_labels = np.array(test.labels, dtype=np.int64)
    extra_images = extra.data.astype(np.float32)
    extra_labels = np.array(extra.labels, dtype=np.int64)
    return train_images, train_labels, test_images, test_labels, extra_images, extra_labels


def load_cifar10():
    train = datasets.CIFAR10(root=_DATA_DIR, train=True, download=True)
    test = datasets.CIFAR10(root=_DATA_DIR, train=False, download=True)
    train_images = np.array(train.data, dtype=np.float32)
    train_labels = np.array(train.targets, dtype=np.int64)
    test_images = np.array(test.data, dtype=np.float32)
    test_labels = np.array(test.targets, dtype=np.int64)
    return train_images, train_labels, test_images, test_labels


def split_l_u(indices, labels, nlabels, num_classes):
    """Split indices into labeled and unlabeled sets."""
    labeled_idx = []
    remaining = set(indices)
    per_class = nlabels // num_classes
    for cls in range(num_classes):
        cls_indices = [idx for idx in indices if labels[idx] == cls]
        if len(cls_indices) < per_class:
            selected = cls_indices
        else:
            selected = np.random.choice(cls_indices, per_class, replace=False)
        labeled_idx.extend(selected)
        remaining.difference_update(selected)
    unlabeled_idx = list(remaining)
    return np.array(labeled_idx, dtype=np.int64), np.array(unlabeled_idx, dtype=np.int64)


def main():
    parser = argparse.ArgumentParser(description="Prepare semi-supervised dataset")
    parser.add_argument("--seed", type=int, default=0, help="Random seed")
    parser.add_argument(
        "--dataset",
        type=str,
        choices=["svhn", "cifar10"],
        required=True,
        help="Dataset to use",
    )
    parser.add_argument(
        "--nlabels",
        type=int,
        required=True,
        help="Number of labeled samples to use",
    )
    args = parser.parse_args()

    np.random.seed(args.seed)
    torch.manual_seed(args.seed)

    if args.dataset == "svhn":
        train_img, train_lbl, test_img, test_lbl, extra_img, extra_lbl = load_svhn()
        # No preprocessing for SVHN
        train_img_np = train_img
        test_img_np = test_img
    else:
        train_img, train_lbl, test_img, test_lbl = load_cifar10()
        train_img_np, test_img_np = preprocess_cifar10(train_img, test_img)
        extra_img_np = None
        extra_lbl_np = None

    # Permute indices
    train_indices = np.arange(len(train_img_np))
    np.random.shuffle(train_indices)

    if args.dataset == "svhn":
        extra_indices = np.arange(len(extra_img))
        np.random.shuffle(extra_indices)
        extra_img_np = extra_img
        extra_lbl_np = extra_lbl

    # Validation split
    val_size = COUNTS[args.dataset]["valid"]
    val_indices = train_indices[:val_size]
    train_indices = train_indices[val_size:]

    # Labeled/Unlabeled split
    num_classes = len(np.unique(train_lbl))
    l_idx, u_idx = split_l_u(train_indices, train_lbl, args.nlabels, num_classes)

    # Prepare datasets
    l_train_imgs = train_img_np[l_idx]
    l_train_lbls = train_lbl[l_idx]
    u_train_imgs = train_img_np[u_idx]
    u_train_lbls = train_lbl[u_idx]
    val_imgs = train_img_np[val_indices]
    val_lbls = train_lbl[val_indices]
    test_imgs = test_img_np
    test_lbls = test_lbl

    # Create output directory
    out_dir = os.path.join(_DATA_DIR, args.dataset)
    os.makedirs(out_dir, exist_ok=True)

    # Save datasets
    np.save(os.path.join(out_dir, "l_train_imgs.npy"), l_train_imgs)
    np.save(os.path.join(out_dir, "l_train_lbls.npy"), l_train_lbls)
    np.save(os.path.join(out_dir, "u_train_imgs.npy"), u_train_imgs)
    np.save(os.path.join(out_dir, "u_train_lbls.npy"), u_train_lbls)
    np.save(os.path.join(out_dir, "val_imgs.npy"), val_imgs)
    np.save(os.path.join(out_dir, "val_lbls.npy"), val_lbls)
    np.save(os.path.join(out_dir, "test_imgs.npy"), test_imgs)
    np.save(os.path.join(out_dir, "test_lbls.npy"), test_lbls)

    if args.dataset == "svhn":
        np.save(os.path.join(out_dir, "extra_imgs.npy"), extra_img_np)
        np.save(os.path.join(out_dir, "extra_lbls.npy"), extra_lbl_np)


if __name__ == "__main__":
    main()
