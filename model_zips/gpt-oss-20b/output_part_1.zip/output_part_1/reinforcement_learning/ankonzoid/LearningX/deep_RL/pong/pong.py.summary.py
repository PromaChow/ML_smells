import os
import pickle
import gym
import numpy as np

# Hyperparameters
H = 200                   # hidden layer size
BATCH_SIZE = 10           # update after this many episodes
LR = 1e-4                 # learning rate
GAMMA = 0.99              # discount factor
DECAY = 0.99              # RMSProp decay
RESUME = False            # load model if True
RENDER = False            # render environment if True
MODEL_FILE = 'model.p'

# Model initialization
INPUT_DIM = 80 * 80       # 6400
if RESUME and os.path.isfile(MODEL_FILE):
    data = pickle.load(open(MODEL_FILE, 'rb'))
    W1 = data['W1']
    W2 = data['W2']
else:
    W1 = np.random.randn(INPUT_DIM, H) * np.sqrt(1. / INPUT_DIM)
    W2 = np.random.randn(H, 1) * np.sqrt(1. / H)

# Gradients and RMSProp cache
grad_buffer = {'W1': np.zeros_like(W1), 'W2': np.zeros_like(W2)}
rmsprop_cache = {'W1': np.zeros_like(W1), 'W2': np.zeros_like(W2)}

def sigmoid(x):
    return 1. / (1. + np.exp(-x))

def prepro(I):
    I = I[35:195]                      # crop
    I = I[::2, ::2, 0]                 # downsample & take one channel
    I[I == 144] = 0
    I[I == 109] = 0
    I[I != 0] = 1
    return I.astype(np.float).ravel()

def discount_rewards(r):
    discounted_r = np.zeros_like(r, dtype=np.float)
    running_sum = 0.
    for t in reversed(range(0, r.size)):
        if r[t] != 0:
            running_sum = 0.
        running_sum = running_sum * GAMMA + r[t]
        discounted_r[t] = running_sum
    return discounted_r

def policy_forward(x):
    h = np.maximum(0, np.dot(x, W1))
    logp = np.dot(h, W2)
    p = sigmoid(logp)
    return p, h

def policy_backward(x, h, dlogp):
    dW2 = np.outer(h, dlogp)
    dh = dlogp * W2.T
    dh[h <= 0] = 0
    dW1 = np.outer(x, dh)
    return dW1, dW2

env = gym.make('Pong-v0')
observation = env.reset()
prev_x = None
episode_num = 0
running_reward = None

while True:
    xs, hs, dlogps, rewards = [], [], [], []
    episode_reward = 0
    done = False
    while not done:
        cur_x = prepro(observation)
        if prev_x is None:
            prev_x = np.zeros_like(cur_x)
        x = cur_x - prev_x
        aprob, h = policy_forward(x)
        action = 2 if np.random.rand() < aprob else 3
        y = 1 if action == 2 else 0
        dlogp = y - aprob
        xs.append(x)
        hs.append(h)
        dlogps.append(dlogp)
        observation, reward, done, info = env.step(action)
        episode_reward += reward
        rewards.append(reward)
        prev_x = cur_x
        if RENDER:
            env.render()
    # End of episode
    episode_num += 1
    rewards = np.array(rewards)
    discounted_r = discount_rewards(rewards)
    discounted_r -= np.mean(discounted_r)
    discounted_r /= np.std(discounted_r) + 1e-8
    for i in range(len(xs)):
        dlogps[i] *= discounted_r[i]
    dW1, dW2 = np.zeros_like(W1), np.zeros_like(W2)
    for i in range(len(xs)):
        dw1, dw2 = policy_backward(xs[i], hs[i], dlogps[i])
        dW1 += dw1
        dW2 += dw2
    grad_buffer['W1'] += dW1
    grad_buffer['W2'] += dW2
    if episode_num % BATCH_SIZE == 0:
        for param, dparam, cache in zip([W1, W2], [grad_buffer['W1'], grad_buffer['W2']],
                                        [rmsprop_cache['W1'], rmsprop_cache['W2']]):
            cache = DECAY * cache + (1 - DECAY) * dparam**2
            param += LR * dparam / (np.sqrt(cache) + 1e-5)
        grad_buffer = {'W1': np.zeros_like(W1), 'W2': np.zeros_like(W2)}
    if running_reward is None:
        running_reward = episode_reward
    else:
        running_reward = 0.99 * running_reward + 0.01 * episode_reward
    print(f"Episode: {episode_num}\tReward: {episode_reward}\tRunning reward: {running_reward:.3f}")
    if episode_num % 100 == 0:
        pickle.dump({'W1': W1, 'W2': W2}, open(MODEL_FILE, 'wb'))
    observation = env.reset()
    prev_x = None
    env.close()