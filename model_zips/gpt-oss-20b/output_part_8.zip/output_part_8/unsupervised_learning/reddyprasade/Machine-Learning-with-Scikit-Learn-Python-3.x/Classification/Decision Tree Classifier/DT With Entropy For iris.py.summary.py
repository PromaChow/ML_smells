import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, plot_tree

# Load dataset
url = "https://raw.githubusercontent.com/uiuc-cse/data-fa14/gh-pages/data/iris.csv"
df = pd.read_csv(url)

# Inspect data
print(df.head())
print(df.tail())

# Feature and target selection
X = df[['sepal_length', 'sepal_width', 'petal_length', 'petal_width']]
y = df['species']

# Train-test split
x_train, x_test, y_train, y_test = train_test_split(X, y)

# Model initialization
clf = DecisionTreeClassifier(criterion='entropy', max_features=2)

# Model training
clf.fit(x_train, y_train)

# Prediction
yhat = clf.predict(x_test)

# Feature importance analysis
importances = clf.feature_importances_
print("Feature importances:", importances)

# Bar plot of feature importances
features = X.columns
plt.figure(figsize=(8, 6))
sns.barplot(x=importances, y=features)
plt.title("Feature Importances")
plt.xlabel("Importance")
plt.ylabel("Feature")
plt.tight_layout()
plt.show()

# Decision tree visualization (default)
plt.figure()
plot_tree(clf)
plt.title("Decision Tree (default)")
plt.show()

# Decision tree visualization with adjusted size and filled colors
fig, ax = plt.subplots(figsize=(16, 9))
plot_tree(clf, ax=ax, filled=True)
plt.title("Decision Tree (filled, 16x9)")
plt.show()