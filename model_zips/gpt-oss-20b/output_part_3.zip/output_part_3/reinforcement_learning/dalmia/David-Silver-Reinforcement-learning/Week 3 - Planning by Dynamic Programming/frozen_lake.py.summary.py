import gym
import numpy as np


def policy_iteration(env, gamma=0.99, tol=1e-3, max_iterations=1000):
    """Perform policy iteration on a discrete MDP."""
    n_states = env.observation_space.n
    n_actions = env.action_space.n

    # Initialize a random policy
    policy = np.zeros((n_states, n_actions), dtype=np.float32)
    for s in range(n_states):
        policy[s, np.random.choice(n_actions)] = 1.0

    V = np.zeros(n_states, dtype=np.float32)

    for _ in range(max_iterations):
        # Policy evaluation
        delta = 0
        while True:
            delta = 0
            for s in range(n_states):
                v = 0
                for a in range(n_actions):
                    prob = policy[s, a]
                    for prob_transition, next_s, reward, done in env.P[s][a]:
                        v += prob * prob_transition * (reward + gamma * V[next_s])
                delta = max(delta, abs(V[s] - v))
                V[s] = v
            if delta < tol:
                break

        # Policy improvement
        policy_stable = True
        for s in range(n_states):
            old_action = np.argmax(policy[s])
            q_values = np.zeros(n_actions, dtype=np.float32)
            for a in range(n_actions):
                for prob_transition, next_s, reward, done in env.P[s][a]:
                    q_values[a] += prob_transition * (reward + gamma * V[next_s])
            best_action = np.argmax(q_values)
            if best_action != old_action:
                policy_stable = False
            policy[s] = 0.0
            policy[s, best_action] = 1.0

        if policy_stable:
            break

    return policy, V


def value_iteration(env, gamma=0.99, tol=1e-3, max_iterations=1000):
    """Perform value iteration on a discrete MDP."""
    n_states = env.observation_space.n
    n_actions = env.action_space.n

    V = np.zeros(n_states, dtype=np.float32)

    for _ in range(max_iterations):
        delta = 0
        for s in range(n_states):
            q_values = np.zeros(n_actions, dtype=np.float32)
            for a in range(n_actions):
                for prob_transition, next_s, reward, done in env.P[s][a]:
                    q_values[a] += prob_transition * (reward + gamma * V[next_s])
            new_v = np.max(q_values)
            delta = max(delta, abs(V[s] - new_v))
            V[s] = new_v
        if delta < tol:
            break

    policy = np.zeros((n_states, n_actions), dtype=np.float32)
    for s in range(n_states):
        q_values = np.zeros(n_actions, dtype=np.float32)
        for a in range(n_actions):
            for prob_transition, next_s, reward, done in env.P[s][a]:
                q_values[a] += prob_transition * (reward + gamma * V[next_s])
        best_action = np.argmax(q_values)
        policy[s, best_action] = 1.0

    return policy, V


def play_episodes(env, policy, n_episodes=10000):
    """Simulate episodes using the given deterministic policy."""
    wins = 0
    total_reward = 0.0

    for _ in range(n_episodes):
        state, _ = env.reset()
        episode_reward = 0.0
        done = False

        while not done:
            action = np.argmax(policy[state])
            state, reward, done, truncated, _ = env.step(action)
            episode_reward += reward
            if done:
                break

        if episode_reward == 1.0:
            wins += 1
        total_reward += episode_reward

    avg_reward = total_reward / n_episodes
    return wins, total_reward, avg_reward


action_mappings = {0: '←', 1: '↓', 2: '→', 3: '↑'}


def print_policy_grid(policy_actions, grid_size=8):
    """Print the policy grid using arrow symbols."""
    for i in range(grid_size):
        row = policy_actions[i * grid_size : (i + 1) * grid_size]
        symbols = [action_mappings.get(a, '?') for a in row]
        print(' '.join(symbols))
    print()


def main():
    solvers = [
        ('Policy Iteration', policy_iteration),
        ('Value Iteration', value_iteration),
    ]

    for solver_name, solver_func in solvers:
        env = gym.make('FrozenLake8x8-v0')
        inner_env = env.env

        policy, V = solver_func(inner_env)

        # Convert policy to deterministic actions
        policy_actions = np.argmax(policy, axis=1)

        print(f"=== {solver_name} ===")
        print("Optimal policy:")
        print_policy_grid(policy_actions, grid_size=8)

        wins, total_reward, avg_reward = play_episodes(env, policy)

        print(f"Wins: {wins} / 10000")
        print(f"Average reward: {avg_reward:.4f}")
        print("-" * 40)


if __name__ == "__main__":
    main()
