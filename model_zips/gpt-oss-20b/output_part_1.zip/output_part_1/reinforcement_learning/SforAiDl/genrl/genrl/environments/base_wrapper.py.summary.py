import numpy as np
from abc import ABC, abstractmethod
from typing import Any

class BaseWrapper(ABC):
    def __init__(self, env: Any, batch_size: Any = None) -> None:
        self.env = env
        self._batch_size = batch_size

    @property
    def batch_size(self) -> Any:
        return self._batch_size

    @abstractmethod
    def seed(self, seed_value: int) -> None:
        """Set a seed for the environment."""
        raise NotImplementedError

    @abstractmethod
    def render(self, mode: str = "human") -> None:
        """Render the environment."""
        raise NotImplementedError

    @abstractmethod
    def step(self, action: Any) -> Any:
        """Execute an action in the environment."""
        raise NotImplementedError

    @abstractmethod
    def reset(self) -> Any:
        """Reset the environment to an initial state."""
        raise NotImplementedError

    @abstractmethod
    def close(self) -> None:
        """Clean up resources."""
        raise NotImplementedError

    def __enter__(self) -> "BaseWrapper":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()
