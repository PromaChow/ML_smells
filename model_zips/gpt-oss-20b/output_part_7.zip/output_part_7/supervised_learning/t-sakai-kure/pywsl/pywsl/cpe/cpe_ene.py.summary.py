import numpy as np


def alpha_dist(a: np.ndarray, b: np.ndarray, alpha: float) -> np.ndarray:
    """
    Compute the pairwise Euclidean distances between rows of a and b,
    optionally applying a power transformation.
    """
    diff = a[:, None, :] - b[None, :, :]  # shape (m, n, d)
    dist = np.linalg.norm(diff, axis=2)
    if alpha != 1.0:
        dist = dist ** alpha
    return dist


class ThetaCalculator:
    def __init__(self, y: np.ndarray, xl: np.ndarray, xu: np.ndarray, alpha: float = 1.0):
        self.y = y
        self.xl = xl
        self.xu = xu
        self.alpha = alpha
        self.classes = np.unique(y)
        self.n_c = len(self.classes)
        self.x = [xl[y == cls] for cls in self.classes]

    def compute_theta(self) -> float:
        # Step 2: Compute vector b
        b = np.empty(self.n_c)
        for i, xi in enumerate(self.x):
            dists = alpha_dist(xi, self.xu, self.alpha)
            b[i] = 2.0 * np.mean(dists)

        # Step 3: Construct matrix A
        A = np.empty((self.n_c, self.n_c))
        for i in range(self.n_c):
            for j in range(self.n_c):
                dists = alpha_dist(self.x[i], self.x[j], self.alpha)
                A[i, j] = -np.mean(dists)

        # Step 4: Slice matrices and vectors
        As = A[: self.n_c - 1, : self.n_c - 1]
        a = A[: self.n_c - 1, self.n_c - 1]
        Ac = A[self.n_c - 1, self.n_c - 1]
        bs = b[: self.n_c - 1]
        bc = b[self.n_c - 1]

        # Step 5: Reformulate Anew and bnew
        Anew = As - a[:, None] - a[None, :] + Ac
        Anew = (Anew + Anew.T) / 2.0
        bnew = 2.0 * a - 2.0 * Ac + bs - bc

        # Step 6: Solve linear system
        try:
            x0 = np.linalg.solve(2.0 * Anew, bnew)
        except np.linalg.LinAlgError:
            # If singular, use least squares solution
            x0 = np.linalg.lstsq(2.0 * Anew, bnew, rcond=None)[0]

        x0 = np.clip(x0, 0.0, 1.0)

        # Step 7: Compute theta
        theta = 1.0 - np.sum(x0)
        return theta
