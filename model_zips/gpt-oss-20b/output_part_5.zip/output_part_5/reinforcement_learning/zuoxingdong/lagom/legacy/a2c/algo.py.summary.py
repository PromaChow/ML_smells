import os
import pickle
import random
import numpy as np
import torch
from pathlib import Path
from itertools import count
from typing import Any, Dict, List, Tuple

# ------------------------------------------------------------------
# Utility functions
# ------------------------------------------------------------------
def set_global_seeds(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

# ------------------------------------------------------------------
# Dummy environment wrappers
# ------------------------------------------------------------------
class VecClipAction:
    def __init__(self, env, clip_action: bool = True):
        self.env = env
        self.clip_action = clip_action

    def reset(self):
        return self.env.reset()

    def step(self, actions):
        if self.clip_action:
            clipped = np.clip(actions, self.env.action_space.low, self.env.action_space.high)
            return self.env.step(clipped)
        return self.env.step(actions)

    def __getattr__(self, name):
        return getattr(self.env, name)

class VecStandardize:
    def __init__(self, env, ob_std: bool = True, re_std: bool = True, eps: float = 1e-8):
        self.env = env
        self.ob_std = ob_std
        self.re_std = re_std
        self.eps = eps
        self.obs_mean = np.zeros(self.env.observation_space.shape, dtype=np.float32)
        self.obs_var = np.ones(self.env.observation_space.shape, dtype=np.float32)
        self.rew_mean = 0.0
        self.rew_var = 1.0
        self.count = 1

    def reset(self):
        obs = self.env.reset()
        return self._normalize_obs(obs)

    def step(self, actions):
        obs, rewards, dones, infos = self.env.step(actions)
        self._update_stats(obs, rewards)
        return self._normalize_obs(obs), self._normalize_rew(rewards), dones, infos

    def _update_stats(self, obs, rewards):
        self.count += 1
        alpha = 1.0 / self.count
        delta = obs - self.obs_mean
        self.obs_mean += alpha * delta
        delta2 = obs - self.obs_mean
        self.obs_var += alpha * (delta * delta2 - self.obs_var)

        self.rew_mean += alpha * (rewards - self.rew_mean)
        self.rew_var += alpha * ((rewards - self.rew_mean)**2 - self.rew_var)

    def _normalize_obs(self, obs):
        if self.ob_std:
            return (obs - self.obs_mean) / np.sqrt(self.obs_var + self.eps)
        return obs

    def _normalize_rew(self, rew):
        if self.re_std:
            return (rew - self.rew_mean) / np.sqrt(self.rew_var + self.eps)
        return rew

    def __getattr__(self, name):
        return getattr(self.env, name)

# ------------------------------------------------------------------
# Environment creation utilities
# ------------------------------------------------------------------
def make_gym_env(env_id: str, seed: int):
    import gym
    def _init():
        env = gym.make(env_id)
        env.seed(seed)
        return env
    return _init

def make_vec_env(env_id: str, n_envs: int, seed: int):
    from stable_baselines3.common.vec_env import SerialVecEnv
    env_fns = [make_gym_env(env_id, seed + i) for i in range(n_envs)]
    return SerialVecEnv(env_fns)

# ------------------------------------------------------------------
# Environment specification
# ------------------------------------------------------------------
class EnvSpec:
    def __init__(self, env):
        self.observation_space = env.observation_space
        self.action_space = env.action_space
        self.num_envs = getattr(env, 'num_envs', 1)

# ------------------------------------------------------------------
# Dummy Agent
# ------------------------------------------------------------------
class Agent:
    def __init__(self, config: Dict[str, Any], env_spec: EnvSpec, device: torch.device):
        self.config = config
        self.env_spec = env_spec
        self.device = device

    def train(self, env, batch_size: int = 1) -> Dict[str, Any]:
        # Dummy training step
        return {"timesteps": batch_size, "loss": np.random.rand()}

    def evaluate(self, env, episodes: int = 1) -> Dict[str, Any]:
        # Dummy evaluation step
        return {"episode_reward": np.random.rand() * 10, "episode_length": 100}

# ------------------------------------------------------------------
# RollingSegmentRunner placeholder
# ------------------------------------------------------------------
class RollingSegmentRunner:
    def __init__(self, agent: Agent, env):
        self.agent = agent
        self.env = env

    def run(self, batch_size: int = 1):
        return self.agent.train(self.env, batch_size)

# ------------------------------------------------------------------
# Engine placeholder
# ------------------------------------------------------------------
class Engine:
    def __init__(self, agent: Agent, runner: RollingSegmentRunner, config: Dict[str, Any], eval_env=None):
        self.agent = agent
        self.runner = runner
        self.config = config
        self.eval_env = eval_env

    def train(self, iteration: int) -> Dict[str, Any]:
        return self.runner.run(batch_size=1)

    def eval(self, n: int = 0) -> Dict[str, Any]:
        if self.eval_env is None:
            return {}
        return self.agent.evaluate(self.eval_env, episodes=1)

    def log_train(self, output: Dict[str, Any]) -> Dict[str, Any]:
        return {"iteration": output, "log_type": "train"}

    def log_eval(self, output: Dict[str, Any]) -> Dict[str, Any]:
        return {"evaluation": output, "log_type": "eval"}

# ------------------------------------------------------------------
# Main training routine
# ------------------------------------------------------------------
def main(config: Dict[str, Any]) -> None:
    seed = config.get("seed", 42)
    set_global_seeds(seed)

    log_dir = Path(config["log.dir"]) / config["ID"] / f"seed_{seed}"
    log_dir.mkdir(parents=True, exist_ok=True)

    # Training environment
    train_env = make_vec_env(
        env_id=config["env.id"],
        n_envs=config["train.N"],
        seed=seed
    )

    # Apply wrappers to training env
    if config.get("env.clip_action", False):
        train_env = VecClipAction(train_env)
    if config.get("env.standardize", False):
        train_env = VecStandardize(train_env)

    # Evaluation environment
    eval_env = None
    if config.get("eval.independent", False):
        eval_env = make_vec_env(
            env_id=config["env.id"],
            n_envs=config["eval.N"],
            seed=seed + 1000
        )
        if config.get("env.clip_action", False):
            eval_env = VecClipAction(eval_env)
        if config.get("env.standardize", False):
            eval_env = VecStandardize(eval_env)

    env_spec = EnvSpec(train_env)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    agent = Agent(config, env_spec, device)
    runner = RollingSegmentRunner(agent, train_env)
    engine = Engine(agent, runner, config, eval_env=eval_env)

    train_logs: List[Dict[str, Any]] = []
    eval_logs: List[Dict[str, Any]] = []

    total_timesteps = 0
    max_iter = config["train.iter"]
    max_timesteps = config["train.timestep"]
    log_interval = config["log.interval"]

    for i in count():
        if i >= max_iter or total_timesteps >= max_timesteps:
            break

        train_output = engine.train(i)
        total_timesteps += train_output.get("timesteps", 0)

        if i % log_interval == 0:
            log_entry = engine.log_train(train_output)
            train_logs.append(log_entry)

        if config.get("eval.independent", False):
            eval_output = engine.eval(n=i)
            log_entry = engine.log_eval(eval_output)
            eval_logs.append(log_entry)

    # Save logs
    with open(log_dir / "train_logs.pkl", "wb") as f:
        pickle.dump(train_logs, f)
    with open(log_dir / "eval_logs.pkl", "wb") as f:
        pickle.dump(eval_logs, f)

if __name__ == "__main__":
    # Example configuration
    config_example = {
        "seed": 123,
        "log.dir": "./logs",
        "ID": "experiment_01",
        "env.id": "CartPole-v1",
        "train.N": 8,
        "eval.N": 4,
        "env.clip_action": True,
        "env.standardize": False,
        "eval.independent": True,
        "train.iter": 1000,
        "train.timestep": 50000,
        "log.interval": 100
    }
    main(config_example)