import io
import sys
import warnings
from typing import Any

import torch
import dill
from dill import Pickler as DillPickler

# 1. Set multiprocessing strategy
torch.multiprocessing.set_sharing_strategy("file_system")

# 2. Mark modules as static to avoid pickling CDLL errors
def mark_static_module(module: Any) -> None:
    """Remove __file__ attribute to mark module as static."""
    if hasattr(module, "__file__"):
        del module.__file__

# Apply to the torch module
mark_static_module(torch)

# 3. Custom reduction functions for full tensor/Storage serialization
def _rebuild_full(data: bytes) -> Any:
    """Rebuild an object from full serialized data."""
    buffer = io.BytesIO(data)
    return torch.load(buffer, map_location="cpu")

def _reduce_full(obj: Any) -> tuple:
    """Serialize an object into a byte stream."""
    buffer = io.BytesIO()
    torch.save(obj, buffer, pickle_module=dill)
    return (_rebuild_full, (buffer.getvalue(),))

# 4. Custom Pickler
class Pickler(DillPickler):
    def __init__(self, *args, recurse: bool = True, copy_tensor: bool = True, **kwargs):
        super().__init__(*args, **kwargs)
        self.recurse = recurse
        self.copy_tensor = copy_tensor

        # Register PyTorch-specific reductions
        # Tensor
        if self.copy_tensor:
            self.dispatch[torch.Tensor] = _reduce_full
        else:
            self.dispatch[torch.Tensor] = torch._utils._reduce_tensor

        # Storage
        if self.copy_tensor:
            self.dispatch[torch.Storage] = _rebuild_full
        else:
            self.dispatch[torch.Storage] = torch._utils._reduce_storage

        # Event (e.g., TensorEvent)
        self.dispatch[torch._C._TensorBase] = torch._utils._reduce_event

# 5. dumps function
def dumps(obj: Any, recurse: bool = True, copy_tensor: bool = True) -> bytes:
    """Serialize an object into bytes using the custom Pickler."""
    buffer = io.BytesIO()
    pickler = Pickler(buffer, recurse=recurse, copy_tensor=copy_tensor, protocol=dill.DEFAULT_PROTOCOL)
    pickler.dump(obj)
    return buffer.getvalue()

# 6. Alias loads to dill.loads
loads = dill.loads

# 7. Warning about old PyTorch bug
try:
    from packaging.version import Version
    if Version(torch.__version__) < Version("1.5.0"):
        warnings.warn(
            "Using a PyTorch version prior to 1.5.0 may cause issues with referenced GPU tensors "
            "that require persistent shared memory. Consider updating PyTorch."
        )
except Exception:
    pass
