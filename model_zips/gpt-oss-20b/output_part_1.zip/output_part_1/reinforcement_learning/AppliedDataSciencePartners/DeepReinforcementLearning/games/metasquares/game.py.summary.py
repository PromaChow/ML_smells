import copy

class GameState:
    def __init__(self, board, playerTurn, winners=None):
        self.board = board[:]  # list of 25 integers
        self.playerTurn = playerTurn  # 1 or -1
        self.winners = winners if winners is not None else []
        # binary representation
        self.binary = [0 if v == 0 else 1 if v == 1 else 2 for v in self.board]
        self.id = ",".join(map(str, self.board))
        self.allowedActions = [i for i, v in enumerate(self.board) if v == 0]
        self.isEndGame = len(self.allowedActions) == 1
        self.score = self._getValue()
        if self.score[0] > self.score[1]:
            self.value = 1
        elif self.score[0] < self.score[1]:
            self.value = -1
        else:
            self.value = 0

    def _getValue(self):
        """Calculate points for both players based on scoring regions."""
        player_points = 0
        opponent_points = 0
        for region in self.winners:
            # region is a list of indices
            if all(self.board[i] == self.playerTurn for i in region):
                player_points += 1
            elif all(self.board[i] == -self.playerTurn for i in region):
                opponent_points += 1
        return (player_points, opponent_points)

    def takeAction(self, action):
        new_board = self.board[:]
        new_board[action] = self.playerTurn
        new_state = GameState(new_board, -self.playerTurn, self.winners)
        done = new_state.isEndGame
        # reward to the player who made the move
        if done:
            # new_state.value is relative to new_state.playerTurn
            # if new_state.value == 1 => new_state.playerTurn wins => mover loses
            reward = -new_state.value
        else:
            reward = 0
        return new_state, reward, done

    def render(self, logger):
        symbols = {1: 'X', -1: 'O', 0: '-'}
        for row in range(5):
            line = ""
            for col in range(5):
                idx = row * 5 + col
                line += symbols[self.board[idx]] + " "
            logger.info(line.strip())


class Game:
    def __init__(self):
        empty_board = [0] * 25
        self.currentPlayer = 1
        # Define some example scoring regions (e.g., winning lines)
        self.winners = [
            [0, 1, 2, 3, 4],           # top row
            [5, 6, 7, 8, 9],           # second row
            [10, 11, 12, 13, 14],      # third row
            [15, 16, 17, 18, 19],      # fourth row
            [20, 21, 22, 23, 24],      # bottom row
            [0, 5, 10, 15, 20],        # first column
            [1, 6, 11, 16, 21],        # second column
            [2, 7, 12, 17, 22],        # third column
            [3, 8, 13, 18, 23],        # fourth column
            [4, 9, 14, 19, 24],        # fifth column
            [0, 6, 12, 18, 24],        # diagonal \
            [4, 8, 12, 16, 20]         # diagonal /
        ]
        self.gameState = GameState(empty_board, 1, self.winners)
        self.actionSpace = [0] * 25

    def reset(self):
        empty_board = [0] * 25
        self.gameState = GameState(empty_board, 1, self.winners)
        self.currentPlayer = 1

    def step(self, action):
        new_state, reward, done = self.gameState.takeAction(action)
        self.gameState = new_state
        self.currentPlayer *= -1
        return new_state, reward, done

    def identities(self, state, actionValues):
        """Generate 10 transformed versions of the board and action values."""
        def rotate_board(board):
            matrix = [board[i * 5:(i + 1) * 5] for i in range(5)]
            rotated = list(zip(*matrix[::-1]))
            return [item for row in rotated for item in row]

        def rotate_action_vals(vals):
            matrix = [vals[i * 5:(i + 1) * 5] for i in range(5)]
            rotated = list(zip(*matrix[::-1]))
            return [item for row in rotated for item in row]

        transformed = []

        # Original board and 90,180,270 rotations
        rotations = [state.board]
        vals = [actionValues]
        for _ in range(3):
            rotations.append(rotate_board(rotations[-1]))
            vals.append(rotate_action_vals(vals[-1]))
        # Include 360 (same as original) to have 5
        rotations.append(rotations[0])
        vals.append(vals[0])

        for r_board, r_vals in zip(rotations, vals):
            transformed.append((GameState(r_board, state.playerTurn, self.winners), r_vals))

        # Vertical flip of each rotation
        for r_board, r_vals in zip(rotations, vals):
            flipped_board = r_board[::-1]  # reverse rows
            flipped_vals_matrix = [r_vals[i * 5:(i + 1) * 5] for i in range(5)]
            flipped_vals = [item for row in flipped_vals_matrix[::-1] for item in row]
            transformed.append((GameState(flipped_board, state.playerTurn, self.winners), flipped_vals))

        return transformed
