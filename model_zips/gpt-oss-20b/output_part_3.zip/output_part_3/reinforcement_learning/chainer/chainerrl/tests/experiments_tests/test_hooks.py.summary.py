import numpy as np

class LinearInterpolationHook:
    def __init__(self, total_steps: int, start_value: float, stop_value: float, setter):
        self.total_steps = total_steps
        self.start_value = start_value
        self.stop_value = stop_value
        self.setter = setter

    def __call__(self, step: int):
        if self.total_steps <= 1:
            value = self.stop_value
        else:
            ratio = (step - 1) / (self.total_steps - 1)
            value = self.start_value + (self.stop_value - self.start_value) * ratio
        self.setter(value)


def main():
    buf = []

    def setter(value):
        buf.append(value)

    hook = LinearInterpolationHook(
        total_steps=10,
        start_value=0.1,
        stop_value=1.0,
        setter=setter,
    )

    for step in range(1, 11):
        hook(step)

    expected = np.arange(1, 11, dtype=np.float32) / 10
    np.testing.assert_allclose(buf, expected, rtol=1e-5, atol=1e-8)
    print("All values match expected array.")


if __name__ == "__main__":
    main()
