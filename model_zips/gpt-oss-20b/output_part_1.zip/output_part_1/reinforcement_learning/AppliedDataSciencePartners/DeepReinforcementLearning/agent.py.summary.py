import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import random
from collections import deque

# Placeholder functions for game environment
def is_terminal(state: np.ndarray) -> bool:
    return False

def get_reward(state: np.ndarray) -> float:
    return 0.0

def get_legal_actions(state: np.ndarray) -> list[int]:
    return list(range(5))

def apply_action(state: np.ndarray, action: int) -> np.ndarray:
    return state

class Node:
    def __init__(self, state: np.ndarray, parent: "Node" = None):
        self.state = state
        self.parent = parent
        self.children: dict[int, Node] = {}
        self.N = 0
        self.W = 0.0
        self.Q = 0.0
        self.P = 0.0

    def expanded(self) -> bool:
        return len(self.children) > 0

    def update(self, value: float):
        self.N += 1
        self.W += value
        self.Q = self.W / self.N

class MCTS:
    def __init__(self, model, cpuct: float = 1.0, num_simulations: int = 800):
        self.root: Node | None = None
        self.model = model
        self.cpuct = cpuct
        self.num_simulations = num_simulations

    def search(self, state: np.ndarray, legal_actions: list[int]) -> Node:
        if self.root is None or not np.array_equal(self.root.state, state):
            self.root = Node(state)
        for _ in range(self.num_simulations):
            leaf, path = self._select(self.root, legal_actions)
            value = self._evaluate(leaf, legal_actions)
            self._backpropagate(path, value)
        return self.root

    def _select(self, node: Node, legal_actions: list[int]):
        path = [node]
        while node.expanded():
            max_ucb = -float("inf")
            best_action = None
            best_child = None
            for a in legal_actions:
                if a in node.children:
                    child = node.children[a]
                    ucb = child.Q + self.cpuct * child.P * (np.sqrt(node.N) / (1 + child.N))
                    if ucb > max_ucb:
                        max_ucb = ucb
                        best_action = a
                        best_child = child
            if best_child is None:
                break
            node = best_child
            path.append(node)
        return node, path

    def _evaluate(self, leaf: Node, legal_actions: list[int]) -> float:
        if is_terminal(leaf.state):
            return get_reward(leaf.state)
        logits, value = self.model.predict(leaf.state)
        probs = self._policy_mask_and_softmax(logits, legal_actions)
        leaf.children = {}
        for a in legal_actions:
            next_state = apply_action(leaf.state, a)
            child = Node(next_state, parent=leaf)
            child.P = probs[a]
            leaf.children[a] = child
        return value

    def _policy_mask_and_softmax(self, logits: np.ndarray, legal_actions: list[int]) -> np.ndarray:
        mask = np.full(logits.shape[0], -np.inf)
        mask[legal_actions] = 0.0
        masked_logits = logits + mask
        exp = np.exp(masked_logits - np.max(masked_logits))
        probs = exp / np.sum(exp)
        return probs

    def _backpropagate(self, path: list[Node], value: float):
        for node in reversed(path):
            node.update(value)
            value = -value  # zero‑sum assumption

class SimpleNet(nn.Module):
    def __init__(self, state_size: int, action_size: int):
        super().__init__()
        self.fc = nn.Linear(state_size, 128)
        self.policy_head = nn.Linear(128, action_size)
        self.value_head = nn.Linear(128, 1)

    def forward(self, x: torch.Tensor):
        x = F.relu(self.fc(x))
        logits = self.policy_head(x)
        value = torch.tanh(self.value_head(x))
        return logits, value

    def predict(self, state: np.ndarray):
        with torch.no_grad():
            state_tensor = torch.tensor(state, dtype=torch.float32).unsqueeze(0)
            logits, value = self(state_tensor)
            return logits.squeeze(0).numpy(), value.item()

class Agent:
    def __init__(
        self,
        state_size: int,
        action_size: int,
        num_simulations: int = 800,
        cpuct: float = 1.0,
        tau: float = 1.0,
        model: nn.Module | None = None,
    ):
        self.state_size = state_size
        self.action_size = action_size
        self.tau = tau
        self.model = model or SimpleNet(state_size, action_size)
        self.mcts = MCTS(self.model, cpuct, num_simulations)
        self.memory: deque = deque(maxlen=100000)

    def select_action(self, state: np.ndarray) -> int:
        legal_actions = get_legal_actions(state)
        root = self.mcts.search(state, legal_actions)
        visit_counts = np.array(
            [root.children[a].N if a in root.children else 0 for a in range(self.action_size)]
        )
        if self.tau == 0:
            action = int(np.argmax(visit_counts))
        else:
            probs = visit_counts ** (1.0 / self.tau)
            probs = probs / probs.sum()
            action = np.random.choice(self.action_size, p=probs)
        pi = np.zeros(self.action_size)
        pi[legal_actions] = visit_counts[legal_actions] ** (1.0 / self.tau)
        pi /= pi.sum()
        value = root.Q
        self.memory.append((state.copy(), value, pi.copy()))
        return action

    def train(self, batch_size: int = 32, epochs: int = 1, lr: float = 1e-3):
        if len(self.memory) < batch_size:
            return
        samples = random.sample(self.memory, batch_size)
        states, values, pis = zip(*samples)
        states = torch.tensor(np.array(states), dtype=torch.float32)
        values = torch.tensor(np.array(values), dtype=torch.float32).unsqueeze(1)
        pis = torch.tensor(np.array(pis), dtype=torch.float32)
        optimizer = torch.optim.Adam(self.model.parameters(), lr=lr)
        for _ in range(epochs):
            logits, val_preds = self.model(states)
            policy_loss = -(pis * F.log_softmax(logits, dim=1)).sum(dim=1).mean()
            value_loss = F.mse_loss(val_preds, values)
            loss = policy_loss + value_loss
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

if __name__ == "__main__":
    agent = Agent(state_size=10, action_size=5, num_simulations=50)
    dummy_state = np.zeros(10)
    action = agent.select_action(dummy_state)
    print("Selected action:", action)