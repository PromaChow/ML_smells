import os
import unittest
import numpy as np
import geopandas as gpd
from scipy.sparse.csgraph import connected_components
from sklearn.metrics import accuracy_score
from pysal.lib.weights.contiguity import Rook
from spenc import SPENC  # Assumed import from the SPENC library


class TestSPENC(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Load geospatial dataset
        cls.shp_path = os.path.join(os.path.dirname(__file__), "NAT.shp")
        cls.gdf = gpd.read_file(cls.shp_path)

        # Create spatial weights matrix using Rook contiguity
        cls.w = Rook.from_dataframe(cls.gdf)
        cls.W = cls.w.full()[0]  # adjacency matrix as scipy sparse matrix

        # Load precomputed label arrays
        data_dir = os.path.join(os.path.dirname(__file__), "precomputed")
        cls.nat_10k_nodata = np.load(os.path.join(data_dir, "nat_10k_nodata.npy"))
        cls.nat_30k_randoms = np.load(os.path.join(data_dir, "nat_30k_randoms.npy"))
        cls.nat_infk_randoms = np.load(os.path.join(data_dir, "nat_infk_randoms.npy"))
        cls.nat_30k_discovered = np.load(os.path.join(data_dir, "nat_30k_discovered.npy"))
        cls.nat_infk_discovered = np.load(os.path.join(data_dir, "nat_infk_discovered.npy"))

        # Normalize feature columns by year codes
        year_cols = [col for col in cls.gdf.columns if col.startswith("Y")]
        X = cls.gdf[year_cols].values.astype(float)
        X = (X - X.mean(axis=0)) / X.std(axis=0)
        cls.X = X

    def _check_connected_components(self, labels):
        """Ensure each cluster forms a single connected component."""
        unique_labels = np.unique(labels)
        for lab in unique_labels:
            mask = labels == lab
            subgraph = self.W[mask][:, mask]
            n_components, _ = connected_components(csgraph=subgraph, directed=False, return_labels=False)
            self.assertEqual(n_components, 1, f"Cluster {lab} is disconnected")

    def test_NAT_nodata(self):
        SEED = 1901
        np.random.seed(SEED)
        spenc = SPENC(n_clusters=10, random_state=SEED)
        labels = spenc.fit(self.W)
        self._check_connected_components(labels)
        acc = accuracy_score(self.nat_10k_nodata, labels)
        self.assertAlmostEqual(acc, 1.0, places=4)

    def test_NAT_randoms(self):
        SEED = 1901
        np.random.seed(SEED)

        # 3 random cluster assignments for finite clusters
        spenc = SPENC(n_clusters=10, random_state=SEED)
        random_labels = spenc.sample(self.W, n_samples=3)
        self.assertEqual(random_labels.shape, (self.W.shape[0], 3))
        for i in range(3):
            self._check_connected_components(random_labels[:, i])
        acc = accuracy_score(self.nat_30k_randoms, random_labels)
        self.assertAlmostEqual(acc, 1.0, places=4)

        # Infinite clusters
        spenc_inf = SPENC(n_clusters=None, infinite=True, random_state=SEED)
        inf_random_labels = spenc_inf.sample(self.W, n_samples=3)
        self.assertEqual(inf_random_labels.shape, (self.W.shape[0], 3))
        for i in range(3):
            self._check_connected_components(inf_random_labels[:, i])
        acc_inf = accuracy_score(self.nat_infk_randoms, inf_random_labels)
        self.assertAlmostEqual(acc_inf, 1.0, places=4)

    def test_NAT_data(self):
        SEED = 1901
        np.random.seed(SEED)

        # Fit with 30 clusters using features and weights
        spenc = SPENC(n_clusters=30, random_state=SEED)
        labels = spenc.fit(self.X, self.W)
        self._check_connected_components(labels)
        acc = accuracy_score(self.nat_30k_discovered, labels)
        self.assertAlmostEqual(acc, 1.0, places=4)

        # Infinite clusters with floor parameter
        spenc_inf = SPENC(n_clusters=None, infinite=True, floor=10, random_state=SEED)
        inf_labels = spenc_inf.fit(self.X, self.W)
        self._check_connected_components(inf_labels)
        acc_inf = accuracy_score(self.nat_infk_discovered, inf_labels)
        self.assertAlmostEqual(acc_inf, 1.0, places=4)


if __name__ == "__main__":
    unittest.main()
