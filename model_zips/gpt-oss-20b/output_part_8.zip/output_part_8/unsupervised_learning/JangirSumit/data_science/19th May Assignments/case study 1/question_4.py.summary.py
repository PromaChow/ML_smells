import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('HollywoodMovies.csv')

plt.figure(figsize=(8, 6))
plt.scatter(df['RottenTomatoes'], df['AudienceScore'], alpha=0.7)
plt.xlabel('Rotten Tomatoes')
plt.ylabel('Audience Score')
plt.title('Critics vs Audience')
plt.grid(True)
plt.tight_layout()
plt.show()

plt.figure(figsize=(8, 6))
plt.scatter(df['RottenTomatoes'], df['Profitability'], alpha=0.7)
plt.xlabel('Rotten Tomatoes')
plt.ylabel('Profitability')
plt.title('Critics vs Profitability')
plt.grid(True)
plt.tight_layout()
plt.show()