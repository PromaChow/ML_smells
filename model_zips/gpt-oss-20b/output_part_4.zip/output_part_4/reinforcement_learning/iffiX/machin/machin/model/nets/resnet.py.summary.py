import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.utils import weight_norm

def conv1x1(in_planes, out_planes, stride=1):
    return nn.Conv2d(
        in_planes, out_planes, kernel_size=1, stride=stride, bias=False
    )

def conv3x3(in_planes, out_planes, stride=1):
    return nn.Conv2d(
        in_planes,
        out_planes,
        kernel_size=3,
        stride=stride,
        padding=1,
        bias=False,
    )

def conv5x5(in_planes, out_planes, stride=1):
    return nn.Conv2d(
        in_planes,
        out_planes,
        kernel_size=5,
        stride=stride,
        padding=2,
        bias=False,
    )

def _cfg(depth, norm):
    if depth == 18 or depth == 34:
        block = BasicBlock if norm != "weight" else BasicBlockWN
        layers = [2, 2, 2, 2]
    elif depth == 50 or depth == 101 or depth == 152:
        block = Bottleneck if norm != "weight" else BottleneckWN
        if depth == 50:
            layers = [3, 4, 6, 3]
        elif depth == 101:
            layers = [3, 4, 23, 3]
        else:
            layers = [3, 8, 36, 3]
    else:
        raise ValueError(f"Unsupported depth: {depth}")
    return block, layers

class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, inplanes, planes, stride=1, downsample=None, norm="batch"):
        super().__init__()
        self.conv1 = conv3x3(inplanes, planes, stride)
        self.bn1 = nn.BatchNorm2d(planes) if norm == "batch" else None
        self.conv2 = conv3x3(planes, planes)
        self.bn2 = nn.BatchNorm2d(planes) if norm == "batch" else None
        self.downsample = downsample
        self.relu = nn.ReLU(inplace=True)
        self.norm = norm

    def forward(self, x):
        identity = x
        out = self.conv1(x)
        if self.norm == "batch":
            out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        if self.norm == "batch":
            out = self.bn2(out)

        if self.downsample is not None:
            identity = self.downsample(x)

        out += identity
        out = self.relu(out)
        return out

class Bottleneck(nn.Module):
    expansion = 4

    def __init__(self, inplanes, planes, stride=1, downsample=None, norm="batch"):
        super().__init__()
        self.conv1 = conv1x1(inplanes, planes)
        self.bn1 = nn.BatchNorm2d(planes) if norm == "batch" else None
        self.conv2 = conv3x3(planes, planes, stride)
        self.bn2 = nn.BatchNorm2d(planes) if norm == "batch" else None
        self.conv3 = conv1x1(planes, planes * self.expansion)
        self.bn3 = nn.BatchNorm2d(planes * self.expansion) if norm == "batch" else None
        self.downsample = downsample
        self.relu = nn.ReLU(inplace=True)
        self.norm = norm

    def forward(self, x):
        identity = x

        out = self.conv1(x)
        if self.norm == "batch":
            out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        if self.norm == "batch":
            out = self.bn2(out)
        out = self.relu(out)

        out = self.conv3(out)
        if self.norm == "batch":
            out = self.bn3(out)

        if self.downsample is not None:
            identity = self.downsample(x)

        out += identity
        out = self.relu(out)
        return out

class BasicBlockWN(nn.Module):
    expansion = 1

    def __init__(self, inplanes, planes, stride=1, downsample=None):
        super().__init__()
        self.conv1 = weight_norm(conv3x3(inplanes, planes, stride))
        self.conv2 = weight_norm(conv3x3(planes, planes))
        self.downsample = downsample
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        identity = x

        out = self.conv1(x)
        out = self.relu(out)

        out = self.conv2(out)

        if self.downsample is not None:
            identity = self.downsample(x)

        out += identity
        out = self.relu(out)
        return out

class BottleneckWN(nn.Module):
    expansion = 4

    def __init__(self, inplanes, planes, stride=1, downsample=None):
        super().__init__()
        self.conv1 = weight_norm(conv1x1(inplanes, planes))
        self.conv2 = weight_norm(conv3x3(planes, planes, stride))
        self.conv3 = weight_norm(conv1x1(planes, planes * self.expansion))
        self.downsample = downsample
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        identity = x

        out = self.conv1(x)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.relu(out)

        out = self.conv3(out)

        if self.downsample is not None:
            identity = self.downsample(x)

        out += identity
        out = self.relu(out)
        return out

class ResNet(nn.Module):
    def __init__(self, depth=50, num_classes=1000, norm="batch", out_pool_size=1):
        super().__init__()
        self.norm = norm
        block, layers = _cfg(depth, norm)
        self.inplanes = 64
        self.conv1 = nn.Conv2d(
            3, 64, kernel_size=7, stride=2, padding=3, bias=False
        )
        self.bn1 = nn.BatchNorm2d(64) if norm == "batch" else None
        self.relu = nn.ReLU(inplace=True)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)

        self.layer1 = self._make_layer(block, 64, layers[0], stride=1)
        self.layer2 = self._make_layer(block, 128, layers[1], stride=2)
        self.layer3 = self._make_layer(block, 256, layers[2], stride=2)
        self.layer4 = self._make_layer(block, 512, layers[3], stride=2)

        self.avgpool = nn.AdaptiveAvgPool2d((out_pool_size, out_pool_size))
        self.fc = nn.Linear(512 * block.expansion * out_pool_size * out_pool_size, num_classes)

    def _make_layer(self, block, planes, blocks, stride=1):
        downsample = None
        if stride != 1 or self.inplanes != planes * block.expansion:
            conv = conv1x1(self.inplanes, planes * block.expansion, stride)
            if self.norm == "batch":
                bn = nn.BatchNorm2d(planes * block.expansion)
                downsample = nn.Sequential(conv, bn)
            else:
                downsample = conv

        layers = []
        if self.norm == "weight":
            layers.append(
                block(
                    self.inplanes,
                    planes,
                    stride,
                    downsample=downsample,
                )
            )
        else:
            layers.append(
                block(
                    self.inplanes,
                    planes,
                    stride,
                    downsample=downsample,
                    norm=self.norm,
                )
            )
        self.inplanes = planes * block.expansion
        for _ in range(1, blocks):
            if self.norm == "weight":
                layers.append(
                    block(
                        self.inplanes,
                        planes,
                    )
                )
            else:
                layers.append(
                    block(
                        self.inplanes,
                        planes,
                        norm=self.norm,
                    )
                )
        return nn.Sequential(*layers)

    def forward(self, x):
        if x.size(2) != 224 or x.size(3) != 224:
            raise ValueError("Input spatial dimensions must be 224x224")

        x = self.conv1(x)
        if self.norm == "batch":
            x = self.bn1(x)
        x = self.relu(x)
        x = self.maxpool(x)

        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)

        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.fc(x)
        return x
```