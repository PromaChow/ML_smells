import numpy as np


def same_dim(x1, x2):
    if x1.shape[1] != x2.shape[1]:
        raise ValueError(
            f"Arrays must have the same number of columns: x1.shape[1]={x1.shape[1]}, x2.shape[1]={x2.shape[1]}"
        )


def in_range(x, a, b, name):
    if not (a < x < b):
        raise ValueError(
            f"Variable '{name}' must satisfy {a} < {name} < {b}, but got {x}"
        )


def check_bags(bags):
    if not isinstance(bags, list):
        raise TypeError(f"Input must be a list, got {type(bags).__name__}")

    processed = []
    for idx, item in enumerate(bags):
        arr = np.array(item)
        if arr.ndim == 1:
            raise ValueError(
                f"Bag at index {idx} has 1 dimension. Reshape using reshape(-1,1) or reshape(1,-1)."
            )
        arr = np.atleast_2d(arr)
        processed.append(arr)

    return processed

