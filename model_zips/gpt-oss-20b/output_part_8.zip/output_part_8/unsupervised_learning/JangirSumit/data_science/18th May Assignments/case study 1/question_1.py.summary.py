import pandas as pd
import numpy as np

df = pd.read_csv("SalaryGender.csv")

salary = df["Salary"].to_numpy()
gender = df["Gender"].to_numpy()
age = df["Age"].to_numpy()
phd = df["PhD"].to_numpy()