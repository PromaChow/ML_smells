import math
import torch
import torch.nn as nn
import torch.nn.functional as F
import pytest

# Dummy mixins to satisfy inheritance. In real usage these would provide full training logic.
class _TestBatchTrainingMixin:
    pass

class _BaseTestDQNOnDiscreteABC:
    pass

class _BaseTestDQNOnDiscretePOABC:
    pass

# Mock of chainerrl's components used in the tests
try:
    from chainerrl import nn as ch_nn
    from chainerrl.agents import iqn as ch_iqn
except ImportError:
    # Minimal stubs if chainerrl is not available
    class ch_nn:
        @staticmethod
        def CosineBasisLinear(in_features, out_features, num_basis_functions, bias=True):
            return nn.Sequential(
                nn.Linear(in_features, out_features, bias=bias),
                nn.ReLU()
            )

        @staticmethod
        def NStepRNNTanh(in_features, hidden_size, n_step, bias=True):
            return nn.RNNCell(in_features, hidden_size, bias=bias)

        @staticmethod
        def cosine_basis_functions(x, n_basis_functions):
            batch, m = x.shape
            k = torch.arange(1, n_basis_functions + 1, device=x.device, dtype=x.dtype)
            k = k.view(1, 1, -1)  # (1, 1, n_basis_functions)
            x = x.unsqueeze(-1)  # (batch, m, 1)
            return torch.cos(x * k * math.pi)  # (batch, m, n_basis_functions)

    class ch_iqn:
        class IQNAgent:
            def __init__(self, q_func, optimizer, quantile_thresholds, quantile_thresholds_prime,
                         replay_buffer_size, gamma, replay_start_size,
                         target_update_interval, deterministic=True, recurrent=False):
                self.q_func = q_func
                self.optimizer = optimizer
                self.quantile_thresholds = quantile_thresholds
                self.quantile_thresholds_prime = quantile_thresholds_prime
                self.replay_buffer_size = replay_buffer_size
                self.gamma = gamma
                self.replay_start_size = replay_start_size
                self.target_update_interval = target_update_interval
                self.deterministic = deterministic
                self.recurrent = recurrent

        def IQNAgent(*args, **kwargs):
            return ch_iqn.IQNAgent(*args, **kwargs)


# 1. TestIQNOnDiscreteABC Class
@pytest.mark.parametrize("quantile_thresholds_N", [1, 5])
@pytest.mark.parametrize("quantile_thresholds_N_prime", [1, 7])
class TestIQNOnDiscreteABC(_TestBatchTrainingMixin, _BaseTestDQNOnDiscreteABC):
    action_space_size = 4
    obs_dim = 10

    def make_q_func(self):
        psi = nn.Sequential(
            nn.Linear(self.obs_dim, 32),
            nn.ReLU()
        )
        phi = nn.Sequential(
            ch_nn.CosineBasisLinear(self.obs_dim, 32, 32),
            nn.ReLU()
        )
        final = nn.Linear(32, self.action_space_size)
        return nn.Sequential(
            nn.ModuleList([psi, phi]),
            final
        )

    def make_dqn_agent(self, quantile_thresholds_N, quantile_thresholds_N_prime):
        q_func = self.make_q_func()
        optimizer = torch.optim.Adam(q_func.parameters(), lr=1e-3)
        agent = ch_iqn.IQNAgent(
            q_func=q_func,
            optimizer=optimizer,
            quantile_thresholds=quantile_thresholds_N,
            quantile_thresholds_prime=quantile_thresholds_N_prime,
            replay_buffer_size=1000,
            gamma=0.9,
            replay_start_size=100,
            target_update_interval=100,
            deterministic=True,
            recurrent=False
        )
        return agent

    def test_agent_creation(self, quantile_thresholds_N, quantile_thresholds_N_prime):
        agent = self.make_dqn_agent(quantile_thresholds_N, quantile_thresholds_N_prime)
        assert agent.quantile_thresholds == quantile_thresholds_N
        assert agent.quantile_thresholds_prime == quantile_thresholds_N_prime
        assert agent.deterministic is True
        assert agent.recurrent is False
        # Check that q_func has correct output shape
        dummy_obs = torch.randn(1, self.obs_dim)
        with torch.no_grad():
            q_vals = agent.q_func(dummy_obs)
        assert q_vals.shape == (1, self.action_space_size)


# 2. TestIQNOnDiscretePOABC Class
class TestIQNOnDiscretePOABC(_TestBatchTrainingMixin, _BaseTestDQNOnDiscretePOABC):
    action_space_size = 3
    obs_dim = 8

    def make_q_func(self):
        psi = nn.Sequential(
            nn.Linear(self.obs_dim, 32),
            nn.ReLU(),
            ch_nn.NStepRNNTanh(32, 32, 3)
        )
        phi = nn.Sequential(
            ch_nn.CosineBasisLinear(self.obs_dim, 32, 32),
            nn.ReLU()
        )
        final = nn.Linear(32, self.action_space_size)
        return nn.Sequential(
            nn.ModuleList([psi, phi]),
            final
        )

    def make_dqn_agent(self):
        q_func = self.make_q_func()
        optimizer = torch.optim.Adam(q_func.parameters(), lr=1e-3)
        agent = ch_iqn.IQNAgent(
            q_func=q_func,
            optimizer=optimizer,
            quantile_thresholds=32,
            quantile_thresholds_prime=32,
            replay_buffer_size=1000,
            gamma=0.9,
            replay_start_size=100,
            target_update_interval=100,
            deterministic=True,
            recurrent=True
        )
        return agent

    def test_agent_creation(self):
        agent = self.make_dqn_agent()
        assert agent.recurrent is True
        assert agent.quantile_thresholds == 32
        assert agent.quantile_thresholds_prime == 32
        dummy_obs = torch.randn(1, self.obs_dim)
        with torch.no_grad():
            q_vals = agent.q_func(dummy_obs)
        assert q_vals.shape == (1, self.action_space_size)


# 3. TestComputeEltwiseHuberQuantileLoss Class
@pytest.mark.parametrize("batch_size", [1, 3])
@pytest.mark.parametrize("N", [1, 5])
@pytest.mark.parametrize("N_prime", [1, 7])
@pytest.mark.parametrize("huber_loss_threshold", [0.5, 1.0])
def test_compute_eltwise_huber_quantile_loss(batch_size, N, N_prime, huber_loss_threshold):
    # Create random tensors
    y = torch.randn(batch_size, N, requires_grad=True)
    t = torch.randn(batch_size, N_prime)
    tau = torch.rand(batch_size, N)

    # Compute loss using the function under test
    def compute_eltwise_huber_quantile_loss(y, t, tau, huber_threshold):
        # y: (B, N), t: (B, N'), tau: (B, N)
        # Expand dimensions for broadcasting
        y_exp = y.unsqueeze(-1)  # (B, N, 1)
        t_exp = t.unsqueeze(1)   # (B, 1, N')
        tau_exp = tau.unsqueeze(-1)  # (B, N, 1)

        diff = y_exp - t_exp  # (B, N, N')
        abs_diff = diff.abs()
        huber = torch.where(
            abs_diff <= huber_threshold,
            0.5 * diff * diff,
            huber_threshold * (abs_diff - 0.5 * huber_threshold)
        )  # (B, N, N')

        penalty = torch.where(
            diff > 0,
            tau_exp,
            1 - tau_exp
        )  # (B, N, N')

        loss = penalty * huber
        return loss

    loss = compute_eltwise_huber_quantile_loss(y, t, tau, huber_loss_threshold)
    assert loss.shape == (batch_size, N, N_prime)

    # Expected loss computation for verification
    y_exp = y.unsqueeze(-1)
    t_exp = t.unsqueeze(1)
    tau_exp = tau.unsqueeze(-1)
    diff = y_exp - t_exp
    abs_diff = diff.abs()
    huber_expected = torch.where(
        abs_diff <= huber_loss_threshold,
        0.5 * diff * diff,
        huber_loss_threshold * (abs_diff - 0.5 * huber_loss_threshold)
    )
    penalty_expected = torch.where(
        diff > 0,
        tau_exp,
        1 - tau_exp
    )
    loss_expected = penalty_expected * huber_expected
    torch.testing.assert_allclose(loss, loss_expected, rtol=1e-5, atol=1e-5)

    # Gradient check
    loss.sum().backward()
    # Compute expected gradient manually
    grad_expected = torch.zeros_like(y)
    for b in range(batch_size):
        for n in range(N):
            for np_ in range(N_prime):
                diff_val = y[b, n] - t[b, np_]
                if abs(diff_val) <= huber_loss_threshold:
                    grad_term = diff_val
                else:
                    grad_term = huber_loss_threshold * torch.sign(diff_val)
                penalty = tau[b, n] if diff_val > 0 else (1 - tau[b, n])
                grad_expected[b, n] += penalty * grad_term
    torch.testing.assert_allclose(y.grad, grad_expected, rtol=1e-5, atol=1e-5)


# 4. TestCosineBasisFunctions Class
@pytest.mark.parametrize("batch_size", [1, 3])
@pytest.mark.parametrize("m", [1, 5])
@pytest.mark.parametrize("n_basis_functions", [1, 7])
def test_cosine_basis_functions(batch_size, m, n_basis_functions):
    x = torch.randn(batch_size, m)
    y = ch_nn.cosine_basis_functions(x, n_basis_functions)
    assert y.shape == (batch_size, m, n_basis_functions)
    # Verify each element matches the formula
    for i in range(batch_size):
        for j in range(m):
            for k in range(n_basis_functions):
                expected = math.cos(x[i, j].item() * (k + 1) * math.pi)
                torch.testing.assert_allclose(y[i, j, k], expected, rtol=1e-5, atol=1e-5)