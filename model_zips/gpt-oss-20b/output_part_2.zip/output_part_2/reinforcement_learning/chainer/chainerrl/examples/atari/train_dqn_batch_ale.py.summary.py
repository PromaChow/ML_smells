import argparse
import os
import logging
import random
import numpy as np

import gym
import chainer
import chainer.functions as F
import chainer.links as L
from chainer import Variable
import chainerrl
from chainerrl import replay_buffer, explorer, agent, eval, function, wrappers, utils
from chainerrl.links import noised
from chainerrl.contrib import atari_wrappers
from chainerrl.contrib.atari_wrappers import frame_stack, make_vector_env
from chainerrl.agents import DoubleDQN, DQN, PAL
from chainerrl.replay_buffer import ReplayBuffer, PrioritizedReplayBuffer
from chainerrl.explorers import LinearSchedule, UniformRandomActionSelector
from chainerrl.eval import eval_performance
from chainerrl.utils import draw_graph

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--env', default='BreakoutNoFrameskip-v4')
    parser.add_argument('--output', default='output')
    parser.add_argument('--seed', type=int, default=1)
    parser.add_argument('--gpu', type=int, default=-1)
    parser.add_argument('--final_epsilon', type=float, default=0.01)
    parser.add_argument('--final_exploration_frames', type=int, default=10**6)
    parser.add_argument('--arch', choices=['doubledqn', 'nature', 'nips', 'dueling'],
                        default='doubledqn')
    parser.add_argument('--steps', type=int, default=5*10**7)
    parser.add_argument('--replay_size', type=int, default=10**6)
    parser.add_argument('--agent', choices=['DoubleDQN', 'DQN', 'PAL'],
                        default='DoubleDQN')
    parser.add_argument('--lr', type=float, default=2.5e-4)
    parser.add_argument('--prioritized', action='store_true')
    parser.add_argument('--render', action='store_true')
    parser.add_argument('--demo', action='store_true')
    parser.add_argument('--eval_n_runs', type=int, default=10)
    parser.add_argument('--load', default='')
    parser.add_argument('--noisy_net_sigma', type=float, default=0.5)
    parser.add_argument('--n_steps', type=int, default=1)
    parser.add_argument('--eval_interval', type=int, default=10**5)
    return parser.parse_args()

def set_seed(seed, gpu):
    random.seed(seed)
    np.random.seed(seed)
    chainer.set_random_state(seed)
    if gpu >= 0:
        chainer.backends.cuda.cupy.random.seed(seed)

def make_env(env_name, seed, is_train=True):
    def _thunk():
        env = gym.make(env_name)
        env = atari_wrappers.wrap_deepmind(env, frame_stack=True, clip_rewards=True)
        env.seed(seed)
        return env
    return _thunk

def make_batch_env(env_name, num_envs, seed, render=False):
    envs = [make_env(env_name, seed + i) for i in range(num_envs)]
    env = make_vector_env(envs, num_envs, 1, num_processes=num_envs)
    if render:
        env = wrappers.Render(env)
    return env

def create_q_func(obs_shape, n_actions, arch, noisy_sigma):
    if arch == 'nature':
        conv = L.Convolution2D(4, 32, 8, stride=4)
        conv2 = L.Convolution2D(32, 64, 4, stride=2)
        conv3 = L.Convolution2D(64, 64, 3, stride=1)
        fc = L.Linear(7 * 7 * 64, 512)
        out = L.Linear(512, n_actions)
    elif arch == 'doubledqn':
        conv = L.Convolution2D(4, 32, 8, stride=4)
        conv2 = L.Convolution2D(32, 64, 4, stride=2)
        conv3 = L.Convolution2D(64, 64, 3, stride=1)
        fc = L.Linear(7 * 7 * 64, 512)
        out = L.Linear(512, n_actions, nobias=True)
    elif arch == 'nips':
        conv = L.Convolution2D(4, 32, 8, stride=4)
        conv2 = L.Convolution2D(32, 64, 4, stride=2)
        conv3 = L.Convolution2D(64, 64, 3, stride=1)
        fc = L.Linear(7 * 7 * 64, 512)
        out = L.Linear(512, n_actions)
    elif arch == 'dueling':
        conv = L.Convolution2D(4, 32, 8, stride=4)
        conv2 = L.Convolution2D(32, 64, 4, stride=2)
        conv3 = L.Convolution2D(64, 64, 3, stride=1)
        fc = L.Linear(7 * 7 * 64, 512)
        val = L.Linear(512, 1)
        adv = L.Linear(512, n_actions)
        out = None  # placeholder
    else:
        raise ValueError('Unknown architecture')

    class QFunction(chainer.Chain):
        def __init__(self):
            super().__init__()
            with self.init_scope():
                self.conv = conv
                self.conv2 = conv2
                self.conv3 = conv3
                self.fc = fc
                if arch == 'dueling':
                    self.val = val
                    self.adv = adv
                else:
                    self.out = out

        def __call__(self, x):
            h = F.relu(self.conv(x))
            h = F.relu(self.conv2(h))
            h = F.relu(self.conv3(h))
            h = F.reshape(h, (h.shape[0], -1))
            h = F.relu(self.fc(h))
            if arch == 'dueling':
                val = self.val(h)
                adv = self.adv(h)
                q = val + (adv - F.mean(adv, axis=1, keepdims=True))
                return q
            else:
                return self.out(h)

    q_func = QFunction()
    if noisy_sigma > 0:
        q_func = noised.to_factorized_noisy(q_func, sigma=noisy_sigma)
    return q_func

def main():
    args = parse_args()
    os.makedirs(args.output, exist_ok=True)
    logging.basicConfig(level=logging.INFO)
    set_seed(args.seed, args.gpu)

    if args.gpu >= 0:
        chainer.backends.cuda.get_device_from_id(args.gpu).use()
        chainer.cuda.cupy.random.seed(args.seed)

    env_name = args.env
    test_env = make_env(env_name, args.seed + 1000, False)()
    n_actions = test_env.action_space.n
    obs_shape = test_env.observation_space.shape

    q_func = create_q_func(obs_shape, n_actions, args.arch, args.noisy_net_sigma)
    if args.gpu >= 0:
        q_func.to_gpu()

    graph_path = os.path.join(args.output, 'q_func.png')
    draw_graph(q_func, graph_path)

    optimizer = chainer.optimizers.RMSpropGRAD(lr=args.lr, alpha=0.95, momentum=0.0, eps=1e-2)
    optimizer.setup(q_func)

    if args.prioritized:
        buffer = PrioritizedReplayBuffer(
            capacity=args.replay_size,
            alpha=0.6,
            beta0=0.4,
            beta_schedule=utils.linear_schedule(
                start_value=0.4,
                end_value=1.0,
                nsteps=args.steps,
            ),
            n_step=args.n_steps,
        )
    else:
        buffer = ReplayBuffer(
            capacity=args.replay_size,
            n_step=args.n_steps,
        )

    explorer_obj = explorer.LinearSchedule(
        start_value=1.0,
        end_value=args.final_epsilon,
        decay_steps=args.final_exploration_frames,
        selector=UniformRandomActionSelector(n_actions)
    )

    if args.agent == 'DoubleDQN':
        agt = DoubleDQN(
            q_func,
            optimizer,
            buffer,
            gamma=0.99,
            target_update_interval=3 * 10**4,
            replay_start_size=5 * 10**4,
            clip_delta=True,
            update_interval=4,
            phi=utils.normalizer_by_255,
        )
    elif args.agent == 'DQN':
        agt = DQN(
            q_func,
            optimizer,
            buffer,
            gamma=0.99,
            target_update_interval=3 * 10**4,
            replay_start_size=5 * 10**4,
            clip_delta=True,
            update_interval=4,
            phi=utils.normalizer_by_255,
        )
    elif args.agent == 'PAL':
        agt = PAL(
            q_func,
            optimizer,
            buffer,
            gamma=0.99,
            target_update_interval=3 * 10**4,
            replay_start_size=5 * 10**4,
            clip_delta=True,
            update_interval=4,
            phi=utils.normalizer_by_255,
        )
    else:
        raise ValueError('Unknown agent type')

    if args.load:
        chainer.serializers.load_npz(args.load, agt)

    if args.demo:
        mean, std, median = eval_performance(
            agent=agt,
            env=test_env,
            n_runs=args.eval_n_runs,
            explorer=explorer_obj,
        )
        logging.info(f'Demo results: mean={mean:.2f}, median={median:.2f}, std={std:.2f}')
        return

    n_train_envs = 8
    train_env = make_batch_env(env_name, n_train_envs, args.seed, render=args.render)
    eval_env = make_env(env_name, args.seed + 2000, False)()

    train_agent_batch_with_evaluation(
        agent=agt,
        env=train_env,
        n_steps=args.steps,
        eval_n_steps=args.eval_interval,
        eval_env=eval_env,
        explorer=explorer_obj,
        log_interval=1000,
        output_dir=args.output,
    )

def train_agent_batch_with_evaluation(agent, env, n_steps, eval_n_steps, eval_env, explorer,
                                      log_interval=1000, output_dir='output'):
    step = 0
    eval_step = 0
    while step < n_steps:
        agent.update(env, explorer, n_steps=eval_n_steps)
        step += eval_n_steps
        if step % eval_n_steps == 0:
            mean, std, median = eval_performance(
                agent=agent,
                env=eval_env,
                n_runs=10,
                explorer=explorer,
            )
            logging.info(f'Step {step}: mean={mean:.2f}, median={median:.2f}, std={std:.2f}')
            result_path = os.path.join(output_dir, f'eval_{step}.npz')
            np.savez(result_path, mean=mean, std=std, median=median)

if __name__ == '__main__':
    main()
