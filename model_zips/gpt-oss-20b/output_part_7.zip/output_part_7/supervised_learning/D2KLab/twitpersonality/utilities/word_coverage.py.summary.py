import numpy as np
from sklearn.feature_extraction.text import CountVectorizer
from gensim.models import KeyedVectors
import datasetUtils as dsu

# Load the training data
data, y_O, y_C, *_ = dsu.readMyPersonality()

# Configure text processing
vectorizer = CountVectorizer(stop_words='english', analyzer='word')
analyzer = vectorizer.build_analyzer()

# Load pre-trained FastText embeddings
wordDictionary = dsu.parseFastText("../FastText/dataset.vec")

def countWords(embeddings_dataset: KeyedVectors):
    tot_words = 0
    found_words = 0
    for doc in data:
        words = analyzer(doc)
        if not words:
            continue
        for word in words:
            tot_words += 1
            if word in embeddings_dataset:
                found_words += 1
    return tot_words, found_words

# Compute word coverage metrics
tot_words, hits = countWords(wordDictionary)
coverage = (hits / tot_words) * 100 if tot_words else 0

print(f"Total number of words: {tot_words}")
print(f"Number of words found in the embeddings: {hits}")
print(f"Word coverage percentage: {coverage:.2f}%")