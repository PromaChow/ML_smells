import random
import numpy as np

class Environment:
    def __init__(self):
        self.player_sum = None
        self.dealer_card = None
        self.deck_values = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        self.deck_weights = [4] * 10

    def reset(self):
        self.player_sum = random.randint(12, 21)
        self.dealer_card = random.randint(1, 10)
        return (self.player_sum, self.dealer_card)

    def draw_card(self):
        return random.choices(self.deck_values, weights=self.deck_weights, k=1)[0]

    def step(self, action):
        if action == 1:  # hit
            self.player_sum += self.draw_card()
            if self.player_sum > 21:
                return (self.player_sum, self.dealer_card), -1, True
            else:
                return (self.player_sum, self.dealer_card), 0, False
        else:  # stick
            dealer_sum = self.dealer_card
            while dealer_sum < 17:
                dealer_sum += self.draw_card()
            if dealer_sum > 21:
                return (self.player_sum, self.dealer_card), 1, True
            if self.player_sum > dealer_sum:
                return (self.player_sum, self.dealer_card), 1, True
            if self.player_sum == dealer_sum:
                return (self.player_sum, self.dealer_card), 0, True
            return (self.player_sum, self.dealer_card), -1, True


class Agent:
    def __init__(self):
        self.Q = np.zeros((10, 10, 2))
        self.returns_sum = np.zeros((10, 10, 2))
        self.returns_visits = np.zeros((10, 10, 2))
        self.policy = np.zeros((10, 10), dtype=int)

    def state_index(self, state):
        s_player, s_dealer = state
        return s_player - 12, s_dealer - 1

    def get_action(self, state, force_random=False):
        i, j = self.state_index(state)
        if force_random:
            return random.randint(0, 1)
        return self.policy[i, j]

    def update(self, episode_memory):
        visited_pairs = set()
        final_reward = episode_memory[-1][3]
        for idx, (state, action, _, _) in enumerate(episode_memory):
            if (state, action) in visited_pairs:
                continue
            visited_pairs.add((state, action))
            i, j = self.state_index(state)
            self.returns_sum[i, j, action] += final_reward
            self.returns_visits[i, j, action] += 1
            self.Q[i, j, action] = self.returns_sum[i, j, action] / self.returns_visits[i, j, action]
        # update policy greedily
        self.policy = np.argmax(self.Q, axis=2)


def print_policy(policy):
    action_map = {0: 'S', 1: 'H'}
    for i in range(10):
        row = []
        for j in range(10):
            row.append(action_map[policy[i, j]])
        print(' '.join(row))
    print()


def main():
    env = Environment()
    agent = Agent()
    num_episodes = 5_000_000
    print_interval = num_episodes // 100

    for episode in range(1, num_episodes + 1):
        state = env.reset()
        memory = []
        done = False
        # first step exploring starts
        action = agent.get_action(state, force_random=True)
        next_state, reward, done = env.step(action)
        memory.append((state, action, next_state, reward, done))
        state = next_state

        while not done:
            action = agent.get_action(state, force_random=False)
            next_state, reward, done = env.step(action)
            memory.append((state, action, next_state, reward, done))
            state = next_state

        agent.update(memory)

        if episode % print_interval == 0:
            print(f"Episode {episode}")
            print_policy(agent.policy)

if __name__ == "__main__":
    main()
