import numpy as np
from gym import spaces


def flatdim(space: spaces.Space) -> int:
    if isinstance(space, spaces.Box) or isinstance(space, spaces.MultiDiscrete):
        return int(np.prod(space.shape))
    if isinstance(space, spaces.Discrete):
        return space.n
    if isinstance(space, spaces.Tuple):
        return sum(flatdim(sub) for sub in space.spaces)
    if isinstance(space, spaces.Dict):
        return sum(flatdim(sub) for sub in space.spaces.values())
    if isinstance(space, spaces.MultiBinary):
        return space.n
    raise NotImplementedError(f"Unsupported space type: {type(space).__name__}")


def flatten(space: spaces.Space, x):
    if isinstance(space, spaces.Box):
        return np.array(x).flatten()
    if isinstance(space, spaces.Discrete):
        vec = np.zeros(space.n, dtype=int)
        vec[x] = 1
        return vec
    if isinstance(space, spaces.Tuple):
        parts = [flatten(sub, xi) for sub, xi in zip(space.spaces, x)]
        return np.concatenate(parts)
    if isinstance(space, spaces.Dict):
        parts = [flatten(sub, xi) for sub, xi in zip(space.spaces.values(), x.values())]
        return np.concatenate(parts)
    if isinstance(space, (spaces.MultiBinary, spaces.MultiDiscrete)):
        return np.array(x).flatten()
    raise NotImplementedError(f"Unsupported space type: {type(space).__name__}")


def unflatten(space: spaces.Space, x: np.ndarray):
    if isinstance(space, spaces.Box):
        return x.reshape(space.shape)
    if isinstance(space, spaces.Discrete):
        return int(np.argmax(x))
    if isinstance(space, spaces.Tuple):
        segments = []
        idx = 0
        for sub in space.spaces:
            sz = flatdim(sub)
            seg = x[idx : idx + sz]
            segments.append(unflatten(sub, seg))
            idx += sz
        return tuple(segments)
    if isinstance(space, spaces.Dict):
        result = {}
        idx = 0
        for key, sub in space.spaces.items():
            sz = flatdim(sub)
            seg = x[idx : idx + sz]
            result[key] = unflatten(sub, seg)
            idx += sz
        return result
    if isinstance(space, (spaces.MultiBinary, spaces.MultiDiscrete)):
        return x.reshape(space.shape)
    raise NotImplementedError(f"Unsupported space type: {type(space).__name__}")


def test_space_utils():
    # Box space test
    box1 = spaces.Box(low=-1, high=1, shape=(2, 3), dtype=np.float32)
    sample1 = box1.sample()
    assert flatdim(box1) == 6
    flat1 = flatten(box1, sample1)
    assert flat1.shape == (6,)
    rec1 = unflatten(box1, flat1)
    assert np.allclose(rec1, sample1)

    # Box defined by matrix
    x_mat = np.array([[0, 1, 2], [3, 4, 5]], dtype=np.float32)
    box2 = spaces.Box(low=x_mat, high=x_mat, dtype=np.float32)
    sample2 = box2.sample()
    assert flatdim(box2) == 6
    flat2 = flatten(box2, sample2)
    assert flat2.shape == (6,)
    rec2 = unflatten(box2, flat2)
    assert np.allclose(rec2, sample2)

    # Discrete space test
    disc = spaces.Discrete(5)
    sample3 = disc.sample()
    assert flatdim(disc) == 5
    flat3 = flatten(disc, sample3)
    assert flat3.shape == (5,)
    rec3 = unflatten(disc, flat3)
    assert rec3 == sample3

    # Tuple space test
    dict_sub = spaces.Dict({"a": spaces.Box(low=0, high=1, shape=(2,), dtype=np.float32),
                            "b": spaces.Discrete(3)})
    tuple_space = spaces.Tuple((disc, box1, dict_sub))
    sample4 = tuple_space.sample()
    expected_dim = flatdim(disc) + flatdim(box1) + flatdim(dict_sub)  # 5 + 6 + 5 = 16
    assert flatdim(tuple_space) == expected_dim
    flat4 = flatten(tuple_space, sample4)
    assert flat4.shape == (expected_dim,)
    rec4 = unflatten(tuple_space, flat4)
    # Compare each component
    assert rec4[0] == sample4[0]
    assert np.allclose(rec4[1], sample4[1])
    assert rec4[2] == sample4[2]

    # Dict space test
    dict_space = spaces.Dict({
        "x": spaces.Box(low=0, high=1, shape=(3,), dtype=np.float32),
        "y": spaces.Discrete(4),
        "z": spaces.Box(low=-1, high=1, shape=(100,), dtype=np.float32)
    })
    sample5 = dict_space.sample()
    expected_dim_dict = flatdim(dict_space)  # 3 + 4 + 100 = 107
    assert expected_dim_dict == 107
    flat5 = flatten(dict_space, sample5)
    assert flat5.shape == (107,)
    rec5 = unflatten(dict_space, flat5)
    assert np.allclose(rec5["x"], sample5["x"])
    assert rec5["y"] == sample5["y"]
    assert np.allclose(rec5["z"], sample5["z"])

    print("All tests passed.")


if __name__ == "__main__":
    test_space_utils()
