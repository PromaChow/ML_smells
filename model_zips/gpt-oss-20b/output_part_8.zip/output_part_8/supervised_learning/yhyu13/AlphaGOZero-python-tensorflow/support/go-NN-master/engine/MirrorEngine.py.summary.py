import sys
import numpy as np

# Mapping for GTP coordinates, skipping the letter 'I'
LETTER_TO_INDEX = {chr(ord('A') + i + (1 if i >= 8 else 0)): i for i in range(19)}

def gtp_to_xy(coord: str, size: int):
    """Convert GTP coordinate to (x, y) zero-based indices."""
    if coord.lower() == "pass":
        return None
    if len(coord) < 2:
        return None
    col_letter = coord[0].upper()
    row_str = coord[1:]
    if col_letter not in LETTER_TO_INDEX:
        return None
    col = LETTER_TO_INDEX[col_letter]
    try:
        row = int(row_str) - 1
    except ValueError:
        return None
    if not (0 <= col < size and 0 <= row < size):
        return None
    # In GTP, row 1 is at the bottom; convert to 0-based from top
    y = size - 1 - row
    return (col, y)

def xy_to_gtp(x: int, y: int, size: int):
    """Convert (x, y) zero-based indices to GTP coordinate."""
    # Convert back to GTP numbering
    row = size - y
    # Skip 'I' when mapping
    if x >= 8:
        col_letter = chr(ord('A') + x + 1)
    else:
        col_letter = chr(ord('A') + x)
    return f"{col_letter}{row}"

class MirrorEngine:
    def __init__(self, board_size: int):
        self.N = board_size
        self.last_opponent_play = None
        self.board = np.zeros((self.N, self.N), dtype=int)  # 0 empty, 1 opponent, 2 us

    def stone_played(self, x: int, y: int):
        self.last_opponent_play = (x, y)
        self.board[y, x] = 1

    def pick_move(self):
        N = self.N
        board = self.board

        # Step 1: Mirror opponent's last move
        if self.last_opponent_play is not None:
            x, y = self.last_opponent_play
            mirror_x = N - x - 1
            mirror_y = N - y - 1
            if 0 <= mirror_x < N and 0 <= mirror_y < N:
                if board[mirror_y, mirror_x] == 0:
                    return (mirror_x, mirror_y)

        # Step 2: Find symmetric positions relative to enemy stones
        enemy_mask = (board == 1)
        our_mask = (board == 2)
        rotated_enemy = np.rot90(np.rot90(enemy_mask))
        # Positions where rotated enemy is true and empty
        candidate_mask = rotated_enemy & (board == 0)
        if np.any(candidate_mask):
            y_indices, x_indices = np.where(candidate_mask)
            for y, x in zip(y_indices, x_indices):
                return (x, y)

        # Step 3: Fallback to center move
        center = N // 2
        if board[center, center] == 0:
            return (center, center)

        # Step 4: Default action (pass)
        return None

    def play_move(self, move):
        if move is None:
            return
        x, y = move
        self.board[y, x] = 2

def main():
    board_size = 19
    engine = MirrorEngine(board_size)

    # Redirect stdout to a log file
    log_file = open("mirror_engine.log", "w")
    sys.stdout = log_file

    print("OK")

    while True:
        line = sys.stdin.readline()
        if not line:
            break
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        parts = line.split()
        cmd = parts[0].lower()
        args = parts[1:]

        if cmd == "quit":
            print("OK")
            break
        elif cmd == "name":
            print("OK MirrorEngine")
        elif cmd == "protocol_version":
            print("OK 2")
        elif cmd == "known_command":
            known = {"play", "genmove", "quit", "name", "protocol_version", "known_command", "showboard"}
            print(f"OK {args[0] if args and args[0] in known else 'false'}")
        elif cmd == "play":
            if len(args) < 2:
                print("ERROR: play requires color and coordinate")
                continue
            color, coord = args[0], args[1]
            xy = gtp_to_xy(coord, board_size)
            if xy is None:
                print("ERROR: invalid coordinate")
                continue
            engine.stone_played(*xy)
            print("OK")
        elif cmd == "genmove":
            move = engine.pick_move()
            if move is None:
                print("OK pass")
            else:
                engine.play_move(move)
                coord = xy_to_gtp(*move, board_size)
                print(f"OK {coord}")
        elif cmd == "showboard":
            # Simple ASCII board
            for y in range(board_size):
                line_str = ""
                for x in range(board_size):
                    val = engine.board[y, x]
                    if val == 0:
                        line_str += ". "
                    elif val == 1:
                        line_str += "X "
                    else:
                        line_str += "O "
                print(f"OK {line_str.strip()}")
        else:
            print(f"ERROR unknown command {cmd}")

    log_file.close()

if __name__ == "__main__":
    main()
