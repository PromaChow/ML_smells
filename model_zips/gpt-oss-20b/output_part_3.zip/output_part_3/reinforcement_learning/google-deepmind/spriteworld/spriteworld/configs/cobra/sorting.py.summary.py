import random
import itertools
from dataclasses import dataclass, field
from typing import List, Tuple, Dict, Callable

# Placeholder common module with minimal implementation
class common:
    @staticmethod
    def action_space():
        return "DiscreteActionSpace"

    @staticmethod
    def renderers():
        return {"renderer": "SimpleRenderer"}

# Data structures for sprites and subtasks
@dataclass
class Sprite:
    color: Dict[str, float]
    shape: str
    position: Tuple[float, float]
    scale: float = 0.13

@dataclass
class Subtask:
    name: str
    color_range: Dict[str, Tuple[float, float]]
    target_pos: Tuple[float, float]
    generator: Callable[[], Sprite] = field(repr=False)

# MetaAggregated aggregates multiple subtasks
class MetaAggregated:
    def __init__(self, subtasks: List[Subtask], terminate_distance: float):
        self.subtasks = subtasks
        self.terminate_distance = terminate_distance

    def aggregate_rewards(self, individual_rewards: List[float]) -> float:
        return sum(individual_rewards)

    def is_terminated(self, agent_pos: Tuple[float, float]) -> bool:
        return all(
            self.distance(agent_pos, sub.target_pos) <= self.terminate_distance
            for sub in self.subtasks
        )

    @staticmethod
    def distance(a: Tuple[float, float], b: Tuple[float, float]) -> float:
        return ((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2) ** 0.5

# Task parameters
MAX_EPISODE_LENGTH = 50
TERMINATE_DISTANCE = 0.075
RAW_REWARD_MULTIPLIER = 20
NUM_TARGETS = 2  # one per subtask per episode

# Define subtasks
def create_sprite_generator(color_range: Dict[str, Tuple[float, float]]) -> Callable[[], Sprite]:
    shapes = ["square", "triangle", "circle"]
    def generator() -> Sprite:
        color = {
            ch: random.uniform(lo, hi) if (lo, hi) == color_range[ch]
            else random.uniform(0.0, 1.0)
            for ch, (lo, hi) in color_range.items()
        }
        # Add additional channels c1 and c2 if not specified
        if "c1" not in color:
            color["c1"] = random.uniform(0.0, 1.0)
        if "c2" not in color:
            color["c2"] = random.uniform(0.0, 1.0)
        shape = random.choice(shapes)
        position = (random.uniform(0.1, 0.9), random.uniform(0.1, 0.9))
        return Sprite(color=color, shape=shape, position=position)
    return generator

subtasks = [
    Subtask(
        name="red",
        color_range={"c0": (0.9, 1.0)},
        target_pos=(0.75, 0.75),
        generator=create_sprite_generator({"c0": (0.9, 1.0)}),
    ),
    Subtask(
        name="blue",
        color_range={"c0": (0.0, 0.1)},
        target_pos=(0.25, 0.75),
        generator=create_sprite_generator({"c0": (0.0, 0.1)}),
    ),
    Subtask(
        name="green",
        color_range={"c0": (0.4, 0.6)},
        target_pos=(0.75, 0.25),
        generator=create_sprite_generator({"c0": (0.4, 0.6)}),
    ),
    Subtask(
        name="purple",
        color_range={"c0": (0.8, 0.9)},
        target_pos=(0.25, 0.25),
        generator=create_sprite_generator({"c0": (0.8, 0.9)}),
    ),
    Subtask(
        name="yellow",
        color_range={"c0": (0.7, 0.8)},
        target_pos=(0.5, 0.5),
        generator=create_sprite_generator({"c0": (0.7, 0.8)}),
    ),
]

# All combinations of two subtasks
subtask_combinations = list(itertools.combinations(subtasks, 2))

def generate_sprites_for_combination(combination: Tuple[Subtask, Subtask]) -> List[Sprite]:
    sprites = []
    for subtask in combination:
        sprite = subtask.generator()
        sprite.position = subtask.target_pos  # Place sprite at its target position
        sprites.append(sprite)
    return sprites

def create_environment_config(mode: str, excluded_combo: Tuple[Subtask, Subtask]) -> Dict:
    # Select combinations to include
    if mode == "train":
        combos = [c for c in subtask_combinations if c != excluded_combo]
    else:  # test
        combos = [excluded_combo]

    # Generate sprites
    all_sprites = []
    for combo in combos:
        all_sprites.extend(generate_sprites_for_combination(combo))

    random.shuffle(all_sprites)  # Shuffle to avoid bias

    # Aggregate subtasks for reward and termination
    aggregated_task = MetaAggregated(
        subtasks=[c[0] for c in combos] + [c[1] for c in combos],
        terminate_distance=TERMINATE_DISTANCE,
    )

    config = {
        "task": aggregated_task,
        "action_space": common.action_space(),
        "renderers": common.renderers(),
        "initial_sprites": all_sprites,
        "episode_length": MAX_EPISODE_LENGTH,
        "metadata": {"file_name": "sprite_sorting_env.py", "mode": mode},
    }
    return config

# Example usage
if __name__ == "__main__":
    # Randomly pick an excluded combination for training
    excluded = random.choice(subtask_combinations)

    train_config = create_environment_config("train", excluded)
    test_config = create_environment_config("test", excluded)

    # The configs can now be used to instantiate environments
    print("Training configuration:")
    print(train_config)
    print("\nTesting configuration:")
    print(test_config)