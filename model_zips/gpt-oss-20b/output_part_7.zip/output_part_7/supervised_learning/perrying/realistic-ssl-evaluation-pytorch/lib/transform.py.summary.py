import random
import torch
import torch.nn.functional as F

class Augmentation:
    def __init__(self, flip=False, r_crop=False, g_noise=False):
        self.flip = flip
        self.r_crop = r_crop
        self.g_noise = g_noise
        print(f"flip={flip}, r_crop={r_crop}, g_noise={g_noise}")

    def __call__(self, x):
        if self.flip and random.random() > 0.5:
            x = torch.flip(x, dims=(-1,))

        if self.r_crop:
            padded = F.pad(x, pad=(2, 2, 2, 2), mode='reflect')
            h, w = x.shape[-2], x.shape[-1]
            l = random.randint(0, 4)
            t = random.randint(0, 4)
            x = padded[..., t:t+h, l:l+w]

        if self.g_noise:
            noise = torch.randn_like(x) * 0.15
            x = x + noise

        return x