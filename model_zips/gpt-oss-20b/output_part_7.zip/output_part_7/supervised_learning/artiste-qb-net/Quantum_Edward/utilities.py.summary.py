import numpy as np
import numpy.random as npr
import scipy.special as sp
import scipy.stats as st

def bin_vec_to_dec(bin_vec: np.ndarray) -> np.ndarray:
    """
    Convert a binary vector or matrix to its decimal representation.

    Parameters
    ----------
    bin_vec : np.ndarray
        Binary array of 0s and 1s. Can be 1-D or 2-D.

    Returns
    -------
    np.ndarray
        Decimal representation as integer(s).
    """
    bin_vec = np.asarray(bin_vec, dtype=int)
    if bin_vec.ndim == 1:
        weights = 2 ** np.arange(bin_vec.shape[0] - 1, -1, -1)
        return int(np.dot(bin_vec, weights))
    elif bin_vec.ndim == 2:
        weights = 2 ** np.arange(bin_vec.shape[1] - 1, -1, -1)
        return np.dot(bin_vec, weights)
    else:
        raise ValueError("bin_vec must be 1-D or 2-D array of 0s and 1s.")


def dec_to_bin_vec(dec: np.ndarray, size: int) -> np.ndarray:
    """
    Convert decimal number(s) to binary vector(s) of specified bit width.

    Parameters
    ----------
    dec : int or np.ndarray
        Decimal value(s).
    size : int
        Number of bits for the binary representation.

    Returns
    -------
    np.ndarray
        Binary vector(s) of shape (size,) or (m, size).
    """
    dec_arr = np.asarray(dec, dtype=np.int64)
    max_val = 2 ** size
    if np.any(dec_arr >= max_val) or np.any(dec_arr < 0):
        raise ValueError(f"Decimal value out of range for {size} bits.")
    if dec_arr.ndim == 0:
        dec_arr = dec_arr.reshape(1)
    bits = ((dec_arr[:, None] >> np.arange(size - 1, -1, -1)) & 1).astype(int)
    if bits.shape[0] == 1:
        return bits[0]
    return bits


def ang_to_cs2_prob(angle: np.ndarray, use_sin: bool = True) -> np.ndarray:
    """
    Return the square of sine or cosine of the given angle(s).

    Parameters
    ----------
    angle : array_like
        Angle(s) in radians.
    use_sin : bool, optional
        If True use sine; otherwise use cosine.

    Returns
    -------
    np.ndarray
        Square of sine or cosine.
    """
    angle = np.asarray(angle)
    if use_sin:
        return np.sin(angle) ** 2
    return np.cos(angle) ** 2


def log_beta_prob(x: np.ndarray, conc0: float, conc1: float) -> np.ndarray:
    """
    Compute log probability of x under a Beta distribution.

    Parameters
    ----------
    x : array_like
        Observation(s) in (0, 1).
    conc0 : float
        First concentration parameter.
    conc1 : float
        Second concentration parameter.

    Returns
    -------
    np.ndarray
        Log probability values.
    """
    eps = 1e-12
    x = np.asarray(x, dtype=float)
    x_clipped = np.clip(x, eps, 1 - eps)
    pdf = st.beta.pdf(x_clipped, conc0, conc1)
    return np.log(pdf)


def grad_log_beta_prob(x: np.ndarray, conc0: float, conc1: float):
    """
    Gradient of log Beta probability w.r.t conc0 and conc1.

    Parameters
    ----------
    x : array_like
        Observation(s) in (0, 1).
    conc0 : float
        First concentration parameter.
    conc1 : float
        Second concentration parameter.

    Returns
    -------
    tuple of np.ndarray
        Gradients (grad_conc0, grad_conc1) with respect to conc0 and conc1.
    """
    x = np.asarray(x, dtype=float)
    eps = 1e-12
    x_clipped = np.clip(x, eps, 1 - eps)
    dig_a = sp.digamma(conc0)
    dig_b = sp.digamma(conc1)
    dig_ab = sp.digamma(conc0 + conc1)
    log_x = np.log(x_clipped)
    log_one_minus_x = np.log(1 - x_clipped)
    grad_conc0 = dig_ab - dig_a + log_x
    grad_conc1 = dig_ab - dig_b + log_one_minus_x
    return grad_conc0, grad_conc1


def log_bern_prob(x: np.ndarray, prob1: float) -> np.ndarray:
    """
    Compute log probability of Bernoulli observations.

    Parameters
    ----------
    x : array_like
        Binary observations (0 or 1).
    prob1 : float
        Probability of observing 1.

    Returns
    -------
    np.ndarray
        Log probability values.
    """
    eps = 1e-12
    prob1 = np.clip(prob1, eps, 1 - eps)
    x = np.asarray(x, dtype=int)
    pmf = st.bernoulli.pmf(x, prob1)
    return np.log(pmf)


def av_each_elem_in_array_list(arr_list: list) -> list:
    """
    Compute average of each array in a list.

    Parameters
    ----------
    arr_list : list of np.ndarray
        List of arrays.

    Returns
    -------
    list of float
        Mean of each array.
    """
    return [float(np.mean(arr)) for arr in arr_list]


def get_shapes_of_array_list(arr_list: list) -> list:
    """
    Get shapes of arrays in a list.

    Parameters
    ----------
    arr_list : list of np.ndarray
        List of arrays.

    Returns
    -------
    list of tuple
        Shapes of each array.
    """
    return [arr.shape for arr in arr_list]


def new_uniform_array_list(val: float, shapes: list) -> list:
    """
    Create list of arrays filled with a uniform value.

    Parameters
    ----------
    val : float
        Value to fill.
    shapes : list of tuple
        Shapes of the arrays.

    Returns
    -------
    list of np.ndarray
        Generated arrays.
    """
    return [np.full(shape, val, dtype=float) for shape in shapes]


def new_uniformly_random_array_list(low: float, high: float, shapes: list) -> list:
    """
    Create list of arrays with random values uniformly sampled from [low, high].

    Parameters
    ----------
    low : float
        Lower bound of uniform distribution.
    high : float
        Upper bound of uniform distribution.
    shapes : list of tuple
        Shapes of the arrays.

    Returns
    -------
    list of np.ndarray
        Generated random arrays.
    """
    return [npr.uniform(low, high, size=shape).astype(float) for shape in shapes]


def main():
    # Demonstrate decimal <-> binary conversion
    dec_val = 5
    bits = dec_to_bin_vec(dec_val, size=3)
    print(f"Decimal {dec_val} -> Binary vector: {bits}")
    back = bin_vec_to_dec(bits)
    print(f"Binary vector {bits} -> Decimal: {back}")

    # Multiple samples
    dec_vals = np.array([3, 7, 12])
    bits_multi = dec_to_bin_vec(dec_vals, size=4)
    print(f"Decimal {dec_vals} -> Binary matrix:\n{bits_multi}")
    back_multi = bin_vec_to_dec(bits_multi)
    print(f"Binary matrix -> Decimal: {back_multi}")

    # Invalid case (uncomment to test)
    # dec_to_bin_vec(16, size=4)  # ValueError expected

    # Example of other utilities
    angles = np.array([0, np.pi / 4, np.pi / 2])
    sin2 = ang_to_cs2_prob(angles, use_sin=True)
    cos2 = ang_to_cs2_prob(angles, use_sin=False)
    print(f"sin^2(angles): {sin2}")
    print(f"cos^2(angles): {cos2}")

    x = 0.3
    logp = log_beta_prob(x, 2.0, 5.0)
    print(f"log_beta_pdf({x}) = {logp}")

    grad_conc0, grad_conc1 = grad_log_beta_prob(x, 2.0, 5.0)
    print(f"grad_log_beta_prob gradients: conc0={grad_conc0}, conc1={grad_conc1}")

    bern_logp = log_bern_prob(np.array([0, 1, 1, 0]), 0.7)
    print(f"log_bern_pdf: {bern_logp}")

    arr_list = [np.arange(4), np.ones((2, 2))]
    avs = av_each_elem_in_array_list(arr_list)
    shapes = get_shapes_of_array_list(arr_list)
    print(f"Averages: {avs}")
    print(f"Shapes: {shapes}")

    uniform_arrays = new_uniform_array_list(3.14, shapes)
    print(f"Uniform arrays: {uniform_arrays}")

    random_arrays = new_uniformly_random_array_list(0, 1, shapes)
    print(f"Random arrays: {random_arrays}")


if __name__ == "__main__":
    main()
