import numpy as np
import torch
from lagom.utils import tensorify


class ReplayBuffer:
    def __init__(self, env, capacity: int, device: torch.device):
        self.env = env
        self.capacity = capacity
        self.device = device

        self.obs_dim = self._flatdim(env.observation_space)
        self.act_dim = self._flatdim(env.action_space)

        self.observations = np.zeros((capacity, self.obs_dim), dtype=np.float32)
        self.actions = np.zeros((capacity, self.act_dim), dtype=np.float32)
        self.rewards = np.zeros((capacity, 1), dtype=np.float32)
        self.next_observations = np.zeros((capacity, self.obs_dim), dtype=np.float32)
        self.masks = np.zeros((capacity, 1), dtype=np.float32)

        self.size = 0
        self.pointer = 0

    def __len__(self) -> int:
        return self.size

    def _flatdim(self, space):
        if hasattr(space, "shape"):
            return int(np.prod(space.shape))
        if hasattr(space, "n"):
            return space.n
        raise ValueError("Unsupported space type for flatdim")

    def _add(self, observation, action, reward, next_observation, terminal):
        self.observations[self.pointer] = observation.ravel()
        self.actions[self.pointer] = action.ravel()
        self.rewards[self.pointer] = reward
        self.next_observations[self.pointer] = next_observation.ravel()
        self.masks[self.pointer] = 1.0 - float(terminal)

        self.pointer = (self.pointer + 1) % self.capacity
        self.size = min(self.size + 1, self.capacity)

    def add(self, traj):
        for t in range(1, traj.T + 1):
            observation = traj[t - 1].observation
            action = traj.actions[t - 1]
            reward = traj[t].reward
            next_observation = traj[t].observation
            terminal = traj[t].terminal()
            self._add(observation, action, reward, next_observation, terminal)

    def sample(self, batch_size: int):
        if self.size == 0:
            raise ValueError("ReplayBuffer is empty")
        indices = np.random.choice(self.size, batch_size, replace=False)

        batch_observations = tensorify(self.observations[indices]).to(self.device)
        batch_actions = tensorify(self.actions[indices]).to(self.device)
        batch_rewards = tensorify(self.rewards[indices]).to(self.device)
        batch_next_observations = tensorify(self.next_observations[indices]).to(self.device)
        batch_masks = tensorify(self.masks[indices]).to(self.device)

        return [batch_observations, batch_actions, batch_rewards, batch_next_observations, batch_masks]