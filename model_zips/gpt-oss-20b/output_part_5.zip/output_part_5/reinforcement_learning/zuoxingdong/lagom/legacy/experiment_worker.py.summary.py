import torch
from typing import Any, Callable, Dict, Tuple

class ExperimentWorker:
    @staticmethod
    def make_device(task_id: int, config: Dict[str, Any]) -> torch.device:
        if config.get("cuda", False):
            cuda_ids = config.get("cuda_ids", [])
            if cuda_ids:
                device_id = task_id % len(cuda_ids)
                selected_id = cuda_ids[device_id]
            else:
                device_count = torch.cuda.device_count()
                if device_count == 0:
                    torch.set_num_threads(1)
                    return torch.device("cpu")
                device_id = task_id % device_count
                selected_id = device_id
            torch.cuda.set_device(selected_id)
            return torch.device(f"cuda:{selected_id}")
        else:
            torch.set_num_threads(1)
            return torch.device("cpu")

    @staticmethod
    def run_task(
        task_id: int,
        task: Tuple[Dict[str, Any], int, Callable[[Dict[str, Any], int, torch.device], Any]],
    ) -> Any:
        config, seed, run = task
        device = ExperimentWorker.make_device(task_id, config)
        print(f"Config: {config}")
        print(f"Seed: {seed}")
        result = run(config, seed, device)
        return result
