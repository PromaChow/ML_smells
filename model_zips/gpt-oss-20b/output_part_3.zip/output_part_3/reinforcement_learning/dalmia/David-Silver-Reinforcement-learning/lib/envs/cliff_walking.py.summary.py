import sys
import numpy as np
from gym.envs.toy_text import discrete

# Action constants
UP = 0
RIGHT = 1
DOWN = 2
LEFT = 3

class CliffWalkingEnv(discrete.DiscreteEnv):
    metadata = {"render.modes": ["human", "ansi"]}

    def __init__(self):
        self.shape = (4, 12)  # rows, cols
        self.nrows, self.ncols = self.shape
        self.nS = self.nrows * self.ncols
        self.nA = 4

        # Define cliff positions (row 3, columns 1-10)
        self.cliff = {(3, col) for col in range(1, 11)}
        self.target = (3, 11)

        P = {}
        for state in range(self.nS):
            P[state] = {}
            y, x = divmod(state, self.ncols)
            for action in range(self.nA):
                next_state, reward, done = self._calculate_transition_prob(x, y, action)
                P[state][action] = [(1.0, next_state, reward, done)]

        # Initial state distribution: start at (3,0)
        isd = np.zeros(self.nS, dtype=np.float32)
        start_state = 3 * self.ncols + 0
        isd[start_state] = 1.0

        super().__init__(self.nS, self.nA, P, isd)

    def _limit_coordinates(self, x, y):
        x = max(0, min(self.ncols - 1, x))
        y = max(0, min(self.nrows - 1, y))
        return x, y

    def _calculate_transition_prob(self, x, y, action):
        if action == UP:
            new_y = y - 1
            new_x = x
        elif action == RIGHT:
            new_y = y
            new_x = x + 1
        elif action == DOWN:
            new_y = y + 1
            new_x = x
        else:  # LEFT
            new_y = y
            new_x = x - 1

        new_x, new_y = self._limit_coordinates(new_x, new_y)
        next_state = new_y * self.ncols + new_x

        if (new_y, new_x) in self.cliff:
            reward = -100
            done = True
        elif (new_y, new_x) == self.target:
            reward = 0
            done = True
        else:
            reward = -1
            done = False

        return next_state, reward, done

    def _render(self, mode="human"):
        grid = [["o"] * self.ncols for _ in range(self.nrows)]
        y, x = divmod(self.state, self.ncols)
        grid[y][x] = "x"

        for (cliff_y, cliff_x) in self.cliff:
            grid[cliff_y][cliff_x] = "C"
        grid[self.target[0]][self.target[1]] = "T"

        lines = ["".join(row) for row in grid]
        output = "\n".join(lines)

        if mode == "ansi":
            return output
        elif mode == "human":
            print(output)
        else:
            raise NotImplementedError(f"Render mode {mode} not supported")
        return None
