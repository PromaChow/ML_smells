import numpy as np
import random
from collections import deque, namedtuple

class PriorityWeightError:
    def __init__(self, alpha, beta0, betasteps, eps, normalize_by_max, error_min, error_max):
        self.alpha = alpha
        self.beta = beta0
        self.beta0 = beta0
        self.betasteps = betasteps
        self.eps = eps
        self.normalize_by_max = normalize_by_max
        self.error_min = error_min
        self.error_max = error_max
        self.step = 0

    def priority_from_errors(self, errors):
        clipped = np.clip(errors, self.error_min, self.error_max)
        return (clipped + self.eps) ** self.alpha

    def weights_from_probabilities(self, probs):
        if self.normalize_by_max:
            min_prob = 1.0 / len(probs) if len(probs) > 0 else 1.0
        else:
            min_prob = probs.min() if len(probs) > 0 else 1.0
        weights = (probs ** -self.beta) / min_prob
        # Normalize weights to max 1
        if weights.max() > 0:
            weights = weights / weights.max()
        # Update beta
        if self.step < self.betasteps:
            self.beta = self.beta0 + (1.0 - self.beta0) * (self.step / self.betasteps)
        self.step += 1
        return weights

class PrioritizedReplayBuffer:
    Transition = namedtuple('Transition', ['state', 'action', 'reward', 'next_state', 'done'])

    def __init__(self, capacity, n_step, priority_weight_error):
        self.capacity = capacity
        self.n_step = n_step
        self.buffer = deque(maxlen=capacity)
        self.priorities = deque(maxlen=capacity)
        self.pwe = priority_weight_error
        self.max_priority = 1.0

    def add(self, state, action, reward, next_state, done):
        transition = self.Transition(state, action, reward, next_state, done)
        self.buffer.append(transition)
        self.priorities.append(self.max_priority)

    def sample(self, batch_size):
        if len(self.buffer) == 0:
            return []
        priorities_array = np.array(self.priorities, dtype=np.float32)
        total = priorities_array.sum()
        if total == 0:
            probs = np.full_like(priorities_array, 1.0 / len(priorities_array))
        else:
            probs = priorities_array / total
        indices = np.random.choice(len(self.buffer), size=batch_size, replace=False, p=probs)
        transitions = [self.buffer[i] for i in indices]
        weights = self.pwe.weights_from_probabilities(probs[indices])
        samples = []
        for t, w in zip(transitions, weights):
            sample = {
                'state': t.state,
                'action': t.action,
                'reward': t.reward,
                'next_state': t.next_state,
                'done': t.done,
                'weight': w
            }
            samples.append(sample)
        return samples

    def update_errors(self, errors):
        priorities = self.pwe.priority_from_errors(errors)
        n = len(priorities)
        if n == 0:
            return
        for i, p in zip(reversed(range(len(self.priorities))), priorities):
            self.priorities[i] = p
            if p > self.max_priority:
                self.max_priority = p

    def __len__(self):
        return len(self.buffer)