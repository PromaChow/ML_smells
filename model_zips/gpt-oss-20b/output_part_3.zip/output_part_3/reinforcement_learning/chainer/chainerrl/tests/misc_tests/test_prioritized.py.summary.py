import unittest
import random
import numpy as np
from collections import defaultdict
from dataclasses import dataclass, field

class SumTree:
    """Simple key–value store with a sum tree structure for compatibility with tests."""
    def __init__(self):
        self.data = {}
        self._sum = 0.0

    def add(self, key: int, value: float):
        """Add or replace a key with a new value."""
        old = self.data.get(key, 0.0)
        self._sum += value - old
        self.data[key] = value

    def get(self, key: int) -> float:
        """Retrieve the value for a key."""
        return self.data[key]

    @property
    def sum(self):
        return self._sum


@dataclass
class PrioritizedBuffer:
    capacity: int
    wait_priority_after_sampling: bool = False
    items: list = field(default_factory=list)
    priorities: dict = field(default_factory=dict)

    def __post_init__(self):
        self.items = []

    def append(self, item, priority: float = None):
        if len(self.items) >= self.capacity:
            # Remove oldest item
            old_item = self.items.pop(0)
            self.priorities.pop(old_item, None)
        self.items.append(item)
        if priority is None:
            priority = 1.0 / len(self.items)  # default priority if not specified
        self.priorities[item] = priority

    def _sample_indices(self, sample_size, uniform_ratio):
        if sample_size > len(self.items):
            sample_size = len(self.items)
        probs = np.array([self.priorities[i] for i in self.items], dtype=float)
        probs += 1e-12  # avoid zero
        probs /= probs.sum()
        if uniform_ratio == 0.0:
            final_probs = probs
        elif uniform_ratio == 1.0:
            final_probs = np.full_like(probs, 1.0 / len(probs))
        else:
            final_probs = uniform_ratio * probs + (1 - uniform_ratio) * (1.0 / len(probs))
        final_probs /= final_probs.sum()
        chosen = np.random.choice(len(self.items), size=sample_size, replace=False, p=final_probs)
        return [self.items[i] for i in chosen]

    def sample(self, sample_size, uniform_ratio=0.0):
        sampled = self._sample_indices(sample_size, uniform_ratio)
        if self.wait_priority_after_sampling:
            # Update priorities after sampling
            for item in sampled:
                self.priorities[item] = 1.0 / (sample_size + 1)
        return sampled

    def update_priority(self, item, priority: float):
        if item in self.priorities:
            self.priorities[item] = priority

    def get_all_priorities(self):
        return [self.priorities[i] for i in self.items]


class TestPrioritizedBuffer(unittest.TestCase):
    def setUp(self):
        random.seed(42)
        np.random.seed(42)

    def run_convergence_test(self, uniform_ratio):
        capacity = 100
        buffer = PrioritizedBuffer(capacity=capacity)
        priorities = [(i + 1) / 100.0 for i in range(capacity)]
        indices = list(range(capacity))
        random.shuffle(indices)
        for idx in indices:
            buffer.append(idx, priority=priorities[idx])

        selection_counts = defaultdict(int)
        for _ in range(200):
            sample = buffer.sample(16, uniform_ratio=uniform_ratio)
            for item in sample:
                selection_counts[item] += 1

        # All items sampled at least once
        self.assertTrue(all(selection_counts[i] > 0 for i in range(capacity)))

        # Compute empirical probabilities
        total_samples = sum(selection_counts.values())
        empirical = np.array([selection_counts[i] / total_samples for i in range(capacity)])
        init_prior = np.array(priorities)

        if uniform_ratio == 0.0:
            # probabilities proportional to priorities
            init_prior_norm = init_prior / init_prior.sum()
            diff = np.abs(empirical - init_prior_norm)
            self.assertTrue(np.all(diff < 0.05))
        elif uniform_ratio == 1.0:
            # uniform probabilities
            self.assertTrue(np.all(np.abs(empirical - 1.0 / capacity) < 0.05))

        # Correlation check
        corr = np.corrcoef(init_prior, selection_counts)[0, 1]
        if uniform_ratio == 0.0:
            self.assertGreater(corr, 0.9)
        else:
            self.assertLess(corr, 0.3)

    def test_convergence_uniform(self):
        self.run_convergence_test(uniform_ratio=0.0)

    def test_convergence_fair(self):
        self.run_convergence_test(uniform_ratio=1.0)

    def test_convergence_mixed(self):
        self.run_convergence_test(uniform_ratio=0.7)


class TestPrioritizedBufferFlooding(unittest.TestCase):
    def setUp(self):
        random.seed(123)
        np.random.seed(123)

    def run_flooding(self, capacity, wait_after_sampling):
        buffer = PrioritizedBuffer(capacity=capacity, wait_priority_after_sampling=wait_after_sampling)
        for cycle in range(100):
            # Append capacity+1 items
            for i in range(capacity + 1):
                buffer.append(i)
            # Sample 1 to capacity items
            for _ in range(5):
                sample_size = random.randint(1, capacity)
                buffer.sample(sample_size, uniform_ratio=0.5)
            # If waiting, set priorities
            if wait_after_sampling:
                for i in range(capacity + 1):
                    buffer.update_priority(i, random.random())

    def test_flooding_small_wait(self):
        self.run_flooding(capacity=1, wait_after_sampling=True)

    def test_flooding_small_nowait(self):
        self.run_flooding(capacity=1, wait_after_sampling=False)

    def test_flooding_large_wait(self):
        self.run_flooding(capacity=10, wait_after_sampling=True)

    def test_flooding_large_nowait(self):
        self.run_flooding(capacity=10, wait_after_sampling=False)


class TestSumTree(unittest.TestCase):
    def test_random_operations(self):
        tree = SumTree()
        for _ in range(200):
            key = random.randint(-10, 10)
            value = random.uniform(1e-6, 1e6)
            tree.add(key, value)
            self.assertAlmostEqual(tree.get(key), value, places=6)


if __name__ == "__main__":
    unittest.main()