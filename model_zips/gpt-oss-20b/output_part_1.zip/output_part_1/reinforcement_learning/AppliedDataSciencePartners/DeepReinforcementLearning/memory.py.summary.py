import collections
from collections import deque

# Simple configuration holder
class Config:
    MEMORY_SIZE = 1000

config = Config()

class Memory:
    def __init__(self):
        self.ltmemory = deque(maxlen=config.MEMORY_SIZE)
        self.stmemory = deque(maxlen=config.MEMORY_SIZE)

    def commit_stmemory(self, identities, state, actionValues):
        """
        Store entries in short-term memory.

        Parameters:
            identities (callable): Function that returns an iterable of tuples.
            state: Full state object.
            actionValues: Values associated with actions.
        """
        for entry in identities(state, actionValues):
            first, second = entry
            item = {
                'board': getattr(first, 'board', None),
                'state': getattr(first, 'state', None),
                'id': getattr(first, 'id', None),
                'AV': second,
                'playerTurn': getattr(first, 'playerTurn', None)
            }
            self.stmemory.append(item)

    def commit_ltmemory(self):
        """
        Transfer all entries from short-term memory to long-term memory
        and then clear the short-term memory.
        """
        for item in self.stmemory:
            self.ltmemory.append(item)
        self.clear_stmemory()

    def clear_stmemory(self):
        """
        Reinitialize the short-term memory as an empty deque.
        """
        self.stmemory = deque(maxlen=config.MEMORY_SIZE)