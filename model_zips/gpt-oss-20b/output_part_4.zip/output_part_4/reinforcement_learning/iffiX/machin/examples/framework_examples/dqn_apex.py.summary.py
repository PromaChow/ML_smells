import os
import sys
import time
import collections
from typing import List

import gym
import torch
import torch.nn as nn
import torch.optim as optim

from machin import World
from machin.env import GymEnvironment
from machin.framework.model import model_server_helper
from machin.model.nn import MLP
from machin.parallel import rpc
from machin.rl.algorithms import DQNApex

# --------------------- Q-Network Definition --------------------- #
class QNet(nn.Module):
    def __init__(self, state_dim: int, action_dim: int, hidden_dim: int = 128):
        super(QNet, self).__init__()
        self.model = MLP(
            input_dim=state_dim,
            output_dim=action_dim,
            hidden_dims=[hidden_dim, hidden_dim, hidden_dim],
            activation=nn.ReLU,
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.model(x)

# --------------------- Worker Code --------------------- #
def worker(rank: int, env_name: str, solved_reward: float, solved_repeat: int):
    env = GymEnvironment(env_name)
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.n

    # Instantiate networks
    q_net = QNet(state_dim, action_dim)
    q_net_target = QNet(state_dim, action_dim)

    # Optimizer and loss
    optimizer = optim.Adam(q_net.parameters(), lr=1e-4)
    loss_fn = nn.MSELoss()

    # Model server
    server = model_server_helper(models=[q_net_target], n_models=1)

    # RPC group
    rpc_group = rpc.RPCGroup(name="apex")

    # DQN-Apex instance
    dqn_apex = DQNApex(
        q_net=q_net,
        q_net_t=q_net_target,
        optimizer=optimizer,
        loss_fn=loss_fn,
        rpc_group=rpc_group,
        server=server,
    )

    # Synchronize all processes
    rpc_group.barrier()
    dqn_apex.set_sync(False)

    # Tracking for solving
    reward_history = collections.deque(maxlen=solved_repeat)
    episode = 0

    while True:
        obs = env.reset()
        done = False
        total_reward = 0.0
        observations: List[torch.Tensor] = []
        actions: List[int] = []
        rewards: List[float] = []
        next_observations: List[torch.Tensor] = []
        dones: List[bool] = []

        while not done:
            action = dqn_apex.act_discrete_with_noise(obs)[0]
            next_obs, reward, done, _ = env.step(action)

            observations.append(torch.tensor(obs, dtype=torch.float32))
            actions.append(action)
            rewards.append(reward)
            next_observations.append(torch.tensor(next_obs, dtype=torch.float32))
            dones.append(done)

            obs = next_obs
            total_reward += reward

        # Store episode
        dqn_apex.store_episode(
            observations,
            actions,
            rewards,
            next_observations,
            dones,
        )

        # Manual sync with learners
        dqn_apex.manual_sync()

        reward_history.append(total_reward)
        episode += 1

        if episode % 10 == 0:
            avg_reward = sum(reward_history) / len(reward_history)
            print(f"[Worker {rank}] Episode {episode} | Avg Reward: {avg_reward:.2f}")
            if avg_reward >= solved_reward:
                print(f"[Worker {rank}] Environment solved after {episode} episodes!")
                sys.exit(0)

# --------------------- Learner Code --------------------- #
def learner(rank: int):
    # Instantiate dummy environment for shape inference
    env = GymEnvironment("CartPole-v1")
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.n

    # Instantiate networks
    q_net = QNet(state_dim, action_dim)
    q_net_target = QNet(state_dim, action_dim)

    # Optimizer and loss
    optimizer = optim.Adam(q_net.parameters(), lr=1e-4)
    loss_fn = nn.MSELoss()

    # Model server
    server = model_server_helper(models=[q_net_target], n_models=1)

    # RPC group
    rpc_group = rpc.RPCGroup(name="apex")

    # DQN-Apex instance
    dqn_apex = DQNApex(
        q_net=q_net,
        q_net_t=q_net_target,
        optimizer=optimizer,
        loss_fn=loss_fn,
        rpc_group=rpc_group,
        server=server,
    )

    # Synchronize all processes
    rpc_group.barrier()
    dqn_apex.set_sync(False)

    # Wait until enough samples
    while dqn_apex.replay_buffer.size() < 500:
        time.sleep(1)

    # Update loop
    while True:
        dqn_apex.update()
        time.sleep(0.01)  # small sleep to yield

# --------------------- Main --------------------- #
def main(rank: int):
    if rank in (0, 1):
        worker(rank, env_name="CartPole-v1", solved_reward=195.0, solved_repeat=10)
    else:
        learner(rank)

if __name__ == "__main__":
    world = World(num_processes=4)
    world.run(main)