import torch
import torch.nn as nn
import unittest
import random
import os

# ---------- Core recurrent building blocks ----------

class NStepLSTM(nn.Module):
    def __init__(self, input_size, hidden_size):
        super().__init__()
        self.hidden_size = hidden_size
        self.lstm = nn.LSTM(input_size, hidden_size, batch_first=True)

    def forward(self, x, hx=None):
        # x: (batch, input_size)
        x = x.unsqueeze(1)  # (batch, 1, input_size)
        if hx is None:
            batch = x.size(0)
            hx = (torch.zeros(1, batch, self.hidden_size, device=x.device),
                  torch.zeros(1, batch, self.hidden_size, device=x.device))
        out, hx = self.lstm(x, hx)
        return out.squeeze(1), hx

class NStepGRU(nn.Module):
    def __init__(self, input_size, hidden_size):
        super().__init__()
        self.hidden_size = hidden_size
        self.gru = nn.GRU(input_size, hidden_size, batch_first=True)

    def forward(self, x, hx=None):
        x = x.unsqueeze(1)
        if hx is None:
            batch = x.size(0)
            hx = torch.zeros(1, batch, self.hidden_size, device=x.device)
        out, hx = self.gru(x, hx)
        return out.squeeze(1), hx

class NStepRNNReLU(nn.Module):
    def __init__(self, input_size, hidden_size):
        super().__init__()
        self.hidden_size = hidden_size
        self.rnn = nn.RNN(input_size, hidden_size, nonlinearity='relu', batch_first=True)

    def forward(self, x, hx=None):
        x = x.unsqueeze(1)
        if hx is None:
            batch = x.size(0)
            hx = torch.zeros(1, batch, self.hidden_size, device=x.device)
        out, hx = self.rnn(x, hx)
        return out.squeeze(1), hx

class StatelessRecurrentSequential(nn.Module):
    def __init__(self, *modules):
        super().__init__()
        self.seq = nn.Sequential(*modules)

    def forward(self, x):
        return self.seq(x)

# ---------- Branched recurrent network ----------

class StatelessRecurrentBranched(nn.Module):
    def __init__(self, *branches):
        super().__init__()
        self.branches = nn.ModuleList(branches)
        self.hidden_states = [None] * len(self.branches)
        self.states_history = []
        self.mask_indices = set()

    def reset_states(self, device=None):
        self.hidden_states = [None] * len(self.branches)
        self.states_history = []

    def mask_recurrent_state_at(self, mask_indices):
        self.mask_indices = set(mask_indices)

    def get_recurrent_state_at(self, step_index):
        if step_index < len(self.states_history):
            return self.states_history[step_index]
        return [None] * len(self.branches)

    def concatenate_recurrent_states(self, states_list):
        return states_list

    def _zero_hidden(self, branch, batch, device):
        if isinstance(branch, NStepLSTM):
            return (torch.zeros(1, batch, branch.hidden_size, device=device),
                    torch.zeros(1, batch, branch.hidden_size, device=device))
        elif isinstance(branch, (NStepGRU, NStepRNNReLU)):
            return torch.zeros(1, batch, branch.hidden_size, device=device)
        else:
            return None

    def n_step_forward(self, seqs_x, output_mode='concat', init_hidden=None, device=None):
        """
        seqs_x: list of tensors each of shape (batch, input_size)
        init_hidden: optional list of hidden states for each branch
        """
        batch = seqs_x[0].size(0)
        if device is None:
            device = seqs_x[0].device
        # Initialize hidden states
        if init_hidden is None:
            self.hidden_states = [self._zero_hidden(b, batch, device) for b in self.branches]
        else:
            self.hidden_states = init_hidden

        outputs_per_branch = [[] for _ in self.branches]
        self.states_history = []

        for step_idx, x in enumerate(seqs_x):
            if step_idx in self.mask_indices:
                self.hidden_states = [self._zero_hidden(b, batch, device) for b in self.branches]
            for i, branch in enumerate(self.branches):
                if isinstance(branch, (NStepLSTM, NStepGRU, NStepRNNReLU)):
                    out, h = branch(x, self.hidden_states[i])
                    self.hidden_states[i] = h
                else:
                    out = branch(x)
                outputs_per_branch[i].append(out)
            self.states_history.append([self.hidden_states[i] for i in range(len(self.branches))])

        # Stack outputs
        if output_mode == 'concat':
            concat_outs = [torch.stack(o, dim=0) for o in outputs_per_branch]
            return tuple(concat_outs), self.hidden_states
        elif output_mode == 'split':
            split_outs = []
            for step in range(len(seqs_x)):
                step_out = tuple(outputs_per_branch[i][step] for i in range(len(self.branches)))
                split_outs.append(step_out)
            return split_outs, self.hidden_states
        else:
            raise ValueError(f"Unsupported output_mode {output_mode}")

# ---------- Test Suite ----------

class TestStatelessRecurrentBranched(unittest.TestCase):
    def setUp(self):
        # Random seed for reproducibility
        torch.manual_seed(0)
        random.seed(0)
        self.gpu_available = torch.cuda.is_available()

    def _create_network(self, gpu):
        lstm = NStepLSTM(input_size=2, hidden_size=3)
        rnn_relu = StatelessRecurrentSequential(NStepRNNReLU(input_size=2, hidden_size=4))
        linear = StatelessRecurrentSequential(nn.Linear(2, 1))
        net = StatelessRecurrentBranched(lstm, rnn_relu, linear)
        if gpu and self.gpu_available:
            net.to('cuda')
        return net

    def _prepare_input(self, gpu):
        seqs_x = [torch.randn(1, 2), torch.randn(3, 2)]
        if gpu and self.gpu_available:
            seqs_x = [x.to('cuda') for x in seqs_x]
        return seqs_x

    def test_n_step_forward_concatenation_and_split(self):
        for gpu in [False, True]:
            with self.subTest(gpu=gpu):
                net = self._create_network(gpu)
                seqs_x = self._prepare_input(gpu)
                net.reset_states()
                concat_outs, _ = net.n_step_forward(seqs_x, output_mode='concat')
                split_outs, _ = net.n_step_forward(seqs_x, output_mode='split')

                # Validate shapes
                self.assertEqual(len(concat_outs), 3)
                self.assertEqual(concat_outs[0].shape, (4, 3))
                self.assertEqual(concat_outs[1].shape, (4, 4))
                self.assertEqual(concat_outs[2].shape, (4, 1))

                self.assertEqual(len(split_outs), 2)
                for step_tuple in split_outs:
                    self.assertEqual(len(step_tuple), 3)
                    self.assertEqual(step_tuple[0].shape, (1, 3))
                    self.assertEqual(step_tuple[1].shape, (1, 4))
                    self.assertEqual(step_tuple[2].shape, (1, 1))

                # Consistency check
                for i in range(3):
                    split_stack = torch.stack([step[i] for step in split_outs], dim=0)
                    self.assertTrue(torch.allclose(concat_outs[i], split_stack, atol=1e-6))

    def _create_network_mask(self, gpu):
        gru = NStepGRU(input_size=2, hidden_size=2)
        lstm = StatelessRecurrentSequential(NStepLSTM(input_size=2, hidden_size=3))
        net = StatelessRecurrentBranched(gru, lstm)
        if gpu and self.gpu_available:
            net.to('cuda')
        return net

    def _prepare_input_mask(self, gpu):
        seqs_x = [torch.randn(2, 2), torch.randn(2, 2)]
        if gpu and self.gpu_available:
            seqs_x = [x.to('cuda') for x in seqs_x]
        return seqs_x

    def test_mask_recurrent_state(self):
        for gpu in [False, True]:
            with self.subTest(gpu=gpu):
                net = self._create_network_mask(gpu)
                seqs_x = self._prepare_input_mask(gpu)
                net.reset_states()

                # Standard forward pass
                out1, hs1 = net.n_step_forward(seqs_x, output_mode='concat')
                # Manual forward pass to compare
                net.reset_states()
                out_manual, hs_manual = net.n_step_forward(seqs_x, output_mode='concat')
                self.assertTrue(torch.allclose(out1[0], out_manual[0], atol=1e-6))
                self.assertTrue(torch.allclose(out1[1], out_manual[1], atol=1e-6))

                # Mask first time step only
                net.reset_states()
                net.mask_recurrent_state_at([0])
                out_masked, _ = net.n_step_forward(seqs_x, output_mode='concat')
                # Compare with manual run where first hidden state is zero
                net.reset_states()
                # Set hidden state of first step to zero before second step
                out_manual_masked, _ = net.n_step_forward(seqs_x, output_mode='concat')
                self.assertTrue(torch.allclose(out_masked[0], out_manual_masked[0], atol=1e-6))
                self.assertTrue(torch.allclose(out_masked[1], out_manual_masked[1], atol=1e-6))

                # Mask second time step only
                net.reset_states()
                net.mask_recurrent_state_at([1])
                out_masked2, _ = net.n_step_forward(seqs_x, output_mode='concat')
                net.reset_states()
                out_manual_masked2, _ = net.n_step_forward(seqs_x, output_mode='concat')
                self.assertTrue(torch.allclose(out_masked2[0], out_manual_masked2[0], atol=1e-6))
                self.assertTrue(torch.allclose(out_masked2[1], out_manual_masked2[1], atol=1e-6))

                # Mask both time steps
                net.reset_states()
                net.mask_recurrent_state_at([0, 1])
                out_masked_all, _ = net.n_step_forward(seqs_x, output_mode='concat')
                net.reset_states()
                out_manual_masked_all, _ = net.n_step_forward(seqs_x, output_mode='concat')
                self.assertTrue(torch.allclose(out_masked_all[0], out_manual_masked_all[0], atol=1e-6))
                self.assertTrue(torch.allclose(out_masked_all[1], out_manual_masked_all[1], atol=1e-6))

                # Recurrent state concatenation test
                net.reset_states()
                out_base, hs_base = net.n_step_forward(seqs_x, output_mode='concat')
                # Extract hidden states after first step
                hs_at_0 = net.get_recurrent_state_at(0)
                # Concatenate (in this simple case just pass through)
                hs_concat = net.concatenate_recurrent_states(hs_at_0)
                net.reset_states()
                out_concat, _ = net.n_step_forward(seqs_x, output_mode='concat', init_hidden=hs_concat)
                self.assertTrue(torch.allclose(out_base[0], out_concat[0], atol=1e-6))
                self.assertTrue(torch.allclose(out_base[1], out_concat[1], atol=1e-6))

# ---------- Run tests ----------
if __name__ == '__main__':
    unittest.main()
