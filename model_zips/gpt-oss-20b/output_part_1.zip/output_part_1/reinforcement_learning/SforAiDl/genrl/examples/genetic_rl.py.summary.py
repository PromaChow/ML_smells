import argparse
from genrl.envs import VectorEnv, get_env_properties
from genrl.agents import MlpActorCritic, A2C
from genrl.tuners import GATuner
from genrl.trainers import OnPolicyTrainer


def parse_args():
    parser = argparse.ArgumentParser(description="GA hyperparameter tuning for RL")
    parser.add_argument("--env", type=str, default="CartPole-v1", help="Gym environment name")
    parser.add_argument("--n-envs", type=int, default=4, help="Number of parallel environments")
    parser.add_argument("--epochs", type=int, default=50, help="Number of training epochs per agent")
    parser.add_argument("--rollout-size", type=int, default=128, help="Rollout size for A2C")
    parser.add_argument("--log", type=str, default="stdout", help="Logging target (stdout or file path)")
    parser.add_argument("--population", type=int, default=10, help="GA population size")
    parser.add_argument("--generations", type=int, default=5, help="Number of GA generations")
    return parser.parse_args()


def create_env(env_name: str, n_envs: int):
    return VectorEnv(env_name, n_envs=n_envs, env_type="subproc")


def create_agent_kwargs(env_properties):
    actor_critic = MlpActorCritic(
        input_dim=env_properties["obs_shape"],
        output_dim=env_properties["action_shape"],
        hidden_sizes=(256, 256),
        activation="relu",
        value_function="mlp",
    )
    return {"actor_critic": actor_critic, "rollout_size": None}


def generate(tuner: GATuner, population_size: int, generations: int, epochs: int, log_target: str):
    agents = tuner.initialize_population(population_size)

    for gen in range(generations):
        for agent in agents:
            trainer = OnPolicyTrainer(env=tuner.env, agent=agent, epochs=epochs, log=log_target, render=False)
            trainer.train()

        fitnesses = tuner.grade(agents)
        avg_reward = sum(fitnesses) / len(fitnesses)
        print(f"Generation {gen + 1} average reward: {avg_reward:.4f}")

        if gen < generations - 1:
            agents = tuner.evolve(agents)

    fitnesses = tuner.grade(agents)
    sorted_agents = sorted(zip(agents, fitnesses), key=lambda x: x[1], reverse=True)

    print("\nTop 5 agents:")
    for idx, (agent, reward) in enumerate(sorted_agents[:5], start=1):
        print(f"{idx}. Reward: {reward:.4f}")


def main():
    args = parse_args()
    env = create_env(args.env, args.n_envs)
    env_props = get_env_properties(env)

    agent_kwargs = create_agent_kwargs(env_props)
    agent_kwargs["rollout_size"] = args.rollout_size

    agent_parameter_choices = {"gamma": [12, 121]}

    tuner = GATuner(
        agent_cls=A2C,
        agent_kwargs=agent_kwargs,
        agent_parameter_choices=agent_parameter_choices,
        env=env,
    )

    generate(
        tuner=tuner,
        population_size=args.population,
        generations=args.generations,
        epochs=args.epochs,
        log_target=args.log,
    )


if __name__ == "__main__":
    main()