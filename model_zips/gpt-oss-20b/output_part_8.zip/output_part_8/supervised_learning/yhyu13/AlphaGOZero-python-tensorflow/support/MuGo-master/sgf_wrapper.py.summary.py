import re
import copy
from dataclasses import dataclass
from typing import List, Tuple, Optional, Iterable, Dict

# ---------- Coordinate utilities ----------
def coord_to_index(coord: str) -> Tuple[int, int]:
    """Convert SGF coordinate to 0-based board indices."""
    if not coord:
        return None  # pass
    col = ord(coord[0]) - ord('a')
    row = ord(coord[1]) - ord('a')
    return row, col

def index_to_coord(row: int, col: int) -> str:
    """Convert 0-based board indices to SGF coordinate."""
    return chr(ord('a') + col) + chr(ord('a') + row)

# ---------- Board representation ----------
class Position:
    def __init__(self, size: int, komi: float = 0.0, metadata: Optional[Dict] = None):
        self.size = size
        self.komi = komi
        self.board: List[List[int]] = [[0] * size for _ in range(size)]  # 0 empty, 1 black, 2 white
        self.recent: List[Tuple[str, str]] = []  # list of (player, coord)
        self.metadata = metadata or {}

    def add_stones(self, player: str, coords: List[str]) -> None:
        for c in coords:
            idx = coord_to_index(c)
            if idx:
                r, c_ = idx
                self.board[r][c_] = 1 if player == 'B' else 2

    def play_move(self, player: str, coord: str) -> None:
        if coord == '':
            self.recent.append((player, ''))
            return
        r, c = coord_to_index(coord)
        self.board[r][c] = 1 if player == 'B' else 2
        self.recent.append((player, coord))

    def copy(self) -> 'Position':
        new_pos = Position(self.size, self.komi, copy.deepcopy(self.metadata))
        new_pos.board = [row[:] for row in self.board]
        new_pos.recent = self.recent[:]  # shallow copy is fine
        return new_pos

# ---------- Context container ----------
@dataclass
class PositionWithContext:
    position: Position
    next_move: Optional[Tuple[str, str]]
    metadata: Dict

# ---------- SGF parsing ----------
SGF_PROPERTY_RE = re.compile(r'([A-Z]+)(\[[^\]]*\])+')

def parse_sgf_nodes(sgf_content: str) -> List[Dict[str, List[str]]]:
    """Parse SGF content into a list of node property dictionaries."""
    nodes = []
    # Remove comments and whitespace
    sgf_content = re.sub(r'\{[^}]*\}', '', sgf_content)
    sgf_content = sgf_content.replace('\n', '')
    # Split at ';' ignoring leading '(' and trailing ')'
    parts = sgf_content.strip('()').split(';')
    for part in parts:
        if not part:
            continue
        props = {}
        for match in SGF_PROPERTY_RE.finditer(part):
            key = match.group(1)
            vals = re.findall(r'\[([^\]]*)\]', match.group(0))
            props[key] = vals
        nodes.append(props)
    return nodes

# ---------- Replay functions ----------
def replay_sgf(sgf_content: str) -> Iterable[PositionWithContext]:
    nodes = parse_sgf_nodes(sgf_content)
    if not nodes:
        return

    # Extract metadata from root node
    root = nodes[0]
    size = int(root.get('SZ', ['19'])[0])
    komi = float(root.get('KM', ['0'])[0])
    result = root.get('RE', [''])[0]
    handicap = int(root.get('HA', ['0'])[0])
    metadata = {'SZ': size, 'KM': komi, 'RE': result, 'HA': handicap}

    pos = Position(size, komi, metadata)

    # Apply any initial stone additions on root (handicap)
    for key in ('AB', 'AW'):
        if key in root:
            pos.add_stones('B' if key == 'AB' else 'W', root[key])

    current_player = 'B'  # black starts
    for i, node in enumerate(nodes):
        # Apply stone additions
        for key in ('AB', 'AW'):
            if key in node:
                pos.add_stones('B' if key == 'AB' else 'W', node[key])

        # Apply move if present
        move_key = None
        if current_player == 'B' and 'B' in node:
            move_key = 'B'
        elif current_player == 'W' and 'W' in node:
            move_key = 'W'
        else:
            # Handle non-alternating move: search for any move
            if 'B' in node:
                move_key = 'B'
                current_player = 'B'
            elif 'W' in node:
                move_key = 'W'
                current_player = 'W'

        if move_key:
            coord = node[move_key][0]
            pos.play_move(move_key, coord)

        # Determine next move
        next_move = None
        if i + 1 < len(nodes):
            next_node = nodes[i + 1]
            if 'B' in next_node:
                next_move = ('B', next_node['B'][0])
                current_player = 'W'
            elif 'W' in next_node:
                next_move = ('W', next_node['W'][0])
                current_player = 'B'
        yield PositionWithContext(pos.copy(), next_move, metadata)

def replay_position(position: Position) -> Iterable[PositionWithContext]:
    size = position.size
    komi = position.komi
    metadata = copy.deepcopy(position.metadata)
    pos = Position(size, komi, metadata)
    moves = position.recent
    for i, (player, coord) in enumerate(moves):
        pos.play_move(player, coord)
        next_move = None
        if i + 1 < len(moves):
            next_move = moves[i + 1]
        yield PositionWithContext(pos.copy(), next_move, metadata)

# ---------- SGF generation ----------
def make_sgf(moves: List[Tuple[str, str]], metadata: Dict) -> str:
    parts = ['(;GM[1]FF[4]CA[UTF-8]']
    sz = metadata.get('SZ')
    if sz:
        parts.append(f'SZ[{sz}]')
    km = metadata.get('KM')
    if km is not None:
        parts.append(f'KM[{km}]')
    ha = metadata.get('HA')
    if ha:
        parts.append(f'HA[{ha}]')
    re_ = metadata.get('RE')
    if re_:
        parts.append(f'RE[{re_}]')
    parts.append('')

    for player, coord in moves:
        if player == 'B':
            parts.append(f'B[{coord}]')
        else:
            parts.append(f'W[{coord}]')
        parts.append(';')

    sgf = ''.join(parts).rstrip(';')
    sgf += ')'
    return sgf
