import torch
from wavencoder.models import CNN1d, LSTM_Attn_Classifier

# Convolutional layer configuration: (out_channels, kernel_size, stride)
conv_layers = [(16, 10, 5), (32, 10, 5), (64, 10, 5)]

# Encoder and classifier initialization
encoder = CNN1d(conv_layers)
classifier = LSTM_Attn_Classifier(input_size=64, hidden_size=64, num_classes=2)

# Input tensor: batch of 2 audio samples, 1 channel, 16000 time steps
x = torch.randn(2, 1, 16000)

# Forward pass through encoder
z = encoder(x)

# Forward pass through classifier
y = classifier(z)

# Output shape verification
print(f"Feature representation shape: {z.shape}")
print(f"Classification output shape: {y.shape}")