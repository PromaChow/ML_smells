import random
import unittest
import timeit
import numpy as np
from scipy import stats


def sample_n_k(n: int, k: int):
    """
    Return a list of k unique random integers from the range [0, n).
    Uses a partial Fisher–Yates shuffle for efficiency.
    """
    arr = list(range(n))
    for i in range(k):
        j = random.randint(i, n - 1)
        arr[i], arr[j] = arr[j], arr[i]
    return arr[:k]


class TestSampleNK(unittest.TestCase):
    combos = [
        (10, 3),
        (20, 5),
        (50, 10),
        (128, 64),
    ]

    def test_fast(self):
        for n, k in self.combos:
            with self.subTest(n=n, k=k):
                for _ in range(200):
                    sample = sample_n_k(n, k)
                    self.assertEqual(len(sample), k, f"Sample length mismatch for n={n}, k={k}")
                    self.assertTrue(all(0 <= x < n for x in sample), f"Element out of range for n={n}, k={k}")
                    self.assertEqual(len(set(sample)), k, f"Duplicate elements for n={n}, k={k}")

    def test_slow(self):
        N_SAMPLES = 100000
        for n, k in self.combos:
            with self.subTest(n=n, k=k):
                counts = [0] * n
                pair_counts = {(i, j): 0 for i in range(k) for j in range(i + 1, k)}
                for _ in range(N_SAMPLES):
                    sample = sample_n_k(n, k)
                    for idx, val in enumerate(sample):
                        counts[val] += 1
                    for i in range(k):
                        for j in range(i + 1, k):
                            if sample[i] < sample[j]:
                                pair_counts[(i, j)] += 1

                expected_mean = N_SAMPLES * k / n
                expected_std = (N_SAMPLES * (k / n) * (1 - k / n)) ** 0.5
                ks_stat, p_value = stats.kstest(
                    counts, 'norm', args=(expected_mean, expected_std)
                )
                self.assertGreater(
                    p_value,
                    0.01,
                    f"Count distribution KS test failed for n={n}, k={k}, p={p_value:.5f}",
                )

                expected_mean_pair = N_SAMPLES * 0.5
                expected_std_pair = (N_SAMPLES * 0.5 * 0.5) ** 0.5
                pair_values = list(pair_counts.values())
                ks_stat_pair, p_value_pair = stats.kstest(
                    pair_values, 'norm', args=(expected_mean_pair, expected_std_pair)
                )
                self.assertGreater(
                    p_value_pair,
                    0.01,
                    f"Pair order distribution KS test failed for n={n}, k={k}, p={p_value_pair:.5f}",
                )


class TestSampleNKSpeed(unittest.TestCase):
    def test_speed(self):
        n_values = [64, 256, 1024, 4096, 10000]
        k = 64

        def bench_sample_n_k():
            for n in n_values:
                sample_n_k(n, k)

        def bench_random_sample():
            for n in n_values:
                random.sample(range(n), k)

        def bench_np_choice():
            for n in n_values:
                np.random.choice(n, k, replace=False)

        time_sample = timeit.timeit(bench_sample_n_k, number=1)
        time_random = timeit.timeit(bench_random_sample, number=1)
        time_np = timeit.timeit(bench_np_choice, number=1)

        self.assertLess(
            time_sample,
            time_random,
            f"sample_n_k ({time_sample:.4f}s) should be faster than random.sample ({time_random:.4f}s)",
        )
        self.assertLess(
            time_sample,
            time_np,
            f"sample_n_k ({time_sample:.4f}s) should be faster than np.random.choice ({time_np:.4f}s)",
        )


if __name__ == "__main__":
    unittest.main()