import numpy as np
from dataclasses import dataclass

@dataclass
class ModelParams:
    weights_dense1_w: np.ndarray  # shape (1, 300) or (300,)
    weights_dense1_b: float
    weights_dense2_w: np.ndarray  # shape (300, 100)
    weights_dense2_b: float
    weights_final_w: np.ndarray   # shape (100, 2)
    weights_final_b: float

def forward(params: ModelParams, x: np.ndarray) -> np.ndarray:
    """
    Forward pass of the three-layer dense network.
    Parameters
    ----------
    params : ModelParams
        The weights and biases of the model.
    x : np.ndarray
        Input vector of shape (1,) or (n_features,).
    Returns
    -------
    np.ndarray
        Output vector of shape (2,).
    """
    # Ensure x is a 1D vector
    x = np.asarray(x).flatten()
    # Layer 1: Input -> Dense1
    if params.weights_dense1_w.ndim == 1:
        z1 = x.dot(params.weights_dense1_w) + params.weights_dense1_b
    else:
        z1 = x.dot(params.weights_dense1_w.T) + params.weights_dense1_b
    # Layer 2: Dense1 -> Dense2
    z2 = z1.dot(params.weights_dense2_w) + params.weights_dense2_b
    # Layer 3: Dense2 -> Final
    out = z2.dot(params.weights_final_w) + params.weights_final_b
    return out

# Example usage with placeholder random weights
def create_random_params(seed: int = 42) -> ModelParams:
    rng = np.random.default_rng(seed)
    weights_dense1_w = rng.standard_normal(300)
    weights_dense1_b = rng.standard_normal()
    weights_dense2_w = rng.standard_normal((300, 100))
    weights_dense2_b = rng.standard_normal()
    weights_final_w = rng.standard_normal((100, 2))
    weights_final_b = rng.standard_normal()
    return ModelParams(
        weights_dense1_w=weights_dense1_w,
        weights_dense1_b=weights_dense1_b,
        weights_dense2_w=weights_dense2_w,
        weights_dense2_b=weights_dense2_b,
        weights_final_w=weights_final_w,
        weights_final_b=weights_final_b,
    )

if __name__ == "__main__":
    params = create_random_params()
    # Example input: single scalar or 1-element vector
    x = np.array([0.5])
    output = forward(params, x)
    print("Network output:", output)