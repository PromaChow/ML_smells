import os
import json
import random
import numpy as np
import tensorflow as tf
from absl import app, flags, logging

FLAGS = flags.FLAGS

flags.DEFINE_string('data_dir', None, 'The input data dir. Should contain the data files.')
flags.DEFINE_string('output_dir', None, 'The output directory where the model checkpoints will be written.')
flags.DEFINE_string('task_name', None, 'The name of the task to train.')
flags.DEFINE_string('vocab_file', None, 'The vocabulary file that the BERT model was trained on.')
flags.DEFINE_string('bert_config_file', None, 'BERT config file')
flags.DEFINE_string('init_checkpoint', None, 'Initial checkpoint (usually from a pre-trained BERT model)')
flags.DEFINE_integer('max_seq_length', 128, 'Maximum sequence length')
flags.DEFINE_integer('train_batch_size', 32, 'Batch size for training.')
flags.DEFINE_integer('eval_batch_size', 32, 'Batch size for eval.')
flags.DEFINE_integer('predict_batch_size', 32, 'Batch size for prediction.')
flags.DEFINE_float('learning_rate', 2e-5, 'The initial learning rate for Adam.')
flags.DEFINE_float('warmup_proportion', 0.1, 'Proportion of training to perform linear learning rate warmup for.')
flags.DEFINE_integer('num_train_epochs', 3, 'Total number of training epochs to perform.')
flags.DEFINE_boolean('do_train', False, 'Whether to run training.')
flags.DEFINE_boolean('do_eval', False, 'Whether to run eval on the dev set.')
flags.DEFINE_boolean('do_predict', False, 'Whether to run predictions on the test set.')
flags.DEFINE_string('eval_data_file', None, 'The eval data file.')
flags.DEFINE_string('predict_data_file', None, 'The predict data file.')
flags.DEFINE_boolean('use_tpu', False, 'Whether to use TPU.')
flags.DEFINE_integer('num_tpu_cores', 8, 'Number of TPU cores.')
flags.DEFINE_string('tpu_name', None, 'Name of the TPU to use.')
flags.DEFINE_string('project', None, 'Project name for TPU.')
flags.DEFINE_string('zone', None, 'Zone of the TPU.')
flags.DEFINE_integer('save_checkpoints_steps', 1000, 'How often to save checkpoints.')
flags.DEFINE_integer('iterations_per_loop', 2000, 'Iterations per loop for TPUEstimator.')

SEED = 0
random.seed(SEED)
np.random.seed(SEED)
tf.random.set_seed(SEED)

class InputExample(object):
    def __init__(self, guid, text_a, text_b=None, label=None):
        self.guid = guid
        self.text_a = text_a
        self.text_b = text_b
        self.label = label

class InputFeatures(object):
    def __init__(self, input_ids, input_mask, segment_ids, label_id):
        self.input_ids = input_ids
        self.input_mask = input_mask
        self.segment_ids = segment_ids
        self.label_id = label_id

class QcFineProcessor:
    def get_labels(self):
        return ['0', '1']

    def get_train_examples(self, data_dir):
        return self._create_examples(self._read_data(os.path.join(data_dir, 'train.txt')), 'train')

    def get_dev_examples(self, data_dir):
        return self._create_examples(self._read_data(os.path.join(data_dir, 'dev.txt')), 'dev')

    def get_test_examples(self, data_dir):
        return self._create_examples(self._read_data(os.path.join(data_dir, 'test.txt')), 'test')

    def _read_data(self, input_file):
        examples = []
        with open(input_file, 'r', encoding='utf-8') as f:
            for line in f:
                parts = line.strip().split('\t')
                if len(parts) == 2:
                    guid, text = parts
                    label = None
                elif len(parts) == 3:
                    guid, text, label = parts
                else:
                    continue
                examples.append((guid, text, label))
        return examples

    def _create_examples(self, lines, set_type):
        examples = []
        for (guid, text, label) in lines:
            examples.append(InputExample(guid=guid, text_a=text, label=label))
        return examples

def convert_examples_to_features(examples, label_list, max_seq_length, tokenizer):
    label_map = {label: i for i, label in enumerate(label_list)}
    features = []
    for ex_index, example in enumerate(examples):
        tokens_a = tokenizer.tokenize(example.text_a)
        if example.text_b:
            tokens_b = tokenizer.tokenize(example.text_b)
            _truncate_seq_pair(tokens_a, tokens_b, max_seq_length - 3)
            tokens = ['[CLS]'] + tokens_a + ['[SEP]'] + tokens_b + ['[SEP]']
            segment_ids = [0] * (len(tokens_a) + 2) + [1] * (len(tokens_b) + 1)
        else:
            _truncate_seq_pair(tokens_a, [], max_seq_length - 2)
            tokens = ['[CLS]'] + tokens_a + ['[SEP]']
            segment_ids = [0] * (len(tokens_a) + 2)
        input_ids = tokenizer.convert_tokens_to_ids(tokens)
        input_mask = [1] * len(input_ids)
        padding_length = max_seq_length - len(input_ids)
        input_ids += [0] * padding_length
        input_mask += [0] * padding_length
        segment_ids += [0] * padding_length
        label_id = label_map[example.label] if example.label else -1
        features.append(InputFeatures(input_ids=input_ids, input_mask=input_mask,
                                      segment_ids=segment_ids, label_id=label_id))
    return features

def _truncate_seq_pair(tokens_a, tokens_b, max_length):
    while True:
        total_length = len(tokens_a) + len(tokens_b)
        if total_length <= max_length:
            break
        if len(tokens_a) > len(tokens_b):
            tokens_a.pop()
        else:
            tokens_b.pop()

def file_based_input_fn_builder(input_file, seq_length, is_training, drop_remainder):
    def _decode_record(record):
        name_to_features = {
            'input_ids': tf.io.FixedLenFeature([seq_length], tf.int64),
            'input_mask': tf.io.FixedLenFeature([seq_length], tf.int64),
            'segment_ids': tf.io.FixedLenFeature([seq_length], tf.int64),
            'label_ids': tf.io.FixedLenFeature([], tf.int64),
        }
        example = tf.io.parse_single_example(record, name_to_features)
        input_ids = tf.cast(example['input_ids'], tf.int32)
        input_mask = tf.cast(example['input_mask'], tf.int32)
        segment_ids = tf.cast(example['segment_ids'], tf.int32)
        label_ids = tf.cast(example['label_ids'], tf.int32)
        return ({'input_ids': input_ids,
                 'input_mask': input_mask,
                 'segment_ids': segment_ids},
                label_ids)

    dataset = tf.data.TFRecordDataset(input_file)
    if is_training:
        dataset = dataset.shuffle(buffer_size=10000)
    dataset = dataset.map(_decode_record, num_parallel_calls=tf.data.experimental.AUTOTUNE)
    dataset = dataset.batch(seq_length, drop_remainder=drop_remainder)
    dataset = dataset.prefetch(tf.data.experimental.AUTOTUNE)
    return dataset

def model_fn_builder(bert_config, init_checkpoint, learning_rate, num_train_steps,
                     num_warmup_steps, use_tpu, loss_fn, label_size):
    def model_fn(features, labels, mode, params):
        bert_model = tf.keras.models.load_model(init_checkpoint)
        input_ids = features['input_ids']
        input_mask = features['input_mask']
        segment_ids = features['segment_ids']
        pooled_output = bert_model([input_ids, segment_ids, input_mask], training=(mode == tf.estimator.ModeKeys.TRAIN))
        logits = tf.keras.layers.Dense(label_size, activation=None)(pooled_output)
        probs = tf.nn.softmax(logits)
        predicted_classes = tf.argmax(probs, axis=1, output_type=tf.int32)
        loss = None
        if mode == tf.estimator.ModeKeys.TRAIN:
            loss = loss_fn(labels, logits)
            optimizer = tf.keras.optimizers.Adam(learning_rate=learning_rate, epsilon=1e-6)
            train_op = optimizer.minimize(loss, var_list=tf.trainable_variables(), global_step=tf.train.get_or_create_global_step())
            return tf.estimator.EstimatorSpec(mode, loss=loss, train_op=train_op)
        elif mode == tf.estimator.ModeKeys.EVAL:
            eval_metrics = {
                'accuracy': tf.metrics.accuracy,
                'precision': tf.metrics.precision,
                'recall': tf.metrics.recall,
                'f1': tf.metrics.auc,
            }
            def metric_fn(labels, logits):
                predictions = tf.argmax(logits, axis=1, output_type=tf.int32)
                metrics = {}
                for name, fn in eval_metrics.items():
                    metrics[name] = fn(labels, predictions)
                return metrics
            return tf.estimator.EstimatorSpec(mode, loss=loss, eval_metric_ops=metric_fn(labels, logits))
        else:
            return tf.estimator.EstimatorSpec(mode, predictions=probs)
    return model_fn

def main(_):
    if not FLAGS.data_dir:
        raise ValueError('data_dir must be specified')
    if not FLAGS.task_name:
        raise ValueError('task_name must be specified')
    if not FLAGS.vocab_file:
        raise ValueError('vocab_file must be specified')
    if not FLAGS.bert_config_file:
        raise ValueError('bert_config_file must be specified')
    if not FLAGS.output_dir:
        raise ValueError('output_dir must be specified')

    processor = QcFineProcessor()
    label_list = processor.get_labels()
    label_size = len(label_list)

    tokenizer = tf.keras.preprocessing.text.Tokenizer(num_words=30522, oov_token='[UNK]')
    tokenizer.fit_on_texts(['[CLS]', '[SEP]', '[PAD]'])
    bert_config = json.load(open(FLAGS.bert_config_file))

    train_examples = processor.get_train_examples(FLAGS.data_dir) if FLAGS.do_train else None
    dev_examples = processor.get_dev_examples(FLAGS.data_dir) if FLAGS.do_eval else None
    test_examples = processor.get_test_examples(FLAGS.data_dir) if FLAGS.do_predict else None

    train_features = convert_examples_to_features(train_examples, label_list, FLAGS.max_seq_length, tokenizer) if FLAGS.do_train else None
    dev_features = convert_examples_to_features(dev_examples, label_list, FLAGS.max_seq_length, tokenizer) if FLAGS.do_eval else None
    test_features = convert_examples_to_features(test_examples, label_list, FLAGS.max_seq_length, tokenizer) if FLAGS.do_predict else None

    def _write_tfrecord(features, file_path):
        with tf.io.TFRecordWriter(file_path) as writer:
            for feat in features:
                example = tf.train.Example(features=tf.train.Features(feature={
                    'input_ids': tf.train.Feature(int64_list=tf.train.Int64List(value=feat.input_ids)),
                    'input_mask': tf.train.Feature(int64_list=tf.train.Int64List(value=feat.input_mask)),
                    'segment_ids': tf.train.Feature(int64_list=tf.train.Int64List(value=feat.segment_ids)),
                    'label_ids': tf.train.Feature(int64_list=tf.train.Int64List(value=[feat.label_id])),
                }))
                writer.write(example.SerializeToString())

    train_file = os.path.join(FLAGS.output_dir, 'train.tf_record')
    dev_file = os.path.join(FLAGS.output_dir, 'dev.tf_record')
    test_file = os.path.join(FLAGS.output_dir, 'test.tf_record')
    if FLAGS.do_train:
        _write_tfrecord(train_features, train_file)
    if FLAGS.do_eval:
        _write_tfrecord(dev_features, dev_file)
    if FLAGS.do_predict:
        _write_tfrecord(test_features, test_file)

    if FLAGS.use_tpu:
        tpu_cluster_resolver = tf.distribute.cluster_resolver.TPUClusterResolver(
            tpu=FLAGS.tpu_name, project=FLAGS.project, zone=FLAGS.zone)
        tf.config.experimental_connect_to_cluster(tpu_cluster_resolver)
        tf.tpu.experimental.initialize_tpu_system(tpu_cluster_resolver)
        strategy = tf.distribute.TPUStrategy(tpu_cluster_resolver)
    else:
        strategy = tf.distribute.get_strategy()

    with strategy.scope():
        global_step = tf.train.get_or_create_global_step()
        num_train_steps = int((len(train_features) if FLAGS.do_train else 0) * FLAGS.num_train_epochs / FLAGS.train_batch_size)
        num_warmup_steps = int(num_train_steps * FLAGS.warmup_proportion)

        def cross_entropy(labels, logits):
            loss = tf.nn.sparse_softmax_cross_entropy_with_logits(labels=labels, logits=logits)
            return tf.reduce_mean(loss)

        model_fn = model_fn_builder(bert_config, FLAGS.init_checkpoint, FLAGS.learning_rate,
                                    num_train_steps, num_warmup_steps, FLAGS.use_tpu,
                                    cross_entropy, label_size)

    run_config = tf.estimator.RunConfig(
        model_dir=FLAGS.output_dir,
        save_checkpoints_steps=FLAGS.save_checkpoints_steps,
        keep_checkpoint_max=5,
        train_distribute=strategy if FLAGS.use_tpu else None)

    estimator = tf.estimator.Estimator(model_fn=model_fn, config=run_config)

    if FLAGS.do_train:
        train_input_fn = tf.compat.v1.estimator.inputs.numpy_input_fn(
            x={'input_ids': np.array([f.input_ids for f in train_features]),
               'input_mask': np.array([f.input_mask for f in train_features]),
               'segment_ids': np.array([f.segment_ids for f in train_features])},
            y=np.array([f.label_id for f in train_features]),
            batch_size=FLAGS.train_batch_size,
            num_epochs=None,
            shuffle=True)
        estimator.train(input_fn=train_input_fn, steps=num_train_steps)

    if FLAGS.do_eval:
        eval_input_fn = tf.compat.v1.estimator.inputs.numpy_input_fn(
            x={'input_ids': np.array([f.input_ids for f in dev_features]),
               'input_mask': np.array([f.input_mask for f in dev_features]),
               'segment_ids': np.array([f.segment_ids for f in dev_features])},
            y=np.array([f.label_id for f in dev_features]),
            batch_size=FLAGS.eval_batch_size,
            num_epochs=1,
            shuffle=False)
        eval_results = estimator.evaluate(input_fn=eval_input_fn)
        eval_file = os.path.join(FLAGS.output_dir, 'eval_results.txt')
        with open(eval_file, 'w') as f:
            for key, value in eval_results.items():
                f.write(f'{key}: {value}\n')

    if FLAGS.do_predict:
        predict_input_fn = tf.compat.v1.estimator.inputs.numpy_input_fn(
            x={'input_ids': np.array([f.input_ids for f in test_features]),
               'input_mask': np.array([f.input_mask for f in test_features]),
               'segment_ids': np.array([f.segment_ids for f in test_features])},
            batch_size=FLAGS.predict_batch_size,
            num_epochs=1,
            shuffle=False)
        predictions = estimator.predict(input_fn=predict_input_fn)
        predict_file = os.path.join(FLAGS.output_dir, 'predictions.tsv')
        with open(predict_file, 'w') as f:
            for pred in predictions:
                probs = pred['softmax_tensor']
                f.write('\t'.join([str(p) for p in probs]) + '\n')

if __name__ == '__main__':
    tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.INFO)
    app.run(main)