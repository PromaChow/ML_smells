import gym
import numpy as np
import matplotlib.pyplot as plt
from dataclasses import dataclass, field

# Load the custom environment (assumed to be available as a module)
# from windy_gridworld import WindyGridworldEnv
# For demonstration, we create a placeholder environment
try:
    from windy_gridworld import WindyGridworldEnv
except Exception:
    class WindyGridworldEnv(gym.Env):
        def __init__(self):
            super().__init__()
            self.observation_space = gym.spaces.Discrete(7 * 7)  # example
            self.action_space = gym.spaces.Discrete(4)
            self.state = 0
        def reset(self):
            self.state = 0
            return self.state
        def step(self, action):
            next_state = (self.state + action) % self.observation_space.n
            reward = -1
            done = next_state == self.observation_space.n - 1
            self.state = next_state
            return next_state, reward, done, {}

@dataclass
class EpisodeStats:
    episode_rewards: list = field(default_factory=list)
    episode_lengths: list = field(default_factory=list)

def create_epsilon_greedy_policy(Q, epsilon, num_actions):
    def policy(state):
        if state not in Q:
            Q[state] = np.zeros(num_actions)
        action_values = Q[state]
        best_action = np.argmax(action_values)
        probabilities = np.full(num_actions, epsilon / num_actions)
        probabilities[best_action] += 1.0 - epsilon
        return probabilities
    return policy

def q_learning(env, num_episodes=5, discount_factor=1.0, alpha=0.6, epsilon=0.1):
    Q = {}
    stats = EpisodeStats()
    num_actions = env.action_space.n
    policy = create_epsilon_greedy_policy(Q, epsilon, num_actions)

    for episode in range(num_episodes):
        state = env.reset()
        episode_reward = 0
        episode_length = 0

        while True:
            probs = policy(state)
            action = np.random.choice(num_actions, p=probs)
            next_state, reward, done, _ = env.step(action)

            if next_state not in Q:
                Q[next_state] = np.zeros(num_actions)

            best_next_action = np.argmax(Q[next_state])
            td_target = reward + discount_factor * Q[next_state][best_next_action]
            td_error = td_target - Q[state][action]
            Q[state][action] += alpha * td_error

            episode_reward += reward
            episode_length += 1
            state = next_state

            if done:
                break

        stats.episode_rewards.append(episode_reward)
        stats.episode_lengths.append(episode_length)

    return Q, stats

def plot_episode_stats(stats):
    plt.style.use('ggplot')
    fig, ax1 = plt.subplots(figsize=(10, 4))
    episodes = np.arange(1, len(stats.episode_rewards) + 1)

    ax1.plot(episodes, stats.episode_rewards, marker='o', label='Reward')
    ax1.set_xlabel('Episode')
    ax1.set_ylabel('Total Reward')
    ax1.set_title('Episode Rewards and Lengths')
    ax1.grid(True)

    ax2 = ax1.twinx()
    ax2.plot(episodes, stats.episode_lengths, marker='x', color='red', label='Length')
    ax2.set_ylabel('Episode Length')

    fig.legend(loc='upper right')
    plt.show()

if __name__ == "__main__":
    env = WindyGridworldEnv()
    Q, stats = q_learning(env, num_episodes=5, discount_factor=1.0, alpha=0.6, epsilon=0.1)
    plot_episode_stats(stats)