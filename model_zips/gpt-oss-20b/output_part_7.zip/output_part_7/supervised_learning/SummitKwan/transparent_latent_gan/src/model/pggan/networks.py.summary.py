import math
import torch
import torch.nn as nn
import torch.nn.functional as F


def lerp(a, b, t):
    return a + (b - a) * t


def lerp_clip(a, b, t, low=0.0, high=1.0):
    t = torch.clamp(t, low, high)
    return lerp(a, b, t)


def cset(condition, true_fn, false_fn=None):
    if false_fn is None:
        return true_fn if condition else lambda *x, **k: x
    return true_fn if condition else false_fn


def get_weight(shape, gain=1.0, use_wscale=True, dtype=torch.float32):
    fan_in = math.prod(shape[1:])
    init = torch.randn(shape, dtype=dtype) * gain / math.sqrt(fan_in)
    if use_wscale:
        init = init * math.sqrt(gain * 2.0 / fan_in)
    return nn.Parameter(init)


def dense(x, out_features, use_wscale=True, use_bias=True, dtype=torch.float32, name="dense"):
    in_features = x.shape[-1]
    w = get_weight((out_features, in_features), dtype=dtype, name=name + "_w")
    y = F.linear(x, w)
    if use_bias:
        b = nn.Parameter(torch.zeros(out_features, dtype=dtype))
        y = y + b
    return y


def conv2d(x, out_channels, kernel_size, stride=1, padding=0,
          use_wscale=True, use_bias=True, dtype=torch.float32, name="conv"):
    in_channels = x.shape[1]
    w = get_weight((out_channels, in_channels, kernel_size, kernel_size),
                   dtype=dtype, name=name + "_w")
    y = F.conv2d(x, w, stride=stride, padding=padding)
    if use_bias:
        b = nn.Parameter(torch.zeros(out_channels, dtype=dtype))
        y = y + b
    return y


def apply_bias(x, use_bias=True, dtype=torch.float32, name="bias"):
    if not use_bias:
        return x
    b = nn.Parameter(torch.zeros(x.shape[1], dtype=dtype), name=name)
    return x + b


def leaky_relu(x, negative_slope=0.2):
    return F.leaky_relu(x, negative_slope)


def upscale2d(x, scale=2):
    return F.interpolate(x, scale_factor=scale, mode='nearest')


def downscale2d(x, scale=2):
    return F.avg_pool2d(x, kernel_size=scale, stride=scale)


def upscale2d_conv2d(x, out_channels, kernel_size, stride=1, padding=0,
                     use_wscale=True, use_bias=True, dtype=torch.float32,
                     name="upconv"):
    x = upscale2d(x)
    return conv2d(x, out_channels, kernel_size, stride, padding,
                  use_wscale, use_bias, dtype, name=name)


def conv2d_downscale2d(x, out_channels, kernel_size, stride=1, padding=0,
                       use_wscale=True, use_bias=True, dtype=torch.float32,
                       name="convdown"):
    x = conv2d(x, out_channels, kernel_size, stride, padding,
               use_wscale, use_bias, dtype, name=name)
    return downscale2d(x)


def pixel_norm(x, eps=1e-8):
    return x / torch.sqrt(torch.mean(x ** 2, dim=1, keepdim=True) + eps)


def minibatch_stddev_layer(x, group_size=4, num_new=1, eps=1e-8):
    N, C, H, W = x.shape
    G = min(group_size, N)
    y = x.view(G, -1, num_new, C // num_new, H, W)
    y = torch.mean(y, dim=0, keepdim=True)
    y = torch.mean((y - torch.mean(y, dim=1, keepdim=True)) ** 2, dim=1, keepdim=True)
    y = torch.sqrt(y + eps)
    y = y.repeat(G, 1, H, W)
    y = y.view(N, num_new, H, W)
    y = y.repeat(1, C // num_new, 1, 1)
    return torch.cat([x, y], dim=1)


def nf(stage, fmap_base=8192, fmap_decay=1.0, fmap_max=512):
    return min(int(fmap_base / (2.0 ** (stage * fmap_decay))), fmap_max)


class G_paper(nn.Module):
    def __init__(self, latent_dim=512, num_channels=3,
                 resolution=1024, fmap_base=8192, fmap_decay=1.0, fmap_max=512,
                 use_pixelnorm=True, use_leakyrelu=True):
        super().__init__()
        self.latent_dim = latent_dim
        self.num_channels = num_channels
        self.resolution = resolution
        self.fmap_base = fmap_base
        self.fmap_decay = fmap_decay
        self.fmap_max = fmap_max
        self.use_pixelnorm = use_pixelnorm
        self.use_leakyrelu = use_leakyrelu

        self.lod = nn.Parameter(torch.tensor(0.0))
        self.blocks = nn.ModuleDict()
        self.torgb_layers = nn.ModuleDict()

        max_res_log2 = int(math.log2(self.resolution))
        for res in range(2, max_res_log2 + 1):
            stage = res
            in_channels = nf(stage)
            out_channels = nf(stage - 1)
            self.blocks[str(res)] = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, 3, padding=1),
                nn.LeakyReLU(0.2) if self.use_leakyrelu else nn.ReLU()
            )
            self.torgb_layers[str(res)] = nn.Conv2d(out_channels, self.num_channels, 1)

        self.initial_dense = nn.Linear(self.latent_dim, nf(2) * 4 * 4)

    def forward(self, z, labels=None):
        x = self.initial_dense(z)
        if self.use_pixelnorm:
            x = pixel_norm(x)
        x = x.view(-1, nf(2), 4, 4)

        lod = self.lod
        cur_res = 4
        prev_rgb = None

        for res in range(3, int(math.log2(self.resolution)) + 1):
            stage = res
            if res == 3:
                x = upscale2d_conv2d(x, nf(stage - 1), 3, name=f"upconv_{res}")
            else:
                x = upscale2d_conv2d(x, nf(stage - 1), 3, name=f"upconv_{res}")
                x = self.blocks[str(res)](x)
            rgb = self.torgb_layers[str(res)](x)
            if prev_rgb is not None:
                rgb = lerp_clip(prev_rgb, rgb, lod, low=0.0, high=1.0)
            prev_rgb = rgb
            cur_res *= 2

        return prev_rgb


class D_paper(nn.Module):
    def __init__(self, num_channels=3, resolution=1024,
                 fmap_base=8192, fmap_decay=1.0, fmap_max=512,
                 mbstd_group_size=4, use_leakyrelu=True):
        super().__init__()
        self.num_channels = num_channels
        self.resolution = resolution
        self.fmap_base = fmap_base
        self.fmap_decay = fmap_decay
        self.fmap_max = fmap_max
        self.mbstd_group_size = mbstd_group_size
        self.use_leakyrelu = use_leakyrelu

        self.lod = nn.Parameter(torch.tensor(0.0))
        self.blocks = nn.ModuleDict()
        self.fromrgb_layers = nn.ModuleDict()

        max_res_log2 = int(math.log2(self.resolution))
        for res in range(max_res_log2, 1, -1):
            stage = res
            in_channels = nf(stage - 1)
            out_channels = nf(stage)
            self.blocks[str(res)] = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, 3, padding=1),
                nn.LeakyReLU(0.2) if self.use_leakyrelu else nn.ReLU()
            )
            self.fromrgb_layers[str(res)] = nn.Conv2d(self.num_channels, in_channels, 1)

        self.final_dense = nn.Linear(nf(2) * 4 * 4, 1)

    def forward(self, x):
        lod = self.lod
        cur_res = self.resolution
        stage = int(math.log2(cur_res))

        rgb = self.fromrgb_layers[str(stage)](x)
        x = rgb

        for res in range(stage, 2, -1):
            x = conv2d_downscale2d(x, nf(res - 1), 3, name=f"convdown_{res}")
            if res > 3:
                x = self.blocks[str(res)](x)
            else:
                x = conv2d_downscale2d(x, nf(res - 1), 3, name=f"convdown_{res}")

            if res == 3:
                if self.mbstd_group_size > 0:
                    x = minibatch_stddev_layer(x, group_size=self.mbstd_group_size)
                rgb = self.fromrgb_layers[str(res - 1)](x)
                x = torch.cat([rgb, x], dim=1)

        x = x.view(x.size(0), -1)
        logits = self.final_dense(x)
        return logits.squeeze(1)<|reserved_200016|>#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Simple implementation of a ResNet‑50 backbone that
exposes an `extract_features` method for easy use in
image‑classification or object‑detection pipelines.

The code is deliberately compact yet fully typed, fully
Python‑3.12‑compatible, and suitable for integration into
any project that requires a lightweight ResNet encoder.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Iterable, List, Tuple

import torch
from torch import nn
from torch.nn import functional as F

__all__ = [
    "ResNet50Backbone",
    "ConvBlock",
    "Bottleneck",
    "create_resnet50_backbone",
]


@dataclass
class ConvBlock:
    """A single 1x1/3x3/1x1 convolution block used inside a Bottleneck.

    The class implements ``forward`` directly for speed and avoids
    the overhead of ``nn.Sequential``.  It uses the same padding
    strategy as the reference implementation: ``padding=1`` for 3x3
    convolutions and ``padding=0`` for 1x1 convolutions.
    """

    in_channels: int
    out_channels: int
    stride: int = 1
    dilation: int = 1

    def __post_init__(self):
        self.conv1 = nn.Conv2d(
            self.in_channels,
            self.out_channels,
            kernel_size=1,
            stride=1,
            padding=0,
            bias=False,
        )
        self.bn1 = nn.BatchNorm2d(self.out_channels)
        self.conv2 = nn.Conv2d(
            self.out_channels,
            self.out_channels,
            kernel_size=3,
            stride=self.stride,
            padding=self.dilation,
            bias=False,
            dilation=self.dilation,
        )
        self.bn2 = nn.BatchNorm2d(self.out_channels)
        self.conv3 = nn.Conv2d(
            self.out_channels,
            self.out_channels * 4,
            kernel_size=1,
            stride=1,
            padding=0,
            bias=False,
        )
        self.bn3 = nn.BatchNorm2d(self.out_channels * 4)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        y = self.relu(self.bn1(self.conv1(x)))
        y = self.relu(self.bn2(self.conv2(y)))
        y = self.relu(self.bn3(self.conv3(y)))
        return y


@dataclass
class Bottleneck:
    """A ResNet bottleneck block with optional down‑sampling."""

    in_channels: int
    out_channels: int
    stride: int = 1
    dilation: int = 1

    def __post_init__(self):
        self.conv_block = ConvBlock(
            self.in_channels,
            self.out_channels,
            stride=self.stride,
            dilation=self.dilation,
        )
        if self.stride != 1 or self.in_channels != self.out_channels * 4:
            self.downsample = nn.Sequential(
                nn.Conv2d(
                    self.in_channels,
                    self.out_channels * 4,
                    kernel_size=1,
                    stride=self.stride,
                    bias=False,
                ),
                nn.BatchNorm2d(self.out_channels * 4),
            )
        else:
            self.downsample = nn.Identity()

        self.relu = nn.ReLU(inplace=True)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = self.downsample(x)
        out = self.conv_block(x)
        out = self.relu(out + residual)
        return out


class ResNet50Backbone(nn.Module):
    """
    Lightweight ResNet‑50 backbone for feature extraction.

    Parameters
    ----------
    pretrained : bool, optional
        If True, initialise the model with weights from
        :class:`torchvision.models.resnet50` (requires internet
        access).  Default: False.
    """

    def __init__(self, pretrained: bool = False):
        super().__init__()

        self.stem = nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3, bias=False),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(kernel_size=3, stride=2, padding=1),
        )

        self.layer1 = self._make_layer(64, 64, blocks=3, stride=1)
        self.layer2 = self._make_layer(256, 128, blocks=4, stride=2)
        self.layer3 = self._make_layer(512, 256, blocks=6, stride=2)
        self.layer4 = self._make_layer(1024, 512, blocks=3, stride=2)

        if pretrained:
            self._load_pretrained()

    # ------------------------------------------------------------------ #
    # Construction helpers
    # ------------------------------------------------------------------ #
    @staticmethod
    def _make_layer(
        in_channels: int,
        out_channels: int,
        blocks: int,
        stride: int = 1,
        dilation: int = 1,
    ) -> nn.Sequential:
        layers: List[nn.Module] = []
        layers.append(
            Bottleneck(
                in_channels,
                out_channels,
                stride=stride,
                dilation=dilation,
            )
        )
        for _ in range(1, blocks):
            layers.append(
                Bottleneck(
                    out_channels * 4,
                    out_channels,
                    stride=1,
                    dilation=dilation,
                )
            )
        return nn.Sequential(*layers)

    # ------------------------------------------------------------------ #
    # Forward logic
    # ------------------------------------------------------------------ #
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Standard forward that returns the final global average pooled vector."""
        x = self.stem(x)
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        x = F.adaptive_avg_pool2d(x, (1, 1))
        return torch.flatten(x, 1)

    def extract_features(
        self,
        x: torch.Tensor,
        return_intermediate: bool = False,
    ) -> torch.Tensor | List[torch.Tensor]:
        """Return a list of feature maps for all four stages.

        Parameters
        ----------
        x
            Input image tensor with shape ``(N, 3, H, W)``.
        return_intermediate
            If ``True`` return the intermediate maps
            ``[c1, c2, c3, c4]`` where each ``c`` has
            the same number of channels as the output of the
            corresponding ``layerX``.  Otherwise return the
            flattened global average pooled representation.

        Returns
        -------
        torch.Tensor | List[torch.Tensor]
            Either a single vector (``N, 2048``) or a list of four
            feature maps.
        """
        x = self.stem(x)
        c1 = self.layer1(x)
        c2 = self.layer2(c1)
        c3 = self.layer3(c2)
        c4 = self.layer4(c3)

        if return_intermediate:
            return [c1, c2, c3, c4]

        c4 = F.adaptive_avg_pool2d(c4, (1, 1))
        return torch.flatten(c4, 1)

    # ------------------------------------------------------------------ #
    # Utility helpers
    # ------------------------------------------------------------------ #
    def _load_pretrained(self) -> None:
        """Load ImageNet weights from torchvision and copy them over."""
        import torchvision

        state = torchvision.models.resnet50(pretrained=True).state_dict()
        own_state = self.state_dict()
        for name, param in state.items():
            if name in own_state:
                if isinstance(param, torch.Tensor):
                    own_state[name].copy_(param)
                else:
                    own_state[name].copy_(param.data)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({sum(p.numel() for p in self.parameters())} parameters)"


# --------------------------------------------------------------------------- #
# Public factory function
# --------------------------------------------------------------------------- #
def create_resnet50_backbone(pretrained: bool = False) -> ResNet50Backbone:
    """Convenience wrapper that returns a :class:`ResNet50Backbone` instance."""
    return ResNet50Backbone(pretrained=pretrained)


# --------------------------------------------------------------------------- #
# Self‑test when executed as a script
# --------------------------------------------------------------------------- #
if __name__ == "__main__":
    net = create_resnet50_backbone()
    dummy = torch.randn(2, 3, 224, 224)
    out = net.extract_features(dummy)
    print(f"Output shape: {out.shape}")  # should be (2, 2048)

    features = net.extract_features(dummy, return_intermediate=True)
    for i, f in enumerate(features, 1):
        print(f"Stage {i} feature map shape: {f.shape}")

*** End of code block ***