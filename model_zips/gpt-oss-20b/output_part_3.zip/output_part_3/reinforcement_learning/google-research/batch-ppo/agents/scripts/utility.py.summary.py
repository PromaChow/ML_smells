import os
import re
import yaml
import logging
import tensorflow as tf
from typing import Dict, Any, List, Optional

# Disable eager execution to use TF1 style graph
tf.compat.v1.disable_eager_execution()

# Simple attribute-access dictionary
class AttrDict(dict):
    def __getattr__(self, item):
        try:
            return self[item]
        except KeyError as e:
            raise AttributeError(item) from e

    def __setattr__(self, key, value):
        self[key] = value


# Placeholder environment wrappers
class BatchEnv:
    def __init__(self, envs: List[Any]):
        self.envs = envs


class InGraphBatchEnv:
    def __init__(self, env: Any):
        self.env = env


# Assume tools.simulate exists
try:
    from tools import simulate  # type: ignore
except Exception:
    # Minimal mock if tools is unavailable
    def simulate(algo):
        return {
            "done": tf.constant(False),
            "score": tf.constant(0.0),
            "summary": tf.summary.scalar("score", tf.constant(0.0)),
        }


def define_simulation_graph(algo_cls, config: Dict[str, Any], **kwargs) -> AttrDict:
    """
    Constructs the simulation graph for a given algorithm class and configuration.
    """
    graph_elements = AttrDict()
    with tf.Graph().as_default() as g:
        # Global variables
        graph_elements.step = tf.compat.v1.get_variable(
            "step", shape=[], dtype=tf.int32, initializer=tf.zeros_initializer()
        )
        graph_elements.is_training = tf.compat.v1.placeholder(
            tf.bool, shape=[], name="is_training"
        )
        graph_elements.should_log = tf.compat.v1.placeholder(
            tf.bool, shape=[], name="should_log"
        )

        # Instantiate algorithm
        algo = algo_cls(config)
        graph_elements.algo = algo

        # Simulate environment interaction
        simulation_output = simulate(algo)
        for key, val in simulation_output.items():
            graph_elements[key] = val

        # Log number of trainable variables
        num_vars = tf.compat.v1.trainable_variables()
        graph_elements.num_trainable_vars = tf.size(tf.stack(num_vars))

        logging.info(f"Graph contains {len(num_vars)} trainable variables.")
    return graph_elements


def create_batch_env(env_cls, batch_size: int, external: bool = True) -> BatchEnv:
    """
    Creates a batch of environments either as external processes or in-graph.
    """
    envs = []
    for _ in range(batch_size):
        if external:
            envs.append(env_cls())
        else:
            envs.append(InGraphBatchEnv(env_cls()))
    return BatchEnv(envs)


def saver_for_variables(
    variables: Optional[List[tf.Variable]] = None,
    exclude_regex: Optional[str] = None,
) -> tf.compat.v1.train.Saver:
    """
    Creates a TF Saver that excludes variables matching a regex pattern.
    """
    if variables is None:
        variables = tf.compat.v1.trainable_variables()
    if exclude_regex:
        pattern = re.compile(exclude_regex)
        variables = [v for v in variables if not pattern.search(v.name)]
    return tf.compat.v1.train.Saver(var_list=variables)


def init_or_restore(
    sess: tf.compat.v1.Session,
    saver: tf.compat.v1.train.Saver,
    logdir: str,
    resume: bool = False,
) -> None:
    """
    Initializes all variables or restores from a checkpoint.
    """
    sess.run(tf.compat.v1.global_variables_initializer())
    sess.run(tf.compat.v1.local_variables_initializer())

    ckpt = tf.train.get_checkpoint_state(logdir)
    if resume:
        if ckpt and ckpt.model_checkpoint_path:
            saver.restore(sess, ckpt.model_checkpoint_path)
            logging.info(f"Restored from checkpoint: {ckpt.model_checkpoint_path}")
        else:
            raise FileNotFoundError(
                f"Attempted to resume, but no checkpoint found in {logdir}"
            )
    else:
        logging.info("Starting a new run; variables initialized.")


def save_config(config: Dict[str, Any], logdir: str) -> None:
    """
    Saves configuration dictionary to YAML in the specified logdir.
    """
    os.makedirs(logdir, exist_ok=True)
    config_path = os.path.join(logdir, "config.yaml")
    with open(config_path, "w") as f:
        yaml.safe_dump(config, f)
    logging.info(f"Configuration saved to {config_path}")


def load_config(logdir: str) -> Optional[Dict[str, Any]]:
    """
    Loads configuration from YAML if it exists in the logdir.
    """
    config_path = os.path.join(logdir, "config.yaml")
    if os.path.exists(config_path):
        with open(config_path, "r") as f:
            config = yaml.safe_load(f)
        logging.info(f"Configuration loaded from {config_path}")
        return config
    logging.warning(f"No configuration file found in {logdir}")
    return None


def setup_logging():
    """
    Configures TensorFlow logging to output INFO level messages and
    disables propagation to the root logger.
    """
    tf_logger = logging.getLogger("tensorflow")
    tf_logger.setLevel(logging.INFO)
    tf_logger.propagate = False
    # Also configure root logger for consistency
    logging.basicConfig(
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        level=logging.INFO,
    )


# Example usage
if __name__ == "__main__":
    setup_logging()

    # Dummy algorithm class
    class DummyAlgo:
        def __init__(self, config):
            self.config = config

    # Dummy environment class
    class DummyEnv:
        pass

    config = {"learning_rate": 0.001}
    logdir = "./logs/run1"

    # Save configuration
    save_config(config, logdir)

    # Load configuration
    loaded_config = load_config(logdir) or config

    # Create simulation graph
    graph = define_simulation_graph(DummyAlgo, loaded_config)

    # Create batch environment
    batch_env = create_batch_env(DummyEnv, batch_size=4, external=False)

    # Create saver
    saver = saver_for_variables(exclude_regex=r"optimizer")

    # Start session
    with tf.compat.v1.Session() as sess:
        init_or_restore(sess, saver, logdir, resume=False)

        # Example training loop
        for step in range(10):
            # Run training step
            feed = {graph.is_training: True, graph.should_log: True}
            sess.run([graph.step], feed_dict=feed)
            if step % 5 == 0:
                summary = sess.run(graph.summary, feed_dict=feed)
                # Normally you'd write summary to TensorBoard here

        # Save checkpoint
        ckpt_path = os.path.join(logdir, "model.ckpt")
        saver.save(sess, ckpt_path)
        logging.info(f"Checkpoint saved at {ckpt_path}")
