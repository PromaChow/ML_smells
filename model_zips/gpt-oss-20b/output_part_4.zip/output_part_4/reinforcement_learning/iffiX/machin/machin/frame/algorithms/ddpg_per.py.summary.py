import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np

# Assume these classes are defined elsewhere in the project
from ddpg import DDPG  # Base DDPG implementation
from buffer import PrioritizedBuffer  # Prioritized experience replay buffer


class DDPGPer(DDPG):
    def __init__(self, cfg=None, device=None, replay_buffer=None):
        super().__init__(cfg=cfg, device=device)
        # Use a PrioritizedBuffer if none provided
        if replay_buffer is None:
            self.replay_buffer = PrioritizedBuffer()
        else:
            self.replay_buffer = replay_buffer

        # Ensure the criterion uses element-wise loss for importance sampling
        if getattr(self.criterion, "reduction", None) != "none":
            self.criterion.reduction = "none"

        # Optional visualization directory
        self.visualization_dir = cfg.get("visualization_dir") if cfg else None

    def update(self, batch_size, update_value=True, update_policy=True, update_steps=None):
        # Sample from prioritized buffer
        (
            states,
            actions,
            rewards,
            next_states,
            dones,
            weights,
            indices,
        ) = self.replay_buffer.sample(batch_size)

        states = torch.tensor(states, dtype=torch.float32, device=self.device)
        actions = torch.tensor(actions, dtype=torch.float32, device=self.device)
        rewards = torch.tensor(rewards, dtype=torch.float32, device=self.device).unsqueeze(1)
        next_states = torch.tensor(next_states, dtype=torch.float32, device=self.device)
        dones = torch.tensor(dones, dtype=torch.float32, device=self.device).unsqueeze(1)
        weights = torch.tensor(weights, dtype=torch.float32, device=self.device).unsqueeze(1)

        # Critic target Q value
        with torch.no_grad():
            next_actions = self.target_actor(next_states)
            q_next = self.target_critic(next_states, next_actions)
            y = rewards + self.gamma * (1 - dones) * q_next

        # Critic loss with importance sampling weights
        q_current = self.critic(states, actions)
        critic_loss_elements = self.criterion(q_current, y)
        critic_loss = (critic_loss_elements * weights).mean()

        if update_value:
            self.optimizer_critic.zero_grad()
            critic_loss.backward()
            self.optimizer_critic.step()

        # Actor loss
        actor_loss = -self.critic(states, self.actor(states)).mean()

        if update_policy:
            self.optimizer_actor.zero_grad()
            actor_loss.backward()
            self.optimizer_actor.step()

        # Update priorities in buffer
        with torch.no_grad():
            td_error = torch.abs(q_current - y).cpu().numpy().squeeze()
            priorities = td_error + 1e-6  # small constant to avoid zero priority
            self.replay_buffer.update_priorities(indices, priorities)

        # Target network update
        if update_steps is not None and update_steps > 0:
            # Hard update every `update_steps` iterations
            if self.step % update_steps == 0:
                self.target_actor.load_state_dict(self.actor.state_dict())
                self.target_critic.load_state_dict(self.critic.state_dict())
        else:
            # Soft update
            for target_param, param in zip(self.target_actor.parameters(), self.actor.parameters()):
                target_param.data.copy_(self.update_rate * param.data + (1 - self.update_rate) * target_param.data)
            for target_param, param in zip(self.target_critic.parameters(), self.critic.parameters()):
                target_param.data.copy_(self.update_rate * param.data + (1 - self.update_rate) * target_param.data)

        # Visualization (placeholder)
        if self.visualization_dir is not None:
            self._visualize(actor_loss.item(), critic_loss.item())

        self.step += 1

    def _visualize(self, actor_loss, critic_loss):
        # Simple logging; replace with actual plotting if needed
        log_path = f"{self.visualization_dir}/loss_log.txt"
        with open(log_path, "a") as f:
            f.write(f"Step {self.step}: Actor loss = {actor_loss:.4f}, Critic loss = {critic_loss:.4f}\n")

    @staticmethod
    def generate_config():
        cfg = DDPG.generate_config()
        cfg["frame"] = "DDPGPer"
        return cfg

    @classmethod
    def init_from_config(cls, cfg, device=None):
        # Instantiate models
        actor = cls._build_actor(cfg)
        critic = cls._build_critic(cfg)

        # Instantiate optimizers
        optimizer_actor = optim.Adam(actor.parameters(), lr=cfg["actor_lr"])
        optimizer_critic = optim.Adam(critic.parameters(), lr=cfg["critic_lr"])

        # Criterion
        criterion = nn.MSELoss(reduction="none")

        # Ensure reduction is none for importance sampling
        if criterion.reduction != "none":
            criterion.reduction = "none"

        # Build the class instance
        instance = cls(
            cfg=cfg,
            device=device,
            replay_buffer=PrioritizedBuffer(),
        )
        instance.actor = actor
        instance.critic = critic
        instance.target_actor = nn.Module()
        instance.target_critic = nn.Module()
        instance.target_actor.load_state_dict(actor.state_dict())
        instance.target_critic.load_state_dict(critic.state_dict())
        instance.optimizer_actor = optimizer_actor
        instance.optimizer_critic = optimizer_critic
        instance.criterion = criterion
        instance.gamma = cfg.get("gamma", 0.99)
        instance.update_rate = cfg.get("update_rate", 0.005)
        instance.update_steps = cfg.get("update_steps", None)
        instance.step = 0
        instance.visualization_dir = cfg.get("visualization_dir")
        return instance

    @staticmethod
    def _build_actor(cfg):
        # Placeholder: build actor network based on cfg
        layers = []
        input_dim = cfg["state_dim"]
        output_dim = cfg["action_dim"]
        hidden_dims = cfg.get("actor_hidden_dims", [400, 300])
        for hidden in hidden_dims:
            layers.append(nn.Linear(input_dim, hidden))
            layers.append(nn.ReLU())
            input_dim = hidden
        layers.append(nn.Linear(input_dim, output_dim))
        layers.append(nn.Tanh())
        return nn.Sequential(*layers)

    @staticmethod
    def _build_critic(cfg):
        # Placeholder: build critic network based on cfg
        layers = []
        input_dim = cfg["state_dim"] + cfg["action_dim"]
        hidden_dims = cfg.get("critic_hidden_dims", [400, 300])
        for hidden in hidden_dims:
            layers.append(nn.Linear(input_dim, hidden))
            layers.append(nn.ReLU())
            input_dim = hidden
        layers.append(nn.Linear(input_dim, 1))
        return nn.Sequential(*layers)