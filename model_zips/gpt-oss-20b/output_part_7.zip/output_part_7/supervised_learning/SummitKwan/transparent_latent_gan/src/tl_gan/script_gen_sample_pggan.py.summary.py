import os
import time
import numpy as np
import pickle
import tensorflow as tf

tf.compat.v1.disable_eager_execution()

# ----------------------------------------------------
# Configuration
# ----------------------------------------------------
MODEL_DIR = 'asset_model'
MODEL_FILENAME = 'karras2018iclr-celebahq-1024x1024.pkl'
MODEL_PATH = os.path.join(MODEL_DIR, MODEL_FILENAME)

OUTPUT_DIR_PKL = 'asset_results/pggan_celeba_sample_pkl'
OUTPUT_DIR_EXPLORE = 'asset_results/pggan_celeba_explore'

BATCH_SIZE = 32
NUM_BATCHES = 8000

# Optional visualization flag
yn_view_sample = False

# ----------------------------------------------------
# Prepare directories
# ----------------------------------------------------
os.makedirs(OUTPUT_DIR_PKL, exist_ok=True)
os.makedirs(OUTPUT_DIR_EXPLORE, exist_ok=True)

# ----------------------------------------------------
# Load the pre-trained model
# ----------------------------------------------------
if not os.path.exists(MODEL_PATH):
    raise RuntimeError(f"Pre-trained model not found at '{MODEL_PATH}'. "
                       f"Please download it from the official source and place it there.")

with open(MODEL_PATH, 'rb') as f:
    model_dict = pickle.load(f)

# Expect the dictionary to contain keys 'Gs' and 'D'
Gs = model_dict.get('Gs')
if Gs is None:
    raise KeyError("Key 'Gs' not found in the model pickle. "
                   "Ensure the file is a valid PG-GAN checkpoint.")
D = model_dict.get('D')  # not used directly in this script

# ----------------------------------------------------
# Sample generation
# ----------------------------------------------------
with tf.compat.v1.Session() as sess:
    # Create a dummy feed dict for the generator input shapes
    latent_shape = Gs.input_shapes[0][1:]  # shape of a single latent vector
    label_shape = Gs.input_shapes[1][1:]   # shape of a single label vector

    for batch_idx in range(NUM_BATCHES):
        start_time = time.time()

        # Generate random latents and dummy labels
        z = np.random.randn(BATCH_SIZE, *latent_shape).astype(np.float32)
        labels = np.zeros((BATCH_SIZE, *label_shape), dtype=np.float32)

        # Run generator
        outputs = Gs.run([Gs.components.G], feed_dict={
            Gs.input[0]: z,
            Gs.input[1]: labels
        })
        images = outputs[0]  # NCHW format

        # Post-process images
        # Scale from [-1, 1] to [0, 255] and clip
        images = ((images + 1.0) * 127.5).astype(np.float32)
        images = np.clip(images, 0, 255)

        # Transpose to NHWC
        images = np.transpose(images, (0, 2, 3, 1))

        # Subsample pixels: every 8th pixel starting at index 4
        images_subsampled = images[:, 4::8, 4::8, :]

        # Save results
        out_path = os.path.join(OUTPUT_DIR_PKL, f'batch_{batch_idx:05d}.pkl')
        with open(out_path, 'wb') as out_file:
            pickle.dump({'z': z, 'x': images_subsampled}, out_file)

        elapsed = time.time() - start_time
        print(f'Batch {batch_idx + 1}/{NUM_BATCHES} generated in {elapsed:.2f} seconds.')

# ----------------------------------------------------
# Optional visualization
# ----------------------------------------------------
if yn_view_sample:
    import matplotlib.pyplot as plt
    sample_path = os.path.join(OUTPUT_DIR_PKL, 'batch_00000.pkl')
    with open(sample_path, 'rb') as f:
        sample_data = pickle.load(f)
    img = sample_data['x'][0]
    plt.imshow(img.astype(np.uint8))
    plt.title('Sample Generated Image')
    plt.axis('off')
    plt.show()
