import torch
from torch.optim.lr_scheduler import LambdaLR

def linear_lr_scheduler(optimizer, N, min_lr):
    """Creates a linear learning rate scheduler that decreases the learning rate
    from its initial value to `min_lr` over `N` iterations."""
    initial_lr = optimizer.param_groups[0]['lr']
    scale_fn = lambda n: max(min_lr / initial_lr, 1 - n / N)
    scheduler = LambdaLR(optimizer, lr_lambda=scale_fn)
    return scheduler

