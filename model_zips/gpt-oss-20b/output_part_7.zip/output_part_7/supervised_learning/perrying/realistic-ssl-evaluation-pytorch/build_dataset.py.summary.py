import argparse
import os
import numpy as np
import torch
from torchvision import datasets, transforms

# Configuration
_DATA_DIR = "./data"
COUNTS = {
    "SVHN": {"train": 73257, "test": 26032, "extra": 531131, "validation": 5000},
    "CIFAR10": {"train": 50000, "test": 10000, "validation": 5000},
}
NUM_CLASSES = {"SVHN": 10, "CIFAR10": 10}


def parse_args():
    parser = argparse.ArgumentParser(description="Prepare semi-supervised splits.")
    parser.add_argument("--seed", type=int, default=0, help="Random seed")
    parser.add_argument(
        "--dataset", type=str, choices=["SVHN", "CIFAR10"], required=True, help="Dataset name"
    )
    parser.add_argument("--nlabels", type=int, default=100, help="Number of labeled samples per class")
    return parser.parse_args()


def load_svhn():
    train = datasets.SVHN(root=_DATA_DIR, split="train", download=True)
    test = datasets.SVHN(root=_DATA_DIR, split="test", download=True)
    extra = datasets.SVHN(root=_DATA_DIR, split="extra", download=True)
    def to_numpy(dataset):
        imgs = dataset.data.astype(np.float32)  # shape (N, H, W, C)
        imgs = imgs.transpose(0, 3, 1, 2)  # (N, C, H, W)
        lbls = np.array(dataset.labels, dtype=np.int64)
        return imgs, lbls
    return (to_numpy(train), to_numpy(test), to_numpy(extra))


def load_cifar10():
    transform = transforms.Compose([transforms.ToTensor()])  # for consistency; not used for numpy
    train = datasets.CIFAR10(root=_DATA_DIR, train=True, download=True)
    test = datasets.CIFAR10(root=_DATA_DIR, train=False, download=True)

    def to_numpy(dataset):
        imgs = [np.array(img) for img, _ in dataset]  # (H, W, C)
        imgs = np.stack(imgs, axis=0).astype(np.float32)  # (N, H, W, C)
        imgs = imgs.transpose(0, 3, 1, 2)  # (N, C, H, W)
        lbls = np.array([label for _, label in dataset], dtype=np.int64)
        return imgs, lbls

    train_imgs, train_lbls = to_numpy(train)
    test_imgs, test_lbls = to_numpy(test)

    # Global Contrast Normalization
    train_mean = train_imgs.mean(axis=(0, 2, 3), keepdims=True)
    train_std = train_imgs.std(axis=(0, 2, 3), keepdims=True)
    train_imgs = (train_imgs - train_mean) / (train_std + 1e-8)
    test_imgs = (test_imgs - train_mean) / (train_std + 1e-8)

    # ZCA Whitening
    N, C, H, W = train_imgs.shape
    flat_train = train_imgs.reshape(N, -1).T  # shape (C*H*W, N)
    cov = np.cov(flat_train, bias=True)
    epsilon = 1e-5
    U, S, _ = np.linalg.svd(cov)
    whitening_mat = U @ np.diag(1.0 / np.sqrt(S + epsilon)) @ U.T
    flat_train_whitened = whitening_mat @ flat_train
    train_imgs = flat_train_whitened.T.reshape(N, C, H, W)

    flat_test = test_imgs.reshape(test_imgs.shape[0], -1).T
    flat_test_whitened = whitening_mat @ flat_test
    test_imgs = flat_test_whitened.T.reshape(test_imgs.shape[0], C, H, W)

    return (train_imgs, train_lbls), (test_imgs, test_lbls), None


def split_l_u(data, nlabels, num_classes):
    imgs, lbls = data
    rng = np.random.default_rng()
    indices = rng.permutation(len(imgs))
    imgs = imgs[indices]
    lbls = lbls[indices]
    n_labels_per_cls = nlabels // num_classes
    labeled_idx = []
    unlabeled_idx = []
    for cls in range(num_classes):
        cls_mask = lbls == cls
        cls_indices = np.where(cls_mask)[0]
        if len(cls_indices) < n_labels_per_cls:
            raise ValueError(f"Not enough samples for class {cls}")
        labeled_idx.extend(cls_indices[:n_labels_per_cls])
        unlabeled_idx.extend(cls_indices[n_labels_per_cls:])
    labeled_idx = np.array(labeled_idx)
    unlabeled_idx = np.array(unlabeled_idx)
    l_train = {"x": imgs[labeled_idx], "y": lbls[labeled_idx]}
    u_train = {"x": imgs[unlabeled_idx], "y": np.full(len(unlabeled_idx), -1, dtype=np.int64)}
    return l_train, u_train


def prepare_and_save(dataset_name, nlabels, seed):
    torch.manual_seed(seed)
    rng = np.random.default_rng(seed)

    if dataset_name == "SVHN":
        (train_imgs, train_lbls), (test_imgs, test_lbls), (extra_imgs, extra_lbls) = load_svhn()
        validation_count = COUNTS[dataset_name]["validation"]
    else:  # CIFAR10
        (train_imgs, train_lbls), (test_imgs, test_lbls), _ = load_cifar10()
        validation_count = COUNTS[dataset_name]["validation"]
        extra_imgs = None
        extra_lbls = None

    # Permute training data
    perm = rng.permutation(len(train_imgs))
    train_imgs = train_imgs[perm]
    train_lbls = train_lbls[perm]
    if extra_imgs is not None:
        extra_perm = rng.permutation(len(extra_imgs))
        extra_imgs = extra_imgs[extra_perm]
        extra_lbls = extra_lbls[extra_perm]

    # Validation split
    val_imgs = train_imgs[:validation_count]
    val_lbls = train_lbls[:validation_count]
    train_imgs = train_imgs[validation_count:]
    train_lbls = train_lbls[validation_count:]

    # Labeled / Unlabeled split
    l_train, u_train = split_l_u((train_imgs, train_lbls), nlabels, NUM_CLASSES[dataset_name])

    # Prepare output directory
    out_dir = os.path.join(_DATA_DIR, dataset_name)
    os.makedirs(out_dir, exist_ok=True)

    # Save datasets
    np.save(os.path.join(out_dir, "l_train.npy"), np.array([l_train["x"], l_train["y"]]))
    np.save(os.path.join(out_dir, "u_train.npy"), np.array([u_train["x"], u_train["y"]]))
    np.save(os.path.join(out_dir, "val.npy"), np.array([val_imgs, val_lbls]))
    np.save(os.path.join(out_dir, "test.npy"), np.array([test_imgs, test_lbls]))
    if extra_imgs is not None:
        np.save(os.path.join(out_dir, "extra.npy"), np.array([extra_imgs, extra_lbls]))


def main():
    args = parse_args()
    prepare_and_save(args.dataset, args.nlabels, args.seed)


if __name__ == "__main__":
    main()
