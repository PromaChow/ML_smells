import pandas as pd
import matplotlib.pyplot as plt

# Load dataset
df = pd.read_csv('HollywoodMovies.csv')

# Group by Genre
genre_groups = df.groupby('Genre')
genre_counts = genre_groups.size()

# Create bar chart
fig, ax = plt.subplots(figsize=(10, 6))
genre_counts.plot(kind='bar', ax=ax, color='skyblue')

# Customizations
ax.set_xlabel('Genre')
ax.set_ylabel('Number of Movies')
ax.set_title('Number of Hollywood Movies per Genre')
ax.set_xticklabels(genre_counts.index, rotation=45, ha='right')
ax.grid(axis='y', linestyle='--', alpha=0.7)

# Highlight genre with maximum movies
max_genre = genre_counts.idxmax()
max_count = genre_counts.max()
ax.annotate(f'{max_genre}\n{max_count} movies', xy=(max_genre, max_count),
            xytext=(0, 10), textcoords='offset points',
            ha='center', va='bottom', fontsize=12,
            arrowprops=dict(arrowstyle='-|>', color='red'))

plt.tight_layout()
plt.show()