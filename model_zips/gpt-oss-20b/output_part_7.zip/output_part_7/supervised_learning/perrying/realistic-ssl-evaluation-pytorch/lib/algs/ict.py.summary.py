import torch
import torch.nn.functional as F
import copy


class ICT:
    def __init__(self, alpha: float, model: torch.nn.Module, ema_factor: float):
        self.alpha = alpha
        self.model = model
        self.ema_factor = ema_factor
        self.mean_teacher = copy.deepcopy(model)
        self.global_step = 0

    def _set_batchnorm_tracking(self, module: torch.nn.Module, tracking: bool) -> None:
        for m in module.modules():
            if isinstance(m, torch.nn.modules.batchnorm._BatchNorm):
                m.track_running_stats = tracking

    def train_step(self, x: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        self.global_step += 1

        mask = mask.to(dtype=torch.bool)

        # Disable BN updates for the student model during forward
        self._set_batchnorm_tracking(self.model, False)

        # Teacher predictions
        with torch.no_grad():
            mt_y = self.mean_teacher(x)

        # Split data
        unlabeled_mask = ~mask
        l_x = x[mask]
        l_y = mt_y[mask]
        u_x = x[unlabeled_mask]
        u_y = mt_y[unlabeled_mask]

        # Mixup on unlabeled data
        lam = torch.distributions.Beta(self.alpha, self.alpha).sample().item()
        idx = torch.randperm(u_x.size(0))
        u_x_perm = u_x[idx]
        u_y_perm = u_y[idx]
        mixed_u_x = lam * u_x + (1.0 - lam) * u_x_perm
        mixed_u_y = lam * u_y + (1.0 - lam) * u_y_perm

        # Concatenate labeled and mixed unlabeled data
        inputs = torch.cat([l_x, mixed_u_x], dim=0)
        targets = torch.cat([l_y, mixed_u_y], dim=0)

        # Student forward
        logits = self.model(inputs)

        # Loss calculation (MSE on softmax outputs)
        pred_soft = torch.softmax(logits, dim=1)
        target_soft = torch.softmax(targets, dim=1)
        mse = F.mse_loss(pred_soft, target_soft, reduction='none').mean(dim=1)

        # Use only unlabeled portion for loss
        if l_x.size(0) > 0:
            loss = mse[l_x.size(0):].mean() / x.size(0)
        else:
            loss = mse.mean() / x.size(0)

        # Re-enable BN updates
        self._set_batchnorm_tracking(self.model, True)

        # EMA update for the teacher
        ema_coef = min(1.0 - 1.0 / self.global_step, self.ema_factor)
        with torch.no_grad():
            for tp, sp in zip(self.mean_teacher.parameters(), self.model.parameters()):
                tp.data.mul_(ema_coef).add_(sp.data, alpha=1.0 - ema_coef)

        return loss