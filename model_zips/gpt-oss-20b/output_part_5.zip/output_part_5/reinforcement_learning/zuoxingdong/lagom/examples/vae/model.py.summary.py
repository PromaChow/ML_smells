import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.init import orthogonal_, constant_

class VAE(nn.Module):
    def __init__(self, z_dim: int, device: torch.device):
        super().__init__()
        self.device = device

        self.enc_fc = nn.Linear(784, 400, bias=True)
        self.mean_head = nn.Linear(400, z_dim, bias=True)
        self.logvar_head = nn.Linear(400, z_dim, bias=True)

        self.dec_fc = nn.Linear(z_dim, 400, bias=True)
        self.x_head = nn.Linear(400, 784, bias=True)

        self._init_weights()

    def _init_weights(self):
        orthogonal_(self.enc_fc.weight)
        constant_(self.enc_fc.bias, 0)

        orthogonal_(self.mean_head.weight, gain=0.01)
        constant_(self.mean_head.bias, 0)

        orthogonal_(self.logvar_head.weight, gain=0.01)
        constant_(self.logvar_head.bias, 0)

        orthogonal_(self.dec_fc.weight)
        constant_(self.dec_fc.bias, 0)

        orthogonal_(self.x_head.weight)
        constant_(self.x_head.bias, 0)

        self.to(self.device)

    def reparameterize(self, mu: torch.Tensor, logvar: torch.Tensor) -> torch.Tensor:
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def forward(self, x: torch.Tensor):
        x_flat = x.view(x.size(0), -1).to(self.device)
        h = F.relu(self.enc_fc(x_flat))
        mu = self.mean_head(h)
        logvar = self.logvar_head(h)
        z = self.reparameterize(mu, logvar)
        h_dec = F.relu(self.dec_fc(z))
        x_recon = torch.sigmoid(self.x_head(h_dec))
        return x_recon, mu, logvar


class ConvVAE(nn.Module):
    def __init__(self, z_dim: int, device: torch.device):
        super().__init__()
        self.device = device

        self.conv1 = nn.Conv2d(1, 64, kernel_size=4, stride=2, padding=0, bias=True)
        self.conv2 = nn.Conv2d(64, 64, kernel_size=4, stride=2, padding=0, bias=True)
        self.conv3 = nn.Conv2d(64, 64, kernel_size=4, stride=1, padding=0, bias=True)

        self.mean_head = nn.Linear(256, z_dim, bias=True)
        self.logvar_head = nn.Linear(256, z_dim, bias=True)

        self.decoder_fc = nn.Linear(z_dim, 256, bias=True)

        self.deconv1 = nn.ConvTranspose2d(64, 64, kernel_size=4, stride=2, padding=0, bias=True)
        self.deconv2 = nn.ConvTranspose2d(64, 64, kernel_size=4, stride=1, padding=0, bias=True)
        self.deconv3 = nn.ConvTranspose2d(64, 64, kernel_size=4, stride=1, padding=0, bias=True)

        self.x_head = nn.Linear(9216, 784, bias=True)

        self._init_weights()

    def _init_weights(self):
        for conv in [self.conv1, self.conv2, self.conv3, self.deconv1, self.deconv2, self.deconv3]:
            orthogonal_(conv.weight)
            constant_(conv.bias, 0)

        orthogonal_(self.mean_head.weight, gain=0.01)
        constant_(self.mean_head.bias, 0)

        orthogonal_(self.logvar_head.weight, gain=0.01)
        constant_(self.logvar_head.bias, 0)

        orthogonal_(self.decoder_fc.weight)
        constant_(self.decoder_fc.bias, 0)

        orthogonal_(self.x_head.weight)
        constant_(self.x_head.bias, 0)

        self.to(self.device)

    def reparameterize(self, mu: torch.Tensor, logvar: torch.Tensor) -> torch.Tensor:
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def forward(self, x: torch.Tensor):
        x = x.to(self.device)
        h = F.relu(self.conv1(x))
        h = F.relu(self.conv2(h))
        h = F.relu(self.conv3(h))
        h_flat = h.view(h.size(0), -1)
        mu = self.mean_head(h_flat)
        logvar = self.logvar_head(h_flat)
        z = self.reparameterize(mu, logvar)
        h_dec = F.relu(self.decoder_fc(z))
        h_dec = h_dec.view(h_dec.size(0), 64, 2, 2)
        h_dec = F.relu(self.deconv1(h_dec))
        h_dec = F.relu(self.deconv2(h_dec))
        h_dec = F.relu(self.deconv3(h_dec))
        h_dec_flat = h_dec.view(h_dec.size(0), -1)
        x_recon = torch.sigmoid(self.x_head(h_dec_flat))
        return x_recon, mu, logvar


def vae_loss(recon_x: torch.Tensor, x: torch.Tensor,
             mu: torch.Tensor, logvar: torch.Tensor,
             bce: bool = True) -> torch.Tensor:
    if bce:
        recon_loss = F.binary_cross_entropy(recon_x, x, reduction='sum')
    else:
        recon_loss = F.mse_loss(recon_x, x, reduction='sum')
    kl_loss = -0.5 * torch.sum(1 + logvar - mu.pow(2) - torch.exp(logvar), dim=1)
    kl_loss = kl_loss.mean()
    recon_loss = recon_loss / x.size(0)
    return recon_loss + kl_loss

