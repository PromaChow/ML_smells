import unittest
import numpy as np
from pywsl.pul import PUMIL_SL, gen_twonorm_pumil, bin_clf_err
from sklearn.model_selection import GridSearchCV

class TestPUMILSL(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Synthetic data generation
        cls.x, cls.y, cls.x_t, cls.y_t = gen_twonorm_pumil(
            n_p=30,
            n_u=200,
            prior_u=0.5,
            n_t=100,
            random_state=42
        )

    def test_fit(self):
        model = PUMIL_SL(prior=0.5, basis='minimax')
        model.fit(self.x, self.y)
        preds = model.predict(self.x_t)
        err = bin_clf_err(self.y_t, preds, prior=0.5)
        self.assertLess(err, 0.2, f"Error too high: {err}")

    def test_cv(self):
        base_estimator = PUMIL_SL(prior=0.5, basis='minimax')
        param_grid = {'lam': np.logspace(-3, 1, 10)}
        grid_search = GridSearchCV(
            estimator=base_estimator,
            param_grid=param_grid,
            cv=5,
            n_jobs=-1
        )
        grid_search.fit(self.x, self.y)
        best_model = grid_search.best_estimator_
        preds = best_model.predict(self.x_t)
        err = bin_clf_err(self.y_t, preds, prior=0.5)
        self.assertLess(err, 0.2, f"Error too high after CV: {err}")

if __name__ == "__main__":
    unittest.main()
