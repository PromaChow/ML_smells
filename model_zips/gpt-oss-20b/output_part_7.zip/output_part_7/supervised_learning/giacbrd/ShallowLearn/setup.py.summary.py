import io
import os

import numpy
from setuptools import Extension, find_packages, setup

def readfile(fname):
    with io.open(fname, encoding='utf-8') as f:
        return f.read()

def readme():
    return readfile('README.rst')

package_dir = os.path.abspath('shallowlearn')

setup(
    name='ShallowLearn',
    version='0.0.5',
    description='A collection of supervised learning models based on shallow neural networks such as word2vec and fastText.',
    long_description=readfile('README.rst'),
    url='https://github.com/giacbrd/ShallowLearn',
    author='Giacomo Berardi',
    author_email='barnets@gmail.com',
    license='LGPLv3+',
    packages=['shallowlearn'] + find_packages('shallowlearn'),
    include_package_data=True,
    install_requires=[
        'cython>=0.24.1',
        'scikit-learn>=0.18',
        'gensim==0.13.4',
        'fasttext==0.8.2',
    ],
    setup_requires=[
        'pytest-runner==2.9',
    ],
    tests_require=[
        'pytest==3.0.3',
    ],
    classifiers=[
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Science/Research',
        'License :: OSI Approved :: GNU Lesser General Public License v3 or later (LGPLv3+)',
        'Operating System :: OS Independent',
        'Programming Language :: Python :: 2.7',
        'Programming Language :: Python :: 3.5',
        'Environment :: Console',
        'Topic :: Scientific/Engineering :: Artificial Intelligence',
        'Topic :: Scientific/Engineering :: Information Analysis',
        'Topic :: Text Processing',
    ],
    ext_modules=[
        Extension(
            'shallowlearn.word2vec_inner',
            sources=['./shallowlearn/word2vec_inner.pyx'],
            include_dirs=[numpy.get_include()],
        )
    ],
)