import gym
import numpy as np
import random
import multiprocessing as mp
import collections
import pickle


class AutoReset(gym.Wrapper):
    def __init__(self, env):
        super().__init__(env)
        self._done = False

    def step(self, action):
        obs, reward, done, info = self.env.step(action)
        if done:
            new_obs = self.env.reset()
            self._done = False
            return new_obs, 0.0, True, info
        self._done = done
        return obs, reward, done, info

    def reset(self, **kwargs):
        self._done = False
        return self.env.reset(**kwargs)


class ActionRepeat(gym.Wrapper):
    def __init__(self, env, repeats):
        super().__init__(env)
        self.repeats = repeats

    def step(self, action):
        total_reward = 0.0
        for i in range(self.repeats):
            obs, reward, done, info = self.env.step(action)
            total_reward += reward
            if done:
                break
        return obs, total_reward, done, info


class RandomStart(gym.Wrapper):
    def __init__(self, env, max_steps):
        super().__init__(env)
        self.max_steps = max_steps

    def reset(self, **kwargs):
        obs = self.env.reset(**kwargs)
        steps = random.randint(0, self.max_steps)
        for _ in range(steps):
            action = self.env.action_space.sample()
            obs, reward, done, info = self.env.step(action)
            if done:
                return self.reset(**kwargs)
        return obs


class FrameHistory(gym.Wrapper):
    def __init__(self, env, offsets, flatten=False):
        super().__init__(env)
        self.offsets = offsets
        self.flatten = flatten
        max_offset = max(abs(o) for o in offsets)
        self._buffer = collections.deque(maxlen=max_offset + 1)

    def reset(self, **kwargs):
        obs = self.env.reset(**kwargs)
        for _ in range(self._buffer.maxlen):
            self._buffer.append(obs)
        return self._get_observation()

    def step(self, action):
        obs, reward, done, info = self.env.step(action)
        self._buffer.append(obs)
        return self._get_observation(), reward, done, info

    def _get_observation(self):
        frames = [self._buffer[-offset] if -offset < len(self._buffer) else self._buffer[0]
                  for offset in self.offsets]
        if not self.flatten:
            return np.concatenate(frames, axis=0)
        return np.concatenate(frames, axis=0).ravel()


class FrameDelta(gym.Wrapper):
    def __init__(self, env):
        super().__init__(env)
        self._last = None

    def reset(self, **kwargs):
        obs = self.env.reset(**kwargs)
        self._last = obs
        return obs

    def step(self, action):
        obs, reward, done, info = self.env.step(action)
        delta = obs - self._last
        self._last = obs
        return delta, reward, done, info


class RangeNormalize(gym.Wrapper):
    def __init__(self, env, normalize_observation=True, normalize_action=True):
        super().__init__(env)
        self.normalize_observation = normalize_observation
        self.normalize_action = normalize_action
        self._obs_low = None
        self._obs_high = None
        self._act_low = None
        self._act_high = None
        self._prepare_spaces()

    def _prepare_spaces(self):
        obs_space = self.env.observation_space
        act_space = self.env.action_space
        if self.normalize_observation and isinstance(obs_space, gym.spaces.Box):
            if np.all(np.isfinite(obs_space.low)) and np.all(np.isfinite(obs_space.high)):
                self._obs_low = obs_space.low
                self._obs_high = obs_space.high
                self.observation_space = gym.spaces.Box(-1.0, 1.0, shape=obs_space.shape,
                                                       dtype=obs_space.dtype)
        if self.normalize_action and isinstance(act_space, gym.spaces.Box):
            if np.all(np.isfinite(act_space.low)) and np.all(np.isfinite(act_space.high)):
                self._act_low = act_space.low
                self._act_high = act_space.high
                self.action_space = gym.spaces.Box(-1.0, 1.0, shape=act_space.shape,
                                                   dtype=act_space.dtype)

    def _normalize_observation(self, obs):
        if self._obs_low is None:
            return obs
        return 2.0 * (obs - self._obs_low) / (self._obs_high - self._obs_low) - 1.0

    def _denormalize_action(self, act):
        if self._act_low is None:
            return act
        return (act + 1.0) / 2.0 * (self._act_high - self._act_low) + self._act_low

    def reset(self, **kwargs):
        obs = self.env.reset(**kwargs)
        return self._normalize_observation(obs)

    def step(self, action):
        if self.normalize_action:
            action = self._denormalize_action(action)
        obs, reward, done, info = self.env.step(action)
        obs = self._normalize_observation(obs)
        return obs, reward, done, info


class ClipAction(gym.Wrapper):
    def __init__(self, env):
        super().__init__(env)

    @property
    def action_space(self):
        return gym.spaces.Box(-np.inf, np.inf, shape=self.env.action_space.shape,
                              dtype=self.env.action_space.dtype)

    def step(self, action):
        clipped = np.clip(action, self.env.action_space.low, self.env.action_space.high)
        return self.env.step(clipped)


class LimitDuration(gym.Wrapper):
    def __init__(self, env, max_steps):
        super().__init__(env)
        self.max_steps = max_steps
        self._step = 0

    def reset(self, **kwargs):
        self._step = 0
        return self.env.reset(**kwargs)

    def step(self, action):
        self._step += 1
        obs, reward, done, info = self.env.step(action)
        if self._step >= self.max_steps:
            done = True
        return obs, reward, done, info


class ExternalProcess(gym.Env):
    def __init__(self, env_fn):
        super().__init__()
        self.parent_conn, child_conn = mp.Pipe()
        self.process = mp.Process(target=self._worker, args=(env_fn, child_conn))
        self.process.start()
        child_conn.close()
        self._recv()
        self.observation_space = self._recv()
        self.action_space = self._recv()

    def _worker(self, env_fn, conn):
        env = env_fn()
        conn.send(env.observation_space)
        conn.send(env.action_space)
        try:
            while True:
                cmd, data = conn.recv()
                if cmd == 'step':
                    obs, rew, done, info = env.step(data)
                    conn.send((obs, rew, done, info))
                elif cmd == 'reset':
                    obs = env.reset()
                    conn.send(obs)
                elif cmd == 'get_attr':
                    value = getattr(env, data)
                    conn.send(value)
                elif cmd == 'call':
                    func_name, args, kwargs = data
                    func = getattr(env, func_name)
                    result = func(*args, **kwargs)
                    conn.send(result)
                elif cmd == 'close':
                    conn.close()
                    break
        except Exception as e:
            conn.send(('EXCEPTION', pickle.dumps(e)))

    def _recv(self):
        data = self.parent_conn.recv()
        if isinstance(data, tuple) and data[0] == 'EXCEPTION':
            e = pickle.loads(data[1])
            raise e
        return data

    def step(self, action):
        self.parent_conn.send(('step', action))
        return self._recv()

    def reset(self, **kwargs):
        self.parent_conn.send(('reset', None))
        return self._recv()

    def __getattr__(self, name):
        self.parent_conn.send(('get_attr', name))
        return self._recv()

    def __call__(self, *args, **kwargs):
        self.parent_conn.send(('call', (self.__class__.__name__, args, kwargs)))
        return self._recv()

    def close(self):
        self.parent_conn.send(('close', None))
        self.process.join()
        self.parent_conn.close()


class ConvertTo32Bit(gym.Wrapper):
    def __init__(self, env):
        super().__init__(env)

    def reset(self, **kwargs):
        obs = self.env.reset(**kwargs)
        return self._convert(obs)

    def step(self, action):
        obs, reward, done, info = self.env.step(action)
        obs = self._convert(obs)
        reward = self._convert(reward)
        return obs, reward, done, info

    def _convert(self, value):
        if isinstance(value, np.ndarray):
            if np.isinf(value).any():
                raise ValueError("Infinite values found during conversion")
            dtype = np.float32 if np.issubdtype(value.dtype, np.floating) else np.int32
            return value.astype(dtype)
        elif isinstance(value, (int, float)):
            if np.isinf(value):
                raise ValueError("Infinite value found during conversion")
            return np.float32(value)
        return value


class CacheSpaces(gym.Wrapper):
    def __init__(self, env):
        super().__init__(env)
        self._cached_obs_space = env.observation_space
        self._cached_act_space = env.action_space

    @property
    def observation_space(self):
        return self._cached_obs_space

    @property
    def action_space(self):
        return self._cached_act_space
