import torch
import torch.nn as nn
from wavencoder import Wav2Vec, SincNet, LSTM_Classifier, LSTM_Attn_Classifier

def main():
    encoder = Wav2Vec(pretrained=False)
    classifier = LSTM_Attn_Classifier(
        input_size=512,
        hidden_size=64,
        num_classes=2,
        return_attn_weights=False
    )
    
    x = torch.randn(2, 1, 16000)
    z = encoder(x)
    y = classifier(z)
    
    print("Encoder output shape:", z.shape)
    print("Classifier output shape:", y.shape)

if __name__ == "__main__":
    main()