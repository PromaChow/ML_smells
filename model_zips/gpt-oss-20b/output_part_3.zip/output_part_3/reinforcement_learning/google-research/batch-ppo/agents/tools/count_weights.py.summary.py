import tensorflow as tf
import re
from functools import reduce
import operator

def count_trainable_params(graph=None, scope=None, exclude=None):
    """
    Count the number of trainable parameters in a TensorFlow graph.

    Args:
        graph: Optional. A tf.Graph instance. If None, the default graph is used.
        scope: Optional. A string. If provided, only variables whose names start with this
               scope (ending with a '/') are counted.
        exclude: Optional. A string representing a regular expression. Variables whose
                 names match this pattern are excluded from the count.

    Returns:
        int: Total number of trainable parameters.
    """
    # Ensure scope ends with a slash if provided
    if scope and not scope.endswith('/'):
        scope = scope + '/'

    # Use the provided graph or the default one
    if graph is None:
        graph = tf.compat.v1.get_default_graph()

    # Retrieve all trainable variables
    variables = graph.get_collection(tf.compat.v1.GraphKeys.TRAINABLE_VARIABLES)

    # Filter by scope if specified
    if scope:
        variables = [v for v in variables if v.name.startswith(scope)]

    # Filter out variables matching the exclude regex if specified
    if exclude:
        pattern = re.compile(exclude)
        variables = [v for v in variables if not pattern.search(v.name)]

    # Sum the number of parameters for each variable
    total_params = 0
    for var in variables:
        shape = var.shape.as_list()
        # Handle None dimensions (e.g., unspecified batch size)
        num_elements = reduce(operator.mul, [(dim if dim is not None else 1) for dim in shape], 1)
        total_params += num_elements

    return int(total_params)