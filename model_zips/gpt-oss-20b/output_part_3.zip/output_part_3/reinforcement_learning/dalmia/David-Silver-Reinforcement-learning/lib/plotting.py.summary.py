import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D


def plot_cost_to_go_mountain_car(
    estimator,
    env,
    num_points: int = 50,
    noshow: bool = False,
) -> None:
    """Plot the cost‑to‑go surface for a MountainCar environment."""
    low = env.observation_space.low
    high = env.observation_space.high

    pos = np.linspace(low[0], high[0], num_points)
    vel = np.linspace(low[1], high[1], num_points)
    X, Y = np.meshgrid(pos, vel)

    # Prepare grid points for evaluation
    grid_points = np.column_stack((X.ravel(), Y.ravel()))

    # Predict value for each point and compute negative max (cost‑to‑go)
    preds = estimator.predict(grid_points)
    if preds.ndim == 1:
        # estimator returns a single value per point
        Z = -preds.reshape(X.shape)
    else:
        Z = -np.max(preds, axis=1).reshape(X.shape)

    # Plotting
    fig = plt.figure(figsize=(10, 6))
    ax = fig.add_subplot(111, projection="3d")
    surf = ax.plot_surface(
        X,
        Y,
        Z,
        cmap="viridis",
        edgecolor="none",
        alpha=0.8,
    )
    ax.set_xlabel("Position")
    ax.set_ylabel("Velocity")
    ax.set_zlabel("Value")
    ax.set_title("Cost‑to‑Go Surface (MountainCar)")
    fig.colorbar(surf, shrink=0.5, aspect=10, label="Cost to Go")

    if noshow:
        plt.close(fig)
    else:
        plt.show()


def plot_value_function(
    V: dict,
    noshow: bool = False,
) -> None:
    """Plot value functions for Blackjack with and without a usable ace."""
    # Extract ranges
    player_sums = [key[0] for key in V.keys()]
    dealer_shows = [key[1] for key in V.keys()]

    x_min, x_max = min(player_sums), max(player_sums)
    y_min, y_max = min(dealer_shows), max(dealer_shows)

    x_vals = np.arange(x_min, x_max + 1)
    y_vals = np.arange(y_min, y_max + 1)
    X, Y = np.meshgrid(x_vals, y_vals)

    # Helper to build Z grid
    def build_z(usable_ace: bool) -> np.ndarray:
        Z = np.full(X.shape, np.nan)
        for i in range(X.shape[0]):
            for j in range(X.shape[1]):
                key = (int(X[i, j]), int(Y[i, j]), usable_ace)
                Z[i, j] = V.get(key, np.nan)
        return Z

    Z_true = build_z(True)
    Z_false = build_z(False)

    # Plot with usable ace
    fig1 = plt.figure(figsize=(10, 6))
    ax1 = fig1.add_subplot(111, projection="3d")
    surf1 = ax1.plot_surface(
        X,
        Y,
        Z_true,
        cmap="coolwarm",
        edgecolor="none",
        alpha=0.8,
    )
    ax1.set_xlabel("Player Sum")
    ax1.set_ylabel("Dealer Showing")
    ax1.set_zlabel("Value")
    ax1.set_title("Blackjack Value Function (Usable Ace)")
    fig1.colorbar(surf1, shrink=0.5, aspect=10, label="Value")

    # Plot without usable ace
    fig2 = plt.figure(figsize=(10, 6))
    ax2 = fig2.add_subplot(111, projection="3d")
    surf2 = ax2.plot_surface(
        X,
        Y,
        Z_false,
        cmap="coolwarm",
        edgecolor="none",
        alpha=0.8,
    )
    ax2.set_xlabel("Player Sum")
    ax2.set_ylabel("Dealer Showing")
    ax2.set_zlabel("Value")
    ax2.set_title("Blackjack Value Function (No Usable Ace)")
    fig2.colorbar(surf2, shrink=0.5, aspect=10, label="Value")

    if noshow:
        plt.close(fig1)
        plt.close(fig2)
    else:
        plt.show()


def plot_episode_stats(
    episode_lengths: list[int],
    episode_rewards: list[float],
    window: int = 100,
    noshow: bool = False,
) -> None:
    """Plot episode statistics: length, smoothed reward, and time‑step relationship."""
    episodes = np.arange(1, len(episode_lengths) + 1)

    # Episode length plot
    fig1, ax1 = plt.subplots(figsize=(10, 4))
    ax1.plot(episodes, episode_lengths, label="Episode Length")
    ax1.set_xlabel("Episode")
    ax1.set_ylabel("Episode Length")
    ax1.set_title("Episode Length Over Time")
    ax1.grid(True)

    # Smoothed reward plot
    reward_series = pd.Series(episode_rewards)
    smoothed = reward_series.rolling(window=window, min_periods=1, center=True).mean()
    fig2, ax2 = plt.subplots(figsize=(10, 4))
    ax2.plot(episodes, smoothed, color="orange", label="Smoothed Reward")
    ax2.set_xlabel("Episode")
    ax2.set_ylabel("Episode Reward (Smoothed)")
    ax2.set_title(f"Smoothed Episode Reward (window={window})")
    ax2.grid(True)

    # Time step vs episode plot
    cumulative_steps = np.cumsum(episode_lengths)
    fig3, ax3 = plt.subplots(figsize=(10, 4))
    ax3.plot(cumulative_steps, episodes, color="green", label="Episode vs Time Step")
    ax3.set_xlabel("Cumulative Time Steps")
    ax3.set_ylabel("Episode")
    ax3.set_title("Time Steps vs. Episode Number")
    ax3.grid(True)

    if noshow:
        plt.close(fig1)
        plt.close(fig2)
        plt.close(fig3)
    else:
        plt.show()