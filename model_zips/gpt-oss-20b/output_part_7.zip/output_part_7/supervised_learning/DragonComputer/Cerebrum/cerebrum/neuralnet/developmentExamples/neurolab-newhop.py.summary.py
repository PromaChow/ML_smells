import numpy as np
import neurolab as nl

def encode(grid):
    arr = np.array(grid, dtype=int)
    arr[arr == 0] = -1
    return arr.flatten()

# 5x5 grid representations for letters N, E, R, O
N_grid = [
    [1, 0, 0, 0, 1],
    [1, 1, 0, 0, 1],
    [1, 0, 1, 0, 1],
    [1, 0, 0, 1, 1],
    [1, 0, 0, 0, 1],
]

E_grid = [
    [1, 1, 1, 1, 1],
    [1, 0, 0, 0, 0],
    [1, 1, 1, 1, 0],
    [1, 0, 0, 0, 0],
    [1, 1, 1, 1, 1],
]

R_grid = [
    [1, 1, 1, 1, 0],
    [1, 0, 0, 0, 1],
    [1, 1, 1, 1, 0],
    [1, 0, 1, 0, 0],
    [1, 0, 0, 1, 0],
]

O_grid = [
    [0, 1, 1, 1, 0],
    [1, 0, 0, 0, 1],
    [1, 0, 0, 0, 1],
    [1, 0, 0, 0, 1],
    [0, 1, 1, 1, 0],
]

N = encode(N_grid)
E = encode(E_grid)
R = encode(R_grid)
O = encode(O_grid)

targets = np.vstack([N, E, R, O])  # shape (4, 25)

# Create Hopfield network
net = nl.net.newhop(targets)

# Validation on training data
letters = ['N', 'E', 'R', 'O']
for idx, pattern in enumerate(targets):
    out = net.simulate(pattern)
    print(f"Pattern {letters[idx]} reconstruction: {np.array_equal(out, pattern)}")

# Testing on a corrupted input
corrupted = N.copy()
indices_to_flip = [0, 6, 12, 18, 24]  # diagonal elements
for i in indices_to_flip:
    corrupted[i] = -corrupted[i]

def hopfield_iterative(net, input_pattern, max_iter=1000):
    state = input_pattern.copy()
    w = net.w
    try:
        b = net.b
    except AttributeError:
        b = np.zeros(w.shape[0])
    steps = 0
    while steps < max_iter:
        steps += 1
        u = np.dot(w, state) + b
        new_state = np.where(u >= 0, 1, -1)
        if np.array_equal(new_state, state):
            break
        state = new_state
    return state, steps

recon, steps = hopfield_iterative(net, corrupted)
print(f"Corrupted N reconstruction matches original: {np.array_equal(recon, N)}")
print(f"Simulation steps taken: {steps}")