import re
import copy
import numpy as np
import matplotlib.pyplot as plt

# Constants
LETTERS = 'ABCDEFGHJKLMNOPQRST'  # 19 columns (I omitted)
PASS_MOVE = (-1, -1)

# Helper functions
def flatten_idx(x, y, size):
    return y * size + x

def unflatten_idx(idx, size):
    return idx % size, idx // size

def _parse_sgf_move(move_str):
    if not move_str:
        return PASS_MOVE
    x = ord(move_str[0].lower()) - ord('a')
    y = ord(move_str[1].lower()) - ord('a')
    return (x, y)

def sgf_coord_from_idx(x, y):
    return chr(ord('a') + x) + chr(ord('a') + y)

# GameState implementation
class GameState:
    def __init__(self, size):
        self.size = size
        self.board = np.full((size, size), None)  # None, 'B', 'W'
        self.history = []  # list of (player, move)
        self.current_player = 'B'

    def place_stone(self, x, y, player):
        if self.board[y, x] is not None:
            raise ValueError(f"Cell ({x},{y}) already occupied.")
        self.board[y, x] = player

    def pass_move(self, player):
        # pass does not modify board
        pass

    def update_move(self, move, player):
        if move == PASS_MOVE:
            self.pass_move(player)
        else:
            x, y = move
            self.place_stone(x, y, player)
        self.history.append((player, move))
        self.current_player = 'W' if player == 'B' else 'B'

# SGF parsing utilities
def _parse_root_node(sgf_str):
    root_content = re.search(r'\((;[^\;]*)', sgf_str)
    if not root_content:
        raise ValueError("Invalid SGF format.")
    props = dict(re.findall(r'([A-Z]+)\[([^\]]*)\]', root_content.group(1)))
    return props

def _sgf_init_gamestate(root_props):
    size = int(root_props.get('SZ', 19))
    gs = GameState(size)
    pl = root_props.get('PL', 'B')
    gs.current_player = pl
    # initial stones
    for stone_prop in ['AB', 'AW']:
        if stone_prop in root_props:
            for coord in root_props[stone_prop].split(']'):
                if coord:
                    move = _parse_sgf_move(coord)
                    if move != PASS_MOVE:
                        x, y = move
                        gs.place_stone(x, y, 'B' if stone_prop == 'AB' else 'W')
    return gs

def sgf_iter_states(sgf_str, include_end_state=False):
    root_props = _parse_root_node(sgf_str)
    gs = _sgf_init_gamestate(root_props)
    move_pattern = re.compile(r'([BW])\[(.*?)\]')
    moves = move_pattern.findall(sgf_str)
    for player, coord in moves:
        move = _parse_sgf_move(coord)
        gs.update_move(move, player)
        yield copy.deepcopy(gs), move, player
    if include_end_state:
        yield copy.deepcopy(gs), None, None

def sgf_to_gamestate(sgf_str):
    gs = None
    for gs, _, _ in sgf_iter_states(sgf_str, include_end_state=True):
        pass
    return gs

def save_gamestate_to_sgf(gs, filename):
    lines = ['(;GM[1]FF[4]SZ[{}]PL[{}]'.format(gs.size, gs.current_player)]
    # Encode moves
    for player, move in gs.history:
        if move == PASS_MOVE:
            coord = ''
        else:
            x, y = move
            coord = sgf_coord_from_idx(x, y)
        lines.append(f'{player}[{coord}]')
    lines.append(')')
    sgf_text = ''.join(lines)
    with open(filename, 'w') as f:
        f.write(sgf_text)

# Visualization
def plot_network_output(board, heatmap=None, last_move=None, save_path=None, show=True):
    size = board.shape[0]
    fig, ax = plt.subplots(figsize=(6, 6))
    # Grid
    ax.set_xticks(np.arange(-0.5, size, 1))
    ax.set_yticks(np.arange(-0.5, size, 1))
    ax.set_xticklabels([])
    ax.set_yticklabels([])
    ax.grid(which='both', color='black', linewidth=1)
    ax.set_xlim(-0.5, size - 0.5)
    ax.set_ylim(-0.5, size - 0.5)
    # Stones
    for y in range(size):
        for x in range(size):
            stone = board[y, x]
            if stone == 'B':
                ax.scatter(x, y, s=300, c='black', marker='o')
            elif stone == 'W':
                ax.scatter(x, y, s=300, c='white', edgecolors='black', marker='o')
    # Heatmap
    if heatmap is not None:
        im = ax.imshow(heatmap, cmap='coolwarm', alpha=0.3, extent=[-0.5, size-0.5, -0.5, size-0.5])
        plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    # Last move highlight
    if last_move is not None:
        lx, ly = last_move
        rect = plt.Rectangle((lx-0.5, ly-0.5), 1, 1, linewidth=2, edgecolor='red', facecolor='none')
        ax.add_patch(rect)
    if save_path:
        plt.savefig(save_path, bbox_inches='tight')
    if show:
        plt.show()
    plt.close(fig)
