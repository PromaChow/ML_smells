import seaborn as sns
import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt

# Load dataset
data = pd.read_csv("driver-data.csv", index_col="id")
print(data.head())

# Initialize and fit KMeans
kmeans = KMeans(n_clusters=4, random_state=0)
kmeans.fit(data)

# Print cluster centers
print("Cluster centers:")
print(kmeans.cluster_centers_)

# Count data points in each cluster
labels, counts = np.unique(kmeans.labels_, return_counts=True)
cluster_counts = dict(zip(labels, counts))
print("Data points per cluster:", cluster_counts)

# Add cluster labels to dataset
data["cluster"] = kmeans.labels_

# Visualize clusters
sns.lmplot(
    x="mean_dist_day",
    y="mean_over_speed_perc",
    hue="cluster",
    data=data,
    palette="coolwarm",
    fit_reg=False,
)
plt.show()

# Print inertia
print("Inertia:", kmeans.inertia_)

# Display final dataset
print(data)