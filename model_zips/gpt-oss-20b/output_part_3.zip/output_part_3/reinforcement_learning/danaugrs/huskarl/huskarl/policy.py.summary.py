import numpy as np
from abc import ABC, abstractmethod
from scipy.stats import truncnorm


class Policy(ABC):
    @abstractmethod
    def act(self, *args, **kwargs):
        """Return an action based on the provided inputs."""
        raise NotImplementedError("Subclasses must implement this method.")


class GreedyPolicy(Policy):
    def act(self, qvals: np.ndarray) -> int:
        qvals = np.asarray(qvals)
        if qvals.size == 0:
            raise ValueError("qvals must contain at least one value.")
        return int(np.argmax(qvals))


class EpsGreedyPolicy(Policy):
    def __init__(self, eps: float = 0.1):
        if not 0.0 <= eps <= 1.0:
            raise ValueError("eps must be in [0, 1].")
        self.eps = eps

    def act(self, qvals: np.ndarray) -> int:
        qvals = np.asarray(qvals)
        if qvals.size == 0:
            raise ValueError("qvals must contain at least one value.")
        if np.random.rand() > self.eps:
            return int(np.argmax(qvals))
        return int(np.random.choice(len(qvals)))


class GaussianEpsGreedyPolicy(Policy):
    def __init__(self, eps_mean: float = 0.1, eps_std: float = 0.05):
        if not 0.0 <= eps_mean <= 1.0:
            raise ValueError("eps_mean must be in [0, 1].")
        if eps_std <= 0:
            raise ValueError("eps_std must be positive.")
        self.eps_mean = eps_mean
        self.eps_std = eps_std
        self._a = (0 - eps_mean) / eps_std
        self._b = (1 - eps_mean) / eps_std

    def _sample_eps(self) -> float:
        return truncnorm.rvs(self._a, self._b, loc=self.eps_mean, scale=self.eps_std)

    def act(self, qvals: np.ndarray) -> int:
        qvals = np.asarray(qvals)
        if qvals.size == 0:
            raise ValueError("qvals must contain at least one value.")
        eps = self._sample_eps()
        if eps < np.random.rand():
            return int(np.argmax(qvals))
        return int(np.random.choice(len(qvals)))


class PassThroughPolicy(Policy):
    def act(self, action):
        return action
