import numpy as np

arr = np.arange(12).reshape(4, 3)
mask = arr > 5
filtered = arr[mask]
print(filtered)