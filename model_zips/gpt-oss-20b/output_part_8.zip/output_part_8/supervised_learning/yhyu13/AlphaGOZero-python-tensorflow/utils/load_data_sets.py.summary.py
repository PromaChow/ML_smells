import os
import gzip
import struct
import random
from typing import Iterable, Iterator, List, Tuple, Dict
import numpy as np

# Configuration constants
BOARD_SIZE = 19
INPUT_PLANES = 17
CHUNK_SIZE = 4096
EST_POS_PER_GAME = 200
TEST_POS_THRESHOLD = 200_000
TEST_CHUNK_SIZE = 100_000
PASS_MOVE_IDX = BOARD_SIZE * BOARD_SIZE  # last index reserved for pass

# ----------------------------------------------------------------------
# File discovery
# ----------------------------------------------------------------------
def find_sgf_files(directories: List[str]) -> List[str]:
    sgf_files = []
    cwd = os.getcwd()
    for root_dir in directories:
        for root, _, files in os.walk(root_dir):
            for file in files:
                if file.lower().endswith('.sgf'):
                    full_path = os.path.join(root, file)
                    rel_path = os.path.relpath(full_path, cwd)
                    sgf_files.append(rel_path)
    return sgf_files

# ----------------------------------------------------------------------
# SGF parsing placeholder
# ----------------------------------------------------------------------
def replay_sgf(file_path: str) -> List[Dict]:
    """
    Placeholder for SGF replay logic.
    Returns a list of positions, each a dict containing:
        - board: 2D numpy array (BOARD_SIZE x BOARD_SIZE) of 0/1 values
        - next_move: (x, y) tuple or None for pass
        - result: -1 or 1 indicating win for current player
    """
    num_moves = random.randint(50, 200)
    positions = []
    for _ in range(num_moves):
        board = np.random.randint(0, 2, size=(BOARD_SIZE, BOARD_SIZE), dtype=np.uint8)
        if random.random() < 0.1:
            next_move = None
        else:
            next_move = (random.randint(0, BOARD_SIZE - 1), random.randint(0, BOARD_SIZE - 1))
        result = random.choice([-1, 1])
        positions.append({'board': board, 'next_move': next_move, 'result': result})
    return positions

def get_positions_from_sgf(file_path: str) -> Iterator[Dict]:
    positions = replay_sgf(file_path)
    for pos in positions:
        yield pos

# ----------------------------------------------------------------------
# Feature extraction and encoding
# ----------------------------------------------------------------------
def bulk_extract_features(positions: List[Dict]) -> np.ndarray:
    """
    Extract board state features for a batch of positions.
    Returns array of shape (N, BOARD_SIZE**2, INPUT_PLANES) with bool dtype.
    For simplicity, we generate random boolean features.
    """
    N = len(positions)
    features = np.random.randint(0, 2, size=(N, BOARD_SIZE * BOARD_SIZE, INPUT_PLANES), dtype=bool)
    return features

def make_onehot(move) -> np.ndarray:
    """
    Encode a move as a one-hot vector of length BOARD_SIZE**2 + 1.
    Move is a (x, y) tuple or None for pass.
    """
    vec = np.zeros(BOARD_SIZE * BOARD_SIZE + 1, dtype=bool)
    if move is None:
        vec[PASS_MOVE_IDX] = True
    else:
        x, y = move
        idx = y * BOARD_SIZE + x
        vec[idx] = True
    return vec

# ----------------------------------------------------------------------
# DataSet class
# ----------------------------------------------------------------------
class DataSet:
    def __init__(self, pos_features: np.ndarray, next_moves: np.ndarray,
                 results: np.ndarray, board_size: int = BOARD_SIZE,
                 input_planes: int = INPUT_PLANES, is_test: bool = False):
        self.board_size = board_size
        self.input_planes = input_planes
        self.is_test = is_test
        self.num_positions = pos_features.shape[0]
        self.pos_features = pos_features
        self.next_moves = next_moves
        self.results = results

    def shuffle(self, seed: int = None):
        rng = np.random.default_rng(seed)
        indices = rng.permutation(self.num_positions)
        self.pos_features = self.pos_features[indices]
        self.next_moves = self.next_moves[indices]
        self.results = self.results[indices]

    def get_batch(self, start: int, batch_size: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        end = min(start + batch_size, self.num_positions)
        return (self.pos_features[start:end],
                self.next_moves[start:end],
                self.results[start:end])

    def write(self, file_path: str):
        header = struct.pack('>5I',
                             self.num_positions,
                             self.board_size,
                             self.input_planes,
                             int(self.is_test),
                             0)  # reserved
        with gzip.open(file_path, 'wb') as f:
            f.write(header)
            # Pack features
            flat_features = self.pos_features.reshape(self.num_positions, -1)
            packed_features = np.packbits(flat_features, axis=1)
            f.write(packed_features.tobytes())
            # Pack next moves
            packed_moves = np.packbits(self.next_moves, axis=1)
            f.write(packed_moves.tobytes())
            # Pack results (convert to 0/1)
            binary_results = (self.results > 0).astype(np.uint8)
            packed_results = np.packbits(binary_results, axis=1)
            f.write(packed_results.tobytes())

    @staticmethod
    def read(file_path: str) -> 'DataSet':
        with gzip.open(file_path, 'rb') as f:
            header = f.read(20)
            num_positions, board_size, input_planes, is_test, _ = struct.unpack('>5I', header)
            features_bits = np.frombuffer(f.read(num_positions * board_size * board_size * input_planes // 8), dtype=np.uint8)
            features = np.unpackbits(features_bits, axis=1).reshape(num_positions, board_size * board_size, input_planes).astype(bool)
            moves_bits = np.frombuffer(f.read(num_positions * (board_size * board_size + 1) // 8), dtype=np.uint8)
            moves = np.unpackbits(moves_bits, axis=1).reshape(num_positions, board_size * board_size + 1).astype(bool)
            results_bits = np.frombuffer(f.read(num_positions // 8), dtype=np.uint8)
            results = np.unpackbits(results_bits, axis=1)[:, 0].astype(int) * 2 - 1
            return DataSet(features, moves, results, board_size, input_planes, bool(is_test))

# ----------------------------------------------------------------------
# Data splitting
# ----------------------------------------------------------------------
def split_test_training(positions: List[Dict]) -> Tuple[DataSet, List[DataSet]]:
    total_positions = len(positions)
    if total_positions < TEST_POS_THRESHOLD:
        test_size = total_positions // 3
        train_positions = positions[test_size:]
        test_positions = positions[:test_size]
    else:
        random.shuffle(positions)
        test_positions = positions[:TEST_CHUNK_SIZE]
        train_positions = positions[TEST_CHUNK_SIZE:]
    # Extract features and encode
    test_features = bulk_extract_features(test_positions)
    test_moves = np.array([make_onehot(p['next_move']) for p in test_positions], dtype=bool)
    test_results = np.array([p['result'] for p in test_positions], dtype=int)
    test_set = DataSet(test_features, test_moves, test_results, is_test=True)
    # Chunk training data
    train_sets = []
    for i in range(0, len(train_positions), CHUNK_SIZE):
        chunk = train_positions[i:i + CHUNK_SIZE]
        feat = bulk_extract_features(chunk)
        moves = np.array([make_onehot(p['next_move']) for p in chunk], dtype=bool)
        results = np.array([p['result'] for p in chunk], dtype=int)
        train_sets.append(DataSet(feat, moves, results, is_test=False))
    return test_set, train_sets

# ----------------------------------------------------------------------
# Main orchestration
# ----------------------------------------------------------------------
def parse_data_sets(directories: List[str]) -> Tuple[DataSet, List[DataSet]]:
    sgf_files = find_sgf_files(directories)
    all_positions = []
    for sgf_path in sgf_files:
        all_positions.extend(list(get_positions_from_sgf(sgf_path)))
    test_set, train_sets = split_test_training(all_positions)
    return test_set, train_sets

# ----------------------------------------------------------------------
# Example usage
# ----------------------------------------------------------------------
if __name__ == '__main__':
    # Replace ['data'] with actual directories containing SGF files
    test_ds, train_dss = parse_data_sets(['data'])
    print(f'Test set size: {test_ds.num_positions}')
    print(f'Number of training chunks: {len(train_dss)}')
    # Save test set
    test_ds.write('test_set.gz')
    # Save first training chunk as example
    if train_dss:
        train_dss[0].write('train_chunk_0.gz')
    # Load from file
    loaded_test = DataSet.read('test_set.gz')
    print(f'Loaded test set size: {loaded_test.num_positions}')