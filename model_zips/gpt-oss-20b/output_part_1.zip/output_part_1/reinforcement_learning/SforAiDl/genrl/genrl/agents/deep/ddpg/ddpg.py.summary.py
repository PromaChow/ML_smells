import copy
import numpy as np
import random
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from collections import deque

# Minimal OffPolicyAgentAC stub
class OffPolicyAgentAC:
    def __init__(self, env):
        self.env = env
        self.replay_buffer = ReplayBuffer(capacity=1000000)

# Simple replay buffer
class ReplayBuffer:
    def __init__(self, capacity=1000000):
        self.capacity = capacity
        self.buffer = deque(maxlen=capacity)

    def add(self, state, action, reward, next_state, done):
        self.buffer.append((state, action, reward, next_state, done))

    def sample(self, batch_size):
        batch = random.sample(self.buffer, batch_size)
        states, actions, rewards, next_states, dones = map(np.array, zip(*batch))
        return states, actions, rewards, next_states, dones

    def __len__(self):
        return len(self.buffer)

# Actor-Critic network
class ActorCritic(nn.Module):
    def __init__(self, state_dim, action_dim, action_low, action_high, hidden_sizes=[256, 256]):
        super().__init__()
        # Actor
        actor_layers = []
        last_size = state_dim
        for h in hidden_sizes:
            actor_layers.append(nn.Linear(last_size, h))
            actor_layers.append(nn.ReLU())
            last_size = h
        actor_layers.append(nn.Linear(last_size, action_dim))
        self.actor = nn.Sequential(*actor_layers)
        self.action_low = torch.tensor(action_low, dtype=torch.float32)
        self.action_high = torch.tensor(action_high, dtype=torch.float32)

        # Critic
        critic_layers = []
        critic_input = state_dim + action_dim
        last_size = critic_input
        for h in hidden_sizes:
            critic_layers.append(nn.Linear(last_size, h))
            critic_layers.append(nn.ReLU())
            last_size = h
        critic_layers.append(nn.Linear(last_size, 1))
        self.critic = nn.Sequential(*critic_layers)

    def forward(self, state, action):
        q = self.critic(torch.cat([state, action], dim=-1))
        return q.squeeze(-1)

    def act(self, state, noise=None):
        state = torch.tensor(state, dtype=torch.float32).unsqueeze(0)
        with torch.no_grad():
            raw_action = torch.tanh(self.actor(state))
        action = raw_action * (self.action_high - self.action_low) / 2 + (self.action_high + self.action_low) / 2
        if noise is not None:
            action += noise.sample()
        return action.squeeze(0).numpy()

# Noise placeholder
class OrnsteinUhlenbeckNoise:
    def __init__(self, size, std=0.1, mu=0.0, theta=0.15, dt=1e-2, x0=None):
        self.size = size
        self.std = std
        self.mu = mu
        self.theta = theta
        self.dt = dt
        self.x0 = x0
        self.reset()

    def reset(self):
        self.state = self.x0 if self.x0 is not None else np.zeros(self.size)

    def sample(self):
        x = self.state
        dx = self.theta * (self.mu - x) * self.dt + self.std * np.sqrt(self.dt) * np.random.randn(self.size)
        self.state = x + dx
        return self.state

# DDPG agent
class DDPG(OffPolicyAgentAC):
    def __init__(
        self,
        env,
        noise=OrnsteinUhlenbeckNoise,
        noise_std=0.1,
        lr_policy=1e-4,
        lr_value=1e-3,
        gamma=0.99,
        polyak=0.995,
        update_interval=1,
        create_model=True,
        network="mlp",
        shared_layers=None,
        batch_size=64,
        device=None,
    ):
        super().__init__(env)
        self.noise = noise
        self.noise_std = noise_std
        self.lr_policy = lr_policy
        self.lr_value = lr_value
        self.gamma = gamma
        self.polyak = polyak
        self.update_interval = update_interval
        self.batch_size = batch_size
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")

        self.state_dim = env.observation_space.shape[0]
        self.action_dim = env.action_space.shape[0]
        self.action_low = env.action_space.low
        self.action_high = env.action_space.high

        if hasattr(env.action_space, "n"):
            raise ValueError("DDPG does not support discrete action spaces")

        self.noise_process = self.noise(self.action_dim, std=self.noise_std)

        if create_model:
            self._create_model(network, shared_layers)

        self.empty_logs()

    def _create_model(self, network, shared_layers):
        if isinstance(network, str):
            if network.lower() == "mlp":
                self.ac = ActorCritic(
                    self.state_dim,
                    self.action_dim,
                    self.action_low,
                    self.action_high,
                    hidden_sizes=shared_layers or [256, 256],
                ).to(self.device)
            else:
                raise NotImplementedError(f"Network type {network} not implemented")
        else:
            self.ac = network.to(self.device)

        self.ac_target = copy.deepcopy(self.ac).to(self.device)
        for param in self.ac_target.parameters():
            param.requires_grad = False

        self.policy_optimizer = optim.Adam(self.ac.actor.parameters(), lr=self.lr_policy)
        self.value_optimizer = optim.Adam(self.ac.critic.parameters(), lr=self.lr_value)

    def update_params(self, steps=1):
        for _ in range(steps):
            if len(self.replay_buffer) < self.batch_size:
                return

            states, actions, rewards, next_states, dones = self.replay_buffer.sample(self.batch_size)

            states = torch.tensor(states, dtype=torch.float32, device=self.device)
            actions = torch.tensor(actions, dtype=torch.float32, device=self.device)
            rewards = torch.tensor(rewards, dtype=torch.float32, device=self.device)
            next_states = torch.tensor(next_states, dtype=torch.float32, device=self.device)
            dones = torch.tensor(dones, dtype=torch.float32, device=self.device)

            # Compute target Q values
            with torch.no_grad():
                next_actions = self.ac_target.actor(next_states)
                next_q = self.ac_target.critic(torch.cat([next_states, next_actions], dim=-1))
                target_q = rewards + self.gamma * (1 - dones) * next_q.squeeze(-1)

            # Critic loss
            current_q = self.ac.critic(torch.cat([states, actions], dim=-1))
            value_loss = F.mse_loss(current_q.squeeze(-1), target_q)
            self.value_optimizer.zero_grad()
            value_loss.backward()
            self.value_optimizer.step()
            self.value_loss_log.append(value_loss.item())

            # Actor loss
            pred_actions = self.ac.actor(states)
            actor_loss = -self.ac.critic(torch.cat([states, pred_actions], dim=-1)).mean()
            self.policy_optimizer.zero_grad()
            actor_loss.backward()
            self.policy_optimizer.step()
            self.policy_loss_log.append(actor_loss.item())

            # Soft update target network
            for target_param, param in zip(self.ac_target.parameters(), self.ac.parameters()):
                target_param.data.copy_(self.polyak * target_param.data + (1.0 - self.polyak) * param.data)

    def get_hyperparams(self):
        return {
            "gamma": self.gamma,
            "lr_policy": self.lr_policy,
            "lr_value": self.lr_value,
            "noise_std": self.noise_std,
            "polyak": self.polyak,
            "update_interval": self.update_interval,
            "batch_size": self.batch_size,
            "state_dim": self.state_dim,
            "action_dim": self.action_dim,
            "model_weights": self.ac.state_dict(),
        }

    def get_logging_params(self):
        avg_policy_loss = np.mean(self.policy_loss_log) if self.policy_loss_log else 0.0
        avg_value_loss = np.mean(self.value_loss_log) if self.value_loss_log else 0.0
        logs = {
            "avg_policy_loss": avg_policy_loss,
            "avg_value_loss": avg_value_loss,
        }
        self.empty_logs()
        return logs

    def empty_logs(self):
        self.policy_loss_log = []
        self.value_loss_log = []