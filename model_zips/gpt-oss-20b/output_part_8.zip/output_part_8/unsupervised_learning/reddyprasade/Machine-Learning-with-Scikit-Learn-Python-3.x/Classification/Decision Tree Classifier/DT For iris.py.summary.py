import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, plot_tree

def main():
    # Load dataset
    url = "https://raw.githubusercontent.com/uiuc-cse/data-fa14/gh-pages/data/iris.csv"
    df = pd.read_csv(url)
    print("First 5 rows:")
    print(df.head())
    print("\nLast 5 rows:")
    print(df.tail())

    # Feature and target selection
    X = df[['sepal_length', 'sepal_width', 'petal_length', 'petal_width']]
    Y = df['species']

    # Train-test split
    x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.25)

    # Model instantiation and training
    clf = DecisionTreeClassifier()
    clf.fit(x_train, y_train)

    # Predictions
    yhat = clf.predict(x_test)

    # Feature importance analysis
    importances = clf.feature_importances_
    for feature, importance in zip(X.columns, importances):
        print(f"{feature}: {importance:.4f}")

    plt.figure(figsize=(8, 6))
    sns.barplot(x=importances, y=X.columns)
    plt.title("Feature Importances")
    plt.xlabel("Importance")
    plt.ylabel("Feature")
    plt.tight_layout()
    plt.show()

    # Decision tree visualization (default)
    plt.figure(figsize=(16, 9))
    plot_tree(clf)
    plt.title("Decision Tree")
    plt.tight_layout()
    plt.show()

    # Decision tree visualization (filled)
    plt.figure(figsize=(16, 9))
    plot_tree(clf, filled=True)
    plt.title("Decision Tree (Filled)")
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()