import numpy as np
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error

class svm_regr:
    def __init__(self):
        self.model = SVR()

    def fit(self, X, y):
        self.model.fit(X, y)

    def predict(self, X):
        return self.model.predict(X)

    def loss(self, y_true, y_pred):
        return mean_squared_error(y_true, y_pred)