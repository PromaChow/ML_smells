import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import mean_squared_error

class CustomLogisticRegression:
    def __init__(self):
        self.model = LogisticRegression(penalty='l2')
        self.flag = False
        self.flag_y_pred = None

    def fit(self, X, y):
        unique_labels = np.unique(y)
        if len(unique_labels) == 1:
            self.flag = True
            self.flag_y_pred = unique_labels[0]
        else:
            self.flag = False
            self.model.fit(X, y)

    def predict(self, X):
        if self.flag:
            return np.full(shape=(len(X),), fill_value=self.flag_y_pred)
        return self.model.predict(X)

    def loss(self, y_true, y_pred):
        return mean_squared_error(y_true, y_pred)