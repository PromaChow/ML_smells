import os
import pandas as pd
import numpy as np
from sklearn.svm import SVR
from joblib import dump
import datasetUtils as dsu
import embeddings

def main():
    # Configuration
    post_threshold = 3
    dataset_path = "fasttext.vec"  # path to FastText embedding file

    # Load training dataset
    dtype_map = {
        "userid": "int64",
        "ope": "float32",
        "con": "float32",
        "ext": "float32",
        "agr": "float32",
        "neu": "float32",
        "message": "string"
    }
    df = pd.read_csv(
        "join.csv",
        nrows=20000000,
        dtype=dtype_map,
        on_bad_lines="skip",
        encoding="utf-8",
        low_memory=False
    )

    # Shuffle and sample
    df_subset = df.sample(n=30000, random_state=42).reset_index(drop=True)

    # Load FastText embeddings
    wordDictionary = dsu.parseFastText(dataset_path)

    # Prepare data
    posts = df_subset["message"].values
    yO = df_subset["ope"].values
    yC = df_subset["con"].values
    yE = df_subset["ext"].values
    yA = df_subset["agr"].values
    yN = df_subset["neu"].values

    # Transform text into embeddings
    conE, *_ = embeddings.transformTextForTraining(
        wordDictionary,
        post_threshold,
        posts,
        yO,
        yC,
        yE,
        yA,
        yN,
        "conc",
        True
    )

    # Ensure output directory exists
    output_dir = os.path.join("Models", "MPBig")
    os.makedirs(output_dir, exist_ok=True)

    # Hyperparameters per trait
    trait_params = {
        "ope": {"gamma": 0.01, "C": 1},
        "con": {"gamma": 0.01, "C": 1},
        "ext": {"gamma": 0.01, "C": 1},
        "agr": {"gamma": 0.01, "C": 1},
        "neu": {"gamma": 10, "C": 10},
    }

    # Trait labels mapping
    trait_labels = {
        "ope": yO,
        "con": yC,
        "ext": yE,
        "agr": yA,
        "neu": yN,
    }

    # Model filenames mapping
    trait_filenames = {
        "ope": "SVM_Big_conc_O.pkl",
        "con": "SVM_Big_conc_C.pkl",
        "ext": "SVM_Big_conc_E.pkl",
        "agr": "SVM_Big_conc_A.pkl",
        "neu": "SVM_Big_conc_N.pkl",
    }

    # Train and save models
    for trait, params in trait_params.items():
        svr = SVR(kernel="rbf", gamma=params["gamma"], C=params["C"])
        svr.fit(conE, trait_labels[trait])
        model_path = os.path.join(output_dir, trait_filenames[trait])
        dump(svr, model_path)

if __name__ == "__main__":
    main()
