import torch
from torch.utils.data import DataLoader, ConcatDataset
from utils import (
    get_cifar10,
    get_cifar100,
    get_svhn,
    get_stl10,
    dataset_split,
    get_zca_normalization_param,
)
from augmentation import gen_weak_augmentation, gen_strong_augmentation
from dataset import LabeledDataset, UnlabeledDataset
from sampler import InfiniteSampler


def get_data_loaders(cfg, logger=None, ul_data=None):
    # Dataset loading
    if cfg.dataset == "cifar10":
        train_data, test_data = get_cifar10()
        num_classes, img_size = 10, 32
    elif cfg.dataset == "cifar100":
        train_data, test_data = get_cifar100()
        num_classes, img_size = 100, 32
    elif cfg.dataset == "svhn":
        train_data, test_data = get_svhn()
        num_classes, img_size = 10, 32
    elif cfg.dataset == "stl10":
        train_data, test_data, unlabeled_data = get_stl10()
        num_classes, img_size = 10, 96
    else:
        raise ValueError(f"Unsupported dataset: {cfg.dataset}")

    # Shuffling and splitting
    torch.manual_seed(cfg.seed)
    indices = torch.randperm(len(train_data))
    train_data = torch.utils.data.Subset(train_data, indices)

    if cfg.validation_split:
        val_ratio = cfg.val_ratio
        val_data, remaining_data = dataset_split(train_data, val_ratio)
        l_train_data, ul_train_data = dataset_split(
            remaining_data, cfg.num_labels / len(remaining_data)
        )
        if cfg.dataset == "stl10" and unlabeled_data is not None:
            ul_train_data = ConcatDataset([ul_train_data, unlabeled_data])
    else:
        l_train_data, ul_train_data = dataset_split(
            train_data, cfg.num_labels / len(train_data)
        )
        if cfg.dataset == "stl10" and unlabeled_data is not None:
            ul_train_data = ConcatDataset([ul_train_data, unlabeled_data])
        val_data = None

    # Combined unlabeled dataset
    unlabeled_combined = ConcatDataset([l_train_data, ul_train_data])

    # Normalization parameters
    if cfg.whiten:
        loader = DataLoader(train_data, batch_size=512, shuffle=False, num_workers=2)
        means = torch.zeros(3)
        stds = torch.zeros(3)
        n = 0
        for images, _ in loader:
            batch_size = images.size(0)
            means += images.view(batch_size, 3, -1).mean(2).sum(0)
            stds += images.view(batch_size, 3, -1).std(2).sum(0)
            n += batch_size
        mean = means / n
        scale = stds / n
    elif cfg.zca:
        mean, scale, zca_matrix = get_zca_normalization_param(train_data, cfg.seed)
    else:
        mean = torch.tensor([0.5, 0.5, 0.5])
        scale = torch.tensor([0.5, 0.5, 0.5])
        zca_matrix = None

    # Augmentation configuration
    weak_flags = cfg.wa.split(",")
    strong_flags = [f for f in cfg.wa.split(",") if f == "RA"]

    if cfg.labeled_aug == "WA":
        l_aug = gen_weak_augmentation(weak_flags)
    else:
        l_aug = None

    if cfg.unlabeled_aug == "WA":
        ul_weak_aug = gen_weak_augmentation(weak_flags)
        ul_strong_aug = None
    elif cfg.unlabeled_aug == "RA":
        ul_weak_aug = None
        ul_strong_aug = gen_strong_augmentation(strong_flags)
    else:
        ul_weak_aug = None
        ul_strong_aug = None

    # Dataset and DataLoader creation
    l_train_ds = LabeledDataset(
        l_train_data,
        transform=l_aug,
        normalize=(mean, scale, zca_matrix),
    )
    ul_train_ds = UnlabeledDataset(
        unlabeled_combined,
        weak_transform=ul_weak_aug,
        strong_transform=ul_strong_aug,
        normalize=(mean, scale, zca_matrix),
    )
    test_ds = LabeledDataset(
        test_data,
        transform=None,
        normalize=(mean, scale, zca_matrix),
    )
    if val_data is not None:
        val_ds = LabeledDataset(
            val_data,
            transform=None,
            normalize=(mean, scale, zca_matrix),
        )

    l_train_loader = DataLoader(
        l_train_ds,
        batch_size=cfg.l_batch_size,
        sampler=InfiniteSampler(l_train_ds),
        num_workers=4,
    )
    ul_train_loader = DataLoader(
        ul_train_ds,
        batch_size=cfg.ul_batch_size,
        sampler=InfiniteSampler(ul_train_ds),
        num_workers=4,
    )
    test_loader = DataLoader(
        test_ds,
        batch_size=1,
        shuffle=False,
        num_workers=2,
    )
    if val_data is not None:
        val_loader = DataLoader(
            val_ds,
            batch_size=1,
            shuffle=False,
            num_workers=2,
        )
    else:
        val_loader = None

    # Logging
    if logger is not None:
        logger.info(f"Training samples: {len(train_data)}")
        logger.info(f"Labeled samples: {len(l_train_data)}")
        logger.info(f"Unlabeled samples: {len(unlabeled_combined)}")
        if val_loader is not None:
            logger.info(f"Validation samples: {len(val_data)}")
        logger.info(f"Test samples: {len(test_data)}")
        logger.info(f"Labeled augmentation: {cfg.labeled_aug}")
        logger.info(f"Unlabeled augmentation: {cfg.unlabeled_aug}")

    return {
        "l_train_loader": l_train_loader,
        "ul_train_loader": ul_train_loader,
        "test_loader": test_loader,
        "val_loader": val_loader,
    }