import numpy as np
import sys
from io import StringIO

import gymnasium
from gymnasium.envs.toy_text.discrete import DiscreteEnv


class GridworldEnv(DiscreteEnv):
    """Gridworld environment based on Sutton & Barto's RL book."""

    def __init__(self, shape=(4, 4)):
        # Validate shape
        if not isinstance(shape, (list, tuple)) or len(shape) != 2:
            raise ValueError("shape must be a 2‑tuple or list of two integers")
        self.shape = tuple(shape)
        self.MAX_Y, self.MAX_X = self.shape

        # Number of states and actions
        self.nS = self.MAX_Y * self.MAX_X
        self.nA = 4  # UP, RIGHT, DOWN, LEFT

        # Transition probability matrix
        P = {}
        for y, x in np.ndindex(self.shape):
            s = y * self.MAX_X + x
            P[s] = {}
            for a in range(self.nA):
                if s == 0 or s == self.nS - 1:
                    # Terminal states
                    P[s][a] = [(1.0, s, 0.0, True)]
                else:
                    if a == 0:  # UP
                        ns = s - self.MAX_X if y > 0 else s
                    elif a == 1:  # RIGHT
                        ns = s + 1 if x < self.MAX_X - 1 else s
                    elif a == 2:  # DOWN
                        ns = s + self.MAX_X if y < self.MAX_Y - 1 else s
                    elif a == 3:  # LEFT
                        ns = s - 1 if x > 0 else s
                    else:
                        ns = s
                    P[s][a] = [(1.0, ns, -1.0, False)]

        # Initial state distribution (uniform)
        isd = np.ones(self.nS) / self.nS

        # Assign the transition matrix before calling super
        self.P = P
        super().__init__(self.nS, self.nA, self.P, isd)

    def _render(self, mode='human'):
        out = StringIO()
        for y in range(self.MAX_Y):
            for x in range(self.MAX_X):
                s = y * self.MAX_X + x
                if s == self.s:
                    out.write(" x ")
                elif s == 0 or s == self.nS - 1:
                    out.write(" T ")
                else:
                    out.write(" o ")
            out.write("\n")
        output = out.getvalue()
        if mode == 'human':
            sys.stdout.write(output)
        else:
            return output
