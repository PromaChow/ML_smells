import os
import pandas as pd
import matplotlib.pyplot as plt
import qtrader
from qtrader.utils import econometric, plotting


def stats(returns: pd.Series) -> pd.Series:
    """
    Compute a set of financial metrics for the given strategy returns.

    Parameters
    ----------
    returns : pd.Series
        Realised strategy returns.

    Returns
    -------
    pd.Series
        Series of computed metrics named after the input returns series.
    """
    metrics = {
        "Mean Return": econometric.mean(returns),
        "Cumulative Return": econometric.cumulative(returns),
        "Annualised Volatility": econometric.volatility(returns, annual=True),
        "Sharpe Ratio": econometric.sharpe_ratio(returns),
        "Max Drawdown": econometric.max_drawdown(returns),
        "Skewness": econometric.skewness(returns),
        "Kurtosis": econometric.kurtosis(returns),
        "Value at Risk": econometric.value_at_risk(returns, confidence=0.95),
        "Conditional VaR": econometric.cvar(returns, confidence=0.95),
        "Sortino Ratio": econometric.sortino_ratio(returns),
        "Alpha": econometric.alpha(returns),
        "Beta": econometric.beta(returns),
        "Treynor Ratio": econometric.treynor_ratio(returns),
        "Information Ratio": econometric.information_ratio(returns),
        "Calmar Ratio": econometric.calmar_ratio(returns),
    }

    name = returns.name if returns.name else "Strategy"
    return pd.Series(metrics, name=name)


def figure(
    prices: pd.DataFrame,
    returns: pd.Series,
    weights: pd.DataFrame,
    path: str | None = None,
) -> None:
    """
    Generate and optionally save visualisations for strategy performance.

    Parameters
    ----------
    prices : pd.DataFrame
        Asset price data indexed by date with tickers as columns.
    returns : pd.Series
        Strategy realised returns indexed by date.
    weights : pd.DataFrame
        Portfolio weights indexed by date with tickers as columns.
    path : str, optional
        Directory to save the generated figures. If None, figures are shown
        interactively.
    """
    if path:
        os.makedirs(path, exist_ok=True)

    # Drawdown plot
    plotting.drawdown(returns, path=path)

    # Trades plot for each asset
    for ticker in prices.columns:
        if ticker not in weights.columns:
            continue
        plotting.trades(prices[ticker], weights[ticker], path=path)

    # Show plots if not saving to a path
    if not path:
        plt.show()
