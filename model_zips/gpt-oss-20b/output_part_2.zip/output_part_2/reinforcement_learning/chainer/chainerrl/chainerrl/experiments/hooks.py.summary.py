import abc
from typing import Callable, Any
import numpy as np

class StepHook(abc.ABC):
    """Abstract base class for hooks that are executed at each step."""

    @abc.abstractmethod
    def __call__(self, env: Any, agent: Any, step: int) -> None:
        """
        Execute the hook logic.

        Parameters
        ----------
        env : Any
            The environment instance. It is passed for compatibility
            with potential future extensions but is not used by default.
        agent : Any
            The agent instance to which the hook may apply changes.
        step : int
            The current step index, starting from 0.
        """
        pass


class LinearInterpolationHook(StepHook):
    """
    A hook that linearly interpolates a value between ``start`` and ``stop``
    over ``total_steps`` steps and applies it to the agent using the
    provided ``setter`` function.
    """

    def __init__(
        self,
        start: float,
        stop: float,
        total_steps: int,
        setter: Callable[[Any, float], None],
    ) -> None:
        """
        Parameters
        ----------
        start : float
            The value at step 0.
        stop : float
            The value at step ``total_steps``.
        total_steps : int
            The number of steps over which interpolation occurs. Must be > 0.
        setter : Callable[[Any, float], None]
            Function that receives the agent and the interpolated value
            and applies the value to the agent (e.g., updating a learning rate).
        """
        if total_steps <= 0:
            raise ValueError("total_steps must be a positive integer.")
        self.start = float(start)
        self.stop = float(stop)
        self.total_steps = int(total_steps)
        self.setter = setter

    def __call__(self, env: Any, agent: Any, step: int) -> None:
        # Map step from 0..total_steps-1 to 1..total_steps for np.interp
        x = min(max(step + 1, 1), self.total_steps)
        value = np.interp(x, [1, self.total_steps], [self.start, self.stop])
        self.setter(agent, float(value))

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}(start={self.start}, stop={self.stop}, "
            f"total_steps={self.total_steps})"
        )