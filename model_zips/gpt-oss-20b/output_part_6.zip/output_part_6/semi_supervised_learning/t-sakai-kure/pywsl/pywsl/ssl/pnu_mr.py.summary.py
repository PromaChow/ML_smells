import numpy as np


def sqdist(X: np.ndarray, Z: np.ndarray) -> np.ndarray:
    """Squared Euclidean distance between rows of X and Z."""
    X_sq = np.sum(X ** 2, axis=1, keepdims=True)
    Z_sq = np.sum(Z ** 2, axis=1, keepdims=True).T
    return X_sq + Z_sq - 2 * X @ Z.T


def ker(X: np.ndarray, Z: np.ndarray, sigma: float, basis: str) -> np.ndarray:
    """Kernel matrix between X and basis Z."""
    if basis == "gauss":
        K = np.exp(-sqdist(X, Z) / (2 * sigma ** 2))
    elif basis == "lm":
        K = X @ Z.T
    else:
        raise ValueError(f"Unsupported basis: {basis}")
    return K


class PNU_SL:
    def __init__(
        self,
        prior: float,
        eta: int,
        sigma: float,
        lam: float,
        basis: str = "gauss",
        n_basis: int = 10,
        random_state: int | None = None,
    ):
        if not (0 < prior < 1):
            raise ValueError("prior must be in (0, 1)")
        if eta not in (0, 1):
            raise ValueError("eta must be 0 or 1")
        if sigma <= 0:
            raise ValueError("sigma must be positive")
        if lam < 0:
            raise ValueError("lam must be non-negative")
        if basis not in ("gauss", "lm"):
            raise ValueError("basis must be 'gauss' or 'lm'")
        if n_basis <= 0 or not isinstance(n_basis, int):
            raise ValueError("n_basis must be a positive integer")

        self.prior = prior
        self.eta = eta
        self.sigma = sigma
        self.lam = lam
        self.basis = basis
        self.n_basis = n_basis
        self.random_state = random_state

        self.coef_ = None
        self.centers_ = None
        self.Z_ = None
        self._rng = np.random.default_rng(random_state)

    def _prepare_basis(self, x: np.ndarray, y: np.ndarray):
        idx_u = np.where(y == 0)[0]
        if self.basis == "gauss":
            if len(idx_u) < self.n_basis:
                raise ValueError("Not enough unlabeled samples to select centers")
            centers_idx = self._rng.choice(idx_u, size=self.n_basis, replace=False)
            self.centers_ = x[centers_idx]
            self.Z_ = self.centers_
        else:  # lm basis
            # homogeneous coordinates: augment with 1
            X_aug = np.hstack([x, np.ones((x.shape[0], 1))])
            self.Z_ = X_aug

    def fit(self, x: np.ndarray, y: np.ndarray):
        if x.ndim != 2:
            raise ValueError("x must be a 2D array")
        if y.ndim != 1:
            raise ValueError("y must be a 1D array")
        if x.shape[0] != y.shape[0]:
            raise ValueError("x and y must have the same number of samples")
        if not set(np.unique(y)).issubset({-1, 0, 1}):
            raise ValueError("y must contain only -1, 0, +1")

        self._prepare_basis(x, y)

        idx_p = np.where(y == 1)[0]
        idx_n = np.where(y == -1)[0]
        idx_u = np.where(y == 0)[0]

        X_p = x[idx_p]
        X_n = x[idx_n]
        X_u = x[idx_u]

        K_p = ker(X_p, self.Z_, self.sigma, self.basis)
        K_n = ker(X_n, self.Z_, self.sigma, self.basis)
        K_u = ker(X_u, self.Z_, self.sigma, self.basis)

        H_pn = np.vstack([K_p, K_n])
        H_u = K_u

        y_pn = np.hstack([np.ones(len(idx_p)), -np.ones(len(idx_n))])

        # Regularization matrix
        Reg = self.lam * np.eye(self.Z_.shape[0])
        if self.basis == "lm" and Reg.shape[0] > 0:
            Reg[-1, -1] = 0.0

        M = H_pn.T @ H_pn + self.eta * H_u.T @ H_u + Reg
        b = H_pn.T @ y_pn
        self.coef_ = np.linalg.solve(M, b)

    def predict(self, x: np.ndarray) -> np.ndarray:
        if self.coef_ is None:
            raise RuntimeError("Model has not been fitted yet")
        K = ker(x, self.Z_, self.sigma, self.basis)
        scores = K @ self.coef_
        return np.sign(scores)

    def pnu_risk(self, x: np.ndarray, y: np.ndarray) -> float:
        preds = self.predict(x)
        idx_p = np.where(y == 1)[0]
        idx_n = np.where(y == -1)[0]
        fn = np.sum(preds[idx_p] == -1)
        fp = np.sum(preds[idx_n] == 1)
        denom = len(idx_p) + len(idx_n)
        if denom == 0:
            return np.nan
        return (fn + fp) / denom


class PNU_SL_FastCV:
    def __init__(
        self,
        n_fold: int = 5,
        sigma_list: list[float] | None = None,
        lambda_list: list[float] | None = None,
        eta_list: list[int] | None = None,
        random_state: int | None = None,
    ):
        if n_fold < 2:
            raise ValueError("n_fold must be at least 2")
        self.n_fold = n_fold
        self.sigma_list = sigma_list or [0.1, 1.0, 10.0]
        self.lambda_list = lambda_list or [0.0, 0.01, 0.1]
        self.eta_list = eta_list or [0, 1]
        self.random_state = random_state
        self.best_params_ = None
        self.best_model_ = None
        self.risk_history_ = {}

    def _split_folds(self, x: np.ndarray, y: np.ndarray):
        rng = np.random.default_rng(self.random_state)
        idx_p = np.where(y == 1)[0]
        idx_n = np.where(y == -1)[0]
        idx_u = np.where(y == 0)[0]

        def split_idx(idx):
            shuffled = rng.permutation(idx)
            fold_sizes = [len(idx) // self.n_fold] * self.n_fold
            for i in range(len(idx) % self.n_fold):
                fold_sizes[i] += 1
            folds = []
            current = 0
            for size in fold_sizes:
                folds.append(shuffled[current : current + size])
                current += size
            return folds

        folds_p = split_idx(idx_p)
        folds_n = split_idx(idx_n)
        folds_u = split_idx(idx_u)
        return folds_p, folds_n, folds_u

    def _evaluate(self, params):
        sigma, lam, eta = params
        folds_p, folds_n, folds_u = self._split_folds(self.X_, self.y_)
        risks = []
        for i in range(self.n_fold):
            idx_train_p = np.hstack([folds_p[j] for j in range(self.n_fold) if j != i])
            idx_train_n = np.hstack([folds_n[j] for j in range(self.n_fold) if j != i])
            idx_train_u = np.hstack([folds_u[j] for j in range(self.n_fold) if j != i])

            idx_test_p = folds_p[i]
            idx_test_n = folds_n[i]
            idx_test_u = folds_u[i]

            idx_train = np.hstack([idx_train_p, idx_train_n, idx_train_u])
            idx_test = np.hstack([idx_test_p, idx_test_n, idx_test_u])

            X_train = self.X_[idx_train]
            y_train = self.y_[idx_train]
            X_test = self.X_[idx_test]
            y_test = self.y_[idx_test]

            model = PNU_SL(
                prior=self.prior_,
                eta=eta,
                sigma=sigma,
                lam=lam,
                basis=self.basis_,
                n_basis=self.n_basis_,
                random_state=self.random_state,
            )
            model.fit(X_train, y_train)
            risk = model.pnu_risk(X_test, y_test)
            risks.append(risk)
        avg_risk = np.mean(risks)
        return avg_risk

    def fit(self, x: np.ndarray, y: np.ndarray, prior: float | None = None):
        if x.ndim != 2:
            raise ValueError("x must be a 2D array")
        if y.ndim != 1:
            raise ValueError("y must be a 1D array")
        if x.shape[0] != y.shape[0]:
            raise ValueError("x and y must have the same number of samples")
        if not set(np.unique(y)).issubset({-1, 0, 1}):
            raise ValueError("y must contain only -1, 0, +1")

        self.X_ = x
        self.y_ = y
        self.prior_ = prior if prior is not None else np.mean(y == 1)
        self.basis_ = "gauss"  # fixed for this implementation
        self.n_basis_ = 20

        best_risk = np.inf
        best_params = None

        for sigma in self.sigma_list:
            for lam in self.lambda_list:
                for eta in self.eta_list:
                    params = (sigma, lam, eta)
                    risk = self._evaluate(params)
                    self.risk_history_[params] = risk
                    if risk < best_risk:
                        best_risk = risk
                        best_params = params

        self.best_params_ = best_params
        sigma, lam, eta = best_params
        self.best_model_ = PNU_SL(
            prior=self.prior_,
            eta=eta,
            sigma=sigma,
            lam=lam,
            basis=self.basis_,
            n_basis=self.n_basis_,
            random_state=self.random_state,
        )
        self.best_model_.fit(self.X_, self.y_)

    def predict(self, x: np.ndarray) -> np.ndarray:
        if self.best_model_ is None:
            raise RuntimeError("CV has not been performed yet")
        return self.best_model_.predict(x)

    def pnu_risk(self, x: np.ndarray, y: np.ndarray) -> float:
        if self.best_model_ is None:
            raise RuntimeError("CV has not been performed yet")
        return self.best_model_.pnu_risk(x, y)
