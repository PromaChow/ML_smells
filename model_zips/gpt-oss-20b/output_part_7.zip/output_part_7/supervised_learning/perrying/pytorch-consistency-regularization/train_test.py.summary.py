import argparse
import json
import os
import random
import copy
from collections import deque

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader

# Assume custom modules are available
from utils import model_utils
from data import gen_dataloader
from model import gen_model
from consistency import gen_consistency
from ssl_alg import gen_ssl_alg
from evaluation import evaluation

# --------------------------------------
# Utility classes
# --------------------------------------
class Meter:
    def __init__(self):
        self.reset()

    def reset(self):
        self.sum = 0.0
        self.count = 0

    def update(self, val, n=1):
        self.sum += val * n
        self.count += n

    @property
    def avg(self):
        return self.sum / self.count if self.count != 0 else 0.0

# --------------------------------------
# EMA helper
# --------------------------------------
def ema_update(ema_model, student_model, decay):
    for ema_param, student_param in zip(ema_model.parameters(), student_model.parameters()):
        ema_param.data.mul_(decay).add_(student_param.data, alpha=1 - decay)

# --------------------------------------
# Temperature scaling annealing (TSA)
# --------------------------------------
def tsa_mask(logits, labels, step, total_steps, start, end):
    prob = torch.softmax(logits, dim=1).gather(1, labels.unsqueeze(1)).squeeze(1)
    threshold = start + (end - start) * step / total_steps
    mask = prob < threshold
    return mask.float()

# --------------------------------------
# Main training function
# --------------------------------------
def train(cfg):
    # Seed
    torch.manual_seed(cfg.seed)
    np.random.seed(cfg.seed)
    random.seed(cfg.seed)

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # Data
    (
        labeled_loader,
        unlabeled_loader,
        test_loader,
        n_classes,
        img_size,
    ) = gen_dataloader(
        cfg.data_root,
        cfg.batch_size,
        cfg.labeled_ratio,
        cfg.unlabeled_ratio,
        cfg.num_workers,
        cfg.pin_memory,
    )

    labeled_iter = iter(labeled_loader)
    unlabeled_iter = iter(unlabeled_loader)

    # Models
    student_model = gen_model(cfg.model, n_classes).to(device)
    teacher_model = None
    eval_model = None

    if cfg.ema_teacher:
        teacher_model = copy.deepcopy(student_model)
        teacher_model.eval()
    if cfg.weight_average:
        eval_model = copy.deepcopy(student_model)
        eval_model.eval()

    # Consistency and SSL algorithm
    consistency_fn = gen_consistency(cfg.consistency, n_classes, device)
    ssl_alg = gen_ssl_alg(cfg.alg, n_classes, device)

    # Optimizer
    if cfg.optimizer.lower() == 'adam':
        optimizer = optim.Adam(
            student_model.parameters(),
            lr=cfg.lr,
            weight_decay=0.0 if cfg.weight_decay == 0 else cfg.weight_decay,
        )
    else:
        optimizer = optim.SGD(
            student_model.parameters(),
            lr=cfg.lr,
            momentum=cfg.momentum,
            weight_decay=0.0 if cfg.weight_decay == 0 else cfg.weight_decay,
        )

    # Scheduler
    if cfg.lr_decay.lower() == 'cosine':
        scheduler = optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=cfg.iteration, eta_min=cfg.lr_min
        )
    else:
        scheduler = optim.lr_scheduler.MultiStepLR(
            optimizer, milestones=cfg.lr_milestones, gamma=cfg.lr_gamma
        )

    # Meters
    loss_meter = Meter()
    acc_meter = Meter()
    coef_meter = Meter()

    # Checkpoint tracking
    checkpoint_acc = []

    for step in range(1, cfg.iteration + 1):
        student_model.train()
        if teacher_model:
            teacher_model.eval()

        # Get labeled batch
        try:
            x_l1, x_l2, y_l = next(labeled_iter)
        except StopIteration:
            labeled_iter = iter(labeled_loader)
            x_l1, x_l2, y_l = next(labeled_iter)

        # Get unlabeled batch
        try:
            x_u_w, x_u_s = next(unlabeled_iter)
        except StopIteration:
            unlabeled_iter = iter(unlabeled_loader)
            x_u_w, x_u_s = next(unlabeled_iter)

        # Move to device
        x_l1 = x_l1.to(device)
        x_l2 = x_l2.to(device)
        y_l = y_l.to(device)
        x_u_w = x_u_w.to(device)
        x_u_s = x_u_s.to(device)

        # Forward labeled
        logits_l1 = student_model(x_l1)
        logits_l2 = student_model(x_l2)

        # Supervised loss
        ce_loss = nn.CrossEntropyLoss()(logits_l1, y_l)

        if cfg.tsa:
            tsa = tsa_mask(
                logits_l1,
                y_l,
                step,
                cfg.iteration,
                cfg.tsa_start,
                cfg.tsa_end,
            )
            ce_loss = (ce_loss * tsa).mean()

        # Consistency loss
        cons_loss = 0.0
        if cfg.coef > 0.0:
            with torch.no_grad():
                if teacher_model:
                    weak_logits = teacher_model(x_u_w)
                else:
                    weak_logits = student_model(x_u_w)
                pseudo = consistency_fn(weak_logits)

            strong_logits = student_model(x_u_s)
            cons_loss = ssl_alg.compute_loss(pseudo, strong_logits)
            cons_loss = cons_loss * cfg.coef

            if cfg.entropy_minimization:
                p_w = torch.softmax(weak_logits, dim=1)
                entropy = -torch.sum(p_w * torch.log(p_w + 1e-8), dim=1).mean()
                cons_loss += cfg.entropy_coef * entropy

        total_loss = ce_loss + cons_loss

        # Backprop
        optimizer.zero_grad()
        total_loss.backward()
        if cfg.weight_decay > 0:
            model_utils.apply_weight_decay(student_model, cfg.weight_decay)
        optimizer.step()
        scheduler.step()

        # EMA updates
        if teacher_model:
            ema_update(teacher_model, student_model, cfg.ema_decay)
        if eval_model:
            ema_update(eval_model, student_model, cfg.ema_decay)

        # Accuracy
        preds = torch.argmax(logits_l1, dim=1)
        acc = (preds == y_l).float().mean().item()

        # Update meters
        loss_meter.update(total_loss.item(), y_l.size(0))
        acc_meter.update(acc, y_l.size(0))
        coef_meter.update(cfg.coef)

        # Logging
        if step % cfg.disp == 0 or step == 1:
            print(
                f"Step [{step}/{cfg.iteration}] "
                f"Loss: {loss_meter.avg:.4f} "
                f"Acc: {acc_meter.avg:.4f} "
                f"Coef: {coef_meter.avg:.4f} "
                f"LR: {scheduler.get_last_lr()[0]:.6f}"
            )
            loss_meter.reset()
            acc_meter.reset()
            coef_meter.reset()

        # Evaluation
        if step % cfg.eval_interval == 0 or step == cfg.iteration:
            student_acc, student_loss = evaluation(
                student_model, test_loader, device
            )
            if eval_model:
                eval_acc, eval_loss = evaluation(
                    eval_model, test_loader, device
                )
            else:
                eval_acc, eval_loss = None, None

            print(
                f"Evaluation at step {step}: "
                f"Student Acc {student_acc:.4f}, "
                f"Student Loss {student_loss:.4f}"
            )
            if eval_acc is not None:
                print(
                    f"Eval Model Acc {eval_acc:.4f}, "
                    f"Eval Loss {eval_loss:.4f}"
                )

        # Checkpoint
        if step % cfg.checkpoint == 0 or step == cfg.iteration:
            ckpt_dir = os.path.join(cfg.out_dir, 'checkpoints')
            os.makedirs(ckpt_dir, exist_ok=True)
            ckpt_path = os.path.join(ckpt_dir, f'ckpt_{step}.pth')
            torch.save(
                {
                    'step': step,
                    'student_state_dict': student_model.state_dict(),
                    'teacher_state_dict': teacher_model.state_dict()
                    if teacher_model
                    else None,
                    'eval_state_dict': eval_model.state_dict()
                    if eval_model
                    else None,
                    'optimizer_state_dict': optimizer.state_dict(),
                    'scheduler_state_dict': scheduler.state_dict(),
                },
                ckpt_path,
            )
            checkpoint_acc.append(student_acc)

    # Final results
    out_dir = cfg.out_dir
    os.makedirs(out_dir, exist_ok=True)
    np.save(os.path.join(out_dir, 'test_acc.npy'), np.array(checkpoint_acc))
    with open(os.path.join(out_dir, 'median_acc.json'), 'w') as f:
        json.dump(
            {
                'median_1': np.median(checkpoint_acc[-1:]),
                'median_10': np.median(checkpoint_acc[-10:]) if len(checkpoint_acc) >= 10 else np.nan,
                'median_20': np.median(checkpoint_acc[-20:]) if len(checkpoint_acc) >= 20 else np.nan,
                'median_50': np.median(checkpoint_acc[-50:]) if len(checkpoint_acc) >= 50 else np.nan,
            },
            f,
        )

# --------------------------------------
# Configuration dataclass
# --------------------------------------
class Config:
    def __init__(self, args):
        self.seed = 42
        self.data_root = args.data_root
        self.out_dir = args.out_dir
        self.batch_size = 64
        self.labeled_ratio = 0.1
        self.unlabeled_ratio = 0.9
        self.num_workers = 4
        self.pin_memory = True

        self.model = 'resnet50'
        self.optimizer = 'sgd'
        self.lr = 0.03
        self.momentum = 0.9
        self.weight_decay = 5e-4
        self.lr_decay = 'cosine'
        self.lr_min = 1e-5
        self.lr_milestones = [100000, 200000]
        self.lr_gamma = 0.1
        self.iteration = 300000
        self.disp = 500
        self.eval_interval = 10000
        self.checkpoint = 50000

        self.ema_teacher = True
        self.ema_decay = 0.99
        self.weight_average = True

        self.consistency = 'cross_entropy'
        self.alg = 'mixmatch'
        self.coef = 1.0
        self.tsa = True
        self.tsa_start = 0.5
        self.tsa_end = 1.0
        self.entropy_minimization = False
        self.entropy_coef = 0.01

# --------------------------------------
# Entry point
# --------------------------------------
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--data_root', type=str, required=True)
    parser.add_argument('--out_dir', type=str, required=True)
    args = parser.parse_args()

    cfg = Config(args)
    train(cfg)