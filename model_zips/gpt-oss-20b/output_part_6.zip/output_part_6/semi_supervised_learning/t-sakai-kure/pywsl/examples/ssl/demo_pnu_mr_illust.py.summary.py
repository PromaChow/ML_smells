import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from sklearn.model_selection import GridSearchCV
from pywsl import PNU_SL, cpe, gen_twonorm_ssl, bin_clf_err

sns.set(style='whitegrid', context='talk')

# ---------------------- Parameter Configuration ----------------------
n_l = 20
n_u = 1000
n_t = 1000
prior_l = 0.5
prior_u = 0.3

eta_list = np.arange(-0.9, 1, 0.1)
n_trial = 20

errs1 = np.zeros(n_trial)
errs2 = np.zeros((n_trial, len(eta_list)))
priors_est = np.zeros(n_trial)

best_w = None
best_x = None
best_y = None
best_err = np.inf

# ---------------------- Main Loop Over Trials ----------------------
for t in range(n_trial):
    # Data Generation
    x, y, x_u, y_u, x_t, y_t = gen_twonorm_ssl(n_l=n_l, prior_l=prior_l,
                                                n_u=n_u, prior_u=prior_u,
                                                n_t=n_t)

    # Class Prior Estimation on unlabeled data
    prior_est = cpe(x_l=x, y_l=y, x_u=x_u, y_u=y_u, prior_l=prior_l)
    priors_est[t] = prior_est

    # Model Training with Grid Search
    clf = PNU_SL(lam=0.1, basis='lm', prior=prior_est)
    param_grid = {'eta': eta_list}
    grid = GridSearchCV(clf, param_grid, cv=2, scoring='neg_log_loss')
    grid.fit(np.vstack((x, x_u)), np.concatenate((y, y_u)))
    best_eta = grid.best_params_['eta']
    clf = grid.best_estimator_
    clf.fit(np.vstack((x, x_u)), np.concatenate((y, y_u)))

    # Error Calculation on test data
    y_pred = clf.predict(x_t)
    err = bin_clf_err(y_pred, y_t, prior_u)
    errs1[t] = err

    if err < best_err:
        best_err = err
        best_w = clf.w_.copy()
        best_x = np.vstack((x, x_u))
        best_y = np.concatenate((y, y_u))

    # Additional evaluation for each eta
    for i, eta in enumerate(eta_list):
        clf_i = PNU_SL(lam=0.1, basis='lm', prior=prior_est, eta=eta)
        clf_i.fit(np.vstack((x, x_u)), np.concatenate((y, y_u)))
        y_pred_i = clf_i.predict(x_t)
        errs2[t, i] = bin_clf_err(y_pred_i, y_t, prior_u)

# ---------------------- Post-Processing and Results ----------------------
print(f'Average error (errs1): {errs1.mean():.4f} ± {errs1.std(ddof=1)/np.sqrt(n_trial):.4f}')
print(f'Average estimated prior: {priors_est.mean():.4f} ± {priors_est.std(ddof=1)/np.sqrt(n_trial):.4f}')

# ---------------------- Visualization ----------------------
# Figure 1: Data scatter and decision boundaries
plt.figure(figsize=(8, 6))
# Unlabeled
plt.scatter(x_u[:, 0], x_u[:, 1], color='k', s=20, alpha=0.6, label='Unlabeled')
# Positive class
plt.scatter(x[y==1, 0], x[y==1, 1], facecolors='none', edgecolors='b', s=80,
            linewidths=2, label='Positive')
# Negative class
plt.scatter(x[y==-1, 0], x[y==-1, 1], color='r', marker='x', s=80,
            linewidths=2, label='Negative')

# Reference decision boundary from prior (using symmetric line)
x_vals = np.linspace(np.min(x[:,0]), np.max(x[:,0]), 200)
y_vals = -x_vals  # placeholder for prior-based boundary
plt.plot(x_vals, y_vals, '--', color='gray', label='Prior-based boundary')

# Decision boundary from best model
if best_w is not None:
    a, b, c = best_w[0], best_w[1], best_w[2]
    if b != 0:
        y_best = -(a * x_vals + c) / b
        plt.plot(x_vals, y_best, '-', color='green', label='Best model boundary')
    else:
        plt.axvline(-c/a, color='green', label='Best model boundary')

plt.title('Synthetic Data and Decision Boundaries')
plt.xlabel('x1')
plt.ylabel('x2')
plt.legend()
plt.tight_layout()
plt.savefig('data.pdf')
plt.close()

# Figure 2: Error curve over eta
plt.figure(figsize=(8, 6))
err_mean = errs2.mean(axis=0)
err_se = errs2.std(axis=0, ddof=1) / np.sqrt(n_trial)
plt.errorbar(eta_list, err_mean, yerr=err_se, fmt='-o', color='blue')
plt.title('Test Error vs Eta')
plt.xlabel('Eta')
plt.ylabel('Misclassification Rate')
plt.tight_layout()
plt.savefig('err_curve.pdf')
plt.close()
```