import numpy as np
from time import perf_counter
from collections import deque


class Logger:
    def __init__(self):
        self.records = {}

    def log_scalar(self, key, value):
        self.records[key] = value

    def describe(self, key, data, **kwargs):
        if not isinstance(data, (list, np.ndarray)):
            data = np.array(data)
        desc = {
            "count": data.size,
            "mean": np.mean(data),
            "std": np.std(data),
            "min": np.min(data),
            "25%": np.percentile(data, 25),
            "50%": np.percentile(data, 50),
            "75%": np.percentile(data, 75),
            "max": np.max(data),
        }
        self.records[key] = desc
        # Apply formatting kwargs if needed (ignored for simplicity)

    def __repr__(self):
        return f"Logger(records={self.records})"


class VecMonitor:
    def __init__(self):
        self.return_queue = deque()
        self.horizon_queue = deque()

    def add(self, ret, horizon):
        self.return_queue.append(ret)
        self.horizon_queue.append(horizon)


class Engine:
    def __init__(self, agent, env, logger_class=Logger):
        self.agent = agent
        self.env = env
        self.logger_class = logger_class
        self.iteration = 0

    def train(self, **kwargs):
        # 1. Agent Preparation
        self.agent.train()

        # 2. Timing Initialization
        start_time = perf_counter()

        # 3. Data Retrieval
        D = kwargs.get("D", [])

        # 4. Agent Learning
        out_agent = self.agent.learn(D)

        # 5. Logger Initialization
        logger = self.logger_class()

        # 6. Training Iteration Logging
        logger.log_scalar("training_iteration", self.iteration + 1)

        # 7. Time Tracking
        num_seconds = round(perf_counter() - start_time, 1)
        logger.log_scalar("elapsed_time_sec", num_seconds)

        # 8. Agent Output Logging
        for key, value in out_agent.items():
            logger.log_scalar(f"agent_{key}", value)

        # 9. Data Statistics Logging
        num_trajectories = len(D)
        num_timesteps = sum(len(traj.get("numpy_rewards", [])) for traj in D)
        accumulated_trained_timesteps = self.agent.total_timestep

        logger.log_scalar("num_trajectories", num_trajectories)
        logger.log_scalar("num_timesteps", num_timesteps)
        logger.log_scalar("accumulated_trained_timesteps", accumulated_trained_timesteps)

        # 10. Return Calculation
        G = [np.array(traj.get("numpy_rewards", [])).sum() for traj in D]
        logger.describe("returns", G, precision=2, line_width=80)

        # 11. Episode Info Extraction
        infos = [info for traj in D for info in traj.get("infos", []) if "episode" in info]
        online_returns = [info["episode"]["r"] for info in infos]
        online_horizons = [info["episode"]["l"] for info in infos]
        logger.describe("online_returns", online_returns, precision=2, line_width=80)
        logger.describe("online_horizons", online_horizons, precision=2, line_width=80)

        # 12. Monitor Environment Metrics
        monitor_env = getattr(self.env, "monitor_env", None)
        if monitor_env:
            return_queue = list(monitor_env.return_queue)
            horizon_queue = list(monitor_env.horizon_queue)
            logger.describe("monitor_returns", return_queue, precision=2, line_width=80)
            logger.describe("monitor_horizons", horizon_queue, precision=2, line_width=80)

        # Update iteration count
        self.iteration += 1

        # Return Logger
        return logger


# Dummy implementations for Agent and Env to demonstrate usage

class DummyAgent:
    def __init__(self):
        self.total_timestep = 0

    def train(self):
        pass

    def learn(self, D):
        self.total_timestep += sum(len(traj.get("numpy_rewards", [])) for traj in D)
        return {"loss": 0.05, "policy_updates": 3}


class DummyEnv:
    def __init__(self):
        self.monitor_env = VecMonitor()


# Example usage

if __name__ == "__main__":
    agent = DummyAgent()
    env = DummyEnv()
    engine = Engine(agent, env)

    # Create mock trajectories
    D = [
        {
            "numpy_rewards": [1, 2, 3],
            "infos": [{"episode": {"r": 6, "l": 3}}],
        },
        {
            "numpy_rewards": [0.5, 1.5],
            "infos": [{"episode": {"r": 2, "l": 2}}],
        },
    ]

    # Simulate monitor environment data
    env.monitor_env.add(6, 3)
    env.monitor_env.add(2, 2)

    logger = engine.train(D=D)
    print(logger)
