import unittest
import math
from collections import defaultdict

# Dummy game state representation
class GameState:
    def __init__(self, board_size=19):
        self.board_size = board_size
        self.legal_moves = [(x, y) for x in range(board_size) for y in range(board_size)]

    def clone(self):
        return GameState(self.board_size)

# Dummy distribution: weight increases from (0,0) to (18,18)
def dummy_distribution():
    board_size = 19
    total = 0
    dist = {}
    for x in range(board_size):
        for y in range(board_size):
            weight = x * board_size + y + 1
            dist[(x, y)] = weight
            total += weight
    for move in dist:
        dist[move] /= total
    return dist

_DUMMY_DISTRIBUTION = dummy_distribution()

def dummy_policy(state: GameState):
    return list(_DUMMY_DISTRIBUTION.items())

def dummy_value(state: GameState):
    return 0.0

def dummy_rollout(state: GameState):
    return dummy_policy(state)

# Import TreeNode and MCTS from the module under test
try:
    from mcts import TreeNode, MCTS
except ImportError:
    # Minimal placeholder implementations for testing purposes
    class TreeNode:
        def __init__(self, prior=1.0, parent=None, move=None):
            self.parent = parent
            self.move = move
            self.prior = prior
            self.children = {}
            self.visits = 0
            self.total_value = 0.0
            self.value = 0.0
            self.c_puct = 1.0

        def expand(self, policy_fn):
            if self.children:
                return
            for move, prob in policy_fn(GameState()):
                self.children[move] = TreeNode(prior=prob, parent=self, move=move)

        def select(self):
            best_score = -float("inf")
            best_move = None
            for move, child in self.children.items():
                u = self.c_puct * child.prior * math.sqrt(self.visits) / (1 + child.visits)
                score = child.value + u
                if score > best_score:
                    best_score = score
                    best_move = move
            return self.children[best_move]

        def update(self, leaf_value, recursive=False):
            self.visits += 1
            self.total_value += leaf_value
            self.value = self.total_value / self.visits
            if recursive and self.parent:
                self.parent.update(leaf_value, recursive=True)

    class MCTS:
        def __init__(self, policy_fn, value_fn, rollout_fn, board_size=19):
            self.policy_fn = policy_fn
            self.value_fn = value_fn
            self.rollout_fn = rollout_fn
            self.root = TreeNode(prior=1.0)

        def playout(self, n_simulations):
            for _ in range(n_simulations):
                node = self.root
                path = [node]
                while node.children:
                    node = node.select()
                    path.append(node)
                node.expand(self.policy_fn)
                leaf_value = self.value_fn(GameState())
                for n in reversed(path):
                    n.update(leaf_value)

        def get_move(self):
            best_visits = -1
            best_move = None
            for move, child in self.root.children.items():
                if child.visits > best_visits:
                    best_visits = child.visits
                    best_move = move
            return best_move

        def update_with_move(self, move):
            if move in self.root.children:
                self.root = self.root.children[move]
                self.root.parent = None
            else:
                self.root = TreeNode(prior=1.0)


class TestTreeNode(unittest.TestCase):
    def setUp(self):
        self.state = GameState()
        self.root = TreeNode(prior=1.0)

    def test_selection(self):
        self.root.expand(dummy_policy)
        selected_child = self.root.select()
        self.assertIsNotNone(selected_child)
        self.assertEqual(selected_child.move, (18, 18))
        self.assertIn((18, 18), self.root.children)

    def test_expansion(self):
        self.assertEqual(len(self.root.children), 0)
        self.root.expand(dummy_policy)
        self.assertEqual(len(self.root.children), 361)
        for move, child in self.root.children.items():
            self.assertAlmostEqual(child.prior, _DUMMY_DISTRIBUTION[move])

    def test_update(self):
        self.root.expand(dummy_policy)
        child = self.root.children[(18, 18)]
        self.root.update(1.0)
        child.update(0.0)
        expected_child_value = child.value
        self.assertAlmostEqual(expected_child_value,
                               _DUMMY_DISTRIBUTION[(18, 18)] * math.sqrt(self.root.visits) / (1 + child.visits))
        self.assertAlmostEqual(self.root.value, 1.0)

    def test_recursive_update(self):
        self.root.expand(dummy_policy)
        child = self.root.children[(18, 18)]
        self.root.update(1.0, recursive=True)
        child.update(0.0, recursive=True)
        self.assertAlmostEqual(self.root.value, 1.0)
        expected_child_value = child.value
        self.assertAlmostEqual(expected_child_value,
                               _DUMMY_DISTRIBUTION[(18, 18)] * math.sqrt(self.root.visits) / (1 + child.visits))

class TestMCTS(unittest.TestCase):
    def setUp(self):
        self.mcts = MCTS(dummy_policy, dummy_value, dummy_rollout)

    def test_playout(self):
        self.mcts.playout(8)
        most_probable_move = (18, 18)
        child = self.mcts.root.children.get(most_probable_move)
        self.assertIsNotNone(child)
        self.assertEqual(child.visits, 8)
        depth = 0
        node = self.mcts.root
        while node.children:
            node = node.select()
            depth += 1
        self.assertEqual(depth, 8)

    def test_playout_with_pass(self):
        def limited_policy(state):
            legal = state.legal_moves[:5]
            return [(move, _DUMMY_DISTRIBUTION[move]) for move in legal]

        mcts_pass = MCTS(limited_policy, dummy_value, dummy_rollout)
        mcts_pass.playout(8)
        self.assertEqual(len(mcts_pass.root.children), 5)
        for move in mcts_pass.root.children:
            self.assertIn(move, limited_policy(mcts_pass.root.state)[0])

    def test_get_move(self):
        self.mcts.playout(10)
        move = self.mcts.get_move()
        self.assertIn(move, self.mcts.root.children)
        self.mcts.update_with_move(move)
        self.assertIsNone(self.mcts.root.parent)

    def test_update_with_move(self):
        self.mcts.playout(10)
        move = (18, 18)
        self.mcts.update_with_move(move)
        self.assertIsNone(self.mcts.root.parent)
        self.assertIn((18, 17), self.mcts.root.children)

if __name__ == "__main__":
    unittest.main()