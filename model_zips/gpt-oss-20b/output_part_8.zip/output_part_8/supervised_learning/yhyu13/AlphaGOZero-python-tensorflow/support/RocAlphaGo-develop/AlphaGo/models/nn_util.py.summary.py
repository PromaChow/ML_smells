import json
import os
from typing import Any, Dict, Callable, Type

import tensorflow as tf
from tensorflow.keras.layers import Layer
from tensorflow.keras.models import Model, model_from_json
from tensorflow.keras import backend as K


# Registry for NeuralNetBase subclasses
subclasses: Dict[str, Type["NeuralNetBase"]] = {}


def neuralnet(cls: Type["NeuralNetBase"]) -> Type["NeuralNetBase"]:
    """Decorator to register NeuralNetBase subclasses."""
    subclasses[cls.__name__] = cls
    return cls


class Preprocess:
    """Placeholder preprocessing class."""

    def __init__(self, feature_list):
        self.feature_list = feature_list
        self.input_dim = len(feature_list)

    def to_dict(self) -> Dict[str, Any]:
        return {"feature_list": self.feature_list}

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Preprocess":
        return cls(d["feature_list"])


class NeuralNetBase:
    """Base class for neural networks with preprocessing and serialization."""

    def __init__(self, feature_list, init_network: bool = True):
        self.preprocess = Preprocess(feature_list)
        self.model: Model | None = None
        self.forward: Callable[[Any], Any] | None = None
        if init_network:
            self.create_network()
            self.forward = self._model_forward()

    def create_network(self):
        """Subclasses must implement this method to build the Keras model."""
        raise NotImplementedError("Subclasses must implement create_network()")

    def _model_forward(self) -> Callable[[Any], Any]:
        if self.model is None:
            raise ValueError("Model has not been created.")
        inputs = self.model.input
        outputs = self.model.output

        # Determine if learning phase is required
        if any(
            isinstance(layer, (tf.keras.layers.Dropout, tf.keras.layers.BatchNormalization))
            for layer in self.model.layers
        ):
            # Use a function that accepts the learning phase argument
            func = K.function([inputs, K.learning_phase()], [outputs])
            return lambda x: func([x, 0.0])[0]
        else:
            func = K.function([inputs], [outputs])
            return lambda x: func([x])[0]

    def load_model(self, json_path: str, weights_path: str | None = None):
        with open(json_path, "r") as f:
            meta = json.load(f)

        class_name = meta["class_name"]
        if class_name not in subclasses:
            raise ValueError(f"Unknown class name '{class_name}' in JSON.")
        cls = subclasses[class_name]

        # Instantiate with preprocessing info
        preprocess_dict = meta["preprocess"]
        self.__class__ = cls
        self.__init__(feature_list=preprocess_dict["feature_list"], init_network=False)

        # Load architecture
        architecture = meta["architecture"]
        self.model = model_from_json(architecture)

        # Load weights if provided
        if weights_path and os.path.isfile(weights_path):
            self.model.load_weights(weights_path)

        # Create forward function
        self.forward = self._model_forward()

    def save_model(self, json_path: str, weights_path: str | None = None):
        if self.model is None:
            raise ValueError("No model to save.")
        architecture = self.model.to_json()
        meta = {
            "class_name": self.__class__.__name__,
            "preprocess": self.preprocess.to_dict(),
            "architecture": architecture,
        }
        with open(json_path, "w") as f:
            json.dump(meta, f, indent=2)
        if weights_path:
            self.model.save_weights(weights_path)

    def predict(self, data):
        if self.forward is None:
            raise ValueError("Forward function not initialized.")
        return self.forward(data)


class Bias(Layer):
    """Custom Keras layer that adds a scalar bias to the input."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def build(self, input_shape):
        self.bias = self.add_weight(
            shape=(1,),
            initializer="zeros",
            trainable=True,
            name="bias",
        )
        super().build(input_shape)

    def call(self, inputs):
        return inputs + self.bias
