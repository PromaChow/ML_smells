import os
import pickle
import numpy as np
import gym
import pytest

from lagom import (
    Logger,
    RandomAgent,
    TimeStep,
    StepType,
    Trajectory,
    EpisodeRunner,
    StepRunner,
    TimeStepEnv,
)


# ------------------------------
# Logger Test
# ------------------------------
@pytest.mark.parametrize("iterations", [3])
def test_logger(iterations):
    logger = Logger()
    for i in range(iterations):
        logger.log(
            iteration=i,
            learning_rate=0.01 * (i + 1),
            train_loss=np.random.rand(),
            eval_loss=np.random.rand(),
        )

    # Check internal logs structure
    logs = logger.logs
    assert isinstance(logs, dict)
    assert set(logs.keys()) == {"iteration", "learning_rate", "train_loss", "eval_loss"}
    for key in logs:
        assert isinstance(logs[key], list)
        assert len(logs[key]) == iterations

    # Verify numeric precision for learning_rate
    for lr, i in zip(logs["learning_rate"], range(iterations)):
        assert np.isclose(lr, 0.01 * (i + 1))

    # Dump methods
    full_dump = logger.dump()
    assert isinstance(full_dump, dict)
    assert set(full_dump.keys()) == set(logs.keys())

    key_dump = logger.dump(keys=["iteration", "train_loss"])
    assert set(key_dump.keys()) == {"iteration", "train_loss"}

    index_dump = logger.dump(indices=[0, 2])
    assert len(index_dump["iteration"]) == 2
    assert index_dump["iteration"] == [0, 2]

    # Save to pickle and load
    pkl_path = "test_logger.pkl"
    with open(pkl_path, "wb") as f:
        pickle.dump(logs, f)
    with open(pkl_path, "rb") as f:
        loaded_logs = pickle.load(f)
    os.remove(pkl_path)
    assert loaded_logs == logs

    # Clear logs
    logger.clear()
    assert logger.logs == {}


# ------------------------------
# Random Agent Test
# ------------------------------
@pytest.mark.parametrize("env_id, num_envs", [("CartPole-v1", 1), ("Pendulum-v0", 5)])
def test_random_agent(env_id, num_envs):
    if num_envs == 1:
        env = gym.make(env_id)
        agent = RandomAgent(env)
        env.reset()
        action_dict = agent.act(env.state)
        assert "raw_action" in action_dict
        assert isinstance(action_dict["raw_action"], int) or isinstance(
            action_dict["raw_action"], np.integer
        )
    else:
        env = gym.vector.make(env_id, num_envs=num_envs)
        agent = RandomAgent(env)
        env.reset()
        action_dict = agent.act(env.state)
        assert "raw_action" in action_dict
        raw = action_dict["raw_action"]
        assert isinstance(raw, list) or isinstance(raw, np.ndarray)
        assert len(raw) == num_envs
        for a in raw:
            assert isinstance(a, int) or isinstance(a, np.integer)


# ------------------------------
# TimeStep Test
# ------------------------------
def test_time_step():
    env = gym.make("CartPole-v1")
    obs, _ = env.reset()
    ts_first = TimeStep(
        observation=obs,
        reward=0.0,
        discount=1.0,
        step_type=StepType.FIRST,
        info={},
    )
    assert ts_first.first()
    assert not ts_first.mid()
    assert not ts_first.last()

    # Mid step
    next_obs, reward, terminated, truncated, info = env.step(env.action_space.sample())
    ts_mid = TimeStep(
        observation=next_obs,
        reward=reward,
        discount=1.0,
        step_type=StepType.MID,
        info=info,
    )
    assert ts_mid.mid()
    assert not ts_mid.first()
    assert not ts_mid.last()
    assert not ts_mid.time_limit()
    assert not ts_mid.terminal()

    # Last step
    while not (terminated or truncated):
        next_obs, reward, terminated, truncated, info = env.step(env.action_space.sample())
    ts_last = TimeStep(
        observation=next_obs,
        reward=reward,
        discount=1.0,
        step_type=StepType.LAST,
        info=info,
    )
    assert ts_last.last()
    assert ts_last.time_limit() == truncated
    assert ts_last.terminal() == terminated


# ------------------------------
# Trajectory Test
# ------------------------------
def test_trajectory():
    traj = Trajectory()
    assert traj.length == 0
    assert len(traj.steps) == 0

    env = gym.make("CartPole-v1")
    obs, _ = env.reset()
    ts_first = TimeStep(
        observation=obs,
        reward=0.0,
        discount=1.0,
        step_type=StepType.FIRST,
        info={},
    )
    traj.add(ts_first)
    assert traj.length == 1
    assert traj.T == 0

    # Simulate episode
    steps = [ts_first]
    while not steps[-1].last():
        next_obs, reward, terminated, truncated, info = env.step(
            env.action_space.sample()
        )
        step_type = StepType.LAST if terminated or truncated else StepType.MID
        ts = TimeStep(
            observation=next_obs,
            reward=reward,
            discount=1.0,
            step_type=step_type,
            info=info,
        )
        traj.add(ts)
        steps.append(ts)

    assert traj.finished
    assert len(traj.observations) == traj.length
    assert len(traj.actions) == traj.length
    assert len(traj.rewards) == traj.length

    # Add custom info
    traj.last_info["last_V"] = 42.0
    traj.last_info["last_Q"] = np.array([1.0, 2.0, 3.0])
    assert traj.last_info["last_V"] == 42.0
    assert np.array_equal(traj.last_info["last_Q"], np.array([1.0, 2.0, 3.0]))

    # Check shapes
    obs_shape = traj.observations[0].shape
    for obs in traj.observations:
        assert obs.shape == obs_shape
    for act in traj.actions:
        assert isinstance(act, int) or isinstance(act, np.integer)


# ------------------------------
# EpisodeRunner Test
# ------------------------------
@pytest.mark.parametrize("num_episodes", [1, 5])
def test_episode_runner(num_episodes):
    env_id = "CartPole-v1"
    env = TimeStepEnv(gym.make(env_id))
    agent = RandomAgent(env)
    runner = EpisodeRunner(env, agent, n_episodes=num_episodes)
    trajectories = runner.run()
    assert len(trajectories) == num_episodes
    for traj in trajectories:
        assert traj.steps[0].first()
        assert traj.steps[-1].last()
        for step in traj.steps[1:-1]:
            assert step.mid()
        assert "raw_action" in traj.last_info


# ------------------------------
# StepRunner Test
# ------------------------------
def test_step_runner_reset_on_call():
    env_id = "CartPole-v1"
    env = TimeStepEnv(gym.make(env_id))
    agent = RandomAgent(env)
    # Reset on each call
    runner = StepRunner(env, agent, max_steps=10, reset_on_call=True)
    trajs = runner.run()
    assert len(trajs) == 10
    for traj in trajs:
        assert traj.steps[0].first()
        assert traj.steps[-1].last()
        assert "raw_action" in traj.last_info


def test_step_runner_continuity():
    env_id = "CartPole-v1"
    env = TimeStepEnv(gym.make(env_id))
    agent = RandomAgent(env)
    runner = StepRunner(env, agent, max_steps=1, reset_on_call=False)
    traj1 = runner.run()[0]
    runner.max_steps = 3
    traj2 = runner.run()[0]
    # Trajectory 2 should continue from trajectory 1's last observation
    assert traj2.steps[0].observation is not None
    assert traj2.steps[0].observation.shape == traj1.steps[-1].observation.shape
    assert "raw_action" in traj2.last_info
    assert traj2.length == 4  # 1 + 3 steps

# End of tests

