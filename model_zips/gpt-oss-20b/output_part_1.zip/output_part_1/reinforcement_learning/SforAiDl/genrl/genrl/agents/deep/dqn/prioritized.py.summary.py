import torch
from genrl.agents.deep.dqn import DQN
from genrl.agents.deep.dqn.utils import prioritized_q_loss


class PrioritizedReplayDQN(DQN):
    def __init__(self, env, *, alpha: float = 0.6, beta: float = 0.4, create_model: bool = True, **kwargs):
        """
        Initializes a DQN agent that uses a prioritized replay buffer.

        Args:
            env: The environment instance.
            alpha (float): Prioritization exponent controlling the importance of TD-error.
            beta (float): Importance sampling exponent controlling bias correction.
            create_model (bool): Whether to create the neural network at initialization.
            **kwargs: Additional keyword arguments passed to the parent DQN constructor.
        """
        super().__init__(env, buffer_type="prioritized", **kwargs)

        # Attach prioritization parameters to the replay buffer
        self.replay_buffer.alpha = alpha
        self.replay_buffer.beta = beta

        # Reset logging state
        self.empty_logs()

        # Create the Q-network if requested
        if create_model:
            self._create_model()

    def get_q_loss(self, batch: torch.Tensor) -> torch.Tensor:
        """
        Computes the Q-function loss using prioritized sampling.

        Args:
            batch (torch.Tensor): A batch of transitions sampled from the replay buffer.

        Returns:
            torch.Tensor: The loss value.
        """
        return prioritized_q_loss(
            network=self.model,
            batch=batch,
            alpha=self.replay_buffer.alpha,
            beta=self.replay_buffer.beta,
        )