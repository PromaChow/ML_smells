import os
import shutil

from genrl.env import VectorEnv
from genrl.algorithms import TD3
from genrl.algorithms.exploration import OrnsteinUhlenbeckActionNoise
from genrl.trainers import OffPolicyTrainer


def create_vector_env():
    return VectorEnv(env_name="Pendulum-v0", num_envs=2)


def initialize_td3(shared: bool = False):
    policy_layers = [1, 1]
    value_layers = [1, 1]
    shared_layers = [1, 1] if shared else None
    exploration_noise = OrnsteinUhlenbeckActionNoise(theta=0.15, sigma=0.2)
    return TD3(
        policy_layers=policy_layers,
        value_layers=value_layers,
        shared_layers=shared_layers,
        exploration_noise=exploration_noise,
    )


def configure_trainer(env, algo):
    log_dir = "./logs"
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    return OffPolicyTrainer(
        env,
        algo,
        log_dir=log_dir,
        epochs=5,
        max_episodes=500,
        warmup=10,
        start=10,
    )


def run_training(trainer):
    trainer.train()


def cleanup_logs():
    shutil.rmtree("./logs", ignore_errors=True)


def test_td3():
    env = create_vector_env()
    algo = initialize_td3()
    trainer = configure_trainer(env, algo)
    run_training(trainer)
    cleanup_logs()


def test_td3_shared():
    env = create_vector_env()
    algo = initialize_td3(shared=True)
    trainer = configure_trainer(env, algo)
    run_training(trainer)
    cleanup_logs()


if __name__ == "__main__":
    test_td3()
    test_td3_shared()
