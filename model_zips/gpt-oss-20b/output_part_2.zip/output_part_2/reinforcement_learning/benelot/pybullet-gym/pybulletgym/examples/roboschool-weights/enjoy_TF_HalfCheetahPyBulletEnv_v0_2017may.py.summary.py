import numpy as np

def relu(x: np.ndarray) -> np.ndarray:
    return np.maximum(0, x)

def dense(x: np.ndarray, w: np.ndarray, b: np.ndarray, activation=None) -> np.ndarray:
    y = x @ w + b
    if activation is not None:
        y = activation(y)
    return y

def model(x: np.ndarray,
          w1: np.ndarray, b1: np.ndarray,
          w2: np.ndarray, b2: np.ndarray,
          wf: np.ndarray, bf: np.ndarray) -> np.ndarray:
    out1 = dense(x, w1, b1, activation=relu)
    out2 = dense(out1, w2, b2, activation=relu)
    out_final = dense(out2, wf, bf, activation=None)
    return out_final

def main() -> None:
    batch_size = 1
    input_dim = 512
    x = np.random.randn(batch_size, input_dim)

    w1 = np.random.randn(input_dim, 128)
    b1 = np.random.randn(128)

    w2 = np.random.randn(128, 64)
    b2 = np.random.randn(64)

    wf = np.random.randn(64, 6)
    bf = np.random.randn(6)

    predictions = model(x, w1, b1, w2, b2, wf, bf)
    print("Predictions shape:", predictions.shape)
    print("Predictions:", predictions)

if __name__ == "__main__":
    main()