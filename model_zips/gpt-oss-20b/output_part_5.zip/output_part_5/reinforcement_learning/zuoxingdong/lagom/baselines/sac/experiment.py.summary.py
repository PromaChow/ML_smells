import os
import random
import pickle
import numpy as np
import gym
import torch
from dataclasses import dataclass, field

from lagom import (
    set_global_seeds,
    RandomAgent,
    SACAgent,
    EpisodeRunner,
    ReplayBuffer,
    Engine,
    TimeStepEnv,
    run_experiment,
    RecordEpisodeStatistics,
)


@dataclass
class Config:
    train_timesteps: int = int(1e6)
    checkpoint_freq: int = 3
    log_freq: int = 10
    envs: list[str] = field(default_factory=lambda: [
        "HalfCheetah-v3", "Hopper-v3", "Walker2d-v3", "Swimmer-v3"])
    discount: float = 0.99
    polyak: float = 0.995
    lr_actor: float = 3e-4
    lr_critic: float = 3e-4
    init_temperature: float = 1.0
    grad_norm_clip: float = 999999
    buffer_capacity: int = 1_000_000
    initial_random_rollouts: int = 10
    batch_size: int = 256
    eval_episodes: int = 200


class NormalizeAction(gym.Wrapper):
    def __init__(self, env: gym.Env):
        super().__init__(env)
        low = env.action_space.low
        high = env.action_space.high
        self.scale = (high - low) / 2.0
        self.bias = (high + low) / 2.0

    def step(self, action):
        action = np.clip(action, -1, 1)
        scaled = self.bias + action * self.scale
        return self.env.step(scaled)

    def reset(self, **kwargs):
        return self.env.reset(**kwargs)


def make_env(env_id: str, seed: int, eval_mode: bool = False) -> gym.Env:
    env = gym.make(env_id)
    env.seed(seed)
    env.action_space.seed(seed)
    env.observation_space.seed(seed)
    env = NormalizeAction(env)
    if eval_mode:
        env = RecordEpisodeStatistics(env)
    env = TimeStepEnv(env)
    return env


def run(seed: int, device: torch.device):
    set_global_seeds(seed)
    cfg = Config()

    train_envs = [make_env(eid, seed) for eid in cfg.envs]
    eval_envs = [make_env(eid, seed, eval_mode=True) for eid in cfg.envs]

    random_agent = RandomAgent(train_envs[0].action_space)

    sac_agent = SACAgent(
        env=train_envs[0],
        discount=cfg.discount,
        polyak=cfg.polyak,
        lr_actor=cfg.lr_actor,
        lr_critic=cfg.lr_critic,
        init_temperature=cfg.init_temperature,
        grad_norm_clip=cfg.grad_norm_clip,
        device=device,
    )

    episode_runner = EpisodeRunner(
        env=train_envs[0],
        agent=sac_agent,
        random_agent=random_agent,
        initial_random=cfg.initial_random_rollouts,
    )

    replay_buffer = ReplayBuffer(
        capacity=cfg.buffer_capacity,
        batch_size=cfg.batch_size,
        env=train_envs[0],
    )

    engine = Engine(
        episode_runner=episode_runner,
        replay_buffer=replay_buffer,
        agent=sac_agent,
        total_timesteps=cfg.train_timesteps,
        checkpoint_freq=cfg.checkpoint_freq,
        log_freq=cfg.log_freq,
    )

    train_logs, eval_logs = engine.train()

    log_dir = os.path.join("logs", f"seed_{seed}")
    os.makedirs(log_dir, exist_ok=True)
    with open(os.path.join(log_dir, "train_logs.pkl"), "wb") as f:
        pickle.dump(train_logs, f)
    with open(os.path.join(log_dir, "eval_logs.pkl"), "wb") as f:
        pickle.dump(eval_logs, f)


if __name__ == "__main__":
    seeds = [4153361530, 3503522377, 232342342, 987654321, 123456789]
    log_dir = "logs/default"
    os.makedirs(log_dir, exist_ok=True)
    cfg = Config()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    run_experiment(
        run,
        cfg,
        seeds=seeds,
        log_dir=log_dir,
        n_cpu=os.cpu_count(),
        use_gpu=device.type == "cuda",
    )