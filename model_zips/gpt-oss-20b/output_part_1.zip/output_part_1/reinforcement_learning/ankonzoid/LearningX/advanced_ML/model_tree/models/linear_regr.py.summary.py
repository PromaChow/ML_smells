import warnings

# Suppress warnings related to the 'gelsd' solver in scipy
warnings.filterwarnings('ignore', message='.*gelsd.*')

class linear_regr:
    def __init__(self):
        from sklearn.linear_model import LinearRegression
        self.model = LinearRegression()

    def fit(self, X, y):
        """Train the linear regression model."""
        self.model.fit(X, y)

    def predict(self, X):
        """Generate predictions using the trained model."""
        return self.model.predict(X)

    def loss(self, y, y_pred):
        """Compute the mean squared error between true and predicted values."""
        from sklearn.metrics import mean_squared_error
        return mean_squared_error(y, y_pred)