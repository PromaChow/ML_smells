import gym
import numpy as np
import pytest
import chainerrl.wrappers as wrappers


class TestCastObservation:
    @pytest.mark.parametrize("env_id", ["CartPole-v1", "Pendulum-v0"])
    @pytest.mark.parametrize("dtype", [np.float16, np.float32, np.float64])
    def test_reset_and_step(self, env_id, dtype):
        base_env = gym.make(env_id)
        env = wrappers.CastObservation(base_env, dtype)
        obs = env.reset()
        assert base_env.observation_space.dtype == np.float64
        assert obs.dtype == dtype
        rtol = 1e-3 if dtype == np.float16 else 1e-7
        np.testing.assert_allclose(obs.astype(np.float64), obs, rtol=rtol, atol=rtol)

        action = env.action_space.sample()
        obs, reward, terminated, truncated, info = env.step(action)
        assert base_env.observation_space.dtype == np.float64
        assert obs.dtype == dtype
        np.testing.assert_allclose(obs.astype(np.float64), obs, rtol=rtol, atol=rtol)

        env.close()
        base_env.close()


class TestCastObservationToFloat32:
    @pytest.mark.parametrize("env_id", ["CartPole-v1", "Pendulum-v0"])
    def test_reset_and_step(self, env_id):
        base_env = gym.make(env_id)
        env = wrappers.CastObservationToFloat32(base_env)
        obs = env.reset()
        assert base_env.observation_space.dtype == np.float64
        assert obs.dtype == np.float32
        np.testing.assert_allclose(obs.astype(np.float64), obs)

        action = env.action_space.sample()
        obs, reward, terminated, truncated, info = env.step(action)
        assert base_env.observation_space.dtype == np.float64
        assert obs.dtype == np.float32
        np.testing.assert_allclose(obs.astype(np.float64), obs)

        env.close()
        base_env.close()