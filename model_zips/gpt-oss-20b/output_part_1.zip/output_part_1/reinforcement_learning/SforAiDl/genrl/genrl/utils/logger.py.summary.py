import os
import csv
import sys
from pathlib import Path
from typing import Dict, List, Type

try:
    from torch.utils.tensorboard import SummaryWriter
except ImportError:
    SummaryWriter = None


# Registry for logger classes
logger_registry: Dict[str, Type] = {}


def register_logger(name: str):
    def decorator(cls: Type):
        logger_registry[name] = cls
        return cls

    return decorator


def get_logger_by_name(name: str) -> Type:
    cls = logger_registry.get(name)
    if cls is None:
        raise ValueError(f"Logger format '{name}' not registered.")
    return cls


@register_logger("stdout")
class StdoutLogger:
    def __init__(self, logdir: Path):
        self.logfile = logdir / "train.log"
        self.file_handle = open(self.logfile, "a")
        self.max_key_len = 0

    def write(self, kvs: Dict[str, float], log_key: str = "timestep") -> None:
        if not kvs:
            return
        self.max_key_len = max(self.max_key_len, max(len(k) for k in kvs))
        line = " | ".join(
            f"{k:<{self.max_key_len}}: {v:.4g}" for k, v in kvs.items()
        )
        self.file_handle.write(line + "\n")
        self.file_handle.flush()
        print(line)

    def close(self) -> None:
        self.file_handle.close()


@register_logger("csv")
class CSVLogger:
    def __init__(self, logdir: Path):
        self.csvfile = logdir / "train.csv"
        self.file_handle = open(self.csvfile, "a", newline="")
        self.writer = csv.DictWriter(self.file_handle, fieldnames=None)
        self.header_set = False
        self.keys = None

    def write(self, kvs: Dict[str, float], log_key: str = "timestep") -> None:
        if not self.header_set:
            self.keys = list(kvs.keys())
            self.writer = csv.DictWriter(self.file_handle, fieldnames=self.keys)
            self.writer.writeheader()
            self.header_set = True
        else:
            if set(kvs.keys()) != set(self.keys):
                raise ValueError(
                    "CSVLogger: Inconsistent keys detected after initial write."
                )
        self.writer.writerow(kvs)
        self.file_handle.flush()

    def close(self) -> None:
        self.file_handle.close()


@register_logger("tensorboard")
class TensorBoardLogger:
    def __init__(self, logdir: Path):
        if SummaryWriter is None:
            raise ImportError("TensorBoard support requires torch.")
        self.writer = SummaryWriter(log_dir=logdir)

    def write(self, kvs: Dict[str, float], log_key: str = "timestep") -> None:
        step = kvs.get(log_key, 0)
        for k, v in kvs.items():
            if k == log_key:
                continue
            self.writer.add_scalar(k, v, global_step=step)

    def close(self) -> None:
        self.writer.close()


class Logger:
    def __init__(self, logdir: str = None, formats: List[str] = None):
        if logdir is None:
            logdir = Path.cwd()
        else:
            logdir = Path(logdir)
        self.logdir = logdir
        self.logdir.mkdir(parents=True, exist_ok=True)

        if formats is None:
            formats = ["csv"]
        self.loggers = []
        for fmt in formats:
            logger_cls = get_logger_by_name(fmt)
            self.loggers.append(logger_cls(self.logdir))

    def write(self, kvs: Dict[str, float], log_key: str = "timestep") -> None:
        for logger in self.loggers:
            logger.write(kvs, log_key)

    def close(self) -> None:
        for logger in self.loggers:
            logger.close()
