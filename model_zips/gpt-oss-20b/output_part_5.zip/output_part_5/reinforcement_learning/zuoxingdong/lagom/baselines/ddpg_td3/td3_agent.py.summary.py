import os
import random
import pickle
from collections import deque

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim


class ReplayBuffer:
    def __init__(self, capacity: int):
        self.capacity = capacity
        self.buffer = deque(maxlen=capacity)

    def add(self, state, action, reward, next_state, done):
        self.buffer.append((state, action, reward, next_state, done))

    def sample(self, batch_size: int):
        batch = random.sample(self.buffer, batch_size)
        states, actions, rewards, next_states, dones = map(np.stack, zip(*batch))
        return (
            torch.FloatTensor(states),
            torch.FloatTensor(actions),
            torch.FloatTensor(rewards).unsqueeze(1),
            torch.FloatTensor(next_states),
            torch.FloatTensor(1 - dones).unsqueeze(1),
        )

    def __len__(self):
        return len(self.buffer)


class Actor(nn.Module):
    def __init__(self, state_dim: int, action_dim: int, max_action: float):
        super().__init__()
        self.max_action = max_action
        self.l1 = nn.Linear(state_dim, 400)
        self.l2 = nn.Linear(400, 300)
        self.l3 = nn.Linear(300, action_dim)

    def forward(self, state: torch.Tensor) -> torch.Tensor:
        a = torch.relu(self.l1(state))
        a = torch.relu(self.l2(a))
        a = torch.tanh(self.l3(a))
        return a * self.max_action


class Critic(nn.Module):
    def __init__(self, state_dim: int, action_dim: int):
        super().__init__()
        # Q1 architecture
        self.l1 = nn.Linear(state_dim + action_dim, 400)
        self.l2 = nn.Linear(400, 300)
        self.l3 = nn.Linear(300, 1)
        # Q2 architecture
        self.l4 = nn.Linear(state_dim + action_dim, 400)
        self.l5 = nn.Linear(400, 300)
        self.l6 = nn.Linear(300, 1)

    def forward(self, state: torch.Tensor, action: torch.Tensor):
        sa = torch.cat([state, action], dim=1)
        q1 = torch.relu(self.l1(sa))
        q1 = torch.relu(self.l2(q1))
        q1 = self.l3(q1)
        q2 = torch.relu(self.l4(sa))
        q2 = torch.relu(self.l5(q2))
        q2 = self.l6(q2)
        return q1, q2

    def q1(self, state: torch.Tensor, action: torch.Tensor):
        sa = torch.cat([state, action], dim=1)
        q1 = torch.relu(self.l1(sa))
        q1 = torch.relu(self.l2(q1))
        q1 = self.l3(q1)
        return q1


class TD3Agent:
    def __init__(self, config: dict):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        self.state_dim = config["state_dim"]
        self.action_dim = config["action_dim"]
        self.max_action = config["max_action"]
        self.batch_size = config["batch_size"]
        self.discount = config["discount"]
        self.tau = config["tau"]
        self.policy_noise = config["policy_noise"]
        self.noise_clip = config["noise_clip"]
        self.policy_delay = config["policy_delay"]

        self.actor = Actor(self.state_dim, self.action_dim, self.max_action).to(
            self.device
        )
        self.actor_target = Actor(self.state_dim, self.action_dim, self.max_action).to(
            self.device
        )
        self.actor_target.load_state_dict(self.actor.state_dict())
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=config["actor_lr"])

        self.critic = Critic(self.state_dim, self.action_dim).to(self.device)
        self.critic_target = Critic(self.state_dim, self.action_dim).to(self.device)
        self.critic_target.load_state_dict(self.critic.state_dict())
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=config["critic_lr"])

        self.replay_buffer = ReplayBuffer(config["replay_buffer_capacity"])

        self.total_it = 0

    def select_action(self, state: np.ndarray) -> np.ndarray:
        state = torch.FloatTensor(state.reshape(1, -1)).to(self.device)
        action = self.actor(state).cpu().data.numpy().flatten()
        return action

    def add_experience(self, state, action, reward, next_state, done):
        self.replay_buffer.add(state, action, reward, next_state, done)

    def soft_update(self, target, source):
        for target_param, param in zip(target.parameters(), source.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)

    def learn(self):
        if len(self.replay_buffer) < self.batch_size:
            return {}

        self.total_it += 1

        state, action, reward, next_state, mask = self.replay_buffer.sample(self.batch_size)
        state = state.to(self.device)
        action = action.to(self.device)
        reward = reward.to(self.device)
        next_state = next_state.to(self.device)
        mask = mask.to(self.device)

        with torch.no_grad():
            noise = (
                torch.randn_like(action) * self.policy_noise
            ).clamp(-self.noise_clip, self.noise_clip)
            next_action = (
                self.actor_target(next_state) + noise
            ).clamp(-self.max_action, self.max_action)

            target_q1, target_q2 = self.critic_target(next_state, next_action)
            target_q = torch.min(target_q1, target_q2)
            target_q = reward + mask * self.discount * target_q

        current_q1, current_q2 = self.critic(state, action)
        critic_loss = nn.functional.mse_loss(current_q1, target_q) + nn.functional.mse_loss(
            current_q2, target_q
        )

        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        self.critic_optimizer.step()

        actor_loss = None
        actor_grad_norm = None
        if self.total_it % self.policy_delay == 0:
            actor_loss = -self.critic.q1(state, self.actor(state)).mean()
            self.actor_optimizer.zero_grad()
            actor_loss.backward()
            self.actor_optimizer.step()
            actor_grad_norm = sum(p.grad.norm(2).item() for p in self.actor.parameters())

        self.soft_update(self.critic_target, self.critic)
        self.soft_update(self.actor_target, self.actor)

        q1_mean = current_q1.mean().item()
        q2_mean = current_q2.mean().item()

        metrics = {
            "critic_loss": critic_loss.item(),
            "q1_mean": q1_mean,
            "q2_mean": q2_mean,
        }

        if actor_loss is not None:
            metrics["actor_loss"] = actor_loss.item()
            metrics["actor_grad_norm"] = actor_grad_norm

        return metrics

    def checkpoint(self, path: str):
        os.makedirs(path, exist_ok=True)
        torch.save(
            {
                "actor": self.actor.state_dict(),
                "actor_target": self.actor_target.state_dict(),
                "critic": self.critic.state_dict(),
                "critic_target": self.critic_target.state_dict(),
                "actor_optimizer": self.actor_optimizer.state_dict(),
                "critic_optimizer": self.critic_optimizer.state_dict(),
                "total_it": self.total_it,
            },
            os.path.join(path, "td3_checkpoint.pth"),
        )
        with open(os.path.join(path, "replay_buffer.pkl"), "wb") as f:
            pickle.dump(self.replay_buffer, f)


if __name__ == "__main__":
    config = {
        "state_dim": 8,
        "action_dim": 2,
        "max_action": 1.0,
        "batch_size": 100,
        "discount": 0.99,
        "tau": 0.005,
        "policy_noise": 0.2,
        "noise_clip": 0.5,
        "policy_delay": 2,
        "actor_lr": 3e-4,
        "critic_lr": 3e-4,
        "replay_buffer_capacity": 1_000_000,
    }

    agent = TD3Agent(config)

    # Dummy training loop
    for _ in range(1000):
        state = np.random.randn(config["state_dim"])
        action = agent.select_action(state)
        next_state = np.random.randn(config["state_dim"])
        reward = np.random.randn()
        done = np.random.rand() > 0.95
        agent.add_experience(state, action, reward, next_state, done)
        metrics = agent.learn()
        if metrics:
            print(metrics)

    agent.checkpoint("td3_checkpoints")