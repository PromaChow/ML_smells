import os
import json
import random
import logging
import pathlib
import numpy as np
import torch
import torch.nn as nn
import torch.utils.data as data
import click
from dataclasses import dataclass, asdict

# ------------------ Utilities ------------------
def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def ensure_dir(path: pathlib.Path):
    path.mkdir(parents=True, exist_ok=True)

def plot_images_grid(images, labels, title, out_path, ncols=8, nrows=4):
    import matplotlib.pyplot as plt
    plt.figure(figsize=(ncols, nrows))
    for i, (img, lbl) in enumerate(zip(images, labels)):
        plt.subplot(nrows, ncols, i + 1)
        plt.imshow(img.squeeze(), cmap='gray')
        plt.title(str(lbl))
        plt.axis('off')
    plt.suptitle(title)
    plt.tight_layout()
    plt.savefig(out_path)
    plt.close()

# ------------------ Config ------------------
@dataclass
class Config:
    dataset: str
    xp_path: pathlib.Path
    data_path: pathlib.Path
    load_ae: pathlib.Path
    load_model: pathlib.Path
    ratio_known_normal: float
    nu: float
    kernel: str
    hybrid: bool
    seed: int
    known_outlier_class: int
    normal_class: int
    pollution_ratio: float

# ------------------ Dataset Loader ------------------
def load_dataset(config: Config):
    # Placeholder: generate random data
    num_samples = 1000
    if config.dataset in ['mnist', 'fmnist', 'cifar10']:
        img_shape = (1, 28, 28) if config.dataset != 'cifar10' else (3, 32, 32)
        data_tensor = torch.randn(num_samples, *img_shape)
    else:
        data_tensor = torch.randn(num_samples, 20)
    labels = torch.randint(0, 2, (num_samples,))
    dataset = data.TensorDataset(data_tensor, labels)
    loader = data.DataLoader(dataset, batch_size=64, shuffle=True)
    return loader

# ------------------ Models ------------------
class AutoEncoder(nn.Module):
    def __init__(self, input_dim: int, latent_dim: int = 10):
        super().__init__()
        self.encoder = nn.Sequential(nn.Linear(input_dim, 64), nn.ReLU(),
                                     nn.Linear(64, latent_dim))
        self.decoder = nn.Sequential(nn.Linear(latent_dim, 64), nn.ReLU(),
                                     nn.Linear(64, input_dim))

    def forward(self, x):
        z = self.encoder(x)
        return self.decoder(z), z

class OCSVM:
    def __init__(self, kernel: str = 'rbf', nu: float = 0.5, device='cpu'):
        self.kernel = kernel
        self.nu = nu
        self.device = device
        self.support_vectors = None
        self.alpha = None
        self.threshold = None

    def _kernel(self, x, y):
        if self.kernel == 'rbf':
            diff = x.unsqueeze(1) - y.unsqueeze(0)
            return torch.exp(-torch.sum(diff ** 2, dim=2))
        elif self.kernel == 'linear':
            return x @ y.t()
        elif self.kernel == 'poly':
            return (x @ y.t() + 1) ** 3
        else:
            raise ValueError(f'Unsupported kernel {self.kernel}')

    def fit(self, loader):
        X = []
        for batch, _ in loader:
            X.append(batch)
        X = torch.cat(X, dim=0).to(self.device)
        K = self._kernel(X, X)
        n_samples = X.shape[0]
        P = K / n_samples
        P = P.double()
        G = -torch.eye(n_samples)
        h = -torch.ones(n_samples)
        A = torch.ones(1, n_samples)
        b = torch.tensor([self.nu * n_samples])
        params = {
            'P': P,
            'q': torch.zeros(n_samples),
            'G': G,
            'h': h,
            'A': A,
            'b': b
        }
        import cvxopt
        sol = cvxopt.solvers.qp(cvxopt.matrix(params['P']),
                                cvxopt.matrix(params['q']),
                                cvxopt.matrix(params['G']),
                                cvxopt.matrix(params['h']),
                                cvxopt.matrix(params['A']),
                                cvxopt.matrix(params['b']))
        alpha = torch.tensor(sol['x']).squeeze().to(self.device)
        self.alpha = alpha
        sv_mask = alpha > 1e-5
        self.support_vectors = X[sv_mask]
        self.alpha = alpha[sv_mask]
        self.threshold = torch.max(self.decision_function(self.support_vectors))
    
    def decision_function(self, X):
        K = self._kernel(X, self.support_vectors)
        return torch.matmul(K, self.alpha) - self.threshold

    def score_samples(self, loader):
        scores = []
        for batch, _ in loader:
            scores.append(self.decision_function(batch).detach().cpu())
        return torch.cat(scores, dim=0)

# ------------------ Main ------------------
@click.command()
@click.option('--dataset', type=str, required=True, help='Dataset name')
@click.option('--xp_path', type=click.Path(file_okay=False), required=True, help='Experiment path')
@click.option('--data_path', type=click.Path(file_okay=False), required=True, help='Data path')
@click.option('--load_ae', type=click.Path(dir_okay=False), default='', help='Autoencoder path')
@click.option('--load_model', type=click.Path(dir_okay=False), default='', help='OCSVM model path')
@click.option('--ratio_known_normal', type=float, default=0.1, help='Known normal ratio')
@click.option('--nu', type=float, default=0.5, help='OCSVM nu')
@click.option('--kernel', type=click.Choice(['rbf', 'linear', 'poly']), default='rbf', help='Kernel type')
@click.option('--hybrid', is_flag=True, default=False, help='Enable hybrid mode')
@click.option('--seed', type=int, default=42, help='Random seed')
@click.option('--known_outlier_class', type=int, default=1, help='Known outlier class')
@click.option('--normal_class', type=int, default=0, help='Normal class')
@click.option('--pollution_ratio', type=float, default=0.0, help='Pollution ratio')
def main(dataset, xp_path, data_path, load_ae, load_model, ratio_known_normal,
         nu, kernel, hybrid, seed, known_outlier_class,
         normal_class, pollution_ratio):
    cfg = Config(
        dataset=dataset,
        xp_path=pathlib.Path(xp_path),
        data_path=pathlib.Path(data_path),
        load_ae=pathlib.Path(load_ae) if load_ae else None,
        load_model=pathlib.Path(load_model) if load_model else None,
        ratio_known_normal=ratio_known_normal,
        nu=nu,
        kernel=kernel,
        hybrid=hybrid,
        seed=seed,
        known_outlier_class=known_outlier_class,
        normal_class=normal_class,
        pollution_ratio=pollution_ratio
    )
    ensure_dir(cfg.xp_path)
    logging.basicConfig(filename=cfg.xp_path / 'log.txt',
                        level=logging.INFO,
                        format='%(asctime)s %(levelname)s %(message)s')
    logging.info(f'Configuration: {json.dumps(asdict(cfg), indent=2)}')
    set_seed(cfg.seed)
    device = torch.device('cpu')
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    loader = load_dataset(cfg)
    if cfg.hybrid:
        ae = AutoEncoder(input_dim=28*28 if 'mnist' in cfg.dataset else 20)
        if cfg.load_ae and cfg.load_ae.exists():
            ae.load_state_dict(torch.load(cfg.load_ae))
        ae.to(device)
        ae.eval()
        def feature_extractor(batch):
            with torch.no_grad():
                _, z = ae(batch)
            return z
        loader = data.DataLoader(
            data.TensorDataset(
                torch.cat([feature_extractor(batch) for batch, _ in loader], dim=0),
                torch.cat([lbl for _, lbl in loader], dim=0)
            ),
            batch_size=64,
            shuffle=True
        )
    ocsvm = OCSVM(kernel=cfg.kernel, nu=cfg.nu, device=device)
    if cfg.load_model and cfg.load_model.exists():
        ocsvm_state = torch.load(cfg.load_model)
        ocsvm.__dict__.update(ocsvm_state)
    ocsvm.fit(loader)
    scores = ocsvm.score_samples(loader)
    results = []
    for idx, (batch, lbl) in enumerate(loader):
        for s, l in zip(scores[idx*64:(idx+1)*64], lbl):
            results.append({'index': idx, 'label': int(l.item()), 'score': float(s.item())})
    results_path = cfg.xp_path / 'test_results.json'
    with open(results_path, 'w') as f:
        json.dump(results, f, indent=2)
    cfg_path = cfg.xp_path / 'config.json'
    with open(cfg_path, 'w') as f:
        json.dump(asdict(cfg), f, indent=2)
    if cfg.dataset in ['mnist', 'fmnist', 'cifar10']:
        scores_np = np.array([r['score'] for r in results])
        indices = np.argsort(scores_np)
        normal_idx = indices[:32]
        anomaly_idx = indices[-32:]
        normal_imgs = [results[i]['index'] for i in normal_idx]
        anomaly_imgs = [results[i]['index'] for i in anomaly_idx]
        plot_images_grid([torch.randn(28,28) for _ in normal_imgs],
                         [r['label'] for r in [results[i] for i in normal_idx]],
                         'Normal Samples',
                         cfg.xp_path / 'normal.png')
        plot_images_grid([torch.randn(28,28) for _ in anomaly_imgs],
                         [r['label'] for r in [results[i] for i in anomaly_idx]],
                         'Anomalous Samples',
                         cfg.xp_path / 'anomalous.png')

if __name__ == '__main__':
    main()
