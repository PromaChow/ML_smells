import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.hub import load_state_dict_from_url


class SincConv1d(nn.Module):
    def __init__(
        self,
        in_channels: int = 1,
        out_channels: int = 80,
        kernel_size: int = 251,
        sample_rate: int = 16000,
        low_freq: float = 50.0,
        high_freq: float = 8000.0,
        min_low_hz: float = 50.0,
        min_band_hz: float = 50.0,
    ):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.kernel_size = kernel_size
        self.sample_rate = sample_rate
        self.low_freq = low_freq
        self.high_freq = high_freq
        self.min_low_hz = min_low_hz
        self.min_band_hz = min_band_hz

        self.n = (kernel_size - 1) // 2
        t = torch.linspace(-self.n, self.n, kernel_size) / sample_rate
        window = torch.hann_window(kernel_size)
        self.register_buffer("t", t)
        self.register_buffer("window", window)

        # Initial filter cutoff frequencies
        lowcut_init = torch.linspace(
            low_freq, high_freq, out_channels, dtype=torch.float32
        )
        highcut_init = torch.linspace(
            low_freq, high_freq, out_channels, dtype=torch.float32
        )
        self.lowcut = nn.Parameter(lowcut_init)
        self.highcut = nn.Parameter(highcut_init)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, in_channels, T)
        batch, _, _ = x.shape

        lowcut = torch.clamp(
            self.lowcut, min=self.min_low_hz / self.sample_rate
        )
        highcut = torch.clamp(
            self.highcut,
            min=lowcut + self.min_band_hz / self.sample_rate,
        )

        filters = torch.zeros(
            (self.out_channels, 1, self.kernel_size),
            device=x.device,
            dtype=x.dtype,
        )

        for i in range(self.out_channels):
            band = (highcut[i] - lowcut[i]) * self.t
            band = torch.where(band == 0, torch.tensor(1e-9, device=x.device), band)
            sinc = (
                torch.sin(2 * math.pi * highcut[i] * self.t)
                - torch.sin(2 * math.pi * lowcut[i] * self.t)
            )
            sinc = sinc / band
            sinc = sinc * self.window
            filters[i, 0, :] = sinc

        out = F.conv1d(
            x,
            filters,
            stride=1,
            padding=self.kernel_size // 2,
            groups=self.in_channels,
        )
        return out


class SincConvBlock(nn.Module):
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        sample_rate: int = 16000,
        kernel_size: int = 251,
    ):
        super().__init__()
        self.sinc_conv = SincConv1d(
            in_channels=in_channels,
            out_channels=out_channels,
            kernel_size=kernel_size,
            sample_rate=sample_rate,
        )
        self.pool = nn.MaxPool1d(kernel_size=3, stride=2, padding=1)
        self.bn = nn.BatchNorm1d(out_channels)
        self.act = nn.LeakyReLU(0.3)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.sinc_conv(x)
        x = self.pool(x)
        x = self.bn(x)
        x = self.act(x)
        return x


class FRM(nn.Module):
    def __init__(self, channels: int, do_add: bool = True, do_mul: bool = True):
        super().__init__()
        self.do_add = do_add
        self.do_mul = do_mul
        self.fc = nn.Linear(channels, channels)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, C, T)
        gate = torch.sigmoid(self.fc(x.mean(dim=2)))  # (B, C)
        gate = gate.unsqueeze(2)  # (B, C, 1)
        out = x
        if self.do_mul:
            out = out * gate
        if self.do_add:
            out = out + gate
        return out


class ResidualBlockWithFRM(nn.Module):
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        downsample: bool = False,
        do_add: bool = True,
        do_mul: bool = True,
    ):
        super().__init__()
        self.conv1 = nn.Conv1d(
            in_channels, out_channels, kernel_size=3, padding=1
        )
        self.bn1 = nn.BatchNorm1d(out_channels)
        self.act1 = nn.LeakyReLU(0.3)

        self.conv2 = nn.Conv1d(
            out_channels, out_channels, kernel_size=3, padding=1
        )
        self.bn2 = nn.BatchNorm1d(out_channels)
        self.act2 = nn.LeakyReLU(0.3)

        self.downsample = downsample
        if downsample or in_channels != out_channels:
            self.residual_conv = nn.Conv1d(
                in_channels, out_channels, kernel_size=1, stride=2, bias=False
            )
            self.residual_bn = nn.BatchNorm1d(out_channels)
        else:
            self.residual_conv = None

        self.pool = nn.MaxPool1d(kernel_size=3, stride=2, padding=1)
        self.frm = FRM(out_channels, do_add=do_add, do_mul=do_mul)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = x
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.act1(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.act2(out)

        if self.residual_conv is not None:
            residual = self.residual_conv(residual)
            residual = self.residual_bn(residual)

        out = out + residual
        out = self.pool(out)
        out = self.frm(out)
        return out


class RawNet2Model(nn.Module):
    def __init__(
        self,
        nb_classes: int,
        return_code: bool = True,
        pretrained_url: str = None,
        sample_rate: int = 16000,
    ):
        super().__init__()
        self.return_code = return_code
        self.nb_classes = nb_classes

        self.sinc_block = SincConvBlock(
            in_channels=1, out_channels=80, sample_rate=sample_rate
        )

        # Residual blocks
        self.res_blocks = nn.Sequential(
            ResidualBlockWithFRM(
                in_channels=80, out_channels=128, downsample=False, do_add=True, do_mul=True
            ),
            ResidualBlockWithFRM(
                in_channels=128, out_channels=128, downsample=False, do_add=True, do_mul=True
            ),
            ResidualBlockWithFRM(
                in_channels=128, out_channels=256, downsample=True, do_add=True, do_mul=True
            ),
            ResidualBlockWithFRM(
                in_channels=256, out_channels=256, downsample=False, do_add=True, do_mul=True
            ),
            ResidualBlockWithFRM(
                in_channels=256, out_channels=256, downsample=True, do_add=True, do_mul=True
            ),
            ResidualBlockWithFRM(
                in_channels=256, out_channels=256, downsample=False, do_add=True, do_mul=True
            ),
        )

        self.adaptive_pool = nn.AdaptiveAvgPool1d(1)
        self.bn_final = nn.BatchNorm1d(256)

        self.gru = nn.GRU(
            input_size=256, hidden_size=1024, num_layers=1, batch_first=True
        )

        self.code_fc = nn.Linear(1024, 1024)
        if not return_code:
            self.class_fc = nn.Linear(1024, nb_classes)

        if pretrained_url is not None:
            self.load_pretrained_weights(pretrained_url)

    def load_pretrained_weights(self, url: str):
        state_dict = load_state_dict_from_url(url, progress=True)
        self.load_state_dict(state_dict, strict=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, 1, T)
        x = self.sinc_block(x)  # (B, 80, T')
        x = self.res_blocks(x)  # (B, 256, T'')
        x = self.adaptive_pool(x)  # (B, 256, 1)
        x = x.squeeze(-1)  # (B, 256)
        x = self.bn_final(x)
        x = x.unsqueeze(1)  # (B, 1, 256)
        _, h_n = self.gru(x)  # h_n: (1, B, 1024)
        h = h_n.squeeze(0)  # (B, 1024)

        code = self.code_fc(h)  # (B, 1024)

        if self.return_code:
            return code
        else:
            code_norm = code / (torch.norm(code, dim=1, keepdim=True) * 10)
            logits = self.class_fc(code_norm)
            return logits
```