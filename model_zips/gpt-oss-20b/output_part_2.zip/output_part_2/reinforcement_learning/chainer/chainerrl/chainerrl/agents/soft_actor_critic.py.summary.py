import gym
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from collections import deque
from typing import Tuple

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


class ReplayBuffer:
    def __init__(self, capacity: int, state_dim: int, action_dim: int):
        self.capacity = capacity
        self.states = np.zeros((capacity, state_dim), dtype=np.float32)
        self.actions = np.zeros((capacity, action_dim), dtype=np.float32)
        self.rewards = np.zeros((capacity, 1), dtype=np.float32)
        self.next_states = np.zeros((capacity, state_dim), dtype=np.float32)
        self.dones = np.zeros((capacity, 1), dtype=np.float32)
        self.ptr = 0
        self.size = 0

    def push(self, state, action, reward, next_state, done):
        idx = self.ptr
        self.states[idx] = state
        self.actions[idx] = action
        self.rewards[idx] = reward
        self.next_states[idx] = next_state
        self.dones[idx] = done
        self.ptr = (self.ptr + 1) % self.capacity
        self.size = min(self.size + 1, self.capacity)

    def sample(self, batch_size: int):
        idxs = np.random.choice(self.size, batch_size, replace=False)
        batch = dict(
            state=torch.tensor(self.states[idxs], device=device),
            action=torch.tensor(self.actions[idxs], device=device),
            reward=torch.tensor(self.rewards[idxs], device=device),
            next_state=torch.tensor(self.next_states[idxs], device=device),
            done=torch.tensor(self.dones[idxs], device=device),
        )
        return batch

    def __len__(self):
        return self.size


class TemperatureHolder(nn.Module):
    def __init__(self, initial_log_temperature: float):
        super().__init__()
        self.log_alpha = nn.Parameter(torch.tensor(initial_log_temperature, dtype=torch.float32))

    @property
    def alpha(self):
        return torch.exp(self.log_alpha)


def synchronize_parameters(source: nn.Module, target: nn.Module, tau: float):
    for src_param, tgt_param in zip(source.parameters(), target.parameters()):
        tgt_param.data.copy_(tau * src_param.data + (1.0 - tau) * tgt_param.data)


class ReplayUpdater:
    def __init__(self, start_size: int, update_interval: int):
        self.start_size = start_size
        self.update_interval = update_interval
        self.step = 0

    def should_update(self, buffer: ReplayBuffer):
        self.step += 1
        return buffer.size >= self.start_size and self.step % self.update_interval == 0


class PolicyNetwork(nn.Module):
    def __init__(self, state_dim: int, action_dim: int, hidden_dim: int = 256):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
        )
        self.mean_head = nn.Linear(hidden_dim, action_dim)
        self.log_std_head = nn.Linear(hidden_dim, action_dim)
        self.action_dim = action_dim

    def forward(self, state):
        x = self.net(state)
        mean = self.mean_head(x)
        log_std = self.log_std_head(x)
        log_std = torch.clamp(log_std, -20, 2)
        std = log_std.exp()
        return mean, std

    def sample(self, state, deterministic=False):
        mean, std = self.forward(state)
        if deterministic:
            action = mean
        else:
            normal = torch.distributions.Normal(mean, std)
            action = normal.rsample()
        action_tanh = torch.tanh(action)
        log_prob = self.log_prob(action, mean, std, action_tanh)
        return action_tanh, log_prob

    def log_prob(self, action, mean, std, action_tanh):
        normal = torch.distributions.Normal(mean, std)
        log_prob = normal.log_prob(action).sum(-1, keepdim=True)
        # Correction for Tanh squashing
        log_prob -= torch.log(1 - action_tanh.pow(2) + 1e-6).sum(-1, keepdim=True)
        return log_prob


class QNetwork(nn.Module):
    def __init__(self, state_dim: int, action_dim: int, hidden_dim: int = 256):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim + action_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
        )

    def forward(self, state, action):
        x = torch.cat([state, action], dim=-1)
        q = self.net(x)
        return q


class SACAgent:
    def __init__(
        self,
        env: gym.Env,
        replay_buffer_capacity: int = 1_000_000,
        batch_size: int = 256,
        gamma: float = 0.99,
        tau: float = 0.005,
        lr: float = 3e-4,
        initial_log_temperature: float = 0.0,
        entropy_target: float = None,
        update_interval: int = 50,
        replay_start_size: int = 1000,
    ):
        self.env = env
        self.state_dim = env.observation_space.shape[0]
        self.action_dim = env.action_space.shape[0]
        self.batch_size = batch_size
        self.gamma = gamma
        self.tau = tau
        self.entropy_target = entropy_target

        self.policy = PolicyNetwork(self.state_dim, self.action_dim).to(device)
        self.q_func1 = QNetwork(self.state_dim, self.action_dim).to(device)
        self.q_func2 = QNetwork(self.state_dim, self.action_dim).to(device)
        self.target_q_func1 = QNetwork(self.state_dim, self.action_dim).to(device)
        self.target_q_func2 = QNetwork(self.state_dim, self.action_dim).to(device)

        self.target_q_func1.load_state_dict(self.q_func1.state_dict())
        self.target_q_func2.load_state_dict(self.q_func2.state_dict())

        self.policy_opt = optim.Adam(self.policy.parameters(), lr=lr)
        self.q_func1_opt = optim.Adam(self.q_func1.parameters(), lr=lr)
        self.q_func2_opt = optim.Adam(self.q_func2.parameters(), lr=lr)

        if entropy_target is not None:
            self.temperature = TemperatureHolder(initial_log_temperature).to(device)
            self.temp_opt = optim.Adam(self.temperature.parameters(), lr=lr)
        else:
            self.temperature = None

        self.replay_buffer = ReplayBuffer(replay_buffer_capacity, self.state_dim, self.action_dim)
        self.replay_updater = ReplayUpdater(replay_start_size, update_interval)

        self.stats = {
            "q1_loss": [],
            "q2_loss": [],
            "policy_loss": [],
            "temperature": [],
            "entropy": [],
        }

    def select_action(self, state, deterministic=False):
        state_tensor = torch.tensor(state, dtype=torch.float32, device=device).unsqueeze(0)
        action, _ = self.policy.sample(state_tensor, deterministic=deterministic)
        return action.cpu().detach().numpy()[0]

    def train_step(self):
        if not self.replay_updater.should_update(self.replay_buffer):
            return

        batch = self.replay_buffer.sample(self.batch_size)
        state = batch["state"]
        action = batch["action"]
        reward = batch["reward"]
        next_state = batch["next_state"]
        done = batch["done"]

        with torch.no_grad():
            next_action, next_log_prob = self.policy.sample(next_state)
            target_q1 = self.target_q_func1(next_state, next_action)
            target_q2 = self.target_q_func2(next_state, next_action)
            target_q = torch.min(target_q1, target_q2) - (self.temperature.alpha if self.temperature else 0.0) * next_log_prob
            target_q = reward + (1 - done) * self.gamma * target_q

        current_q1 = self.q_func1(state, action)
        current_q2 = self.q_func2(state, action)
        q1_loss = nn.functional.mse_loss(current_q1, target_q)
        q2_loss = nn.functional.mse_loss(current_q2, target_q)

        self.q_func1_opt.zero_grad()
        q1_loss.backward()
        self.q_func1_opt.step()

        self.q_func2_opt.zero_grad()
        q2_loss.backward()
        self.q_func2_opt.step()

        # Policy update
        new_action, log_prob = self.policy.sample(state)
        q1_new = self.q_func1(state, new_action)
        q2_new = self.q_func2(state, new_action)
        min_q_new = torch.min(q1_new, q2_new)
        policy_loss = ((self.temperature.alpha if self.temperature else 0.0) * log_prob - min_q_new).mean()

        self.policy_opt.zero_grad()
        policy_loss.backward()
        self.policy_opt.step()

        # Temperature update
        if self.temperature is not None:
            entropy = -log_prob.mean().item()
            temp_loss = -(self.temperature.log_alpha * (log_prob + self.entropy_target)).mean()
            self.temp_opt.zero_grad()
            temp_loss.backward()
            self.temp_opt.step()
            self.stats["temperature"].append(self.temperature.alpha.item())
            self.stats["entropy"].append(entropy)
        else:
            entropy = None

        synchronize_parameters(self.q_func1, self.target_q_func1, self.tau)
        synchronize_parameters(self.q_func2, self.target_q_func2, self.tau)

        self.stats["q1_loss"].append(q1_loss.item())
        self.stats["q2_loss"].append(q2_loss.item())
        self.stats["policy_loss"].append(policy_loss.item())

    def run(self, num_episodes: int, max_steps_per_episode: int, act_deterministically=False):
        for episode in range(num_episodes):
            state = self.env.reset()
            episode_reward = 0.0
            for step in range(max_steps_per_episode):
                action = self.select_action(state, deterministic=act_deterministically)
                next_state, reward, done, _ = self.env.step(action)
                self.replay_buffer.push(state, action, reward, next_state, done)
                self.train_step()
                state = next_state
                episode_reward += reward
                if done:
                    break
            print(f"Episode {episode + 1} Reward: {episode_reward:.2f}")


if __name__ == "__main__":
    env = gym.make("Pendulum-v1")
    agent = SACAgent(
        env,
        replay_buffer_capacity=500_000,
        batch_size=256,
        gamma=0.99,
        tau=0.005,
        lr=3e-4,
        initial_log_temperature=0.0,
        entropy_target=-1.0,
        update_interval=50,
        replay_start_size=1000,
    )
    agent.run(num_episodes=200, max_steps_per_episode=200)