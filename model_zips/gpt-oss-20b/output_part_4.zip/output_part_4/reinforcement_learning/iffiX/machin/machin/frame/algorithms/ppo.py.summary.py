import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.distributions import Categorical
import random
import numpy as np


class ReplayBuffer:
    def __init__(self, capacity: int):
        self.capacity = capacity
        self.states = []
        self.actions = []
        self.advantages = []
        self.targets = []

    def add(self, state, action, advantage, target):
        if len(self.states) >= self.capacity:
            self.states.pop(0)
            self.actions.pop(0)
            self.advantages.pop(0)
            self.targets.pop(0)
        self.states.append(state)
        self.actions.append(action)
        self.advantages.append(advantage)
        self.targets.append(target)

    def sample(self, batch_size: int):
        idxs = random.sample(range(len(self.states)), batch_size)
        batch_states = torch.stack([self.states[i] for i in idxs])
        batch_actions = torch.tensor([self.actions[i] for i in idxs], dtype=torch.long)
        batch_advantages = torch.stack([self.advantages[i] for i in idxs])
        batch_targets = torch.stack([self.targets[i] for i in idxs])
        return batch_states, batch_actions, batch_advantages, batch_targets

    def clear(self):
        self.states.clear()
        self.actions.clear()
        self.advantages.clear()
        self.targets.clear()

    def __len__(self):
        return len(self.states)


class ActorNetwork(nn.Module):
    def __init__(self, state_dim: int, action_dim: int, hidden_dim: int = 64):
        super().__init__()
        self.fc1 = nn.Linear(state_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.out = nn.Linear(hidden_dim, action_dim)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        logits = self.out(x)
        return logits


class CriticNetwork(nn.Module):
    def __init__(self, state_dim: int, hidden_dim: int = 64):
        super().__init__()
        self.fc1 = nn.Linear(state_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.out = nn.Linear(hidden_dim, 1)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        value = self.out(x)
        return value


class A2C:
    def __init__(
        self,
        state_dim: int,
        action_dim: int,
        actor_lr: float = 3e-4,
        critic_lr: float = 1e-3,
        entropy_weight: float = 0.01,
        value_weight: float = 0.5,
        buffer_capacity: int = 5000,
    ):
        self.actor = ActorNetwork(state_dim, action_dim)
        self.critic = CriticNetwork(state_dim)
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=actor_lr)
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=critic_lr)
        self.entropy_weight = entropy_weight
        self.value_weight = value_weight
        self.replay_buffer = ReplayBuffer(buffer_capacity)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.actor.to(self.device)
        self.critic.to(self.device)

    def generate_config(self):
        return {
            "framework": "A2C",
            "actor_lr": self.actor_optimizer.defaults["lr"],
            "critic_lr": self.critic_optimizer.defaults["lr"],
            "entropy_weight": self.entropy_weight,
            "value_weight": self.value_weight,
        }


class PPO(A2C):
    def __init__(
        self,
        state_dim: int,
        action_dim: int,
        actor_lr: float = 3e-4,
        critic_lr: float = 1e-3,
        entropy_weight: float = 0.01,
        value_weight: float = 0.5,
        clip_epsilon: float = 0.2,
        gradient_norm_clip: float = 0.5,
        gae_lambda: float = 0.95,
        discount_factor: float = 0.99,
        buffer_capacity: int = 5000,
        advantage_normalization: bool = True,
        update_policy: bool = True,
        update_value: bool = True,
    ):
        super().__init__(
            state_dim,
            action_dim,
            actor_lr,
            critic_lr,
            entropy_weight,
            value_weight,
            buffer_capacity,
        )
        self.clip_epsilon = clip_epsilon
        self.gradient_norm_clip = gradient_norm_clip
        self.gae_lambda = gae_lambda
        self.discount_factor = discount_factor
        self.advantage_normalization = advantage_normalization
        self.update_policy = update_policy
        self.update_value = update_value
        self.temp_actor = ActorNetwork(state_dim, action_dim).to(self.device)
        self.temp_actor.load_state_dict(self.actor.state_dict())

    def update(self, batch_size: int = 64):
        if len(self.replay_buffer) < batch_size:
            return None, None
        states, actions, advantages, targets = self.replay_buffer.sample(batch_size)

        states = states.to(self.device)
        actions = actions.to(self.device)
        advantages = advantages.to(self.device)
        targets = targets.to(self.device)

        if self.advantage_normalization:
            adv_mean = advantages.mean()
            adv_std = advantages.std() + 1e-8
            advantages = (advantages - adv_mean) / adv_std

        with torch.no_grad():
            old_logits = self.temp_actor(states)
            old_dist = Categorical(logits=old_logits)
            old_log_probs = old_dist.log_prob(actions)

        new_logits = self.actor(states)
        new_dist = Categorical(logits=new_logits)
        new_log_probs = new_dist.log_prob(actions)
        entropy = new_dist.entropy().mean()

        ratio = torch.exp(new_log_probs - old_log_probs)
        surrogate = ratio * advantages
        surrogate_clipped = torch.clamp(
            ratio, 1 - self.clip_epsilon, 1 + self.clip_epsilon
        ) * advantages
        policy_loss = -torch.min(surrogate, surrogate_clipped).mean()
        if self.entropy_weight > 0:
            policy_loss = policy_loss - self.entropy_weight * entropy

        if self.update_policy:
            self.actor_optimizer.zero_grad()
            policy_loss.backward()
            torch.nn.utils.clip_grad_norm_(self.actor.parameters(), self.gradient_norm_clip)
            self.actor_optimizer.step()

        value_pred = self.critic(states).squeeze(-1)
        value_loss = F.mse_loss(value_pred, targets) * self.value_weight

        if self.update_value:
            self.critic_optimizer.zero_grad()
            value_loss.backward()
            torch.nn.utils.clip_grad_norm_(self.critic.parameters(), self.gradient_norm_clip)
            self.critic_optimizer.step()

        self.replay_buffer.clear()
        self.actor.eval()
        self.critic.eval()
        self.temp_actor.eval()

        return -policy_loss.item(), value_loss.item()

    def generate_config(self):
        cfg = super().generate_config()
        cfg.update(
            {
                "framework": "PPO",
                "clip_epsilon": self.clip_epsilon,
            }
        )
        return cfg
