import os
import numpy as np
import pybullet as p
from gymnasium.envs.robotics import MJCFBasedRobot


class InvertedDoublePendulum(MJCFBasedRobot):
    def __init__(self, xml_path="inverted_double_pendulum.xml"):
        super().__init__(
            xml_path=os.path.join(os.path.dirname(__file__), xml_path),
            main_body_part="cart",
            action_dim=1,
            obs_dim=9,
        )
        self.pos_x = 0.0

    def robot_specific_reset(self, bullet_client: p):
        self._p = bullet_client

        # Reference parts and joints
        self.pole2 = self._model.parts["pole2"]
        self.slider = self._model.parts["slider"]
        self.hinge = self._model.joints["hinge"]
        self.hinge2 = self._model.joints["hinge2"]

        # Random initial angles and angular velocities for both hinges
        for hinge in (self.hinge, self.hinge2):
            init_angle = np.random.uniform(-0.1, 0.1)
            init_vel = np.random.uniform(-0.1, 0.1)
            self._p.resetJointState(
                hinge.body_id,
                hinge.joint_index,
                init_angle,
                init_vel,
            )

        # Zero torques for both hinges
        self._p.setJointMotorControlArray(
            self._model.body_id,
            [self.hinge.joint_index, self.hinge2.joint_index],
            self._p.TORQUE_CONTROL,
            forces=[0, 0],
        )

    def apply_action(self, action):
        torque = np.clip(action[0], -1, 1) * 200.0
        self._p.setJointMotorControl2(
            self.slider.body_id,
            self.slider.joint_index,
            self._p.TORQUE_CONTROL,
            force=torque,
        )

    def calc_state(self):
        # Slider (cart) state
        slider_pos, slider_vel = self._p.getJointState(
            self.slider.body_id, self.slider.joint_index
        )[:2]
        x, vx = slider_pos, slider_vel

        # First hinge state
        j1_pos, j1_vel = self._p.getJointState(
            self.hinge.body_id, self.hinge.joint_index
        )[:2]
        theta, omega1 = j1_pos, j1_vel

        # Second hinge state
        j2_pos, j2_vel = self._p.getJointState(
            self.hinge2.body_id, self.hinge2.joint_index
        )[:2]
        gamma, omega2 = j2_pos, j2_vel

        # Position of second pendulum segment (pole2)
        pole2_pos, _ = self._p.getLinkState(
            self.pole2.body_id, self.pole2.link_index, computeForwardKinematics=True
        )
        self.pos_x = pole2_pos[0]

        state = np.array(
            [
                x,
                vx,
                self.pos_x,
                np.cos(theta),
                np.sin(theta),
                omega1,
                np.cos(gamma),
                np.sin(gamma),
                omega2,
            ],
            dtype=np.float32,
        )
        return state

    @property
    def state_dim(self):
        return 9

    @property
    def action_dim(self):
        return 1

    @property
    def observation_space(self):
        return self.obs_dim

    @property
    def action_space(self):
        return self.action_dim

    def close(self):
        if self._p is not None:
            self._p.disconnect()
            self._p = None

    def __del__(self):
        self.close()