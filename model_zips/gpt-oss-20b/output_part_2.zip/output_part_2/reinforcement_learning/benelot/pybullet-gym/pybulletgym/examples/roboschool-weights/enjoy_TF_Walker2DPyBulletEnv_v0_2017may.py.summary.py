import numpy as np

class SimpleFeedForward:
    def __init__(self):
        # Layer 1 weights (50x100) and bias (100,)
        self.w1 = np.arange(50 * 100).reshape(50, 100).astype(float)
        self.b1 = np.arange(100).astype(float)

        # Layer 2 weights (100x100) and bias (100,)
        self.w2 = np.arange(100 * 100, 100 * 100 + 100 * 100).reshape(100, 100).astype(float)
        self.b2 = np.arange(100, 200).astype(float)

        # Final layer weights (100x60) and bias (60,)
        self.w3 = np.arange(100 * 60, 100 * 60 + 100 * 60).reshape(100, 60).astype(float)
        self.b3 = np.arange(60, 120).astype(float)

    def forward(self, x):
        """Performs a forward pass through the network."""
        # Layer 1
        z1 = np.dot(x, self.w1) + self.b1

        # Layer 2
        z2 = np.dot(z1, self.w2) + self.b2

        # Final Layer
        z3 = np.dot(z2, self.w3) + self.b3

        return z3

def main():
    # Example input: vector of size 50
    input_vector = np.linspace(0, 49, 50, dtype=float)

    # Initialize network
    net = SimpleFeedForward()

    # Forward pass
    output = net.forward(input_vector)

    print("Output shape:", output.shape)
    print("Output values:\n", output)

if __name__ == "__main__":
    main()