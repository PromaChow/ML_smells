import math
import numpy as np


class WeightTree:
    def __init__(self, size: int, epsilon: float = 1e-6, alpha: float = 0.6):
        self.size = size
        self.epsilon = epsilon
        self.alpha = alpha
        self.tree = np.zeros(2 * size, dtype=np.float32)
        self.max_weight = 0.0

    def _normalize(self, priority: float) -> float:
        return (abs(priority) + self.epsilon) ** self.alpha

    def update(self, idx: int, priority: float) -> None:
        priority = self._normalize(priority)
        pos = idx + self.size
        self.tree[pos] = priority
        while pos > 1:
            pos //= 2
            self.tree[pos] = self.tree[2 * pos] + self.tree[2 * pos + 1]
        if priority > self.max_weight:
            self.max_weight = priority

    def update_batch(self, idxs: np.ndarray, priorities: np.ndarray) -> None:
        priorities = np.array([self._normalize(p) for p in priorities], dtype=np.float32)
        for idx, p in zip(idxs, priorities):
            pos = idx + self.size
            self.tree[pos] = p
            if p > self.max_weight:
                self.max_weight = p
        for pos in range(self.size - 1, 0, -1):
            self.tree[pos] = self.tree[2 * pos] + self.tree[2 * pos + 1]

    def total(self) -> float:
        return float(self.tree[1])

    def find_leaf(self, value: float) -> int:
        pos = 1
        while pos < self.size:
            left = 2 * pos
            if value <= self.tree[left]:
                pos = left
            else:
                value -= self.tree[left]
                pos = left + 1
        return pos - self.size


class Buffer:
    def __init__(self, capacity: int):
        self.capacity = capacity
        self.data = [None] * capacity
        self.idx = 0
        self.size = 0

    def add(self, item):
        self.data[self.idx] = item
        self.idx = (self.idx + 1) % self.capacity
        if self.size < self.capacity:
            self.size += 1

    def get(self, indices):
        return [self.data[i] for i in indices]


class PrioritizedBuffer(Buffer):
    def __init__(
        self,
        capacity: int,
        alpha: float = 0.6,
        beta_start: float = 0.4,
        beta_frames: int = 100000,
        epsilon: float = 1e-6,
    ):
        super().__init__(capacity)
        self.alpha = alpha
        self.epsilon = epsilon
        self.beta = beta_start
        self.beta_increment_per_sampling = (1.0 - beta_start) / beta_frames
        self.tree = WeightTree(capacity, epsilon=epsilon, alpha=alpha)
        self.max_priority = 1.0

    def add(self, item, priority: float = None):
        if priority is None:
            priority = self.max_priority
        self.tree.update(self.idx, priority)
        super().add(item)
        if priority > self.max_priority:
            self.max_priority = priority

    def sample(self, batch_size: int):
        batch_indices = []
        leaf_weights = []
        total = self.tree.total()
        segment = total / batch_size
        for i in range(batch_size):
            a = segment * i
            b = segment * (i + 1)
            s = np.random.uniform(a, b)
            idx = self.tree.find_leaf(s)
            batch_indices.append(idx)
            leaf_weights.append(self.tree.tree[idx + self.tree.size])
        probs = np.array(leaf_weights) / total
        is_weights = np.power(self.size * probs, -self.beta)
        is_weights /= is_weights.max()
        self.beta = min(1.0, self.beta + self.beta_increment_per_sampling)
        samples = self.get(batch_indices)
        return batch_indices, samples, is_weights

    def update_priorities(self, indices, priorities):
        self.tree.update_batch(np.array(indices), np.array(priorities))
        for p in priorities:
            norm_p = self.tree._normalize(p)
            if norm_p > self.max_priority:
                self.max_priority = norm_p

    def clear(self):
        self.data = [None] * self.capacity
        self.idx = 0
        self.size = 0
        self.tree = WeightTree(self.capacity, epsilon=self.epsilon, alpha=self.alpha)
        self.max_priority = 1.0
        self.beta = 0.4

# Example usage (for illustration; remove or comment out in production)
if __name__ == "__main__":
    buffer = PrioritizedBuffer(10)
    for i in range(15):
        buffer.add(f"experience_{i}")
    indices, samples, weights = buffer.sample(5)
    print("Indices:", indices)
    print("Samples:", samples)
    print("IS weights:", weights)
    buffer.update_priorities(indices, [0.5] * len(indices))
    print("Updated priorities")
    indices, samples, weights = buffer.sample(5)
    print("New samples:", samples)