import numpy as np
from scipy.interpolate import CubicSpline

def add_noise(X, sigma=0.05):
    noise = np.random.normal(0, sigma, size=X.shape)
    return X + noise

def scale(X, sigma=0.1):
    batch, time, ch = X.shape
    scale_factors = np.random.normal(1.0, sigma, size=(batch, 1, 1))
    return X * scale_factors

def rodrigues(axis, angle):
    x, y, z = axis
    c = np.cos(angle)
    s = np.sin(angle)
    C = 1 - c
    R = np.array([[x*x*C + c,   x*y*C - z*s, x*z*C + y*s],
                  [y*x*C + z*s, y*y*C + c,   y*z*C - x*s],
                  [z*x*C - y*s, z*y*C + x*s, z*z*C + c]])
    return R

def rotate_3d(X):
    batch, time, ch = X.shape
    assert ch == 3, "Rotation requires 3 channels"
    axes = np.random.normal(size=(batch, 3))
    axes /= np.linalg.norm(axes, axis=1, keepdims=True)
    angles = np.random.uniform(0, 2*np.pi, size=(batch, 1, 1))
    Rs = np.array([rodrigues(a, ang) for a, ang in zip(axes, angles)])
    return np.einsum('bti,bij->btj', X, Rs)

def invert_signal(X):
    return -X

def reverse_time(X):
    return X[:, ::-1, :]

def shuffle_channels(X):
    batch, time, ch = X.shape
    perms = [p for p in np.array(np.meshgrid(*[np.arange(ch)]*ch)).T.reshape(-1, ch) if not np.all(p == np.arange(ch))]
    perm_indices = np.random.choice(len(perms), size=batch)
    shuffled = np.stack([X[i, :, perms[perm_indices[i]]] for i in range(batch)])
    return shuffled

def permute_time_segments(X, num_segments=4):
    batch, time, ch = X.shape
    segs = np.linspace(0, time, num_segments + 1, dtype=int)
    perm_indices = np.random.permutation(num_segments)
    permuted = np.zeros_like(X)
    for i in range(batch):
        parts = [X[i, segs[j]:segs[j+1], :] for j in range(num_segments)]
        parts = [parts[j] for j in perm_indices]
        permuted[i] = np.concatenate(parts, axis=0)
    return permuted

def cubic_spline_interpolate(x, y, new_x):
    cs = CubicSpline(x, y, bc_type='natural')
    return cs(new_x)

def time_warp_improved(X, sigma=0.2, num_knots=4):
    batch, time, ch = X.shape
    warped = np.zeros_like(X)
    t = np.linspace(0, 1, time)
    for i in range(batch):
        knots = np.linspace(0, 1, num_knots)
        offsets = np.random.normal(0, sigma, size=num_knots)
        knots_vals = np.clip(knots + offsets, 0, 1)
        knots_vals = np.sort(knots_vals)
        spline = CubicSpline(knots, knots_vals, bc_type='clamp')
        warp_t = spline(t)
        warp_t = np.clip(warp_t, 0, 1)
        warp_t = np.interp(np.linspace(0, 1, time), t, warp_t)
        for c in range(ch):
            warped[i, :, c] = np.interp(warp_t, t, X[i, :, c], left=0, right=0)
    return warped

class TimeWarpLowCost:
    def __init__(self, time_len, num_splines=150, sigma=0.2, num_knots=4):
        self.time_len = time_len
        t = np.linspace(0, 1, time_len)
        self.curves = np.zeros((num_splines, time_len))
        for s in range(num_splines):
            knots = np.linspace(0, 1, num_knots)
            offsets = np.random.normal(0, sigma, size=num_knots)
            knots_vals = np.clip(knots + offsets, 0, 1)
            knots_vals = np.sort(knots_vals)
            spline = CubicSpline(knots, knots_vals, bc_type='clamp')
            warp_t = spline(t)
            warp_t = np.clip(warp_t, 0, 1)
            self.curves[s] = warp_t
    def __call__(self, X):
        batch, time, ch = X.shape
        assert time == self.time_len
        warped = np.zeros_like(X)
        indices = np.random.choice(self.curves.shape[0], size=batch)
        t = np.linspace(0, 1, time)
        for i in range(batch):
            warp_t = self.curves[indices[i]]
            for c in range(ch):
                warped[i, :, c] = np.interp(warp_t, t, X[i, :, c], left=0, right=0)
        return warped
