import tensorflow as tf
import numpy as np

# ----------------------------------------------------------------------
# 1. Initialization and Session Configuration
# ----------------------------------------------------------------------
def create_session(config_dict=None):
    config = tf.ConfigProto()
    if config_dict:
        gpu_options = config_dict.get('gpu_options', {})
        config.gpu_options.allow_growth = gpu_options.get('allow_growth', True)
        config.gpu_options.per_process_gpu_memory_fraction = gpu_options.get('memory_fraction', 1.0)
    else:
        config.gpu_options.allow_growth = True
    return tf.Session(config=config)

def init_tf(config_dict=None):
    tf.set_random_seed(config_dict.get('seed', 42) if config_dict else 42)
    tf.reset_default_graph()
    sess = create_session(config_dict)
    sess.run(tf.global_variables_initializer())
    return sess

def init_uninited_vars():
    uninit_vars = tf.report_uninitialized_variables()
    sess = tf.get_default_session()
    if uninit_vars:
        sess.run(tf.variables_initializer(tf.get_collection(tf.GraphKeys.GLOBAL_VARIABLES)))

def set_vars(var_to_value_dict):
    ops = [var.assign(val) for var, val in var_to_value_dict.items()]
    tf.get_default_session().run(ops)

# ----------------------------------------------------------------------
# 2. Tensor and Variable Utilities
# ----------------------------------------------------------------------
def flatten(t):
    return tf.reshape(t, [-1])

def log2(x):
    return tf.math.log(x) / tf.math.log(2.0)

def exp2(x):
    return tf.math.pow(2.0, x)

def lerp(a, b, t):
    return a + t * (b - a)

def shape_to_list(shape):
    return [s.value if hasattr(s, 'value') else s for s in shape]

def absolute_name_scope(scope):
    base = tf.get_default_graph().get_name_scope()
    return f'{base}/{scope}' if base else scope

# ----------------------------------------------------------------------
# 3. Autosummaries for TensorBoard
# ----------------------------------------------------------------------
_autosummary_vars = {}
_summary_op = None

def autosummary(name, value):
    with tf.variable_scope(name, reuse=tf.AUTO_REUSE):
        sum_var = tf.get_variable('sum', shape=value.shape, dtype=value.dtype,
                                  initializer=tf.zeros_initializer())
        count_var = tf.get_variable('count', shape=(), dtype=tf.int32,
                                    initializer=tf.zeros_initializer())
        op_sum = tf.assign_add(sum_var, value)
        op_count = tf.assign_add(count_var, 1)
        tf.group(op_sum, op_count)
        _autosummary_vars[name] = (sum_var, count_var)
        return tf.identity(value, name=name)

def finalize_autosummaries():
    global _summary_op
    summaries = []
    for name, (sum_var, count_var) in _autosummary_vars.items():
        avg = tf.divide(tf.cast(sum_var, tf.float32), tf.cast(count_var, tf.float32))
        summaries.append(tf.summary.scalar(name, avg))
    _summary_op = tf.summary.merge(summaries)
    return _summary_op

def save_summaries(filewriter, global_step):
    if _summary_op is None:
        finalize_autosummaries()
    summary = tf.get_default_session().run(_summary_op)
    filewriter.add_summary(summary, global_step)

# ----------------------------------------------------------------------
# 4. Dynamic Import and Module Handling
# ----------------------------------------------------------------------
_import_aliases = {'np': np, 'tf': tf}

def import_module(module_or_obj_name):
    if module_or_obj_name in _import_aliases:
        return _import_aliases[module_or_obj_name]
    components = module_or_obj_name.split('.')
    module = __import__(components[0])
    for comp in components[1:]:
        module = getattr(module, comp)
    return module

def import_obj(obj_name):
    return import_module(obj_name)

def call_func_by_name(func, *args, **kwargs):
    func_obj = func if not isinstance(func, str) else import_obj(func)
    return func_obj(*args, **kwargs)

# ----------------------------------------------------------------------
# 5. Custom Optimizer Class
# ----------------------------------------------------------------------
class Optimizer:
    def __init__(self, base_optimizer, loss_scaling=1.0, fp16=False, beta=0.5):
        self.base_optimizer = base_optimizer
        self.loss_scaling = tf.Variable(loss_scaling, trainable=False, dtype=tf.float32)
        self.fp16 = fp16
        self.grads_and_vars = []
        self.beta = beta

    def register_gradients(self, loss, var_list):
        grads = tf.gradients(loss, var_list)
        self.grads_and_vars.append((grads, var_list))

    def apply_updates(self):
        var_to_grads = {}
        for grads, vars in self.grads_and_vars:
            for g, v in zip(grads, vars):
                if v not in var_to_grads:
                    var_to_grads[v] = []
                var_to_grads[v].append(g)
        avg_grads_and_vars = []
        for v, grads in var_to_grads.items():
            grad_sum = tf.add_n(grads)
            grad_avg = tf.divide(grad_sum, tf.cast(tf.size(grads), tf.float32))
            avg_grads_and_vars.append((grad_avg, v))
        train_op = self.base_optimizer.apply_gradients(avg_grads_and_vars)
        overflow = tf.reduce_any([tf.reduce_any(tf.math.is_nan(g)) | tf.reduce_any(tf.math.is_inf(g))
                                  for g, _ in avg_grads_and_vars])
        scaling_op = tf.cond(
            overflow,
            lambda: tf.assign_sub(self.loss_scaling,
                                   tf.cast(self.loss_scaling, tf.float32) * self.beta),
            lambda: tf.assign_add(self.loss_scaling,
                                   tf.cast(self.loss_scaling, tf.float32) * (1.0 - self.beta))
        )
        with tf.control_dependencies([train_op, scaling_op]):
            return tf.no_op()

    def apply_loss_scaling(self, value):
        return tf.multiply(value, self.loss_scaling)

    def undo_loss_scaling(self, value):
        return tf.divide(value, self.loss_scaling)

    def reset_optimizer_state(self):
        tf.get_default_session().run(tf.variables_initializer([self.loss_scaling]))

# ----------------------------------------------------------------------
# 6. Network Abstraction Class
# ----------------------------------------------------------------------
class Network:
    def __init__(self, builder, input_shapes, name='Network'):
        self.name = name
        self.builder = builder
        self.input_shapes = input_shapes
        self.placeholders = {}
        with tf.variable_scope(self.name):
            for key, shape in input_shapes.items():
                self.placeholders[key] = tf.placeholder(tf.float32, shape=shape, name=key)
            self.outputs = self.builder(**self.placeholders)
            self.trainable_vars = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES,
                                                    scope=self.name)

    def get_output_for(self, **kwargs):
        feed = {self.placeholders[k]: v for k, v in kwargs.items()}
        return tf.get_default_session().run(self.outputs, feed_dict=feed)

    def reset_vars(self):
        tf.get_default_session().run(tf.variables_initializer(self.trainable_vars))

    def reset_trainables(self):
        self.reset_vars()

    def get_var(self, localname):
        var = tf.get_default_graph().get_tensor_by_name(f'{self.name}/{localname}:0')
        return tf.get_default_session().run(var)

    def set_var(self, localname, new_value):
        var = tf.get_default_graph().get_tensor_by_name(f'{self.name}/{localname}:0')
        tf.get_default_session().run(var.assign(new_value))

    def run(self, **kwargs):
        return self.get_output_for(**kwargs)

    def __getstate__(self):
        state = {}
        for v in self.trainable_vars:
            state[v.name] = tf.get_default_session().run(v)
        return {'name': self.name, 'state': state, 'input_shapes': self.input_shapes}

    def __setstate__(self, state):
        self.name = state['name']
        self.input_shapes = state['input_shapes']
        self.builder = None  # Cannot serialize builder
        with tf.variable_scope(self.name):
            for key, shape in self.input_shapes.items():
                self.placeholders[key] = tf.placeholder(tf.float32, shape=shape, name=key)
            self.outputs = self.builder(**self.placeholders)
            self.trainable_vars = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES,
                                                    scope=self.name)
        for name, val in state['state'].items():
            var = tf.get_default_graph().get_tensor_by_name(name)
            tf.get_default_session().run(var.assign(val))

    def clone(self, name=None):
        new_name = name or f'{self.name}_clone'
        return Network(self.builder, self.input_shapes, name=new_name)

    def copy_vars_from(self, src_net):
        ops = []
        for src_var, dst_var in zip(src_net.trainable_vars, self.trainable_vars):
            ops.append(dst_var.assign(src_var))
        tf.get_default_session().run(ops)

    def setup_as_moving_average_of(self, src_net, beta=0.99):
        ops = []
        for src_var, dst_var in zip(src_net.trainable_vars, self.trainable_vars):
            assign_op = dst_var.assign(beta * dst_var + (1 - beta) * src_var)
            ops.append(assign_op)
        return tf.group(*ops)

    def print_layers(self):
        for v in self.trainable_vars:
            print(v.name, v.shape)

    def setup_weight_histograms(self, title=None):
        histograms = []
        for v in self.trainable_vars:
            histograms.append(tf.summary.histogram(f'{v.name}_{title if title else ""}', v))
        return tf.summary.merge(histograms)
