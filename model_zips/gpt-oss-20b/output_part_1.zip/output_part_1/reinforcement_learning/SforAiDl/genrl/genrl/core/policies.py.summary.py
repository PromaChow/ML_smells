import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple, List, Dict, Type, Any, Union


def _activation_fn(name: str) -> nn.Module:
    name = name.lower()
    if name == "relu":
        return nn.ReLU(inplace=True)
    if name == "tanh":
        return nn.Tanh()
    if name == "sigmoid":
        return nn.Sigmoid()
    raise ValueError(f"Unsupported activation: {name}")


def mlp(
    input_dim: int,
    output_dim: int,
    hidden_sizes: Union[Tuple[int, ...], List[int]],
    activation: nn.Module,
) -> nn.Sequential:
    layers: List[nn.Module] = []
    last_dim = input_dim
    for h in hidden_sizes:
        layers.append(nn.Linear(last_dim, h))
        layers.append(activation)
        last_dim = h
    layers.append(nn.Linear(last_dim, output_dim))
    return nn.Sequential(*layers)


def cnn(
    input_channels: int,
    channel_sizes: Tuple[int, ...] = (16, 32),
    kernel_sizes: Tuple[int, ...] = (8, 4),
    strides: Tuple[int, ...] = (4, 2),
) -> Tuple[nn.Sequential, int]:
    conv_layers: List[nn.Module] = []
    in_channels = input_channels
    for out_channels, k, s in zip(channel_sizes, kernel_sizes, strides):
        conv_layers.append(nn.Conv2d(in_channels, out_channels, kernel_size=k, stride=s))
        conv_layers.append(nn.ReLU(inplace=True))
        in_channels = out_channels
    conv_seq = nn.Sequential(*conv_layers)
    # Compute output size
    dummy = torch.zeros(1, input_channels, 84, 84)  # assuming 84x84 input
    with torch.no_grad():
        out = conv_seq(dummy)
    out_dim = out.view(out.size(0), -1).size(1)
    return conv_seq, out_dim


class BasePolicy(nn.Module):
    def __init__(
        self,
        state_dim: int,
        action_dim: int,
        hidden: Union[Tuple[int, ...], List[int]],
        discrete: bool = True,
    ):
        super().__init__()
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.hidden = hidden
        self.discrete = discrete

    def forward(self, state: torch.Tensor) -> torch.Tensor:
        raise NotImplementedError


class MlpPolicy(BasePolicy):
    def __init__(
        self,
        state_dim: int,
        action_dim: int,
        hidden: Union[Tuple[int, ...], List[int]],
        discrete: bool = True,
        **kwargs: Any,
    ):
        super().__init__(state_dim, action_dim, hidden, discrete)
        act_name = kwargs.get("activation", "relu")
        self.activation = _activation_fn(act_name)
        self.net = mlp(
            input_dim=state_dim,
            output_dim=action_dim,
            hidden_sizes=hidden,
            activation=self.activation,
        )

    def forward(self, state: torch.Tensor) -> torch.Tensor:
        return self.net(state)


class CNNPolicy(BasePolicy):
    def __init__(
        self,
        framestack: int,
        action_dim: int,
        hidden: Union[Tuple[int, ...], List[int]],
        discrete: bool = True,
        **kwargs: Any,
    ):
        super().__init__(framestack, action_dim, hidden, discrete)
        act_name = kwargs.get("activation", "relu")
        self.activation = _activation_fn(act_name)
        self.cnn_layers, cnn_output_size = cnn(input_channels=framestack)
        self.net = mlp(
            input_dim=cnn_output_size,
            output_dim=action_dim,
            hidden_sizes=hidden,
            activation=self.activation,
        )

    def forward(self, state: torch.Tensor) -> torch.Tensor:
        x = self.cnn_layers(state)
        x = torch.flatten(x, start_dim=1)
        return self.net(x)


policy_registry: Dict[str, Type[BasePolicy]] = {
    "mlp": MlpPolicy,
    "cnn": CNNPolicy,
}


def get_policy_from_name(name: str) -> Type[BasePolicy]:
    try:
        return policy_registry[name.lower()]
    except KeyError as exc:
        raise ValueError(f"Policy name '{name}' not found in registry.") from exc
