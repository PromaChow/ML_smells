import random
import math
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from collections import deque, namedtuple

# ---------- Replay Buffer ----------
Transition = namedtuple('Transition',
                        ('state', 'action', 'reward', 'next_state', 'done'))

class ReplayBuffer:
    def __init__(self, capacity):
        self.capacity = capacity
        self.memory = deque(maxlen=capacity)

    def push(self, *args):
        self.memory.append(Transition(*args))

    def sample(self, batch_size):
        batch = random.sample(self.memory, batch_size)
        return Transition(*zip(*batch))

    def __len__(self):
        return len(self.memory)

# ---------- Models ----------
def mlp_model(state_size, action_size, hidden_size=128):
    return nn.Sequential(
        nn.Flatten(),
        nn.Linear(state_size, hidden_size),
        nn.ReLU(),
        nn.Linear(hidden_size, hidden_size),
        nn.ReLU(),
        nn.Linear(hidden_size, action_size)
    )

def cnn_model(state_shape, action_size, hidden_channels=32):
    return nn.Sequential(
        nn.Conv2d(state_shape[0], hidden_channels, kernel_size=3, stride=1, padding=1),
        nn.ReLU(),
        nn.Flatten(),
        nn.Linear(hidden_channels * state_shape[1] * state_shape[2], 128),
        nn.ReLU(),
        nn.Linear(128, action_size)
    )

def get_model(env, network_type):
    if network_type == 'mlp':
        state_size = np.prod(env.observation_space.shape)
        action_size = env.action_space.n
        return mlp_model(state_size, action_size)
    elif network_type == 'cnn':
        state_shape = env.observation_space.shape
        action_size = env.action_space.n
        return cnn_model(state_shape, action_size)
    else:
        raise ValueError(f"Unsupported network type: {network_type}")

# ---------- DQN Agent ----------
class DQNAgent:
    def __init__(self,
                 env,
                 network='mlp',
                 max_epsilon=1.0,
                 min_epsilon=0.05,
                 epsilon_decay=5000,
                 gamma=0.99,
                 batch_size=64,
                 replay_size=100000,
                 lr_value=1e-3,
                 create_model=True,
                 seed=0):
        self.env = env
        self.network = network
        self.max_epsilon = max_epsilon
        self.min_epsilon = min_epsilon
        self.epsilon_decay = epsilon_decay
        self.gamma = gamma
        self.batch_size = batch_size
        self.replay_size = replay_size
        self.lr_value = lr_value
        self.timestep = 0
        self.epsilon = max_epsilon
        self.metrics = {'value_loss': [], 'epsilon': []}
        self.replay_buffer = ReplayBuffer(replay_size)
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        torch.manual_seed(seed)
        np.random.seed(seed)
        random.seed(seed)
        if create_model:
            self._create_model()

    def _create_model(self):
        if not isinstance(self.env.action_space, type(self.env.action_space)):
            raise ValueError("Environment action space must be discrete.")
        self.model = get_model(self.env, self.network).to(self.device)
        self.target_model = type(self.model)(*self.model.parameters()).to(self.device)
        self.target_model.load_state_dict(self.model.state_dict())
        self.optimizer = optim.Adam(self.model.parameters(), lr=self.lr_value)

    def update_target_model(self):
        self.target_model.load_state_dict(self.model.state_dict())

    def update_params_before_select_action(self):
        self.epsilon = self.min_epsilon + (self.max_epsilon - self.min_epsilon) * \
                       math.exp(-self.timestep / self.epsilon_decay)
        self.metrics['epsilon'].append(self.epsilon)

    def get_greedy_action(self, state):
        state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
        with torch.no_grad():
            q_values = self.model(state_tensor)
        action = q_values.argmax().item()
        return action

    def select_action(self, state):
        self.update_params_before_select_action()
        if random.random() < self.epsilon:
            return self.env.action_space.sample()
        return self.get_greedy_action(state)

    def _reshape_batch(self, batch):
        states = torch.FloatTensor(batch.state).to(self.device)
        actions = torch.LongTensor(batch.action).unsqueeze(1).to(self.device)
        rewards = torch.FloatTensor(batch.reward).unsqueeze(1).to(self.device)
        next_states = torch.FloatTensor(batch.next_state).to(self.device)
        dones = torch.FloatTensor(batch.done).unsqueeze(1).to(self.device)
        return states, actions, rewards, next_states, dones

    def get_q_values(self, states, actions):
        q_values = self.model(states)
        return q_values.gather(1, actions)

    def get_target_q_values(self, rewards, next_states, dones):
        with torch.no_grad():
            next_q_values = self.target_model(next_states)
            max_next_q = next_q_values.max(1, keepdim=True)[0]
            target_q = rewards + self.gamma * max_next_q * (1 - dones)
        return target_q

    def update_params(self, update_target_every=1000):
        if len(self.replay_buffer) < self.batch_size:
            return
        batch = self.replay_buffer.sample(self.batch_size)
        states, actions, rewards, next_states, dones = self._reshape_batch(batch)
        q_values = self.get_q_values(states, actions)
        target_q_values = self.get_target_q_values(rewards, next_states, dones)
        loss = nn.MSELoss()(q_values, target_q_values)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        self.metrics['value_loss'].append(loss.item())
        if self.timestep % update_target_every == 0:
            self.update_target_model()

    def get_hyperparams(self):
        return {
            'gamma': self.gamma,
            'lr_value': self.lr_value,
            'timestep': self.timestep,
            'epsilon': self.epsilon
        }

    def load_weights(self, state_dict):
        self.model.load_state_dict(state_dict)
        self.update_target_model()

    def get_logging_params(self):
        logs = {
            'value_loss': np.mean(self.metrics['value_loss']) if self.metrics['value_loss'] else 0.0,
            'epsilon': np.mean(self.metrics['epsilon']) if self.metrics['epsilon'] else 0.0
        }
        self.metrics['value_loss'] = []
        self.metrics['epsilon'] = []
        return logs

    def train(self, num_episodes=500):
        for episode in range(num_episodes):
            state = self.env.reset()
            done = False
            while not done:
                action = self.select_action(state)
                next_state, reward, done, _ = self.env.step(action)
                self.replay_buffer.push(state, action, reward, next_state, done)
                state = next_state
                self.timestep += 1
                self.update_params()
            if episode % 10 == 0:
                logs = self.get_logging_params()
                print(f"Episode {episode}, Logs: {logs}")
```