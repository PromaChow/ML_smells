import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression

# Load dataset
df = pd.read_csv("BostonHousing.csv")
print(df.head())

# Prepare features and target
X = df.iloc[:, :13]  # first 13 columns as features
y = df["medv"]       # target variable

# Correlation matrix and heatmap
corr_matrix = X.corr()
plt.figure(figsize=(10, 8))
sns.heatmap(corr_matrix, annot=True, fmt=".2f", cmap="coolwarm")
plt.title("Feature Correlation Matrix")
plt.show()

# Split into training and testing sets
x_train, x_test, y_train, y_test = train_test_split(
    X, y, test_size=0.3, random_state=10
)

# Train linear regression model
model = LinearRegression()
model.fit(x_train, y_train)

# Predict on test set
predicted_house_price = model.predict(x_test)

# Scatter plot of predicted vs actual prices
plt.figure(figsize=(6, 6))
plt.scatter(y_test, predicted_house_price, alpha=0.7)
plt.xlabel("Actual Median House Value")
plt.ylabel("Predicted Median House Value")
plt.title("Predicted vs Actual House Prices")
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'r--')
plt.show()

# Comparison DataFrame
comparison_df = pd.DataFrame(
    {"Actual": y_test.values, "Predicted": predicted_house_price}
)
print(comparison_df.head())