import os
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import gym
import multiprocessing as mp
from torch.utils.tensorboard import SummaryWriter

# Hyper‑parameters
MAX_ITERATIONS = 500
MAX_WORKERS    = 4
BATCH_SIZE     = 10
VIDEOS_INTERVAL = 50
SIGMA          = 0.1
LEARNING_RATE  = 0.01
VIDEO_DIR      = "videos"
VIDEO_ENABLED  = False

def normalized_rank(rewards: np.ndarray) -> np.ndarray:
    ranks = np.argsort(np.argsort(-rewards)) + 1.0
    ranks = (ranks - ranks.mean()) / (ranks.std() + 1e-8)
    return ranks

class NeuralNetwork(nn.Module):
    def __init__(self, input_dim=8, action_dim=2, hidden_dim=32):
        super().__init__()
        self.fc1   = nn.Linear(input_dim, hidden_dim)
        self.fc2   = nn.Linear(hidden_dim, hidden_dim)
        self.mean_l = nn.Linear(hidden_dim, action_dim)
        self.logstd = nn.Parameter(torch.zeros(action_dim))
    def forward(self, x):
        x = torch.tanh(self.fc1(x))
        x = torch.tanh(self.fc2(x))
        mean = torch.tanh(self.mean_l(x))
        return mean

def sample_noise(net: nn.Module) -> list:
    noise = []
    for p in net.parameters():
        n = np.random.randn(*p.shape) * SIGMA
        noise.append(n.astype(np.float32))
    return noise

def evaluate_neuralnet(net: nn.Module, env: gym.Env, seed: int) -> float:
    state = env.reset(seed=seed)
    total_reward = 0.0
    done = False
    while not done:
        state_t = torch.from_numpy(state).float()
        with torch.no_grad():
            action = net(state_t).cpu().numpy()
        action = np.clip(action, -1.0, 1.0)
        state, reward, done, _ = env.step(action)
        total_reward += reward
    return total_reward

def evaluate_noisy_net(net: nn.Module, noise: list, env: gym.Env, seed: int) -> float:
    original = [p.data.clone() for p in net.parameters()]
    for p, n in zip(net.parameters(), noise):
        p.data.add_(torch.from_numpy(n))
    reward = evaluate_neuralnet(net, env, seed)
    for p, orig in zip(net.parameters(), original):
        p.data.copy_(orig)
    return reward

def worker(params_queue: mp.Queue, output_queue: mp.Queue):
    env = gym.make("LunarLanderContinuous-v2")
    net = NeuralNetwork()
    while True:
        params = params_queue.get()
        if params is None:
            break
        for p, param_np in zip(net.parameters(), params):
            p.data.copy_(torch.from_numpy(param_np))
        for _ in range(BATCH_SIZE):
            seed = np.random.randint(0, 1_000_000)
            env.seed(seed)
            noise = sample_noise(net)
            reward_pos = evaluate_noisy_net(net, noise, env, seed)
            reward_neg = evaluate_noisy_net(net, [-n for n in noise], env, seed)
            noise_np = [n.copy() for n in noise]
            output_queue.put((seed, reward_pos, reward_neg, noise_np))
    env.close()

def test_agent(net: nn.Module, env: gym.Env, episodes: int = 5) -> float:
    total = 0.0
    for _ in range(episodes):
        total += evaluate_neuralnet(net, env, seed=np.random.randint(0, 1_000_000))
    return total / episodes

def main():
    env = gym.make("LunarLanderContinuous-v2")
    actor = NeuralNetwork()
    optimizer = optim.Adam(actor.parameters(), lr=LEARNING_RATE)
    writer = SummaryWriter()

    params_queue = mp.Queue()
    output_queue = mp.Queue()

    workers = []
    for _ in range(MAX_WORKERS):
        p = mp.Process(target=worker, args=(params_queue, output_queue))
        p.start()
        workers.append(p)

    for iteration in range(1, MAX_ITERATIONS + 1):
        params_np = [p.data.cpu().numpy() for p in actor.parameters()]
        for _ in range(BATCH_SIZE):
            for _ in range(MAX_WORKERS):
                params_queue.put(params_np)

        total_samples = BATCH_SIZE * MAX_WORKERS
        rewards_pos = []
        rewards_neg = []
        noise_list  = []

        for _ in range(total_samples):
            seed, r_pos, r_neg, noise_np = output_queue.get()
            rewards_pos.append(r_pos)
            rewards_neg.append(r_neg)
            noise_list.append(noise_np)

        delta_rewards = np.array(rewards_pos) - np.array(rewards_neg)
        norm_rewards = normalized_rank(delta_rewards)

        grads = [torch.zeros_like(p) for p in actor.parameters()]
        for s in range(total_samples):
            for i, p in enumerate(actor.parameters()):
                grads[i] += norm_rewards[s] * torch.from_numpy(noise_list[s][i])

        optimizer.zero_grad()
        for p, g in zip(actor.parameters(), grads):
            p.grad = -g / total_samples
        optimizer.step()

        mean_reward = np.mean(rewards_pos)
        writer.add_scalar("MeanReward", mean_reward, iteration)
        writer.add_scalar("Loss", -mean_reward, iteration)

        if iteration % VIDEOS_INTERVAL == 0:
            avg_test = test_agent(actor, env)
            print(f"Iteration {iteration} - Avg Test Reward: {avg_test:.2f}")

    for _ in range(MAX_WORKERS):
        params_queue.put(None)
    for p in workers:
        p.join()
    writer.close()
    env.close()

if __name__ == "__main__":
    mp.set_start_method("spawn")
    main()