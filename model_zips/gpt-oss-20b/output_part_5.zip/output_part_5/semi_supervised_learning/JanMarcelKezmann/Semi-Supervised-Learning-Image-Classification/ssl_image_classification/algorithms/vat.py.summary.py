import tensorflow as tf
import tensorflow_probability as tfp
from tensorflow_probability import distributions as tfd

@tf.function
def kl_divergence_from_logits(logits_a: tf.Tensor, logits_b: tf.Tensor) -> tf.Tensor:
    """Batchwise KL divergence between two sets of logits."""
    dist_a = tfd.Categorical(logits=logits_a)
    dist_b = tfd.Categorical(logits=logits_b)
    return tfp.math.kl_divergence(dist_a, dist_b)

@tf.function
def entropy(logits: tf.Tensor) -> tf.Tensor:
    """Shannon entropy of categorical distribution defined by logits."""
    dist = tfd.Categorical(logits=logits)
    return dist.entropy()

@tf.function
def kl_divergence_with_logits(logits_a: tf.Tensor, logits_b: tf.Tensor) -> tf.Tensor:
    """Manual computation of KL divergence between two logits sets."""
    a = tf.nn.softmax(logits_a, axis=-1)
    log_soft_a = tf.nn.log_softmax(logits_a, axis=-1)
    log_soft_b = tf.nn.log_softmax(logits_b, axis=-1)
    a_loga = tf.reduce_sum(a * log_soft_a, axis=-1)
    a_logb = tf.reduce_sum(a * log_soft_b, axis=-1)
    return a_loga - a_logb

@tf.function
def get_normalized_vector(v: tf.Tensor) -> tf.Tensor:
    """Normalize vector v first by its infinity norm then by its L2 norm."""
    axes = tf.range(1, tf.rank(v))
    inf_norm = tf.reduce_max(tf.abs(v), axis=axes, keepdims=True) + 1e-12
    v = v / inf_norm
    l2_norm = tf.sqrt(tf.reduce_sum(tf.square(v), axis=axes, keepdims=True) + 1e-12)
    return v / l2_norm

@tf.function
def log_softmax(x: tf.Tensor, axis: int = -1) -> tf.Tensor:
    """Compute the log-domain softmax of x."""
    x_max = tf.reduce_max(x, axis=axis, keepdims=True)
    x_adj = x - x_max
    log_sum_exp = tf.math.log(tf.reduce_sum(tf.exp(x_adj), axis=axis, keepdims=True))
    return x_adj - log_sum_exp

@tf.function
def vat(
    logits_p: tf.Tensor,
    model,
    x: tf.Tensor,
    xi: float = 1e-6,
    eps: float = 1.0
) -> tf.Tensor:
    """Generate virtual adversarial perturbation for input x."""
    v = tf.random.normal(tf.shape(x)) * xi
    v = get_normalized_vector(v)
    with tf.GradientTape() as tape:
        tape.watch(v)
        logits_m = model(x + v, training=True)
        kl = kl_divergence_with_logits(logits_p, logits_m)
        kl_mean = tf.reduce_mean(kl)
    grad = tape.gradient(kl_mean, v)
    v_adv = eps * get_normalized_vector(grad)
    return tf.stop_gradient(v_adv)

@tf.function
def ssl_loss_vat(
    labels_x: tf.Tensor,
    logits_x: tf.Tensor,
    logits_student: tf.Tensor,
    logits_teacher: tf.Tensor,
    logits_u: tf.Tensor
) -> tuple[tf.Tensor, tf.Tensor, tf.Tensor]:
    """Compute VAT-based SSL losses."""
    x_loss = tf.reduce_mean(
        tf.nn.sparse_softmax_cross_entropy_with_logits(
            labels=labels_x, logits=logits_x
        )
    )
    loss_vat = tf.reduce_mean(
        kl_divergence_from_logits(logits_student, logits_teacher)
    )
    loss_entropy = tf.reduce_mean(entropy(logits_u))
    return x_loss, loss_vat, loss_entropy
