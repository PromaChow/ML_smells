import numpy as np

def create_semisupervised_setting(
    labels,
    normal_classes,
    outlier_classes,
    known_outlier_classes,
    ratio_known_normal=0.1,
    ratio_known_outlier=0.1,
    ratio_pollution=0.1,
    random_state=None,
):
    rng = np.random.default_rng(random_state)

    # 1. Class index identification
    labels_arr = np.asarray(labels)
    idx_normal = np.where(np.isin(labels_arr, normal_classes))[0]
    idx_outlier = np.where(np.isin(labels_arr, outlier_classes))[0]
    idx_known_outlier_candidates = np.where(np.isin(labels_arr, known_outlier_classes))[0]

    n_normal = len(idx_normal)
    n_known_outlier_candidates = len(idx_known_outlier_candidates)

    # 2. Compute counts
    n_known_normal = int(round(ratio_known_normal * n_normal))
    n_known_normal = min(n_known_normal, n_normal)

    n_known_outlier = int(round(ratio_known_outlier * n_known_outlier_candidates))
    n_known_outlier = min(n_known_outlier, n_known_outlier_candidates)

    n_unlabeled_normal = n_normal - n_known_normal

    if ratio_pollution == 1.0:
        n_unlabeled_outlier = n_unlabeled_normal  # all unlabeled will become outliers
        n_unlabeled_normal = 0
    else:
        if ratio_pollution == 0.0:
            n_unlabeled_outlier = 0
        else:
            n_unlabeled_outlier = int(round((ratio_pollution / (1.0 - ratio_pollution)) * n_unlabeled_normal))
            # Adjust if exceeds available outlier indices
            n_unlabeled_outlier = min(n_unlabeled_outlier, len(idx_outlier))
            # Recompute unlabeled normal to maintain totals
            n_unlabeled_normal = min(n_unlabeled_normal, len(idx_outlier) - n_unlabeled_outlier)

    # 3. Random sampling of indices
    perm_normal = rng.permutation(idx_normal)
    idx_known_normal = perm_normal[:n_known_normal]
    idx_unlabeled_normal = perm_normal[n_known_normal : n_known_normal + n_unlabeled_normal]

    perm_outlier = rng.permutation(idx_outlier)
    idx_unlabeled_outlier = perm_outlier[:n_unlabeled_outlier]

    perm_known_outlier = rng.permutation(idx_known_outlier_candidates)
    idx_known_outlier = perm_known_outlier[:n_known_outlier]

    # 4. Label extraction
    labels_known_normal = labels_arr[idx_known_normal]
    labels_unlabeled_normal = labels_arr[idx_unlabeled_normal]
    labels_unlabeled_outlier = labels_arr[idx_unlabeled_outlier]
    labels_known_outlier = labels_arr[idx_known_outlier]

    # 5. Semi-supervised label assignment
    semi_labels_known_normal = np.full_like(labels_known_normal, 1)
    semi_labels_unlabeled_normal = np.full_like(labels_unlabeled_normal, 0)
    semi_labels_unlabeled_outlier = np.full_like(labels_unlabeled_outlier, 0)
    semi_labels_known_outlier = np.full_like(labels_known_outlier, -1)

    # 6. Final aggregation
    list_idx = np.concatenate(
        [
            idx_known_normal,
            idx_unlabeled_normal,
            idx_unlabeled_outlier,
            idx_known_outlier,
        ]
    ).tolist()

    list_labels = np.concatenate(
        [
            labels_known_normal,
            labels_unlabeled_normal,
            labels_unlabeled_outlier,
            labels_known_outlier,
        ]
    ).tolist()

    list_semi_labels = np.concatenate(
        [
            semi_labels_known_normal,
            semi_labels_unlabeled_normal,
            semi_labels_unlabeled_outlier,
            semi_labels_known_outlier,
        ]
    ).tolist()

    return list_idx, list_labels, list_semi_labels

# Example usage (uncomment to test)
# if __name__ == "__main__":
#     labels = np.random.randint(0, 5, size=1000)
#     normal_classes = [0, 1]
#     outlier_classes = [2, 3, 4]
#     known_outlier_classes = [2]
#     idx, lbls, semi_lbls = create_semisupervised_setting(
#         labels, normal_classes, outlier_classes, known_outlier_classes,
#         ratio_known_normal=0.2, ratio_known_outlier=0.3, ratio_pollution=0.1,
#         random_state=42
#     )
#     print(len(idx), len(lbls), len(semi_lbls))