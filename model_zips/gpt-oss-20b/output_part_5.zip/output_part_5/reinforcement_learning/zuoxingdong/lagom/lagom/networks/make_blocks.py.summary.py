import torch.nn as nn


def make_fc(input_dim, hidden_sizes):
    """
    Create a list of fully connected (Linear) layers.

    Args:
        input_dim (int): Size of the input features.
        hidden_sizes (list of int): Sizes of the hidden layers.

    Returns:
        nn.ModuleList: A ModuleList containing the Linear layers.
    """
    if not isinstance(hidden_sizes, list):
        raise TypeError("hidden_sizes must be a list")

    dims = [input_dim] + hidden_sizes
    layers = []

    for in_dim, out_dim in zip(dims[:-1], dims[1:]):
        layers.append(nn.Linear(in_dim, out_dim))

    return nn.ModuleList(layers)


def make_cnn(input_channel, channels, kernels, strides, paddings):
    """
    Create a list of Conv2d layers.

    Args:
        input_channel (int): Number of input channels.
        channels (list of int): Output channel sizes for each layer.
        kernels (list of int or tuple): Kernel sizes for each layer.
        strides (list of int or tuple): Stride values for each layer.
        paddings (list of int or tuple): Padding values for each layer.

    Returns:
        nn.ModuleList: A ModuleList containing the Conv2d layers.
    """
    if not (isinstance(channels, list) and isinstance(kernels, list) and
            isinstance(strides, list) and isinstance(paddings, list)):
        raise TypeError("channels, kernels, strides, and paddings must be lists")

    length = len(channels)
    if not (len(kernels) == len(strides) == len(paddings) == length):
        raise ValueError("channels, kernels, strides, and paddings must have the same length")

    ch_seq = [input_channel] + channels
    layers = []

    for in_ch, out_ch, k, s, p in zip(ch_seq[:-1], ch_seq[1:], kernels, strides, paddings):
        layers.append(nn.Conv2d(in_ch, out_ch, kernel_size=k, stride=s, padding=p))

    return nn.ModuleList(layers)


def make_transposed_cnn(input_channel, channels, kernels, strides, paddings, output_paddings):
    """
    Create a list of ConvTranspose2d layers.

    Args:
        input_channel (int): Number of input channels.
        channels (list of int): Output channel sizes for each layer.
        kernels (list of int or tuple): Kernel sizes for each layer.
        strides (list of int or tuple): Stride values for each layer.
        paddings (list of int or tuple): Padding values for each layer.
        output_paddings (list of int or tuple): Output padding values for each layer.

    Returns:
        nn.ModuleList: A ModuleList containing the ConvTranspose2d layers.
    """
    if not (isinstance(channels, list) and isinstance(kernels, list) and
            isinstance(strides, list) and isinstance(paddings, list) and
            isinstance(output_paddings, list)):
        raise TypeError("channels, kernels, strides, paddings, and output_paddings must be lists")

    length = len(channels)
    if not (len(kernels) == len(strides) == len(paddings) == len(output_paddings) == length):
        raise ValueError("All parameter lists must have the same length")

    ch_seq = [input_channel] + channels
    layers = []

    for in_ch, out_ch, k, s, p, op in zip(ch_seq[:-1], ch_seq[1:], kernels, strides, paddings, output_paddings):
        layers.append(nn.ConvTranspose2d(in_ch, out_ch, kernel_size=k,
                                         stride=s, padding=p, output_padding=op))

    return nn.ModuleList(layers)