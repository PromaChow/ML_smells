import enum
import numpy as np
from spriteworld import shapes

# Define a library of predefined shapes
SHAPES = {
    'triangle': shapes.polygon(num_sides=3, theta_0=0),
    'square': shapes.polygon(num_sides=4, theta_0=0),
    'pentagon': shapes.polygon(num_sides=5, theta_0=0),
    'hexagon': shapes.polygon(num_sides=6, theta_0=0),
    'heptagon': shapes.polygon(num_sides=7, theta_0=0),
    'octagon': shapes.polygon(num_sides=8, theta_0=0),
    'star_4': shapes.star(num_sides=4, theta_0=0),
    'star_5': shapes.star(num_sides=5, theta_0=0),
    'spoke_4': shapes.spokes(num_sides=4, theta_0=0),
    'spoke_5': shapes.spokes(num_sides=5, theta_0=0),
    'circle': shapes.polygon(num_sides=30, theta_0=0),
}

# Create an IntEnum mapping each shape to a unique integer
class ShapeType(enum.IntEnum):
    triangle = 1
    square = 2
    pentagon = 3
    hexagon = 4
    heptagon = 5
    octagon = 6
    star_4 = 7
    star_5 = 8
    spoke_4 = 9
    spoke_5 = 10
    circle = 11
