import unittest
import gym
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from collections import deque, Counter

# Simple moving average smoother
class Smooth:
    def __init__(self, window_size=10):
        self.window_size = window_size
        self.data = deque(maxlen=window_size)

    def add(self, value):
        self.data.append(value)

    def avg(self):
        return np.mean(self.data) if self.data else 0.0

# Replay buffer
class ReplayBuffer:
    def __init__(self, capacity=10000):
        self.capacity = capacity
        self.buffer = deque(maxlen=capacity)

    def push(self, state, action, reward, next_state, done):
        self.buffer.append((state, action, reward, next_state, done))

    def sample(self, batch_size):
        idx = np.random.choice(len(self.buffer), batch_size, replace=False)
        batch = [self.buffer[i] for i in idx]
        state, action, reward, next_state, done = map(np.array, zip(*batch))
        return state, action, reward, next_state, done

    def __len__(self):
        return len(self.buffer)

# Simple Q-network for discrete actions
class QNet(nn.Module):
    def __init__(self, state_dim, action_dim, hidden=128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, hidden),
            nn.ReLU(),
            nn.Linear(hidden, hidden),
            nn.ReLU(),
            nn.Linear(hidden, action_dim),
        )

    def forward(self, x):
        return self.net(x)

# Actor network for continuous actions (not used in CartPole)
class Actor(nn.Module):
    def __init__(self, state_dim, action_dim, hidden=128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, hidden),
            nn.ReLU(),
            nn.Linear(hidden, hidden),
            nn.ReLU(),
            nn.Linear(hidden, action_dim),
            nn.Tanh(),
        )

    def forward(self, x):
        return self.net(x)

# Critic network for DDPG
class Critic(nn.Module):
    def __init__(self, state_dim, action_dim, hidden=128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim + action_dim, hidden),
            nn.ReLU(),
            nn.Linear(hidden, hidden),
            nn.ReLU(),
            nn.Linear(hidden, 1),
        )

    def forward(self, state, action):
        x = torch.cat([state, action], dim=1)
        return self.net(x)

# DQNApex minimal implementation
class DQNApex:
    def __init__(self, qnet, target_qnet, lr=1e-3, gamma=0.99, batch_size=32, replay_size=10000):
        self.qnet = qnet
        self.target_qnet = target_qnet
        self.optimizer = optim.Adam(self.qnet.parameters(), lr=lr)
        self.criterion = nn.MSELoss()
        self.gamma = gamma
        self.batch_size = batch_size
        self.replay = ReplayBuffer(replay_size)

    def act_discrete(self, state, epsilon=0.0):
        state = torch.tensor(state, dtype=torch.float32).unsqueeze(0)
        with torch.no_grad():
            q_values = self.qnet(state)
        if np.random.rand() < epsilon:
            return np.random.randint(q_values.shape[-1])
        return int(torch.argmax(q_values, dim=1).item())

    def act_discrete_with_noise(self, state, epsilon=0.1):
        return self.act_discrete(state, epsilon)

    def _criticize(self, state, action):
        state = torch.tensor(state, dtype=torch.float32)
        action = torch.tensor(action, dtype=torch.float32)
        q = self.qnet(state.unsqueeze(0))
        return q[0, int(action)].item()

    def store(self, state, action, reward, next_state, done):
        self.replay.push(state, action, reward, next_state, done)

    def update(self):
        if len(self.replay) < self.batch_size:
            return
        states, actions, rewards, next_states, dones = self.replay.sample(self.batch_size)
        states = torch.tensor(states, dtype=torch.float32)
        actions = torch.tensor(actions, dtype=torch.int64).unsqueeze(1)
        rewards = torch.tensor(rewards, dtype=torch.float32).unsqueeze(1)
        next_states = torch.tensor(next_states, dtype=torch.float32)
        dones = torch.tensor(dones, dtype=torch.float32).unsqueeze(1)

        q_values = self.qnet(states).gather(1, actions)
        with torch.no_grad():
            next_q = self.target_qnet(next_states).max(1)[0].unsqueeze(1)
            target = rewards + self.gamma * next_q * (1 - dones)
        loss = self.criterion(q_values, target)
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

    def sync_target(self):
        self.target_qnet.load_state_dict(self.qnet.state_dict())

# DDPGApex minimal implementation (discrete version for CartPole)
class DDPGApex:
    def __init__(self, actor, critic, target_actor, target_critic,
                 lr_actor=1e-3, lr_critic=1e-3, gamma=0.99, batch_size=32, replay_size=10000):
        self.actor = actor
        self.critic = critic
        self.target_actor = target_actor
        self.target_critic = target_critic
        self.actor_opt = optim.Adam(self.actor.parameters(), lr=lr_actor)
        self.critic_opt = optim.Adam(self.critic.parameters(), lr=lr_critic)
        self.criterion = nn.MSELoss()
        self.gamma = gamma
        self.batch_size = batch_size
        self.replay = ReplayBuffer(replay_size)

    def act(self, state, epsilon=0.0):
        state = torch.tensor(state, dtype=torch.float32).unsqueeze(0)
        with torch.no_grad():
            action = self.actor(state)
        if np.random.rand() < epsilon:
            return np.random.randn(*action.shape[1:].cpu().numpy().shape)
        return action.squeeze(0).cpu().numpy()

    def act_discrete(self, state, epsilon=0.0):
        # For discrete actions, use argmax of Q-values approximated by critic
        state_t = torch.tensor(state, dtype=torch.float32).unsqueeze(0)
        with torch.no_grad():
            q_vals = self.critic(state_t, torch.tensor([0.0, 0.0], dtype=torch.float32).unsqueeze(0))
        if np.random.rand() < epsilon:
            return np.random.randint(2)
        return int(torch.argmax(q_vals, dim=1).item())

    def act_discrete_with_noise(self, state, epsilon=0.1):
        return self.act_discrete(state, epsilon)

    def _criticize(self, state, action):
        state_t = torch.tensor(state, dtype=torch.float32).unsqueeze(0)
        action_t = torch.tensor(action, dtype=torch.float32).unsqueeze(0)
        q = self.critic(state_t, action_t)
        return q.item()

    def store(self, state, action, reward, next_state, done):
        self.replay.push(state, action, reward, next_state, done)

    def update(self):
        if len(self.replay) < self.batch_size:
            return
        states, actions, rewards, next_states, dones = self.replay.sample(self.batch_size)
        states = torch.tensor(states, dtype=torch.float32)
        actions = torch.tensor(actions, dtype=torch.float32)
        rewards = torch.tensor(rewards, dtype=torch.float32).unsqueeze(1)
        next_states = torch.tensor(next_states, dtype=torch.float32)
        dones = torch.tensor(dones, dtype=torch.float32).unsqueeze(1)

        # Critic update
        with torch.no_grad():
            next_actions = self.target_actor(next_states)
            next_q = self.target_critic(next_states, next_actions)
            target_q = rewards + self.gamma * next_q * (1 - dones)
        current_q = self.critic(states, actions)
        critic_loss = self.criterion(current_q, target_q)
        self.critic_opt.zero_grad()
        critic_loss.backward()
        self.critic_opt.step()

        # Actor update
        actions_pred = self.actor(states)
        actor_loss = -self.critic(states, actions_pred).mean()
        self.actor_opt.zero_grad()
        actor_loss.backward()
        self.actor_opt.step()

    def sync_target(self):
        self.target_actor.load_state_dict(self.actor.state_dict())
        self.target_critic.load_state_dict(self.critic.state_dict())

class TestDQNApex(unittest.TestCase):
    def setUp(self):
        self.env = gym.make('CartPole-v0')
        self.state_dim = self.env.observation_space.shape[0]
        self.action_dim = self.env.action_space.n
        self.qnet = QNet(self.state_dim, self.action_dim)
        self.qnet_t = QNet(self.state_dim, self.action_dim)
        self.agent = DQNApex(self.qnet, self.qnet_t, lr=1e-3, gamma=0.99,
                             batch_size=32, replay_size=10000)
        self.agent.sync_target()
        np.random.seed(0)
        torch.manual_seed(0)

    def test_act_discrete(self):
        state = self.env.reset()
        action = self.agent.act_discrete(state)
        self.assertIn(action, range(self.action_dim))

    def test_act_discrete_with_noise(self):
        state = self.env.reset()
        action = self.agent.act_discrete_with_noise(state, epsilon=0.5)
        self.assertIn(action, range(self.action_dim))

    def test_criticize(self):
        state = self.env.reset()
        action = 0
        value = self.agent._criticize(state, action)
        self.assertIsInstance(value, float)

    def test_update(self):
        # create dummy data
        for _ in range(50):
            state = self.env.reset()
            action = self.agent.act_discrete(state)
            next_state, reward, done, _ = self.env.step(action)
            self.agent.store(state, action, reward, next_state, done)
        # before update
        initial_params = [p.clone() for p in self.agent.qnet.parameters()]
        self.agent.update()
        # after update
        updated_params = [p.clone() for p in self.agent.qnet.parameters()]
        self.assertTrue(any(not torch.equal(ip, up) for ip, up in zip(initial_params, updated_params)))

    def test_config_init(self):
        # Simulate loading config
        config = {
            'lr': 2e-3,
            'gamma': 0.95,
            'batch_size': 64,
            'replay_size': 5000
        }
        agent = DQNApex(self.qnet, self.qnet_t,
                        lr=config['lr'],
                        gamma=config['gamma'],
                        batch_size=config['batch_size'],
                        replay_size=config['replay_size'])
        self.assertEqual(agent.optimizer.param_groups[0]['lr'], config['lr'])
        self.assertEqual(agent.gamma, config['gamma'])
        self.assertEqual(agent.batch_size, config['batch_size'])
        self.assertEqual(len(agent.replay), 0)

    def test_full_training(self):
        max_episodes = 200
        solved_reward = 150
        solved_repeat = 10
        smooth = Smooth(window_size=10)
        episode_counter = Counter()
        for ep in range(max_episodes):
            state = self.env.reset()
            total_reward = 0
            done = False
            while not done:
                action = self.agent.act_discrete(state, epsilon=0.1)
                next_state, reward, done, _ = self.env.step(action)
                self.agent.store(state, action, reward, next_state, done)
                self.agent.update()
                state = next_state
                total_reward += reward
            episode_counter[ep] = total_reward
            smooth.add(total_reward)
            if smooth.avg() >= solved_reward and len(episode_counter) >= solved_repeat:
                break
        self.assertLessEqual(ep, max_episodes)

class TestDDPGApex(unittest.TestCase):
    def setUp(self):
        self.env = gym.make('CartPole-v0')
        self.state_dim = self.env.observation_space.shape[0]
        self.action_dim = self.env.action_space.n
        self.actor = Actor(self.state_dim, self.action_dim)
        self.actor_t = Actor(self.state_dim, self.action_dim)
        self.critic = Critic(self.state_dim, self.action_dim)
        self.critic_t = Critic(self.state_dim, self.action_dim)
        self.agent = DDPGApex(self.actor, self.critic,
                              self.actor_t, self.critic_t,
                              lr_actor=1e-3, lr_critic=1e-3,
                              gamma=0.99, batch_size=32, replay_size=10000)
        self.agent.sync_target()
        np.random.seed(1)
        torch.manual_seed(1)

    def test_act(self):
        state = self.env.reset()
        action = self.agent.act(state, epsilon=0.0)
        self.assertEqual(action.shape, (self.action_dim,))

    def test_act_discrete(self):
        state = self.env.reset()
        action = self.agent.act_discrete(state, epsilon=0.1)
        self.assertIn(action, range(self.action_dim))

    def test_act_discrete_with_noise(self):
        state = self.env.reset()
        action = self.agent.act_discrete_with_noise(state, epsilon=0.2)
        self.assertIn(action, range(self.action_dim))

    def test_criticize(self):
        state = self.env.reset()
        action = 0
        value = self.agent._criticize(state, action)
        self.assertIsInstance(value, float)

    def test_update(self):
        for _ in range(50):
            state = self.env.reset()
            action = self.agent.act_discrete(state)
            next_state, reward, done, _ = self.env.step(action)
            self.agent.store(state, action, reward, next_state, done)
        initial_actor_params = [p.clone() for p in self.agent.actor.parameters()]
        self.agent.update()
        updated_actor_params = [p.clone() for p in self.agent.actor.parameters()]
        self.assertTrue(any(not torch.equal(ip, up) for ip, up in zip(initial_actor_params, updated_actor_params)))

    def test_config_init(self):
        config = {
            'lr_actor': 3e-3,
            'lr_critic': 3e-3,
            'gamma': 0.9,
            'batch_size': 64,
            'replay_size': 8000
        }
        agent = DDPGApex(self.actor, self.critic,
                         self.actor_t, self.critic_t,
                         lr_actor=config['lr_actor'],
                         lr_critic=config['lr_critic'],
                         gamma=config['gamma'],
                         batch_size=config['batch_size'],
                         replay_size=config['replay_size'])
        self.assertEqual(agent.actor_opt.param_groups[0]['lr'], config['lr_actor'])
        self.assertEqual(agent.critic_opt.param_groups[0]['lr'], config['lr_critic'])
        self.assertEqual(agent.gamma, config['gamma'])
        self.assertEqual(agent.batch_size, config['batch_size'])
        self.assertEqual(len(agent.replay), 0)

    def test_full_training(self):
        max_episodes = 200
        solved_reward = 150
        solved_repeat = 10
        smooth = Smooth(window_size=10)
        episode_counter = Counter()
        for ep in range(max_episodes):
            state = self.env.reset()
            total_reward = 0
            done = False
            while not done:
                action = self.agent.act_discrete(state, epsilon=0.1)
                next_state, reward, done, _ = self.env.step(action)
                self.agent.store(state, action, reward, next_state, done)
                self.agent.update()
                state = next_state
                total_reward += reward
            episode_counter[ep] = total_reward
            smooth.add(total_reward)
            if smooth.avg() >= solved_reward and len(episode_counter) >= solved_repeat:
                break
        self.assertLessEqual(ep, max_episodes)

if __name__ == "__main__":
    unittest.main()