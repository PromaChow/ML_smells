import numpy as np

def percent_round_int(percent, x):
    proportional = percent * x
    rounded = np.round(np.array(proportional))
    return rounded.astype(int)