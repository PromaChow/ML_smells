import torch
import torch.nn as nn
import torch.nn.functional as F


class MT(nn.Module):
    def __init__(self, model: nn.Module, ema_factor: float):
        super().__init__()
        self.model = model
        self.ema_factor = ema_factor
        self.model.train()
        self.global_step = 0

    def forward(self, x):
        self.global_step += 1

        y_hat = self.model(x)

        self.model.update_batch_stats(False)
        y = self.model(x)
        self.model.update_batch_stats(True)

        target_soft = F.softmax(y, dim=-1)
        pred_soft = F.softmax(y_hat, dim=-1).detach()

        mse = (target_soft - pred_soft) ** 2
        mask = torch.ones_like(mse)
        loss = (mse * mask).mean()
        return loss

    def moving_average(self, params):
        ema_factor = min(self.ema_factor, 1 - 1 / (self.global_step + 1))
        for emp_p, p in zip(self.model.parameters(), params):
            emp_p.data = ema_factor * emp_p.data + (1 - ema_factor) * p.data