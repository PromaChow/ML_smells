import numpy as np

def cv_index(n, n_fold):
    """Generate a random permutation of fold indices for cross‑validation."""
    indices = np.arange(n)
    fold_idx = (indices * n_fold) // n
    perm = np.random.permutation(n)
    return fold_idx[perm]

def squared_dist(x, c):
    """Compute squared Euclidean distance between rows of x and rows of c."""
    sumx = np.sum(x**2, axis=1, keepdims=True)
    sumc = np.sum(c**2, axis=1, keepdims=True).T
    return sumx + sumc - 2 * x @ c.T

def gauss_basis(dist2, sigma):
    """Apply Gaussian kernel to precomputed squared distances."""
    return np.exp(-dist2 / (2 * sigma**2))

def homo_coord(x):
    """Append a column of ones to create homogeneous coordinates."""
    return np.c_[x, np.ones(x.shape[0])]

def bin_clf_err(y_h, y_t, prior=None):
    """Compute binary classification error."""
    y_h = np.asarray(y_h).reshape(-1)
    y_t = np.asarray(y_t).reshape(-1)
    if prior is not None:
        # False positive rate for true positive class
        tp_mask = y_t == 1
        f_p = np.mean((y_h <= 0)[tp_mask]) if np.any(tp_mask) else 0.0
        # False negative rate for true negative class
        tn_mask = y_t == -1
        f_n = np.mean((y_h > 0)[tn_mask]) if np.any(tn_mask) else 0.0
        return prior * f_p + (1 - prior) * f_n
    else:
        return np.mean((y_h * y_t <= 0))