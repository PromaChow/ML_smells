import numpy as np
import chainer
from chainer import Variable
import chainer.cuda as cuda


class ModelTest:
    def _test_call_given_model(self, model, gpu=-1, n_dim_obs=4, n_dim_action=2):
        batch_size = 7

        obs = np.random.randn(batch_size, n_dim_obs).astype(np.float32)
        action = np.random.randn(batch_size, n_dim_action).astype(np.float32)

        if gpu >= 0:
            model.to_gpu(gpu)
            obs = cuda.to_gpu(obs)
            action = cuda.to_gpu(action)

        y = model(obs, action)

        assert isinstance(y, Variable), "Output is not a chainer.Variable"
        assert y.shape == (batch_size, 1), f"Expected shape (7, 1), got {y.shape}"

        device_obs = cuda.get_device_from_array(obs)
        device_y = cuda.get_device_from_array(y.array)
        assert device_obs == device_y, "y is on a different device than obs"