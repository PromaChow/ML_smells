import argparse
import json
import os
import sys
import numpy as np
import h5py
from tensorflow.keras import models, layers, optimizers, callbacks
from tensorflow.keras.utils import Sequence

# --------------------------------------------
# Utility functions
# --------------------------------------------

def one_hot_action(x, y, board_size=19):
    """Convert board coordinates to one‑hot vector."""
    idx = y * board_size + x
    vec = np.zeros(board_size * board_size, dtype=np.float32)
    vec[idx] = 1.0
    return vec

# --------------------------------------------
# Board transformations
# --------------------------------------------

def _rot90(x, k):
    return np.rot90(x, k=k, axes=(0, 1))

def _flipud(x):
    return np.flipud(x)

def _fliplr(x):
    return np.fliplr(x)

BOARD_TRANSFORMATIONS = {
    'identity': lambda x: x,
    'rot90': lambda x: _rot90(x, 1),
    'rot180': lambda x: _rot90(x, 2),
    'rot270': lambda x: _rot90(x, 3),
    'flipud': _flipud,
    'fliplr': _fliplr,
    'flipud_rot90': lambda x: _rot90(_flipud(x), 1),
    'fliplr_rot90': lambda x: _rot90(_fliplr(x), 1),
}

# --------------------------------------------
# Data generator
# --------------------------------------------

class ShuffledHDF5BatchGenerator(Sequence):
    def __init__(self, h5_path, indices, batch_size, transformations, shuffle=True):
        self.h5_path = h5_path
        self.indices = indices
        self.batch_size = batch_size
        self.transformations = transformations
        self.shuffle = shuffle
        self._file = None
        self.on_epoch_end()

    def __len__(self):
        return int(np.ceil(len(self.indices) / self.batch_size))

    def on_epoch_end(self):
        if self.shuffle:
            np.random.shuffle(self.indices)

    def __getitem__(self, idx):
        if self._file is None:
            self._file = h5py.File(self.h5_path, 'r')
        start = idx * self.batch_size
        end = min(start + self.batch_size, len(self.indices))
        batch_indices = self.indices[start:end]
        states = []
        actions = []
        for i in batch_indices:
            state = self._file['states'][i]
            action = self._file['actions'][i]
            t_name = np.random.choice(self.transformations)
            t_func = BOARD_TRANSFORMATIONS[t_name]
            state_t = t_func(state)
            action_t = self._apply_transform_action(action, t_name)
            states.append(state_t)
            actions.append(one_hot_action(action_t[0], action_t[1]))
        X = np.array(states, dtype=np.float32)
        Y = np.array(actions, dtype=np.float32)
        return X, Y

    def _apply_transform_action(self, action, t_name):
        x, y = action
        if t_name == 'identity':
            return x, y
        if t_name == 'rot90':
            return 18 - y, x
        if t_name == 'rot180':
            return 18 - x, 18 - y
        if t_name == 'rot270':
            return y, 18 - x
        if t_name == 'flipud':
            return x, 18 - y
        if t_name == 'fliplr':
            return 18 - x, y
        if t_name == 'flipud_rot90':
            return 18 - y, 18 - x
        if t_name == 'fliplr_rot90':
            return y, x
        return x, y

# --------------------------------------------
# Metadata callback
# --------------------------------------------

class MetadataWriterCallback(callbacks.Callback):
    def __init__(self, metadata_path, total_epochs):
        super().__init__()
        self.metadata_path = metadata_path
        self.total_epochs = total_epochs
        self.logs = []
        self.best_val_loss = np.Inf
        self.best_epoch = None

    def on_epoch_end(self, epoch, logs=None):
        logs = logs or {}
        self.logs.append({
            'epoch': epoch + 1,
            'loss': logs.get('loss'),
            'val_loss': logs.get('val_loss'),
            'accuracy': logs.get('accuracy'),
            'val_accuracy': logs.get('val_accuracy')
        })
        val_loss = logs.get('val_loss')
        if val_loss is not None and val_loss < self.best_val_loss:
            self.best_val_loss = val_loss
            self.best_epoch = epoch + 1
        self._write_metadata()

    def _write_metadata(self):
        data = {
            'logs': self.logs,
            'best_val_loss': self.best_val_loss,
            'best_epoch': self.best_epoch,
            'total_epochs': self.total_epochs
        }
        with open(self.metadata_path, 'w') as f:
            json.dump(data, f, indent=2)

# --------------------------------------------
# Simple CNNPolicy loader
# --------------------------------------------

class CNNPolicy:
    @staticmethod
    def load_model(json_path):
        with open(json_path, 'r') as f:
            json_str = f.read()
        return models.model_from_json(json_str)

# --------------------------------------------
# Training function
# --------------------------------------------

def run_training():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model_json', required=True, help='Path to model architecture JSON')
    parser.add_argument('--data_file', required=True, help='Path to HDF5 dataset')
    parser.add_argument('--output_dir', required=True, help='Directory to save outputs')
    parser.add_argument('--batch_size', type=int, default=64, help='Batch size')
    parser.add_argument('--learning_rate', type=float, default=0.01, help='Initial learning rate')
    parser.add_argument('--epochs', type=int, default=10, help='Number of epochs')
    parser.add_argument('--symmetry', nargs='+', default=list(BOARD_TRANSFORMATIONS.keys()),
                        help='List of symmetry transformations to use')
    parser.add_argument('--train_frac', type=float, default=0.93, help='Training set fraction')
    parser.add_argument('--val_frac', type=float, default=0.05, help='Validation set fraction')
    parser.add_argument('--test_frac', type=float, default=0.02, help='Test set fraction')
    parser.add_argument('--resume', action='store_true', help='Resume training from existing weights')
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    # Load model
    model = CNNPolicy.load_model(args.model_json)

    # Load dataset metadata
    with h5py.File(args.data_file, 'r') as h5:
        total_samples = h5['states'].shape[0]

    # Split indices
    indices = np.arange(total_samples)
    np.random.shuffle(indices)
    train_end = int(total_samples * args.train_frac)
    val_end = train_end + int(total_samples * args.val_frac)
    train_idx = indices[:train_end]
    val_idx = indices[train_end:val_end]
    test_idx = indices[val_end:]

    # Ensure training size divisible by batch size
    remainder = len(train_idx) % args.batch_size
    if remainder != 0:
        train_idx = train_idx[:-remainder]

    # Shuffle indices file
    shuffle_path = os.path.join(args.output_dir, 'shuffle.npz')
    if os.path.exists(shuffle_path):
        npz = np.load(shuffle_path)
        train_idx = npz['train']
        val_idx = npz['val']
    else:
        np.savez(shuffle_path, train=train_idx, val=val_idx)

    # Data generators
    train_gen = ShuffledHDF5BatchGenerator(
        h5_path=args.data_file,
        indices=train_idx,
        batch_size=args.batch_size,
        transformations=args.symmetry,
        shuffle=True
    )
    val_gen = ShuffledHDF5BatchGenerator(
        h5_path=args.data_file,
        indices=val_idx,
        batch_size=args.batch_size,
        transformations=['identity'],
        shuffle=False
    )

    # Compile model
    sgd = optimizers.SGD(learning_rate=args.learning_rate, decay=args.learning_rate / args.epochs)
    model.compile(optimizer=sgd,
                  loss='categorical_crossentropy',
                  metrics=['accuracy'])

    # Callbacks
    checkpoint_cb = callbacks.ModelCheckpoint(
        filepath=os.path.join(args.output_dir, 'weights.{epoch:05d}.hdf5'),
        save_weights_only=True,
        save_freq='epoch'
    )
    metadata_cb = MetadataWriterCallback(
        metadata_path=os.path.join(args.output_dir, 'metadata.json'),
        total_epochs=args.epochs
    )

    # Load previous weights if resuming
    if args.resume:
        weight_files = [f for f in os.listdir(args.output_dir) if f.startswith('weights')]
        if weight_files:
            latest = max(weight_files, key=lambda x: int(x.split('.')[1]))
            model.load_weights(os.path.join(args.output_dir, latest))

    # Train
    model.fit(
        train_gen,
        epochs=args.epochs,
        validation_data=val_gen,
        callbacks=[checkpoint_cb, metadata_cb],
        workers=4,
        use_multiprocessing=True
    )

if __name__ == '__main__':
    run_training()
