import gym
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.kernel_approximation import RBFSampler
from sklearn.pipeline import FeatureUnion
from sklearn.linear_model import SGDRegressor
import matplotlib.pyplot as plt
from collections import deque

# Environment
env = gym.envs.make('MountainCar-v0')
n_actions = env.action_space.n

# Feature preprocessing
sample_states = np.array([env.observation_space.sample() for _ in range(10000)])
scaler = StandardScaler()
scaler.fit(sample_states)

rbf_features = FeatureUnion([
    ('rbf_5', RBFSampler(gamma=5.0, n_components=100, random_state=1)),
    ('rbf_2', RBFSampler(gamma=2.0, n_components=100, random_state=1)),
    ('rbf_1', RBFSampler(gamma=1.0, n_components=100, random_state=1)),
    ('rbf_0.5', RBFSampler(gamma=0.5, n_components=100, random_state=1))
])
rbf_features.fit(scaler.transform(sample_states))

# Estimator
class Estimator:
    def __init__(self, n_actions, scaler, feature_extractor):
        self.n_actions = n_actions
        self.scaler = scaler
        self.feature_extractor = feature_extractor
        self.models = {a: SGDRegressor(learning_rate='constant', eta0=0.01,
                                        penalty=None, average=True) for a in range(n_actions)}
        # Initial dummy fit
        dummy = np.zeros((1, self.feature_extractor.transform(self.scaler.transform(np.zeros((1, 2)))).shape[1]))
        for a in range(n_actions):
            self.models[a].partial_fit(dummy, np.zeros(1))
    
    def featurize_state(self, state):
        return self.feature_extractor.transform(self.scaler.transform(state.reshape(1, -1)))[0]
    
    def predict(self, state, action=None):
        features = self.featurize_state(state)
        if action is None:
            return np.array([self.models[a].predict(features.reshape(1, -1))[0] for a in range(self.n_actions)])
        else:
            return self.models[action].predict(features.reshape(1, -1))[0]
    
    def update(self, state, action, reward, next_state, done, gamma=1.0):
        target = reward
        if not done:
            target += gamma * np.max(self.predict(next_state))
        features = self.featurize_state(state)
        self.models[action].partial_fit(features.reshape(1, -1), np.array([target]))

# Epsilon-greedy policy
def make_epsilon_greedy_policy(estimator, epsilon, n_actions):
    def policy_fn(state):
        if np.random.rand() < epsilon:
            return np.random.choice(n_actions)
        else:
            q_vals = estimator.predict(state)
            return np.argmax(q_vals)
    return policy_fn

# Q-learning
def q_learning(estimator, policy, n_episodes, gamma=1.0):
    episode_rewards = []
    episode_lengths = []
    for i in range(n_episodes):
        state, _ = env.reset()
        done = False
        total_reward = 0.0
        steps = 0
        while not done:
            action = policy(state)
            next_state, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated
            estimator.update(state, action, reward, next_state, done, gamma)
            state = next_state
            total_reward += reward
            steps += 1
        episode_rewards.append(total_reward)
        episode_lengths.append(steps)
    return episode_rewards, episode_lengths

# Plotting functions
def plot_cost_to_go_mountain_car(estimator):
    pos = np.linspace(-1.2, 0.6, 101)
    vel = np.linspace(-0.07, 0.07, 101)
    X, Y = np.meshgrid(pos, vel)
    cost_to_go = np.zeros_like(X)
    for i in range(X.shape[0]):
        for j in range(X.shape[1]):
            state = np.array([X[i, j], Y[i, j]])
            cost_to_go[i, j] = -np.max(estimator.predict(state))
    plt.figure(figsize=(8, 6))
    plt.contourf(X, Y, cost_to_go, levels=50, cmap='viridis')
    plt.colorbar(label='Cost-to-Go')
    plt.xlabel('Position')
    plt.ylabel('Velocity')
    plt.title('Estimated Cost-to-Go for MountainCar')
    plt.show()

def plot_episode_stats(rewards, lengths):
    def moving_avg(x, window=10):
        return np.convolve(x, np.ones(window)/window, mode='valid')
    plt.figure(figsize=(12, 5))
    plt.subplot(1, 2, 1)
    plt.plot(moving_avg(rewards), label='Smoothed Reward')
    plt.xlabel('Episode')
    plt.ylabel('Reward')
    plt.title('Episode Reward')
    plt.legend()
    plt.subplot(1, 2, 2)
    plt.plot(moving_avg(lengths), label='Smoothed Length', color='orange')
    plt.xlabel('Episode')
    plt.ylabel('Length')
    plt.title('Episode Length')
    plt.legend()
    plt.tight_layout()
    plt.show()

# Training
estimator = Estimator(n_actions, scaler, rbf_features)
policy = make_epsilon_greedy_policy(estimator, epsilon=0.0, n_actions=n_actions)
rewards, lengths = q_learning(estimator, policy, n_episodes=100, gamma=1.0)

# Visualization
plot_cost_to_go_mountain_car(estimator)
plot_episode_stats(rewards, lengths)