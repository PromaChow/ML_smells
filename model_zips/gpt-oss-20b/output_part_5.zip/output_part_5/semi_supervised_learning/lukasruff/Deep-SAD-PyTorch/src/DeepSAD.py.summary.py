import json
import time
from pathlib import Path
from typing import Dict, List, Optional

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from sklearn.metrics import roc_auc_score


# -------------------------------------------------------------
# Helper functions and classes (minimal stubs for illustration)
# -------------------------------------------------------------

def build_network(net_name: str) -> nn.Module:
    """Return a simple neural network based on net_name."""
    if net_name == "MLP":
        return nn.Sequential(
            nn.Flatten(),
            nn.Linear(784, 256),
            nn.ReLU(),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
            nn.ReLU(),
        )
    elif net_name == "ResNet":
        # Simple residual block
        class ResidualBlock(nn.Module):
            def __init__(self):
                super().__init__()
                self.net = nn.Sequential(
                    nn.Conv2d(1, 32, 3, padding=1),
                    nn.ReLU(),
                    nn.Conv2d(32, 32, 3, padding=1),
                )

            def forward(self, x):
                return x + self.net(x)

        return nn.Sequential(
            ResidualBlock(),
            nn.Flatten(),
            nn.Linear(32 * 28 * 28, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
            nn.ReLU(),
        )
    else:
        raise ValueError(f"Unsupported net_name: {net_name}")


def build_autoencoder(net_name: str) -> nn.Module:
    """Return a simple autoencoder with encoder and decoder."""
    encoder = build_network(net_name)
    decoder = nn.Sequential(
        nn.Linear(64, 128),
        nn.ReLU(),
        nn.Linear(128, 784),
        nn.Sigmoid(),
    )
    class AutoEncoder(nn.Module):
        def __init__(self, encoder, decoder):
            super().__init__()
            self.encoder = encoder
            self.decoder = decoder

        def forward(self, x):
            z = self.encoder(x)
            recon = self.decoder(z)
            return recon

    return AutoEncoder(encoder, decoder)


class AETrainer:
    """Trainer for autoencoder."""
    def __init__(self, model: nn.Module, optimizer: optim.Optimizer,
                 epochs: int, device: torch.device):
        self.model = model.to(device)
        self.optimizer = optimizer
        self.criterion = nn.MSELoss()
        self.epochs = epochs
        self.device = device

    def fit(self, loader: DataLoader):
        self.model.train()
        for _ in range(self.epochs):
            for batch, _ in loader:
                batch = batch.to(self.device)
                recon = self.model(batch)
                loss = self.criterion(recon, batch)
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()

    def evaluate(self, loader: DataLoader) -> float:
        self.model.eval()
        losses = []
        with torch.no_grad():
            for batch, _ in loader:
                batch = batch.to(self.device)
                recon = self.model(batch)
                loss = self.criterion(recon, batch)
                losses.append(loss.item())
        return sum(losses) / len(losses)


class DeepSADTrainer:
    """Trainer for Deep SAD."""
    def __init__(self, model: nn.Module, optimizer: optim.Optimizer,
                 epochs: int, device: torch.device, eta: float):
        self.model = model.to(device)
        self.optimizer = optimizer
        self.epochs = epochs
        self.device = device
        self.eta = eta
        self.c = None  # hypersphere center

    def fit(self, loader: DataLoader, c: Optional[List[float]] = None):
        self.model.train()
        if c is None:
            # initialize center as mean of embeddings
            all_z = []
            with torch.no_grad():
                for batch, _ in loader:
                    batch = batch.to(self.device)
                    z = self.model(batch)
                    all_z.append(z)
            all_z = torch.cat(all_z, dim=0)
            c = all_z.mean(dim=0).cpu().numpy().tolist()
        self.c = c
        c_tensor = torch.tensor(c, device=self.device)
        for _ in range(self.epochs):
            for batch, _ in loader:
                batch = batch.to(self.device)
                z = self.model(batch)
                dist = torch.norm(z - c_tensor, dim=1)
                loss = torch.mean(dist**2)
                # add penalty for outliers
                loss += self.eta * torch.mean(torch.relu(dist - 1))
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()

    def evaluate(self, loader: DataLoader) -> Dict[str, float]:
        self.model.eval()
        scores = []
        with torch.no_grad():
            for batch, labels in loader:
                batch = batch.to(self.device)
                z = self.model(batch)
                dist = torch.norm(z - torch.tensor(self.c, device=self.device), dim=1)
                scores.append(dist.cpu().numpy())
        scores = np.concatenate(scores)
        # Assume labels are 0 for normal, 1 for anomaly
        auc = roc_auc_score([int(l.item()) for _, l in loader], scores)
        return {"auc": auc, "scores": scores.tolist()}


# -------------------------------------------------------------
# DeepSAD implementation
# -------------------------------------------------------------

class DeepSAD:
    def __init__(self, eta: float = 0.1, device: Optional[str] = None):
        self.eta = eta
        self.c: Optional[List[float]] = None
        self.net: Optional[nn.Module] = None
        self.deep_sad_trainer: Optional[DeepSADTrainer] = None
        self.ae_trainer: Optional[AETrainer] = None
        self.results: Dict[str, float] = {}
        self.ae_results: Dict[str, float] = {}
        self.device = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))

    def set_network(self, net_name: str):
        self.net = build_network(net_name).to(self.device)

    def pretrain(self,
                 train_loader: DataLoader,
                 epochs: int = 20,
                 lr: float = 1e-3,
                 batch_size: int = 64,
                 ae_net_name: str = "MLP"):
        ae_net = build_autoencoder(ae_net_name)
        optimizer = optim.Adam(ae_net.parameters(), lr=lr)
        self.ae_trainer = AETrainer(ae_net, optimizer, epochs, self.device)
        start = time.time()
        self.ae_trainer.fit(train_loader)
        train_time = time.time() - start
        test_loss = self.ae_trainer.evaluate(train_loader)
        self.ae_results.update({
            "pretrain_train_time": train_time,
            "pretrain_test_loss": test_loss,
        })
        # copy encoder weights to main network
        if self.net is None:
            self.set_network(ae_net_name)
        encoder_state = ae_net.encoder.state_dict()
        self.net.load_state_dict(encoder_state, strict=False)

    def train(self,
              train_loader: DataLoader,
              epochs: int = 30,
              lr: float = 1e-3):
        optimizer = optim.Adam(self.net.parameters(), lr=lr)
        self.deep_sad_trainer = DeepSADTrainer(
            self.net, optimizer, epochs, self.device, self.eta
        )
        start = time.time()
        self.deep_sad_trainer.fit(train_loader, self.c)
        train_time = time.time() - start
        self.c = self.deep_sad_trainer.c
        self.results.update({
            "deep_sad_train_time": train_time,
            "center": self.c,
        })

    def test(self, test_loader: DataLoader):
        if self.deep_sad_trainer is None:
            optimizer = optim.Adam(self.net.parameters(), lr=1e-3)
            self.deep_sad_trainer = DeepSADTrainer(
                self.net, optimizer, 0, self.device, self.eta
            )
        start = time.time()
        metrics = self.deep_sad_trainer.evaluate(test_loader)
        test_time = time.time() - start
        self.results.update({
            "deep_sad_test_time": test_time,
            "deep_sad_auc": metrics["auc"],
            "deep_sad_scores": metrics["scores"],
        })

    def save_model(self, path: str, include_ae: bool = False):
        state = {
            "net_state": self.net.state_dict() if self.net else None,
            "center": self.c,
        }
        if include_ae and self.ae_trainer:
            state["ae_state"] = self.ae_trainer.model.state_dict()
        torch.save(state, Path(path))

    def load_model(self, path: str, include_ae: bool = False):
        state = torch.load(Path(path), map_location=self.device)
        if self.net and state["net_state"]:
            self.net.load_state_dict(state["net_state"])
        self.c = state["center"]
        if include_ae and self.ae_trainer and state.get("ae_state"):
            self.ae_trainer.model.load_state_dict(state["ae_state"])

    def save_results(self, path: str):
        with open(path, "w") as f:
            json.dump(self.results, f, indent=4)

    def save_ae_results(self, path: str):
        with open(path, "w") as f:
            json.dump(self.ae_results, f, indent=4)