import gym
import torch
import torch.nn as nn
import torch.optim as optim
from machin.agent.dqn import DQN

class QNet(nn.Module):
    def __init__(self, input_dim: int, output_dim: int):
        super(QNet, self).__init__()
        self.fc1 = nn.Linear(input_dim, 16)
        self.fc2 = nn.Linear(16, 16)
        self.out = nn.Linear(16, output_dim)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return self.out(x)

def main():
    env = gym.make("CartPole-v0")
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.n

    qnet = QNet(state_dim, action_dim)
    target_net = QNet(state_dim, action_dim)
    target_net.load_state_dict(qnet.state_dict())

    optimizer = optim.Adam(qnet.parameters(), lr=1e-3)
    loss_fn = nn.MSELoss()

    agent = DQN(
        state_dim,
        action_dim,
        qnet,
        target_net,
        optimizer,
        loss_fn,
        device=torch.device("cpu"),
        gamma=0.99,
        replay_buffer_size=100000,
    )

    max_episodes = 1000
    max_steps = 200
    reward_threshold = 190
    smoothed_reward = 0.0
    alpha = 0.9
    consecutive_success = 0

    for episode in range(1, max_episodes + 1):
        state = env.reset()
        state_tensor = torch.tensor(state, dtype=torch.float32)
        episode_experiences = []
        total_reward = 0.0

        for step in range(max_steps):
            action = agent.act_discrete_with_noise(state_tensor, noise=True)
            next_state, reward, done, _ = env.step(action)
            next_state_tensor = torch.tensor(next_state, dtype=torch.float32)
            episode_experiences.append((state_tensor, action, reward, next_state_tensor, done))
            total_reward += reward

            if done:
                break

            state_tensor = next_state_tensor

        for exp in episode_experiences:
            agent.store_experience(*exp)

        if episode > 100:
            for _ in range(len(episode_experiences)):
                agent.step()

        smoothed_reward = alpha * smoothed_reward + (1 - alpha) * total_reward

        print(f"Episode {episode}\tReward: {total_reward:.2f}\tSmoothed: {smoothed_reward:.2f}")

        if smoothed_reward > reward_threshold:
            consecutive_success += 1
            if consecutive_success >= 5:
                print(f"Environment solved after {episode} episodes with smoothed reward {smoothed_reward:.2f}!")
                break
        else:
            consecutive_success = 0

    env.close()

if __name__ == "__main__":
    main()
