import numpy as np
from collections import deque
from time import perf_counter


class VecMonitor:
    def __init__(self, env, deque_size=100):
        """
        Wraps a vectorized environment to monitor episode statistics.

        Parameters
        ----------
        env : gym.vector.VectorEnv or similar
            The vectorized environment to wrap.
        deque_size : int, optional
            Maximum length of the deques storing recent episode returns
            and horizons. Default is 100.
        """
        self.env = env
        self.t0 = perf_counter()

        # Determine the number of environments in the vector
        if hasattr(env, "num_envs"):
            self.n_envs = env.num_envs
        elif hasattr(env, "num_envs"):
            self.n_envs = env.num_envs
        elif hasattr(env, "envs"):
            self.n_envs = len(env.envs)
        else:
            # Fallback for single env
            self.n_envs = 1

        self.episode_rewards = np.zeros(self.n_envs, dtype=np.float64)
        self.episode_horizons = np.zeros(self.n_envs, dtype=np.int32)

        self.return_queue = deque(maxlen=deque_size)
        self.horizon_queue = deque(maxlen=deque_size)

    def step(self, actions):
        """
        Advance all environments in the vector.

        Parameters
        ----------
        actions : array-like
            Actions for each environment in the vector.

        Returns
        -------
        tuple
            Observations, rewards, dones, and infos from the underlying env.
        """
        obs, rewards, dones, infos = self.env.step(actions)

        # Update cumulative rewards and horizons
        self.episode_rewards += np.asarray(rewards, dtype=np.float64)
        self.episode_horizons += 1

        # Process finished episodes
        for idx, done in enumerate(dones):
            if done:
                elapsed = round(perf_counter() - self.t0, 4)
                episode_stats = {
                    "return": float(self.episode_rewards[idx]),
                    "horizon": int(self.episode_horizons[idx]),
                    "time": elapsed,
                }
                if isinstance(infos, list):
                    infos[idx].update(episode_stats)
                else:
                    # If infos is a dict of arrays, fall back to storing in a separate dict
                    if "episode" not in infos:
                        infos["episode"] = {}
                    infos["episode"][idx] = episode_stats

                self.return_queue.append(float(self.episode_rewards[idx]))
                self.horizon_queue.append(int(self.episode_horizons[idx]))

                # Reset counters for the finished environment
                self.episode_rewards[idx] = 0.0
                self.episode_horizons[idx] = 0

        return obs, rewards, dones, infos

    def reset(self, **kwargs):
        """
        Reset all environments in the vector.

        Returns
        -------
        observations : array-like
            Initial observations from the underlying env.
        """
        obs = self.env.reset(**kwargs)
        self.episode_rewards.fill(0.0)
        self.episode_horizons.fill(0)
        return obs

    def close(self):
        """
        Close the underlying environment.
        """
        if hasattr(self.env, "close"):
            self.env.close()

    def get_recent_returns(self):
        """
        Return a list of recent episode returns.
        """
        return list(self.return_queue)

    def get_recent_horizons(self):
        """
        Return a list of recent episode horizons.
        """
        return list(self.horizon_queue)