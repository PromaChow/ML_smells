import os
import urllib.request
import numpy as np
import pandas as pd
import torch
from pathlib import Path

class DataBasedBandit:
    def __init__(self, device: str = "cpu"):
        self.device = torch.device(device)

    def reset(self):
        raise NotImplementedError

    def step(self, action: int):
        raise NotImplementedError

    def _compute_reward(self, action: int):
        raise NotImplementedError

    def _get_context(self):
        raise NotImplementedError


class MushroomDataBandit(DataBasedBandit):
    DEFAULT_URL = "https://archive.ics.uci.edu/ml/machine-learning-databases/mushroom/agaricus-lepiota.data"

    def __init__(
        self,
        data_path: str = "mushroom_data.csv",
        download: bool = True,
        url: str = None,
        r_pass: float = 0.0,
        r_edible: float = 5.0,
        r_poisonous_lucky: float = 5.0,
        r_poisonous_unlucky: float = -35.0,
        lucky_prob: float = 0.5,
        device: str = "cpu",
    ):
        super().__init__(device)
        self.data_path = Path(data_path)
        self.download_flag = download
        self.url = url or self.DEFAULT_URL
        self.r_pass = r_pass
        self.r_edible = r_edible
        self.r_poisonous_lucky = r_poisonous_lucky
        self.r_poisonous_unlucky = r_poisonous_unlucky
        self.lucky_prob = lucky_prob
        self.expected_poisonous_reward = (
            lucky_prob * r_poisonous_lucky + (1 - lucky_prob) * r_poisonous_unlucky
        )
        self._load_and_prepare_data()
        self.reset()

    def _load_and_prepare_data(self):
        if self.download_flag:
            if not self.data_path.exists():
                print(f"Downloading dataset to {self.data_path}...")
                urllib.request.urlretrieve(self.url, str(self.data_path))
        if not self.data_path.exists():
            raise FileNotFoundError(f"Dataset not found at {self.data_path}")
        df_raw = pd.read_csv(self.data_path, header=None)
        df_raw.rename(columns={i: f"col_{i}" for i in df_raw.columns}, inplace=True)
        # Map edible ('e') to 1, poisonous ('p') to 0
        df_raw["edible"] = df_raw["col_0"].map({"e": 1, "p": 0})
        df_raw.drop(columns=["col_0"], inplace=True)
        # One-hot encode remaining columns
        df_dummies = pd.get_dummies(df_raw.drop(columns=["edible"]), prefix=df_raw.columns[:-1])
        self.df = pd.concat([df_raw[["edible"]], df_dummies], axis=1)

    def reset(self):
        self.df = self.df.sample(frac=1).reset_index(drop=True)
        n = len(self.df)
        poisonous_indicator = 1 - self.df["edible"]
        poison_rewards = np.random.choice(
            [self.r_poisonous_lucky, self.r_poisonous_unlucky],
            size=n,
            p=[self.lucky_prob, 1 - self.lucky_prob],
        )
        self.eat_rewards = self.df["edible"].values * self.r_edible + poisonous_indicator * poison_rewards
        self.optimal_expected_rewards = np.maximum(self.r_pass, self.expected_poisonous_reward)
        self.optimal_actions = np.where(self.r_pass > self.expected_poisonous_reward, 1, 0)
        self.current_index = 0
        return self._get_context()

    def step(self, action: int):
        reward = self._compute_reward(action)
        optimal_reward = self.optimal_expected_rewards[self.current_index]
        context = self._get_context()
        done = self.current_index == len(self.df) - 1
        self.current_index += 1
        return reward, context, done, optimal_reward

    def _compute_reward(self, action: int):
        if action == 0:
            return self.r_pass
        return self.eat_rewards[self.current_index]

    def _get_context(self):
        context_df = self.df.drop(columns=["edible"])
        context_tensor = torch.tensor(context_df.values, dtype=torch.float32, device=self.device)
        return context_tensor[self.current_index]
