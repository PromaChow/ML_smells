import json
import time
import numpy as np
from sklearn.svm import OneClassSVM, SVC
from sklearn.metrics import roc_auc_score
from sklearn.metrics.pairwise import rbf_kernel, linear_kernel
import torch
from torch.utils.data import DataLoader, TensorDataset


def load_ae(dataset_name: str, model_name: str, weights_path: str):
    """
    Load an autoencoder model. For demonstration purposes this returns
    a simple identity encoder.
    """
    class IdentityAE(torch.nn.Module):
        def __init__(self):
            super().__init__()

        def encode(self, x):
            return x

    return IdentityAE()


def save_results(results: dict, filepath: str):
    with open(filepath, "w") as f:
        json.dump(results, f, indent=2)


class SSAD:
    def __init__(
        self,
        kernel: str = "rbf",
        Cp: float = 1.0,
        Cu: float = 1.0,
        Cn: float = 1.0,
        hybrid: bool = False,
    ):
        self.kernel = kernel
        self.Cp = Cp
        self.Cu = Cu
        self.Cn = Cn
        self.hybrid = hybrid
        self.model = None
        self.linear_model = None
        self.support_vectors = None
        self.linear_support_vectors = None
        self.results = {}

    def _prepare_features(self, loader: DataLoader, use_ae: bool = False):
        features = []
        labels = []
        if use_ae:
            ae = load_ae("placeholder", "placeholder", "placeholder")
            ae.eval()
            with torch.no_grad():
                for batch, target in loader:
                    batch = batch.to(torch.float32)
                    feat = ae.encode(batch)
                    features.append(feat.cpu().numpy())
                    labels.append(target.numpy())
        else:
            for batch, target in loader:
                batch = batch.to(torch.float32)
                features.append(batch.cpu().numpy())
                labels.append(target.numpy())
        X = np.vstack(features)
        y = np.concatenate(labels)
        return X, y

    def _hyperparameter_search(self, X_train, y_train, X_val, y_val):
        best_auc = -np.inf
        best_gamma = None
        best_model = None
        gamma_grid = np.logspace(-7, 2, 10)
        for gamma in gamma_grid:
            model = OneClassSVM(kernel="rbf", gamma=gamma, nu=0.5)
            model.fit(X_train)
            preds = model.decision_function(X_val)
            auc = roc_auc_score(y_val, preds)
            if auc > best_auc:
                best_auc = auc
                best_gamma = gamma
                best_model = model
        return best_model, best_auc, best_gamma

    def train(self, train_loader: DataLoader, val_loader: DataLoader):
        start_time = time.time()
        X_train, y_train = self._prepare_features(train_loader, use_ae=self.hybrid)
        X_val, y_val = self._prepare_features(val_loader, use_ae=self.hybrid)

        self.model, val_auc, best_gamma = self._hyperparameter_search(
            X_train, y_train, X_val, y_val
        )
        self.support_vectors = self.model.support_vectors_
        self.results["best_gamma"] = best_gamma
        self.results["val_auc"] = val_auc

        if self.hybrid:
            linear_model = SVC(kernel="linear", probability=True, C=1.0)
            linear_model.fit(X_train, y_train)
            self.linear_model = linear_model
            self.linear_support_vectors = linear_model.support_vectors_

        self.results["train_time"] = time.time() - start_time

    def test(self, test_loader: DataLoader):
        start_time = time.time()
        X_test, y_test = self._prepare_features(test_loader, use_ae=self.hybrid)

        # Kernel evaluation for main model
        if self.kernel == "rbf":
            K_test = rbf_kernel(X_test, self.support_vectors)
            scores = np.sum(K_test * self.model.dual_coef_, axis=1) + self.model.intercept_
        else:
            K_test = linear_kernel(X_test, self.support_vectors)
            scores = np.sum(K_test * self.model.dual_coef_, axis=1) + self.model.intercept_

        auc_main = roc_auc_score(y_test, scores)
        self.results["test_auc_main"] = auc_main
        self.results["test_scores_main"] = scores.tolist()

        if self.hybrid and self.linear_model is not None:
            linear_scores = self.linear_model.decision_function(X_test)
            auc_linear = roc_auc_score(y_test, linear_scores)
            self.results["test_auc_linear"] = auc_linear
            self.results["test_scores_linear"] = linear_scores.tolist()

        self.results["test_time"] = time.time() - start_time


# Example usage (requires a real dataset and labels)
if __name__ == "__main__":
    # Dummy data for demonstration
    X = torch.randn(500, 20)
    y = torch.randint(0, 2, (500,)) * 2 - 1  # -1 or 1
    dataset = TensorDataset(X, y)
    train_loader = DataLoader(dataset, batch_size=128, shuffle=True, drop_last=False)

    # For validation and test we use the same data here
    val_loader = DataLoader(dataset, batch_size=128, shuffle=False, drop_last=False)
    test_loader = DataLoader(dataset, batch_size=128, shuffle=False, drop_last=False)

    ssad = SSAD(kernel="rbf", hybrid=True)
    ssad.train(train_loader, val_loader)
    ssad.test(test_loader)

    save_results(ssad.results, "ssad_results.json")
    print(json.dumps(ssad.results, indent=2))