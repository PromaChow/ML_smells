import numpy as np
import random
from dataclasses import dataclass, field
from typing import List, Optional

# ---------- Entity Definitions ----------

@dataclass
class Landmark:
    name: str
    movable: bool = False
    collides: bool = False
    color: np.ndarray = field(default_factory=lambda: np.array([1.0, 1.0, 1.0]))
    p_pos: np.ndarray = field(default_factory=lambda: np.zeros(2))
    p_vel: np.ndarray = field(default_factory=lambda: np.zeros(2))

@dataclass
class Agent:
    name: str
    movable: bool = True
    silent: bool = False
    collides: bool = True
    size: float = 0.1
    goal: Optional[object] = None  # can be Agent or Landmark
    p_pos: np.ndarray = field(default_factory=lambda: np.zeros(2))
    p_vel: np.ndarray = field(default_factory=lambda: np.zeros(2))
    c: np.ndarray = field(default_factory=lambda: np.zeros(3))
    color: np.ndarray = field(default_factory=lambda: np.array([0.5, 0.5, 0.5]))

# ---------- World Definition ----------

class World:
    def __init__(self):
        self.dim_c: int = 3
        self.collaborative: bool = True
        self.agents: List[Agent] = []
        self.landmarks: List[Landmark] = []
        self._init_world()

    def _init_world(self):
        # Create landmarks
        colors = {
            "red": np.array([1.0, 0.0, 0.0]),
            "green": np.array([0.0, 1.0, 0.0]),
            "blue": np.array([0.0, 0.0, 1.0]),
        }
        for i, (name, color) in enumerate(colors.items()):
            lm = Landmark(name=name, color=color)
            self.landmarks.append(lm)

        # Create agents
        speaker = Agent(name="speaker", movable=False, collides=False, size=0.075)
        listener = Agent(name="listener", silent=True, collides=False, size=0.075)
        self.agents.extend([speaker, listener])

    def reset(self):
        # Goal Assignment
        self.agents[0].goal = self.agents[1]  # Speaker's goal is listener
        self.agents[1].goal = random.choice(self.landmarks)  # Listener's goal is a landmark

        # Color Initialization
        base_color = np.array([0.5, 0.5, 0.5])
        for agent in self.agents:
            agent.color = base_color.copy()
        for lm in self.landmarks:
            lm.color = base_color.copy()
        # Modify goal landmark color
        goal_lm = self.agents[1].goal
        goal_lm.color = np.clip(goal_lm.color + 0.45, 0.0, 1.0)

        # Position Initialization
        for agent in self.agents:
            agent.p_pos = np.random.uniform(-1, 1, size=2)
            agent.p_vel = np.zeros(2)
            agent.c = np.zeros(self.dim_c)
        for lm in self.landmarks:
            lm.p_pos = np.random.uniform(-1, 1, size=2)
            lm.p_vel = np.zeros(2)

    def reward(self, agent: Agent) -> float:
        if agent.name != "listener":
            return 0.0
        goal_lm = agent.goal
        diff = agent.p_pos - goal_lm.p_pos
        return -np.sum(diff ** 2)

    def observation(self, agent: Agent) -> np.ndarray:
        if agent.name == "speaker":
            # Speaker observes only goal color
            return agent.goal.color
        elif agent.name == "listener":
            # Listener observes own velocity
            obs = [agent.p_vel]
            # Relative positions of all landmarks
            for lm in self.landmarks:
                obs.append(lm.p_pos - agent.p_pos)
            # Communication states from other agents
            for other in self.agents:
                if other is not agent:
                    obs.append(other.c)
            return np.concatenate(obs)
        else:
            return np.array([])

# ---------- Example Usage ----------

if __name__ == "__main__":
    world = World()
    world.reset()
    for agent in world.agents:
        obs = world.observation(agent)
        rew = world.reward(agent)
        print(f"Agent: {agent.name}")
        print(f"  Observation: {obs}")
        print(f"  Reward: {rew}")
        print()
