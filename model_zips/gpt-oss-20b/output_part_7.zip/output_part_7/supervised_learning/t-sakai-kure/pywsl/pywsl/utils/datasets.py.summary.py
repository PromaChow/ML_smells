import numpy as np
from sklearn.datasets import fetch_openml

def split_size(total, prior):
    """Return number of samples to take using a binomial distribution."""
    return np.random.binomial(total, prior)

def prepare_mnist_splits(
    n_p,
    n_n,
    prior,
    n_vp=None,
    n_vn=None,
    n_vu=None,
    n_t=0,
    data_name="mnist",
):
    # 1. Load and preprocess
    X, y = fetch_openml(name=data_name, version=1, return_X_y=True, as_frame=False)
    X = X.astype(np.float32) / 255.0
    y = y.astype(int)

    # Binarize labels: even -> -1, odd -> +1
    y_bin = np.where(y % 2 == 0, -1, 1)

    # Separate positive and negative data
    pos_indices = np.where(y_bin == 1)[0]
    neg_indices = np.where(y_bin == -1)[0]

    data_p = X[pos_indices]
    data_n = X[neg_indices]
    labels_p = y_bin[pos_indices]
    labels_n = y_bin[neg_indices]

    # 3. Unlabeled data splitting (prior applied to remaining data)
    # 4. Subset creation
    # Helper to split a dataset into two parts
    def split_subset(data, labels, n):
        perm = np.random.permutation(len(data))
        idx_l = perm[:n]
        idx_rem = perm[n:]
        return data[idx_l], labels[idx_l], data[idx_rem], labels[idx_rem]

    # Labeled subsets
    x_l_p, y_l_p, data_p, _ = split_subset(data_p, labels_p, n_p)
    x_l_n, y_l_n, data_n, _ = split_subset(data_n, labels_n, n_n)
    x_l = np.concatenate([x_l_p, x_l_n], axis=0)
    y_l = np.concatenate([y_l_p, y_l_n], axis=0)

    # Unlabeled subsets
    n_u_pos = split_size(len(data_p), prior)
    n_u_neg = split_size(len(data_n), prior)
    x_u_p, y_u_p, data_p, _ = split_subset(data_p, np.ones(len(data_p)), n_u_pos)
    x_u_n, y_u_n, data_n, _ = split_subset(data_n, -np.ones(len(data_n)), n_u_neg)
    x_u = np.concatenate([x_u_p, x_u_n], axis=0)
    y_u = np.concatenate([y_u_p, y_u_n], axis=0)

    # Validation labeled subsets if requested
    x_vp = x_vn = None
    if n_vp is not None and n_vn is not None:
        x_vp, _, data_p, _ = split_subset(data_p, np.ones(len(data_p)), n_vp)
        x_vn, _, data_n, _ = split_subset(data_n, -np.ones(len(data_n)), n_vn)

    # Validation unlabeled subset if requested
    x_vu = y_vu = None
    if n_vu is not None:
        n_vu_pos = split_size(len(data_p), prior)
        n_vu_neg = split_size(len(data_n), prior)
        x_vu_p, y_vu_p, data_p, _ = split_subset(data_p, np.ones(len(data_p)), n_vu_pos)
        x_vu_n, y_vu_n, data_n, _ = split_subset(data_n, -np.ones(len(data_n)), n_vu_neg)
        x_vu = np.concatenate([x_vu_p, x_vu_n], axis=0)
        y_vu = np.concatenate([y_vu_p, y_vu_n], axis=0)

    # Test subsets
    x_t_p, _, data_p, _ = split_subset(data_p, np.ones(len(data_p)), n_t)
    x_t_n, _, data_n, _ = split_subset(data_n, -np.ones(len(data_n)), n_t)
    x_t = np.concatenate([x_t_p, x_t_n], axis=0)
    y_t = np.concatenate([np.ones(n_t), -np.ones(n_t)], axis=0)

    # Final split of labeled data into positives and negatives
    pos_mask = y_l == 1
    x_p = x_l[pos_mask]
    x_n = x_l[~pos_mask]

    # Build result dictionary
    result = {
        "data_name": data_name,
        "x_p": x_p,
        "x_n": x_n,
        "x_u": x_u,
        "y_u": y_u,
        "x_t": x_t,
        "y_t": y_t,
    }
    if x_vp is not None:
        result["x_vp"] = x_vp
    if x_vn is not None:
        result["x_vn"] = x_vn
    if x_vu is not None:
        result["x_vu"] = x_vu
    if y_vu is not None:
        result["y_vu"] = y_vu

    return result

# Example usage:
# splits = prepare_mnist_splits(n_p=500, n_n=500, prior=0.1, n_vp=100, n_vn=100, n_vu=200, n_t=300)
# print(splits.keys())
