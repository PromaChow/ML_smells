import numpy as np
from resnet import ResNet
from shaknet import ShakeNet
from cnn13 import CNN13

def gen_model(name, num_classes, img_size):
    scale = int(np.ceil(np.log2(img_size)))
    if name == "wrn":
        model = ResNet(num_classes=num_classes, in_channels=32, scale=scale, depth_multiplier=4)
    elif name == "shake":
        model = ShakeNet(num_classes=num_classes, in_channels=32, scale=scale, depth_multiplier=4)
    elif name == "cnn13":
        model = CNN13(num_classes=num_classes, in_channels=32)
    else:
        raise NotImplementedError(f"Model '{name}' is not supported.")
    return model