import numpy as np
import matplotlib.pyplot as plt
from scipy.io import loadmat
import soinn

# Load data from MATLAB file
data = loadmat('train.mat')
if 'train' not in data:
    raise KeyError("The key 'train' was not found in 'train.mat'.")
train = data['train']
print(f"Shape of train data: {train.shape}")

# Set up 1x2 subplot grid
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 6))

# Plot original data
ax1.scatter(train[:, 0], train[:, 1], s=10, color='blue')
ax1.set_title('origin data')
ax1.set_xlabel('Feature 1')
ax1.set_ylabel('Feature 2')

# Apply SOINN clustering algorithm
clus = soinn.learn(train)
print(f"Shape of learned centroids: {clus.shape}")

# Plot learned centroids
ax2.scatter(clus[:, 0], clus[:, 1], s=10, color='red')
ax2.set_title('learned centroids')
ax2.set_xlabel('Centroid Feature 1')
ax2.set_ylabel('Centroid Feature 2')

plt.tight_layout()
plt.show()
