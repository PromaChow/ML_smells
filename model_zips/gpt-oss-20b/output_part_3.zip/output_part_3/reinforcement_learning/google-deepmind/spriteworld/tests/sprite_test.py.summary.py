import pytest
import numpy as np
from spriteworld import Sprite

def clamp(val: float, min_val: float = 0.0, max_val: float = 1.0) -> float:
    return max(min_val, min(max_val, val))

@pytest.fixture
def sprite():
    """Return a Sprite with standard initialization."""
    return Sprite(
        x=0.2,
        y=0.8,
        shape="triangle",
        angle=45,
        scale=0.3,
        c0=200,
        c1=150,
        c2=100,
        x_vel=-0.2,
        y_vel=0.1,
    )

def test_basic_initialization(sprite: Sprite):
    assert pytest.approx(sprite.x, 1e-6) == 0.2
    assert pytest.approx(sprite.y, 1e-6) == 0.8
    assert sprite.shape == "triangle"
    assert pytest.approx(sprite.angle, 1e-6) == 45
    assert pytest.approx(sprite.scale, 1e-6) == 0.3
    assert sprite.c0 == 200
    assert sprite.c1 == 150
    assert sprite.c2 == 100
    assert pytest.approx(sprite.x_vel, 1e-6) == -0.2
    assert pytest.approx(sprite.y_vel, 1e-6) == 0.1

@pytest.mark.parametrize(
    "start_x,start_y,dx,dy,keep_in_frame,expected_x,expected_y",
    [
        (0.2, 0.8, 0.1, -0.3, True, 0.3, 0.5),
        (0.9, 0.9, 0.2, 0.2, True, 1.0, 1.0),
        (0.1, 0.1, -0.2, -0.2, True, 0.0, 0.0),
        (0.5, 0.5, -0.3, 0.4, False, 0.2, 0.9),
    ],
)
def test_move(
    start_x: float,
    start_y: float,
    dx: float,
    dy: float,
    keep_in_frame: bool,
    expected_x: float,
    expected_y: float,
):
    s = Sprite(
        x=start_x,
        y=start_y,
        shape="square",
        angle=0,
        scale=0.5,
        c0=0,
        c1=0,
        c2=0,
        x_vel=0,
        y_vel=0,
    )
    s.move(dx, dy, keep_in_frame=keep_in_frame)
    assert pytest.approx(s.x, 1e-6) == expected_x
    assert pytest.approx(s.y, 1e-6) == expected_y

def test_contains_point(sprite: Sprite):
    grid = np.linspace(0.1, 0.9, 4)
    xv, yv = np.meshgrid(grid, grid, indexing="ij")
    contains_matrix = np.vectorize(lambda x, y: sprite.contains_point(x, y))(xv, yv)
    assert contains_matrix.shape == (4, 4)
    # The sprite's own center should be inside
    assert sprite.contains_point(sprite.x, sprite.y) is True
    # A point far outside should be outside
    assert sprite.contains_point(-0.5, 1.5) is False

def test_sample_contained_position(sprite: Sprite):
    for _ in range(5):
        x, y = sprite.sample_contained_position()
        assert sprite.contains_point(x, y) is True

def test_shape_reset():
    s = Sprite(
        x=0.0,
        y=0.0,
        shape="square",
        angle=0,
        scale=0.25,
        c0=0,
        c1=0,
        c2=0,
        x_vel=0,
        y_vel=0,
    )
    old_vertices = s.vertices.copy()
    s.set_shape("triangle")
    s.update_geometry()
    assert not np.allclose(old_vertices, s.vertices)

def test_angle_reset():
    s = Sprite(
        x=0.0,
        y=0.0,
        shape="square",
        angle=0,
        scale=0.25,
        c0=0,
        c1=0,
        c2=0,
        x_vel=0,
        y_vel=0,
    )
    old_vertices = s.vertices.copy()
    s.angle = -45
    s.update_geometry()
    assert not np.allclose(old_vertices, s.vertices)

def test_scale_reset():
    s = Sprite(
        x=0.0,
        y=0.0,
        shape="square",
        angle=0,
        scale=0.25,
        c0=0,
        c1=0,
        c2=0,
        x_vel=0,
        y_vel=0,
    )
    old_vertices = s.vertices.copy()
    s.scale = 0.5
    s.update_geometry()
    assert not np.allclose(old_vertices, s.vertices)