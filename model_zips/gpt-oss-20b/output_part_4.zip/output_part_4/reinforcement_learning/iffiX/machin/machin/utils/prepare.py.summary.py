import os
import shutil
import re
import logging
from typing import Iterable, Dict, Optional

import torch
import torch.nn as nn

logger = logging.getLogger(__name__)


def prep_clear_dirs(dirs: Iterable[str]) -> None:
    """Delete all contents of the given directories."""
    for dir_path in dirs:
        if not os.path.isdir(dir_path):
            continue
        for entry in os.listdir(dir_path):
            full_path = os.path.join(dir_path, entry)
            try:
                if os.path.isfile(full_path) or os.path.islink(full_path):
                    os.unlink(full_path)
                elif os.path.isdir(full_path):
                    shutil.rmtree(full_path)
            except Exception as exc:
                logger.warning("Failed to delete %s: %s", full_path, exc)


def prep_create_dirs(dirs: Iterable[str]) -> None:
    """Create directories if they do not exist."""
    for dir_path in dirs:
        if not os.path.exists(dir_path):
            os.makedirs(dir_path, exist_ok=True)


def prep_load_state_dict(model: nn.Module, state_dict: Dict[str, torch.Tensor]) -> None:
    """Load a state_dict into a model, moving tensors to the model's device."""
    for name, param in model.named_parameters():
        if name in state_dict:
            state_dict[name] = state_dict[name].to(param.device)
    model.load_state_dict(state_dict, strict=True)


def prep_load_model(
    model_dir: str,
    model_map: Dict[str, nn.Module],
    version: Optional[int] = None,
    quiet: bool = False,
) -> None:
    """Load models from files in model_dir, selecting by version."""
    if not os.path.isdir(model_dir):
        raise FileNotFoundError(f"Model directory {model_dir!r} does not exist or is not a directory.")

    version_pattern = re.compile(r"(?P<name>.+)_(?P<ver>\d+)\.pt$")

    version_map: Dict[str, set[int]] = {name: set() for name in model_map}
    for fname in os.listdir(model_dir):
        match = version_pattern.match(fname)
        if match:
            name, ver = match.group("name"), int(match.group("ver"))
            if name in version_map:
                version_map[name].add(ver)

    if version is not None:
        missing = [name for name, vers in version_map.items() if version not in vers]
        if missing:
            for name in missing:
                logger.warning("Model %s does not have version %d", name, version)
            if quiet:
                return
        for name, mod in model_map.items():
            file_path = os.path.join(model_dir, f"{name}_{version}.pt")
            if not os.path.isfile(file_path):
                raise FileNotFoundError(f"Missing file for model {name} at {file_path!r}")
            state = torch.load(file_path, map_location="cpu")
            prep_load_state_dict(mod, state)
        logger.info("Loaded models from version %d", version)
    else:
        common_versions = set.intersection(*[vers for vers in version_map.values() if vers])
        if not common_versions:
            if quiet:
                return
            raise RuntimeError("No common model versions found across all models.")
        chosen_version = max(common_versions)
        for name, mod in model_map.items():
            file_path = os.path.join(model_dir, f"{name}_{chosen_version}.pt")
            if not os.path.isfile(file_path):
                raise FileNotFoundError(f"Missing file for model {name} at {file_path!r}")
            state = torch.load(file_path, map_location="cpu")
            prep_load_state_dict(mod, state)
        logger.info("Loaded models from latest common version %d", chosen_version)