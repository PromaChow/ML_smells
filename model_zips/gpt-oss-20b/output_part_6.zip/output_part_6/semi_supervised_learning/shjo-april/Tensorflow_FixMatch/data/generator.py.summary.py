import threading
import numpy as np
import tensorflow as tf

class Generator(threading.Thread):
    def __init__(self, option):
        super().__init__()
        self.labeled_loader = option['labeled_batch_loader']
        self.unlabeled_loader = option['unlabeled_batch_loader']
        self.placeholders = option['placeholders']
        self.queue_size = option['queue_size']

        placeholder_values = list(self.placeholders.values())
        dtypes = tuple(ph.dtype for ph in placeholder_values)
        shapes = tuple(ph.shape for ph in placeholder_values)

        self.queue = tf.FIFOQueue(
            capacity=self.queue_size,
            dtypes=dtypes,
            shapes=shapes
        )
        self.enqueue_op = self.queue.enqueue
        self.close_op = self.queue.close(cancel_pending_enqueues=False)

        self.sess = None
        self.coord = None

    def set_session(self, sess):
        self.sess = sess

    def set_coordinator(self, coord):
        self.coord = coord

    def run(self):
        if self.sess is None or self.coord is None:
            raise RuntimeError("Session or coordinator not set before starting thread.")
        try:
            while not self.coord.should_stop():
                try:
                    labeled_batch = self.labeled_loader.main_queue.get()
                    unlabeled_batch = self.unlabeled_loader.main_queue.get()
                except Exception as e:
                    print(f"Error fetching batches: {e}")
                    break

                feed_dict = {}
                for name, placeholder in self.placeholders.items():
                    try:
                        labeled = labeled_batch[name]
                        unlabeled = unlabeled_batch[name]
                    except KeyError:
                        continue
                    concatenated = np.concatenate([labeled, unlabeled], axis=0)
                    feed_dict[placeholder] = concatenated

                try:
                    self.sess.run(self.enqueue_op, feed_dict=feed_dict)
                except tf.errors.CancelledError:
                    print("Queue cancelled.")
                    break
                except tf.errors.OutOfRangeError:
                    print("No more data.")
                    break
                except Exception as e:
                    print(f"Error during enqueue: {e}")
                    break
        except Exception as e:
            print(f"Unhandled exception in Generator thread: {e}")
        finally:
            try:
                self.sess.run(self.close_op)
            except Exception:
                pass

    def dequeue(self):
        return self.queue.dequeue()