import numpy as np


class BaseBulletEnv:
    def __init__(self, scene, max_steps=0):
        self.scene = scene
        self.max_steps = max_steps


class Thrower:
    def __init__(self):
        self.joint_positions = np.zeros(6)
        self.joint_velocities = np.zeros(6)
        self.state = np.zeros(10)
        self.to_target_vec = np.zeros(3)
        self.object_position = np.zeros(3)
        self.object_impact_position = np.zeros(3)
        self.target_position = np.array([0.0, 0.0, 0.0])
        self._object_hit_ground = False
        self.fingertip_position = np.array([0.0, 0.0, 0.0])

    def apply_action(self, a):
        self.joint_positions += a
        self.joint_velocities = a

    def calc_state(self):
        self.state = np.concatenate([self.joint_positions, self.joint_velocities])
        self.to_target_vec = self.target_position - self.object_position

    def calc_potential(self):
        return np.sum(self.joint_positions ** 2)


class SingleRobotEmptyScene:
    def __init__(self, gravity, dt, frame_skip):
        self.gravity = gravity
        self.dt = dt
        self.frame_skip = frame_skip

    def global_step(self):
        pass

    def set_camera(self, pos):
        pass


class ThrowerBulletEnv(BaseBulletEnv):
    def __init__(self):
        self.robot = Thrower()
        scene = self.create_single_player_scene()
        super().__init__(scene, max_steps=0)
        self.potential = self.robot.calc_potential()
        self.to_target_vec = None

    def create_single_player_scene(self):
        return SingleRobotEmptyScene(gravity=0, dt=0.0020, frame_skip=5)

    def step(self, a):
        self.robot.apply_action(a)
        self.scene.global_step()
        self.robot.calc_state()
        self.to_target_vec = self.robot.to_target_vec

        potential_diff = self.robot.calc_potential() - self.potential
        self.potential = self.robot.calc_potential()

        action_product = np.sum(np.abs(a) * self.robot.joint_velocities)
        action_sum = np.sum(np.abs(a))
        electricity_cost = -0.10 * action_product - 0.01 * action_sum

        stuck_joint_cost = -0.1 * np.sum(np.abs(self.robot.joint_positions - 1.0) < 0.01)

        if self.robot._object_hit_ground:
            reward_dist = -np.linalg.norm(self.robot.object_impact_position - self.robot.target_position)
        else:
            reward_dist = -np.linalg.norm(self.robot.object_position - self.robot.target_position)

        control_cost = -0.002 * np.sum(a ** 2)

        reward_list = [potential_diff, electricity_cost, stuck_joint_cost, reward_dist, control_cost]

        self.HUD(self.robot.state, a, False)
        self.camera_adjust()

        return reward_list

    def HUD(self, state, action, flag):
        pass

    def camera_adjust(self):
        fingertip_pos = self.robot.fingertip_position * 0.5
        self.scene.set_camera(fingertip_pos)