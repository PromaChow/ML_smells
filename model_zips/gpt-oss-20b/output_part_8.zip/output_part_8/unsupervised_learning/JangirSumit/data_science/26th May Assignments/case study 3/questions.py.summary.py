import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn import metrics

# 1. Data Collection
df = pd.read_csv("loan_borowwer_data.csv")
print(df.head())

# 2. Data Wrangling
X = df.iloc[:, 2:12]  # columns 2 through 11 (inclusive)
Y = df["not.fully.paid"]

# 3. Data Splitting
train_x, test_x, train_y, test_y = train_test_split(
    X, Y, test_size=0.3, random_state=10
)

# 4. Model Creation and Training
model = RandomForestClassifier()
model.fit(train_x, train_y)

# 5. Prediction
predicted_values = model.predict(test_x)

# 6. Accuracy Evaluation
accuracy = metrics.accuracy_score(test_y, predicted_values)