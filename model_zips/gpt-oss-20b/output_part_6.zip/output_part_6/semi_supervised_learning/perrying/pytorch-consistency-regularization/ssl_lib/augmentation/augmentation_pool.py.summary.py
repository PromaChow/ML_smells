import random
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image, ImageEnhance, ImageOps


def _gen_cutout_coord(height: int, width: int, size: int):
    """
    Generate coordinates for a cutout region.

    Returns a tuple (upper_coord, lower_coord) where
    upper_coord = (top, left) and lower_coord = (bottom, right).
    """
    center_x = random.randint(0, width)
    center_y = random.randint(0, height)
    half = size // 2
    left = max(center_x - half, 0)
    top = max(center_y - half, 0)
    right = min(center_x + half, width)
    bottom = min(center_y + half, height)
    return (top, left), (bottom, right)


# ----------------- PIL.Image Operations ----------------- #
def autocontrast(img: Image.Image, level: float, magnitude: float, max_level: float) -> Image.Image:
    img_rgb = img.convert("RGB")
    img_rgb = ImageOps.autocontrast(img_rgb)
    return img_rgb.convert("RGBA")


def brightness(img: Image.Image, level: float, magnitude: float, max_level: float) -> Image.Image:
    level = (level / magnitude) * max_level + 0.1
    enhancer = ImageEnhance.Brightness(img)
    return enhancer.enhance(level)


def color(img: Image.Image, level: float, magnitude: float, max_level: float) -> Image.Image:
    level = (level / magnitude) * max_level + 0.1
    enhancer = ImageEnhance.Color(img)
    return enhancer.enhance(level)


def contrast(img: Image.Image, level: float, magnitude: float, max_level: float) -> Image.Image:
    level = (level / magnitude) * max_level + 0.1
    enhancer = ImageEnhance.Contrast(img)
    return enhancer.enhance(level)


def sharpness(img: Image.Image, level: float, magnitude: float, max_level: float) -> Image.Image:
    level = (level / magnitude) * max_level + 0.1
    enhancer = ImageEnhance.Sharpness(img)
    return enhancer.enhance(level)


def equalize(img: Image.Image, level: float, magnitude: float, max_level: float) -> Image.Image:
    img_rgb = img.convert("RGB")
    img_rgb = ImageOps.equalize(img_rgb)
    return img_rgb.convert("RGBA")


def identity(img: Image.Image, level: float, magnitude: float, max_level: float) -> Image.Image:
    return img


def invert(img: Image.Image, level: float, magnitude: float, max_level: float) -> Image.Image:
    img_rgb = img.convert("RGB")
    img_rgb = ImageOps.invert(img_rgb)
    return img_rgb.convert("RGBA")


def posterize(img: Image.Image, level: float, magnitude: float, max_level: float) -> Image.Image:
    level_int = int((level / magnitude) * max_level)
    bits = max(0, 4 - level_int)
    return ImageOps.posterize(img, bits)


def rotate(img: Image.Image, level: float, magnitude: float, max_level: float) -> Image.Image:
    degree = int((level / magnitude) * max_level)
    if random.random() < 0.5:
        degree = -degree
    return img.rotate(degree, resample=Image.BICUBIC, expand=False)


def shear_x(img: Image.Image, level: float, magnitude: float, max_level: float) -> Image.Image:
    shear = (level / magnitude) * max_level
    if random.random() < 0.5:
        shear = -shear
    width, height = img.size
    return img.transform(
        (width, height),
        Image.AFFINE,
        (1, shear, 0, 0, 1, 0),
        resample=Image.BICUBIC,
    )


def shear_y(img: Image.Image, level: float, magnitude: float, max_level: float) -> Image.Image:
    shear = (level / magnitude) * max_level
    if random.random() < 0.5:
        shear = -shear
    width, height = img.size
    return img.transform(
        (width, height),
        Image.AFFINE,
        (1, 0, 0, shear, 1, 0),
        resample=Image.BICUBIC,
    )


def solarize(img: Image.Image, level: float, magnitude: float, max_level: float) -> Image.Image:
    level_int = int((level / magnitude) * max_level)
    threshold = max(0, 256 - level_int)
    return ImageOps.solarize(img, threshold)


def translate_x(img: Image.Image, level: float, magnitude: float, max_level: float) -> Image.Image:
    tx = int((level / magnitude) * max_level)
    if random.random() < 0.5:
        tx = -tx
    width, height = img.size
    return img.transform(
        (width, height),
        Image.AFFINE,
        (1, 0, tx, 0, 1, 0),
        resample=Image.BICUBIC,
    )


def translate_y(img: Image.Image, level: float, magnitude: float, max_level: float) -> Image.Image:
    ty = int((level / magnitude) * max_level)
    if random.random() < 0.5:
        ty = -ty
    width, height = img.size
    return img.transform(
        (width, height),
        Image.AFFINE,
        (1, 0, 0, 0, 1, ty),
        resample=Image.BICUBIC,
    )


def cutout(img: Image.Image, level: float, magnitude: float, max_level: float) -> Image.Image:
    size = int((level / magnitude) * max_level)
    if size <= 0:
        return img
    width, height = img.size
    upper_coord, lower_coord = _gen_cutout_coord(height, width, size)
    left, upper = upper_coord[1], upper_coord[0]
    right, lower = lower_coord[1], lower_coord[0]
    img = img.copy()
    img.paste((127, 127, 127, 0), (left, upper, right, lower))
    return img


# ----------------- torch.Tensor Operations ----------------- #
class TorchCutout:
    def __init__(self, size: int):
        self.size = size

    def __call__(self, x: torch.Tensor) -> torch.Tensor:
        if x.dim() == 3:  # C, H, W
            _, h, w = x.shape
            upper, lower = _gen_cutout_coord(h, w, self.size)
            mask = torch.ones((h, w), dtype=x.dtype, device=x.device)
            top, left = upper
            bottom, right = lower
            mask[top:bottom, left:right] = 0
            return x * mask.unsqueeze(0)
        elif x.dim() == 4:  # B, C, H, W
            b, c, h, w = x.shape
            mask = torch.ones((b, h, w), dtype=x.dtype, device=x.device)
            for i in range(b):
                upper, lower = _gen_cutout_coord(h, w, self.size)
                top, left = upper
                bottom, right = lower
                mask[i, top:bottom, left:right] = 0
            return x * mask.unsqueeze(1)
        else:
            raise ValueError("Unsupported tensor shape for TorchCutout.")


class GaussianNoise:
    def __init__(self, std: float):
        self.std = std

    def __call__(self, x: torch.Tensor) -> torch.Tensor:
        noise = torch.randn_like(x) * self.std
        return x + noise


class BatchRandomFlip:
    def __init__(self, flip_prob: float):
        self.flip_prob = flip_prob

    def __call__(self, x: torch.Tensor) -> torch.Tensor:
        if x.dim() != 4:
            raise ValueError("BatchRandomFlip expects 4-D tensor (B, C, H, W).")
        b = x.size(0)
        result = []
        for i in range(b):
            if random.random() < self.flip_prob:
                result.append(torch.flip(x[i], dims=[-1]))
            else:
                result.append(x[i])
        return torch.stack(result, dim=0)


class RandomFlip:
    def __init__(self, flip_prob: float):
        self.flip_prob = flip_prob

    def __call__(self, x: torch.Tensor) -> torch.Tensor:
        if random.random() < self.flip_prob:
            return torch.flip(x, dims=[-1])
        return x


class BatchRandomCrop:
    def __init__(self, crop_size: int, padding: int = 0):
        self.crop_size = crop_size
        self.padding = padding

    def __call__(self, x: torch.Tensor) -> torch.Tensor:
        if x.dim() != 4:
            raise ValueError("BatchRandomCrop expects 4-D tensor (B, C, H, W).")
        b, c, h, w = x.shape
        padded = F.pad(x, (self.padding, self.padding, self.padding, self.padding), mode="reflect")
        ph, pw = padded.shape[2], padded.shape[3]
        result = []
        for i in range(b):
            top = random.randint(0, ph - self.crop_size)
            left = random.randint(0, pw - self.crop_size)
            cropped = padded[i, :, top:top + self.crop_size, left:left + self.crop_size]
            result.append(cropped)
        return torch.stack(result, dim=0)


class RandomCrop:
    def __init__(self, crop_size: int, padding: int = 0):
        self.crop_size = crop_size
        self.padding = padding

    def __call__(self, x: torch.Tensor) -> torch.Tensor:
        if x.dim() != 3:
            raise ValueError("RandomCrop expects 3-D tensor (C, H, W).")
        padded = F.pad(x, (self.padding, self.padding, self.padding, self.padding), mode="reflect")
        ph, pw = padded.shape[1], padded.shape[2]
        top = random.randint(0, ph - self.crop_size)
        left = random.randint(0, pw - self.crop_size)
        return padded[:, top:top + self.crop_size, left:left + self.crop_size]


class ZCA:
    def __init__(self, mean: torch.Tensor, scale: torch.Tensor):
        self.mean = mean
        self.scale = scale

    def __call__(self, x: torch.Tensor) -> torch.Tensor:
        return (x - self.mean) * self.scale


class GCN:
    def __init__(self, multiplier: float = 1.0, eps: float = 1e-8):
        self.multiplier = multiplier
        self.eps = eps

    def __call__(self, x: torch.Tensor) -> torch.Tensor:
        mean = x.mean(dim=[1, 2, 3], keepdim=True)
        x = x - mean
        norm = torch.norm(x, p=2, dim=[1, 2, 3], keepdim=True)
        norm = torch.clamp(norm, min=self.eps)
        return x * (self.multiplier / norm)


# ----------------- numpy.array Operations ----------------- #
def numpy_batch_gcn(images: np.ndarray, multiplier: float, eps: float) -> np.ndarray:
    images = images.astype(np.float32)
    mean = images.mean(axis=(1, 2, 3), keepdims=True)
    images = images - mean
    norm = np.linalg.norm(images.reshape(images.shape[0], -1), axis=1, keepdims=True)
    norm = np.maximum(norm, eps)
    images = images * (multiplier / norm[:, None, None, None])
    return images
