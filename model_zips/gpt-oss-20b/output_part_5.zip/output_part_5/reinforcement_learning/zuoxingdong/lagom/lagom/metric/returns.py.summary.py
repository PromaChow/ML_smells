import numpy as np

def geometric_cumsum(gamma: float, rewards: np.ndarray) -> np.ndarray:
    """
    Compute the discounted cumulative sum of rewards for each batch.

    Parameters
    ----------
    gamma : float
        Discount factor.
    rewards : np.ndarray
        Array of shape (batch, seq) containing rewards.

    Returns
    -------
    np.ndarray
        Array of the same shape as `rewards` containing discounted cumulative sums.
    """
    rewards = np.asarray(rewards, dtype=np.float32)
    if rewards.ndim != 2:
        raise ValueError("rewards must be a 2-D array (batch, seq)")
    batch, seq = rewards.shape
    discounted = np.empty_like(rewards, dtype=np.float32)
    for b in range(batch):
        cum = 0.0
        for t in reversed(range(seq)):
            cum = rewards[b, t] + gamma * cum
            discounted[b, t] = cum
    return discounted

def numpify(value) -> np.float32:
    """
    Convert a scalar or array-like value to a NumPy float32 scalar.

    Parameters
    ----------
    value : scalar or array-like
        The value to convert.

    Returns
    -------
    np.float32
        Scalar representation of the input as float32.
    """
    return np.array(value, dtype=np.float32).astype(np.float32).item()

def returns(gamma: float, rewards: np.ndarray) -> np.ndarray:
    """
    Compute discounted returns for a batch of rewards.

    Parameters
    ----------
    gamma : float
        Discount factor.
    rewards : np.ndarray
        Array of shape (batch, seq) containing rewards.

    Returns
    -------
    np.ndarray
        Array of shape (seq,) containing discounted returns for the first batch.
    """
    discounted = geometric_cumsum(gamma, rewards)
    return np.array(discounted[0], dtype=np.float32)

def bootstrapped_returns(gamma: float, rewards: np.ndarray, last_V, reach_terminal: bool) -> np.ndarray:
    """
    Compute bootstrapped discounted returns, using `last_V` when the episode has not terminated.

    Parameters
    ----------
    gamma : float
        Discount factor.
    rewards : np.ndarray
        Array of shape (batch, seq) containing rewards.
    last_V : scalar or array-like
        Value estimate of the terminal state.
    reach_terminal : bool
        True if the episode terminated at the last step, False otherwise.

    Returns
    -------
    np.ndarray
        Array of shape (seq,) containing bootstrapped discounted returns for the first batch.
    """
    last_V_scalar = numpify(last_V)
    append_value = 0.0 if reach_terminal else last_V_scalar
    rewards = np.asarray(rewards, dtype=np.float32)
    if rewards.ndim != 2:
        raise ValueError("rewards must be a 2-D array (batch, seq)")
    appended = np.concatenate(
        [rewards, np.full((rewards.shape[0], 1), append_value, dtype=np.float32)],
        axis=1,
    )
    discounted = geometric_cumsum(gamma, appended)
    return np.array(discounted[0, :-1], dtype=np.float32)