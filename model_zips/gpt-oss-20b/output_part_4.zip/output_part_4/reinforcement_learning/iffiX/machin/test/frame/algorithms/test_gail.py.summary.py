import os
import pickle
import tempfile
import time
from collections import deque

import gym
import numpy as np
import pytest
import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim.lr_scheduler import LambdaLR

# Neural network definitions
class Actor(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden_dim=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, act_dim),
            nn.Softmax(dim=-1),
        )

    def forward(self, x):
        return self.net(x)


class Critic(nn.Module):
    def __init__(self, obs_dim, hidden_dim=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
        )

    def forward(self, x):
        return self.net(x).squeeze(-1)


class Discriminator(nn.Module):
    def __init__(self, obs_dim, act_dim, hidden_dim=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(obs_dim + act_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
            nn.Sigmoid(),
        )

    def forward(self, obs, act):
        inp = torch.cat([obs, act], dim=-1)
        return self.net(inp).squeeze(-1)


# GAIL algorithm implementation
class GAIL:
    def __init__(
        self,
        env_name,
        obs_dim,
        act_dim,
        learning_rate=3e-4,
        gamma=0.99,
        lambda_lr_func=None,
        save_dir=None,
    ):
        self.env_name = env_name
        self.env = gym.make(env_name)
        self.obs_dim = obs_dim
        self.act_dim = act_dim
        self.gamma = gamma

        self.actor = Actor(obs_dim, act_dim)
        self.critic = Critic(obs_dim)
        self.discriminator = Discriminator(obs_dim, act_dim)

        self.actor_opt = optim.Adam(self.actor.parameters(), lr=learning_rate)
        self.critic_opt = optim.Adam(self.critic.parameters(), lr=learning_rate)
        self.disc_opt = optim.Adam(self.discriminator.parameters(), lr=learning_rate)

        if lambda_lr_func is not None:
            self.lr_scheduler = LambdaLR(self.actor_opt, lr_lambda=lambda_lr_func)
        else:
            self.lr_scheduler = None

        self.expert_buffer = deque(maxlen=10000)
        self.agent_buffer = deque(maxlen=10000)
        self.save_dir = save_dir

    def act(self, obs, deterministic=False):
        obs_t = torch.tensor(obs, dtype=torch.float32).unsqueeze(0)
        probs = self.actor(obs_t)
        if deterministic:
            action = probs.argmax(dim=-1).item()
        else:
            action = np.random.choice(self.act_dim, p=probs.detach().cpu().numpy()[0])
        return action

    def _discriminate(self, obs, act):
        obs_t = torch.tensor(obs, dtype=torch.float32)
        act_t = torch.tensor(act, dtype=torch.float32)
        return self.discriminator(obs_t, act_t).item()

    def store_episode(self, obs, act, rew, term):
        self.agent_buffer.append((obs, act, rew, term))

    def store_expert_episode(self, obs, act, rew, term):
        self.expert_buffer.append((obs, act, rew, term))

    def update(self, update_policy=True, update_value=True, update_discriminator=True):
        if update_policy:
            # Policy gradient loss
            policy_loss = 0.0
            for obs, act, _, _ in list(self.agent_buffer):
                obs_t = torch.tensor(obs, dtype=torch.float32)
                probs = self.actor(obs_t)
                logp = torch.log(probs[act] + 1e-8)
                advantage = self.critic(obs_t).detach()
                policy_loss -= logp * advantage
            policy_loss /= len(self.agent_buffer)
            self.actor_opt.zero_grad()
            policy_loss.backward()
            self.actor_opt.step()

        if update_value:
            # Value loss
            value_loss = 0.0
            for obs, _, rew, _ in list(self.agent_buffer):
                obs_t = torch.tensor(obs, dtype=torch.float32)
                value = self.critic(obs_t)
                value_loss += (value - rew) ** 2
            value_loss /= len(self.agent_buffer)
            self.critic_opt.zero_grad()
            value_loss.backward()
            self.critic_opt.step()

        if update_discriminator:
            # Discriminator loss
            disc_loss = 0.0
            for obs, act, _, _ in list(self.expert_buffer):
                obs_t = torch.tensor(obs, dtype=torch.float32)
                act_t = torch.tensor(act, dtype=torch.float32)
                pred = self.discriminator(obs_t, act_t)
                disc_loss -= torch.log(pred + 1e-8)
            for obs, act, _, _ in list(self.agent_buffer):
                obs_t = torch.tensor(obs, dtype=torch.float32)
                act_t = torch.tensor(act, dtype=torch.float32)
                pred = self.discriminator(obs_t, act_t)
                disc_loss -= torch.log(1 - pred + 1e-8)
            disc_loss /= (len(self.expert_buffer) + len(self.agent_buffer))
            self.disc_opt.zero_grad()
            disc_loss.backward()
            self.disc_opt.step()

        if self.lr_scheduler is not None:
            self.lr_scheduler.step()

    def update_lr_scheduler(self, lambda_lr_func):
        self.lr_scheduler = LambdaLR(self.actor_opt, lr_lambda=lambda_lr_func)

    def generate_config(self):
        config = {
            "env_name": self.env_name,
            "obs_dim": self.obs_dim,
            "act_dim": self.act_dim,
            "gamma": self.gamma,
        }
        return config

    def init_from_config(self, config, expert_path=None):
        self.__init__(
            env_name=config["env_name"],
            obs_dim=config["obs_dim"],
            act_dim=config["act_dim"],
            gamma=config.get("gamma", 0.99),
        )
        if expert_path is not None:
            with open(expert_path, "rb") as f:
                expert_episodes = pickle.load(f)
            for ep in expert_episodes:
                for transition in ep:
                    self.store_expert_episode(*transition)

    def save_expert(self, path, episodes):
        with open(path, "wb") as f:
            pickle.dump(episodes, f)

    def load_expert(self, path):
        with open(path, "rb") as f:
            return pickle.load(f)


# Pytest fixtures
@pytest.fixture
def train_config():
    return {
        "env_name": "CartPole-v0",
        "obs_dim": 4,
        "act_dim": 2,
        "max_episodes": 5,
        "max_steps": 200,
        "replay_buffer_size": 10000,
        "solved_reward": 195.0,
    }


@pytest.fixture
def gail(train_config):
    return GAIL(
        env_name=train_config["env_name"],
        obs_dim=train_config["obs_dim"],
        act_dim=train_config["act_dim"],
        learning_rate=3e-4,
    )


@pytest.fixture
def gail_vis(train_config):
    tmp_dir = tempfile.mkdtemp()
    return GAIL(
        env_name=train_config["env_name"],
        obs_dim=train_config["obs_dim"],
        act_dim=train_config["act_dim"],
        learning_rate=3e-4,
        save_dir=tmp_dir,
    )


@pytest.fixture
def gail_lr(train_config):
    def lr_func(step):
        return 0.5 ** (step // 1000)
    return GAIL(
        env_name=train_config["env_name"],
        obs_dim=train_config["obs_dim"],
        act_dim=train_config["act_dim"],
        learning_rate=3e-4,
        lambda_lr_func=lr_func,
    )


@pytest.fixture
def gail_train(train_config):
    return GAIL(
        env_name=train_config["env_name"],
        obs_dim=train_config["obs_dim"],
        act_dim=train_config["act_dim"],
        learning_rate=3e-4,
    )


# Component-specific tests
def test_act(gail):
    obs = np.zeros(gail.obs_dim)
    action = gail.act(obs)
    assert isinstance(action, int)
    assert 0 <= action < gail.act_dim


def test_discriminate(gail):
    obs = np.zeros(gail.obs_dim)
    act = np.zeros(gail.act_dim)
    prob = gail._discriminate(obs, act)
    assert 0.0 <= prob <= 1.0


def test_episode_storage(gail):
    obs = np.zeros(gail.obs_dim)
    act = np.zeros(gail.act_dim)
    rew = 0.0
    term = False
    gail.store_episode(obs, act, rew, term)
    gail.store_expert_episode(obs, act, rew, term)
    assert len(gail.agent_buffer) == 1
    assert len(gail.expert_buffer) == 1


def test_update(gail):
    obs = np.zeros(gail.obs_dim)
    act = np.zeros(gail.act_dim)
    rew = 0.0
    term = False
    gail.store_episode(obs, act, rew, term)
    gail.store_expert_episode(obs, act, rew, term)
    gail.update(
        update_policy=True, update_value=True, update_discriminator=True
    )


def test_lr_scheduler(gail_lr):
    prev_lr = gail_lr.actor_opt.param_groups[0]["lr"]
    gail_lr.update()
    new_lr = gail_lr.actor_opt.param_groups[0]["lr"]
    assert new_lr <= prev_lr


def test_config_init(train_config):
    gail = GAIL(
        env_name=train_config["env_name"],
        obs_dim=train_config["obs_dim"],
        act_dim=train_config["act_dim"],
    )
    config = gail.generate_config()
    assert config["env_name"] == train_config["env_name"]

    # Create dummy expert episodes
    episodes = []
    for _ in range(3):
        ep = []
        for _ in range(5):
            ep.append(
                (
                    np.zeros(train_config["obs_dim"]),
                    np.zeros(train_config["act_dim"]),
                    0.0,
                    False,
                )
            )
        episodes.append(ep)

    with tempfile.NamedTemporaryFile(delete=False) as tmp:
        path = tmp.name
    gail.save_expert(path, episodes)

    new_gail = GAIL(
        env_name=train_config["env_name"],
        obs_dim=train_config["obs_dim"],
        act_dim=train_config["act_dim"],
    )
    new_gail.init_from_config(config, expert_path=path)
    assert len(new_gail.expert_buffer) == len(episodes) * 5
    os.remove(path)


def test_full_training(train_config):
    # Create dummy expert episodes and save
    expert_episodes = []
    for _ in range(10):
        ep = []
        for _ in range(5):
            ep.append(
                (
                    np.zeros(train_config["obs_dim"]),
                    np.zeros(train_config["act_dim"]),
                    0.0,
                    False,
                )
            )
        expert_episodes.append(ep)

    with tempfile.NamedTemporaryFile(delete=False) as tmp:
        expert_path = tmp.name
    gail = GAIL(
        env_name=train_config["env_name"],
        obs_dim=train_config["obs_dim"],
        act_dim=train_config["act_dim"],
    )
    gail.save_expert(expert_path, expert_episodes)
    gail.init_from_config(gail.generate_config(), expert_path=expert_path)
    os.remove(expert_path)

    solved_reward = train_config["solved_reward"]
    reward_history = deque(maxlen=10)
    for ep in range(train_config["max_episodes"]):
        obs = gail.env.reset()
        ep_reward = 0.0
        for step in range(train_config["max_steps"]):
            action = gail.act(obs)
            next_obs, rew, done, _ = gail.env.step(action)
            ep_reward += rew
            gail.store_episode(obs, action, rew, done)
            obs = next_obs
            if done:
                break
        gail.update()
        reward_history.append(ep_reward)
        if len(reward_history) == reward_history.maxlen and all(
            r >= solved_reward for r in reward_history
        ):
            break
    # Ensure some training occurred
    assert len(gail.agent_buffer) > 0
    assert len(reward_history) > 0
    # Cleanup environment
    gail.env.close()
```