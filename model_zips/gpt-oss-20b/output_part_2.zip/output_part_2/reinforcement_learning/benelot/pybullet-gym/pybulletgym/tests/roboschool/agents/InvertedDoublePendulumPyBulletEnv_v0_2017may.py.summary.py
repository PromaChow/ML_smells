import os
import sys
import numpy as np

# Add the parent directory to the system path
parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if parent_dir not in sys.path:
    sys.path.append(parent_dir)

# Weights and biases for a fully connected neural network

# First dense layer (50 neurons, 80 input features)
weights_dense1_w = np.arange(50 * 80, dtype=np.float64).reshape(50, 80)
weights_dense1_b = np.arange(50, dtype=np.float64)

# Second dense layer (32 neurons, 50 inputs from previous layer)
weights_dense2_w = np.arange(32 * 50, dtype=np.float64).reshape(32, 50)
weights_dense2_b = np.arange(32, dtype=np.float64)

# Final output layer (1 neuron, 32 inputs from previous layer)
weights_final_w = np.arange(32 * 1, dtype=np.float64).reshape(32, 1)
weights_final_b = np.array(0.0, dtype=np.float64)