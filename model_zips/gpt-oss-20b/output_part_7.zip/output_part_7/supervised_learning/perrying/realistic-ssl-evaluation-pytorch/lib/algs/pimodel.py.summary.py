import torch
import torch.nn.functional as F


class PiModel(torch.nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, model, x, y, mask):
        model.update_batch_stats(False)
        y_hat = model(x)
        model.update_batch_stats(True)

        y_hat_soft = F.softmax(y_hat, dim=1)
        y_soft = F.softmax(y, dim=1).detach()

        mse = F.mse_loss(y_hat_soft, y_soft, reduction="none")
        masked = mse * mask.unsqueeze(1).float()
        loss = masked.mean(1).mean()
        return loss
