import numpy as np
import matplotlib.pyplot as plt

class LinearRegressorGD:
    def __init__(self):
        self.a_fit = None

    def fit(self, X, y, eta=1e-6, loss_tolerance=1e-2, fit_tolerance=1e-4, max_iter=100000):
        N, d = X.shape
        self.a_fit = np.random.randn(d + 1)
        prev_loss = float('inf')
        prev_a_fit = np.copy(self.a_fit)

        for _ in range(max_iter):
            y_hat = X @ self.a_fit[1:] + self.a_fit[0]
            loss = np.mean((y_hat - y) ** 2)

            grad_intercept = (2 / N) * np.sum(y_hat - y)
            grad_coeffs = (2 / N) * X.T @ (y_hat - y)
            gradient = np.concatenate(([grad_intercept], grad_coeffs))

            self.a_fit -= eta * gradient

            loss_change = abs(loss - prev_loss)
            fit_change = np.linalg.norm(self.a_fit - prev_a_fit)

            if loss_change < loss_tolerance and fit_change < fit_tolerance:
                break

            prev_loss = loss
            prev_a_fit = np.copy(self.a_fit)

    def predict(self, X):
        return X @ self.a_fit[1:] + self.a_fit[0]


if __name__ == "__main__":
    np.random.seed(0)
    X = np.arange(100).reshape(-1, 1)
    noise = np.random.randn(100) * 10
    y = 3 * X.squeeze() + 5 + noise

    model = LinearRegressorGD()
    model.fit(X, y)

    y_pred = model.predict(X)
    mse = np.mean((y_pred - y) ** 2)
    print(f"Mean Squared Error: {mse:.4f}")

    plt.figure(figsize=(8, 5))
    plt.scatter(X, y, label='Actual data')
    plt.plot(X, y_pred, color='red', label='Predicted')
    plt.xlabel('X')
    plt.ylabel('y')
    plt.title('Linear Regression with Gradient Descent')
    plt.legend()
    plt.show()
