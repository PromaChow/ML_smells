import numpy as np
from sklearn.tree import DecisionTreeRegressor

class GradientBoostedTreeRegressor:
    def __init__(self, n_estimators=100, max_depth=3,
                 min_samples_split=2, min_samples_leaf=1):
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.min_samples_leaf = min_samples_leaf
        self.models = []

    def fit(self, X, y):
        X = np.asarray(X)
        y = np.asarray(y).ravel()
        self.models = []
        y_pred_i = np.zeros_like(y)
        y_i = y.copy()
        for _ in range(self.n_estimators):
            tree = DecisionTreeRegressor(
                max_depth=self.max_depth,
                min_samples_split=self.min_samples_split,
                min_samples_leaf=self.min_samples_leaf
            )
            tree.fit(X, y_i)
            y_pred_i += tree.predict(X)
            residuals = y - y_pred_i
            y_i = residuals
            self.models.append(tree)
        return self

    def predict(self, X):
        X = np.asarray(X)
        y_pred = np.zeros(X.shape[0])
        for tree in self.models:
            y_pred += tree.predict(X)
        return y_pred

# Example usage (uncomment to test):
# from sklearn.datasets import make_regression
# X, y = make_regression(n_samples=200, n_features=4, noise=0.1, random_state=42)
# model = GradientBoostedTreeRegressor(n_estimators=50, max_depth=4)
# model.fit(X, y)
# predictions = model.predict(X[:5])
# print(predictions)