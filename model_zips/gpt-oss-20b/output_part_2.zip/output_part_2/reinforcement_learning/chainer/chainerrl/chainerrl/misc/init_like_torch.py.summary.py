import math
import numpy as np
import chainer
from chainer import links

def init_like_torch(link: chainer.Link) -> None:
    """
    Apply PyTorch-style initialization to a Chainer model's layers.
    """
    for li in link.links():
        # Linear layer
        if isinstance(li, links.Linear):
            out_channels, in_channels = li.W.shape
            stdv = 1.0 / math.sqrt(in_channels)
            li.W.data = np.random.uniform(-stdv, stdv, size=li.W.shape).astype(li.W.dtype)
            if li.b is not None:
                li.b.data = np.random.uniform(-stdv, stdv, size=li.b.shape).astype(li.b.dtype)

        # Convolution2D layer
        elif isinstance(li, links.Convolution2D):
            out_channels, in_channels, kh, kw = li.W.shape
            stdv = 1.0 / math.sqrt(in_channels * kh * kw)
            li.W.data = np.random.uniform(-stdv, stdv, size=li.W.shape).astype(li.W.dtype)
            if li.b is not None:
                li.b.data = np.random.uniform(-stdv, stdv, size=li.b.shape).astype(li.b.dtype)