import gym
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from torch.distributions import Categorical, Normal
from typing import Tuple, Dict, Any, List


def get_env_properties(env: gym.Env) -> Dict[str, Any]:
    """Extract environment properties needed for the network."""
    if isinstance(env.action_space, gym.spaces.Discrete):
        action_dim = env.action_space.n
        discrete = True
        max_action = None
    else:
        action_dim = env.action_space.shape[0]
        discrete = False
        max_action = env.action_space.high[0]
    if isinstance(env.observation_space, gym.spaces.Box):
        state_dim = env.observation_space.shape[0]
    else:
        raise NotImplementedError("Only Box observation spaces are supported.")
    return {
        "state_dim": state_dim,
        "action_dim": action_dim,
        "discrete": discrete,
        "max_action": max_action,
    }


def compute_returns_and_advantage(
    rewards: np.ndarray,
    values: np.ndarray,
    dones: np.ndarray,
    gamma: float = 0.99,
    lam: float = 0.95,
) -> Tuple[np.ndarray, np.ndarray]:
    """Compute GAE advantage estimates and returns."""
    advantages = np.zeros_like(rewards)
    returns = np.zeros_like(rewards)
    gae = 0.0
    for t in reversed(range(len(rewards))):
        delta = rewards[t] + gamma * values[t + 1] * (1 - dones[t]) - values[t]
        gae = delta + gamma * lam * (1 - dones[t]) * gae
        advantages[t] = gae
        returns[t] = advantages[t] + values[t]
    return returns, advantages


class ActorCritic(nn.Module):
    def __init__(
        self,
        state_dim: int,
        action_dim: int,
        discrete: bool,
        activation: str = "relu",
        shared_layers: List[int] = None,
        policy_layers: List[int] = None,
        value_layers: List[int] = None,
    ):
        super().__init__()
        act_fn = getattr(nn, activation.capitalize())()
        if shared_layers is None:
            shared_layers = [64, 64]
        self.shared = nn.Sequential(
            nn.Linear(state_dim, shared_layers[0]),
            act_fn,
            *[
                nn.Sequential(nn.Linear(shared_layers[i], shared_layers[i + 1]), act_fn)
                for i in range(len(shared_layers) - 1)
            ]
        )
        # Policy head
        if policy_layers is None:
            policy_layers = [64]
        self.policy = nn.Sequential(
            nn.Linear(shared_layers[-1], policy_layers[0]),
            act_fn,
            *[
                nn.Sequential(nn.Linear(policy_layers[i], policy_layers[i + 1]), act_fn)
                for i in range(len(policy_layers) - 1)
            ],
            nn.Linear(policy_layers[-1], action_dim if discrete else 2 * action_dim),
        )
        # Value head
        if value_layers is None:
            value_layers = [64]
        self.value = nn.Sequential(
            nn.Linear(shared_layers[-1], value_layers[0]),
            act_fn,
            *[
                nn.Sequential(nn.Linear(value_layers[i], value_layers[i + 1]), act_fn)
                for i in range(len(value_layers) - 1)
            ],
            nn.Linear(value_layers[-1], 1),
        )
        self.discrete = discrete

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        h = self.shared(x)
        policy_out = self.policy(h)
        value_out = self.value(h).squeeze(-1)
        return policy_out, value_out

    def get_action(self, state: np.ndarray) -> Tuple[np.ndarray, float, float]:
        state_t = torch.tensor(state, dtype=torch.float32)
        policy_out, value = self.forward(state_t)
        if self.discrete:
            probs = torch.softmax(policy_out, dim=-1)
            dist = Categorical(probs)
            action = dist.sample()
            log_prob = dist.log_prob(action).item()
            return int(action.item()), value.item(), log_prob
        else:
            mean = policy_out[:, : policy_out.shape[-1] // 2]
            log_std = policy_out[:, policy_out.shape[-1] // 2 :]
            std = torch.exp(log_std)
            dist = Normal(mean, std)
            action = dist.sample()
            log_prob = dist.log_prob(action).sum(-1).item()
            # Clip actions to bounds if necessary
            action = torch.clamp(action, -1.0, 1.0).detach().cpu().numpy()
            return action, value.item(), log_prob

    def evaluate_actions(
        self,
        states: torch.Tensor,
        actions: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        policy_out, values = self.forward(states)
        if self.discrete:
            probs = torch.softmax(policy_out, dim=-1)
            dist = Categorical(probs)
            log_probs = dist.log_prob(actions.squeeze(-1))
            entropy = dist.entropy()
        else:
            mean = policy_out[:, : policy_out.shape[-1] // 2]
            log_std = policy_out[:, policy_out.shape[-1] // 2 :]
            std = torch.exp(log_std)
            dist = Normal(mean, std)
            log_probs = dist.log_prob(actions).sum(-1)
            entropy = dist.entropy().sum(-1)
        return log_probs, values, entropy


class OnPolicyAgent:
    def __init__(self, env: gym.Env):
        self.env = env
        self.rollout_buffer: Dict[str, List] = {
            "states": [],
            "actions": [],
            "log_probs": [],
            "rewards": [],
            "values": [],
            "dones": [],
        }

    def store_transition(
        self,
        state: np.ndarray,
        action: Any,
        log_prob: float,
        reward: float,
        value: float,
        done: bool,
    ):
        self.rollout_buffer["states"].append(state)
        self.rollout_buffer["actions"].append(action)
        self.rollout_buffer["log_probs"].append(log_prob)
        self.rollout_buffer["rewards"].append(reward)
        self.rollout_buffer["values"].append(value)
        self.rollout_buffer["dones"].append(done)

    def clear_buffer(self):
        for key in self.rollout_buffer:
            self.rollout_buffer[key] = []

    def get_hyperparams(self) -> Dict[str, Any]:
        return {}


class PPO1(OnPolicyAgent):
    def __init__(
        self,
        env: gym.Env,
        clip_param: float = 0.2,
        value_coeff: float = 0.5,
        entropy_coeff: float = 0.01,
        activation: str = "relu",
        create_model: bool = True,
    ):
        super().__init__(env)
        self.clip_param = clip_param
        self.value_coeff = value_coeff
        self.entropy_coeff = entropy_coeff
        self.activation = activation
        if create_model:
            self._create_model()

    def _create_model(self):
        props = get_env_properties(self.env)
        self.state_dim = props["state_dim"]
        self.action_dim = props["action_dim"]
        self.discrete = props["discrete"]
        self.max_action = props["max_action"]
        self.ac = ActorCritic(
            state_dim=self.state_dim,
            action_dim=self.action_dim,
            discrete=self.discrete,
            activation=self.activation,
        ).to("cpu")
        self.policy_optimizer = optim.Adam(
            self.ac.policy.parameters(), lr=3e-4
        )
        self.value_optimizer = optim.Adam(
            self.ac.value.parameters(), lr=1e-3
        )
        self.ac.shared.train()

    def select_action(self, state: np.ndarray) -> Tuple[Any, float, float]:
        action, value, log_prob = self.ac.get_action(state)
        return action, value, log_prob

    def evaluate_actions(
        self,
        states: torch.Tensor,
        actions: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        log_probs, values, entropy = self.ac.evaluate_actions(states, actions)
        return log_probs, values, entropy

    def get_traj_loss(self, gamma: float = 0.99, lam: float = 0.95) -> Tuple[np.ndarray, np.ndarray]:
        rewards = np.array(self.rollout_buffer["rewards"])
        values = np.array(self.rollout_buffer["values"] + [0])  # bootstrap value
        dones = np.array(self.rollout_buffer["dones"])
        returns, advantages = compute_returns_and_advantage(
            rewards, values, dones, gamma, lam
        )
        return returns, advantages

    def update_params(
        self,
        epochs: int = 4,
        minibatch_size: int = 64,
        gamma: float = 0.99,
        lam: float = 0.95,
    ):
        states = torch.tensor(
            np.array(self.rollout_buffer["states"]), dtype=torch.float32
        )
        actions = torch.tensor(
            np.array(self.rollout_buffer["actions"]), dtype=torch.float32
        )
        old_log_probs = torch.tensor(
            np.array(self.rollout_buffer["log_probs"]), dtype=torch.float32
        )
        returns, advantages = self.get_traj_loss(gamma, lam)
        returns = torch.tensor(returns, dtype=torch.float32)
        advantages = torch.tensor(advantages, dtype=torch.float32)
        advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

        dataset_size = states.shape[0]
        for _ in range(epochs):
            indices = np.arange(dataset_size)
            np.random.shuffle(indices)
            for start in range(0, dataset_size, minibatch_size):
                end = start + minibatch_size
                mb_indices = indices[start:end]
                mb_states = states[mb_indices]
                mb_actions = actions[mb_indices]
                mb_old_log_probs = old_log_probs[mb_indices]
                mb_returns = returns[mb_indices]
                mb_advantages = advantages[mb_indices]

                log_probs, values, entropy = self.evaluate_actions(
                    mb_states, mb_actions
                )

                ratio = torch.exp(log_probs - mb_old_log_probs)
                surr1 = ratio * mb_advantages
                surr2 = torch.clamp(ratio, 1.0 - self.clip_param, 1.0 + self.clip_param) * mb_advantages
                policy_loss = -torch.min(surr1, surr2).mean()

                value_loss = self.value_coeff * nn.functional.mse_loss(values, mb_returns)

                entropy_loss = -self.entropy_coeff * entropy.mean()

                loss = policy_loss + value_loss + entropy_loss

                self.policy_optimizer.zero_grad()
                self.value_optimizer.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(self.ac.parameters(), 0.5)
                self.policy_optimizer.step()
                self.value_optimizer.step()

        # Logging
        print(
            f"Policy Loss: {policy_loss.item():.4f} | "
            f"Value Loss: {value_loss.item():.4f} | "
            f"Entropy Loss: {entropy_loss.item():.4f}"
        )

        self.clear_buffer()

    def get_hyperparams(self) -> Dict[str, Any]:
        return {
            "clip_param": self.clip_param,
            "value_coeff": self.value_coeff,
            "entropy_coeff": self.entropy_coeff,
            "activation": self.activation,
        }

    def _load_weights(self, path: str):
        self.ac.load_state_dict(torch.load(path))
        self.policy_optimizer.load_state_dict(
            torch.load(path + "_policy_opt")
        )
        self.value_optimizer.load_state_dict(
            torch.load(path + "_value_opt")
        )
        print(f"Loaded weights from {path}")

```