import sys
import time
import numpy as np
import pygame

try:
    import doom_py
except ImportError as e:
    raise ImportError("doom_py is required but not installed") from e

class DoomWrapper:
    def __init__(self, cfg_file=None, scenario_file=None, width=640, height=480, allowed_fps=30):
        self.cfg_file = cfg_file or "basic.cfg"
        self.scenario_file = scenario_file or "basic.wad"
        self.width = width
        self.height = height
        self.allowed_fps = allowed_fps

        self.game = doom_py.DoomGame()
        self.window = None
        self.state = None
        self.action = None
        self.action_space = None
        self.noop_action = None
        self.setup()

    def setup(self):
        self.game.set_doom_map(self.scenario_file)
        self.game.set_doom_skill(1)
        self.game.set_doom_resizable(False)
        self.game.set_doom_screen_format(doom_py.ScreenFormat.BGR24)
        self.game.set_doom_screen_resolution(self.width, self.height)
        self.game.load_config(self.cfg_file)

        self.game.init()
        self.game.set_doom_available_levels([self.scenario_file])

        self.game.set_doom_available_game_variables([
            doom_py.GameVariable.HEALTH,
            doom_py.GameVariable.AMMO0,
            doom_py.GameVariable.AMMO1,
            doom_py.GameVariable.AMMO2,
            doom_py.GameVariable.AMMO3,
            doom_py.GameVariable.AMMO4,
            doom_py.GameVariable.AMMO5,
            doom_py.GameVariable.AMMO6,
            doom_py.GameVariable.AMMO7,
            doom_py.GameVariable.AMMO8,
            doom_py.GameVariable.AMMO9,
            doom_py.GameVariable.AMMO10,
            doom_py.GameVariable.AMMO11,
            doom_py.GameVariable.AMMO12,
            doom_py.GameVariable.AMMO13,
            doom_py.GameVariable.AMMO14,
            doom_py.GameVariable.AMMO15,
            doom_py.GameVariable.AMMO16,
            doom_py.GameVariable.AMMO17,
            doom_py.GameVariable.AMMO18,
            doom_py.GameVariable.AMMO19,
            doom_py.GameVariable.AMMO20,
            doom_py.GameVariable.AMMO21,
            doom_py.GameVariable.AMMO22,
            doom_py.GameVariable.AMMO23,
            doom_py.GameVariable.AMMO24,
            doom_py.GameVariable.AMMO25,
            doom_py.GameVariable.AMMO26,
            doom_py.GameVariable.AMMO27,
            doom_py.GameVariable.AMMO28,
            doom_py.GameVariable.AMMO29,
            doom_py.GameVariable.AMMO30,
            doom_py.GameVariable.AMMO31,
            doom_py.GameVariable.AMMO32,
            doom_py.GameVariable.AMMO33,
            doom_py.GameVariable.AMMO34,
            doom_py.GameVariable.AMMO35,
            doom_py.GameVariable.AMMO36,
            doom_py.GameVariable.AMMO37,
            doom_py.GameVariable.AMMO38,
            doom_py.GameVariable.AMMO39,
            doom_py.GameVariable.AMMO40,
            doom_py.GameVariable.AMMO41,
            doom_py.GameVariable.AMMO42,
            doom_py.GameVariable.AMMO43,
            doom_py.GameVariable.AMMO44,
            doom_py.GameVariable.AMMO45,
            doom_py.GameVariable.AMMO46,
            doom_py.GameVariable.AMMO47,
            doom_py.GameVariable.AMMO48,
            doom_py.GameVariable.AMMO49,
            doom_py.GameVariable.AMMO50,
            doom_py.GameVariable.AMMO51,
            doom_py.GameVariable.AMMO52,
            doom_py.GameVariable.AMMO53,
            doom_py.GameVariable.AMMO54,
            doom_py.GameVariable.AMMO55,
            doom_py.GameVariable.AMMO56,
            doom_py.GameVariable.AMMO57,
            doom_py.GameVariable.AMMO58,
            doom_py.GameVariable.AMMO59,
            doom_py.GameVariable.AMMO60,
            doom_py.GameVariable.AMMO61,
            doom_py.GameVariable.AMMO62,
            doom_py.GameVariable.AMMO63,
            doom_py.GameVariable.AMMO64,
            doom_py.GameVariable.AMMO65,
            doom_py.GameVariable.AMMO66,
            doom_py.GameVariable.AMMO67,
            doom_py.GameVariable.AMMO68,
            doom_py.GameVariable.AMMO69,
            doom_py.GameVariable.AMMO70,
            doom_py.GameVariable.AMMO71,
            doom_py.GameVariable.AMMO72,
            doom_py.GameVariable.AMMO73,
            doom_py.GameVariable.AMMO74,
            doom_py.GameVariable.AMMO75,
            doom_py.GameVariable.AMMO76,
            doom_py.GameVariable.AMMO77,
            doom_py.GameVariable.AMMO78,
            doom_py.GameVariable.AMMO79,
            doom_py.GameVariable.AMMO80,
            doom_py.GameVariable.AMMO81,
            doom_py.GameVariable.AMMO82,
            doom_py.GameVariable.AMMO83,
            doom_py.GameVariable.AMMO84,
            doom_py.GameVariable.AMMO85,
            doom_py.GameVariable.AMMO86,
            doom_py.GameVariable.AMMO87,
            doom_py.GameVariable.AMMO88,
            doom_py.GameVariable.AMMO89,
            doom_py.GameVariable.AMMO90,
            doom_py.GameVariable.AMMO91,
            doom_py.GameVariable.AMMO92,
            doom_py.GameVariable.AMMO93,
            doom_py.GameVariable.AMMO94,
            doom_py.GameVariable.AMMO95,
            doom_py.GameVariable.AMMO96,
            doom_py.GameVariable.AMMO97,
            doom_py.GameVariable.AMMO98,
            doom_py.GameVariable.AMMO99
        ])

        self.game.set_doom_available_actions([
            doom_py.ACTIONS["MOVE_LEFT"],
            doom_py.ACTIONS["MOVE_RIGHT"],
            doom_py.ACTIONS["TURN_LEFT"],
            doom_py.ACTIONS["TURN_RIGHT"],
            doom_py.ACTIONS["FORWARD"],
            doom_py.ACTIONS["BACKWARD"],
            doom_py.ACTIONS["USE"],
            doom_py.ACTIONS["ATTACK"]
        ])

        self.noop_action = [0] * len(self.game.get_available_actions())

        self.action_space = len(self.game.get_available_actions())

        pygame.init()
        self.window = doom_py.DoomWindow(self.game, self.width, self.height, "ViZDoom")

    def _setAction(self, action_index):
        actions = self.game.get_available_actions()
        if action_index < 0 or action_index >= len(actions):
            action = self.noop_action
        else:
            action = [0] * len(actions)
            action[action_index] = 1
        self.action = action

    def step(self, action_index=None):
        self._handle_window_events()
        if action_index is None:
            self._setAction(None)
        else:
            self._setAction(action_index)

        self.game.make_action(self.action)
        self.game.advance_action()
        self.state = self.game.get_state()
        self._draw_frame()
        reward = self.state.game_variables[doom_py.GameVariable.AMMO0]
        done = self.game.is_episode_finished()
        info = {"health": self.state.game_variables[doom_py.GameVariable.HEALTH]}
        self.tick()
        return self.state, reward, done, info

    def _draw_frame(self):
        if self.state:
            frame = self.state.screen_buffer
            frame_rgb = frame[..., ::-1]
            surface = pygame.surfarray.make_surface(frame_rgb.swapaxes(0, 1))
            pygame.surfarray.blit_array(self.window.screen, frame_rgb)
            pygame.display.flip()

    def init(self):
        self.game.new_episode()
        self.state = self.game.get_state()
        self._draw_frame()

    def reset(self):
        self.game.new_episode()
        self.state = self.game.get_state()
        self._draw_frame()
        return self.state

    def getGameState(self):
        if self.state:
            return {var.name: self.state.game_variables[var] for var in doom_py.GameVariable}
        return None

    def adjustRewards(self, living_reward=0.0, death_penalty=-1.0):
        self.game.set_living_reward(living_reward)
        self.game.set_death_penalty(death_penalty)

    def game_over(self):
        return self.game.is_episode_finished()

    def _handle_window_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.game.close()
                pygame.quit()
                sys.exit()

    def tick(self):
        time.sleep(1.0 / self.allowed_fps)