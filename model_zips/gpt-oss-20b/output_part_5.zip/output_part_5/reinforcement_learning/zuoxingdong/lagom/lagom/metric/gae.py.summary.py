import numpy as np

def td0_error(gamma: float, rewards: np.ndarray, Vs: np.ndarray,
              last_V: float, reach_terminal: bool) -> np.ndarray:
    """
    Compute TD(0) errors (deltas) for each time step.

    Parameters
    ----------
    gamma : float
        Discount factor.
    rewards : np.ndarray
        Rewards received at each time step. Shape (T,).
    Vs : np.ndarray
        Value estimates for each time step. Shape (T,).
    last_V : float
        Value estimate for the next state after the last time step.
    reach_terminal : bool
        If True, the episode ended at the last step; in that case
        the value estimate of the next state is considered 0.

    Returns
    -------
    np.ndarray
        TD(0) error for each time step. Shape (T,).
    """
    next_Vs = np.concatenate([Vs[1:], np.array([last_V])])
    if reach_terminal:
        next_Vs[-1] = 0.0
    deltas = rewards + gamma * next_Vs - Vs
    return deltas

def geometric_cumsum(discount: float, values: np.ndarray) -> np.ndarray:
    """
    Compute the geometric cumulative sum of `values` with the given discount factor.

    The result at index i is:
        sum_{k=0}^{len(values)-i-1} discount**k * values[i + k]

    Parameters
    ----------
    discount : float
        Discount factor to apply.
    values : np.ndarray
        Array of values to accumulate. Shape (T,).

    Returns
    -------
    np.ndarray
        Cumulative discounted sums for each starting index. Shape (T,).
    """
    T = len(values)
    result = np.empty(T, dtype=values.dtype)
    running_sum = 0.0
    for t in range(T - 1, -1, -1):
        running_sum = values[t] + discount * running_sum
        result[t] = running_sum
    return result

def compute_gae(gamma: float, lam: float, rewards: np.ndarray, Vs: np.ndarray,
                last_V: float, reach_terminal: bool) -> np.float32:
    """
    Calculate Generalized Advantage Estimation (GAE).

    The function follows the three-step procedure described in the specification:
    1. Compute TD(0) errors.
    2. Apply geometric cumulative sum with discount factor gamma * lam.
    3. Extract the first element of the cumulative sum and cast to np.float32.

    Parameters
    ----------
    gamma : float
        Discount factor.
    lam : float
        GAE lambda parameter.
    rewards : np.ndarray
        Rewards at each time step. Shape (T,).
    Vs : np.ndarray
        Value estimates at each time step. Shape (T,).
    last_V : float
        Value estimate for the state following the last time step.
    reach_terminal : bool
        True if the episode ends at the last time step.

    Returns
    -------
    np.float32
        The GAE value corresponding to the first state.
    """
    delta = td0_error(gamma, rewards, Vs, last_V, reach_terminal)
    discounted_cumsum = geometric_cumsum(gamma * lam, delta)
    return np.float32(discounted_cumsum[0])