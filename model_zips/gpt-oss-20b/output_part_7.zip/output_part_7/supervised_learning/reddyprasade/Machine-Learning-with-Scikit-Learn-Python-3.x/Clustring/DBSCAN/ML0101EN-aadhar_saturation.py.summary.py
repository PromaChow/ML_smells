import matplotlib.pyplot as plt
import pandas as pd
from itertools import groupby
from mpl_toolkits.basemap import Basemap
from matplotlib.patches import Polygon
from matplotlib.collections import PatchCollection
from matplotlib.colors import Normalize
import numpy as np

# Load and process data
df = pd.read_csv('aadhar_saturation.csv')
df_sorted = df.sort_values('State Name')
groups = groupby(df_sorted['State Name'], key=lambda x: x)
sat_list = [(name, sum(row['saturation'])) for name, row in zip(
    (g[0] for g in groups),
    (list(g[1]) for g in groups)
)]

sat_dict = dict(sat_list)

# Initialize the map
m = Basemap(projection='merc',
            llcrnrlon=68, llcrnrlat=6,
            urcrnrlon=97, urcrnrlat=37,
            resolution='i',
            lon_0=80,
            lat_0=20,
            oceancolor='lightblue')
m.drawcoastlines()
m.drawcountries()
m.fillcontinents(color='lightgray', lake_color='lightblue')

# Load shapefile data
m.readshapefile('India_SHP/INDIA', name='INDIA', drawbounds=False)

# Determine the key that holds the state name in the shapefile attributes
info_keys = list(m.INDIA_info[0].keys())
state_key = next((k for k in info_keys if 'name' in k.lower()), None)
if not state_key:
    state_key = info_keys[0]

# Map saturation values to states
satlist = []
for info in m.INDIA_info:
    state_name = info[state_key]
    satlist.append(sat_dict.get(state_name, 0))

# Create polygons for each state
polygons = []
for shape in m.INDIA:
    xy = [m(x, y) for x, y in shape]
    polygons.append(Polygon(xy, True))

# Create a PatchCollection with color mapping
cmap = plt.cm.Oranges_r
norm = Normalize(vmin=min(satlist), vmax=max(satlist))
patch_coll = PatchCollection(polygons, cmap=cmap, edgecolor='k', linewidth=0.5)
patch_coll.set_array(np.array(satlist))
patch_coll.set_norm(norm)

# Plot the choropleth map
fig, ax = plt.subplots(figsize=(15, 15))
ax.add_collection(patch_coll)
ax.set_xlim(m.lonmin, m.lonmax)
ax.set_ylim(m.latmin, m.latmax)

cbar = fig.colorbar(patch_coll, ax=ax)
cbar.set_label('Aadhar Saturation')

plt.title('Aadhar Saturation')
plt.show()