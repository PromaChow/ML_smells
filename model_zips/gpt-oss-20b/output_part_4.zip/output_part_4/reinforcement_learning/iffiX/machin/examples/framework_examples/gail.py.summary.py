import gym
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from collections import deque, namedtuple
import random

# Set random seeds
SEED = 42
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)

# Hyperparameters
ENV_NAME = 'CartPole-v0'
MAX_EPISODES = 1000
MAX_STEPS = 200
SOLVED_REWARD = 190
SOLVED_CONSEC = 5
EXPERT_EPISODES = 100

GAMMA = 0.99
LAM = 0.95
CLIP_EPS = 0.2
PPO_EPOCHS = 10
PPO_BATCH_SIZE = 64
PPO_LR = 3e-4

DISC_LR = 3e-4
DISC_EPOCHS = 5

# Environment
env = gym.make(ENV_NAME)
env.seed(SEED)
state_dim = env.observation_space.shape[0]
action_dim = env.action_space.n

# Neural network modules
class Actor(nn.Module):
    def __init__(self, state_dim, action_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, action_dim),
            nn.Softmax(dim=-1)
        )
    def forward(self, state):
        return self.net(state)

class Critic(nn.Module):
    def __init__(self, state_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 1)
        )
    def forward(self, state):
        return self.net(state)

class Discriminator(nn.Module):
    def __init__(self, state_dim, action_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim + action_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 128),
            nn.ReLU(),
            nn.Linear(128, 1),
            nn.Sigmoid()
        )
    def forward(self, state, action):
        sa = torch.cat([state, action], dim=-1)
        return self.net(sa)

# Memory buffer for PPO
Transition = namedtuple('Transition',
                        ('state', 'action', 'logprob', 'reward', 'value', 'done'))

class RolloutBuffer:
    def __init__(self):
        self.states = []
        self.actions = []
        self.logprobs = []
        self.rewards = []
        self.values = []
        self.dones = []

    def add(self, *args):
        for attr, value in zip(self.__dict__, args):
            getattr(self, attr).append(value)

    def clear(self):
        for attr in self.__dict__:
            getattr(self, attr).clear()

    def get(self):
        return dict(
            states=torch.tensor(self.states, dtype=torch.float32),
            actions=torch.tensor(self.actions, dtype=torch.long),
            logprobs=torch.tensor(self.logprobs, dtype=torch.float32),
            rewards=torch.tensor(self.rewards, dtype=torch.float32),
            values=torch.tensor(self.values, dtype=torch.float32),
            dones=torch.tensor(self.dones, dtype=torch.float32)
        )

# PPO agent
class PPOAgent:
    def __init__(self):
        self.actor = Actor(state_dim, action_dim).to(device)
        self.critic = Critic(state_dim).to(device)
        self.optimizer = optim.Adam(list(self.actor.parameters()) + list(self.critic.parameters()), lr=PPO_LR)
        self.buffer = RolloutBuffer()

    def select_action(self, state):
        state_t = torch.FloatTensor(state).to(device)
        probs = self.actor(state_t)
        dist = torch.distributions.Categorical(probs)
        action = dist.sample()
        logprob = dist.log_prob(action)
        value = self.critic(state_t)
        return action.item(), logprob.item(), value.item()

    def compute_returns_and_advantages(self):
        rewards = self.buffer.rewards
        values = self.buffer.values + [0]  # value for terminal state
        dones = self.buffer.dones
        gae = 0
        returns = []
        advantages = []
        for step in reversed(range(len(rewards))):
            delta = rewards[step] + GAMMA * values[step + 1] * (1 - dones[step]) - values[step]
            gae = delta + GAMMA * LAM * (1 - dones[step]) * gae
            advantages.insert(0, gae)
            returns.insert(0, gae + values[step])
        return returns, advantages

    def update(self):
        data = self.buffer.get()
        returns, advantages = self.compute_returns_and_advantages()
        returns = torch.tensor(returns, dtype=torch.float32).to(device)
        advantages = torch.tensor(advantages, dtype=torch.float32).to(device)
        advantages = (advantages - advantages.mean()) / (advantages.std() + 1e-8)

        dataset_size = len(data['states'])
        for _ in range(PPO_EPOCHS):
            indices = np.arange(dataset_size)
            np.random.shuffle(indices)
            for start in range(0, dataset_size, PPO_BATCH_SIZE):
                end = start + PPO_BATCH_SIZE
                batch_idx = indices[start:end]
                states = data['states'][batch_idx].to(device)
                actions = data['actions'][batch_idx].to(device)
                old_logprobs = data['logprobs'][batch_idx].to(device)
                returns_batch = returns[batch_idx].to(device)
                advantages_batch = advantages[batch_idx].to(device)

                probs = self.actor(states)
                dist = torch.distributions.Categorical(probs)
                logprobs = dist.log_prob(actions)
                entropy = dist.entropy().mean()

                ratios = torch.exp(logprobs - old_logprobs)
                surr1 = ratios * advantages_batch
                surr2 = torch.clamp(ratios, 1 - CLIP_EPS, 1 + CLIP_EPS) * advantages_batch
                policy_loss = -torch.min(surr1, surr2).mean()
                value_loss = nn.MSELoss()(self.critic(states).squeeze(), returns_batch)
                loss = policy_loss + 0.5 * value_loss - 0.01 * entropy

                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()
        self.buffer.clear()

# Expert data generation
def generate_expert_data(ppo_agent, num_episodes):
    expert_states = []
    expert_actions = []
    for _ in range(num_episodes):
        state = env.reset()
        done = False
        while not done:
            action, _, _ = ppo_agent.select_action(state)
            expert_states.append(state)
            expert_actions.append(action)
            state, _, done, _ = env.step(action)
    return expert_states, expert_actions

# GAIL training
class GAILAgent:
    def __init__(self, ppo_agent, discriminator, expert_states, expert_actions):
        self.ppo_agent = ppo_agent
        self.disc = discriminator
        self.disc_optimizer = optim.Adam(self.disc.parameters(), lr=DISC_LR)
        self.expert_states = torch.tensor(expert_states, dtype=torch.float32).to(device)
        self.expert_actions = torch.tensor(expert_actions, dtype=torch.long).to(device)
        self.expert_actions_onehot = nn.functional.one_hot(self.expert_actions, num_classes=action_dim).float()
        self.expert_sa = torch.cat([self.expert_states, self.expert_actions_onehot], dim=-1)

    def compute_discriminator_loss(self, expert_batch, agent_batch):
        expert_logits = self.disc(expert_batch[:, :state_dim], expert_batch[:, state_dim:])
        agent_logits = self.disc(agent_batch[:, :state_dim], agent_batch[:, state_dim:])
        expert_labels = torch.ones(expert_logits.size(0), 1).to(device)
        agent_labels = torch.zeros(agent_logits.size(0), 1).to(device)
        bce = nn.BCELoss()
        loss_expert = bce(expert_logits, expert_labels)
        loss_agent = bce(agent_logits, agent_labels)
        return loss_expert + loss_agent

    def train_discriminator(self):
        dataset_size = self.expert_sa.size(0)
        indices = torch.randperm(dataset_size)
        for _ in range(DISC_EPOCHS):
            for start in range(0, dataset_size, PPO_BATCH_SIZE):
                end = start + PPO_BATCH_SIZE
                idx = indices[start:end]
                expert_batch = self.expert_sa[idx]
                # Sample agent batch from recent rollouts
                agent_states = self.ppo_agent.buffer.states
                agent_actions = self.ppo_agent.buffer.actions
                if not agent_states:
                    continue
                agent_sa = torch.cat([torch.tensor(agent_states, dtype=torch.float32).to(device),
                                      torch.nn.functional.one_hot(torch.tensor(agent_actions, dtype=torch.long).to(device), num_classes=action_dim).float()], dim=-1)
                agent_batch = agent_sa[:len(expert_batch)]
                loss = self.compute_discriminator_loss(expert_batch, agent_batch)
                self.disc_optimizer.zero_grad()
                loss.backward()
                self.disc_optimizer.step()

    def sample_from_expert(self, batch_size):
        idx = torch.randint(0, self.expert_sa.size(0), (batch_size,))
        return self.expert_sa[idx]

    def train_policy_with_discriminator(self):
        # Replace rewards with discriminator rewards
        self.ppo_agent.buffer.rewards = [-torch.log(1 - self.disc(
            torch.tensor(self.ppo_agent.buffer.states[i], dtype=torch.float32).to(device),
            torch.nn.functional.one_hot(torch.tensor(self.ppo_agent.buffer.actions[i], dtype=torch.long).to(device), num_classes=action_dim).float()).item()
                                          for i in range(len(self.ppo_agent.buffer.states))]
        self.ppo_agent.update()

# Helper
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Step 1: Train PPO to solve environment
ppo_agent = PPOAgent()
solved = False
reward_history = deque(maxlen=SOLVED_CONSEC)
for ep in range(MAX_EPISODES):
    state = env.reset()
    ep_reward = 0
    for t in range(MAX_STEPS):
        action, logprob, value = ppo_agent.select_action(state)
        next_state, reward, done, _ = env.step(action)
        ppo_agent.buffer.add(state, action, logprob, reward, value, float(done))
        state = next_state
        ep_reward += reward
        if done:
            break
    ppo_agent.update()
    reward_history.append(ep_reward)
    if len(reward_history) == SOLVED_CONSEC and sum(reward_history) / SOLVED_CONSEC >= SOLVED_REWARD:
        solved = True
        print(f"PPO solved at episode {ep+1}")
        break
if not solved:
    print("PPO did not solve within episode limit.")

# Step 2: Generate expert trajectories
expert_states, expert_actions = generate_expert_data(ppo_agent, EXPERT_EPISODES)
print(f"Generated {len(expert_states)} expert transitions.")

# Step 3: Initialize GAIL
discriminator = Discriminator(state_dim, action_dim).to(device)
gail_agent = GAILAgent(ppo_agent, discriminator, expert_states, expert_actions)

# Step 4: GAIL training loop
smoothed_rewards = deque(maxlen=10)
for ep in range(MAX_EPISODES):
    state = env.reset()
    ep_reward = 0
    for t in range(MAX_STEPS):
        action, logprob, value = gail_agent.ppo_agent.select_action(state)
        next_state, _, done, _ = env.step(action)
        gail_agent.ppo_agent.buffer.add(state, action, logprob, 0.0, value, float(done))  # reward placeholder
        state = next_state
        ep_reward += 0  # placeholder
        if done:
            break
    # Compute discriminator reward
    gail_agent.train_policy_with_discriminator()
    gail_agent.train_discriminator()
    smoothed_rewards.append(ep_reward)
    avg_reward = np.mean(smoothed_rewards)
    if len(smoothed_rewards) == SOLVED_CONSEC and avg_reward >= SOLVED_REWARD:
        print(f"GAIL solved at episode {ep+1}")
        break
    if ep % 10 == 0:
        print(f"Episode {ep+1} finished. Avg reward: {avg_reward:.2f}")

print("Training completed.")
