import unittest
import numpy as np
import tensorflow as tf
from tf_agents.environments import py_environment
from tf_agents.environments import wrappers
from tf_agents.environments import external_process
from tf_agents.environments import tf_py_environment
from tf_agents.specs import array_spec
from tf_agents.trajectories import time_step as ts
from tf_agents.trajectories import step_type as st


class MockPyEnvironment(py_environment.PyEnvironment):
    def __init__(self, observation_shape, action_shape, duration, crash_on_step=None):
        super().__init__()
        self.observation_spec = array_spec.ArraySpec(
            shape=observation_shape, dtype=np.float32, name='observation')
        self.action_spec = array_spec.ArraySpec(
            shape=action_shape, dtype=np.int32, name='action')
        self.duration = duration
        self.crash_on_step = crash_on_step
        self._step_counter = 0
        self._reset_called = False

    def _reset(self):
        self._step_counter = 0
        self._reset_called = True
        obs = np.zeros(self.observation_spec.shape, dtype=np.float32)
        return ts.restart(obs)

    def _step(self, action):
        if not self._reset_called:
            raise RuntimeError("Environment not reset")
        self._step_counter += 1
        if self.crash_on_step is not None and self._step_counter == self.crash_on_step:
            raise RuntimeError("Crash on step {}".format(self.crash_on_step))
        if self._step_counter >= self.duration:
            obs = np.zeros(self.observation_spec.shape, dtype=np.float32)
            return ts.termination(obs, reward=0.0)
        obs = np.full(self.observation_spec.shape, self._step_counter, dtype=np.float32)
        return ts.transition(obs, reward=1.0, discount=1.0)


class ExternalProcessTest(unittest.TestCase):
    def test_initialization_and_closure(self):
        env = MockPyEnvironment(
            observation_shape=(3,),
            action_shape=(2,),
            duration=5)
        wrapped = external_process.ExternalProcess(env)
        wrapped.close()

    def test_closure_after_steps(self):
        env = MockPyEnvironment(
            observation_shape=(4,),
            action_shape=(1,),
            duration=10)
        wrapped = external_process.ExternalProcess(env)
        ts_obj = wrapped.reset()
        self.assertEqual(ts_obj.step_type, st.FIRST)
        for _ in range(2):
            action = wrapped.action_spec.sample()
            ts_obj = wrapped.step(action)
            self.assertIn(ts_obj.step_type, [st.MID, st.LAST])
        wrapped.close()

    def test_exception_reraising_during_initialization(self):
        class InitCrashEnv(py_environment.PyEnvironment):
            def __init__(self, *args, **kwargs):
                raise RuntimeError("Initialization failed")

            def observation_spec(self):
                return array_spec.ArraySpec(shape=(1,), dtype=np.float32)

            def action_spec(self):
                return array_spec.ArraySpec(shape=(1,), dtype=np.int32)

            def _reset(self):
                pass

            def _step(self, action):
                pass

        with self.assertRaises(RuntimeError) as ctx:
            external_process.ExternalProcess(InitCrashEnv())
        self.assertIn("Initialization failed", str(ctx.exception))

    def test_exception_reraising_during_step_execution(self):
        env = MockPyEnvironment(
            observation_shape=(2,),
            action_shape=(1,),
            duration=5,
            crash_on_step=3)
        wrapped = external_process.ExternalProcess(env)
        wrapped.reset()
        # Two steps that should succeed
        for _ in range(2):
            action = wrapped.action_spec.sample()
            wrapped.step(action)
        # Third step should raise
        with self.assertRaises(RuntimeError) as ctx:
            wrapped.step(wrapped.action_spec.sample())
        self.assertIn("Crash on step 3", str(ctx.exception))
        wrapped.close()


if __name__ == "__main__":
    unittest.main()
