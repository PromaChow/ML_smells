import numpy as np
from gymnasium.spaces import Space


class PortfolioVector(Space):
    """
    Custom Gym Space representing a portfolio weight vector.

    Attributes
    ----------
    num_instruments : int
        Number of instruments in the portfolio.
    low : np.ndarray
        Lower bounds of the space (negative infinity).
    high : np.ndarray
        Upper bounds of the space (positive infinity).
    """

    def __init__(self, num_instruments: int):
        self.num_instruments = int(num_instruments)
        shape = (self.num_instruments,)
        self.low = np.full(shape, -np.inf, dtype=np.float64)
        self.high = np.full(shape, np.inf, dtype=np.float64)
        super().__init__(self.low, self.high)

    @property
    def shape(self):
        return self.low.shape

    def sample(self):
        vec = np.random.uniform(low=0.0, high=1.0, size=self.num_instruments)
        vec_sum = vec.sum()
        if vec_sum == 0:
            # Fall back to uniform distribution if sum is zero (extremely unlikely)
            vec = np.full(self.num_instruments, 1.0 / self.num_instruments, dtype=np.float64)
        else:
            vec = vec / vec_sum
        return vec

    def contains(self, x, tolerance: float = 1e-5):
        try:
            x_arr = np.asarray(x, dtype=np.float64)
        except Exception:
            return False
        if x_arr.shape != self.shape:
            return False
        if not np.all(x_arr >= self.low) or not np.all(x_arr <= self.high):
            return False
        if not np.isclose(x_arr.sum(), 1.0, atol=tolerance):
            return False
        return True

    def __repr__(self):
        return f"PortfolioVector({self.num_instruments},)"

    def __eq__(self, other):
        if not isinstance(other, PortfolioVector):
            return False
        return np.allclose(self.low, other.low, atol=1e-12) and np.allclose(self.high, other.high, atol=1e-12)
