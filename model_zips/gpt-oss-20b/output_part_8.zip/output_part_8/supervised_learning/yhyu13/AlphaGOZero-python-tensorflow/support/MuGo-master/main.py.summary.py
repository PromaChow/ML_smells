import argparse
import contextlib
import json
import os
import random
import re
import sys
import time
from pathlib import Path

import argh

# Regular expression for training chunk filenames
TRAINING_CHUNK_RE = re.compile(r"train(\d+)\.chunk\.gz")


@contextlib.contextmanager
def timer(label: str):
    """Context manager that times a block of code and prints elapsed time."""
    start = time.perf_counter()
    try:
        yield
    finally:
        elapsed = time.perf_counter() - start
        print(f"[{label}] elapsed: {elapsed:.2f}s")


class DataSet:
    """Simple dataset representation that can be serialized to a gzip-compressed JSON file."""

    def __init__(self, data=None):
        self.data = data or []

    def shuffle(self):
        random.shuffle(self.data)

    def save(self, path: Path):
        with gzip_open(path, "wt") as f:
            json.dump(self.data, f)

    @staticmethod
    def load(path: Path):
        with gzip_open(path, "rt") as f:
            data = json.load(f)
        return DataSet(data)


def gzip_open(path, mode):
    import gzip
    return gzip.open(path, mode)


def parse_data_sets(paths):
    """
    Very simple parser that reads all lines from the provided files,
    concatenates them, and splits into a test set (10%) and multiple
    training chunks (remaining 90% split into 10-element chunks).
    """
    all_lines = []
    for p in paths:
        with open(p, "r", encoding="utf-8") as f:
            all_lines.extend([line.strip() for line in f if line.strip()])
    random.shuffle(all_lines)
    test_size = max(1, int(0.1 * len(all_lines)))
    test_chunk = DataSet(all_lines[:test_size])
    remaining = all_lines[test_size:]
    # Split remaining into chunks of 1000 lines each
    train_chunks = []
    chunk_size = 1000
    for i in range(0, len(remaining), chunk_size):
        train_chunks.append(DataSet(remaining[i : i + chunk_size]))
    return test_chunk, train_chunks


def preprocess(datasets, processed_dir):
    """
    Preprocess input datasets into a test chunk and multiple training chunks.
    """
    processed_path = Path(processed_dir)
    processed_path.mkdir(parents=True, exist_ok=True)

    test_chunk, train_chunks = parse_data_sets(datasets)

    # Save test chunk
    test_path = processed_path / "test.chunk.gz"
    with timer("save test chunk"):
        test_chunk.save(test_path)

    # Save training chunks
    for idx, chunk in enumerate(train_chunks, start=1):
        train_path = processed_path / f"train{idx}.chunk.gz"
        with timer(f"save training chunk {idx}"):
            chunk.save(train_path)


class PolicyNetwork:
    """Mock policy network that tracks training steps and can evaluate accuracy."""

    def __init__(self):
        self.steps = 0

    def load_vars(self, file_path):
        if os.path.exists(file_path):
            with open(file_path, "r", encoding="utf-8") as f:
                self.steps = int(f.read().strip())
            print(f"[PolicyNetwork] Loaded {self.steps} training steps from {file_path}")

    def init_vars(self):
        self.steps = 0
        print("[PolicyNetwork] Initialized variables from scratch")

    def train(self, dataset: DataSet):
        # Dummy training: increment step count by number of examples divided by 1000
        self.steps += max(1, len(dataset.data) // 1000)
        # Simulate training time
        time.sleep(0.01)

    def check_accuracy(self, test_dataset: DataSet):
        # Dummy accuracy: random value between 0 and 1
        acc = random.random()
        print(f"[PolicyNetwork] Accuracy on test set: {acc:.4f}")
        return acc

    def save_vars(self, file_path):
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(str(self.steps))
        print(f"[PolicyNetwork] Saved {self.steps} training steps to {file_path}")


def train(processed_dir, epochs, checkpoint_freq, save_file, logdir=None):
    processed_path = Path(processed_dir)

    # Load test dataset
    test_path = processed_path / "test.chunk.gz"
    if not test_path.exists():
        raise FileNotFoundError(f"Test dataset not found at {test_path}")
    with timer("load test dataset"):
        test_dataset = DataSet.load(test_path)

    # Find all training chunk files
    train_files = sorted(
        [p for p in processed_path.iterdir() if TRAINING_CHUNK_RE.match(p.name)]
    )
    if not train_files:
        raise FileNotFoundError("No training chunks found in processed directory")

    # Initialize policy network
    n = PolicyNetwork()
    if os.path.exists(save_file):
        n.load_vars(save_file)
    else:
        n.init_vars()

    # Simple logging placeholder
    if logdir:
        log_path = Path(logdir)
        log_path.mkdir(parents=True, exist_ok=True)
        log_file = log_path / "training.log"

    # Training loop
    for epoch in range(1, epochs + 1):
        print(f"[Epoch {epoch}/{epochs}]")
        random.shuffle(train_files)
        step = 0
        for file_path in train_files:
            with timer(f"load {file_path.name}"):
                dataset = DataSet.load(file_path)
                dataset.shuffle()
            n.train(dataset)
            n.save_vars(save_file)
            step += 1
            if step % checkpoint_freq == 0:
                n.check_accuracy(test_dataset)
                if logdir:
                    with open(log_file, "a", encoding="utf-8") as lf:
                        lf.write(f"Epoch {epoch}, Step {step}: Accuracy {n.check_accuracy(test_dataset):.4f}\n")
    print("[Training] Completed")


def make_gtp_instance(strategy, input_file=None):
    """Mock GTP engine that echoes commands with a prefix."""
    class GTPEngine:
        def __init__(self, strategy, input_file):
            self.strategy = strategy
            self.input_file = input_file

        def handle(self, command):
            # Simulate a disconnect after receiving "quit"
            if command.strip() == "quit":
                return None
            return f"+ {self.strategy} received: {command.strip()}"

    return GTPEngine(strategy, input_file)


def gtp(strategy, input_file=None):
    engine = make_gtp_instance(strategy, input_file)
    for line in sys.stdin:
        line = line.rstrip("\n")
        if not line:
            continue
        response = engine.handle(line)
        if response is None:
            print("=-\n", flush=True)
            break
        print(f"={response}\n", flush=True)


def main():
    parser = argparse.ArgumentParser(description="Policy network training workflow.")
    subparsers = parser.add_subparsers(dest="command")
    argh.add_commands(parser, [gtp, preprocess, train])

    args = parser.parse_args()
    if not hasattr(args, "func"):
        parser.print_help()
        sys.exit(1)
    args.func(**vars(args))


if __name__ == "__main__":
    main()
