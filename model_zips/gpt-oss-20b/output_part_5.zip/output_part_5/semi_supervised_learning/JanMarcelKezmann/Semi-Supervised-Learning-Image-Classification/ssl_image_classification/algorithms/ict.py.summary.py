import tensorflow as tf

# ----------------------------------------------------------------------
# Augmentation utilities
# ----------------------------------------------------------------------
def weak_augment(x: tf.Tensor, height: int, width: int) -> tf.Tensor:
    """Apply weak augmentation: random horizontal flip."""
    x = tf.image.random_flip_left_right(x)
    x = tf.image.resize(x, [height, width])
    return x

def medium_augment(x: tf.Tensor, height: int, width: int) -> tf.Tensor:
    """Apply medium augmentation: random flip, crop, brightness, contrast."""
    x = tf.image.random_flip_left_right(x)
    # Random crop and resize back to original size
    x = tf.image.random_crop(x, size=[tf.shape(x)[0], height, width, tf.shape(x)[-1]])
    x = tf.image.resize(x, [height, width])
    x = tf.image.random_brightness(x, max_delta=0.1)
    x = tf.image.random_contrast(x, lower=0.9, upper=1.1)
    return x

# ----------------------------------------------------------------------
# Semi-supervised augmentation pipeline
# ----------------------------------------------------------------------
def ict(x: tf.Tensor, u: tf.Tensor, height: int, width: int):
    """
    Apply augmentation strategies to labeled and unlabeled data.

    Args:
        x: Labeled input tensor of shape [batch, h, w, c].
        u: Unlabeled input tensor of shape [batch, h, w, c].
        height: Desired height after augmentation.
        width: Desired width after augmentation.

    Returns:
        x_augment: Augmented labeled data.
        u_teacher: Weakly augmented unlabeled data for teacher.
        u_student: Medium augmented unlabeled data for student.
    """
    x_augment = medium_augment(x, height, width)
    u_teacher = weak_augment(u, height, width)
    u_student = medium_augment(u, height, width)
    return x_augment, u_teacher, u_student

# ----------------------------------------------------------------------
# Loss computation
# ----------------------------------------------------------------------
def ssl_loss_ict(
    labels_x: tf.Tensor,
    logits_x: tf.Tensor,
    labels_teacher: tf.Tensor,
    logits_student: tf.Tensor
):
    """
    Compute labeled and unlabeled losses for semi-supervised learning.

    Args:
        labels_x: Integer labels for labeled data (shape [batch]).
        logits_x: Logits from model for labeled data (shape [batch, num_classes]).
        labels_teacher: Logits from teacher model for unlabeled data
                        (shape [batch, num_classes]).
        logits_student: Logits from student model for unlabeled data
                        (shape [batch, num_classes]).

    Returns:
        x_loss: Mean softmax cross‑entropy for labeled data.
        ict_loss: Mean squared error between teacher predictions and
                  student softmax outputs.
    """
    # Labeled loss: cross‑entropy
    x_loss = tf.reduce_mean(
        tf.nn.sparse_softmax_cross_entropy_with_logits(
            labels=labels_x, logits=logits_x
        )
    )

    # Unlabeled loss: MSE between teacher logits and student softmax
    student_softmax = tf.nn.softmax(logits_student, axis=-1)
    ict_loss = tf.reduce_mean(
        tf.keras.losses.mean_squared_error(labels_teacher, student_softmax)
    )

    return x_loss, ict_loss

# ----------------------------------------------------------------------
# Example usage (for demonstration purposes)
# ----------------------------------------------------------------------
if __name__ == "__main__":
    # Dummy data
    batch, h, w, c = 4, 128, 128, 3
    num_classes = 10
    x = tf.random.uniform([batch, h, w, c], dtype=tf.float32)
    u = tf.random.uniform([batch, h, w, c], dtype=tf.float32)
    labels_x = tf.random.uniform([batch], maxval=num_classes, dtype=tf.int32)

    # Augmentations
    x_aug, u_teacher_aug, u_student_aug = ict(x, u, h, w)

    # Dummy model outputs
    logits_x = tf.random.normal([batch, num_classes])
    logits_teacher = tf.random.normal([batch, num_classes])
    logits_student = tf.random.normal([batch, num_classes])

    # Losses
    x_loss, ict_loss = ssl_loss_ict(labels_x, logits_x, logits_teacher, logits_student)
    print("Labeled loss:", x_loss.numpy())
    print("Unlabeled loss:", ict_loss.numpy())