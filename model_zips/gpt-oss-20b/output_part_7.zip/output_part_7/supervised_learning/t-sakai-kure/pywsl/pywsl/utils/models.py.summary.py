import chainer
import chainer.functions as F
import chainer.links as L
from chainer import Chain


class TLP(Chain):
    def __init__(self, input_size):
        super().__init__()
        with self.init_scope():
            self.l1 = L.Linear(input_size, 100)
            self.l2 = L.Linear(100, 1)

    def __call__(self, x):
        h = self.l1(x)
        h = F.relu(h)
        return self.l2(h)


class MLP(Chain):
    def __init__(self, input_size):
        super().__init__()
        with self.init_scope():
            self.l1 = L.Linear(input_size, 100)
            self.b1 = L.BatchNormalization(100)
            self.l2 = L.Linear(100, 100)
            self.b2 = L.BatchNormalization(100)
            self.l3 = L.Linear(100, 100)
            self.b3 = L.BatchNormalization(100)
            self.l4 = L.Linear(100, 1)

    def __call__(self, x):
        h = self.l1(x)
        h = self.b1(h)
        h = F.relu(h)

        h = self.l2(h)
        h = self.b2(h)
        h = F.relu(h)

        h = self.l3(h)
        h = self.b3(h)
        h = F.relu(h)

        return self.l4(h)


class CNN(Chain):
    def __init__(self, input_channels=3):
        super().__init__()
        with self.init_scope():
            # Convolutional layers
            self.conv1 = L.Convolution2D(input_channels, 64, ksize=3, stride=1, pad=1)
            self.b1 = L.BatchNormalization(64)
            self.conv2 = L.Convolution2D(64, 128, ksize=3, stride=1, pad=1)
            self.b2 = L.BatchNormalization(128)
            self.conv3 = L.Convolution2D(128, 256, ksize=3, stride=2, pad=1)
            self.b3 = L.BatchNormalization(256)
            self.conv4 = L.Convolution2D(256, 256, ksize=3, stride=1, pad=1)
            self.b4 = L.BatchNormalization(256)
            self.conv5 = L.Convolution2D(256, 512, ksize=3, stride=1, pad=1)
            self.b5 = L.BatchNormalization(512)
            self.conv6 = L.Convolution2D(512, 512, ksize=3, stride=2, pad=1)
            self.b6 = L.BatchNormalization(512)
            self.conv7 = L.Convolution2D(512, 512, ksize=3, stride=1, pad=1)
            self.b7 = L.BatchNormalization(512)
            self.conv8 = L.Convolution2D(512, 512, ksize=3, stride=1, pad=1)
            self.b8 = L.BatchNormalization(512)
            self.conv9 = L.Convolution2D(512, 512, ksize=3, stride=1, pad=1)
            self.b9 = L.BatchNormalization(512)

            # Fully connected layers
            # Assuming input image size 224x224, the final feature map is 56x56x512
            self.fc1 = L.Linear(512 * 56 * 56, 1000)
            self.fc2 = L.Linear(1000, 1000)
            self.fc3 = L.Linear(1000, 1)

    def __call__(self, x):
        h = self.conv1(x)
        h = self.b1(h)
        h = F.relu(h)

        h = self.conv2(h)
        h = self.b2(h)
        h = F.relu(h)

        h = self.conv3(h)
        h = self.b3(h)
        h = F.relu(h)

        h = self.conv4(h)
        h = self.b4(h)
        h = F.relu(h)

        h = self.conv5(h)
        h = self.b5(h)
        h = F.relu(h)

        h = self.conv6(h)
        h = self.b6(h)
        h = F.relu(h)

        h = self.conv7(h)
        h = self.b7(h)
        h = F.relu(h)

        h = self.conv8(h)
        h = self.b8(h)
        h = F.relu(h)

        h = self.conv9(h)
        h = self.b9(h)
        h = F.relu(h)

        h = F.reshape(h, (h.shape[0], -1))
        h = self.fc1(h)
        h = F.relu(h)
        h = self.fc2(h)
        h = F.relu(h)
        return self.fc3(h)