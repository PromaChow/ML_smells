import numpy as np
import chainer
from chainer.dataset import TupleDataset, concat_examples
from chainer.iterators import SerialIterator
from chainer.backends.cuda import to_cpu


def pred(model, x, batchsize):
    x = np.array(x, dtype=np.float32)
    tmp = np.ones(len(x), dtype=np.int32)
    dataset = TupleDataset(x, tmp)
    iterator = SerialIterator(dataset, batchsize, shuffle=False, repeat=False)

    preds = []

    with chainer.no_backprop_mode():
        with chainer.using_config('train', False):
            for batch in iterator:
                x_batch, _ = batch
                x_gpu = concat_examples([x_batch], device=0)
                y = model.predictor(x_gpu)
                y_cpu = to_cpu(y.array)
                preds.append(y_cpu)

    if preds:
        h = np.concatenate(preds, axis=0)
    else:
        h = np.array([], dtype=np.float32)
    return h