import copy
import numpy as np
from collections import deque
from dataclasses import dataclass, field
from typing import Dict, List, Set, Tuple

# Constants
EMPTY = 0
BLACK = 1
WHITE = -1
KO = 2

# Global board parameters
N: int = 0
ALL_COORDS: List[Tuple[int, int]] = []
NEIGHBORS: Dict[Tuple[int, int], List[Tuple[int, int]]] = {}
DIAGONALS: Dict[Tuple[int, int], List[Tuple[int, int]]] = {}

def set_board_size(n: int) -> None:
    global N, ALL_COORDS, NEIGHBORS, DIAGONALS
    N = n
    ALL_COORDS = [(x, y) for x in range(N) for y in range(N)]
    NEIGHBORS = {}
    DIAGONALS = {}
    for x in range(N):
        for y in range(N):
            neighbors = []
            diagonals = []
            for dx, dy in [(-1,0),(1,0),(0,-1),(0,1)]:
                nx, ny = x+dx, y+dy
                if 0 <= nx < N and 0 <= ny < N:
                    neighbors.append((nx, ny))
            for dx, dy in [(-1,-1),(-1,1),(1,-1),(1,1)]:
                nx, ny = x+dx, y+dy
                if 0 <= nx < N and 0 <= ny < N:
                    diagonals.append((nx, ny))
            NEIGHBORS[(x, y)] = neighbors
            DIAGONALS[(x, y)] = diagonals

@dataclass
class Group:
    color: int
    stones: Set[Tuple[int, int]] = field(default_factory=set)
    liberties: Set[Tuple[int, int]] = field(default_factory=set)

class LibertyTracker:
    def __init__(self, board: np.ndarray):
        self.board = board
        self.stone_to_group: Dict[Tuple[int, int], Group] = {}
        self.groups: List[Group] = []

    @classmethod
    def from_board(cls, board: np.ndarray) -> 'LibertyTracker':
        tracker = cls(board)
        visited = set()
        for coord in ALL_COORDS:
            if coord in visited:
                continue
            color = board[coord]
            if color == EMPTY:
                continue
            stones, liberties = find_reached(board, coord)
            visited.update(stones)
            group = Group(color=color, stones=stones, liberties=liberties)
            tracker.groups.append(group)
            for s in stones:
                tracker.stone_to_group[s] = group
        return tracker

    def add_stone(self, color: int, coord: Tuple[int, int]) -> Tuple[int, int, Set[Tuple[int, int]]]:
        """Place stone, merge groups, capture opponents. Return (captured_count, ko_coord, captured_stones)"""
        captured_count = 0
        captured_stones = set()
        new_group = Group(color=color, stones={coord})
        new_liberties = set()
        for n in NEIGHBORS[coord]:
            if self.board[n] == EMPTY:
                new_liberties.add(n)
        new_group.liberties = new_liberties
        self.groups.append(new_group)
        self.stone_to_group[coord] = new_group
        self.board[coord] = color

        # Merge with same color neighbors
        same_groups = set()
        for n in NEIGHBORS[coord]:
            if self.board[n] == color:
                same_groups.add(self.stone_to_group[n])
        for sg in same_groups:
            if sg is new_group:
                continue
            sg.stones.update(new_group.stones)
            sg.liberties.update(new_group.liberties)
            for s in new_group.stones:
                self.stone_to_group[s] = sg
            self.groups.remove(new_group)
            new_group = sg
        new_group.liberties.discard(coord)

        # Update liberties of opposite color groups adjacent
        opp_color = -color
        ko_coord = None
        for n in NEIGHBORS[coord]:
            if self.board[n] == opp_color:
                opp_group = self.stone_to_group[n]
                opp_group.liberties.discard(coord)
                if not opp_group.liberties:
                    # Capture
                    for s in opp_group.stones:
                        self.board[s] = EMPTY
                    captured_stones.update(opp_group.stones)
                    captured_count += len(opp_group.stones)
                    self.groups.remove(opp_group)
                    for s in opp_group.stones:
                        del self.stone_to_group[s]
                    if len(opp_group.stones) == 1:
                        ko_coord = list(opp_group.stones)[0]

        # Update liberties of adjacent groups of same color
        for n in NEIGHBORS[coord]:
            if self.board[n] == color:
                self.stone_to_group[n].liberties.discard(coord)

        return captured_count, ko_coord, captured_stones

def find_reached(board: np.ndarray, start: Tuple[int, int]) -> Tuple[Set[Tuple[int, int]], Set[Tuple[int, int]]]:
    """Return group stones and liberties."""
    color = board[start]
    visited = set()
    liberties = set()
    queue = deque([start])
    while queue:
        c = queue.popleft()
        if c in visited:
            continue
        visited.add(c)
        for n in NEIGHBORS[c]:
            if board[n] == EMPTY:
                liberties.add(n)
            elif board[n] == color and n not in visited:
                queue.append(n)
    return visited, liberties

def is_koish(board: np.ndarray, coord: Tuple[int, int]) -> bool:
    """Placeholder: detect simple ko by checking if capture results in same board state."""
    return False

def is_eyeish(board: np.ndarray, coord: Tuple[int, int], color: int) -> bool:
    """Placeholder: simple eye detection."""
    if board[coord] != EMPTY:
        return False
    opp = -color
    for n in NEIGHBORS[coord]:
        if board[n] != opp:
            return False
    return True

class Position:
    def __init__(self, board: np.ndarray = None):
        if board is None:
            board = np.zeros((N, N), dtype=np.int8)
        self.board = board
        self.tracker = LibertyTracker.from_board(self.board)
        self.captures = {BLACK: 0, WHITE: 0}
        self.ko_coord: Tuple[int, int] = None
        self.player = BLACK
        self.history: List[np.ndarray] = [self.board.copy()]
        self.recent_states: List[np.ndarray] = [self.board.copy()]

    def is_move_legal(self, coord: Tuple[int, int]) -> bool:
        if self.board[coord] != EMPTY:
            return False
        if coord == self.ko_coord:
            return False
        temp_board = self.board.copy()
        temp_tracker = LibertyTracker.from_board(temp_board)
        captured, ko, _ = temp_tracker.add_stone(self.player, coord)
        if not captured:
            # check suicide
            group = temp_tracker.stone_to_group[coord]
            if not group.liberties:
                return False
        return True

    def play_move(self, coord: Tuple[int, int]) -> None:
        if not self.is_move_legal(coord):
            raise ValueError("Illegal move")
        captured, ko, captured_stones = self.tracker.add_stone(self.player, coord)
        self.captures[self.player] += captured
        self.ko_coord = ko if captured == 1 else None
        self.player = -self.player
        self.history.append(self.board.copy())
        self.recent_states.append(self.board.copy())
        if len(self.recent_states) > 8:
            self.recent_states.pop(0)

    def pass_move(self) -> None:
        self.player = -self.player
        self.history.append(self.board.copy())
        self.recent_states.append(self.board.copy())
        if len(self.recent_states) > 8:
            self.recent_states.pop(0)

    def score(self, komi: float = 7.5) -> float:
        visited = set()
        territory = {BLACK: 0, WHITE: 0}
        for coord in ALL_COORDS:
            if coord in visited or self.board[coord] != EMPTY:
                continue
            region = set()
            border_colors = set()
            queue = deque([coord])
            while queue:
                c = queue.popleft()
                if c in visited:
                    continue
                visited.add(c)
                region.add(c)
                for n in NEIGHBORS[c]:
                    if self.board[n] == EMPTY:
                        if n not in visited:
                            queue.append(n)
                    else:
                        border_colors.add(self.board[n])
            if len(border_colors) == 1:
                owner = border_colors.pop()
                territory[owner] += len(region)
        return territory[BLACK] - (territory[WHITE] + komi)

    def result(self, komi: float = 7.5) -> str:
        diff = self.score(komi)
        if diff > 0:
            return f"B+{diff:.1f}"
        elif diff < 0:
            return f"W+{-diff:.1f}"
        else:
            return "DRAW"

    def __deepcopy__(self, memo):
        new_pos = Position(self.board.copy())
        new_pos.tracker = LibertyTracker.from_board(new_pos.board)
        new_pos.captures = self.captures.copy()
        new_pos.ko_coord = self.ko_coord
        new_pos.player = self.player
        new_pos.history = [h.copy() for h in self.history]
        new_pos.recent_states = [h.copy() for h in self.recent_states]
        return new_pos

# Initialize default board
set_board_size(19)

if __name__ == "__main__":
    pos = Position()
    # Example moves
    pos.play_move((3, 3))
    pos.play_move((16, 16))
    print(pos.score())
    print(pos.result())
    pos.pass_move()
    print(pos.player)  # Should switch back to BLACK
    print("Game history length:", len(pos.history))
    # Deep copy test
    pos2 = copy.deepcopy(pos)
    pos2.play_move((3, 4))
    print(pos2.score())
    print(pos.score())  # Should be unchanged from original state
