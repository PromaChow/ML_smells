import numpy as np

np.random.seed(0)

weights_dense1_w = np.random.randn(128, 128) * 0.01
weights_dense1_b = np.random.randn(128) * 0.01

weights_dense2_w = np.random.randn(128, 128) * 0.01
weights_dense2_b = np.random.randn(128) * 0.01

weights_final_w = np.random.randn(8, 128) * 0.01
weights_final_b = np.random.randn(8) * 0.01


def forward(input_data: np.ndarray) -> np.ndarray:
    out1 = np.dot(input_data, weights_dense1_w) + weights_dense1_b
    out2 = np.dot(out1, weights_dense2_w) + weights_dense2_b
    out_final = np.dot(out2, weights_final_w.T) + weights_final_b
    return out_final


def main() -> None:
    sample_input = np.random.randn(1, 128)
    output = forward(sample_input)
    print("Model output:", output)


if __name__ == "__main__":
    main()