import math
import torch
import torch.nn as nn
import torch.optim as optim
import torch.autograd as autograd
from collections import deque
import random

# -------------------------------------------
# Simple replay buffer
# -------------------------------------------

class ReplayBuffer:
    def __init__(self, capacity):
        self.capacity = capacity
        self.buffer = deque(maxlen=capacity)

    def push(self, state, action, reward, next_state, done, logp, value, advantage, target_value):
        self.buffer.append((state, action, reward, next_state, done, logp, value, advantage, target_value))

    def sample(self, batch_size):
        batch = random.sample(self.buffer, batch_size)
        states, actions, rewards, next_states, dones, logps, values, advantages, target_values = map(
            list, zip(*batch)
        )
        return (
            torch.stack(states),
            torch.stack(actions),
            torch.stack(rewards).unsqueeze(1),
            torch.stack(next_states),
            torch.tensor(dones, dtype=torch.float32).unsqueeze(1),
            torch.stack(logps),
            torch.stack(values).unsqueeze(1),
            torch.stack(advantages).unsqueeze(1),
            torch.stack(target_values).unsqueeze(1),
        )

    def __len__(self):
        return len(self.buffer)

# -------------------------------------------
# Policy network (Gaussian)
# -------------------------------------------

class Actor(nn.Module):
    def __init__(self, state_dim, action_dim, hidden_sizes=[64, 64]):
        super().__init__()
        layers = []
        last_size = state_dim
        for h in hidden_sizes:
            layers.append(nn.Linear(last_size, h))
            layers.append(nn.Tanh())
            last_size = h
        self.mean_layer = nn.Linear(last_size, action_dim)
        self.log_std = nn.Parameter(torch.zeros(action_dim))
        self.net = nn.Sequential(*layers)

    def forward(self, state):
        x = self.net(state)
        mean = self.mean_layer(x)
        std = torch.exp(self.log_std)
        return mean, std

    def get_action(self, state):
        mean, std = self.forward(state)
        dist = torch.distributions.Normal(mean, std)
        action = dist.sample()
        logp = dist.log_prob(action).sum(-1, keepdim=True)
        return action, logp

    def log_prob(self, state, action):
        mean, std = self.forward(state)
        dist = torch.distributions.Normal(mean, std)
        return dist.log_prob(action).sum(-1, keepdim=True)

# -------------------------------------------
# Value network
# -------------------------------------------

class Critic(nn.Module):
    def __init__(self, state_dim, hidden_sizes=[64, 64]):
        super().__init__()
        layers = []
        last_size = state_dim
        for h in hidden_sizes:
            layers.append(nn.Linear(last_size, h))
            layers.append(nn.Tanh())
            last_size = h
        layers.append(nn.Linear(last_size, 1))
        self.net = nn.Sequential(*layers)

    def forward(self, state):
        return self.net(state)

# -------------------------------------------
# Base A2C implementation (minimal)
# -------------------------------------------

class A2C:
    def __init__(self, state_dim, action_dim, config=None):
        self.actor = Actor(state_dim, action_dim)
        self.critic = Critic(state_dim)
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=config.get("actor_lr", 3e-4))
        self.critic_optimizer = optim.Adam(self.critic.parameters(), lr=config.get("critic_lr", 1e-3))
        self.buffer = ReplayBuffer(config.get("buffer_capacity", 100000))
        self.adv_norm = config.get("adv_norm", False)

    def update(self):
        # Placeholder for base update
        pass

# -------------------------------------------
# Helper functions
# -------------------------------------------

def get_flat_params_from(model):
    return torch.cat([p.view(-1) for p in model.parameters()])

def set_flat_params_to(model, flat_params):
    prev_idx = 0
    for p in model.parameters():
        numel = p.numel()
        p.data.copy_(flat_params[prev_idx:prev_idx + numel].view_as(p))
        prev_idx += numel

def get_flat_grad(loss, model, retain_graph=False):
    grads = autograd.grad(loss, model.parameters(), retain_graph=retain_graph, allow_unused=True)
    return torch.cat([g.contiguous().view(-1) if g is not None else torch.zeros_like(p).view(-1)
                      for g, p in zip(grads, model.parameters())])

# -------------------------------------------
# Conjugate gradient solver
# -------------------------------------------

def conjugate_gradient(Ax, b, iters=10, residual_tol=1e-10):
    x = torch.zeros_like(b)
    r = b.clone()
    p = b.clone()
    r_dot_r = torch.dot(r, r)
    for i in range(iters):
        Ap = Ax(p)
        alpha = r_dot_r / (torch.dot(p, Ap) + 1e-8)
        x += alpha * p
        r -= alpha * Ap
        new_r_dot_r = torch.dot(r, r)
        if new_r_dot_r < residual_tol:
            break
        beta = new_r_dot_r / (r_dot_r + 1e-8)
        p = r + beta * p
        r_dot_r = new_r_dot_r
    return x

# -------------------------------------------
# TRPO configuration generator
# -------------------------------------------

def generate_config():
    return {
        "kl_max_delta": 0.01,
        "damping": 0.1,
        "cg_iters": 10,
        "cg_tol": 1e-10,
        "max_backtracks": 10,
        "backtrack_coefficient": 0.8,
        "critic_update_times": 5,
        "max_grad_norm": 0.5,
        "fvp_mode": "direct",   # or "fim"
        "adv_norm": True,
        "actor_lr": 3e-4,
        "critic_lr": 1e-3,
        "buffer_capacity": 100000,
    }

# -------------------------------------------
# TRPO implementation
# -------------------------------------------

class TRPO(A2C):
    def __init__(self, state_dim, action_dim, config=None):
        if config is None:
            config = generate_config()
        super().__init__(state_dim, action_dim, config)
        self.config = config

    def _fvp(self, state_batch, flat_grad):
        # Compute Hessian-vector product using automatic differentiation
        mean, std = self.actor(state_batch)
        dist = torch.distributions.Normal(mean, std)
        logp = dist.log_prob(self.actor.last_action).sum(-1, keepdim=True)
        kl = dist.log_prob(self.actor.last_action).sum(-1, keepdim=True)
        kl_loss = kl.mean()
        grads = autograd.grad(kl_loss, self.actor.parameters(), create_graph=True)
        flat_grad_kl = torch.cat([g.contiguous().view(-1) if g is not None else torch.zeros_like(p).view(-1)
                                  for g, p in zip(grads, self.actor.parameters())])
        grad_vector_product = torch.dot(flat_grad_kl, flat_grad)
        hvp = autograd.grad(grad_vector_product, self.actor.parameters(), retain_graph=True)
        hvp_flat = torch.cat([g.contiguous().view(-1) if g is not None else torch.zeros_like(p).view(-1)
                              for g, p in zip(hvp, self.actor.parameters())])
        return hvp_flat + self.config["damping"] * flat_grad

    def _compute_policy_loss(self, states, actions, advantages, old_logp):
        new_logp = self.actor.log_prob(states, actions)
        ratio = torch.exp(new_logp - old_logp)
        loss = -(ratio * advantages).mean()
        return loss, new_logp

    def _line_search(self, states, actions, advantages, old_logp, full_step, old_params):
        step_fraction = 1.0
        for _ in range(self.config["max_backtracks"]):
            new_params = old_params + step_fraction * full_step
            set_flat_params_to(self.actor, new_params)
            with torch.no_grad():
                loss, new_logp = self._compute_policy_loss(states, actions, advantages, old_logp)
                kl = (old_logp - new_logp).mean()
            if kl <= self.config["kl_max_delta"]:
                return True
            step_fraction *= self.config["backtrack_coefficient"]
        set_flat_params_to(self.actor, old_params)
        return False

    def update(self):
        # Sample batch
        batch_size = self.config.get("batch_size", 64)
        states, actions, rewards, next_states, dones, old_logp, values, advantages, target_values = self.buffer.sample(batch_size)

        # Optionally normalize advantages
        if self.config["adv_norm"]:
            adv_mean = advantages.mean()
            adv_std = advantages.std() + 1e-8
            advantages = (advantages - adv_mean) / adv_std

        # ---------- Actor update ----------
        # Store old parameters
        old_params = get_flat_params_from(self.actor).detach()

        # Define function for Hessian-vector product
        def Fvp(vec):
            return self._fvp(states, vec)

        # Compute policy gradient
        policy_loss, new_logp = self._compute_policy_loss(states, actions, advantages, old_logp)
        policy_grad = get_flat_grad(policy_loss, self.actor)

        # Solve for step direction
        step_dir = conjugate_gradient(Fvp, policy_grad, iters=self.config["cg_iters"])

        # Compute step size
        shs = 0.5 * (step_dir * Fvp(step_dir)).sum()
        lm = torch.sqrt(shs / self.config["kl_max_delta"])
        full_step = step_dir / (lm + 1e-8)

        # Line search
        succeeded = self._line_search(states, actions, advantages, old_logp, full_step, old_params)

        # ---------- Critic update ----------
        for _ in range(self.config["critic_update_times"]):
            values_pred = self.critic(states)
            value_loss = nn.functional.mse_loss(values_pred, target_values)
            self.critic_optimizer.zero_grad()
            value_loss.backward()
            nn.utils.clip_grad_norm_(self.critic.parameters(), self.config["max_grad_norm"])
            self.critic_optimizer.step()
```