import argparse
import yaml
import json
import os
import pathlib
import sys
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models, applications, optimizers, losses, metrics
from tqdm.auto import tqdm

# ------------------------------------------------------------
# Utility functions
# ------------------------------------------------------------
def load_yaml(path):
    with open(path, "r") as f:
        return yaml.safe_load(f)

def merge_dicts(a, b):
    result = a.copy()
    for k, v in b.items():
        if isinstance(v, dict) and k in result:
            result[k] = merge_dicts(result[k], v)
        else:
            result[k] = v
    return result

def set_random_seed(seed):
    np.random.seed(seed)
    tf.random.set_seed(seed)

def get_current_time():
    return tf.timestamp()

# ------------------------------------------------------------
# Argument parsing and configuration
# ------------------------------------------------------------
def parse_args():
    parser = argparse.ArgumentParser(description="Semi-Supervised Learning Framework")
    parser.add_argument("--dataset", type=str, default="cifar10", help="Dataset name")
    parser.add_argument("--algorithm", type=str, default="mixmatch",
                        choices=["mixup", "mixmatch", "remixmatch", "fixmatch", "vat",
                                 "mean_teacher", "pseudo_label", "ict"])
    parser.add_argument("--model", type=str, default="EfficientNetB0",
                        help="Model architecture")
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--lr", type=float, default=0.01)
    parser.add_argument("--momentum", type=float, default=0.9)
    parser.add_argument("--weight-decay", type=float, default=5e-4)
    parser.add_argument("--num-lab-samples", type=int, default=4000)
    parser.add_argument("--val-samples", type=int, default=2000)
    parser.add_argument("--total-train-samples", type=int, default=50000)
    parser.add_argument("--uratio", type=float, default=3.0)
    parser.add_argument("--resume", action="store_true", help="Resume from latest checkpoint")
    parser.add_argument("--tensorboard", action="store_true", help="Enable TensorBoard")
    parser.add_argument("--config-path", type=str, default=None,
                        help="Path to YAML configuration file")
    parser.add_argument("--console-args", action="store_true", help="Parse args from console")
    return parser.parse_args() if not sys.argv[0].endswith(".py") or args.console_args else argparse.Namespace()

# ------------------------------------------------------------
# Dataset and data pipelines
# ------------------------------------------------------------
def fetch_dataset(dataset_name, num_lab_samples, val_samples, total_train_samples, batch_size):
    if dataset_name == "cifar10":
        (x_train, y_train), (x_test, y_test) = tf.keras.datasets.cifar10.load_data()
        x_train, y_train = x_train.astype("float32") / 255.0, y_train.squeeze()
        x_test, y_test = x_test.astype("float32") / 255.0, y_test.squeeze()
        num_classes = 10
    else:
        raise ValueError(f"Unsupported dataset: {dataset_name}")

    # Shuffle and split labeled
    indices = np.arange(len(x_train))
    np.random.shuffle(indices)
    labeled_idx = indices[:num_lab_samples]
    unlabeled_idx = indices[num_lab_samples:total_train_samples]
    val_idx = indices[total_train_samples:total_train_samples + val_samples]

    x_labeled, y_labeled = x_train[labeled_idx], y_train[labeled_idx]
    x_unlabeled = x_train[unlabeled_idx]
    x_val, y_val = x_train[val_idx], y_train[val_idx]

    # Create tf.data datasets
    def _preprocess(x, y=None):
        if y is None:
            return x
        return x, y

    labeled_ds = tf.data.Dataset.from_tensor_slices((x_labeled, y_labeled))
    unlabeled_ds = tf.data.Dataset.from_tensor_slices(x_unlabeled)
    val_ds = tf.data.Dataset.from_tensor_slices((x_val, y_val))
    test_ds = tf.data.Dataset.from_tensor_slices((x_test, y_test))

    # Apply shuffling and batching
    labeled_ds = labeled_ds.shuffle(1000).batch(batch_size).prefetch(tf.data.AUTOTUNE)
    unlabeled_ds = unlabeled_ds.shuffle(1000).batch(batch_size).prefetch(tf.data.AUTOTUNE)
    val_ds = val_ds.batch(batch_size).prefetch(tf.data.AUTOTUNE)
    test_ds = test_ds.batch(batch_size).prefetch(tf.data.AUTOTUNE)

    return {
        "labeled": labeled_ds,
        "unlabeled": unlabeled_ds,
        "val": val_ds,
        "test": test_ds,
        "num_classes": num_classes
    }

# ------------------------------------------------------------
# Model creation
# ------------------------------------------------------------
def get_model(model_name, input_shape, num_classes):
    if model_name == "EfficientNetB0":
        base = applications.EfficientNetB0(include_top=False, weights=None,
                                            input_shape=input_shape, pooling="avg")
    else:
        raise ValueError(f"Unsupported model: {model_name}")

    inputs = layers.Input(shape=input_shape)
    x = base(inputs, training=True)
    outputs = layers.Dense(num_classes, activation="softmax")(x)
    model = models.Model(inputs, outputs)
    return model

# ------------------------------------------------------------
# Optimizer configuration
# ------------------------------------------------------------
def get_optimizer(lr, momentum, weight_decay):
    base_opt = optimizers.SGD(learning_rate=lr, momentum=momentum, decay=weight_decay)
    return base_opt

# ------------------------------------------------------------
# EMA model update
# ------------------------------------------------------------
class EMA:
    def __init__(self, model, decay):
        self.decay = decay
        self.ema_model = tf.keras.models.clone_model(model)
        self.ema_model.set_weights(model.get_weights())
        for layer in self.ema_model.layers:
            layer.trainable = False

    def update(self, model):
        new_weights = model.get_weights()
        ema_weights = self.ema_model.get_weights()
        for i in range(len(ema_weights)):
            ema_weights[i] = self.decay * ema_weights[i] + (1 - self.decay) * new_weights[i]
        self.ema_model.set_weights(ema_weights)

# ------------------------------------------------------------
# Data augmentation
# ------------------------------------------------------------
def weak_augment(x):
    return tf.image.random_flip_left_right(x)

def strong_augment(x):
    x = tf.image.random_brightness(x, max_delta=0.4)
    x = tf.image.random_contrast(x, lower=0.5, upper=1.5)
    return x

# ------------------------------------------------------------
# SSL loss functions (simplified placeholders)
# ------------------------------------------------------------
def mixup_loss(logits, labels, beta=0.75):
    lam = np.random.beta(beta, beta)
    idx = tf.random.shuffle(tf.range(tf.shape(labels)[0]))
    mixed_labels = lam * labels + (1 - lam) * tf.gather(labels, idx)
    loss = losses.CategoricalCrossentropy(from_logits=False)(mixed_labels, logits)
    return loss

def mixmatch_loss(model, x_labeled, y_labeled, x_unlabeled, batch_size, num_classes,
                  temperature=0.5, mixup_alpha=0.75):
    # Weak augmentations
    x_labeled_w = weak_augment(x_labeled)
    x_unlabeled_w = weak_augment(x_unlabeled)

    # Strong augmentations
    x_unlabeled_s = strong_augment(x_unlabeled)

    # Forward pass
    logits_l = model(x_labeled_w, training=True)
    logits_u = model(x_unlabeled_w, training=True)

    # Pseudo labels
    probs_u = tf.nn.softmax(logits_u / temperature, axis=-1)
    pseudo_labels = tf.argmax(probs_u, axis=-1)
    pseudo_one_hot = tf.one_hot(pseudo_labels, depth=num_classes)

    # MixUp
    all_x = tf.concat([x_labeled, x_unlabeled], axis=0)
    all_y = tf.concat([tf.one_hot(y_labeled, depth=num_classes), pseudo_one_hot], axis=0)

    lam = np.random.beta(mixup_alpha, mixup_alpha)
    idx = tf.random.shuffle(tf.range(tf.shape(all_y)[0]))
    mixed_x = lam * all_x + (1 - lam) * tf.gather(all_x, idx)
    mixed_y = lam * all_y + (1 - lam) * tf.gather(all_y, idx)

    # Forward pass on mixed
    mixed_logits = model(mixed_x, training=True)
    loss = losses.CategoricalCrossentropy(from_logits=False)(mixed_y, mixed_logits)
    return loss

# ------------------------------------------------------------
# Validation
# ------------------------------------------------------------
def validate(model, dataset, num_classes):
    loss_fn = losses.CategoricalCrossentropy()
    acc_metric = metrics.CategoricalAccuracy()
    total_loss = 0.0
    total_acc = 0.0
    num_batches = 0
    for x_batch, y_batch in dataset:
        logits = model(x_batch, training=False)
        y_one_hot = tf.one_hot(y_batch, depth=num_classes)
        loss = loss_fn(y_one_hot, logits)
        acc = acc_metric(y_one_hot, logits)
        total_loss += loss.numpy()
        total_acc += acc.numpy()
        num_batches += 1
    return total_loss / num_batches, total_acc / num_batches

# ------------------------------------------------------------
# Main training routine
# ------------------------------------------------------------
def main():
    args = parse_args()
    config = {
        "dataset": args.dataset,
        "algorithm": args.algorithm,
        "model": args.model,
        "batch_size": args.batch_size,
        "epochs": args.epochs,
        "lr": args.lr,
        "momentum": args.momentum,
        "weight_decay": args.weight_decay,
        "num_lab_samples": args.num_lab_samples,
        "val_samples": args.val_samples,
        "total_train_samples": args.total_train_samples,
        "uratio": args.uratio,
        "resume": args.resume,
        "tensorboard": args.tensorboard,
    }
    if args.config_path:
        yaml_cfg = load_yaml(args.config_path)
        config = merge_dicts(config, yaml_cfg)

    set_random_seed(42)

    # Data
    datasets = fetch_dataset(
        config["dataset"],
        config["num_lab_samples"],
        config["val_samples"],
        config["total_train_samples"],
        config["batch_size"]
    )
    num_classes = datasets["num_classes"]

    # Model
    input_shape = (32, 32, 3) if config["dataset"] == "cifar10" else (224, 224, 3)
    model = get_model(config["model"], input_shape, num_classes)
    optimizer = get_optimizer(config["lr"], config["momentum"], config["weight_decay"])

    # EMA
    ema = EMA(model, decay=0.999)

    # Checkpointing
    ckpt_dir = pathlib.Path("checkpoints") / config["algorithm"]
    ckpt_dir.mkdir(parents=True, exist_ok=True)
    ckpt = tf.train.Checkpoint(step=tf.Variable(0), optimizer=optimizer, model=model, ema_model=ema.ema_model)
    manager = tf.train.CheckpointManager(ckpt, ckpt_dir, max_to_keep=5)

    if config["resume"]:
        ckpt.restore(manager.latest_checkpoint)
        print(f"Resumed from {manager.latest_checkpoint}")

    # TensorBoard
    if config["tensorboard"]:
        log_dir = pathlib.Path("logs") / config["algorithm"]
        summary_writer = tf.summary.create_file_writer(str(log_dir))
    else:
        summary_writer = None

    # Training loop
    for epoch in range(int(ckpt.step), config["epochs"]):
        epoch_loss = 0.0
        epoch_acc = 0.0
        batch_count = 0

        # Iterate over labeled and unlabeled batches
        labeled_iter = iter(datasets["labeled"])
        unlabeled_iter = iter(datasets["unlabeled"])
        for _ in range(len(datasets["labeled"])):
            try:
                x_lab, y_lab = next(labeled_iter)
            except StopIteration:
                break
            try:
                x_unlab = next(unlabeled_iter)
            except StopIteration:
                unlabeled_iter = iter(datasets["unlabeled"])
                x_unlab = next(unlabeled_iter)

            with tf.GradientTape() as tape:
                if config["algorithm"] == "mixmatch":
                    loss = mixmatch_loss(
                        model, x_lab, y_lab, x_unlab, config["batch_size"], num_classes
                    )
                else:
                    # Default to standard crossentropy on labeled data
                    logits = model(x_lab, training=True)
                    y_one_hot = tf.one_hot(y_lab, depth=num_classes)
                    loss = losses.CategoricalCrossentropy(from_logits=False)(y_one_hot, logits)

            grads = tape.gradient(loss, model.trainable_variables)
            optimizer.apply_gradients(zip(grads, model.trainable_variables))

            # Update EMA
            ema.update(model)

            epoch_loss += loss.numpy()
            batch_count += 1

        epoch_loss /= batch_count

        # Validation
        val_loss, val_acc = validate(model, datasets["val"], num_classes)
        ema_val_loss, ema_val_acc = validate(ema.ema_model, datasets["val"], num_classes)

        # Logging
        print(f"Epoch {epoch+1}/{config['epochs']} - "
              f"Loss: {epoch_loss:.4f} - Val Acc: {val_acc:.4f} - EMA Val Acc: {ema_val_acc:.4f}")

        if summary_writer:
            with summary_writer.as_default():
                tf.summary.scalar("train_loss", epoch_loss, step=epoch)
                tf.summary.scalar("val_loss", val_loss, step=epoch)
                tf.summary.scalar("val_acc", val_acc, step=epoch)
                tf.summary.scalar("ema_val_acc", ema_val_acc, step=epoch)

        # Checkpoint
        ckpt.step.assign_add(1)
        if (epoch + 1) % 5 == 0:
            manager.save()
            print(f"Checkpoint saved at epoch {epoch+1}")

    # Final evaluation on test set
    test_loss, test_acc = validate(model, datasets["test"], num_classes)
    ema_test_loss, ema_test_acc = validate(ema.ema_model, datasets["test"], num_classes)
    print(f"Test Acc: {test_acc:.4f} - EMA Test Acc: {ema_test_acc:.4f}")

if __name__ == "__main__":
    main()
