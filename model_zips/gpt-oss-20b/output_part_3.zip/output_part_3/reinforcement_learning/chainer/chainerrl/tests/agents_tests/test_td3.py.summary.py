import os
import tempfile
import gym
import numpy as np
import torch
import pytest
from stable_baselines3 import TD3
from stable_baselines3.common.vec_env import SubprocVecEnv
from stable_baselines3.common.evaluation import evaluate_policy

class ABCEnv(gym.Env):
    def __init__(self, episodic: bool = False, test: bool = False):
        super().__init__()
        self.episodic = episodic
        self.test = test
        self.observation_space = gym.spaces.Box(low=-1.0, high=1.0, shape=(4,), dtype=np.float32)
        self.action_space = gym.spaces.Box(low=-1.0, high=1.0, shape=(1,), dtype=np.float32)
        self.max_steps = 10 if episodic else 100
        self.current_step = 0
        self.seed(0)

    def seed(self, seed=None):
        np.random.seed(seed)
        torch.manual_seed(seed)

    def reset(self, *, seed=None, options=None):
        self.current_step = 0
        return self.observation_space.sample()

    def step(self, action):
        self.current_step += 1
        reward = 1.0 if self.current_step >= self.max_steps else 0.0
        done = self.current_step >= self.max_steps
        info = {}
        return self.observation_space.sample(), reward, done, info

    def close(self):
        pass

def make_env(episodic: bool = False, test: bool = False):
    def _init():
        return ABCEnv(episodic=episodic, test=test)
    return _init

def train_and_evaluate(
    env,
    model,
    total_steps,
    eval_every,
    eval_episodes,
    require_success,
    success_threshold,
    eval_env,
    device,
):
    model.learn(total_timesteps=total_steps, log_interval=eval_every, eval_freq=eval_every, eval_env=eval_env, deterministic=True)
    returns, _ = evaluate_policy(model, eval_env, n_eval_episodes=eval_episodes, deterministic=True)
    if require_success:
        assert all(r >= success_threshold for r in returns), f"Not all returns exceed threshold: {returns}"
    return returns

@pytest.fixture(scope="class")
def tmpdir(request):
    dirpath = tempfile.mkdtemp()
    request.cls.tmpdir = dirpath
    yield
    try:
        import shutil
        shutil.rmtree(dirpath)
    except Exception:
        pass

@pytest.mark.usefixtures("tmpdir")
class TestTD3ABC:
    @pytest.mark.parametrize("episodic", [True, False])
    @pytest.mark.parametrize("device", ["cpu"] + (["cuda"] if torch.cuda.is_available() else []))
    @pytest.mark.parametrize("steps", [100, 100000])
    @pytest.mark.parametrize("load_model", [False, True])
    def test_single_agent(self, episodic, device, steps, load_model):
        env = ABCEnv(episodic=episodic, test=False)
        eval_env = ABCEnv(episodic=episodic, test=True)
        policy_kwargs = dict(
            net_arch=[64, 64],
            activation_fn=torch.nn.ReLU,
            device=device,
        )
        model = TD3(
            "MlpPolicy",
            env,
            learning_rate=1e-2,
            batch_size=100,
            buffer_size=1000000,
            gamma=0.5,
            tau=0.005,
            train_freq=1,
            gradient_steps=1,
            policy_kwargs=policy_kwargs,
            device=device,
            verbose=0,
            replay_start_size=100,
            action_noise=0.3,
        )
        returns = train_and_evaluate(
            env,
            model,
            total_steps=steps,
            eval_every=200,
            eval_episodes=5,
            require_success=True,
            success_threshold=1,
            eval_env=eval_env,
            device=device,
        )
        model_path = os.path.join(self.tmpdir, "td3_model")
        model.save(model_path)
        if load_model:
            loaded_model = TD3.load(model_path, env=env, device=device)
            eval_returns, _ = evaluate_policy(loaded_model, eval_env, n_eval_episodes=5, deterministic=True)
            assert all(r >= 1 for r in eval_returns), f"Loaded model failed: {eval_returns}"
        env.close()
        eval_env.close()

    @pytest.mark.parametrize("episodic", [True, False])
    @pytest.mark.parametrize("device", ["cpu"] + (["cuda"] if torch.cuda.is_available() else []))
    @pytest.mark.parametrize("steps", [100, 100000])
    @pytest.mark.parametrize("load_model", [False, True])
    def test_batched_agent(self, episodic, device, steps, load_model):
        vec_env = SubprocVecEnv([make_env(episodic=episodic) for _ in range(3)])
        eval_env = ABCEnv(episodic=episodic, test=True)
        policy_kwargs = dict(
            net_arch=[64, 64],
            activation_fn=torch.nn.ReLU,
            device=device,
        )
        model = TD3(
            "MlpPolicy",
            vec_env,
            learning_rate=1e-2,
            batch_size=100,
            buffer_size=1000000,
            gamma=0.5,
            tau=0.005,
            train_freq=1,
            gradient_steps=1,
            policy_kwargs=policy_kwargs,
            device=device,
            verbose=0,
            replay_start_size=100,
            action_noise=0.3,
        )
        returns = train_and_evaluate(
            vec_env,
            model,
            total_steps=steps,
            eval_every=200,
            eval_episodes=5,
            require_success=True,
            success_threshold=1,
            eval_env=eval_env,
            device=device,
        )
        model_path = os.path.join(self.tmpdir, "td3_batch_model")
        model.save(model_path)
        if load_model:
            loaded_model = TD3.load(model_path, env=vec_env, device=device)
            eval_returns, _ = evaluate_policy(loaded_model, eval_env, n_eval_episodes=5, deterministic=True)
            assert all(r >= 1 for r in eval_returns), f"Loaded batch model failed: {eval_returns}"
        vec_env.close()
        eval_env.close()
