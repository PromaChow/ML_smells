import torch
import torch.nn as nn
import torch.nn.functional as F

class MT(nn.Module):
    def __init__(self, model: nn.Module, ema_factor: float):
        super().__init__()
        self.model = model
        self.model.train()
        self.ema_factor = ema_factor
        self.global_step = 0

    def forward(self, x: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        self.global_step += 1

        # Initial prediction
        y_hat = self.model(x)

        # Temporarily disable batch norm statistics
        if hasattr(self.model, "update_batch_stats"):
            self.model.update_batch_stats(False)
        else:
            # Fallback: set BN layers to eval mode
            self._set_bn_eval(self.model, False)

        # Recompute y with updated batch stats
        y = self.model(x)

        # Re-enable batch norm statistics
        if hasattr(self.model, "update_batch_stats"):
            self.model.update_batch_stats(True)
        else:
            self._set_bn_eval(self.model, True)

        # Loss computation
        soft_y = F.softmax(y, dim=1)
        soft_y_hat = F.softmax(y_hat.detach(), dim=1)
        per_class_mse = F.mse_loss(soft_y, soft_y_hat, reduction="none")
        loss_per_sample = per_class_mse.mean(dim=1)
        weighted_loss = loss_per_sample * mask
        loss = weighted_loss.mean()

        return loss

    def moving_average(self, params: torch.nn.ModuleList):
        ema_factor = min(self.ema_factor, 1 - 1 / (self.global_step + 1))
        for emp_p, p in zip(self.model.parameters(), params.parameters()):
            emp_p.data = ema_factor * emp_p.data + (1 - ema_factor) * p.data

    def _set_bn_eval(self, module: nn.Module, train: bool):
        for m in module.modules():
            if isinstance(m, nn.modules.batchnorm._BatchNorm):
                m.eval()
                if train:
                    # Reset running stats to default values if needed
                    pass
        if train:
            module.train()  # restore training mode
        else:
            module.eval()
```