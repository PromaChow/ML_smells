import torch
import torch.nn as nn
import torch.nn.functional as F
from utils import param_init


def _conv3x3(in_channels, out_channels, stride=1, bias=False):
    return nn.Conv2d(
        in_channels,
        out_channels,
        kernel_size=3,
        stride=stride,
        padding=1,
        bias=bias,
    )


def _conv1x1(in_channels, out_channels, stride=1, bias=False):
    return nn.Conv2d(
        in_channels,
        out_channels,
        kernel_size=1,
        stride=stride,
        padding=0,
        bias=bias,
    )


class _ShakeShake(nn.Module):
    def __init__(self, branch1, branch2):
        super().__init__()
        self.branch1 = branch1
        self.branch2 = branch2

    def forward(self, x):
        a = self.branch1(x)
        b = self.branch2(x)
        if self.training:
            # random mixing per sample
            shape = (x.size(0), 1, 1, 1)
            mu = torch.rand(shape, device=x.device, dtype=x.dtype)
            mix = mu * a + (1 - mu) * b
        else:
            mix = 0.5 * (a + b)
        return mix


class _SkipBranch(nn.Module):
    def __init__(self, branch1, branch2, out_channels):
        super().__init__()
        self.branch1 = branch1
        self.branch2 = branch2
        self.bn = nn.BatchNorm2d(out_channels * 2)

    def forward(self, x):
        # split input spatially: even indices
        x_even = x[..., ::2, ::2]
        x_odd = x[..., 1::2, 1::2]
        out_even = self.branch1(x_even)
        out_odd = self.branch2(x_odd)
        # interleave channel-wise
        out = torch.cat([out_even, out_odd], dim=1)
        out = self.bn(out)
        return out


def _branch(out_channels, stride=1):
    return nn.Sequential(
        nn.ReLU(inplace=True),
        _conv3x3(out_channels, out_channels, stride),
        nn.BatchNorm2d(out_channels),
        nn.ReLU(inplace=True),
        _conv3x3(out_channels, out_channels),
        nn.BatchNorm2d(out_channels),
    )


class _Residual(nn.Module):
    def __init__(self, in_channels, out_channels, stride=1):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.stride = stride

        if stride > 1 or in_channels != out_channels:
            self.downsample = nn.Sequential(
                _conv1x1(in_channels, out_channels, stride),
                nn.BatchNorm2d(out_channels),
            )
        else:
            self.downsample = nn.Identity()

        branch_a = _branch(out_channels, stride)
        branch_b = _branch(out_channels, stride)
        self.shake = _ShakeShake(branch_a, branch_b)

    def forward(self, x):
        identity = self.downsample(x)
        out = self.shake(x)
        return identity + out


class ShakeNet(nn.Module):
    def __init__(
        self,
        num_classes=1000,
        scales=4,
        repeats=3,
        dropout_prob=0.5,
    ):
        super().__init__()
        self.num_classes = num_classes
        self.scales = scales
        self.repeats = repeats
        self.dropout_prob = dropout_prob

        layers = []

        # Initial convolution
        layers.append(
            nn.Sequential(
                _conv3x3(3, 16, stride=1, bias=False),
                nn.BatchNorm2d(16),
                nn.ReLU(inplace=True),
            )
        )

        in_channels = 16

        for scale in range(scales):
            out_channels = 16 << scale
            for r in range(repeats):
                stride = 2 if r == 0 else 1
                layers.append(_Residual(in_channels, out_channels, stride))
                in_channels = out_channels

        self.features = nn.Sequential(*layers)

        self.global_pool = nn.AdaptiveAvgPool2d((1, 1))
        self.dropout = nn.Dropout(dropout_prob) if dropout_prob > 0 else nn.Identity()
        self.classifier = nn.Linear(in_channels, num_classes)

        # Initialize parameters
        param_init(self)

    def forward(self, x):
        x = self.features(x)
        x = self.global_pool(x)
        x = torch.flatten(x, 1)
        x = self.dropout(x)
        x = self.classifier(x)
        return x
