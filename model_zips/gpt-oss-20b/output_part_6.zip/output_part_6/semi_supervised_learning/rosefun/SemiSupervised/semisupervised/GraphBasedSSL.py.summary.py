import numpy as np
import scipy.sparse as sp
from abc import ABC, abstractmethod

class BaseGBSSL(ABC):
    def __init__(self, graph: sp.spmatrix, max_iter: int = 20):
        self.S = graph.tocsr()
        self.max_iter = max_iter
        self.P_ = None
        self.B_ = None
        self.F_ = None
        self.n_samples = self.S.shape[0]
        self.n_classes = None
        self.x_ = None
        self.y_ = None

    @abstractmethod
    def _build_propagation_matrix(self):
        pass

    @abstractmethod
    def _build_base_matrix(self):
        pass

    def _init_label_matrix(self):
        self.F_ = np.zeros((self.n_samples, self.n_classes))

    def fit(self, x_: np.ndarray, y_: np.ndarray):
        self.x_ = x_
        self.y_ = y_
        self.n_classes = int(np.max(y_)) + 1
        self._init_label_matrix()
        self.P_ = self._build_propagation_matrix()
        self.B_ = self._build_base_matrix()
        for _ in range(self.max_iter):
            self.F_ = self.P_.dot(self.F_) + self.B_
        return self

    def predict_proba(self, nodes: np.ndarray):
        probs = self.F_[nodes]
        probs = probs / probs.sum(axis=1, keepdims=True)
        return probs

    def predict(self, nodes: np.ndarray):
        probs = self.predict_proba(nodes)
        return np.argmax(probs, axis=1)

    def _propagate(self):
        self.F_ = self.P_.dot(self.F_) + self.B_


class LGC(BaseGBSSL):
    def __init__(self, graph: sp.spmatrix, max_iter: int = 20, alpha: float = 0.99):
        super().__init__(graph, max_iter)
        self.alpha = alpha

    def _build_propagation_matrix(self):
        degrees = np.array(self.S.sum(axis=1)).flatten()
        sqrt_deg = np.sqrt(degrees)
        sqrt_diag = sp.diags(sqrt_deg)
        P = sqrt_diag.dot(self.S).dot(sqrt_diag)
        P = P.tocsr()
        return self.alpha * P

    def _build_base_matrix(self):
        B = np.zeros((self.n_samples, self.n_classes))
        B[self.x_, self.y_] = 1
        return (1 - self.alpha) * B


class HMN(BaseGBSSL):
    def _build_propagation_matrix(self):
        degrees = np.array(self.S.sum(axis=1)).flatten()
        inv_deg = np.divide(1.0, degrees, out=np.zeros_like(degrees), where=degrees != 0)
        inv_diag = sp.diags(inv_deg)
        P = inv_diag.dot(self.S)
        P = P.tocsr()
        # zero out rows for labeled nodes
        P[self.x_, :] = 0
        return P

    def _build_base_matrix(self):
        B = np.zeros((self.n_samples, self.n_classes))
        B[self.x_, self.y_] = 1
        return B


class PARW(BaseGBSSL):
    def __init__(self, graph: sp.spmatrix, max_iter: int = 20, lamb: float = 1.0):
        super().__init__(graph, max_iter)
        self.lamb = lamb

    def _build_propagation_matrix(self):
        degrees = np.array(self.S.sum(axis=1)).flatten()
        denom = degrees + self.lamb
        inv_denom = np.divide(1.0, denom, out=np.zeros_like(denom), where=denom != 0)
        inv_diag = sp.diags(inv_denom)
        P = inv_diag.dot(self.S)
        return P.tocsr()

    def _build_base_matrix(self):
        B = np.zeros((self.n_samples, self.n_classes))
        B[self.x_, self.y_] = 1
        return B


class MAD(BaseGBSSL):
    def _init_label_matrix(self):
        # dummy class column added
        self.F_ = np.zeros((self.n_samples, self.n_classes + 1))

    def _build_propagation_matrix(self):
        degrees = np.array(self.S.sum(axis=1)).flatten()
        inv_deg = np.divide(1.0, degrees, out=np.zeros_like(degrees), where=degrees != 0)
        inv_diag = sp.diags(inv_deg)
        P = inv_diag.dot(self.S)
        P = P.tocsr()
        return P

    def _build_base_matrix(self):
        B = np.zeros((self.n_samples, self.n_classes + 1))
        B[self.x_, self.y_] = 1
        # dummy class probabilities (could be zeros or small value)
        return B


class OMNIProp(BaseGBSSL):
    def __init__(self, graph: sp.spmatrix, max_iter: int = 20, lamb: float = 1.0):
        super().__init__(graph, max_iter)
        self.lamb = lamb

    def _build_propagation_matrix(self):
        degrees = np.array(self.S.sum(axis=1)).flatten()
        denom1 = degrees + self.lamb
        denom2 = degrees + self.lamb
        inv_denom1 = np.divide(1.0, denom1, out=np.zeros_like(denom1), where=denom1 != 0)
        inv_denom2 = np.divide(1.0, denom2, out=np.zeros_like(denom2), where=denom2 != 0)
        Z1 = sp.diags(inv_denom1)
        Z2 = sp.diags(inv_denom2)
        P = Z1.dot(self.S).dot(Z2).dot(self.S.transpose())
        P = P.tocsr()
        # zero rows for labeled nodes
        P[self.x_, :] = 0
        return P

    def _build_base_matrix(self):
        B = np.zeros((self.n_samples, self.n_classes))
        B[self.x_, self.y_] = 1
        return B


class CAMLP(BaseGBSSL):
    def __init__(self, graph: sp.spmatrix, max_iter: int = 20, beta: float = 0.5, H=None):
        super().__init__(graph, max_iter)
        self.beta = beta
        self.H = H

    def _build_propagation_matrix(self):
        degrees = np.array(self.S.sum(axis=1)).flatten()
        inv_deg = np.divide(1.0, degrees, out=np.zeros_like(degrees), where=degrees != 0)
        inv_diag = sp.diags(inv_deg)
        P = inv_diag.dot(self.S)
        P = self.beta * P
        return P.tocsr()

    def _build_base_matrix(self):
        B = np.full((self.n_samples, self.n_classes), 1.0 / self.n_classes)
        B[self.x_, self.y_] = 1.0
        return B

    def _propagate(self):
        self.F_ = self.P_.dot(self.F_) @ self.H + self.B_
        self.F_ = self.P_.dot(self.F_) + self.B_  # default propagation


# Example usage:
# if __name__ == "__main__":
#     # create a small graph
#     S = sp.csr_matrix([[0, 1, 0],
#                        [1, 0, 1],
#                        [0, 1, 0]])
#     model = LGC(S, max_iter=10)
#     model.fit(np.array([0, 2]), np.array([0, 1]))
#     print(model.predict(np.array([1])))
#     print(model.predict_proba(np.array([1])))
