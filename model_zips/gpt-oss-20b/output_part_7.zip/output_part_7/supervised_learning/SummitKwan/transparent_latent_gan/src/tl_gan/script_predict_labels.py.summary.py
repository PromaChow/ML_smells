import os
import glob
import numpy as np
from PIL import Image
import h5py
import cnn_face

def save_predictions(preds, h5_path):
    with h5py.File(h5_path, 'a') as f:
        if 'y' in f:
            del f['y']
        f.create_dataset('y', data=preds, compression='gzip')

def main():
    path_gan_sample_img = '/path/to/gan/sample_images'  # update this path
    image_pattern = os.path.join(path_gan_sample_img, 'sample_*.jpg')
    z_pattern = os.path.join(path_gan_sample_img, 'sample_*_z.npy')
    output_file = os.path.join(path_gan_sample_img, 'sample_y.h5')

    img_files = sorted(glob.glob(image_pattern))
    z_files = sorted(glob.glob(z_pattern))
    assert len(img_files) == len(z_files), 'Image and latent vector counts do not match.'

    model = cnn_face.create_cnn_model()
    ckpt = cnn_face.get_list_model_save()[-1]
    model.load_weights(ckpt)

    batch_size = 64
    save_every = 2048

    list_y = []
    list_img_batch = []

    for idx, img_path in enumerate(img_files):
        img = Image.open(img_path).convert('RGB')
        img_arr = np.asarray(img, dtype=np.float32)
        list_img_batch.append(img_arr)

        if len(list_img_batch) == batch_size or idx == len(img_files) - 1:
            batch_np = np.stack(list_img_batch, axis=0)
            batch_np = cnn_face.preprocess_input(batch_np)
            preds = model.predict(batch_np, batch_size=batch_size, verbose=0)
            list_y.append(preds)
            list_img_batch = []

            if (idx + 1) % save_every == 0:
                all_preds = np.concatenate(list_y, axis=0)
                save_predictions(all_preds, output_file)
                list_y = []

    if list_y:
        all_preds = np.concatenate(list_y, axis=0)
        save_predictions(all_preds, output_file)

if __name__ == "__main__":
    main()