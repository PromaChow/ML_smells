import argparse
import os
import random
import numpy as np
import chainer
import chainer.functions as F
import chainer.links as L
import chainer.optimizers as O
from chainer import Chain, Variable
from chainer_rl.algorithms import DoubleDQN
from chainer_rl.exploration import LinearSchedule
from chainer_rl.replay.prioritized import PrioritizedReplayBuffer
from chainer_rl.envs import MultiprocessVectorEnv
from chainer_rl import wrappers
from chainer_rl.logger import create_log_writer
from chainer_rl.evaluation import evaluate
from chainer_rl import functions as rl_functions

# Ensure reproducibility
def set_global_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    chainer.set_random_seed(seed)

# Feature extractor
def phi(obs):
    # obs is a dict with keys: 'image', 'elapsed'
    img = obs['image'].astype(np.float32) / 255.0
    return {'image': img, 'elapsed': obs['elapsed']}

# Q-function architecture
class GraspingQFunction(Chain):
    def __init__(self, n_actions):
        super().__init__()
        with self.init_scope():
            self.conv1 = L.Convolution2D(3, 32, ksize=8, stride=4, pad=0)
            self.conv2 = L.Convolution2D(32, 64, ksize=4, stride=2, pad=0)
            self.conv3 = L.Convolution2D(64, 64, ksize=3, stride=1, pad=0)
            self.embed = L.Embedding(3136, 64)
            self.fc1 = L.Linear(None, 512)
            self.fc2 = L.Linear(512, n_actions)

    def __call__(self, obs):
        x = F.relu(self.conv1(obs['image']))
        x = F.relu(self.conv2(x))
        x = F.relu(self.conv3(x))
        x = F.reshape(x, (x.shape[0], -1))  # flatten
        e = self.embed(obs['elapsed'])
        x = F.elementwise_mul(x, e)
        x = F.relu(self.fc1(x))
        return self.fc2(x)

# Environment builder
def make_env(seed):
    def _make():
        env = wrappers.cast_action.CastAction('KukaDiverseObjectEnv')
        env = wrappers.transposition.TransposeObservation(env, axes=(2, 0, 1))
        env = wrappers.elapsed.ObserveElapsedSteps(env, max_steps=8)
        if args.record:
            env = wrappers.record.RecordMovie(env, outdir=os.path.join(args.outdir, 'movies'))
        env.seed(seed)
        return env
    return _make

# Main training / demo logic
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--record', action='store_true')
    parser.add_argument('--demo', action='store_true')
    parser.add_argument('--outdir', default='results')
    args = parser.parse_args()

    set_global_seed(args.seed)
    os.makedirs(args.outdir, exist_ok=True)

    num_envs = 1
    process_seeds = np.arange(num_envs) + args.seed * num_envs

    train_envs = MultiprocessVectorEnv([make_env(s) for s in process_seeds])
    eval_envs = MultiprocessVectorEnv([make_env(s + 10000) for s in process_seeds])

    n_actions = train_envs.env_spec.action_space.n
    q_func = GraspingQFunction(n_actions)

    optimizer = O.RMSpropGraves(6.25e-5, alpha=0.95, eps=1e-2)
    optimizer.setup(q_func)

    replay_buffer = PrioritizedReplayBuffer(
        capacity=10**6,
        alpha=0.6,
        beta0=0.4,
        beta_schedule=rl_functions.linear_schedule(0.4, 1.0, 2_000_000)
    )

    exploration = LinearSchedule(
        epsilon_start=1.0,
        epsilon_final=0.2,
        epsilon_decay_steps=5*10**5
    )

    agent = DoubleDQN(
        q_func=q_func,
        optimizer=optimizer,
        replay=replay_buffer,
        exploration=exploration,
        gamma=0.99,
        batchsize=32,
        target_update_interval=10_000,
        phi=phi
    )

    log_writer = create_log_writer(args.outdir)

    if args.demo:
        evaluate(
            agent,
            eval_envs,
            eval_n_episodes=100,
            log_writer=log_writer
        )
    else:
        agent.train(
            train_envs,
            steps=2_000_000,
            eval_env=eval_envs,
            eval_interval=100_000,
            eval_n_episodes=10,
            log_writer=log_writer,
            outdir=args.outdir
        )