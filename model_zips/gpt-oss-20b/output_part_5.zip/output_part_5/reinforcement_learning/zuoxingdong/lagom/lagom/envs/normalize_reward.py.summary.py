import math
from typing import Any, Tuple

import gymnasium
from gymnasium import Wrapper
from gymnasium.spaces import Space


class RunningMeanVar:
    """Online running mean and variance tracker."""

    def __init__(self, epsilon: float = 1e-8) -> None:
        self.mean: float = 0.0
        self.var: float = 0.0
        self.count: int = 0
        self.epsilon = epsilon

    def update(self, value: float) -> None:
        """Update running statistics with a new value."""
        self.count += 1
        delta = value - self.mean
        self.mean += delta / self.count
        delta2 = value - self.mean
        self.var += delta * delta2

    def variance(self) -> float:
        """Return variance; use epsilon if count == 1."""
        if self.count < 2:
            return self.epsilon
        return self.var / (self.count - 1)

    def std(self) -> float:
        """Return standard deviation with epsilon safety."""
        return math.sqrt(self.variance() + self.epsilon)


class RewardNormalizationWrapper(Wrapper):
    """Wrap an environment to normalize rewards using running mean and variance."""

    def __init__(
        self,
        env: gymnasium.Env,
        clip: float = 10.0,
        gamma: float = 0.99,
        constant_var: float | None = None,
    ) -> None:
        super().__init__(env)
        if not (0.0 <= gamma <= 1.0):
            raise ValueError("gamma must be between 0.0 and 1.0")
        self.clip: float = clip
        self.gamma: float = gamma
        self.constant_var: float | None = constant_var
        self.all_returns: float = 0.0
        if self.constant_var is None:
            self.stats: RunningMeanVar = RunningMeanVar()
        else:
            self.stats = None

    def reset(
        self,
        *,
        seed: int | None = None,
        options: dict[str, Any] | None = None,
    ) -> Tuple[Any, dict[str, Any]]:
        self.all_returns = 0.0
        return self.env.reset(seed=seed, options=options)

    def step(self, action: Any) -> Tuple[Any, float, bool, bool, dict[str, Any]]:
        observation, reward, terminated, truncated, info = self.env.step(action)
        done = terminated or truncated
        if done:
            self.all_returns = 0.0
        normalized_reward = self._normalize_reward(reward)
        return observation, normalized_reward, terminated, truncated, info

    def _normalize_reward(self, reward: float) -> float:
        if self.constant_var is None:
            self.all_returns = reward + self.gamma * self.all_returns
            self.stats.update(self.all_returns)
            std = self.stats.std()
        else:
            std = math.sqrt(self.constant_var + 1e-8)
        clipped_reward = max(-self.clip, min(self.clip, reward))
        return clipped_reward / std if std > 0 else 0.0
