import numpy as np
from typing import Any, Tuple, List

def cardinalities(env: Any) -> Tuple[int, int]:
    """
    Determine the cardinality of the observation and action spaces of the environment.
    """
    # Observation space cardinality
    if hasattr(env.observation_space, "n"):
        obs_card = env.observation_space.n
    else:
        obs_card = env.observation_space.shape[0]
    # Action space cardinality
    if hasattr(env.action_space, "n"):
        act_card = env.action_space.n
    else:
        act_card = env.action_space.shape[0]
    return obs_card, act_card

def one_hot(discrete: int, action_space_cardinality: int) -> np.ndarray:
    """
    Convert a discrete action index into a one-hot encoded vector.
    """
    vector = np.zeros(action_space_cardinality, dtype=int)
    if 0 <= discrete < action_space_cardinality:
        vector[discrete] = 1
    return vector

def run(
    env: Any,
    agent: Any,
    num_episodes: int,
    record: bool,
    log: bool
) -> Tuple[List[float], List[int]]:
    """
    Run the agent in the environment for a specified number of episodes.

    Parameters
    ----------
    env : Any
        The reinforcement learning environment.
    agent : Any
        The agent with methods act, observe, begin_episode, end_episode, and optionally save.
    num_episodes : int
        Number of episodes to run.
    record : bool
        Whether to record per-step rewards and actions across episodes.
    log : bool
        Whether to print episode rewards.

    Returns
    -------
    rewards : List[float]
        Cumulative rewards per episode.
    actions : List[int]
        Action indices taken per episode.
    """
    # Unregister existing agents if possible
    if hasattr(env, "unregister"):
        try:
            env.unregister()
        except Exception:
            pass

    # Register the provided agent
    agent_name = getattr(agent, "name", "agent")
    if hasattr(env, "register"):
        try:
            env.register(agent, name=agent_name)
        except Exception:
            pass

    # Storage for all episodes
    all_rewards: List[float] = []
    all_actions: List[int] = []

    # Best cumulative reward seen so far
    _best_reward = float("-inf")

    # Max steps per episode
    max_steps = getattr(env, "_max_episode_steps", None)
    if max_steps is None and hasattr(env, "unwrapped"):
        max_steps = getattr(env.unwrapped, "_max_episode_steps", None)
    if max_steps is None:
        max_steps = 200  # default fallback

    for episode in range(num_episodes):
        # Reset environment
        obs = env.reset()
        if isinstance(obs, tuple):
            obs, _ = obs  # gymnasium reset may return (obs, info)

        agent.begin_episode()

        episode_rewards: List[float] = []
        episode_actions: List[int] = []

        for _ in range(max_steps):
            action = agent.act(obs)
            # Ensure action is an int index if action space is discrete
            if isinstance(action, np.ndarray):
                action = int(action.item())
            next_obs, reward, *rest = env.step(action)

            if len(rest) == 3:
                terminated, truncated, info = rest
                done = terminated or truncated
            elif len(rest) == 2:
                done, info = rest
            else:
                done, _ = rest[0], rest[1] if len(rest) > 1 else {}
            episode_rewards.append(reward)
            episode_actions.append(action)

            agent.observe(obs, action, reward, next_obs, done)
            obs = next_obs

            if done:
                break

        agent.end_episode()

        cumulative_reward = sum(episode_rewards)
        if record:
            all_rewards.extend(episode_rewards)
            all_actions.extend(episode_actions)

        if log:
            print(f"Episode {episode + 1}/{num_episodes} reward: {cumulative_reward:.2f}")

        if cumulative_reward > _best_reward:
            _best_reward = cumulative_reward
            save_name = f"{agent_name}_reward_{cumulative_reward:.2f}.pkl"
            if hasattr(agent, "save") and callable(agent.save):
                try:
                    agent.save(save_name)
                except Exception:
                    pass

    return all_rewards, all_actions

if __name__ == "__main__":
    # Example usage placeholder
    pass