import numpy as np
import gym
from gym.spaces import Dict, Box, Tuple, Discrete
from spriteworld import (
    Environment,
    SpriteInitializer,
    NoReward,
    SelectMove,
    Embodied,
    PILRenderer,
    GymWrapper,
)

def test_gym_wrapper_continuous():
    # Environment Setup
    env = Environment(
        renderer=PILRenderer((64, 64)),
        task=NoReward(),
        action_space=SelectMove(),
        sprite_initializer=SpriteInitializer(1, c0=255),
        max_episode_length=5,
    )

    # Gym Wrapper Application
    wrapper = GymWrapper(env)

    # Observation Space Checks
    assert isinstance(wrapper.observation_space, Dict)
    assert "image" in wrapper.observation_space.spaces
    img_space = wrapper.observation_space["image"]
    assert isinstance(img_space, Box)
    assert img_space.shape == (64, 64, 3)
    assert img_space.dtype == np.uint8

    # Action Space Checks
    assert isinstance(wrapper.action_space, Box)
    assert wrapper.action_space.shape == (4,)
    assert wrapper.action_space.dtype == np.float32

    # Episode Simulation
    max_steps = wrapper.env.max_episode_length
    for _ in range(3):
        obs = wrapper.reset()
        for step in range(max_steps - 1):
            action = wrapper.action_space.sample()
            obs, reward, done, info = wrapper.step(action)
            assert obs["image"].dtype == np.uint8
            assert reward == 0
            if step < max_steps - 2:
                assert not done
            else:
                assert done
        # After termination
        obs, reward, done, info = wrapper.step(wrapper.action_space.sample())
        assert not done


def test_gym_wrapper_embodied():
    # Environment Setup
    env = Environment(
        renderer=PILRenderer((64, 64)),
        task=NoReward(),
        action_space=Embodied(),
        sprite_initializer=SpriteInitializer(1, c0=255),
        max_episode_length=5,
    )

    # Gym Wrapper Application
    wrapper = GymWrapper(env)

    # Observation Space Checks
    assert isinstance(wrapper.observation_space, Dict)
    assert "image" in wrapper.observation_space.spaces
    img_space = wrapper.observation_space["image"]
    assert isinstance(img_space, Box)
    assert img_space.shape == (64, 64, 3)
    assert img_space.dtype == np.uint8

    # Action Space Checks
    assert isinstance(wrapper.action_space, Tuple)
    dir_space, mov_space = wrapper.action_space.spaces
    assert isinstance(dir_space, Discrete)
    assert dir_space.n == 2
    assert isinstance(mov_space, Discrete)
    assert mov_space.n == 4

    # Episode Simulation
    max_steps = wrapper.env.max_episode_length
    for _ in range(3):
        obs = wrapper.reset()
        for step in range(max_steps - 1):
            action = (
                wrapper.action_space.spaces[0].sample(),
                wrapper.action_space.spaces[1].sample(),
            )
            obs, reward, done, info = wrapper.step(action)
            assert obs["image"].dtype == np.uint8
            assert reward == 0
            if step < max_steps - 2:
                assert not done
            else:
                assert done
        # After termination
        obs, reward, done, info = wrapper.step((0, 0))
        assert not done
