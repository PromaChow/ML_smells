import pandas as pd
import matplotlib.pyplot as plt

# Load the dataset
df = pd.read_csv("BigMartSalesData.csv")

# Filter data for the year 2011 and keep only Month and Amount columns
df_2011 = df[df["Year"] == 2011][["Month", "Amount"]]

# Group by Month and sum the Amount to get total sales per month
monthly_sales = df_2011.groupby("Month", as_index=False)["Amount"].sum()
monthly_sales.rename(columns={"Amount": "Total Sales"}, inplace=True)

# Extract data for plotting
months = monthly_sales["Month"]
total_sales = monthly_sales["Total Sales"]

# Generate a line plot
plt.figure(figsize=(10, 6))
plt.plot(months, total_sales, marker='o', linestyle='-')
plt.xlabel("Month")
plt.ylabel("Total Sales")
plt.title("Monthly Sales Trend for 2011")
plt.grid(True)

# Observation: Sales increased until the 11th month and decreased in the 12th month
# February had the lowest sales based on the graph.
plt.show()