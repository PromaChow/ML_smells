import abc
import numpy as np
from typing import Dict, Iterable, List, Optional, Set, Tuple, Union


class AbstractDistribution(abc.ABC):
    @abc.abstractmethod
    def sample(self, rng: np.random.Generator) -> Dict[str, Union[int, float]]:
        """Generate a dictionary spec of factor values."""
        pass

    @abc.abstractmethod
    def contains(self, spec: Dict[str, Union[int, float]]) -> bool:
        """Check if a spec is within the distribution's support."""
        pass

    @abc.abstractmethod
    def to_str(self, indent: int = 0) -> str:
        """Recursive string representation."""
        pass

    @property
    @abc.abstractmethod
    def keys(self) -> Set[str]:
        """Set of factor keys in the spec."""
        pass

    def __str__(self) -> str:
        return self.to_str(0)


class Continuous(AbstractDistribution):
    def __init__(
        self,
        key: str,
        minval: float,
        maxval: float,
        dtype: type = float,
    ):
        self.key = key
        self.minval = minval
        self.maxval = maxval
        self.dtype = dtype

    def sample(self, rng: np.random.Generator) -> Dict[str, Union[int, float]]:
        val = rng.uniform(self.minval, self.maxval)
        return {self.key: self.dtype(val)}

    def contains(self, spec: Dict[str, Union[int, float]]) -> bool:
        val = spec.get(self.key)
        if val is None:
            return False
        return self.minval <= val < self.maxval

    def to_str(self, indent: int = 0) -> str:
        space = "  " * indent
        return (
            f"{space}Continuous("
            f"key={self.key!r}, "
            f"range=[{self.minval}, {self.maxval}), "
            f"dtype={self.dtype.__name__})"
        )

    @property
    def keys(self) -> Set[str]:
        return {self.key}


class Discrete(AbstractDistribution):
    def __init__(
        self,
        key: str,
        candidates: Iterable[Union[int, float]],
        probs: Optional[Iterable[float]] = None,
    ):
        self.key = key
        self.candidates = list(candidates)
        self.probs = list(probs) if probs is not None else None
        if self.probs is not None and len(self.probs) != len(self.candidates):
            raise ValueError("probs length must match candidates length")

    def sample(self, rng: np.random.Generator) -> Dict[str, Union[int, float]]:
        val = rng.choice(self.candidates, p=self.probs)
        return {self.key: val}

    def contains(self, spec: Dict[str, Union[int, float]]) -> bool:
        val = spec.get(self.key)
        return val in self.candidates

    def to_str(self, indent: int = 0) -> str:
        space = "  " * indent
        return (
            f"{space}Discrete("
            f"key={self.key!r}, "
            f"candidates={self.candidates!r}, "
            f"probs={self.probs!r})"
        )

    @property
    def keys(self) -> Set[str]:
        return {self.key}


class Mixture(AbstractDistribution):
    _MAX_TRIES = int(1e5)

    def __init__(
        self,
        components: List[AbstractDistribution],
        probs: Optional[Iterable[float]] = None,
    ):
        if not components:
            raise ValueError("Mixture must have at least one component")
        key_sets = [c.keys for c in components]
        if not all(k == key_sets[0] for k in key_sets):
            raise ValueError("All components must have identical key sets in Mixture")
        self.components = components
        if probs is None:
            self.probs = [1.0 / len(components)] * len(components)
        else:
            probs = list(probs)
            if len(probs) != len(components):
                raise ValueError("probs length must match number of components")
            if not np.isclose(sum(probs), 1.0):
                raise ValueError("probs must sum to 1")
            self.probs = probs

    def sample(self, rng: np.random.Generator) -> Dict[str, Union[int, float]]:
        idx = rng.choice(len(self.components), p=self.probs)
        return self.components[idx].sample(rng)

    def contains(self, spec: Dict[str, Union[int, float]]) -> bool:
        return any(c.contains(spec) for c in self.components)

    def to_str(self, indent: int = 0) -> str:
        space = "  " * indent
        lines = [
            f"{space}Mixture(probs={self.probs!r}):",
        ]
        for c in self.components:
            lines.append(c.to_str(indent + 1))
        return "\n".join(lines)

    @property
    def keys(self) -> Set[str]:
        return self.components[0].keys


class Intersection(AbstractDistribution):
    _MAX_TRIES = int(1e5)

    def __init__(self, components: List[AbstractDistribution]):
        if not components:
            raise ValueError("Intersection must have at least one component")
        self.components = components
        self._validate_keys()

    def _validate_keys(self):
        all_keys = [c.keys for c in self.components]
        # For intersection, just ensure no conflict; all keys can be overlapping
        # but each component must contain the keys present in spec.
        pass

    def sample(self, rng: np.random.Generator) -> Dict[str, Union[int, float]]:
        tries = 0
        while tries < self._MAX_TRIES:
            comp = rng.choice(self.components)
            spec = comp.sample(rng)
            if all(c.contains(spec) for c in self.components):
                return spec
            tries += 1
        raise RuntimeError("Intersection.sample failed to find a valid spec after maximum tries")

    def contains(self, spec: Dict[str, Union[int, float]]) -> bool:
        return all(c.contains(spec) for c in self.components)

    def to_str(self, indent: int = 0) -> str:
        space = "  " * indent
        lines = [f"{space}Intersection:"]
        for c in self.components:
            lines.append(c.to_str(indent + 1))
        return "\n".join(lines)

    @property
    def keys(self) -> Set[str]:
        result: Set[str] = set()
        for c in self.components:
            result.update(c.keys)
        return result


class Product(AbstractDistribution):
    def __init__(self, components: List[AbstractDistribution]):
        if not components:
            raise ValueError("Product must have at least one component")
        self.components = components
        self._validate_disjoint_keys()

    def _validate_disjoint_keys(self):
        seen: Set[str] = set()
        for c in self.components:
            overlap = seen & c.keys
            if overlap:
                raise ValueError(f"Product components have overlapping keys: {overlap}")
            seen.update(c.keys)

    def sample(self, rng: np.random.Generator) -> Dict[str, Union[int, float]]:
        spec: Dict[str, Union[int, float]] = {}
        for c in self.components:
            spec.update(c.sample(rng))
        return spec

    def contains(self, spec: Dict[str, Union[int, float]]) -> bool:
        return all(c.contains(spec) for c in self.components)

    def to_str(self, indent: int = 0) -> str:
        space = "  " * indent
        lines = [f"{space}Product:"]
        for c in self.components:
            lines.append(c.to_str(indent + 1))
        return "\n".join(lines)

    @property
    def keys(self) -> Set[str]:
        result: Set[str] = set()
        for c in self.components:
            result.update(c.keys)
        return result


class SetMinus(AbstractDistribution):
    _MAX_TRIES = int(1e5)

    def __init__(self, base: AbstractDistribution, hold_out: AbstractDistribution):
        self.base = base
        self.hold_out = hold_out
        if self.base.keys != self.hold_out.keys:
            raise ValueError("SetMinus requires base and hold_out to have identical keys")

    def sample(self, rng: np.random.Generator) -> Dict[str, Union[int, float]]:
        tries = 0
        while tries < self._MAX_TRIES:
            spec = self.base.sample(rng)
            if not self.hold_out.contains(spec):
                return spec
            tries += 1
        raise RuntimeError("SetMinus.sample failed to find a valid spec after maximum tries")

    def contains(self, spec: Dict[str, Union[int, float]]) -> bool:
        return self.base.contains(spec) and not self.hold_out.contains(spec)

    def to_str(self, indent: int = 0) -> str:
        space = "  " * indent
        lines = [
            f"{space}SetMinus:",
            f"{space}  Base:",
            self.base.to_str(indent + 2),
            f"{space}  HoldOut:",
            self.hold_out.to_str(indent + 2),
        ]
        return "\n".join(lines)

    @property
    def keys(self) -> Set[str]:
        return self.base.keys


class Selection(AbstractDistribution):
    _MAX_TRIES = int(1e5)

    def __init__(self, base: AbstractDistribution, filtering: AbstractDistribution):
        self.base = base
        self.filtering = filtering
        if not self.filtering.keys.issubset(self.base.keys):
            raise ValueError("Filtering keys must be a subset of base keys in Selection")

    def sample(self, rng: np.random.Generator) -> Dict[str, Union[int, float]]:
        tries = 0
        while tries < self._MAX_TRIES:
            spec = self.base.sample(rng)
            if self.filtering.contains(spec):
                return spec
            tries += 1
        raise RuntimeError("Selection.sample failed to find a valid spec after maximum tries")

    def contains(self, spec: Dict[str, Union[int, float]]) -> bool:
        return self.base.contains(spec) and self.filtering.contains(spec)

    def to_str(self, indent: int = 0) -> str:
        space = "  " * indent
        lines = [
            f"{space}Selection:",
            f"{space}  Base:",
            self.base.to_str(indent + 2),
            f"{space}  Filtering:",
            self.filtering.to_str(indent + 2),
        ]
        return "\n".join(lines)

    @property
    def keys(self) -> Set[str]:
        return self.base.keys
