import torch
from torch.utils.data import Dataset


class LabeledDataset(Dataset):
    def __init__(self, dataset, transform=None):
        self.dataset = dataset
        self.transform = transform

    def __len__(self):
        return len(self.dataset["images"])

    def __getitem__(self, idx):
        img_np = self.dataset["images"][idx]
        img = torch.from_numpy(img_np).float()
        img = img.permute(2, 0, 1) / 255.0
        if self.transform is not None:
            img = self.transform(img)
        label = int(self.dataset["labels"][idx])
        return img, label


class UnlabeledDataset(Dataset):
    def __init__(self, dataset, weak_augmentation, strong_augmentation=None):
        self.dataset = dataset
        self.weak_augmentation = weak_augmentation
        self.strong_augmentation = strong_augmentation

    def __len__(self):
        return len(self.dataset["images"])

    def __getitem__(self, idx):
        img_np = self.dataset["images"][idx]
        img = torch.from_numpy(img_np).float()
        img = img.permute(2, 0, 1) / 255.0
        w_aug = self.weak_augmentation(img)
        if self.strong_augmentation is not None:
            s_aug = self.strong_augmentation(img)
        else:
            s_aug = self.weak_augmentation(img)
        label = int(self.dataset["labels"][idx])
        return w_aug, s_aug, label
