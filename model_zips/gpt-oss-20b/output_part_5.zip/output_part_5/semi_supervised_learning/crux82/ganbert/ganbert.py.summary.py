import os
import random
import json
import numpy as np
import tensorflow as tf
from tensorflow.contrib import predictor
from tensorflow import estimator as tf_estimator
from tensorflow.python.estimator import estimator_lib
from tensorflow.contrib.tpu import tpu_estimator
from tensorflow.python.platform import app
from tensorflow.python.platform import flags

FLAGS = flags.FLAGS

flags.DEFINE_bool("do_train", True, "Whether to run training.")
flags.DEFINE_bool("do_eval", False, "Whether to run eval on the dev set.")
flags.DEFINE_bool("do_predict", False, "Whether to run predict on the test set.")
flags.DEFINE_string("bert_config_file", "", "BERT config json file")
flags.DEFINE_string("vocab_file", "", "Vocabulary json file")
flags.DEFINE_string("train_file", "", "Training data file (csv)")
flags.DEFINE_string("dev_file", "", "Evaluation data file (csv)")
flags.DEFINE_string("predict_file", "", "Prediction data file (csv)")
flags.DEFINE_string("output_dir", "./output", "The output directory.")
flags.DEFINE_integer("max_seq_length", 128, "Maximum sequence length.")
flags.DEFINE_integer("batch_size", 32, "Batch size.")
flags.DEFINE_integer("num_train_steps", 1000, "Number of training steps.")
flags.DEFINE_integer("num_warmup_steps", 100, "Number of warmup steps.")
flags.DEFINE_float("learning_rate", 2e-5, "Learning rate.")
flags.DEFINE_float("dropout_keep_rate", 0.8, "Dropout keep probability.")
flags.DEFINE_integer("num_hidden_discriminator", 2, "Hidden layers for discriminator.")
flags.DEFINE_integer("num_hidden_generator", 2, "Hidden layers for generator.")
flags.DEFINE_integer("latent_z", 100, "Latent dimension for generator.")
flags.DEFINE_float("label_mask_rate", 0.1, "Masking rate for labels.")
flags.DEFINE_float("unlabeled_multiplier", 3.0, "Multiplier for unlabeled data.")
flags.DEFINE_integer("seed", 1234, "Random seed.")

# ---- Helper functions ----
def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    tf.set_random_seed(seed)

# ---- Data processing ----
def convert_single_example(text, label_id, max_seq_length, tokenizer):
    tokens = tokenizer.tokenize(text)
    if len(tokens) > max_seq_length - 2:
        tokens = tokens[:max_seq_length - 2]
    tokens = ["[CLS]"] + tokens + ["[SEP]"]
    input_ids = tokenizer.convert_tokens_to_ids(tokens)
    input_mask = [1] * len(input_ids)
    segment_ids = [0] * len(input_ids)
    padding_length = max_seq_length - len(input_ids)
    input_ids += [0] * padding_length
    input_mask += [0] * padding_length
    segment_ids += [0] * padding_length
    return input_ids, input_mask, segment_ids, label_id

def file_based_convert_examples_to_features(examples, labels, max_seq_length, tokenizer, output_file, label_mask_rate):
    writer = tf.python_io.TFRecordWriter(output_file)
    for text, label in zip(examples, labels):
        if random.random() < label_mask_rate:
            label_id = -1  # masked
        else:
            label_id = label
        input_ids, input_mask, segment_ids, label_id = convert_single_example(
            text, label_id, max_seq_length, tokenizer)
        feature = {
            "input_ids": tf.train.Feature(int64_list=tf.train.Int64List(value=input_ids)),
            "input_mask": tf.train.Feature(int64_list=tf.train.Int64List(value=input_mask)),
            "segment_ids": tf.train.Feature(int64_list=tf.train.Int64List(value=segment_ids)),
            "label_id": tf.train.Feature(int64_list=tf.train.Int64List(value=[label_id]))
        }
        example_proto = tf.train.Example(features=tf.train.Features(feature=feature))
        writer.write(example_proto.SerializeToString())
    writer.close()

def file_based_input_fn_builder(input_file, seq_length, is_training, drop_remainder):
    name_to_features = {
        "input_ids": tf.FixedLenFeature([seq_length], tf.int64),
        "input_mask": tf.FixedLenFeature([seq_length], tf.int64),
        "segment_ids": tf.FixedLenFeature([seq_length], tf.int64),
        "label_id": tf.FixedLenFeature([], tf.int64),
    }

    def _decode_record(record, name_to_features):
        example = tf.parse_single_example(record, name_to_features)
        for name in list(example.keys()):
            t = example[name]
            if t.dtype == tf.int64:
                t = tf.cast(t, tf.int32)
            example[name] = t
        return example

    def _input_fn(params):
        batch_size = params["batch_size"]
        dataset = tf.data.TFRecordDataset(input_file)
        dataset = dataset.map(lambda record: _decode_record(record, name_to_features))
        if is_training:
            dataset = dataset.shuffle(buffer_size=10000)
        dataset = dataset.repeat()
        dataset = dataset.batch(batch_size=batch_size, drop_remainder=drop_remainder)
        features = dataset.make_one_shot_iterator().get_next()
        return features
    return _input_fn

# ---- Model components ----
def leaky_relu(x, alpha=0.2):
    return tf.maximum(alpha * x, x)

def discriminator(features, is_training, hidden_units, dropout_keep):
    net = features
    for i, units in enumerate(hidden_units):
        net = tf.layers.dense(net, units, activation=leaky_relu,
                              name="disc_dense_%d" % i)
        net = tf.layers.dropout(net, dropout_keep if is_training else 1.0,
                                name="disc_dropout_%d" % i)
    logits = tf.layers.dense(net, 1, name="disc_logits")
    probs = tf.nn.sigmoid(logits)
    return logits, probs, net

def generator(z, is_training, hidden_units, dropout_keep):
    net = z
    for i, units in enumerate(hidden_units):
        net = tf.layers.dense(net, units, activation=leaky_relu,
                              name="gen_dense_%d" % i)
        net = tf.layers.dropout(net, dropout_keep if is_training else 1.0,
                                name="gen_dropout_%d" % i)
    output = tf.layers.dense(net, 768, activation=None, name="gen_output")
    return output

# ---- Create model ----
def create_model(input_ids, input_mask, segment_ids, label_ids,
                 is_training, bert_config, dropout_keep_rate,
                 num_labels, latent_z, label_mask_rate):
    # BERT
    bert_module = tf.keras.Sequential()
    bert_module.add(tf.keras.layers.Input(shape=(FLAGS.max_seq_length,), dtype=tf.int32, name="input_ids"))
    bert_module.add(tf.keras.layers.Input(shape=(FLAGS.max_seq_length,), dtype=tf.int32, name="input_mask"))
    bert_module.add(tf.keras.layers.Input(shape=(FLAGS.max_seq_length,), dtype=tf.int32, name="segment_ids"))
    # Dummy embedding for illustration
    bert_output = tf.layers.dense(tf.cast(input_ids, tf.float32), 768, name="bert_embed")
    bert_output = tf.layers.dense(bert_output, 768, activation=tf.nn.tanh, name="bert_encoder")

    # Discriminator on real features
    disc_real_logits, disc_real_probs, disc_real_features = discriminator(
        bert_output, is_training, [256]*FLAGS.num_hidden_discriminator, dropout_keep_rate)

    # Generator
    z = tf.random.normal([tf.shape(input_ids)[0], latent_z])
    gen_features = generator(z, is_training,
                             [256]*FLAGS.num_hidden_generator, dropout_keep_rate)

    # Discriminator on fake features
    disc_fake_logits, disc_fake_probs, _ = discriminator(
        gen_features, is_training, [256]*FLAGS.num_hidden_discriminator, dropout_keep_rate)

    # Supervised loss on labeled data
    supervised_logits = tf.layers.dense(disc_real_features, num_labels, name="supervised_logits")
    supervised_loss = tf.nn.sparse_softmax_cross_entropy_with_logits(
        labels=tf.where(label_ids >= 0, label_ids, tf.zeros_like(label_ids)),
        logits=supervised_logits)

    # Adversarial losses
    d_loss_real = tf.nn.sigmoid_cross_entropy_with_logits(
        labels=tf.ones_like(disc_real_logits), logits=disc_real_logits)
    d_loss_fake = tf.nn.sigmoid_cross_entropy_with_logits(
        labels=tf.zeros_like(disc_fake_logits), logits=disc_fake_logits)
    d_loss = tf.reduce_mean(d_loss_real + d_loss_fake)

    g_loss_fake = tf.nn.sigmoid_cross_entropy_with_logits(
        labels=tf.ones_like(disc_fake_logits), logits=disc_fake_logits)
    # Feature matching loss
    feature_match_loss = tf.reduce_mean(tf.abs(tf.reduce_mean(disc_real_features, axis=0)
                                                - tf.reduce_mean(gen_features, axis=0)))
    g_loss = tf.reduce_mean(g_loss_fake) + feature_match_loss

    total_loss = d_loss + supervised_loss + g_loss

    return total_loss, supervised_logits, disc_real_probs, disc_fake_probs

# ---- Model function builder ----
def model_fn_builder(bert_config, num_labels, dropout_keep_rate,
                     latent_z, label_mask_rate):
    def model_fn(features, labels, mode, params):
        input_ids = features["input_ids"]
        input_mask = features["input_mask"]
        segment_ids = features["segment_ids"]
        label_ids = features["label_id"]

        is_training = (mode == tf_estimator.ModeKeys.TRAIN)

        total_loss, logits, disc_real_probs, disc_fake_probs = create_model(
            input_ids, input_mask, segment_ids, label_ids,
            is_training, bert_config, dropout_keep_rate,
            num_labels, latent_z, label_mask_rate)

        if mode == tf_estimator.ModeKeys.PREDICT:
            predictions = {
                "probabilities": tf.nn.softmax(logits),
                "disc_real_probs": disc_real_probs,
                "disc_fake_probs": disc_fake_probs
            }
            export_outputs = {
                "predict": tf_estimator.tpu.export.PredictOutput(predictions)
            }
            return tf_estimator.tpu.TPUEstimatorSpec(mode, predictions=predictions,
                                                    export_outputs=export_outputs)

        train_op = None
        if mode == tf_estimator.ModeKeys.TRAIN:
            optimizer = tf.train.AdamOptimizer(learning_rate=FLAGS.learning_rate)
            train_op = optimizer.minimize(total_loss, global_step=tf.train.get_or_create_global_step())

        if mode == tf_estimator.ModeKeys.EVAL:
            eval_metric_ops = {
                "accuracy": tf_estimator.metrics.accuracy(
                    labels=tf.where(label_ids >= 0, label_ids, tf.zeros_like(label_ids)),
                    predictions=tf.argmax(logits, axis=-1))
            }
            return tf_estimator.tpu.TPUEstimatorSpec(mode,
                                                    loss=total_loss,
                                                    eval_metric_ops=eval_metric_ops)

        return tf_estimator.tpu.TPUEstimatorSpec(mode, loss=total_loss, train_op=train_op)

    return model_fn

# ---- Training, evaluation, prediction ----
def train_and_evaluate(bert_config, num_labels, dropout_keep_rate, latent_z, label_mask_rate):
    model_fn = model_fn_builder(bert_config, num_labels, dropout_keep_rate,
                                latent_z, label_mask_rate)

    tpu_cluster_resolver = tf.contrib.cluster_resolver.TPUClusterResolver(
        FLAGS.tpu, zone=FLAGS.tpu_zone, project=FLAGS.project)

    run_config = tf_estimator.tpu.RunConfig(
        cluster=tpu_cluster_resolver,
        model_dir=FLAGS.output_dir,
        save_checkpoints_steps=1000,
        keep_checkpoint_max=5,
        tpu_config=tf_estimator.tpu.TPUConfig(
            iterations_per_loop=200,
            num_shards=FLAGS.num_tpu_cores,
            per_host_input_for_training=tf_estimator.tpu.InputPipelineConfig.PER_HOST_V2))

    estimator = tpu_estimator.TPUEstimator(
        use_tpu=True,
        model_fn=model_fn,
        config=run_config,
        train_batch_size=FLAGS.batch_size,
        eval_batch_size=FLAGS.batch_size,
        predict_batch_size=FLAGS.batch_size)

    # Train
    if FLAGS.do_train:
        train_input_fn = file_based_input_fn_builder(
            FLAGS.train_file, FLAGS.max_seq_length, True, True)
        estimator.train(input_fn=train_input_fn, steps=FLAGS.num_train_steps)

    # Evaluate
    if FLAGS.do_eval:
        eval_input_fn = file_based_input_fn_builder(
            FLAGS.dev_file, FLAGS.max_seq_length, False, False)
        eval_result = estimator.evaluate(input_fn=eval_input_fn)
        print("Evaluation results:", eval_result)

    # Predict
    if FLAGS.do_predict:
        predict_input_fn = file_based_input_fn_builder(
            FLAGS.predict_file, FLAGS.max_seq_length, False, False)
        predictions = estimator.predict(input_fn=predict_input_fn)
        with tf.io.gfile.GFile(os.path.join(FLAGS.output_dir, "predictions.tsv"), "w") as out_file:
            for pred in predictions:
                probs = pred["probabilities"]
                out_file.write("\t".join(map(str, probs)) + "\n")

# ---- Main ----
def main(_):
    set_seed(FLAGS.seed)
    bert_config = tf.contrib.training.HParams(
        hidden_size=768,
        num_hidden_layers=12,
        num_attention_heads=12,
        intermediate_size=3072,
        max_position_embeddings=512,
        vocab_size=30522,
        type_vocab_size=2,
        initializer_range=0.02,
        hidden_dropout_prob=1 - FLAGS.dropout_keep_rate,
        attention_probs_dropout_prob=0.1)
    num_labels = 2  # For binary classification; modify as needed
    train_and_evaluate(bert_config, num_labels,
                       FLAGS.dropout_keep_rate,
                       FLAGS.latent_z,
                       FLAGS.label_mask_rate)

if __name__ == "__main__":
    app.run(main)