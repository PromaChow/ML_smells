import subprocess
import sys

def install(package):
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])

# Ensure required packages are installed
required_packages = ["numpy", "pandas", "matplotlib", "seaborn", "pandas_profiling", "scikit-learn"]
for pkg in required_packages:
    try:
        __import__(pkg.replace("-", "_"))
    except ImportError:
        install(pkg)

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pandas.plotting import scatter_matrix
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
from sklearn.neighbors import KNeighborsClassifier

def main():
    # 1. Data Loading
    url = "https://raw.githubusercontent.com/selva86/datasets/master/BreastCancer.csv"
    df = pd.read_csv(url)

    # 2. Data Inspection
    print("Shape:", df.shape)
    print("\nFirst 5 rows:\n", df.head())
    print("\nLast 5 rows:\n", df.tail())

    if 'Unnamed: 0' in df.columns:
        df = df.drop(columns=['Unnamed: 0'])
    print("\nColumns after dropping 'Unnamed: 0':", df.columns.tolist())

    print("\nInfo:")
    print(df.info())

    diagnosis_counts = df['diagnosis'].value_counts()
    print("\nDiagnosis counts:\n", diagnosis_counts)

    plt.figure(figsize=(6,4))
    sns.countplot(x='diagnosis', data=df, palette='Set2')
    plt.title('Diagnosis Count')
    plt.show()

    # 3. Feature Selection
    # Assuming first 10 columns after dropping Unnamed are mean features (excluding 'id' and 'diagnosis')
    mean_features = df.columns[2:12]
    print("\nSelected mean features:", list(mean_features))
    X = df[mean_features]
    y = df['diagnosis']

    # 4. EDA
    plt.figure(figsize=(10,8))
    corr = X.corr()
    sns.heatmap(corr, annot=True, fmt=".2f", cmap='coolwarm')
    plt.title('Correlation Heatmap')
    plt.show()

    scatter_matrix(df[mean_features], figsize=(12,12), diagonal='kde', color='gray')
    plt.suptitle('Scatter Matrix of Mean Features', fontsize=16)
    plt.show()

    # 5. Data Preprocessing
    le = LabelEncoder()
    y_encoded = le.fit_transform(y)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y_encoded, test_size=0.2, random_state=42, stratify=y_encoded
    )

    # 6. Logistic Regression
    lr = LogisticRegression(max_iter=200)
    lr.fit(X_train, y_train)

    y_train_pred = lr.predict(X_train)
    y_test_pred = lr.predict(X_test)

    print("\nLogistic Regression Accuracy:")
    print("Train:", accuracy_score(y_train, y_train_pred))
    print("Test:", accuracy_score(y_test, y_test_pred))

    print("\nTest Set Confusion Matrix:\n", confusion_matrix(y_test, y_test_pred))
    print("\nTest Set Classification Report:\n", classification_report(y_test, y_test_pred))

    comparison_df = pd.DataFrame({
        'Actual': y_test,
        'Predicted': y_test_pred
    })
    print("\nActual vs Predicted (Test Set):\n", comparison_df.head())

    # 7. K-Nearest Neighbors
    knn = KNeighborsClassifier(n_neighbors=10)
    knn.fit(X_train, y_train)

    y_knn_pred = knn.predict(X_test)
    print("\nKNN Accuracy on Test Set:", accuracy_score(y_test, y_knn_pred))

    train_probs = knn.predict_proba(X_train)
    print("\nKNN Predicted Probabilities for Training Data (first 5):\n", train_probs[:5])

if __name__ == "__main__":
    main()