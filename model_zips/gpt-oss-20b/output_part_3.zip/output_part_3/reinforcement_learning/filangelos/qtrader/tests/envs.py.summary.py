import unittest
import numpy as np
from qtrader.envs import TradingEnv
from qtrader.agents import RandomAgent

CSV_PATH = "db/prices.csv"


class TestEnvs(unittest.TestCase):
    def test__TradingEnv(self):
        env = TradingEnv(
            symbols=["AAPL", "MSFT", "GE", "JPM"],
            data_path=CSV_PATH,
            end_date=2018
        )
        agent = RandomAgent(action_space=env.action_space)
        env.register_agent(agent)

        np.random.seed(13)
        obs, done = env.reset(), False
        rewards = []

        while not done:
            action = env.action_space.sample()
            obs, reward, done, info = env.step(action)
            rewards.append(reward)

        env.unregister_agent(agent)
        total_reward = sum(rewards)
        self.assertIsInstance(total_reward, float)


if __name__ == "__main__":
    unittest.main()