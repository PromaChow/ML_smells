import numpy as np


class AtariEnvWrapper:
    """
    Environment wrapper for Atari games that handles episode termination on life loss,
    reward clipping, and provides attribute forwarding to the underlying environment.
    """

    def __init__(self, env):
        self.env = env

    def __getattr__(self, name):
        return getattr(self.env, name)

    def step(self, *args, **kwargs):
        """
        Execute a step in the underlying environment, clip the reward, and
        set done to True if a life has been lost.
        """
        initial_lives = self.env.ale.lives()
        next_state, reward, done, info = self.env.step(*args, **kwargs)
        final_lives = self.env.ale.lives()
        if final_lives < initial_lives:
            done = True
        reward = max(min(reward, 1), -1)
        return next_state, reward, done, info


def atari_make_initial_state(state):
    """
    Create an initial stacked state by replicating the input frame four times.
    """
    return np.stack([state] * 4, axis=2)


def atari_make_next_state(state, next_state):
    """
    Generate a new stacked state by appending the next frame to the existing three.
    """
    next_frame = next_state[..., None]
    return np.concatenate((state[..., 1:], next_frame), axis=2)