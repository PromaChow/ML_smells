import numpy as np

class InvertedPendulum(MJCFBasedRobot):
    def __init__(self):
        super().__init__(
            mjcf_file='inverted_pendulum.xml',
            body_name='cart',
            action_dim=1,
            observation_dim=4
        )
        self._p = None
        self._slider_joint = None
        self._hinge_joint = None

    def robot_specific_reset(self, bullet_client, *args, **kwargs):
        self._p = bullet_client
        self._slider_joint = self._mjcf_model.joint('slider')
        self._hinge_joint = self._mjcf_model.joint('hinge')
        initial_theta = np.random.uniform(-0.1, 0.1)
        self._p.resetJointState(
            bodyUniqueId=self._hinge_joint.body.id,
            jointIndex=self._hinge_joint.id,
            targetValue=initial_theta
        )
        self._p.setJointMotorControl2(
            bodyUniqueId=self._hinge_joint.body.id,
            jointIndex=self._hinge_joint.id,
            controlMode=self._p.TORQUE_CONTROL,
            force=0
        )

    def apply_action(self, action):
        action = np.asarray(action)
        if action.size == 0:
            return
        action = np.where(np.isfinite(action), action, 0)
        torque = 100 * np.clip(action[0], -1, 1)
        self._p.setJointMotorControl2(
            bodyUniqueId=self._slider_joint.body.id,
            jointIndex=self._slider_joint.id,
            controlMode=self._p.TORQUE_CONTROL,
            force=torque
        )

    def calc_state(self):
        slider_pos, slider_vel, _, _ = self._p.getJointState(
            self._slider_joint.body.id,
            self._slider_joint.id
        )
        hinge_angle, hinge_vel, _, _ = self._p.getJointState(
            self._hinge_joint.body.id,
            self._hinge_joint.id
        )
        slider_pos = slider_pos if np.isfinite(slider_pos) else 0
        slider_vel = slider_vel if np.isfinite(slider_vel) else 0
        hinge_angle = hinge_angle if np.isfinite(hinge_angle) else 0
        hinge_vel = hinge_vel if np.isfinite(hinge_vel) else 0
        state = np.array([slider_pos, hinge_angle, slider_vel, hinge_vel], dtype=np.float32)
        return state)