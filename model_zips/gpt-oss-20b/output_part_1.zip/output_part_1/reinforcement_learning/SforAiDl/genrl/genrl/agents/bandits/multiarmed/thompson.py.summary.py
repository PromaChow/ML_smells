import numpy as np

class MultiArmedBandit:
    def __init__(self, bandits: int, arms: int, true_success_rates: np.ndarray):
        """
        Parameters
        ----------
        bandits : int
            Number of contexts (bandits).
        arms : int
            Number of arms (actions).
        true_success_rates : np.ndarray, shape (bandits, arms)
            The probability of success for each arm in each context.
        """
        if true_success_rates.shape != (bandits, arms):
            raise ValueError("true_success_rates must have shape (bandits, arms)")
        self.bandits = bandits
        self.arms = arms
        self.true_success_rates = true_success_rates

    def get_reward(self, context: int, action: int) -> int:
        """
        Simulate a Bernoulli reward for the given context and action.
        """
        prob = self.true_success_rates[context, action]
        return np.random.binomial(1, prob)


class ThompsonSamplingAgent:
    def __init__(self, env: MultiArmedBandit, alpha: float = 1.0, beta: float = 1.0):
        """
        Parameters
        ----------
        env : MultiArmedBandit
            The bandit environment.
        alpha : float
            Initial success prior for Beta distribution.
        beta : float
            Initial failure prior for Beta distribution.
        """
        self.env = env
        self._a = np.full((env.bandits, env.arms), alpha, dtype=float)
        self._b = np.full((env.bandits, env.arms), beta, dtype=float)
        self.action_hist = []      # list of tuples (context, action)
        self.regret_hist = []      # list of regret values
        self.counts = np.zeros((env.bandits, env.arms), dtype=int)

    @property
    def quality(self) -> np.ndarray:
        """
        Expected reward (mean of Beta distribution) for each arm and context.
        """
        return self._a / (self._a + self._b)

    def select_action(self, context: int) -> int:
        """
        Select an action for the given context using Thompson Sampling.
        """
        sampled_values = np.random.beta(self._a[context], self._b[context])
        action = int(np.argmax(sampled_values))
        self.action_hist.append((context, action))
        return action

    def update(self, context: int, action: int, reward: int):
        """
        Update the Beta parameters based on observed reward and record regret.
        """
        self._a[context, action] += reward
        self._b[context, action] += 1 - reward
        self.counts[context, action] += 1

        # Regret calculation
        best_quality = np.max(self.quality[context])
        chosen_quality = self.quality[context, action]
        regret = best_quality - chosen_quality
        self.regret_hist.append(regret)

    def run(self, steps: int):
        """
        Run the agent for a specified number of steps.
        """
        for _ in range(steps):
            context = np.random.randint(self.env.bandits)
            action = self.select_action(context)
            reward = self.env.get_reward(context, action)
            self.update(context, action, reward)


# Example usage
if __name__ == "__main__":
    np.random.seed(42)
    bandits = 3
    arms = 4
    true_rates = np.array([
        [0.1, 0.4, 0.6, 0.8],
        [0.3, 0.5, 0.7, 0.9],
        [0.2, 0.3, 0.5, 0.7]
    ])
    env = MultiArmedBandit(bandits, arms, true_rates)
    agent = ThompsonSamplingAgent(env, alpha=1.0, beta=1.0)
    agent.run(steps=1000)

    print("Estimated quality:")
    print(agent.quality)
    print("Cumulative regret:", np.sum(agent.regret_hist))
    print("Action history length:", len(agent.action_hist))