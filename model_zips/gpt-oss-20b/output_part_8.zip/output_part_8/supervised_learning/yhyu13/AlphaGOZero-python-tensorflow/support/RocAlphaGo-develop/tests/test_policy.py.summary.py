import os
import tempfile
import unittest
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

# --------------------- GameState --------------------- #
class GameState:
    BOARD_SIZE = 19

    def __init__(self, board=None, player_to_move=1):
        if board is None:
            self.board = np.zeros((self.BOARD_SIZE, self.BOARD_SIZE), dtype=int)
        else:
            self.board = board
        self.player_to_move = player_to_move  # 1 for black, -1 for white

    def get_legal_moves(self):
        return list(zip(*np.where(self.board == 0)))

    def place_move(self, x, y, color=None):
        if self.board[x, y] != 0:
            raise ValueError("Illegal move")
        self.board[x, y] = color if color is not None else self.player_to_move
        self.player_to_move *= -1

    def copy(self):
        return GameState(np.copy(self.board), self.player_to_move)

    @classmethod
    def full_board(cls, last_empty=None, color=1):
        board = np.full((cls.BOARD_SIZE, cls.BOARD_SIZE), color, dtype=int)
        if last_empty is not None:
            board[last_empty[0], last_empty[1]] = 0
        return cls(board)

# --------------------- Policies --------------------- #
class BasePolicy:
    def __init__(self, input_features=None):
        self.input_features = input_features or []

    def preprocess(self, state):
        board = state.board
        # Dummy feature channels: board, liberties, sensibleness, capture_size
        chan_board = board.astype(np.float32)
        chan_liberties = np.zeros_like(chan_board)
        chan_sensibleness = np.zeros_like(chan_board)
        chan_capture_size = np.zeros_like(chan_board)
        features = np.stack(
            [chan_board, chan_liberties, chan_sensibleness, chan_capture_size], axis=0
        )
        return torch.tensor(features).unsqueeze(0)  # (1, 4, H, W)

    def batch_preprocess(self, states):
        return torch.cat([self.preprocess(s) for s in states], dim=0)

    def batch_eval_state(self, states):
        inputs = self.batch_preprocess(states)
        outputs = self.model(inputs)  # (batch, 361)
        probs = F.softmax(outputs, dim=1).detach().cpu().numpy()
        results = []
        for prob in probs:
            move_probs = [(i // self.BOARD_SIZE, i % self.BOARD_SIZE, p) for i, p in enumerate(prob)]
            results.append(move_probs)
        return results

    def save_model(self, path):
        torch.save(self.model.state_dict(), path)

    def load_model(self, path):
        self.model.load_state_dict(torch.load(path))

class CNNPolicy(BasePolicy):
    BOARD_SIZE = 19

    def __init__(self, input_features=None):
        super().__init__(input_features)
        self.model = nn.Sequential(
            nn.Conv2d(4, 32, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv2d(32, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv2d(64, 1, kernel_size=1),
            nn.Flatten(),
        )

class ResnetPolicy(BasePolicy):
    BOARD_SIZE = 19

    def __init__(self, input_features=None, num_blocks=3):
        super().__init__(input_features)
        layers = []
        layers.append(nn.Conv2d(4, 32, kernel_size=3, padding=1))
        layers.append(nn.ReLU())
        for _ in range(num_blocks):
            layers.append(nn.Conv2d(32, 32, kernel_size=3, padding=1))
            layers.append(nn.ReLU())
        layers.append(nn.Conv2d(32, 1, kernel_size=1))
        layers.append(nn.Flatten())
        self.model = nn.Sequential(*layers)

# --------------------- Players --------------------- #
class BasePlayer:
    def __init__(self, policy):
        self.policy = policy

    def move(self, state):
        raise NotImplementedError

class GreedyPolicyPlayer(BasePlayer):
    def move(self, state):
        if not state.get_legal_moves():
            return None
        probs = self.policy.batch_eval_state([state])[0]
        # sort by probability descending
        probs_sorted = sorted(probs, key=lambda x: -x[2])
        for x, y, p in probs_sorted:
            if (x, y) in state.get_legal_moves():
                return (x, y)
        return None

class ProbabilisticPolicyPlayer(BasePlayer):
    def move(self, state):
        if not state.get_legal_moves():
            return None
        probs = self.policy.batch_eval_state([state])[0]
        legal = [(x, y, p) for x, y, p in probs if (x, y) in state.get_legal_moves()]
        total = sum(p for _, _, p in legal)
        if total == 0:
            return None
        rnd = np.random.rand() * total
        accum = 0.0
        for x, y, p in legal:
            accum += p
            if rnd <= accum:
                return (x, y)
        return None

# --------------------- Tests --------------------- #
class TestCNNPolicy(unittest.TestCase):
    def setUp(self):
        self.policy = CNNPolicy(
            input_features=["board", "liberties", "sensibleness", "capture_size"]
        )
        self.state = GameState()

    def test_default_policy(self):
        # Initialization should not error
        self.assertIsInstance(self.policy, CNNPolicy)

    def test_batch_eval_state(self):
        state2 = GameState()
        result = self.policy.batch_eval_state([self.state, state2])
        self.assertEqual(len(result), 2)
        for move_probs in result:
            self.assertEqual(len(move_probs), self.policy.BOARD_SIZE ** 2)

    def test_output_size(self):
        input_tensor = self.policy.preprocess(self.state)
        output = self.policy.model(input_tensor)
        self.assertEqual(output.shape, (1, self.policy.BOARD_SIZE ** 2))

    def test_save_load(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            model_path = os.path.join(tmpdir, "cnn_model.pth")
            weights_path = os.path.join(tmpdir, "cnn_weights.pth")
            # Save model
            torch.save(self.policy.model, model_path)
            self.policy.model.save_state_dict(weights_path)
            # Load back
            loaded_model = torch.load(model_path)
            loaded_policy = CNNPolicy()
            loaded_policy.model = loaded_model
            loaded_policy.load_model(weights_path)
            # Compare weights
            for p1, p2 in zip(self.policy.model.parameters(), loaded_policy.model.parameters()):
                self.assertTrue(torch.allclose(p1, p2))

class TestResnetPolicy(unittest.TestCase):
    def setUp(self):
        self.policy = ResnetPolicy(
            input_features=["board", "liberties", "sensibleness", "capture_size"]
        )
        self.state = GameState()

    def test_default_policy(self):
        self.assertIsInstance(self.policy, ResnetPolicy)

    def test_batch_eval_state(self):
        state2 = GameState()
        result = self.policy.batch_eval_state([self.state, state2])
        self.assertEqual(len(result), 2)
        for move_probs in result:
            self.assertEqual(len(move_probs), self.policy.BOARD_SIZE ** 2)

    def test_save_load(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            model_path = os.path.join(tmpdir, "resnet_model.pth")
            weights_path = os.path.join(tmpdir, "resnet_weights.pth")
            torch.save(self.policy.model, model_path)
            self.policy.model.save_state_dict(weights_path)
            loaded_model = torch.load(model_path)
            loaded_policy = ResnetPolicy()
            loaded_policy.model = loaded_model
            loaded_policy.load_model(weights_path)
            self.assertIsInstance(loaded_policy, ResnetPolicy)
            for p1, p2 in zip(self.policy.model.parameters(), loaded_policy.model.parameters()):
                self.assertTrue(torch.allclose(p1, p2))

class TestPlayers(unittest.TestCase):
    def setUp(self):
        self.cnn_policy = CNNPolicy()
        self.prob_policy = CNNPolicy()
        self.greedy_player = GreedyPolicyPlayer(self.cnn_policy)
        self.prob_player = ProbabilisticPolicyPlayer(self.prob_policy)

    def test_greedy_player(self):
        state = GameState()
        for _ in range(20):
            move = self.greedy_player.move(state)
            self.assertIsNotNone(move)
            state.place_move(*move)

    def test_probabilistic_player(self):
        state = GameState()
        for _ in range(20):
            move = self.prob_player.move(state)
            self.assertIsNotNone(move)
            state.place_move(*move)

    def test_sensible_probabilistic(self):
        # almost full board, one empty spot
        empty_spot = (0, 0)
        state = GameState.full_board(last_empty=empty_spot, color=1)
        move = self.prob_player.move(state)
        self.assertIsNone(move)

    def test_sensible_greedy(self):
        empty_spot = (0, 0)
        state = GameState.full_board(last_empty=empty_spot, color=1)
        move = self.greedy_player.move(state)
        self.assertIsNone(move)

if __name__ == "__main__":
    unittest.main()