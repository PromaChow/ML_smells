import os
import sys
import gym
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import tempfile
import shutil
import pytest
from rlpyt.algos.dqn.dqn_per import DQNPer
from rlpyt.replay_buffers.simple_replay_buffer import SimpleReplayBuffer

class QNet(nn.Module):
    def __init__(self, state_dim: int, action_dim: int):
        super().__init__()
        self.fc1 = nn.Linear(state_dim, 16)
        self.fc2 = nn.Linear(16, 16)
        self.out = nn.Linear(16, action_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return self.out(x)

@pytest.fixture
def train_config():
    env = gym.make("CartPole-v0")
    env = gym.wrappers.TimeLimit(env, max_episode_steps=500)
    config = {
        "env_spec": env,
        "max_episodes": 1000,
        "replay_size": 100000,
        "solved_reward": 150,
        "solved_repeat": 5,
    }
    return config

@pytest.fixture
def dqn_per(train_config):
    env = train_config["env_spec"]
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.n
    q_net = QNet(state_dim, action_dim)
    q_net_t = QNet(state_dim, action_dim)
    optimizer = optim.Adam(q_net.parameters())
    criterion = nn.MSELoss()
    replay_buffer = SimpleReplayBuffer(train_config["replay_size"])
    dqn = DQNPer(
        env_spec=env,
        model=q_net,
        target_model=q_net_t,
        optimizer=optimizer,
        criterion=criterion,
        replay_buffer=replay_buffer,
        max_episode_steps=env._max_episode_steps,
    )
    return dqn

@pytest.fixture
def dqn_per_vis(train_config):
    env = train_config["env_spec"]
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.n
    q_net = QNet(state_dim, action_dim)
    q_net_t = QNet(state_dim, action_dim)
    optimizer = optim.Adam(q_net.parameters())
    criterion = nn.MSELoss()
    replay_buffer = SimpleReplayBuffer(train_config["replay_size"])
    tmp_dir = tempfile.mkdtemp()
    dqn = DQNPer(
        env_spec=env,
        model=q_net,
        target_model=q_net_t,
        optimizer=optimizer,
        criterion=criterion,
        replay_buffer=replay_buffer,
        max_episode_steps=env._max_episode_steps,
        vis=True,
        vis_dir=tmp_dir,
    )
    yield dqn
    shutil.rmtree(tmp_dir)

@pytest.fixture
def dqn_per_train(train_config):
    env = train_config["env_spec"]
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.n
    q_net = QNet(state_dim, action_dim)
    q_net_t = QNet(state_dim, action_dim)
    optimizer = optim.Adam(q_net.parameters())
    criterion = nn.MSELoss()
    replay_buffer = SimpleReplayBuffer(train_config["replay_size"])
    dqn = DQNPer(
        env_spec=env,
        model=q_net,
        target_model=q_net_t,
        optimizer=optimizer,
        criterion=criterion,
        replay_buffer=replay_buffer,
        max_episode_steps=env._max_episode_steps,
    )
    return dqn

def test_criterion_reduction(dqn_per):
    assert hasattr(dqn_per.criterion, "reduction")

def test_update_mechanism(dqn_per):
    env = dqn_per.env_spec
    state_dim = env.observation_space.shape[0]
    for _ in range(3):
        state = np.zeros(state_dim, dtype=np.float32)
        action = 0
        reward = 0.0
        terminal = False
        dqn_per.replay_buffer.add(state, action, reward, terminal)
    # Capture weights before update
    pre_weights = [w.clone() for w in dqn_per.model.parameters()]
    dqn_per.update()
    post_weights = [w for w in dqn_per.model.parameters()]
    changed = any((pre - post).abs().sum() > 0 for pre, post in zip(pre_weights, post_weights))
    assert changed, "Weights did not change after update with default settings"
    # Repeat without updates
    pre_weights = [w.clone() for w in dqn_per.model.parameters()]
    dqn_per.update()
    post_weights = [w for w in dqn_per.model.parameters()]
    unchanged = all((pre - post).abs().sum() == 0 for pre, post in zip(pre_weights, post_weights))
    assert unchanged, "Weights changed when they should not have"

def test_config_initialization():
    env = gym.make("CartPole-v0")
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.n
    config = DQNPer.generate_config({})
    config["env_spec"] = env
    config["model"] = QNet(state_dim, action_dim)
    config["target_model"] = QNet(state_dim, action_dim)
    config["optimizer"] = optim.Adam(config["model"].parameters())
    config["criterion"] = nn.MSELoss()
    config["replay_buffer"] = SimpleReplayBuffer(100000)
    config["max_episode_steps"] = env._max_episode_steps
    dqn = DQNPer(**config)
    # Store dummy episode
    state = np.zeros(state_dim, dtype=np.float32)
    action = 0
    reward = 0.0
    terminal = False
    dqn.replay_buffer.add(state, action, reward, terminal)
    dqn.update()

@pytest.mark.skipif(sys.platform != "linux", reason="Linux-only test")
def test_full_training_loop(dqn_per_train):
    env = dqn_per_train.env_spec
    env.seed(0)
    torch.manual_seed(0)
    np.random.seed(0)
    solved_reward = 150
    solved_repeat = 5
    smooth_window = 10
    recent_rewards = []
    consecutive = 0
    for episode in range(dqn_per_train.max_episodes):
        state = env.reset()
        episode_reward = 0
        done = False
        transitions = []
        while not done:
            action = dqn_per_train.act_discrete_with_noise(state)
            next_state, reward, done, _ = env.step(action)
            episode_reward += reward
            transitions.append((state, action, reward, done, next_state))
            state = next_state
        for tr in transitions:
            s, a, r, d, ns = tr
            dqn_per_train.replay_buffer.add(s.astype(np.float32), a, r, d)
        if episode >= 100:
            for _ in range(len(transitions)):
                dqn_per_train.update()
        recent_rewards.append(episode_reward)
        if len(recent_rewards) > smooth_window:
            recent_rewards.pop(0)
        smoothed = np.mean(recent_rewards)
        if smoothed >= solved_reward:
            consecutive += 1
        else:
            consecutive = 0
        if consecutive >= solved_repeat:
            break
    else:
        raise RuntimeError(f"Failed to solve environment within {dqn_per_train.max_episodes} episodes")
    assert consecutive >= solved_repeat, "Did not reach solved repeat threshold"