from abc import ABC, abstractmethod
from typing import Callable, Tuple

import numpy as np
import chainer
from chainer import functions as F
from chainer import Variable
from chainer.utils import cached_property


class ActionValue(ABC):
    @property
    @abstractmethod
    def greedy_actions(self) -> Variable:
        """Return action indices or values that maximize Q."""
        raise NotImplementedError

    @property
    @abstractmethod
    def max(self) -> Variable:
        """Return the maximum Q-value for each state."""
        raise NotImplementedError

    @abstractmethod
    def evaluate_actions(self, actions: Variable) -> Variable:
        """Evaluate Q-values for given actions."""
        raise NotImplementedError

    @property
    @abstractmethod
    def params(self) -> Tuple[Variable, ...]:
        """Return learnable parameters."""
        raise NotImplementedError


class DiscreteActionValue(ActionValue):
    def __init__(self, q_values: Variable):
        """
        Parameters
        ----------
        q_values : Variable
            Shape (batch_size, n_actions)
        """
        self.q_values = q_values

    @cached_property
    def greedy_actions(self) -> Variable:
        return F.argmax(self.q_values, axis=1)

    @cached_property
    def max(self) -> Variable:
        return F.max(self.q_values, axis=1)

    def evaluate_actions(self, actions: Variable) -> Variable:
        return F.select_item(self.q_values, actions)

    def compute_advantage(self, actions: Variable) -> Variable:
        return self.evaluate_actions(actions) - self.max

    def compute_double_advantage(self, actions: Variable, argmax_actions: Variable) -> Variable:
        q1 = F.select_item(self.q_values, actions)
        q2 = F.select_item(self.q_values, argmax_actions)
        return q1 - q2

    def compute_expectation(self, beta: Variable) -> Variable:
        probs = F.softmax(beta, axis=1)
        return F.sum(probs * self.q_values, axis=1)

    @property
    def params(self) -> Tuple[Variable]:
        return (self.q_values,)


class DistributionalDiscreteActionValue(DiscreteActionValue):
    def __init__(self, q_dist: Variable, z_values: np.ndarray):
        """
        Parameters
        ----------
        q_dist : Variable
            Shape (batch_size, n_actions, n_atoms)
        z_values : np.ndarray
            Shape (n_atoms,)
        """
        self.q_dist = q_dist
        self.z_values = np.asarray(z_values, dtype=np.float32)
        weighted = q_dist * self.z_values
        q_values = F.sum(weighted, axis=2)
        super().__init__(q_values)

    def max_as_distribution(self) -> Variable:
        greedy = self.greedy_actions
        return F.select_item(self.q_dist, greedy)

    def evaluate_actions_as_distribution(self, actions: Variable) -> Variable:
        return F.select_item(self.q_dist, actions)

    @property
    def params(self) -> Tuple[Variable]:
        return (self.q_dist,)


class QuantileDiscreteActionValue(DiscreteActionValue):
    def __init__(self, quantiles: Variable):
        """
        Parameters
        ----------
        quantiles : Variable
            Shape (batch_size, n_taus, n_actions)
        """
        self.quantiles = quantiles
        q_values = F.mean(quantiles, axis=1)
        super().__init__(q_values)

    def evaluate_actions_as_quantiles(self, actions: Variable) -> Variable:
        return F.select_item(self.quantiles, actions)

    @property
    def params(self) -> Tuple[Variable]:
        return (self.quantiles,)


class QuadraticActionValue(ActionValue):
    def __init__(
        self,
        mu: Variable,
        mat: Variable,
        v: Variable,
        lower: np.ndarray = None,
        upper: np.ndarray = None,
    ):
        """
        Parameters
        ----------
        mu : Variable
            Action mean, shape (batch_size, action_dim)
        mat : Variable
            Positive definite matrix, shape (batch_size, action_dim, action_dim)
        v : Variable
            State value, shape (batch_size, 1)
        lower : np.ndarray, optional
            Lower action bounds, shape (action_dim,)
        upper : np.ndarray, optional
            Upper action bounds, shape (action_dim,)
        """
        self.mu = mu
        self.mat = mat
        self.v = v
        self.lower = Variable(np.asarray(lower, dtype=np.float32)) if lower is not None else None
        self.upper = Variable(np.asarray(upper, dtype=np.float32)) if upper is not None else None

    @property
    def greedy_actions(self) -> Variable:
        action = self.mu
        if self.lower is not None and self.upper is not None:
            action = F.clip(action, self.lower, self.upper)
        return action

    def evaluate_actions(self, actions: Variable) -> Variable:
        diff = actions - self.mu
        diff_exp = F.expand_dims(diff, axis=2)          # (batch, a_dim, 1)
        mat_mul = F.batch_matmul(self.mat, diff_exp)   # (batch, a_dim, 1)
        quad = F.sum(mat_mul * diff_exp, axis=1)       # (batch, 1)
        return self.v - 0.5 * quad

    @property
    def params(self) -> Tuple[Variable, ...]:
        return (self.mu, self.mat, self.v)


class SingleActionValue(ActionValue):
    def __init__(self, evaluator: Callable[[Variable], Variable], maximizer: Callable[[], Variable]):
        """
        Parameters
        ----------
        evaluator : callable
            Function that evaluates actions, should accept Variable and return Variable.
        maximizer : callable
            Function that returns the greedy action, should take no arguments.
        """
        self._evaluator = evaluator
        self._maximizer = maximizer

    def evaluate_actions(self, actions: Variable) -> Variable:
        return self._evaluator(actions)

    @property
    def greedy_actions(self) -> Variable:
        return self._maximizer()

    @property
    def params(self) -> Tuple[Variable, ...]:
        import warnings
        warnings.warn("SingleActionValue has no learnable parameters.")
        return ()

    def __getitem__(self, key):
        raise NotImplementedError("SingleActionValue does not support slicing.")
```