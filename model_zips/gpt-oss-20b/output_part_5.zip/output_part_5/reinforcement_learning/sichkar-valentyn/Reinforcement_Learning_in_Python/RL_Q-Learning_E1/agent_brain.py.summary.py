import random
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from env import final_states  # Assumes env.py provides final_states() function


class QLearningTable:
    def __init__(self, actions, lr=0.1, gamma=0.9, e_greedy=0.9):
        self.actions = actions
        self.lr = lr
        self.gamma = gamma
        self.e_greedy = e_greedy
        self.q_table = pd.DataFrame(columns=self.actions, dtype=np.float64)
        self.q_table_final = pd.DataFrame(columns=self.actions, dtype=np.float64)

    def check_state_exist(self, state):
        if state not in self.q_table.index:
            self.q_table.loc[state] = [0] * len(self.actions)

    def choose_action(self, state):
        self.check_state_exist(state)
        if np.random.rand() < self.e_greedy:
            q_values = self.q_table.loc[state].values
            max_q = np.max(q_values)
            best_actions = np.where(q_values == max_q)[0]
            action = random.choice(best_actions)
            return self.actions[action]
        else:
            return random.choice(self.actions)

    def learn(self, state, action, reward, next_state, done):
        self.check_state_exist(next_state)
        q_predict = self.q_table.at[state, action]
        if done:
            q_target = reward
        else:
            q_target = reward + self.gamma * self.q_table.loc[next_state].max()
        self.q_table.at[state, action] += self.lr * (q_target - q_predict)

    def print_q_table(self):
        final_state_list = final_states()
        for state in final_state_list:
            if state in self.q_table.index:
                self.q_table_final.loc[state] = self.q_table.loc[state]
        print("Full Q-table:")
        print(self.q_table)
        print("\nFinal route Q-table:")
        print(self.q_table_final)
        print(f"\nFull Q-table length: {len(self.q_table)}")
        print(f"Final route Q-table length: {len(self.q_table_final)}")

    def plot_results(self, steps, costs):
        episodes = list(range(1, len(steps) + 1))
        fig, axs = plt.subplots(2, 1, figsize=(10, 8))
        axs[0].plot(episodes, steps, marker='o')
        axs[0].set_xlabel('Episode')
        axs[0].set_ylabel('Steps')
        axs[0].set_title('Steps per Episode')
        axs[0].grid(True)

        axs[1].plot(episodes, costs, marker='x', color='r')
        axs[1].set_xlabel('Episode')
        axs[1].set_ylabel('Cost')
        axs[1].set_title('Cost per Episode')
        axs[1].grid(True)

        plt.tight_layout()
        plt.show()
        # Separate figure for summary
        plt.figure(figsize=(6, 4))
        plt.plot(episodes, steps, label='Steps', marker='o')
        plt.plot(episodes, costs, label='Cost', marker='x')
        plt.xlabel('Episode')
        plt.ylabel('Value')
        plt.title('Episode Summary')
        plt.legend()
        plt.grid(True)
        plt.show()
