import unittest
from go import (
    Board,
    parse_kgs_coords,
    parse_sgf_coords,
    Game,
    LibertyTracker,
    StoneColor,
)

class TestBoardInitialization(unittest.TestCase):
    def setUp(self):
        self.layout = """
        . . . . . . . . .
        . . . . . . . . .
        . . . . . . . . .
        . . . . . . . . .
        . . . . . . . . .
        . . . . . . . . .
        . . . . . . . . .
        . . . . . . . . .
        . . . . . . . . .
        """.strip()
        self.board = Board.from_text(self.layout)

    def test_empty_board_initialization(self):
        for y in range(9):
            for x in range(9):
                self.assertIsNone(self.board.get_stone((x, y)), f"Expected empty at {(x,y)}")

    def test_parse_kgs_coords_valid(self):
        self.assertEqual(parse_kgs_coords("A1"), (0, 0))
        self.assertEqual(parse_kgs_coords("I9"), (8, 8))
        self.assertEqual(parse_kgs_coords("D4"), (3, 3))

    def test_parse_kgs_coords_invalid(self):
        with self.assertRaises(ValueError):
            parse_kgs_coords("J10")
        with self.assertRaises(ValueError):
            parse_kgs_coords("AA")

    def test_parse_sgf_coords_valid(self):
        self.assertEqual(parse_sgf_coords("aa"), (0, 0))
        self.assertEqual(parse_sgf_coords("ii"), (8, 8))
        self.assertEqual(parse_sgf_coords("dd"), (3, 3))

    def test_parse_sgf_coords_invalid(self):
        with self.assertRaises(ValueError):
            parse_sgf_coords("zz")
        with self.assertRaises(ValueError):
            parse_sgf_coords("a")

class TestNeighborDetection(unittest.TestCase):
    def setUp(self):
        self.board = Board.from_text("""
        . . . . . . . . .
        . . . . . . . . .
        . . . . . . . . .
        . . . . . . . . .
        . . . . . . . . .
        . . . . . . . . .
        . . . . . . . . .
        . . . . . . . . .
        . . . . . . . . .
        """.strip())

    def test_corner_neighbors(self):
        neighbors_a1 = self.board.neighbors((0, 0))
        self.assertEqual(len(neighbors_a1), 2)
        self.assertIn((1, 0), neighbors_a1)
        self.assertIn((0, 1), neighbors_a1)

    def test_edge_neighbors(self):
        neighbors_a2 = self.board.neighbors((0, 1))
        self.assertEqual(len(neighbors_a2), 3)
        self.assertIn((1, 1), neighbors_a2)
        self.assertIn((0, 0), neighbors_a2)
        self.assertIn((0, 2), neighbors_a2)

    def test_inner_neighbors(self):
        neighbors_d4 = self.board.neighbors((3, 3))
        self.assertEqual(len(neighbors_d4), 4)
        expected = {(2,3),(4,3),(3,2),(3,4)}
        self.assertEqual(set(neighbors_d4), expected)

class TestEyeAndKoDetection(unittest.TestCase):
    def setUp(self):
        # Complex board with potential eyes and ko situations
        self.board = Board.from_text("""
        . B B . . . . . .
        B W W B . . . . .
        B W B B . . . . .
        . B B . . . . . .
        . . . . . . . . .
        . . . . . . . . .
        . . . . . . . . .
        . . . . . . . . .
        . . . . . . . . .
        """.strip())

    def test_is_koish(self):
        # Place black at (3,2) would capture white at (2,2) creating ko
        self.assertTrue(self.board.is_koish((3,2), StoneColor.BLACK))
        # Non-ko position
        self.assertFalse(self.board.is_koish((4,4), StoneColor.BLACK))

    def test_is_eyeish(self):
        # (2,1) is a surrounded eye for black
        self.assertTrue(self.board.is_eyeish((2,1), StoneColor.BLACK))
        # (5,5) is not an eye
        self.assertFalse(self.board.is_eyeish((5,5), StoneColor.WHITE))

class TestLibertyTracker(unittest.TestCase):
    def setUp(self):
        self.tracker = LibertyTracker(9)

    def test_group_merging_and_liberties(self):
        self.tracker.add_stone(StoneColor.BLACK, (2,2))
        self.tracker.add_stone(StoneColor.BLACK, (2,3))
        self.tracker.add_stone(StoneColor.WHITE, (3,2))
        self.tracker.add_stone(StoneColor.WHITE, (3,3))
        group_black = self.tracker.get_group((2,2))
        group_white = self.tracker.get_group((3,2))
        self.assertEqual(len(group_black), 2)
        self.assertEqual(len(group_white), 2)
        self.assertEqual(self.tracker.liberties((2,2)), 6)
        self.assertEqual(self.tracker.liberties((3,2)), 6)

    def test_capture_multiple_groups(self):
        # Place white stones forming two separate groups
        self.tracker.add_stone(StoneColor.WHITE, (0,0))
        self.tracker.add_stone(StoneColor.WHITE, (4,4))
        # Place black stones to surround both
        for x in range(9):
            self.tracker.add_stone(StoneColor.BLACK, (x,1))
        for y in range(9):
            self.tracker.add_stone(StoneColor.BLACK, (1,y))
        # White groups should be captured
        self.assertIsNone(self.tracker.get_stone((0,0)))
        self.assertIsNone(self.tracker.get_stone((4,4)))

    def test_ko_enforcement(self):
        # Setup simple ko
        self.tracker.add_stone(StoneColor.BLACK, (2,2))
        self.tracker.add_stone(StoneColor.WHITE, (3,2))
        self.tracker.add_stone(StoneColor.WHITE, (2,3))
        self.tracker.add_stone(StoneColor.WHITE, (1,2))
        # Black captures white at (3,2)
        self.tracker.add_stone(StoneColor.BLACK, (3,2))
        # White attempts immediate recapture
        can_capture = self.tracker.can_place(StoneColor.WHITE, (2,2))
        self.assertFalse(can_capture)

class TestGamePositionHandling(unittest.TestCase):
    def setUp(self):
        self.game = Game(9)

    def test_move_and_pass(self):
        self.game.play_move(parse_kgs_coords("D4"), StoneColor.BLACK)
        self.assertEqual(self.game.board.get_stone((3,3)), StoneColor.BLACK)
        self.game.pass_turn()
        self.assertEqual(self.game.turn, StoneColor.WHITE)

    def test_suicidal_move(self):
        # Surround (2,2) with white, black has no liberties
        self.game.play_move(parse_kgs_coords("D4"), StoneColor.BLACK)
        self.game.play_move(parse_kgs_coords("C4"), StoneColor.WHITE)
        self.game.play_move(parse_kgs_coords("E4"), StoneColor.WHITE)
        self.game.play_move(parse_kgs_coords("D3"), StoneColor.WHITE)
        self.game.play_move(parse_kgs_coords("D5"), StoneColor.WHITE)
        self.assertFalse(self.game.is_legal_move(parse_kgs_coords("D4"), StoneColor.BLACK))

    def test_ko_rule(self):
        # Setup a ko situation
        self.game.play_move(parse_kgs_coords("C3"), StoneColor.BLACK)
        self.game.play_move(parse_kgs_coords("C4"), StoneColor.WHITE)
        self.game.play_move(parse_kgs_coords("B4"), StoneColor.WHITE)
        self.game.play_move(parse_kgs_coords("D4"), StoneColor.WHITE)
        self.game.play_move(parse_kgs_coords("C4"), StoneColor.BLACK)  # Capture
        self.game.play_move(parse_kgs_coords("C3"), StoneColor.WHITE)  # Ko capture
        # Immediate recapture should be illegal
        self.assertFalse(self.game.is_legal_move(parse_kgs_coords("C4"), StoneColor.BLACK))

class TestScoringValidation(unittest.TestCase):
    def setUp(self):
        self.game = Game(9)

    def test_basic_score(self):
        # Simple capture
        self.game.play_move(parse_kgs_coords("A1"), StoneColor.BLACK)
        self.game.play_move(parse_kgs_coords("A2"), StoneColor.WHITE)
        self.game.play_move(parse_kgs_coords("B1"), StoneColor.WHITE)
        self.game.play_move(parse_kgs_coords("B2"), StoneColor.WHITE)
        # Black captures at A2
        self.game.play_move(parse_kgs_coords("A2"), StoneColor.BLACK)
        black_score, white_score = self.game.score(komi=6.5)
        self.assertEqual(black_score, 1 + 6.5)  # territory + komi
        self.assertEqual(white_score, 0)

    def test_territory_with_eye(self):
        # Black forms a territory with a big eye
        for y in range(3,6):
            for x in range(3,6):
                self.game.play_move(parse_kgs_coords(chr(ord('A')+x) + str(9-y)), StoneColor.BLACK)
        self.game.play_move(parse_kgs_coords("D5"), StoneColor.BLACK)  # eye
        black_score, white_score = self.game.score(komi=6.5)
        self.assertTrue(black_score > 6.5)
        self.assertTrue(white_score < black_score)

if __name__ == "__main__":
    unittest.main()
