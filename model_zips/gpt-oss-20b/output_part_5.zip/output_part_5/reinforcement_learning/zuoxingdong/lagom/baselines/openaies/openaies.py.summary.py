import numpy as np
import torch
import torch.nn.functional as F

class EvolutionStrategy:
    def __init__(self, x0, sigma0, opts):
        self.opts = opts
        # Reproducibility
        seed = opts.get("seed", 42)
        np.random.seed(seed)
        torch.manual_seed(seed)

        # Mean parameter
        self.x = torch.tensor(x0, dtype=torch.float32, requires_grad=True)
        # Standard deviation
        self.sigma0 = torch.tensor(sigma0, dtype=torch.float32)
        self.sigma = torch.tensor(sigma0, dtype=torch.float32)

        # Optimizer and learning rate scheduler
        lr = opts.get("learning_rate", 1e-3)
        self.optimizer = torch.optim.Adam([self.x], lr=lr)
        lr_gamma = opts.get("lr_gamma", 0.99)
        self.scheduler = torch.optim.lr_scheduler.ExponentialLR(self.optimizer, gamma=lr_gamma)

        # Hyperparameters
        self.pop_size = opts.get("pop_size", 64)
        self.max_iter = opts.get("max_iter", 1000)
        self.rank_transform = opts.get("rank_transform", False)
        self.antithetic = opts.get("antithetic", False)

        if self.antithetic and self.pop_size % 2 != 0:
            raise ValueError("Population size must be even when antithetic sampling is enabled.")

        # Tracking best solution
        self.xbest = None
        self.fbest = None
        self.iter = 0
        self.eps = None

    def ask(self):
        pop = self.pop_size
        dim = self.x.shape
        if self.antithetic:
            half = pop // 2
            eps = np.random.randn(half, *dim)
            eps = np.concatenate([eps, -eps], axis=0)
        else:
            eps = np.random.randn(pop, *dim)
        self.eps = eps
        noise = eps * self.sigma.numpy()
        solutions = self.x.detach().numpy() + noise
        return solutions

    def tell(self, fitness):
        pop = self.pop_size
        eps = self.eps
        fitness = np.asarray(fitness, dtype=np.float32)

        # Rank transformation
        if self.rank_transform:
            ranks = np.argsort(np.argsort(fitness))
            norm = (ranks + 1) / (pop + 1)
            fitness_std = norm - 0.5
        else:
            mean = np.mean(fitness)
            std = np.std(fitness) + 1e-8
            fitness_std = (fitness - mean) / std

        # Best solution
        best_idx = np.argmin(fitness)
        if self.xbest is None or fitness[best_idx] < self.fbest:
            self.xbest = np.copy(self.x.detach().numpy() + eps[best_idx] * self.sigma.numpy())
            self.fbest = fitness[best_idx]

        # Gradient estimate
        eps_t = torch.tensor(eps, dtype=torch.float32)
        f_t = torch.tensor(fitness_std, dtype=torch.float32).reshape(pop, 1, *([1] * (len(self.x.shape) - 1)))
        grad = (eps_t * f_t).mean(dim=0) / self.sigma
        # For minimization, use negative gradient
        self.x.grad = -grad
        self.optimizer.step()
        self.scheduler.step()

        # Update sigma linearly
        self.iter += 1
        decay = 1.0 - self.iter / self.max_iter
        self.sigma = self.sigma0 * decay

    @property
    def result(self):
        return {
            "xbest": self.xbest,
            "fbest": self.fbest,
            "iterations": self.iter,
            "xfavorite": self.x.detach().numpy(),
            "stds": self.sigma.numpy()
        }