import pathlib
import shutil
import numpy as np
import pytest
from lagom.experiment import Grid, Sample, Condition, Config, run_experiment


@pytest.mark.parametrize(
    "values,expected_length",
    [
        ([1, 2, 3], 3),
        (["MLP", "LSTM"], 2),
    ],
)
def test_grid_initialization(values, expected_length):
    grid = Grid(values)
    result = list(grid)
    assert isinstance(result, list)
    assert len(result) == expected_length
    assert result == values


def test_sample_fixed_value():
    sample = Sample(lambda: 5)
    results = [sample() for _ in range(10)]
    assert all(r == 5 for r in results)


def test_sample_random_value():
    rng = np.random.default_rng(0)
    sample = Sample(lambda: rng.integers(3, 8))
    samples = [sample() for _ in range(100)]
    assert all(3 <= s <= 7 for s in samples)


def test_condition_logic():
    cond = Condition(
        lambda cfg: 10 if cfg.get("one") == "ten" else -1
    )
    assert cond({"one": "ten"}) == 10
    assert cond({"one": "not"}) == -1


def test_config_invalid_initialization():
    with pytest.raises(AssertionError):
        Config([1, 2, 3])  # non-dictionary input should raise


def test_config_mixed_elements(tmp_path):
    rng = np.random.default_rng(42)
    config_dict = {
        "network": {
            "lr": Grid([0.01, 0.02]),
            "size": 64,
            "beta": Condition(lambda cfg: cfg["network"]["alpha"] * 0.5),
        },
        "alpha": Sample(lambda: rng.integers(1, 5)),
        "iter": Grid([10, 20, 30]),
    }
    cfg = Config(config_dict, num_sample=2, keep_dict_order=True)
    configurations = cfg.configurations  # assume attribute providing list
    expected_len = 2 * 3 * 2  # lr options * iter options * sample draws
    assert len(configurations) == expected_len
    for conf in configurations:
        assert "ID" in conf
        alpha_val = conf["alpha"]
        assert conf["network"]["beta"] == pytest.approx(alpha_val * 0.5)


def test_config_non_random_sampling():
    config_dict = {
        "network": {
            "lr": Grid([0.01, 0.02]),
            "size": 64,
        },
        "alpha": 0.5,  # fixed value
        "iter": Grid([10, 20, 30]),
    }
    cfg = Config(config_dict, num_sample=2)
    configurations = cfg.configurations
    # Only two lr options and three iter options, alpha fixed -> 2*3*1 = 6
    assert len(configurations) == 6
    for conf in configurations:
        assert conf["alpha"] == 0.5


def test_config_fully_fixed_parameters():
    config_dict = {
        "network": {
            "lr": 0.01,
            "size": 64,
        },
        "alpha": 0.5,
        "iter": 10,
    }
    cfg = Config(config_dict, num_sample=5)
    configurations = cfg.configurations
    assert len(configurations) == 1
    assert configurations[0]["alpha"] == 0.5
    assert configurations[0]["network"]["lr"] == 0.01


def test_run_experiment(tmp_path):
    def mock_run(cfg, seed):
        return {"config": cfg, "seed": seed}

    config_dict = {
        "network": {
            "lr": Grid([0.01, 0.02]),
            "size": Grid([16, 32]),
        },
        "env": {
            "id": Grid(["A", "B"]),
        },
    }
    cfg = Config(config_dict, num_sample=2)
    log_dir = tmp_path / "experiment_log"
    run_experiment(
        cfg,
        run=mock_run,
        seeds=[42, 43],
        log_dir=log_dir,
        max_workers=2,
        chunksize=1,
    )
    assert (log_dir / "configs.pkl").exists()
    source_dir = log_dir / "source_files"
    assert source_dir.exists() and source_dir.is_dir()
    for config_id in cfg.configurations:
        config_id_dir = log_dir / str(config_id["ID"])
        assert config_id_dir.exists()
        for seed in [42, 43]:
            seed_dir = config_id_dir / str(seed)
            assert seed_dir.exists()

    # Clean up
    shutil.rmtree(log_dir)
    assert not log_dir.exists()
