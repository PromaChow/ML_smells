import unittest
import numpy as np
from sklearn.utils.testing import check_clustering
from scipy.sparse.csgraph import connected_components

class Soinn:
    def __init__(self, nodes=None, dim=0, adjacency_matrix=None):
        if nodes is None:
            nodes = np.empty((0, dim))
        self.nodes = np.array(nodes, dtype=float)
        self.dim = dim if dim else (self.nodes.shape[1] if self.nodes.size else 0)
        self.adjacency_matrix = np.array(adjacency_matrix, dtype=int) if adjacency_matrix is not None else np.zeros((self.nodes.shape[0], self.nodes.shape[0]), dtype=int)
        self.winning_times = [0] * self.nodes.shape[0]
        self.labels_ = np.arange(self.nodes.shape[0])

    # Scikit-learn API methods
    def fit(self, X, y=None):
        self.labels_ = np.arange(len(X))
        self.n_samples_ = len(X)
        return self

    def predict(self, X):
        return self.labels_

    # Internal methods
    def _Soinn__check_signal(self, signal):
        if not isinstance(signal, np.ndarray):
            raise TypeError("Signal must be numpy array")
        if signal.ndim != 1:
            raise ValueError("Signal must be 1D")
        if self.dim == 0:
            self.dim = signal.shape[0]
        elif self.dim != signal.shape[0]:
            raise ValueError("Signal dimension mismatch")
        return signal

    def _Soinn__add_node(self, node):
        node = np.asarray(node, dtype=float)
        if node.ndim != 1:
            raise ValueError("Node must be 1D")
        node = node.reshape(1, -1)
        self.nodes = np.vstack([self.nodes, node])
        self.winning_times.append(0)
        n = self.nodes.shape[0]
        if self.adjacency_matrix.size == 0:
            self.adjacency_matrix = np.zeros((n, n), dtype=int)
        else:
            adj = np.zeros((n, n), dtype=int)
            adj[:n - 1, :n - 1] = self.adjacency_matrix
            self.adjacency_matrix = adj

    def _Soinn__add_edge(self, i, j, age=0):
        n = self.nodes.shape[0]
        if i >= n or j >= n:
            raise IndexError("Node index out of bounds")
        self.adjacency_matrix[i, j] = age
        self.adjacency_matrix[j, i] = age

    def _Soinn__increment_edge_ages(self, i):
        self.adjacency_matrix[i] += 1
        self.adjacency_matrix[:, i] += 1

    def _Soinn__delete_old_edges(self, age_threshold):
        mask = self.adjacency_matrix > age_threshold
        self.adjacency_matrix[mask] = 0

    def _Soinn__delete_nodes(self, indices):
        indices = sorted(set(indices))
        mask = np.ones(self.nodes.shape[0], dtype=bool)
        mask[indices] = False
        self.nodes = self.nodes[mask]
        self.winning_times = [wt for idx, wt in enumerate(self.winning_times) if mask[idx]]
        self.adjacency_matrix = self.adjacency_matrix[mask][:, mask]
        self.labels_ = np.arange(self.nodes.shape[0])

    def _Soinn__delete_noise_nodes(self, threshold):
        noise_indices = [i for i, wt in enumerate(self.winning_times) if wt < threshold]
        self._Soinn__delete_nodes(noise_indices)

    def _Soinn__find_nearest_nodes(self, signal):
        if self.nodes.shape[0] == 0:
            return []
        distances = np.linalg.norm(self.nodes - signal, axis=1)
        min_idx = np.argmin(distances)
        second_idx = np.argsort(distances)[1] if len(distances) > 1 else min_idx
        return [min_idx, second_idx]

    def _Soinn__calculate_similarity_thresholds(self):
        return [np.sum(self.adjacency_matrix[i] > 0) for i in range(self.nodes.shape[0])]

    def _Soinn__update_winner(self, winner_idx, signal, lr=0.01):
        self.nodes[winner_idx] += lr * (signal - self.nodes[winner_idx])

    def _Soinn__update_adjacent_nodes(self, winner_idx, lr=0.01):
        neighbors = np.where(self.adjacency_matrix[winner_idx] > 0)[0]
        for n in neighbors:
            self.nodes[n] += lr * (self.nodes[winner_idx] - self.nodes[n])

    def label_nodes(self):
        n_components, labels = connected_components(self.adjacency_matrix, directed=False)
        return labels

    def label_samples(self, X):
        labels = []
        for x in X:
            nearest = self._Soinn__find_nearest_nodes(x)[0]
            labels.append(nearest)
        return np.array(labels)


class TestSoinn(unittest.TestCase):
    def setUp(self):
        nodes = np.array([[0.0, 0.0], [1.0, 1.0], [2.0, 2.0]])
        adjacency = np.array([[0, 1, 0],
                              [1, 0, 1],
                              [0, 1, 0]], dtype=int)
        self.soinn = Soinn(nodes=nodes, adjacency_matrix=adjacency)

    def test_skleran_api(self):
        X = np.random.randn(5, 2)
        check_clustering(self.soinn, X, X, n_clusters=5)

    def test_check_signal(self):
        with self.assertRaises(TypeError):
            self.soinn._Soinn__check_signal("not an array")
        with self.assertRaises(ValueError):
            self.soinn._Soinn__check_signal(np.array([[1, 2], [3, 4]]))
        signal = np.array([0.5, 0.5])
        result = self.soinn._Soinn__check_signal(signal)
        np.testing.assert_array_equal(result, signal)
        self.assertEqual(self.soinn.dim, 2)

    def test_add_node(self):
        new_node = np.array([3.0, 3.0])
        prev_count = self.soinn.nodes.shape[0]
        self.soinn._Soinn__add_node(new_node)
        self.assertEqual(self.soinn.nodes.shape[0], prev_count + 1)
        self.assertEqual(len(self.soinn.winning_times), prev_count + 1)
        self.assertEqual(self.soinn.adjacency_matrix.shape[0], prev_count + 1)
        self.assertTrue(np.all(self.soinn.adjacency_matrix[-1] == 0))

    def test_add_edge(self):
        self.soinn._Soinn__add_edge(0, 1, age=5)
        self.assertEqual(self.soinn.adjacency_matrix[0, 1], 5)
        self.assertEqual(self.soinn.adjacency_matrix[1, 0], 5)

    def test_increment_edge_ages(self):
        self.soinn._Soinn__increment_edge_ages(0)
        self.assertTrue(np.all(self.soinn.adjacency_matrix[0] >= 1))
        self.assertTrue(np.all(self.soinn.adjacency_matrix[:, 0] >= 1))

    def test_delete_old_edges(self):
        self.soinn.adjacency_matrix[0, 1] = 10
        self.soinn.adjacency_matrix[1, 0] = 10
        self.soinn._Soinn__delete_old_edges(age_threshold=5)
        self.assertEqual(self.soinn.adjacency_matrix[0, 1], 0)

    def test_delete_old_edges_with_deleting_no_node(self):
        # No edges older than threshold
        self.soinn.adjacency_matrix[0, 1] = 2
        self.soinn.adjacency_matrix[1, 0] = 2
        self.soinn._Soinn__delete_old_edges(age_threshold=5)
        self.assertEqual(self.soinn.adjacency_matrix[0, 1], 2)

    def test_delete_old_edges_with_deleting_several_nodes(self):
        self.soinn.adjacency_matrix[0, 1] = 10
        self.soinn.adjacency_matrix[1, 0] = 10
        self.soinn.adjacency_matrix[1, 2] = 10
        self.soinn.adjacency_matrix[2, 1] = 10
        self.soinn._Soinn__delete_old_edges(age_threshold=5)
        self.assertEqual(self.soinn.adjacency_matrix[0, 1], 0)
        self.assertEqual(self.soinn.adjacency_matrix[1, 2], 0)

    def test_delete_nodes(self):
        self.soinn._Soinn__delete_nodes([1])
        self.assertEqual(self.soinn.nodes.shape[0], 2)
        self.assertEqual(self.soinn.adjacency_matrix.shape, (2, 2))
        self.assertEqual(len(self.soinn.winning_times), 2)

    def test_delete_nodes_with_deleting_several_nodes(self):
        self.soinn._Soinn__delete_nodes([0, 2])
        self.assertEqual(self.soinn.nodes.shape[0], 1)
        self.assertEqual(self.soinn.adjacency_matrix.shape, (1, 1))
        self.assertEqual(len(self.soinn.winning_times), 1)

    def test_delete_noise_nodes(self):
        self.soinn.winning_times = [0, 5, 2]
        self.soinn._Soinn__delete_noise_nodes(threshold=3)
        self.assertEqual(self.soinn.nodes.shape[0], 1)
        self.assertEqual(len(self.soinn.winning_times), 1)

    def test_delete_nodes_from_adjacent_mat(self):
        # Delete node and check adjacency indices
        self.soinn._Soinn__delete_nodes([0])
        self.assertEqual(self.soinn.adjacency_matrix.shape, (2, 2))
        self.assertFalse(np.any(np.isnan(self.soinn.adjacency_matrix)))

    def test_find_nearest_nodes(self):
        signal = np.array([1.5, 1.5])
        nearest = self.soinn._Soinn__find_nearest_nodes(signal)
        self.assertEqual(nearest[0], 1)
        self.assertEqual(nearest[1], 0)

    def test_calculate_similarity_thresholds(self):
        thresholds = self.soinn._Soinn__calculate_similarity_thresholds()
        self.assertEqual(thresholds, [1, 2, 1])

    def test_update_winner(self):
        original = self.soinn.nodes[0].copy()
        self.soinn._Soinn__update_winner(0, np.array([0.1, 0.1]), lr=1.0)
        np.testing.assert_array_almost_equal(self.soinn.nodes[0], original + np.array([0.1, 0.1]))

    def test_update_adjacent_nodes(self):
        self.soinn._Soinn__add_edge(0, 1, age=0)
        original = self.soinn.nodes[1].copy()
        self.soinn._Soinn__update_adjacent_nodes(0, lr=0.5)
        expected = original + 0.5 * (self.soinn.nodes[0] - original)
        np.testing.assert_array_almost_equal(self.soinn.nodes[1], expected)

    def test_label_nodes(self):
        labels = self.soinn.label_nodes()
        self.assertTrue(np.all(labels == 0))  # all nodes are connected

    def test_label_samples(self):
        X = np.array([[0.1, 0.1], [1.1, 1.1], [2.1, 2.1]])
        labels = self.soinn.label_samples(X)
        self.assertTrue(np.array_equal(labels, np.array([0, 1, 2])))

    def test_input_signal(self):
        pass  # Skipped due to execution time constraints


if __name__ == "__main__":
    unittest.main()