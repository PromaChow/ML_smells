import unittest
import numpy as np
from pywsl.ssl.pnu_mr import PNU_SL_FastCV, gendata, calc_err, calc_etab


class TestPNU_SL_FastCV(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.n_l = 50
        cls.n_u = 100
        cls.n_t = 200
        cls.prior_l = 0.6
        cls.prior_u = 0.4

        # Generate data
        data = gendata(cls.n_l, cls.n_u, cls.n_t, cls.prior_l, cls.prior_u)
        if isinstance(data, tuple):
            cls.x_l, cls.y_l, cls.x_u, cls.x_tp, cls.x_tn = data
        elif isinstance(data, dict):
            cls.x_l = data["x_l"]
            cls.y_l = data["y_l"]
            cls.x_u = data["x_u"]
            cls.x_tp = data["x_tp"]
            cls.x_tn = data["x_tn"]
        else:
            raise TypeError("gendata returned unexpected format")

        cls.n_pos = np.sum(cls.y_l == 1)
        cls.n_neg = np.sum(cls.y_l == -1)

    def _evaluate(self, basis="lm", eta_list=None, lambda_list=None, nargout=1):
        if eta_list is not None:
            model = PNU_SL_FastCV(
                self.x_l, self.y_l, self.x_u,
                basis=basis, eta_list=eta_list, nargout=nargout
            )
        else:
            model = PNU_SL_FastCV(
                self.x_l, self.y_l, self.x_u,
                basis=basis, lambda_list=lambda_list, nargout=nargout
            )
        if nargout == 1:
            f_dec = model
        else:
            f_dec = model[0]
        err = calc_err(f_dec, self.x_tp, self.x_tn, self.prior_l)
        return err, f_dec

    def test_linear_cross_validation(self):
        eta_list = [0.1, 0.5, 1.0]
        err, _ = self._evaluate(basis="lm", eta_list=eta_list, nargout=1)
        self.assertLess(err, 0.3)

    def test_linear_single_eta(self):
        eta = calc_etab(self.n_pos, self.n_neg, self.prior_l)
        err, _ = self._evaluate(basis="lm", eta_list=[eta], nargout=1)
        self.assertLess(err, 0.3)

    def test_model_without_cross_validation(self):
        lambda_list = [0.1, 1.0]
        err, _ = self._evaluate(basis="lm", lambda_list=lambda_list, nargout=1)
        self.assertLess(err, 0.3)

    def test_nargout_configurations(self):
        # nargout = 3
        err3, f_dec3 = self._evaluate(basis="lm", eta_list=[0.5], nargout=3)
        self.assertIsInstance(f_dec3, tuple)
        self.assertEqual(len(f_dec3), 3)
        # nargout = 2
        err2, f_dec2 = self._evaluate(basis="lm", eta_list=[0.5], nargout=2)
        self.assertIsInstance(f_dec2, tuple)
        self.assertEqual(len(f_dec2), 2)
        # nargout = 1
        err1, f_dec1 = self._evaluate(basis="lm", eta_list=[0.5], nargout=1)
        self.assertTrue(callable(f_dec1))

    def test_gaussian_basis(self):
        eta_list = [0.1, 0.5, 1.0]
        err, _ = self._evaluate(basis="gauss", eta_list=eta_list, nargout=1)
        self.assertLess(err, 0.3)

    def test_invalid_labels(self):
        y_l_invalid = self.y_l.copy()
        y_l_invalid[0] = 2
        with self.assertRaises(ValueError):
            PNU_SL_FastCV(
                self.x_l, y_l_invalid, self.x_u,
                basis="lm", eta_list=[0.5], nargout=1
            )

    def test_invalid_basis(self):
        with self.assertRaises(ValueError):
            PNU_SL_FastCV(
                self.x_l, self.y_l, self.x_u,
                basis="DNN", eta_list=[0.5], nargout=1
            )

    def test_calc_etab(self):
        eta_pos = calc_etab(self.n_pos, self.n_neg, 0.4)
        eta_neg = calc_etab(self.n_neg, self.n_pos, 0.6)
        eta_zero = calc_etab(self.n_pos, self.n_pos, 0.5)
        self.assertGreater(eta_pos, 0)
        self.assertLess(eta_neg, 0)
        self.assertAlmostEqual(eta_zero, 0.0, places=6)


if __name__ == "__main__":
    unittest.main()