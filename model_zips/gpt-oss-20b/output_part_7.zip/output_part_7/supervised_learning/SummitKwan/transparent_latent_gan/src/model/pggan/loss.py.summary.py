import tensorflow as tf

def fp32(x):
    return tf.cast(x, tf.float32)

def G_wgan_acgan(G, D, training_set, cond_weight):
    """Generator loss for WGAN-GP with AC-GAN."""
    labels = training_set.get_random_labels_tf()
    batch_size = tf.shape(labels)[0]
    latent_shape = tf.concat([[batch_size]], G.input_shapes[0][1:], axis=0)
    latent = tf.random.normal(latent_shape, dtype=tf.float32)

    fake_images_out = G(latent, labels)
    fake_scores_out, fake_labels_out = D(fake_images_out)

    loss = -tf.reduce_mean(fake_scores_out)

    if len(D.output_shapes) > 1 and D.output_shapes[1][1] > 0:
        ce = tf.nn.softmax_cross_entropy_with_logits_v2(
            labels=labels, logits=fake_labels_out)
        loss += cond_weight * tf.reduce_mean(ce)

    return fp32(loss)

def D_wgangp_acgan(D, G, training_set, cond_weight, wgan_lambda,
                   wgan_epsilon, wgan_target):
    """Discriminator loss for WGAN-GP with AC-GAN."""
    labels = training_set.get_random_labels_tf()
    batch_size = tf.shape(labels)[0]
    latent_shape = tf.concat([[batch_size]], G.input_shapes[0][1:], axis=0)
    latent = tf.random.normal(latent_shape, dtype=tf.float32)

    real_images = training_set.reals
    fake_images_out = G(latent, labels)

    real_scores_out, real_labels_out = D(real_images)
    fake_scores_out, fake_labels_out = D(fake_images_out)

    base_loss = tf.reduce_mean(fake_scores_out - real_scores_out)

    # Gradient penalty
    mixing_factors = tf.random.uniform(
        tf.shape(real_images)[:1] + (1, 1, 1), 0., 1., dtype=tf.float32)
    mixed_images_out = mixing_factors * real_images + (1 - mixing_factors) * fake_images_out

    with tf.GradientTape() as tape:
        tape.watch(mixed_images_out)
        mixed_scores_out, _ = D(mixed_images_out)
    gradients = tape.gradient(mixed_scores_out, mixed_images_out)
    mixed_norms = tf.sqrt(
        tf.reduce_sum(tf.square(gradients), axis=[1, 2, 3]) + 1e-12)
    gp = wgan_lambda / (wgan_target ** 2) * tf.reduce_mean(
        tf.square(mixed_norms - wgan_target))

    # Epsilon penalty
    ep = wgan_epsilon * tf.reduce_mean(tf.square(real_scores_out))

    loss = base_loss + gp + ep

    if len(D.output_shapes) > 1 and D.output_shapes[1][1] > 0:
        label_penalty_reals = tf.nn.softmax_cross_entropy_with_logits_v2(
            labels=labels, logits=real_labels_out)
        label_penalty_fakes = tf.nn.softmax_cross_entropy_with_logits_v2(
            labels=labels, logits=fake_labels_out)
        loss += cond_weight * tf.reduce_mean(
            label_penalty_reals + label_penalty_fakes)

    return fp32(loss)