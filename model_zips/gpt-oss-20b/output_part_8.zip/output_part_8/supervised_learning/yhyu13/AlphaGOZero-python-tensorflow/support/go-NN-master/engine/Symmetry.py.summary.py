import numpy as np

BIT_X = 1
BIT_Y = 2
BIT_SWAP = 4


def apply_symmetry_features_example(many_planes: np.ndarray, i: int, s: int) -> None:
    """Apply symmetry to a specific plane in a 4‑D array."""
    temp = np.copy(many_planes[i])
    if s & BIT_X:          # flip height (x‑axis)
        temp = np.flip(temp, axis=1)
    if s & BIT_Y:          # flip width (y‑axis)
        temp = np.flip(temp, axis=2)
    if s & BIT_SWAP:       # swap height and width
        temp = np.transpose(temp, (0, 2, 1))
    many_planes[i] = temp


def apply_symmetry_planes(planes: np.ndarray, s: int) -> None:
    """Apply symmetry to a 3‑D array (height, width, channels)."""
    temp = np.copy(planes)
    if s & BIT_X:          # flip height
        temp = np.flip(temp, axis=0)
    if s & BIT_Y:          # flip width
        temp = np.flip(temp, axis=1)
    if s & BIT_SWAP:       # swap height and width
        temp = np.transpose(temp, (1, 0, 2))
    np.copyto(planes, temp)


def apply_symmetry_plane(plane: np.ndarray, s: int) -> None:
    """Apply symmetry to a 2‑D array (height, width)."""
    temp = np.copy(plane)
    if s & BIT_X:          # flip height
        temp = np.flip(temp, axis=0)
    if s & BIT_Y:          # flip width
        temp = np.flip(temp, axis=1)
    if s & BIT_SWAP:       # swap height and width
        temp = np.transpose(temp)
    np.copyto(plane, temp)


def invert_symmetry_plane(plane: np.ndarray) -> None:
    """Undo the symmetry applied by apply_symmetry_plane."""
    temp = np.copy(plane)
    # reverse order: swap, flip y, flip x
    temp = np.transpose(temp)
    temp = np.flip(temp, axis=1)
    temp = np.flip(temp, axis=0)
    np.copyto(plane, temp)


def apply_symmetry_vertex(vertex: list, N: int, s: int) -> None:
    """Apply symmetry to a vertex coordinate in an N×N grid."""
    x, y = vertex
    if s & BIT_X:
        x = N - x - 1
    if s & BIT_Y:
        y = N - y - 1
    if s & BIT_SWAP:
        x, y = y, x
    vertex[0] = x
    vertex[1] = y


def get_symmetry_vertex_tuple(vertex: tuple, N: int, s: int) -> tuple:
    """Return a transformed vertex as a tuple."""
    x, y = vertex
    if s & BIT_X:
        x = N - x - 1
    if s & BIT_Y:
        y = N - y - 1
    if s & BIT_SWAP:
        x, y = y, x
    return (x, y)


def get_inverse_symmetry_vertex_tuple(vertex: tuple, N: int, s: int) -> tuple:
    """Return the vertex after applying the inverse symmetry."""
    x, y = vertex
    if s & BIT_SWAP:
        x, y = y, x
    if s & BIT_Y:
        y = N - y - 1
    if s & BIT_X:
        x = N - x - 1
    return (x, y)


def make_symmetry_batch(features: np.ndarray) -> np.ndarray:
    """Generate a batch of 8 symmetry‑transformed copies of a feature map."""
    N, _, Nfeat = features.shape
    batch = np.empty((8, N, N, Nfeat), dtype=features.dtype)
    for s in range(8):
        batch_s = np.copy(features)
        apply_symmetry_planes(batch_s, s)
        batch[s] = batch_s
    return batch


def average_plane_over_symmetries(planes_flat: np.ndarray) -> np.ndarray:
    """Average 8 planes after inverting their symmetry transformations."""
    N2 = planes_flat.shape[1]
    N = int(np.sqrt(N2))
    planes = planes_flat.reshape(8, N, N)
    for i in range(8):
        invert_symmetry_plane(planes[i])
    mean_plane = planes.mean(axis=0)
    return mean_plane.ravel()
