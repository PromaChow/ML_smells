import pandas as pd
import warnings
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn import metrics

warnings.filterwarnings("ignore")

def main():
    # 1. Data Loading and Initial Inspection
    df = pd.read_csv("horse.csv")
    print("First five rows of the dataset:")
    print(df.head())

    # 2. Missing Value Detection
    missing = df.isna().sum()
    print("\nMissing values per column:")
    print(missing)

    # 3. Target-Feature Separation
    Y = df["outcome"]
    X = df.drop(columns=["outcome"])

    # 4. Categorical Variable Encoding
    X_encoded = pd.get_dummies(X, drop_first=True)

    # 5. Missing Value Imputation
    def most_frequent(series):
        return series.value_counts().index[0]

    X_imputed = X_encoded.apply(lambda col: col.fillna(most_frequent(col)))
    
    # 6. Model Training and Evaluation
    # Decision Tree
    dt_clf = DecisionTreeClassifier(random_state=42)
    dt_clf.fit(X_imputed, Y)
    dt_pred = dt_clf.predict(X_imputed)
    dt_accuracy = metrics.accuracy_score(Y, dt_pred)
    print(f"\nDecision Tree Accuracy: {dt_accuracy:.4f}")

    # Random Forest
    rf_clf = RandomForestClassifier(n_estimators=100, random_state=42)
    rf_clf.fit(X_imputed, Y)
    rf_pred = rf_clf.predict(X_imputed)
    rf_accuracy = metrics.accuracy_score(Y, rf_pred)
    print(f"Random Forest Accuracy: {rf_accuracy:.4f}")

if __name__ == "__main__":
    main()
