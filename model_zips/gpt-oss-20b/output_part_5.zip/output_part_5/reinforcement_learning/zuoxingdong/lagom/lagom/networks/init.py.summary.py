import torch
import torch.nn as nn

def orthogonal_init_module(
    module: nn.Module,
    weight_scale: float = 1.0,
    constant_bias: float = 0.0,
    nonlinearity: str | None = None,
) -> None:
    """
    Apply orthogonal initialization to a PyTorch module.

    Args:
        module: The module to initialize.
        weight_scale: Scale factor for weight initialization when nonlinearity is None.
        constant_bias: Bias value to initialize to.
        nonlinearity: Nonlinearity name for gain calculation (e.g., "relu", "tanh").
    """
    # Determine the gain factor
    if nonlinearity is not None:
        gain = nn.init.calculate_gain(nonlinearity)
    else:
        gain = weight_scale

    # Handle RNN-based modules
    if isinstance(module, (nn.RNNBase, nn.RNNCellBase)):
        for name, param in module.named_parameters():
            if not param.requires_grad:
                continue
            if "weight_" in name:
                nn.init.orthogonal_(param, gain=gain)
            elif "bias_" in name:
                nn.init.constant_(param, constant_bias)
    else:
        # Non-RNN modules
        if hasattr(module, "weight") and module.weight is not None:
            nn.init.orthogonal_(module.weight, gain=gain)
        if hasattr(module, "bias") and module.bias is not None:
            nn.init.constant_(module.bias, constant_bias)