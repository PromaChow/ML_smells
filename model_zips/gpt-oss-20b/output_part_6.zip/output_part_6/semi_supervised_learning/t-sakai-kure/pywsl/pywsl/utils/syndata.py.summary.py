import numpy as np

def gen_twonorm_ssl(n_l, prior_l, n_u, prior_u, n_t):
    d = 2
    mu_p = np.array([1.0, 1.0])
    mu_n = np.array([-1.0, -1.0])

    # Labeled data
    n_p_l = np.random.binomial(n_l, prior_l)
    n_n_l = n_l - n_p_l
    X_l_p = np.random.randn(n_p_l, d) + mu_p
    X_l_n = np.random.randn(n_n_l, d) + mu_n
    X_l = np.vstack([X_l_p, X_l_n])
    y_l = np.concatenate([np.ones(n_p_l, dtype=int), -np.ones(n_n_l, dtype=int)])

    # Unlabeled data
    n_p_u = np.random.binomial(n_u, prior_u)
    n_n_u = n_u - n_p_u
    X_u_p = np.random.randn(n_p_u, d) + mu_p
    X_u_n = np.random.randn(n_n_u, d) + mu_n
    X_u = np.vstack([X_u_p, X_u_n])
    y_u = np.zeros(n_u, dtype=int)

    # Combine
    X = np.vstack([X_l, X_u])
    y = np.concatenate([y_l, y_u])

    # Test data
    X_t_p = np.random.randn(n_t, d) + mu_p
    X_t_n = np.random.randn(n_t, d) + mu_n
    X_t = np.vstack([X_t_p, X_t_n])
    y_t = np.concatenate([np.ones(n_t, dtype=int), -np.ones(n_t, dtype=int)])

    return X, y, X_t, y_t


def gen_twonorm_pu(n_p, n_u, prior_u, n_t):
    d = 2
    mu_p = np.array([1.0, 1.0])
    mu_n = np.array([-1.0, -1.0])

    # Positive data
    X_p = np.random.randn(n_p, d) + mu_p
    y_p = np.ones(n_p, dtype=int)

    # Unlabeled data
    n_p_u = np.random.binomial(n_u, prior_u)
    n_n_u = n_u - n_p_u
    X_u_p = np.random.randn(n_p_u, d) + mu_p
    X_u_n = np.random.randn(n_n_u, d) + mu_n
    X_u = np.vstack([X_u_p, X_u_n])
    y_u = np.zeros(n_u, dtype=int)

    # Combine
    X = np.vstack([X_p, X_u])
    y = np.concatenate([y_p, y_u])

    # Test data
    X_t_p = np.random.randn(n_t, d) + mu_p
    X_t_n = np.random.randn(n_t, d) + mu_n
    X_t = np.vstack([X_t_p, X_t_n])
    y_t = np.concatenate([np.ones(n_t, dtype=int), -np.ones(n_t, dtype=int)])

    return X, y, X_t, y_t


def gen_twonorm_pumil(n_p, n_u, prior_u, n_t, bag_size_lo=3, bag_size_hi=10):
    d = 2
    mu_p = np.array([1.0, 1.0])
    mu_n = np.array([-1.0, -1.0])

    def bag_size():
        return np.random.randint(bag_size_lo, bag_size_hi + 1)

    # Positive bags
    X_pos = []
    for _ in range(n_p):
        sz = bag_size()
        bag = np.random.randn(sz, d) + mu_p
        X_pos.append(bag)

    # Unlabeled bags
    n_p_u = np.random.binomial(n_u, prior_u)
    n_n_u = n_u - n_p_u

    X_up = []
    for _ in range(n_p_u):
        sz = bag_size()
        bag = np.random.randn(sz, d) + mu_p
        X_up.append(bag)

    X_un = []
    for _ in range(n_n_u):
        sz = bag_size()
        bag = np.random.randn(sz, d) + mu_n
        X_un.append(bag)

    X = X_pos + X_up + X_un
    y = np.concatenate([np.ones(n_p, dtype=int),
                        np.zeros(n_u, dtype=int)])

    # Test bags
    X_t_pos = []
    for _ in range(n_t):
        sz = bag_size()
        bag = np.random.randn(sz, d) + mu_p
        X_t_pos.append(bag)

    X_t_neg = []
    for _ in range(n_t):
        sz = bag_size()
        bag = np.random.randn(sz, d) + mu_n
        X_t_neg.append(bag)

    X_t = X_t_pos + X_t_neg
    y_t = np.concatenate([np.ones(n_t, dtype=int), -np.ones(n_t, dtype=int)])

    return X, y, X_t, y_t
