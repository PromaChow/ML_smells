import re
import string
from typing import List, Optional, Tuple

import numpy as np
from gensim.models import KeyedVectors
from scipy.spatial.distance import cosine
from sklearn.feature_extraction.text import TfidfVectorizer


class CentroidSummarizer:
    def __init__(
        self,
        embedding_path: str,
        zero_center: bool = False,
        topic_threshold: float = 0.3,
        bow_param: float = 0.5,
        length_param: float = 0.5,
        position_param: float = 0.5,
        similarity_threshold: float = 0.95,
        keep_first: bool = False,
        reordering: bool = False,
        limit_words: Optional[int] = None,
        limit_chars: Optional[int] = None,
    ):
        self.model = KeyedVectors.load_word2vec_format(embedding_path, binary=True)
        self.zero_center = zero_center
        self.topic_threshold = topic_threshold
        self.bow_param = bow_param
        self.length_param = length_param
        self.position_param = position_param
        self.similarity_threshold = similarity_threshold
        self.keep_first = keep_first
        self.reordering = reordering
        self.limit_words = limit_words
        self.limit_chars = limit_chars

        if self.zero_center:
            all_vecs = self.model.vectors
            self.centroid = np.mean(all_vecs, axis=0)
        else:
            self.centroid = None

    @staticmethod
    def _preprocess(text: str) -> str:
        text = text.lower()
        text = re.sub(f"[{re.escape(string.punctuation)}]", "", text)
        text = re.sub(r"\s+", " ", text).strip()
        return text

    @staticmethod
    def _tokenize(text: str) -> List[str]:
        return text.split()

    def _sentence_vector(self, tokens: List[str]) -> np.ndarray:
        vecs = [self.model[w] for w in tokens if w in self.model]
        if vecs:
            return np.mean(vecs, axis=0)
        return np.zeros(self.model.vector_size)

    def _compute_topic_vector(self, tfidf_vectorizer: TfidfVectorizer, tfidf_matrix) -> np.ndarray:
        feature_names = np.array(tfidf_vectorizer.get_feature_names_out())
        # sum tfidf across all documents (sentences)
        doc_tfidf = np.asarray(tfidf_matrix.sum(axis=0)).ravel()
        topic_indices = np.where(doc_tfidf > self.topic_threshold)[0]
        if len(topic_indices) == 0:
            return np.zeros(self.model.vector_size)
        topic_words = feature_names[topic_indices]
        vecs = [self.model[w] for w in topic_words if w in self.model]
        if vecs:
            return np.mean(vecs, axis=0)
        return np.zeros(self.model.vector_size)

    def summarize(self, text: str) -> str:
        sentences = [s.strip() for s in re.split(r'(?<=[.!?])\s+', text) if s.strip()]
        if not sentences:
            return ""

        preprocessed = [self._preprocess(s) for s in sentences]
        vectorizer = TfidfVectorizer()
        tfidf_matrix = vectorizer.fit_transform(preprocessed)

        topic_vector = self._compute_topic_vector(vectorizer, tfidf_matrix)

        sentence_vectors = []
        sentence_tfidf = []
        scores = []

        total_sentences = len(sentences)

        for idx, s in enumerate(preprocessed):
            tokens = self._tokenize(s)
            sent_vec = self._sentence_vector(tokens)
            if self.zero_center and self.centroid is not None:
                sent_vec -= self.centroid
            sentence_vectors.append(sent_vec)

            tfidf_vec = tfidf_matrix[idx].toarray().ravel()
            sentence_tfidf.append(tfidf_vec)

            # Topic similarity
            if np.linalg.norm(sent_vec) == 0 or np.linalg.norm(topic_vector) == 0:
                topic_sim = 0.0
            else:
                topic_sim = 1 - cosine(sent_vec, topic_vector)

            # TF-IDF alignment
            if np.linalg.norm(tfidf_vec) == 0 or np.linalg.norm(tfidf_matrix.sum(axis=0).A1) == 0:
                tfidf_align = 0.0
            else:
                tfidf_align = 1 - cosine(tfidf_vec, tfidf_matrix.sum(axis=0).A1)

            tfidf_align *= self.bow_param

            # Length penalty
            length_pen = 1.0 / (len(tokens) + 1e-6)

            # Positional bias
            pos_bias = (total_sentences - idx) / total_sentences
            pos_bias *= self.position_param

            factors = [topic_sim, tfidf_align, length_pen, pos_bias]
            non_zero = [f for f in factors if f != 0]
            final_score = sum(non_zero) / len(non_zero) if non_zero else 0.0
            scores.append(final_score)

        # Sentence selection
        scored_sentences = sorted(
            [(i, s, scores[i], sentence_vectors[i]) for i, s in enumerate(sentences)],
            key=lambda x: x[2],
            reverse=True,
        )

        selected_indices = []
        selected_vectors = []

        if self.keep_first:
            selected_indices.append(0)
            selected_vectors.append(sentence_vectors[0])

        for idx, sent, score, vec in scored_sentences:
            if idx in selected_indices:
                continue
            if any(
                1 - cosine(vec, sv) > self.similarity_threshold for sv in selected_vectors
            ):
                continue
            selected_indices.append(idx)
            selected_vectors.append(vec)

        if self.reordering:
            selected_indices.sort()

        selected_sentences = [sentences[i] for i in selected_indices]

        # Enforce length limit
        if self.limit_words is not None:
            word_counts = [len(s.split()) for s in selected_sentences]
            cum_words = 0
            final_sentences = []
            for s, wc in zip(selected_sentences, word_counts):
                if cum_words + wc > self.limit_words:
                    break
                final_sentences.append(s)
                cum_words += wc
            selected_sentences = final_sentences

        if self.limit_chars is not None:
            char_counts = [len(s) for s in selected_sentences]
            cum_chars = 0
            final_sentences = []
            for s, cc in zip(selected_sentences, char_counts):
                if cum_chars + cc > self.limit_chars:
                    break
                final_sentences.append(s)
                cum_chars += cc
            selected_sentences = final_sentences

        return " ".join(selected_sentences)
