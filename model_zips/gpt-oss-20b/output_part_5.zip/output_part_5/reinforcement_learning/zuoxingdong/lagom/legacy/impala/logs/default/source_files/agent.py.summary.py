import gym
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.distributions import Categorical, Normal
from collections import namedtuple
import numpy as np
import math
import os

# Configuration dataclass
class Config:
    def __init__(self,
                 hidden_sizes=(128, 128),
                 lr=3e-4,
                 gamma=0.99,
                 rho_clip=1.0,
                 pg_rho_clip=1.0,
                 value_coef=0.5,
                 entropy_coef=0.01,
                 max_grad_norm=0.5,
                 std_init=0.1,
                 normalize_obs=False,
                 obs_norm_clip=10.0,
                 use_lr_scheduler=False,
                 lr_decay=0.0,
                 standardize_adv=True):
        self.hidden_sizes = hidden_sizes
        self.lr = lr
        self.gamma = gamma
        self.rho_clip = rho_clip
        self.pg_rho_clip = pg_rho_clip
        self.value_coef = value_coef
        self.entropy_coef = entropy_coef
        self.max_grad_norm = max_grad_norm
        self.std_init = std_init
        self.normalize_obs = normalize_obs
        self.obs_norm_clip = obs_norm_clip
        self.use_lr_scheduler = use_lr_scheduler
        self.lr_decay = lr_decay
        self.standardize_adv = standardize_adv

# MLP with orthogonal initialization, ReLU, and LayerNorm
class MLP(nn.Module):
    def __init__(self, input_dim, hidden_sizes):
        super().__init__()
        layers = []
        in_dim = input_dim
        for h in hidden_sizes:
            linear = nn.Linear(in_dim, h)
            nn.init.orthogonal_(linear.weight, gain=nn.init.calculate_gain('relu'))
            nn.init.zeros_(linear.bias)
            layers.append(linear)
            layers.append(nn.ReLU())
            layers.append(nn.LayerNorm(h))
            in_dim = h
        self.model = nn.Sequential(*layers)

    def forward(self, x):
        return self.model(x)

# Heads for action distributions
class CategoricalHead(nn.Module):
    def __init__(self, in_dim, num_actions):
        super().__init__()
        self.logits = nn.Linear(in_dim, num_actions)
        nn.init.orthogonal_(self.logits.weight, gain=nn.init.calculate_gain('linear'))
        nn.init.zeros_(self.logits.bias)

    def forward(self, x):
        return Categorical(logits=self.logits(x))

class DiagGaussianHead(nn.Module):
    def __init__(self, in_dim, action_dim, std_init=0.1):
        super().__init__()
        self.mean = nn.Linear(in_dim, action_dim)
        nn.init.orthogonal_(self.mean.weight, gain=nn.init.calculate_gain('linear'))
        nn.init.zeros_(self.mean.bias)
        self.log_std = nn.Parameter(torch.full((action_dim,), math.log(std_init)))

    def forward(self, x):
        mean = self.mean(x)
        std = torch.exp(self.log_std)
        return Normal(mean, std)

# Value head
class ValueHead(nn.Module):
    def __init__(self, in_dim):
        super().__init__()
        self.v = nn.Linear(in_dim, 1)
        nn.init.orthogonal_(self.v.weight, gain=nn.init.calculate_gain('linear'))
        nn.init.zeros_(self.v.bias)

    def forward(self, x):
        return self.v(x).squeeze(-1)

# V-trace advantage computation
def compute_vtrace(logp_behavior, logp_target, rewards, values, gamma, rho_clip, pg_rho_clip):
    T = rewards.size(0)
    rho = torch.exp(logp_target - logp_behavior).clamp(max=rho_clip)
    c = torch.exp(logp_target - logp_behavior).clamp(max=pg_rho_clip)
    vs = torch.zeros_like(values)
    vs[-1] = values[-1]
    advantage = torch.zeros_like(values)
    for t in reversed(range(T)):
        delta = rho[t] * (rewards[t] + gamma * values[t + 1] - values[t]) if t < T - 1 else rho[t] * (rewards[t] + gamma * values[t + 1] - values[t])
        advantage[t] = delta + gamma * c[t] * advantage[t + 1] if t < T - 1 else delta
        vs[t] = values[t] + advantage[t]
    return advantage, vs

# Explained variance
def explained_variance(pred, target):
    var_target = target.var()
    if var_target == 0:
        return torch.tensor(1.0)
    return 1 - ((target - pred).pow(2).mean() / var_target)

# Main agent
class VTraceAgent:
    def __init__(self, env_name, config: Config):
        self.env = gym.make(env_name)
        obs_dim = self.env.observation_space.shape[0]
        if isinstance(self.env.action_space, gym.spaces.Discrete):
            act_dim = self.env.action_space.n
            self.action_head = CategoricalHead(config.hidden_sizes[-1], act_dim)
        else:
            act_dim = self.env.action_space.shape[0]
            self.action_head = DiagGaussianHead(config.hidden_sizes[-1], act_dim, std_init=config.std_init)
        self.feature_net = MLP(obs_dim, config.hidden_sizes)
        self.value_head = ValueHead(config.hidden_sizes[-1])
        self.optimizer = optim.Adam(
            list(self.feature_net.parameters()) +
            list(self.action_head.parameters()) +
            list(self.value_head.parameters()),
            lr=config.lr
        )
        if config.use_lr_scheduler:
            self.scheduler = optim.lr_scheduler.LinearLR(self.optimizer, start_factor=1.0, end_factor=1.0 - config.lr_decay, total_iters=100000)
        else:
            self.scheduler = None
        self.config = config
        self.total_timesteps = 0
        if config.normalize_obs:
            self.obs_mean = torch.zeros(obs_dim)
            self.obs_var = torch.ones(obs_dim)

    def normalize(self, obs):
        if self.config.normalize_obs:
            return (obs - self.obs_mean) / torch.sqrt(self.obs_var + 1e-8)
        return obs

    def update_obs_norm(self, obs):
        if self.config.normalize_obs:
            batch_mean = obs.mean(0)
            batch_var = obs.var(0)
            self.obs_mean = 0.9 * self.obs_mean + 0.1 * batch_mean
            self.obs_var = 0.9 * self.obs_var + 0.1 * batch_var

    def act(self, obs, deterministic=False):
        obs_t = torch.as_tensor(obs, dtype=torch.float32)
        self.update_obs_norm(obs_t)
        features = self.feature_net(self.normalize(obs_t))
        dist = self.action_head(features)
        if deterministic:
            action = dist.mode() if hasattr(dist, 'mode') else dist.mean
        else:
            action = dist.sample()
        logp = dist.log_prob(action).sum(-1)
        entropy = dist.entropy().sum(-1)
        value = self.value_head(features)
        return action.detach().cpu().numpy(), logp.detach(), entropy.detach(), value.detach()

    def learn(self, trajectories):
        # trajectories: list of dicts with keys: obs, action, reward, logp_behavior
        obs = torch.stack([torch.as_tensor(t['obs'], dtype=torch.float32) for t in trajectories])
        actions = torch.stack([torch.as_tensor(t['action'], dtype=torch.float32) for t in trajectories])
        rewards = torch.tensor([t['reward'] for t in trajectories], dtype=torch.float32)
        logp_behavior = torch.stack([t['logp_behavior'] for t in trajectories])

        self.update_obs_norm(obs)

        features = self.feature_net(self.normalize(obs))
        dist = self.action_head(features)
        logp_target = dist.log_prob(actions).sum(-1)
        entropy = dist.entropy().sum(-1)
        values = self.value_head(features).detach()
        values = torch.cat([values, torch.zeros(1, device=values.device)])

        advantage, vs = compute_vtrace(
            logp_behavior, logp_target, rewards, values, self.config.gamma,
            self.config.rho_clip, self.config.pg_rho_clip
        )

        if self.config.standardize_adv:
            advantage = (advantage - advantage.mean()) / (advantage.std() + 1e-8)

        policy_loss = -(logp_target * advantage).mean()
        value_loss = F.mse_loss(values[:-1], vs)
        entropy_loss = -entropy.mean()
        total_loss = policy_loss + self.config.value_coef * value_loss + self.config.entropy_coef * entropy_loss

        self.optimizer.zero_grad()
        total_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.feature_net.parameters(), self.config.max_grad_norm)
        torch.nn.utils.clip_grad_norm_(self.action_head.parameters(), self.config.max_grad_norm)
        torch.nn.utils.clip_grad_norm_(self.value_head.parameters(), self.config.max_grad_norm)
        self.optimizer.step()
        if self.scheduler:
            self.scheduler.step()

        self.total_timesteps += len(trajectories)
        metrics = {
            'total_loss': total_loss.item(),
            'policy_loss': policy_loss.item(),
            'value_loss': value_loss.item(),
            'entropy_loss': entropy_loss.item(),
            'grad_norm': torch.nn.utils.clip_grad_norm_(self.feature_net.parameters(), self.config.max_grad_norm).item(),
            'explained_variance': explained_variance(values[:-1], vs).item(),
            'learning_rate': self.optimizer.param_groups[0]['lr']
        }
        return metrics

    def save(self, path):
        torch.save({
            'feature_net': self.feature_net.state_dict(),
            'action_head': self.action_head.state_dict(),
            'value_head': self.value_head.state_dict(),
            'optimizer': self.optimizer.state_dict(),
            'total_timesteps': self.total_timesteps,
            'obs_mean': self.obs_mean,
            'obs_var': self.obs_var
        }, path)

    def load(self, path):
        checkpoint = torch.load(path)
        self.feature_net.load_state_dict(checkpoint['feature_net'])
        self.action_head.load_state_dict(checkpoint['action_head'])
        self.value_head.load_state_dict(checkpoint['value_head'])
        self.optimizer.load_state_dict(checkpoint['optimizer'])
        self.total_timesteps = checkpoint['total_timesteps']
        self.obs_mean = checkpoint['obs_mean']
        self.obs_var = checkpoint['obs_var']

# Example usage
if __name__ == "__main__":
    config = Config()
    agent = VTraceAgent("CartPole-v1", config)
    obs = agent.env.reset()
    trajectories = []
    for _ in range(2048):
        action, logp, entropy, value = agent.act(obs)
        next_obs, reward, done, _ = agent.env.step(action)
        trajectories.append({'obs': obs, 'action': action, 'reward': reward, 'logp_behavior': logp})
        obs = next_obs
        if done:
            obs = agent.env.reset()
    metrics = agent.learn(trajectories)
    print(metrics)