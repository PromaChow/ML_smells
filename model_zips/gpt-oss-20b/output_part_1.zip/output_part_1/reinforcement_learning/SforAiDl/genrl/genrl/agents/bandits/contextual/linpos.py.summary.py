import torch
import numpy as np
from scipy.stats import invgamma

class TransitionDB:
    def __init__(self, n_actions, device='cpu'):
        self.device = device
        self.contexts = [[] for _ in range(n_actions)]
        self.rewards = [[] for _ in range(n_actions)]

    def add(self, action, context, reward):
        self.contexts[action].append(context.cpu() if isinstance(context, torch.Tensor) else context)
        self.rewards[action].append(reward)

    def get_action_data(self, action):
        if not self.contexts[action]:
            return None, None
        X = torch.stack([torch.tensor(c, device=self.device) for c in self.contexts[action]])
        y = torch.tensor(self.rewards[action], device=self.device, dtype=torch.float32)
        return X, y

class BayesianLinearBandit:
    def __init__(self, data_bandit, init_pulls, lambda_prior, a0, b0, device='cpu'):
        self.data_bandit = data_bandit  # unused in this implementation
        self.device = device
        self.init_pulls = init_pulls
        self.lambda_prior = lambda_prior
        self.a0 = a0
        self.b0 = b0

        # Assume data_bandit provides number of actions and context dimension
        self.n_actions = data_bandit.n_actions
        self.context_dim = data_bandit.context_dim

        # Prior parameters
        self.mu = torch.zeros((self.n_actions, self.context_dim + 1), device=self.device)
        self.cov = torch.eye(self.context_dim + 1, device=self.device).unsqueeze(0).repeat(self.n_actions, 1, 1)
        self.inv_cov = torch.eye(self.context_dim + 1, device=self.device).unsqueeze(0).repeat(self.n_actions, 1, 1)
        self.a = torch.full((self.n_actions,), self.a0, device=self.device)
        self.b = torch.full((self.n_actions,), self.b0, device=self.device)

        self.db = TransitionDB(self.n_actions, device=self.device)
        self.time_step = 0

    def select_action(self, context):
        context = torch.tensor(context, dtype=torch.float32, device=self.device)
        if self.time_step < self.n_actions * self.init_pulls:
            action = self.time_step % self.n_actions
        else:
            context_aug = torch.cat([context, torch.tensor([1.0], device=self.device)])
            preds = []
            for i in range(self.n_actions):
                sigma2 = invgamma.rvs(self.a[i].item()) * self.b[i].item()
                try:
                    mvn = torch.distributions.MultivariateNormal(
                        self.mu[i],
                        covariance_matrix=self.cov[i] * sigma2
                    )
                    beta = mvn.sample()
                except Exception:
                    beta = torch.distributions.MultivariateNormal(
                        torch.zeros_like(self.mu[i]),
                        covariance_matrix=torch.eye(self.context_dim + 1, device=self.device)
                    ).sample()
                preds.append(beta.dot(context_aug))
            action = int(torch.argmax(torch.tensor(preds, device=self.device)).item())
        return action

    def update(self, action, context, reward):
        self.db.add(action, context, reward)
        self.time_step += 1
        for i in range(self.n_actions):
            X, y = self.db.get_action_data(i)
            if X is None:
                continue
            # Augment with bias term
            ones = torch.ones((X.size(0), 1), device=self.device)
            X_aug = torch.cat([X, ones], dim=1)
            # Posterior covariance and mean
            inv_cov_i = X_aug.t() @ X_aug + self.lambda_prior * torch.eye(self.context_dim + 1, device=self.device)
            cov_i = torch.inverse(inv_cov_i)
            mu_i = cov_i @ X_aug.t() @ y
            # Update inverse gamma parameters
            t_i = X_aug.size(0)
            a_i = self.a0 + t_i / 2.0
            residual = y.t() @ y - mu_i.t() @ cov_i @ mu_i
            b_i = self.b0 + residual / 2.0
            # Store updated parameters
            self.mu[i] = mu_i
            self.cov[i] = cov_i
            self.inv_cov[i] = inv_cov_i
            self.a[i] = a_i
            self.b[i] = b_i
        return

# Mockup for DataBasedBandit to demonstrate usage
class DataBasedBandit:
    def __init__(self, n_actions, context_dim):
        self.n_actions = n_actions
        self.context_dim = context_dim

# Example usage:
# bandit = BayesianLinearBandit(DataBasedBandit(5, 10), init_pulls=5, lambda_prior=1.0, a0=1.0, b0=1.0, device='cpu')
# context = np.random.randn(10)
# action = bandit.select_action(context)
# reward = np.random.randn()  # placeholder for actual reward
# bandit.update(action, context, reward)