import pandas as pd

df = pd.read_csv('SalaryGender.csv')
phd_df = df[df['PhD'] == 1]
count = len(phd_df)
print(f"Total count of individuals with a PhD degree: {count}")