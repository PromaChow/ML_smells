import pandas as pd
import matplotlib.pyplot as plt

# Load the dataset
df = pd.read_csv("BigMartSalesData.csv")

# Filter for the year 2011 and select relevant columns
filtered = df[df["Year"] == 2011][["Month", "Amount"]]

# Group by month and calculate total sales
monthly_sales = filtered.groupby("Month")["Amount"].sum()

# Prepare data for plotting
months = monthly_sales.index
total_sales = monthly_sales.values

# Create a line plot
plt.figure(figsize=(10, 6))
plt.plot(months, total_sales, marker='o', linestyle='-')
plt.xlabel("Month")
plt.ylabel("Total Sales")
plt.title("Month vs sales")
plt.grid(True)

# Display the plot
plt.show()

# Should we consider a bar chart instead for clearer monthly comparison?