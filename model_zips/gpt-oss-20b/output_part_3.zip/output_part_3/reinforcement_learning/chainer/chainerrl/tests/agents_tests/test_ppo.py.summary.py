import os
import tempfile
import pytest
import numpy as np
import torch
import chainerrl
from chainerrl.envs import abc
from chainerrl.algos import ppo
from chainerrl.nn import MLP, GaussianPolicy, SoftmaxPolicy
from chainerrl.optimizers import Adam
from chainerrl.algos.ppo import (
    train_agent_with_evaluation,
    run_evaluation_episodes,
)


def make_random_episodes(num_episodes, max_len, state_shape, action_shape,
                         continuous_action=False, seed=None):
    rng = np.random.default_rng(seed)
    episodes = []
    for _ in range(num_episodes):
        episode = []
        length = rng.integers(1, max_len + 1)
        for t in range(length):
            obs = rng.standard_normal(state_shape).astype(np.float32)
            if continuous_action:
                act = rng.standard_normal(action_shape).astype(np.float32)
            else:
                act = rng.integers(0, action_shape[0], size=()).item()
            rew = rng.standard_normal().astype(np.float32)
            nonterm = t < length - 1
            episode.append((obs, act, rew, nonterm))
        episodes.append(episode)
    return episodes


def split_sequences_fixed(episodes, n_items):
    """Yield sub-sequences of length n_items from episodes."""
    for ep in episodes:
        for i in range(0, len(ep), n_items):
            yield ep[i:i + n_items]


def truncate_sequences(episodes, max_len):
    """Truncate episodes to max_len."""
    truncated = []
    total = 0
    for ep in episodes:
        if len(ep) > max_len:
            ep = ep[:max_len]
        truncated.append(ep)
        total += len(ep)
    return truncated, total


@pytest.fixture
def random_episodes():
    return make_random_episodes(
        num_episodes=5,
        max_len=20,
        state_shape=(4,),
        action_shape=(3,),
        continuous_action=False,
        seed=0,
    )


def test_yield_subset_of_sequences_with_fixed_number_of_items(random_episodes):
    n_items = 5
    sub_sequences = list(split_sequences_fixed(random_episodes, n_items))
    lengths = [len(sub) for sub in sub_sequences]
    assert all(l <= n_items for l in lengths)
    total_items = sum(lengths)
    assert total_items == sum(len(ep) for ep in random_episodes)


def test_limit_sequence_length(random_episodes):
    max_len = 10
    truncated, total = truncate_sequences(random_episodes, max_len)
    assert all(len(ep) <= max_len for ep in truncated)
    original_total = sum(len(ep) for ep in random_episodes)
    assert total == original_total
    for ep in truncated:
        assert len(ep) <= max_len


def _build_model(
    state_shape,
    action_shape,
    continuous_action,
    recurrent=False,
    hidden_size=32,
    num_layers=2,
):
    if continuous_action:
        policy_net = MLP(
            state_shape,
            hidden_size,
            hidden_size,
            num_layers,
            output_size=action_shape[0],
            activation=torch.nn.ReLU(),
        )
        policy = GaussianPolicy(
            policy_net,
            action_shape[0],
            action_std=0.1,
            deterministic=True,
        )
    else:
        policy_net = MLP(
            state_shape,
            hidden_size,
            hidden_size,
            num_layers,
            output_size=action_shape[0],
            activation=torch.nn.ReLU(),
        )
        policy = SoftmaxPolicy(policy_net)

    value_net = MLP(
        state_shape,
        hidden_size,
        hidden_size,
        num_layers,
        output_size=1,
        activation=torch.nn.ReLU(),
    )
    if recurrent:
        from chainerrl import recurrent
        policy = recurrent.StatelessRecurrentBranched(policy, hidden_size)
        value_net = recurrent.StatelessRecurrentBranched(value_net, hidden_size)

    model = chainerrl.models.SurrogateModel(policy, value_net)
    return model


def _evaluate_agent(env, agent, num_episodes=3):
    return run_evaluation_episodes(env, agent, num_episodes)


@pytest.mark.parametrize(
    "continuous_action,recurrent",
    [
        (False, False),
        (False, True),
        (True, False),
        (True, True),
    ],
)
def test_training_and_evaluation(continuous_action, recurrent):
    env = abc.AbcEnv(
        observation_space_shape=(4,),
        action_space_shape=(3,),
        continuous_action=continuous_action,
        episodic=True,
    )
    model = _build_model(
        state_shape=(4,),
        action_shape=(3,),
        continuous_action=continuous_action,
        recurrent=recurrent,
    )
    optimizers = [Adam(model.parameters(), lr=1e-3)]
    agent = ppo.PPO(
        model,
        optimizers=optimizers,
        clip_eps=0.2,
        vf_coef=0.5,
        entropy_coef=0.01,
        max_grad_norm=0.5,
        gamma=0.99,
        lamda=0.95,
    )
    # Train for a very small number of steps to keep test fast
    train_agent_with_evaluation(
        env,
        agent,
        max_steps=200,
        eval_interval=50,
        target_return=0.0,
        eval_n=1,
        verbose=False,
    )
    # Evaluate
    total_return = _evaluate_agent(env, agent, num_episodes=2)
    assert total_return >= 0.0

    # Test saving and loading
    with tempfile.TemporaryDirectory() as tmpdir:
        ckpt = os.path.join(tmpdir, "agent.ckpt")
        agent.save(ckpt)
        loaded_agent = ppo.PPO.load(ckpt, env)
        loaded_return = _evaluate_agent(env, loaded_agent, num_episodes=2)
        assert loaded_return == pytest.approx(total_return, rel=0.01)


def test_log_prob_equivalence():
    env = abc.AbcEnv(
        observation_space_shape=(4,),
        action_space_shape=(3,),
        continuous_action=False,
        episodic=True,
    )
    non_recurrent = _build_model(
        state_shape=(4,),
        action_shape=(3,),
        continuous_action=False,
        recurrent=False,
    )
    recurrent = _build_model(
        state_shape=(4,),
        action_shape=(3,),
        continuous_action=False,
        recurrent=True,
    )
    obs = torch.randn(5, 4)
    act = torch.randint(0, 3, (5,)).long()

    with torch.no_grad():
        # Non-recurrent
        logp_nr = non_recurrent.policy(obs, act)
        v_nr = non_recurrent.value(obs).squeeze(-1)

        # Recurrent
        h = recurrent.policy.init_hidden()
        logp_r, h = recurrent.policy(obs, act, h)
        v_r = recurrent.value(obs, h).squeeze(-1)

    assert torch.allclose(logp_nr, logp_r, atol=1e-5)
    assert torch.allclose(v_nr, v_r, atol=1e-5)
    # Advantages will be identical when computed from the same returns
    rewards = torch.randn(5)
    masks = torch.ones(5)
    returns = chainerrl.utils.compute_gae(
        rewards, masks, v_nr, 0.99, 0.95, None, None
    )
    adv_nr = returns - v_nr
    adv_r = returns - v_r
    assert torch.allclose(adv_nr, adv_r, atol=1e-5)