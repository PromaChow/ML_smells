import torch
import torch.nn.functional as F
from utils import sharpen, temperature_softmax

class ConsistencyRegularization:
    def __init__(self, consistency: str, threshold=None, sharpen=None, temp_softmax=None):
        self.consistency = consistency
        self.threshold = threshold
        self.sharpen = sharpen
        self.temp_softmax = temp_softmax

    def gen_mask(self, tea_logits: torch.Tensor) -> torch.Tensor:
        probs = F.softmax(tea_logits, dim=1)
        if self.threshold is None or self.threshold == 0:
            max_vals = probs.max(dim=1, keepdim=True)[0]
            mask = torch.ones_like(max_vals)
        else:
            max_vals = probs.max(dim=1, keepdim=True)[0]
            mask = (max_vals > self.threshold).float()
        return mask.squeeze(1)

    def adjust_target(self, tea_logits: torch.Tensor) -> torch.Tensor:
        if self.sharpen is not None:
            probs = F.softmax(tea_logits, dim=1)
            adjusted = sharpen(probs, self.sharpen)
        elif self.temp_softmax is not None:
            adjusted = temperature_softmax(tea_logits, self.temp_softmax)
        else:
            adjusted = F.softmax(tea_logits, dim=1)
        return adjusted

    def __call__(self, stu_preds: torch.Tensor, tea_logits: torch.Tensor):
        mask = self.gen_mask(tea_logits)
        adjusted_targets = self.adjust_target(tea_logits)
        return stu_preds, adjusted_targets, mask