import math
import torch
from torch.optim.lr_scheduler import LambdaLR, _LRScheduler


def exp_warmup(base_value: float, max_warmup_iter: int, cur_step: int) -> float:
    """
    Exponential warmup schedule.
    """
    if cur_step >= max_warmup_iter or max_warmup_iter <= 0:
        return float(base_value)
    progress = cur_step / max_warmup_iter
    return float(base_value * math.exp(-5 * (1 - progress) ** 2))


def linear_warmup(base_value: float, max_warmup_iter: int, cur_step: int) -> float:
    """
    Linear warmup schedule.
    """
    if cur_step >= max_warmup_iter or max_warmup_iter <= 0:
        return float(base_value)
    progress = cur_step / max_warmup_iter
    return float(base_value * progress)


def cosine_decay(base_lr: float, max_iteration: int, cur_step: int) -> float:
    """
    Cosine decay schedule.
    """
    if max_iteration <= 0:
        return float(base_lr)
    return float(base_lr * math.cos((7 * math.pi * cur_step) / (16 * max_iteration)))


class CosineAnnealingLR(_LRScheduler):
    """
    Cosine annealing scheduler using LambdaLR.
    """

    def __init__(self, optimizer, max_iteration: int, last_epoch: int = -1):
        self.max_iteration = max_iteration
        base_lrs = [group["lr"] for group in optimizer.param_groups]

        def lr_lambda(step):
            # step starts from 0
            return cosine_decay(
                base_lr=base_lrs[0],
                max_iteration=self.max_iteration,
                cur_step=step,
            ) / base_lrs[0]

        super().__init__(optimizer, lr_lambda=lr_lambda, last_epoch=last_epoch)

    def get_lr(self):
        return super().get_lr()
```