import numpy as np
import chainer
from chainer.datasets import TupleDataset
from chainer.iterators import SerialIterator
from chainer.dataset import concat_examples
from chainer.backends.cuda import to_cpu, to_gpu

def pred(x: np.ndarray, batchsize: int, model):
    """
    Perform deterministic inference on the input array x using the provided model.
    """
    # 1. Data conversion
    x = np.asarray(x, dtype=np.float32)
    tmp = np.ones_like(x, dtype=np.float32)

    # 2. Dataset and iterator setup
    dataset = TupleDataset(x, tmp)
    iterator = SerialIterator(dataset, batchsize, shuffle=False, repeat=False)

    # 3. Accumulator for predictions
    h = np.array([], dtype=np.float32)

    # 4. Non-training mode
    chainer.config.train = False
    with chainer.no_backprop_mode():
        # 5. Batch processing
        for batch in iterator:
            # Convert batch to GPU tensors
            inp_gpu = to_gpu(batch[0])
            # Forward pass
            y = model.predictor(inp_gpu)
            # Move output back to CPU
            y_cpu = to_cpu(y.array)
            # Accumulate results
            h = np.r_[h, y_cpu]

    # 6. Return accumulated predictions
    return h[:]  # return a copy to avoid accidental modifications
