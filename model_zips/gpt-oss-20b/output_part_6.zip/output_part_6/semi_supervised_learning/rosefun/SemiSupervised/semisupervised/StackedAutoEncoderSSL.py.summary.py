import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score
import os

class SAE(nn.Module):
    def __init__(self, input_dim, hidden_dims, num_classes):
        super(SAE, self).__init__()
        # Encoder
        encoder_layers = []
        prev_dim = input_dim
        for h in hidden_dims:
            encoder_layers.append(nn.Linear(prev_dim, h))
            encoder_layers.append(nn.ReLU())
            prev_dim = h
        self.encoder = nn.Sequential(*encoder_layers)

        # Decoder (mirror of encoder)
        decoder_layers = []
        hidden_dims_rev = hidden_dims[::-1]
        for h in hidden_dims_rev:
            decoder_layers.append(nn.Linear(prev_dim, h))
            decoder_layers.append(nn.ReLU())
            prev_dim = h
        decoder_layers.append(nn.Linear(prev_dim, input_dim))
        self.decoder = nn.Sequential(*decoder_layers)

        # Classifier
        self.classifier = nn.Linear(hidden_dims[-1], num_classes)

    def forward(self, x):
        encoded = self.encoder(x)
        decoded = self.decoder(encoded)
        logits = self.classifier(encoded)
        return encoded, decoded, logits

class StackedAutoEncoderClassifier:
    def __init__(self,
                 input_dim,
                 hidden_dims=[128, 64],
                 num_classes=10,
                 pretrain_epochs=20,
                 finetune_epochs=20,
                 pretrain_lr=1e-3,
                 finetune_lr=1e-3,
                 weight_decay=0,
                 batch_size=64,
                 patience=5,
                 device=None):
        self.input_dim = input_dim
        self.hidden_dims = hidden_dims
        self.num_classes = num_classes
        self.pretrain_epochs = pretrain_epochs
        self.finetune_epochs = finetune_epochs
        self.pretrain_lr = pretrain_lr
        self.finetune_lr = finetune_lr
        self.weight_decay = weight_decay
        self.batch_size = batch_size
        self.patience = patience
        self.device = device or ('cuda' if torch.cuda.is_available() else 'cpu')
        self.model = SAE(input_dim, hidden_dims, num_classes).to(self.device)
        self.pretrain_optimizer = optim.Adam(self.model.parameters(),
                                             lr=self.pretrain_lr,
                                             weight_decay=self.weight_decay)
        self.finetune_optimizer = optim.Adam(self.model.parameters(),
                                             lr=self.finetune_lr,
                                             weight_decay=self.weight_decay)

    def _convert_to_tensor(self, X, y=None):
        if isinstance(X, pd.DataFrame):
            X = X.values
        if isinstance(X, np.ndarray):
            X = torch.from_numpy(X.astype(np.float32))
        else:
            X = torch.tensor(X, dtype=torch.float32)
        if y is not None:
            if isinstance(y, pd.Series):
                y = y.values
            y = torch.from_numpy(np.array(y, dtype=np.int64))
        return X, y

    def create_dataloader(self, X, y=None, shuffle=True):
        X_tensor, y_tensor = self._convert_to_tensor(X, y)
        dataset = TensorDataset(X_tensor, y_tensor) if y_tensor is not None else TensorDataset(X_tensor)
        loader = DataLoader(dataset, batch_size=self.batch_size, shuffle=shuffle)
        return loader

    def _pretrain(self, dataloader, save_path=None):
        criterion = nn.MSELoss()
        best_loss = float('inf')
        patience_counter = 0
        for epoch in range(self.pretrain_epochs):
            epoch_loss = 0.0
            self.model.train()
            for batch in dataloader:
                inputs = batch[0].to(self.device)
                _, decoded, _ = self.model(inputs)
                loss = criterion(decoded, inputs)
                self.pretrain_optimizer.zero_grad()
                loss.backward()
                self.pretrain_optimizer.step()
                epoch_loss += loss.item() * inputs.size(0)
            epoch_loss /= len(dataloader.dataset)
            if epoch_loss < best_loss:
                best_loss = epoch_loss
                patience_counter = 0
            else:
                patience_counter += 1
            if patience_counter >= self.patience:
                break
        if save_path is not None:
            os.makedirs(os.path.dirname(save_path), exist_ok=True)
            torch.save({'model_state_dict': self.model.state_dict(),
                        'optimizer_state_dict': self.pretrain_optimizer.state_dict()},
                       save_path)

    def _finetune(self, train_loader, val_loader=None):
        criterion = nn.CrossEntropyLoss()
        best_val_loss = float('inf') if val_loader else None
        patience_counter = 0
        for epoch in range(self.finetune_epochs):
            self.model.train()
            epoch_loss = 0.0
            for batch in train_loader:
                inputs, targets = batch[0].to(self.device), batch[1].to(self.device)
                _, _, logits = self.model(inputs)
                loss = criterion(logits, targets)
                self.finetune_optimizer.zero_grad()
                loss.backward()
                self.finetune_optimizer.step()
                epoch_loss += loss.item() * inputs.size(0)
            epoch_loss /= len(train_loader.dataset)
            if val_loader:
                val_loss = self._evaluate(val_loader, criterion)
                if val_loss < best_val_loss:
                    best_val_loss = val_loss
                    patience_counter = 0
                else:
                    patience_counter += 1
                if patience_counter >= self.patience:
                    break
            else:
                if epoch_loss < best_val_loss:
                    best_val_loss = epoch_loss
                    patience_counter = 0
                else:
                    patience_counter += 1
                if patience_counter >= self.patience:
                    break

    def _evaluate(self, loader, criterion):
        self.model.eval()
        loss = 0.0
        with torch.no_grad():
            for batch in loader:
                inputs, targets = batch[0].to(self.device), batch[1].to(self.device)
                _, _, logits = self.model(inputs)
                loss += criterion(logits, targets).item() * inputs.size(0)
        return loss / len(loader.dataset)

    def fit(self,
            X,
            y=None,
            val_X=None,
            val_y=None,
            save_pretrain_path=None):
        # Pretrain with all data (unlabeled or labeled)
        pretrain_loader = self.create_dataloader(X, shuffle=True)
        self._pretrain(pretrain_loader, save_path=save_pretrain_path)

        if y is not None:
            # Finetune with labeled data
            train_loader = self.create_dataloader(X, y, shuffle=True)
            val_loader = None
            if val_X is not None and val_y is not None:
                val_loader = self.create_dataloader(val_X, val_y, shuffle=False)
            self._finetune(train_loader, val_loader)

    def predict(self, X):
        self.model.eval()
        X_tensor, _ = self._convert_to_tensor(X)
        dataloader = DataLoader(TensorDataset(X_tensor), batch_size=self.batch_size, shuffle=False)
        preds = []
        with torch.no_grad():
            for batch in dataloader:
                inputs = batch[0].to(self.device)
                _, _, logits = self.model(inputs)
                preds.append(torch.argmax(logits, dim=1).cpu())
        return torch.cat(preds).numpy()

    def predict_proba(self, X):
        self.model.eval()
        X_tensor, _ = self._convert_to_tensor(X)
        dataloader = DataLoader(TensorDataset(X_tensor), batch_size=self.batch_size, shuffle=False)
        probs = []
        with torch.no_grad():
            for batch in dataloader:
                inputs = batch[0].to(self.device)
                _, _, logits = self.model(inputs)
                probs.append(nn.functional.softmax(logits, dim=1).cpu())
        return torch.cat(probs).numpy()

    def score(self, X, y_true):
        y_pred = self.predict(X)
        return accuracy_score(y_true, y_pred)
