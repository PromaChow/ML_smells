import math
import random
import time

import numpy as np
import pyglet
from pyglet import shapes


class Viewer:
    """Viewer using pyglet to render the robotic arm environment."""

    def __init__(self, window_size=400, arm_length=100):
        self.window_size = window_size
        self.arm_length = arm_length

        self.window = pyglet.window.Window(width=window_size, height=window_size, caption="Arm Environment")
        self.window.set_location(100, 100)

        # Goal square (centered at (gx, gy), side 40)
        self.goal_rect = shapes.Rectangle(0, 0, 40, 40, color=(0, 255, 0))

        # Arm segments as lines
        self.arm1_line = shapes.Line(0, 0, 0, 0, width=4, color=(255, 0, 0))
        self.arm2_line = shapes.Line(0, 0, 0, 0, width=4, color=(0, 0, 255))

        @self.window.event
        def on_draw():
            self.window.clear()
            self.goal_rect.draw()
            self.arm1_line.draw()
            self.arm2_line.draw()

        @self.window.event
        def on_mouse_motion(self, x, y, dx, dy):
            # Update goal center on mouse movement
            self.goal_rect.x = x - self.goal_rect.width // 2
            self.goal_rect.y = y - self.goal_rect.height // 2

    def update(self, state, goal_center):
        """Update the visual elements based on the current state and goal position."""
        theta1 = state[7] * 2 * math.pi
        theta2 = state[8] * 2 * math.pi

        x1 = self.arm_length * math.cos(theta1)
        y1 = self.arm_length * math.sin(theta1)
        xf = x1 + self.arm_length * math.cos(theta2)
        yf = y1 + self.arm_length * math.sin(theta2)

        # Arm 1 line
        self.arm1_line.set_position(0, 0, x1, y1)
        # Arm 2 line
        self.arm2_line.set_position(x1, y1, xf, yf)

        # Goal rectangle
        gx, gy = goal_center
        self.goal_rect.x = gx - 20
        self.goal_rect.y = gy - 20

    def render(self):
        """Render the current frame."""
        pyglet.clock.tick()
        self.window.flip()


class ArmEnv:
    """Robotic arm environment for reinforcement learning."""

    def __init__(self, dt=0.1, arm_length=100, goal_side=40, goal_center=(100, 100)):
        self.dt = dt
        self.arm_length = arm_length
        self.goal_side = goal_side
        self.goal_center = np.array(goal_center, dtype=np.float32)

        self.viewer = None
        self.steps_on_goal = 0

        # Initialize angles and state
        self.reset()

    def reset(self):
        """Reset the environment to a random state."""
        self.goal_center = np.array(
            [random.uniform(0, 400), random.uniform(0, 400)], dtype=np.float32
        )
        self.theta1 = random.uniform(0, 2 * math.pi)
        self.theta2 = random.uniform(0, 2 * math.pi)
        self.steps_on_goal = 0
        state = self._compute_state()
        return state

    def step(self, action):
        """Apply action, update the environment, and return the new state, reward, done flag, and info."""
        action = np.clip(action, -1, 1)

        # Update angles
        self.theta1 = (self.theta1 + action[0] * self.dt) % (2 * math.pi)
        self.theta2 = (self.theta2 + action[1] * self.dt) % (2 * math.pi)

        state = self._compute_state()

        # Reward: negative distance to goal center
        _, _, _, _, _, dist_to_goal, flag, _, _ = state
        reward = -dist_to_goal * 400  # scale back to actual distance

        if flag:
            self.steps_on_goal += 1
            if self.steps_on_goal >= 50:
                reward += 1
                done = True
            else:
                done = False
        else:
            self.steps_on_goal = 0
            done = False

        info = {}
        return state, reward, done, info

    def _compute_state(self):
        """Compute the 9-dimensional state vector."""
        # Positions
        x1 = self.arm_length * math.cos(self.theta1)
        y1 = self.arm_length * math.sin(self.theta1)
        xf = x1 + self.arm_length * math.cos(self.theta2)
        yf = y1 + self.arm_length * math.sin(self.theta2)

        # Distances to goal center
        dx1 = x1 - self.goal_center[0]
        dy1 = y1 - self.goal_center[1]
        d1 = math.hypot(dx1, dy1)

        dxf = xf - self.goal_center[0]
        dyf = yf - self.goal_center[1]
        df = math.hypot(dxf, dyf)

        # Normalized distances
        d1_norm = d1 / 400
        df_norm = df / 400

        # Flag if finger inside goal square
        flag = int(
            abs(xf - self.goal_center[0]) <= self.goal_side / 2
            and abs(yf - self.goal_center[1]) <= self.goal_side / 2
        )

        # Normalized positions
        x1_norm = x1 / 400
        y1_norm = y1 / 400
        xf_norm = xf / 400
        yf_norm = yf / 400

        # Normalized angles
        theta1_norm = self.theta1 / (2 * math.pi)
        theta2_norm = self.theta2 / (2 * math.pi)

        state = np.array(
            [
                x1_norm,
                y1_norm,
                xf_norm,
                yf_norm,
                d1_norm,
                df_norm,
                flag,
                theta1_norm,
                theta2_norm,
            ],
            dtype=np.float32,
        )
        return state

    def render(self):
        """Render the environment using the viewer."""
        if self.viewer is None:
            self.viewer = Viewer(window_size=400, arm_length=self.arm_length)
        state = self._compute_state()
        self.viewer.update(state, self.goal_center)
        self.viewer.render()

    def sample_action(self):
        """Sample a random action within bounds [-0.5, 0.5] for each arm angle."""
        return np.clip(np.random.uniform(-0.5, 0.5, size=2), -1, 1)


if __name__ == "__main__":
    env = ArmEnv()
    state = env.reset()
    done = False
    while not done:
        action = env.sample_action()
        state, reward, done, _ = env.step(action)
        env.render()
        time.sleep(0.1)