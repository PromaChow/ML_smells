import os
import numpy as np
import torch
from torch.utils.data import Dataset
from torchvision.datasets.utils import download_url
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from scipy.io import loadmat


class ODDSDataset(Dataset):
    """
    PyTorch Dataset for Outlier Detection DataSets (ODDS) repository.
    """

    BASE_URL = "https://github.com/odds-dataset/odds-dataset/raw/master/datasets/"

    def __init__(self, root, dataset_name, train=True, download=False):
        self.root = os.path.expanduser(root)
        self.dataset_name = dataset_name
        self.train = train

        os.makedirs(self.root, exist_ok=True)
        self.file_path = os.path.join(self.root, f"{self.dataset_name}.mat")

        if download and not os.path.isfile(self.file_path):
            url = f"{self.BASE_URL}{self.dataset_name}.mat"
            download_url(url, self.root, filename=f"{self.dataset_name}.mat")

        # Load data
        mat = loadmat(self.file_path)
        X = mat["X"]
        y = mat["y"].flatten()

        # Separate normal and outlier samples
        normal_idx = y == 0
        outlier_idx = y == 1

        X_normal = X[normal_idx]
        y_normal = y[normal_idx]
        X_outlier = X[outlier_idx]
        y_outlier = y[outlier_idx]

        # Train/test split for each group (60-40)
        X_norm_train, X_norm_test, y_norm_train, y_norm_test = train_test_split(
            X_normal, y_normal, test_size=0.4, random_state=42, shuffle=True
        )
        X_out_train, X_out_test, y_out_train, y_out_test = train_test_split(
            X_outlier, y_outlier, test_size=0.4, random_state=42, shuffle=True
        )

        # Combine normal and outlier splits
        X_train = np.vstack((X_norm_train, X_out_train))
        y_train = np.concatenate((y_norm_train, y_out_train))
        X_test = np.vstack((X_norm_test, X_out_test))
        y_test = np.concatenate((y_norm_test, y_out_test))

        # Standardization on training data
        scaler_std = StandardScaler()
        X_train_std = scaler_std.fit_transform(X_train)
        X_test_std = scaler_std.transform(X_test)

        # MinMax scaling to [0, 1]
        scaler_mm = MinMaxScaler()
        X_train_scaled = scaler_mm.fit_transform(X_train_std)
        X_test_scaled = scaler_mm.transform(X_test_std)

        # Convert to tensors
        self.features = torch.tensor(
            X_train_scaled if self.train else X_test_scaled,
            dtype=torch.float32,
        )
        self.targets = torch.tensor(
            y_train if self.train else y_test,
            dtype=torch.int64,
        )
        self.semi_targets = torch.zeros_like(self.targets, dtype=torch.int64)

    def __len__(self):
        return len(self.features)

    def __getitem__(self, idx):
        feature = self.features[idx]
        target = self.targets[idx]
        semi_target = self.semi_targets[idx]
        return feature, target, semi_target, idx
