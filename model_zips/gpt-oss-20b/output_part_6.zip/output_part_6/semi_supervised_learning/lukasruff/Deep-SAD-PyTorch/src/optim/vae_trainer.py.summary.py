import time
from typing import Any, Tuple

import torch
import torch.nn.functional as F
from torch.optim.lr_scheduler import MultiStepLR
from torch.utils.data import DataLoader
from sklearn.metrics import roc_auc_score


class VAETrainer:
    def __init__(
        self,
        model: torch.nn.Module,
        dataset: Any,
        device: str = "cuda",
        optimizer_type: str = "adam",
        lr: float = 1e-3,
        weight_decay: float = 0.0,
        epochs: int = 10,
        batch_size: int = 128,
        workers: int = 4,
        milestones: Tuple[int, ...] = (5,),
        gamma: float = 0.1,
    ):
        self.model = model
        self.dataset = dataset
        self.device = torch.device(device if torch.cuda.is_available() else "cpu")
        self.optimizer_type = optimizer_type
        self.lr = lr
        self.weight_decay = weight_decay
        self.epochs = epochs
        self.batch_size = batch_size
        self.workers = workers
        self.milestones = milestones
        self.gamma = gamma

        self.train_time = 0.0
        self.test_time = 0.0
        self.test_auc = 0.0

    def _get_loader(self, split: str) -> DataLoader:
        return self.dataset.loaders(split=split, batch_size=self.batch_size, workers=self.workers)

    def train(self) -> torch.nn.Module:
        train_loader = self._get_loader("train")
        self.model.to(self.device)

        optimizer = torch.optim.Adam(self.model.parameters(), lr=self.lr, weight_decay=self.weight_decay)
        scheduler = MultiStepLR(optimizer, milestones=self.milestones, gamma=self.gamma)

        total_start = time.time()
        for epoch in range(1, self.epochs + 1):
            epoch_start = time.time()
            epoch_loss = 0.0
            self.model.train()
            for batch in train_loader:
                inputs, _ = batch
                inputs = inputs.view(inputs.size(0), -1).to(self.device)

                rec = self.model(inputs)

                # Likelihood
                likelihood = -F.binary_cross_entropy(rec, inputs, reduction="sum")
                # KL divergence (assumed to be provided by the model)
                kl_div = self.model.kl_divergence().sum()
                elbo = likelihood - kl_div
                loss = -elbo.mean()

                optimizer.zero_grad()
                loss.backward()
                optimizer.step()

                epoch_loss += loss.item()

            scheduler.step()
            epoch_time = time.time() - epoch_start
            avg_epoch_loss = epoch_loss / len(train_loader)
            print(
                f"Epoch {epoch}/{self.epochs} - "
                f"Loss: {avg_epoch_loss:.4f} - "
                f"Time: {epoch_time:.2f}s"
            )
        self.train_time = time.time() - total_start
        print(f"Training completed in {self.train_time:.2f}s")
        return self.model

    def test(self) -> torch.nn.Module:
        test_loader = self._get_loader("test")
        self.model.to(self.device)
        self.model.eval()

        all_scores = []
        all_labels = []
        total_loss = 0.0

        start_time = time.time()
        with torch.no_grad():
            for batch in test_loader:
                inputs, labels = batch
                inputs = inputs.view(inputs.size(0), -1).to(self.device)
                labels = labels.cpu()

                rec = self.model(inputs)

                # Likelihood per sample
                per_sample_likelihood = -F.binary_cross_entropy(rec, inputs, reduction="none").mean(dim=1)
                anomaly_score = -per_sample_likelihood.cpu()
                all_scores.append(anomaly_score)
                all_labels.append(labels)

                # KL divergence and loss
                kl_div = self.model.kl_divergence().sum()
                likelihood = -F.binary_cross_entropy(rec, inputs, reduction="sum")
                elbo = likelihood - kl_div
                loss = -elbo.mean()
                total_loss += loss.item()

        test_time = time.time() - start_time
        self.test_time = test_time

        scores = torch.cat(all_scores)
        labels = torch.cat(all_labels)

        self.test_auc = roc_auc_score(labels.numpy(), scores.numpy())
        avg_test_loss = total_loss / len(test_loader)

        print(
            f"Test completed in {self.test_time:.2f}s - "
            f"Loss: {avg_test_loss:.4f} - "
            f"AUC: {self.test_auc:.4f}"
        )
        return self.model
