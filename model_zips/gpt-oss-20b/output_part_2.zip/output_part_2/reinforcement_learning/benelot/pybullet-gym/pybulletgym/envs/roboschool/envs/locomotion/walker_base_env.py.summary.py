import pybullet as p
import pybullet_data
import time
import numpy as np

# Minimal base classes to make the code executable

class BaseBulletEnv:
    def __init__(self, robot, render=False):
        self.robot = robot
        self.render = render
        self.physics_client = p.connect(p.GUI if render else p.DIRECT)
        p.setAdditionalSearchPath(pybullet_data.getDataPath())
        p.setGravity(0, 0, -9.81)
        self.time_step = 1.0 / 240.0
        p.setTimeStep(self.time_step)
        self.state_id = -1
        self.multiplayer = False

    def _reset(self):
        p.resetSimulation()
        p.setGravity(0, 0, -9.81)
        p.setTimeStep(self.time_step)
        self._load_robot()

    def _load_robot(self):
        self.robot_id = p.loadURDF(self.robot, [0, 0, 0.5], useFixedBase=False)

    def step_simulation(self):
        p.stepSimulation()
        if self.render:
            time.sleep(self.time_step)

class StadiumScene:
    def __init__(self, render=False):
        self.render = render
        self.physics_client = p.connect(p.GUI if render else p.DIRECT)
        p.setAdditionalSearchPath(pybullet_data.getDataPath())
        p.setGravity(0, 0, -9.81)
        self.time_step = 1.0 / 240.0
        p.setTimeStep(self.time_step)
        self.ground = p.loadURDF("plane.urdf")
        self.robot_ids = []

    def add_robot(self, robot_urdf, position, orientation):
        robot_id = p.loadURDF(robot_urdf, position, orientation, useFixedBase=False)
        self.robot_ids.append(robot_id)
        return robot_id

    def step(self):
        p.stepSimulation()
        if self.render:
            time.sleep(self.time_step)

class WalkerBaseBulletEnv(BaseBulletEnv):
    # Cost constants
    ELECTRICITY_COST = 0.001
    JOINT_LIMIT_COST = 10.0
    FOOT_COLLISION_COST = 5.0
    PROGRESS_BONUS = 1.0
    ALIVE_BONUS = 1.0
    HEIGHT_THRESHOLD = 0.5
    PITCH_THRESHOLD = 0.4

    def __init__(self, robot_urdf, render=False):
        super().__init__(robot_urdf, render)
        self.scene = None
        self.camera_position = np.array([0.0, -2.0, 1.5])
        self.walk_target = np.array([0.0, 0.0, 0.0])
        self.state_id = -1
        self.robot_base = None
        self.foot_links = [0, 1]  # placeholder link indices for feet
        self.joint_indices = []
        self.joint_limits = {}
        self._init_robot()

    def _init_robot(self):
        self._load_robot()
        num_joints = p.getNumJoints(self.robot_id)
        for i in range(num_joints):
            info = p.getJointInfo(self.robot_id, i)
            self.joint_indices.append(i)
            lower, upper = info[8], info[9]
            self.joint_limits[i] = (lower, upper)

    def create_single_player_scene(self):
        self.scene = StadiumScene(render=self.render)
        self.scene.ground = p.loadURDF("plane.urdf")
        self.robot_base = self.scene.add_robot(self.robot, [0, 0, 0.5], p.getQuaternionFromEuler([0, 0, 0]))

    def reset(self):
        if self.state_id >= 0:
            p.restoreState(self.state_id)
        else:
            super()._reset()
            self._init_robot()
        self._find_feet()
        self.state_id = p.saveState()
        return self._get_state()

    def _find_feet(self):
        # Placeholder: identify foot link indices
        self.foot_links = []
        for i in self.joint_indices:
            info = p.getJointInfo(self.robot_id, i)
            if b"foot" in info[12].lower():
                self.foot_links.append(i)

    def move_robot(self, x, y, z):
        p.resetBasePositionAndOrientation(self.robot_id, [x, y, z], p.getQuaternionFromEuler([0, 0, 0]))

    def step(self, action):
        # action: array of desired joint velocities
        if not self.multiplayer:
            p.setJointMotorControlArray(self.robot_id,
                                        self.joint_indices,
                                        p.VELOCITY_CONTROL,
                                        targetVelocities=action,
                                        force=100)
            self.step_simulation()
        state = self._get_state()
        alive_bonus = self._compute_alive_bonus()
        progress = self._compute_progress(state)
        electricity = self._compute_electricity_cost()
        joint_limit = self._compute_joint_limit_penalty()
        foot_collision = self._compute_foot_collision_penalty()
        reward = (alive_bonus +
                  progress * self.PROGRESS_BONUS -
                  electricity * self.ELECTRICITY_COST -
                  joint_limit * self.JOINT_LIMIT_COST -
                  foot_collision * self.FOOT_COLLISION_COST)
        done = not alive_bonus
        self._update_hud(state, action, reward)
        self.camera_adjust()
        return state, reward, done, {}

    def _get_state(self):
        joint_states = p.getJointStates(self.robot_id, self.joint_indices)
        positions = [s[0] for s in joint_states]
        velocities = [s[1] for s in joint_states]
        base_pos, base_ori = p.getBasePositionAndOrientation(self.robot_id)
        state = np.array(positions + velocities + list(base_pos) + list(base_ori))
        return state

    def _compute_alive_bonus(self):
        base_pos, base_ori = p.getBasePositionAndOrientation(self.robot_id)
        height = base_pos[2]
        roll, pitch, yaw = p.getEulerFromQuaternion(base_ori)
        if height < self.HEIGHT_THRESHOLD or abs(pitch) > self.PITCH_THRESHOLD:
            return 0.0
        return self.ALIVE_BONUS

    def _compute_progress(self, state):
        # Simplified: change in height
        base_pos = state[-3:]
        height = base_pos[2]
        progress = height - self.walk_target[2]
        return max(progress, 0.0)

    def _compute_electricity_cost(self):
        total = 0.0
        for i in self.joint_indices:
            applied_torque = p.getJointState(self.robot_id, i)[3]
            total += abs(applied_torque)
        return total

    def _compute_joint_limit_penalty(self):
        penalty = 0.0
        for i in self.joint_indices:
            pos = p.getJointState(self.robot_id, i)[0]
            lower, upper = self.joint_limits[i]
            if pos <= lower + 0.05 or pos >= upper - 0.05:
                penalty += 1.0
        return penalty

    def _compute_foot_collision_penalty(self):
        penalty = 0.0
        for link in self.foot_links:
            contacts = p.getContactPoints(bodyA=self.robot_id, linkIndexA=link, bodyB=self.scene.ground)
            if contacts:
                penalty += 1.0
        return penalty

    def camera_adjust(self):
        target_pos, _ = p.getBasePositionAndOrientation(self.robot_id)
        desired_cam = np.array(target_pos) + np.array([0, -2, 1.5])
        self.camera_position += (desired_cam - self.camera_position) * 0.1
        p.resetDebugVisualizerCamera(distance=5,
                                     yaw=0,
                                     pitch=-30,
                                     targetPosition=self.camera_position)

    def _update_hud(self, state, action, reward):
        p.addUserDebugText(f"Reward: {reward:.3f}", [0, 0, 2], textSize=1.2, lifeTime=0.1)
        p.addUserDebugText(f"Alive Bonus: {self.ALIVE_BONUS}", [0, 0, 1.9], textSize=1.0, lifeTime=0.1)

# Example usage:
if __name__ == "__main__":
    env = WalkerBaseBulletEnv("r2d2.urdf", render=True)
    env.create_single_player_scene()
    state = env.reset()
    for _ in range(1000):
        action = np.zeros(len(env.joint_indices))
        state, reward, done, _ = env.step(action)
        if done:
            break
    p.disconnect()
