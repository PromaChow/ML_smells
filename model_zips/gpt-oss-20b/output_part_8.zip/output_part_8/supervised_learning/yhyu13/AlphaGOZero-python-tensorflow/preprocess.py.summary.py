import os
import sys
import random
import pickle
import gzip
import argh
import tensorflow as tf

# Add parent directory to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from utils.load_data_sets import (
    parse_data_sets,
    find_sgf_files,
    get_positions_from_sgf,
    iter_chunks,
    DataSet
)

def preprocess(data_sets, processed_dir='processed_data', one_big_training_chunck=True):
    """
    Preprocess Go game datasets.

    Parameters:
    - data_sets: list of paths to folders containing .sgf files.
    - processed_dir: directory to store processed data.
    - one_big_training_chunck: if True, all training data is written into a single file.
    """
    os.makedirs(processed_dir, exist_ok=True)

    # Split datasets into test and training chunks
    test_chunk, train_chunks = parse_data_sets(data_sets)
    print(f"Test chunk size: {len(test_chunk)}")

    # Convert test chunk to DataSet and write
    test_ds = DataSet.from_sgf_paths(test_chunk)
    test_file = os.path.join(processed_dir, 'test.chunk.gz')
    with gzip.open(test_file, 'wb') as f:
        pickle.dump(test_ds, f)

    # Process training chunks
    if one_big_training_chunck:
        all_train = [sgf for chunk in train_chunks for sgf in chunk]
        train_ds = DataSet.from_sgf_paths(all_train)
        train_file = os.path.join(processed_dir, 'train0.chunk.gz')
        with gzip.open(train_file, 'wb') as f:
            pickle.dump(train_ds, f)
        train_chunk_count = 1
    else:
        train_chunk_count = 0
        for idx, chunk in enumerate(train_chunks):
            ds = DataSet.from_sgf_paths(chunk)
            train_file = os.path.join(processed_dir, f'train{idx}.chunk.gz')
            with gzip.open(train_file, 'wb') as f:
                pickle.dump(ds, f)
            train_chunk_count += 1

    print(f"Total chunks written: {1 + train_chunk_count}")

def tfrecord(data_sets, processed_dir='processed_data'):
    """
    Convert Go game datasets to TFRecord format.

    Parameters:
    - data_sets: list of paths to folders containing .sgf files.
    - processed_dir: directory to store the TFRecord file.
    """
    os.makedirs(processed_dir, exist_ok=True)

    # Find all SGF files
    sgf_files = find_sgf_files(data_sets)

    # Extract positions and context from each SGF
    all_positions = []
    for sgf in sgf_files:
        positions = get_positions_from_sgf(sgf)
        all_positions.extend(positions)

    print(f"Total positions extracted: {len(all_positions)}")

    # Shuffle and chunk positions
    random.shuffle(all_positions)
    chunk_size = 4096
    chunks = list(iter_chunks(all_positions, chunk_size))

    # Write to TFRecord
    writer_path = os.path.join(processed_dir, 'train.tfrecords')
    with tf.io.TFRecordWriter(writer_path) as writer:
        for chunk in chunks:
            ds = DataSet.from_positions_w_context(chunk)
            feature_dict = {
                'labels': tf.train.Feature(
                    int64_list=tf.train.Int64List(value=ds.next_moves)
                ),
                'features': tf.train.Feature(
                    bytes_list=tf.train.BytesList(value=ds.pos_features)
                ),
                'results': tf.train.Feature(
                    int64_list=tf.train.Int64List(value=ds.results)
                ),
            }
            example = tf.train.Example(
                features=tf.train.Features(feature=feature_dict)
            )
            writer.write(example.SerializeToString())

    print(f"Total chunks written: {len(chunks)}")
    print(f"Total positions written: {len(all_positions)}")

if __name__ == "__main__":
    argh.dispatch_commands([preprocess, tfrecord])