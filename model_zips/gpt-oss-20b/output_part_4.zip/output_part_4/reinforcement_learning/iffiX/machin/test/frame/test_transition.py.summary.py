import pytest
import torch
from transition import TransitionBase, Transition

# Helper function to create tensors of given shape
def make_tensor(shape, dtype=torch.float32):
    return torch.randn(shape, dtype=dtype)

# ---------- TransitionBase.__init__ ----------

param_test_init_base = [
    # Valid case
    {
        "major": {"sa1": make_tensor((4, 3)), "sa2": make_tensor((4, 5))},
        "sub": {"sa3": make_tensor((4, 2)), "sa4": make_tensor((4, 1))},
        "custom": {"custom1": None},
        "exception": None,
        "match": None,
    },
    # Mismatched batch sizes
    {
        "major": {"sa1": make_tensor((4, 3))},
        "sub": {"sa3": make_tensor((5, 2))},
        "custom": {},
        "exception": ValueError,
        "match": "batch size mismatch",
    },
    # Scalar in tensor
    {
        "major": {"sa1": make_tensor((4, 3))},
        "sub": {"sa3": torch.tensor(5)},
        "custom": {},
        "exception": ValueError,
        "match": "expected tensor",
    },
    # None in major
    {
        "major": {"sa1": None},
        "sub": {"sa3": make_tensor((4, 2))},
        "custom": {},
        "exception": ValueError,
        "match": "None value in major",
    },
]

@pytest.mark.parametrize("case", param_test_init_base)
def test_transition_base_init(case):
    major = case["major"]
    sub = case["sub"]
    custom = case["custom"]
    exception = case["exception"]
    match = case["match"]
    if exception is None:
        tb = TransitionBase(major=major, sub=sub, custom=custom)
        assert isinstance(tb, TransitionBase)
    else:
        with pytest.raises(exception) as excinfo:
            TransitionBase(major=major, sub=sub, custom=custom)
        assert match in str(excinfo.value)

# ---------- TransitionBase.__len__ ----------

param_test_len = [
    {
        "major": {"sa1": make_tensor((4, 3)), "sa2": make_tensor((4, 5))},
        "sub": {"sa3": make_tensor((4, 2)), "sa4": make_tensor((4, 1))},
        "custom": {"custom1": None},
        "expected_len": 4,
    },
]

@pytest.mark.parametrize("case", param_test_len)
def test_transition_base_len(case):
    tb = TransitionBase(major=case["major"], sub=case["sub"], custom=case["custom"])
    assert len(tb) == case["expected_len"]

# ---------- TransitionBase.__setattr__, __setitem__, __getitem__ ----------

param_test_set_get = [
    {
        "major": {"sa1": make_tensor((4, 3))},
        "sub": {"sa2": make_tensor((4, 2))},
        "custom": {"custom1": None},
        "key": "sa1",
        "value": make_tensor((4, 3)),
    },
]

@pytest.mark.parametrize("case", param_test_set_get)
def test_transition_base_set_get(case):
    tb = TransitionBase(major=case["major"], sub=case["sub"], custom=case["custom"])
    key = case["key"]
    value = case["value"]

    # __getitem__ and __getattr__
    assert getattr(tb, key) is tb[key]
    assert tb[key] is tb[key]

    # __setitem__ and __setattr__
    tb[key] = value
    assert tb[key] is value
    tb.__setattr__(key, value)
    assert tb[key] is value

# ---------- Dynamic Attribute Setting ----------

def test_transition_base_dynamic_set():
    tb = TransitionBase(major={"sa1": make_tensor((4, 3))}, sub={}, custom={})
    with pytest.raises(RuntimeError) as excinfo:
        tb["some_attr"] = 1
    assert "You cannot dynamically set" in str(excinfo.value)
    with pytest.raises(RuntimeError) as excinfo:
        tb.some_attr = 1
    assert "You cannot dynamically set" in str(excinfo.value)

# ---------- TransitionBase Properties ----------

param_test_attr = [
    {
        "major": {"sa1": make_tensor((4, 3))},
        "sub": {"sa2": make_tensor((4, 2))},
        "custom": {"custom1": None},
    },
]

@pytest.mark.parametrize("case", param_test_attr)
def test_transition_base_properties(case):
    tb = TransitionBase(major=case["major"], sub=case["sub"], custom=case["custom"])
    assert tb.major_attr == list(case["major"].keys())
    assert tb.sub_attr == list(case["sub"].keys())
    assert tb.custom_attr == list(case["custom"].keys())
    expected_keys = tb.major_attr + tb.sub_attr + tb.custom_attr
    assert tb.keys() == expected_keys
    items = dict(tb.items())
    for k in expected_keys:
        assert k in items
    # has_keys
    assert tb.has_keys("sa1") is True
    assert tb.has_keys("nonexistent") is False

# ---------- TransitionBase.to() ----------

def test_transition_base_to(pytestconfig):
    device = pytestconfig.getoption("gpu_device")
    tb = TransitionBase(major={"sa1": make_tensor((4, 3))}, sub={}, custom={})
    tb.to(device)
    for val in tb.major_attr + tb.sub_attr + tb.custom_attr:
        attr = getattr(tb, val)
        if isinstance(attr, torch.Tensor):
            assert attr.device.type == device

# ---------- Transition.__init__ ----------

param_test_init_transition = [
    # Valid reward
    {
        "state": make_tensor((1, 3)),
        "action": make_tensor((1, 2)),
        "next_state": make_tensor((1, 3)),
        "reward": make_tensor((1, 1)),
        "terminal": torch.tensor([False]),
        "custom": {"foo": None},
        "exception": None,
        "match": None,
    },
    # Reward with batch > 1
    {
        "state": make_tensor((2, 3)),
        "action": make_tensor((2, 2)),
        "next_state": make_tensor((2, 3)),
        "reward": make_tensor((2, 1)),
        "terminal": torch.tensor([False, True]),
        "custom": {},
        "exception": ValueError,
        "match": "must be 1",
    },
]

@pytest.mark.parametrize("case", param_test_init_transition)
def test_transition_init(case, pytestconfig):
    kwargs = {
        "state": case["state"],
        "action": case["action"],
        "next_state": case["next_state"],
        "reward": case["reward"],
        "terminal": case["terminal"],
    }
    kwargs.update(case["custom"])
    exception = case["exception"]
    match = case["match"]
    if exception is None:
        tr = Transition(**kwargs)
        assert isinstance(tr, Transition)
        tr.to(pytestconfig.getoption("gpu_device"))
    else:
        with pytest.raises(exception) as excinfo:
            Transition(**kwargs)
        assert match in str(excinfo.value)