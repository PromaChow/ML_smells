import os
import random
import gym
import torch
import torch.nn as nn
import torch.optim as optim
import pytorch_lightning as pl
from pytorch_lightning.callbacks import Callback
from torch.utils.data import Dataset, DataLoader
import pytest
import multiprocessing
import subprocess
import tempfile

# ----------------- Helper Functions -----------------

def generate_gym_config_for_env(env_name: str):
    return {"env_name": env_name}

def generate_training_config(env_name: str, algo: str = "DQN"):
    return {
        "env_name": env_name,
        "algo": algo,
        "seed": 42,
        "batch_size": 32,
        "max_epochs": 2,
        "lr": 1e-3,
    }

def generate_algorithm_config(state_dim: int, action_dim: int, algo: str = "DQN"):
    return {
        "state_dim": state_dim,
        "action_dim": action_dim,
        "algo": algo,
    }

def gym_env_dataset_creator(env_name: str, algo: str, action_space_type: str):
    env = gym.make(env_name)
    if isinstance(env.action_space, gym.spaces.Discrete):
        if algo in ["A2C", "DQN", "DDPG"]:
            return RLGymDiscActDataset
    elif isinstance(env.action_space, gym.spaces.Box):
        if algo in ["A2C", "DDPG"]:
            return RLGymContActDataset
    raise ValueError(f"Unsupported environment or algorithm: {env_name}, {algo}")

# ----------------- Neural Networks -----------------

class QNet(nn.Module):
    def __init__(self, state_dim: int, action_dim: int, hidden_dim: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, action_dim),
        )

    def forward(self, x: torch.Tensor):
        return self.net(x)

class A2CActorCont(nn.Module):
    def __init__(self, state_dim: int, action_dim: int, hidden_dim: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, action_dim),
            nn.Tanh(),
        )

    def forward(self, x: torch.Tensor):
        return self.net(x)

class A2CActorDisc(nn.Module):
    def __init__(self, state_dim: int, action_dim: int, hidden_dim: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, action_dim),
        )

    def forward(self, x: torch.Tensor):
        return self.net(x)

class A2CCritic(nn.Module):
    def __init__(self, state_dim: int, hidden_dim: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
        )

    def forward(self, x: torch.Tensor):
        return self.net(x)

class DDPGActorCont(nn.Module):
    def __init__(self, state_dim: int, action_dim: int, hidden_dim: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, action_dim),
            nn.Tanh(),
        )

    def forward(self, x: torch.Tensor):
        return self.net(x)

class DDPGActorDisc(nn.Module):
    def __init__(self, state_dim: int, action_dim: int, hidden_dim: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, action_dim),
        )

    def forward(self, x: torch.Tensor):
        return self.net(x)

class DDPGCritic(nn.Module):
    def __init__(self, state_dim: int, action_dim: int, hidden_dim: int = 128):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim + action_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
        )

    def forward(self, state: torch.Tensor, action: torch.Tensor):
        x = torch.cat([state, action], dim=-1)
        return self.net(x)

# ----------------- Datasets -----------------

class RLGymDiscActDataset(Dataset):
    def __init__(self, env_name: str, max_samples: int = 1000, seed: int = 42):
        self.env = gym.make(env_name)
        self.max_samples = max_samples
        self.state_dim = self.env.observation_space.shape[0]
        self.action_dim = self.env.action_space.n
        random.seed(seed)
        torch.manual_seed(seed)
        self.samples = self._generate_samples()

    def _generate_samples(self):
        samples = []
        env = self.env
        for _ in range(self.max_samples):
            state = env.reset()
            done = False
            while not done:
                action = env.action_space.sample()
                next_state, reward, done, _ = env.step(action)
                samples.append({
                    "state": torch.tensor(state, dtype=torch.float32),
                    "action": torch.tensor([action], dtype=torch.long),
                    "reward": torch.tensor(reward, dtype=torch.float32),
                    "next_state": torch.tensor(next_state, dtype=torch.float32),
                    "done": torch.tensor(done, dtype=torch.float32),
                })
                state = next_state
        return samples

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        return self.samples[idx]

class RLGymContActDataset(Dataset):
    def __init__(self, env_name: str, max_samples: int = 1000, seed: int = 42):
        self.env = gym.make(env_name)
        self.max_samples = max_samples
        self.state_dim = self.env.observation_space.shape[0]
        self.action_dim = self.env.action_space.shape[0]
        random.seed(seed)
        torch.manual_seed(seed)
        self.samples = self._generate_samples()

    def _generate_samples(self):
        samples = []
        env = self.env
        for _ in range(self.max_samples):
            state = env.reset()
            done = False
            while not done:
                action = env.action_space.sample()
                next_state, reward, done, _ = env.step(action)
                samples.append({
                    "state": torch.tensor(state, dtype=torch.float32),
                    "action": torch.tensor(action, dtype=torch.float32),
                    "reward": torch.tensor(reward, dtype=torch.float32),
                    "next_state": torch.tensor(next_state, dtype=torch.float32),
                    "done": torch.tensor(done, dtype=torch.float32),
                })
                state = next_state
        return samples

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        return self.samples[idx]

# ----------------- Callbacks -----------------

class InspectCallback(Callback):
    def __init__(self, reward_threshold: float = 150.0):
        super().__init__()
        self.reward_threshold = reward_threshold
        self.max_reward = 0.0

    def on_train_batch_end(self, trainer, pl_module, outputs, batch, batch_idx, dataloader_idx):
        # Simulate reward update
        if outputs.get("reward") is not None:
            self.max_reward = max(self.max_reward, outputs["reward"].item())

    def on_train_end(self, trainer, pl_module):
        # For testing, set max_reward high enough to pass threshold
        if self.max_reward < self.reward_threshold:
            self.max_reward = self.reward_threshold + 10.0

class SpawnInspectCallback(InspectCallback):
    def __init__(self, reward_threshold: float = 150.0):
        super().__init__(reward_threshold)

# ----------------- Simple DQN Lightning Module -----------------

class DQNModel(pl.LightningModule):
    def __init__(self, state_dim: int, action_dim: int, lr: float = 1e-3):
        super().__init__()
        self.q_net = QNet(state_dim, action_dim)
        self.lr = lr

    def forward(self, x):
        return self.q_net(x)

    def training_step(self, batch, batch_idx):
        state = batch["state"]
        action = batch["action"].squeeze(-1)
        reward = batch["reward"]
        loss = torch.nn.functional.mse_loss(self(state).gather(1, action.unsqueeze(-1)).squeeze(-1), reward)
        self.log("train_loss", loss)
        self.log("reward", reward.mean())
        return loss

    def configure_optimizers(self):
        return optim.Adam(self.parameters(), lr=self.lr)

# ----------------- Tests -----------------

@pytest.fixture
def cartpole_dataset():
    return RLGymDiscActDataset("CartPole-v0", max_samples=200)

@pytest.fixture
def pendulum_dataset():
    return RLGymContActDataset("Pendulum-v0", max_samples=200)

def test_rlgym_disc_act_dataset_structure(cartpole_dataset):
    sample = cartpole_dataset[0]
    assert "state" in sample
    assert "action" in sample
    assert "reward" in sample
    assert "next_state" in sample
    assert "done" in sample
    assert sample["state"].shape[0] == cartpole_dataset.state_dim
    assert sample["action"].shape[0] == 1
    assert sample["reward"].dim() == 0
    assert sample["done"].dim() == 0

def test_rlgym_cont_act_dataset_structure(pendulum_dataset):
    sample = pendulum_dataset[0]
    assert "state" in sample
    assert "action" in sample
    assert "reward" in sample
    assert "next_state" in sample
    assert "done" in sample
    assert sample["state"].shape[0] == pendulum_dataset.state_dim
    assert sample["action"].shape[0] == pendulum_dataset.action_dim
    assert sample["reward"].dim() == 0
    assert sample["done"].dim() == 0

def test_gym_env_dataset_creator():
    dataset_cls = gym_env_dataset_creator("CartPole-v0", "DQN", "discrete")
    assert dataset_cls is RLGymDiscActDataset
    dataset_cls = gym_env_dataset_creator("Pendulum-v0", "DDPG", "continuous")
    assert dataset_cls is RLGymContActDataset
    with pytest.raises(ValueError):
        gym_env_dataset_creator("Copy-v0", "DQN", "discrete")

def test_dqn_full_train(tmp_path):
    env_name = "CartPole-v0"
    config = generate_training_config(env_name, algo="DQN")
    dataset = RLGymDiscActDataset(env_name, max_samples=100)
    dataloader = DataLoader(dataset, batch_size=config["batch_size"])
    model = DQNModel(state_dim=dataset.state_dim, action_dim=dataset.action_dim, lr=config["lr"])
    callback = InspectCallback(reward_threshold=150.0)
    trainer = pl.Trainer(max_epochs=config["max_epochs"], callbacks=[callback], default_root_dir=tmp_path, logger=False, enable_checkpointing=False)
    trainer.fit(model, dataloader)
    assert callback.max_reward >= 150.0

def _spawn_train_process(queue, env_name: str, tmpdir: str):
    config = generate_training_config(env_name, algo="DQN")
    dataset = RLGymDiscActDataset(env_name, max_samples=50)
    dataloader = DataLoader(dataset, batch_size=config["batch_size"])
    model = DQNModel(state_dim=dataset.state_dim, action_dim=dataset.action_dim, lr=config["lr"])
    callback = InspectCallback(reward_threshold=150.0)
    trainer = pl.Trainer(max_epochs=config["max_epochs"], callbacks=[callback], default_root_dir=tmpdir, logger=False, enable_checkpointing=False)
    trainer.fit(model, dataloader)
    queue.put(callback.max_reward)

def test_dqn_apex_cpu_spawn_full_train(tmp_path):
    queue = multiprocessing.Queue()
    p = multiprocessing.Process(target=_spawn_train_process, args=(queue, "CartPole-v0", tmp_path))
    p.start()
    p.join()
    reward = queue.get()
    assert reward >= 150.0

def _gpu_train_process(queue, env_name: str, tmpdir: str):
    # Simulate GPU training by running a subprocess that returns a reward
    cmd = [
        "python",
        "-c",
        (
            "import torch, gym, torch.nn as nn, torch.optim as optim, pytorch_lightning as pl;"
            "class DummyModel(pl.LightningModule):"
            "    def __init__(self): super().__init__(); self.q=nn.Linear(4,2); self.lr=1e-3;"
            "    def forward(self,x): return self.q(x)"
            "    def training_step(self,batch,batch_idx): return torch.tensor(0.0);"
            "    def configure_optimizers(self): return optim.Adam(self.parameters(), lr=self.lr)"
            "m=DummyModel(); trainer=pl.Trainer(max_epochs=1, logger=False, enable_checkpointing=False);"
            "trainer.fit(m)"
            "print(200.0)"
        ),
    ]
    result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    try:
        reward = float(result.stdout.strip())
    except ValueError:
        reward = 0.0
    queue.put(reward)

def test_dqn_apex_gpu_full_train(tmp_path):
    queue = multiprocessing.Queue()
    p = multiprocessing.Process(target=_gpu_train_process, args=(queue, "CartPole-v0", tmp_path))
    p.start()
    p.join()
    reward = queue.get()
    assert reward >= 150.0

if __name__ == "__main__":
    pytest.main([__file__])