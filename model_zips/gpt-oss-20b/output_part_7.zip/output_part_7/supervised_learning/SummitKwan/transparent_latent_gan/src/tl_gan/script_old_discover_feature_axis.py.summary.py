import os
import glob
import pickle
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image

# 1. Setup and Pre‑Requisites
project_root = os.path.abspath('.')
data_dir = os.path.join(project_root, 'asset_results', 'pggan_celeba_sample_pkl')
os.makedirs(data_dir, exist_ok=True)

# 2. Feature Extraction Function
def get_feature(x):
    """
    Compute foreground and background luminance for a single image.
    x: numpy array of shape (H, W, 3) with values in [0, 255].
    Returns a 2‑element array [fg_lum, bg_lum].
    """
    h, w, _ = x.shape
    luminance = 0.2126 * x[..., 0] + 0.7152 * x[..., 1] + 0.0722 * x[..., 2]
    # Foreground: central 3/4 region
    fh_start, fh_end = int(h * 1/8), int(h * 7/8)
    fw_start, fw_end = int(w * 1/8), int(w * 7/8)
    fg_lum = luminance[fh_start:fh_end, fw_start:fw_end].mean()
    # Background: top‑left 1/4 region
    bh_start, bh_end = 0, int(h * 1/4)
    bw_start, bw_end = 0, int(w * 1/4)
    bg_lum = luminance[bh_start:bh_end, bw_start:bw_end].mean()
    return np.array([fg_lum, bg_lum], dtype=np.float32)

# 3. Data Loading and Preprocessing
pkl_paths = sorted(glob.glob(os.path.join(data_dir, '*.pkl')))[:8000]
z_list, y_list = [], []

for path in pkl_paths:
    with open(path, 'rb') as f:
        data = pickle.load(f)
    z = data['z']          # latent vectors, shape (N, latent_dim)
    x = data['x']          # generated images, shape (N, H, W, 3)
    for img in x:
        y_list.append(get_feature(img))
    z_list.append(z)

z_all = np.concatenate(z_list, axis=0)
y_all_raw = np.concatenate(y_list, axis=0)
# Standardize features
y_mean = y_all_raw.mean(axis=0)
y_std = y_all_raw.std(axis=0)
y_all = (y_all_raw - y_mean) / y_std

# 4. Feature Axis Discovery
# Solve y = z * beta
beta, _, _, _ = np.linalg.lstsq(z_all, y_all, rcond=None)
# beta shape: (latent_dim, 2)
feature_direction_fg = beta[:, 0]   # direction for foreground luminance
feature_direction_bg = beta[:, 1]   # direction for background luminance

# 5. Visualization of Sample Image
first_pickle = pkl_paths[0]
with open(first_pickle, 'rb') as f:
    sample_data = pickle.load(f)
sample_x = sample_data['x']
if len(sample_x) > 5:
    sample_img = sample_x[5]  # 6th image
    plt.imshow(sample_img.astype(np.uint8))
    plt.axis('off')
    plt.title('Sample Image (6th in first pickle)')
    plt.show()

# 6. Latent Space Exploration and Image Generation
model_path = os.path.join(project_root, 'asset_model', 'karras2018iclr-celebahq-1024x1024.pkl')
with open(model_path, 'rb') as f:
    G = pickle.load(f)
# Assume generator is under key 'G_synthesis' or 'G'
Gs = G.get('G_synthesis', G.get('G', None))
if Gs is None:
    raise KeyError("Generator 'G_synthesis' or 'G' not found in the model pickle.")

output_dir = os.path.join(project_root, 'asset_results', 'pggan_celeba_feature_axis_explore')
os.makedirs(output_dir, exist_ok=True)

latent_dim = z_all.shape[1]
directions = {
    'fg_lum': feature_direction_fg,
    'bg_lum': feature_direction_bg
}

for feat_name, direction in directions.items():
    dir_dir = os.path.join(output_dir, feat_name)
    os.makedirs(dir_dir, exist_ok=True)
    # Random base latent vector
    latents_c = np.random.randn(1, latent_dim).astype(np.float32)
    # Perturbations ±2 * direction
    delta = 2.0 * direction.reshape(1, -1).astype(np.float32)
    latents_0 = latents_c - delta
    latents_1 = latents_c + delta
    # Interpolation steps
    steps = np.linspace(-2.0, 2.0, num=7)
    latents_interp = latents_c + (steps[:, None] * direction.reshape(1, -1)).astype(np.float32)
    # Generate images
    imgs = Gs.run(
        latents_interp,
        randomize_noise=False,
        output_transform=dict(func=lambda x: x[0], nchw_to_nhwc=True)
    )
    # Save images and labels
    labels = []
    for i, img in enumerate(imgs):
        img_uint8 = np.clip(img * 255, 0, 255).astype(np.uint8)
        im = Image.fromarray(img_uint8)
        fname = os.path.join(dir_dir, f'{feat_name}_{i:03d}.png')
        im.save(fname)
        labels.append(steps[i])
    # Save labels as pickle
    label_path = os.path.join(dir_dir, f'{feat_name}_labels.pkl')
    with open(label_path, 'wb') as f:
        pickle.dump(labels, f)