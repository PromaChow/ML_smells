import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, plot_tree

def main():
    # 1. Load the Iris dataset from a URL
    url = "https://raw.githubusercontent.com/uiuc-cse/data-fa14/gh-pages/data/iris.csv"
    df = pd.read_csv(url)

    # Display first and last five rows
    print("First five rows:")
    print(df.head())
    print("\nLast five rows:")
    print(df.tail())

    # 2. Split data into features and target
    feature_cols = ['sepal_length', 'sepal_width', 'petal_length', 'petal_width']
    X = df[feature_cols]
    Y = df['species']

    # 3. Split into training and testing sets
    x_train, x_test, y_train, y_test = train_test_split(X, Y)

    # 4. Initialize and train Decision Tree Classifier
    DTC = DecisionTreeClassifier(criterion='entropy', max_features=2)
    DTC.fit(x_train, y_train)

    # 5. Predict on the test set
    yhat = DTC.predict(x_test)

    # 6. Evaluate feature importance
    importances = DTC.feature_importances_
    for feature, importance in zip(feature_cols, importances):
        print(f"Feature: {feature}, Importance: {importance:.4f}")

    # Bar plot of feature importances
    plt.figure(figsize=(8, 6))
    sns.barplot(x=feature_cols, y=importances, palette="viridis")
    plt.title("Feature Importances")
    plt.ylabel("Importance")
    plt.xlabel("Feature")
    plt.tight_layout()
    plt.show()

    # 7. Visualize the decision tree (default settings)
    plt.figure(figsize=(12, 8))
    plot_tree(DTC, feature_names=feature_cols, class_names=DTC.classes_, rounded=True)
    plt.title("Decision Tree (Default Settings)")
    plt.show()

    # 8. Visualize the decision tree with adjusted figure size and filled nodes
    plt.figure(figsize=(16, 9))
    plot_tree(DTC, feature_names=feature_cols, class_names=DTC.classes_,
              filled=True, rounded=True)
    plt.title("Decision Tree (Filled Nodes)")
    plt.show()

if __name__ == "__main__":
    main()