import numpy as np
from sklearn.tree import DecisionTreeClassifier

class DT_sklearn_clf:
    def __init__(self, max_depth: int = 20, min_samples_leaf: int = 10):
        self.max_depth = max_depth
        self.min_samples_leaf = min_samples_leaf
        self.model = DecisionTreeClassifier(
            criterion="gini",
            splitter="best",
            max_depth=self.max_depth,
            min_samples_leaf=self.min_samples_leaf
        )

    def fit(self, X, y):
        self.model.fit(X, y)

    def predict(self, X):
        return self.model.predict(X)

    def loss(self, y):
        y_arr = np.asarray(y)
        unique, counts = np.unique(y_arr, return_counts=True)
        probabilities = counts / y_arr.size
        gini_impurity = 1.0 - np.sum(probabilities ** 2)
        return gini_impurity

if __name__ == "__main__":
    # Example usage
    from sklearn.datasets import load_iris
    from sklearn.model_selection import train_test_split

    X, y = load_iris(return_X_y=True)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    clf = DT_sklearn_clf(max_depth=5, min_samples_leaf=5)
    clf.fit(X_train, y_train)
    predictions = clf.predict(X_test)
    print("Predictions:", predictions)
    print("Gini impurity of true labels:", clf.loss(y_test))