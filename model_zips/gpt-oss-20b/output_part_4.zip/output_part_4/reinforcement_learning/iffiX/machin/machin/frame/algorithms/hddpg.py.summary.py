import torch
import torch.nn as nn
import torch.optim as optim
import random
import numpy as np


class ReplayBuffer:
    """Simple replay buffer."""

    def __init__(self, capacity: int):
        self.capacity = capacity
        self.buffer = []
        self.position = 0

    def push(self, state, action, reward, next_state, done):
        """Store a transition."""
        if len(self.buffer) < self.capacity:
            self.buffer.append(None)
        self.buffer[self.position] = (state, action, reward, next_state, done)
        self.position = (self.position + 1) % self.capacity

    def sample(self, batch_size: int):
        """Randomly sample a batch of transitions."""
        batch = random.sample(self.buffer, batch_size)
        state, action, reward, next_state, done = map(np.stack, zip(*batch))
        return (
            torch.FloatTensor(state),
            torch.FloatTensor(action),
            torch.FloatTensor(reward).unsqueeze(-1),
            torch.FloatTensor(next_state),
            torch.FloatTensor(done).unsqueeze(-1),
        )

    def __len__(self):
        return len(self.buffer)


class DDPG:
    """Basic DDPG implementation."""

    def __init__(
        self,
        actor,
        critic,
        actor_optimizer,
        critic_optimizer,
        buffer: ReplayBuffer,
        lr_actor: float,
        lr_critic: float,
        gamma: float,
        tau: float,
        update_steps: int,
        device: torch.device,
    ):
        self.actor = actor.to(device)
        self.critic = critic.to(device)
        self.target_actor = type(actor)(*actor.parameters()).to(device)
        self.target_critic = type(critic)(*critic.parameters()).to(device)
        self.target_actor.load_state_dict(self.actor.state_dict())
        self.target_critic.load_state_dict(self.critic.state_dict())
        self.actor_optimizer = actor_optimizer
        self.critic_optimizer = critic_optimizer
        self.buffer = buffer
        self.gamma = gamma
        self.tau = tau
        self.update_steps = update_steps
        self.device = device
        self.total_it = 0

    def soft_update(self, target, source, tau):
        for target_param, param in zip(target.parameters(), source.parameters()):
            target_param.data.copy_(tau * param.data + (1.0 - tau) * target_param.data)

    def hard_update(self, target, source):
        target.load_state_dict(source.state_dict())

    def update(self, batch_size: int, clip_norm: float = 1.0):
        pass  # To be overridden by child classes


class HDDPG(DDPG):
    """HDDPG – DDPG with asymmetric Q‑value scaling during critic updates."""

    def __init__(
        self,
        actor,
        critic,
        actor_optimizer,
        critic_optimizer,
        buffer: ReplayBuffer,
        lr_actor: float,
        lr_critic: float,
        gamma: float,
        tau: float,
        update_steps: int,
        device: torch.device,
        q_increase_rate: float = 1.0,
        q_decrease_rate: float = 1.0,
    ):
        super().__init__(
            actor,
            critic,
            actor_optimizer,
            critic_optimizer,
            buffer,
            lr_actor,
            lr_critic,
            gamma,
            tau,
            update_steps,
            device,
        )
        self.q_increase_rate = q_increase_rate
        self.q_decrease_rate = q_decrease_rate

    def update(self, batch_size: int, clip_norm: float = 1.0):
        self.total_it += 1

        # Set networks to training mode
        self.actor.train()
        self.critic.train()

        # Sample batch from replay buffer
        state, action, reward, next_state, done = self.buffer.sample(batch_size)
        state = state.to(self.device)
        action = action.to(self.device)
        reward = reward.to(self.device)
        next_state = next_state.to(self.device)
        done = done.to(self.device)

        # ----- Critic update -----
        with torch.no_grad():
            next_action = self.target_actor(next_state)
            target_q = self.target_critic(next_state, next_action)
            y = reward + self.gamma * target_q * (1.0 - done)

        current_q = self.critic(state, action)

        value_diff = y - current_q
        scaled_diff = torch.where(
            value_diff > 0,
            value_diff * self.q_increase_rate,
            value_diff * self.q_decrease_rate,
        )
        value_loss = nn.functional.mse_loss(current_q, scaled_diff)

        self.critic_optimizer.zero_grad()
        value_loss.backward()
        nn.utils.clip_grad_norm_(self.critic.parameters(), clip_norm)
        self.critic_optimizer.step()

        # ----- Actor update -----
        actor_action = self.actor(state)
        policy_loss = -self.critic(state, actor_action).mean()

        self.actor_optimizer.zero_grad()
        policy_loss.backward()
        nn.utils.clip_grad_norm_(self.actor.parameters(), clip_norm)
        self.actor_optimizer.step()

        # ----- Target networks update -----
        if self.total_it % self.update_steps == 0:
            # Hard update
            self.hard_update(self.target_actor, self.actor)
            self.hard_update(self.target_critic, self.critic)
        else:
            # Soft update
            self.soft_update(self.target_actor, self.actor, self.tau)
            self.soft_update(self.target_critic, self.critic, self.tau)

        # Set networks to eval mode
        self.actor.eval()
        self.critic.eval()

        return -policy_loss.item(), value_loss.item()


def get_hddpg_config():
    """Generate default configuration dictionary for HDDPG."""
    config = {
        "frame": "HDDPG",
        "q_increase_rate": 1.0,
        "q_decrease_rate": 1.0,
        # Additional DDPG configuration parameters would be set here
    }
    return config
