import re
import copy
from dataclasses import dataclass
from typing import List, Tuple, Optional, Dict, Iterator

# --- SGF Parsing ---

SGF_NODE_RE = re.compile(r"\(([^()]*)\)")
PROP_RE = re.compile(r"([A-Z]+)\[([^\]]*)\]")

def parse_sgf_nodes(sgf: str) -> List[Dict[str, List[str]]]:
    """Parse SGF content into a flat list of node property dictionaries."""
    nodes = []
    stack = [sgf]
    while stack:
        block = stack.pop()
        # Find top-level nodes
        for node_text in SGF_NODE_RE.findall(block):
            props = {}
            for prop, val in PROP_RE.findall(node_text):
                props.setdefault(prop, []).append(val)
            nodes.append(props)
            # Extract subblocks for children
            subblock = node_text[node_text.find(')')+1:]
            if subblock:
                stack.append(subblock)
    return nodes

def parse_coord(coord: str, size: int) -> Optional[Tuple[int, int]]:
    if coord == "":
        return None  # Pass
    if len(coord) != 2:
        return None
    col = ord(coord[0]) - ord("a")
    row = ord(coord[1]) - ord("a")
    if 0 <= row < size and 0 <= col < size:
        return (row, col)
    return None

# --- Go Board ---

class GoBoard:
    def __init__(self, size: int, komi: float = 0.0):
        self.size = size
        self.komi = komi
        self.grid = [[None for _ in range(size)] for _ in range(size)]
        self.turn = "B"

    def copy(self):
        new_board = GoBoard(self.size, self.komi)
        new_board.grid = copy.deepcopy(self.grid)
        new_board.turn = self.turn
        return new_board

    def place_stone(self, color: str, coord: Tuple[int, int]):
        row, col = coord
        self.grid[row][col] = color

    def apply_move(self, color: str, coord: Optional[Tuple[int, int]]):
        if coord is not None:
            self.place_stone(color, coord)
        self.turn = "W" if color == "B" else "B"

    def add_stones(self, color: str, coords: List[Tuple[int, int]]):
        for c in coords:
            self.place_stone(color, c)

# --- Data Classes ---

@dataclass
class PositionWithContext:
    board: GoBoard
    next_move: Optional[Tuple[str, Optional[Tuple[int, int]]]]
    result: str
    handicap: int
    size: int

    def __post_init__(self):
        if self.handicap > 4:
            raise ValueError("Handicap exceeds maximum allowed value of 4")
        if not self.result:
            raise ValueError("Result metadata is missing")

# --- Replay Functions ---

def replay_sgf(sgf_content: str) -> Iterator[PositionWithContext]:
    nodes = parse_sgf_nodes(sgf_content)
    if not nodes:
        return
    root = nodes[0]
    size = int(root.get("SZ", ["19"])[0])
    handicap = int(root.get("HA", ["0"])[0])
    result = root.get("RE", [""])[0]
    komi = float(root.get("KM", ["0"])[0])
    board = GoBoard(size, komi)
    # Apply initial handicap stones if specified
    if handicap:
        ab_vals = root.get("AB", [])
        aw_vals = root.get("AW", [])
        ab_coords = [parse_coord(v, size) for v in ab_vals if parse_coord(v, size)]
        aw_coords = [parse_coord(v, size) for v in aw_vals if parse_coord(v, size)]
        board.add_stones("B", ab_coords)
        board.add_stones("W", aw_coords)
        board.turn = "B" if handicap % 2 == 0 else "W"
    for i, node in enumerate(nodes[1:]):  # skip root
        # Stone additions
        for val in node.get("AB", []):
            coord = parse_coord(val, size)
            if coord:
                board.place_stone("B", coord)
        for val in node.get("AW", []):
            coord = parse_coord(val, size)
            if coord:
                board.place_stone("W", coord)
        # Move execution
        move_prop = None
        color = None
        if "B" in node:
            move_prop = node["B"][0]
            color = "B"
        elif "W" in node:
            move_prop = node["W"][0]
            color = "W"
        if move_prop is not None:
            coord = parse_coord(move_prop, size)
            board.apply_move(color, coord)
        # Next move extraction
        next_node = nodes[i+2] if i+2 < len(nodes) else None
        next_move = None
        if next_node:
            if "B" in next_node:
                next_move = ("B", parse_coord(next_node["B"][0], size))
            elif "W" in next_node:
                next_move = ("W", parse_coord(next_node["W"][0], size))
        yield PositionWithContext(
            board=board.copy(),
            next_move=next_move,
            result=result,
            handicap=handicap,
            size=size
        )

def replay_position(size: int, komi: float, moves: List[Tuple[str, Optional[Tuple[int, int]]]], result: str = "0-1") -> Iterator[PositionWithContext]:
    board = GoBoard(size, komi)
    handicap = 0
    for idx, (color, coord) in enumerate(moves):
        if coord is not None:
            board.apply_move(color, coord)
        else:
            board.turn = "W" if color == "B" else "B"
        next_move = None
        if idx + 1 < len(moves):
            next_move = moves[idx + 1]
        yield PositionWithContext(
            board=board.copy(),
            next_move=next_move,
            result=result,
            handicap=handicap,
            size=size
        )
```