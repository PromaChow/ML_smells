import numpy as np
import torch
from typing import Any, Optional, Union

def tensorify(x: Any, device: Union[str, torch.device]) -> torch.Tensor:
    """
    Convert an input to a PyTorch tensor on the specified device.

    Parameters
    ----------
    x : Any
        Input data; may be a PyTorch tensor, a NumPy array, or any object convertible to a NumPy array.
    device : str or torch.device
        Target device for the resulting tensor.

    Returns
    -------
    torch.Tensor
        Tensor on the specified device with dtype torch.float32.
    """
    if isinstance(x, torch.Tensor):
        if x.device != device:
            return x.to(device)
        return x
    if isinstance(x, np.ndarray):
        return torch.from_numpy(x).float().to(device)
    arr = np.asarray(x)
    return torch.from_numpy(arr).float().to(device)

def numpify(x: Any, dtype: Optional[Any] = None) -> np.ndarray:
    """
    Convert an input to a NumPy array, detaching tensors from the graph.

    Parameters
    ----------
    x : Any
        Input data; may be a PyTorch tensor or any object convertible to a NumPy array.
    dtype : optional
        Desired data type for the resulting NumPy array.

    Returns
    -------
    np.ndarray
        NumPy array representation of the input.
    """
    if isinstance(x, torch.Tensor):
        arr = x.detach().cpu().numpy()
    else:
        arr = np.asarray(x)
    if dtype is not None:
        arr = arr.astype(dtype)
    return arr
