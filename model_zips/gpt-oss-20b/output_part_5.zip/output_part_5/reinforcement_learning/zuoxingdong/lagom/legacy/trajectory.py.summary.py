import dataclasses
import numpy as np
import gymnasium as gym
from gymnasium import spaces

@dataclasses.dataclass
class StepInfo:
    last: bool
    terminal: bool
    time_limit: bool


class Trajectory:
    def __init__(self):
        self.observations = []
        self.actions = []
        self.rewards = []
        self.step_infos = []

    @property
    def completed(self):
        return bool(self.step_infos) and self.step_infos[-1].last

    def add_observation(self, observation):
        assert not self.completed, "Cannot add observation: trajectory completed."
        self.observations.append(observation)

    def add_action(self, action):
        assert not self.completed, "Cannot add action: trajectory completed."
        self.actions.append(action)

    def add_reward(self, reward):
        assert not self.completed, "Cannot add reward: trajectory completed."
        self.rewards.append(reward)

    def add_step_info(self, step_info):
        assert not self.completed, "Cannot add step_info: trajectory completed."
        self.step_infos.append(step_info)

    @property
    def numpy_observations(self):
        return np.array(self.observations)

    @property
    def numpy_actions(self):
        return np.array(self.actions)

    @property
    def numpy_rewards(self):
        return np.array(self.rewards)

    @property
    def numpy_dones(self):
        return np.array([si.last for si in self.step_infos])

    @property
    def numpy_masks(self):
        return 1 - self.numpy_dones

    @property
    def reach_terminal(self):
        return bool(self.step_infos) and self.step_infos[-1].terminal

    @property
    def reach_time_limit(self):
        return bool(self.step_infos) and self.step_infos[-1].time_limit


class SanityEnv(gym.Env):
    metadata = {"render_modes": []}

    def __init__(self, max_steps=10):
        super().__init__()
        self.max_steps = max_steps
        self.observation_space = spaces.Box(low=0, high=max_steps, shape=(1,), dtype=np.int32)
        self.action_space = spaces.Discrete(2)
        self.state = 0
        self.steps_taken = 0

    def reset(self, seed=None, options=None):
        self.state = 0
        self.steps_taken = 0
        return np.array([self.state], dtype=np.int32), {}

    def step(self, action):
        self.state += 1
        self.steps_taken += 1
        reward = 1.0
        terminated = self.state >= self.max_steps - 1
        truncated = self.steps_taken >= self.max_steps
        info = {}
        return np.array([self.state], dtype=np.int32), reward, terminated, truncated, info


def test_trajectory_behavior():
    max_steps = 5
    env = SanityEnv(max_steps=max_steps)
    obs, _ = env.reset()
    trajectory = Trajectory()
    trajectory.add_observation(obs)

    for _ in range(max_steps):
        action = env.action_space.sample()
        trajectory.add_action(action)
        next_obs, reward, terminated, truncated, _ = env.step(action)
        trajectory.add_reward(reward)
        step_info = StepInfo(
            last=terminated or truncated,
            terminal=terminated,
            time_limit=truncated
        )
        trajectory.add_step_info(step_info)
        trajectory.add_observation(next_obs)

        if step_info.last:
            break

    length = len(trajectory.step_infos)
    assert length == len(trajectory.rewards) == len(trajectory.actions) == len(trajectory.observations) - 1

    np_obs = trajectory.numpy_observations
    np_actions = trajectory.numpy_actions
    np_rewards = trajectory.numpy_rewards
    np_dones = trajectory.numpy_dones
    np_masks = trajectory.numpy_masks

    assert np_obs.shape[0] == length + 1
    assert np_actions.shape[0] == length
    assert np_rewards.shape[0] == length
    assert np_dones.shape[0] == length
    assert np_masks.shape[0] == length

    assert trajectory.completed is True
    assert trajectory.reach_terminal == terminated
    assert trajectory.reach_time_limit == truncated

    assert np.all(np_masks == 1 - np_dones)


if __name__ == "__main__":
    test_trajectory_behavior()
    print("All tests passed.")