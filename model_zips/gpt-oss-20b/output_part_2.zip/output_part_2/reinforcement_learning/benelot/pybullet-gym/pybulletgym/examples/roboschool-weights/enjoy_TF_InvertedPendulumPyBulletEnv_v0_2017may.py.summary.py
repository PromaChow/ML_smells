import sys
import os
import time
import numpy as np
import gym
import pybulletgym.envs  # Register PyBullet environments

# Add parent directory to path for source code builds
parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if parent_dir not in sys.path:
    sys.path.append(parent_dir)

# Activation function
def relu(x):
    return np.maximum(0, x)

# Global weight matrices and biases
np.random.seed(42)
weights_dense1_w = np.random.randn(50, 64)
weights_dense1_b = np.random.randn(64)
weights_dense2_w = np.random.randn(64, 32)
weights_dense2_b = np.random.randn(32)
weights_final_w = np.random.randn(32, 1)
weights_final_b = np.random.randn(1)

class SmallReactivePolicy:
    def __init__(self, obs_space, act_space):
        self.obs_shape = obs_space.shape
        self.act_shape = act_space.shape
        self.act_low = act_space.low
        self.act_high = act_space.high

    def get_action(self, observation):
        x = observation.reshape(-1, 1)  # column vector
        h1 = relu(weights_dense1_w.T @ x + weights_dense1_b.reshape(-1, 1))
        h2 = relu(weights_dense2_w.T @ h1 + weights_dense2_b.reshape(-1, 1))
        out = weights_final_w.T @ h2 + weights_final_b.reshape(-1, 1)
        action = np.clip(out, self.act_low, self.act_high)
        return action.flatten()

def main():
    env = gym.make("InvertedPendulumPyBulletEnv-v0")
    policy = SmallReactivePolicy(env.observation_space, env.action_space)

    while True:
        obs = env.reset()
        done = False
        total_reward = 0.0
        while not done:
            env.render(mode="human")
            action = policy.get_action(obs)
            obs, reward, done, _ = env.step(action)
            total_reward += reward
            time.sleep(1.0 / env.frame_skip)
        print(f"Episode finished. Total reward: {total_reward:.2f}")
        time.sleep(2.0)

if __name__ == "__main__":
    main()
