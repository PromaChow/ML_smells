import random
from typing import Any, Callable, List

import utils
import augmentation_pool


class RandAugment:
    def __init__(
        self,
        nops: int,
        magnitude: int = 10,
        prob: float = 0.5,
        alg: str = "fixmatch",
    ):
        if alg not in ("fixmatch", "uda"):
            raise ValueError(f"Unsupported algorithm: {alg!r}")
        self.nops = nops
        self.magnitude = magnitude
        self.prob = prob
        self.alg = alg

        if alg == "fixmatch":
            self.ops_list = utils.FIXMATCH_RANDAUGMENT_OPS_LIST
        else:  # uda
            self.ops_list = utils.UDA_RANDAUGMENT_OPS_LIST

        self.ops_max_level = utils.RANDAUGMENT_MAX_LEVELS

        if nops > len(self.ops_list):
            raise ValueError(
                f"nops ({nops}) cannot exceed the number of available operations ({len(self.ops_list)})"
            )

    def __call__(self, image: Any) -> Any:
        ops_to_apply = random.sample(self.ops_list, self.nops)
        for op_name in ops_to_apply:
            if random.random() >= self.prob:
                continue

            level = random.randint(1, self.magnitude)
            max_level = self.ops_max_level.get(op_name, self.magnitude)

            aug_func: Callable[..., Any] = getattr(
                augmentation_pool, op_name, None
            )
            if aug_func is None:
                raise AttributeError(
                    f"Augmentation function {op_name} not found in augmentation_pool"
                )

            image = aug_func(image, level, self.magnitude, max_level)

        return image

    def __repr__(self) -> str:
        return f"RandAugment(nops={self.nops}, magnitude={self.magnitude})"