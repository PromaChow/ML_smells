import abc
import random
import collections
import heapq
from collections import namedtuple
from typing import List, Tuple

Transition = namedtuple('Transition', ['state', 'action', 'reward', 'next_state'])

class Memory(abc.ABC):
    @abc.abstractmethod
    def put(self, *args, **kwargs):
        pass

    @abc.abstractmethod
    def get(self, *args, **kwargs):
        pass

    @abc.abstractmethod
    def __len__(self):
        pass

def unpack(traces: List[List[Transition]]) -> Tuple[List, List, List[List[float]], List, List[List[int]]]:
    states = [trace[0].state for trace in traces]
    actions = [trace[0].action for trace in traces]
    rewards = [[t.reward for t in trace] for trace in traces]
    end_states = [trace[-1].next_state for trace in traces]
    not_done_mask = [[1 if t.next_state is not None else 0 for t in trace] for trace in traces]
    return states, actions, rewards, end_states, not_done_mask

class OnPolicy(Memory):
    def __init__(self, instances: int, steps: int):
        self.instances = instances
        self.steps = steps
        self.buffers = [[] for _ in range(instances)]

    def put(self, instance: int, transition: Transition):
        if 0 <= instance < self.instances:
            self.buffers[instance].append(transition)

    def get(self):
        traces = []
        for buf in self.buffers:
            traces.extend([buf[i:i+self.steps] for i in range(len(buf)-self.steps+1)])
        # Clear buffers
        self.buffers = [[] for _ in range(self.instances)]
        return unpack(traces)

    def __len__(self):
        return sum(max(0, len(b) - self.steps + 1) for b in self.buffers)

EPS = 1e-3

class ExperienceReplay(Memory):
    def __init__(self, capacity: int, steps: int, exclude_boundaries: bool = False):
        self.capacity = capacity
        self.steps = steps
        self.exclude_boundaries = exclude_boundaries
        self.traces = collections.deque(maxlen=capacity)
        self.roll_buffer = []

    def put(self, transition: Transition):
        if self.exclude_boundaries and transition.next_state is None:
            self.roll_buffer.clear()
        self.roll_buffer.append(transition)
        if len(self.roll_buffer) == self.steps:
            self.traces.append(list(self.roll_buffer))
            self.roll_buffer.pop(0)

    def get(self, batch_size: int):
        if not self.traces:
            return [], [], [], [], []
        indices = random.sample(range(len(self.traces)), min(batch_size, len(self.traces)))
        selected = [self.traces[i] for i in indices]
        return unpack(selected)

    def __len__(self):
        return len(self.traces)

class PrioritizedExperienceReplay(Memory):
    def __init__(self, capacity: int, steps: int, exclude_boundaries: bool = False, prob_alpha: float = 0.6):
        self.capacity = capacity
        self.steps = steps
        self.exclude_boundaries = exclude_boundaries
        self.prob_alpha = prob_alpha
        self.traces = []
        self.priorities = []
        self.min_heap = []  # (priority, index)
        self.roll_buffer = []
        self.traces_idxs = []

    def put(self, transition: Transition):
        if self.exclude_boundaries and transition.next_state is None:
            self.roll_buffer.clear()
        self.roll_buffer.append(transition)
        if len(self.roll_buffer) == self.steps:
            priority = max(self.priorities, default=EPS)
            if len(self.traces) < self.capacity:
                idx = len(self.traces)
                self.traces.append(list(self.roll_buffer))
                self.priorities.append(priority)
                heapq.heappush(self.min_heap, (priority, idx))
            else:
                # replace lowest priority
                min_pri, min_idx = heapq.heappop(self.min_heap)
                self.traces[min_idx] = list(self.roll_buffer)
                self.priorities[min_idx] = priority
                heapq.heappush(self.min_heap, (priority, min_idx))
            self.roll_buffer.pop(0)

    def get(self, batch_size: int):
        if not self.traces:
            return [], [], [], [], []
        total = sum(p ** self.prob_alpha for p in self.priorities)
        probs = [(p ** self.prob_alpha) / total for p in self.priorities]
        indices = random.choices(range(len(self.traces)), weights=probs, k=min(batch_size, len(self.traces)))
        self.traces_idxs = indices
        selected = [self.traces[i] for i in indices]
        return unpack(selected)

    def update_priorities(self, priorities: List[float]):
        for idx, new_pri in zip(self.traces_idxs, priorities):
            updated = new_pri + EPS
            self.priorities[idx] = updated
            # Rebuild heap to maintain correct ordering
            self.min_heap = [(p, i) for i, p in enumerate(self.priorities)]
            heapq.heapify(self.min_heap)

    def __len__(self):
        return len(self.traces)