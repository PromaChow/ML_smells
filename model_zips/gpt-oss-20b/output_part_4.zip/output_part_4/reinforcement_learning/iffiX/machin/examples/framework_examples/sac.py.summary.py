import gymnasium as gym
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import torch.distributions as dist
from collections import deque
import random

# Hyperbolic arctangent
def atanh(x):
    return 0.5 * torch.log((1 + x) / (1 - x))

# Replay buffer
class ReplayBuffer:
    def __init__(self, capacity=1000000):
        self.buffer = deque(maxlen=capacity)

    def push(self, state, action, reward, next_state, done):
        self.buffer.append((state, action, reward, next_state, done))

    def sample(self, batch_size):
        batch = random.sample(self.buffer, batch_size)
        state, action, reward, next_state, done = map(np.stack, zip(*batch))
        return (
            torch.FloatTensor(state),
            torch.FloatTensor(action),
            torch.FloatTensor(reward).unsqueeze(1),
            torch.FloatTensor(next_state),
            torch.FloatTensor(done).unsqueeze(1),
        )

    def __len__(self):
        return len(self.buffer)

# Actor network
class Actor(nn.Module):
    def __init__(self, state_dim, action_dim, action_limit):
        super().__init__()
        self.action_limit = action_limit
        self.net = nn.Sequential(
            nn.Linear(state_dim, 16),
            nn.ReLU(),
            nn.Linear(16, 16),
            nn.ReLU(),
        )
        self.mu_head = nn.Linear(16, action_dim)
        self.sigma_head = nn.Linear(16, action_dim)
        self.log_sigma_min = -20
        self.log_sigma_max = 2

    def forward(self, state):
        x = self.net(state)
        mu = self.mu_head(x)
        log_sigma = self.sigma_head(x)
        log_sigma = torch.clamp(log_sigma, self.log_sigma_min, self.log_sigma_max)
        sigma = torch.exp(log_sigma)
        return mu, sigma

    def sample(self, state):
        mu, sigma = self.forward(state)
        normal = dist.Normal(mu, sigma)
        z = normal.rsample()
        action = torch.tanh(z)
        log_prob = normal.log_prob(z) - torch.log(1 - action.pow(2) + 1e-6)
        log_prob = log_prob.sum(1, keepdim=True)
        return action, log_prob, mu, sigma

    def deterministic(self, state):
        mu, _ = self.forward(state)
        action = torch.tanh(mu)
        return action

# Critic network
class Critic(nn.Module):
    def __init__(self, state_dim, action_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim + action_dim, 16),
            nn.ReLU(),
            nn.Linear(16, 16),
            nn.ReLU(),
            nn.Linear(16, 1),
        )

    def forward(self, state, action):
        x = torch.cat([state, action], dim=1)
        q = self.net(x)
        return q

# SAC Agent
class SACAgent:
    def __init__(self, state_dim, action_dim, action_limit, lr=3e-4, gamma=0.99, tau=0.005, alpha=0.2):
        self.actor = Actor(state_dim, action_dim, action_limit).to(device)
        self.critic1 = Critic(state_dim, action_dim).to(device)
        self.critic2 = Critic(state_dim, action_dim).to(device)
        self.critic1_target = Critic(state_dim, action_dim).to(device)
        self.critic2_target = Critic(state_dim, action_dim).to(device)
        self.critic1_target.load_state_dict(self.critic1.state_dict())
        self.critic2_target.load_state_dict(self.critic2.state_dict())
        self.actor_optimizer = optim.Adam(self.actor.parameters(), lr=lr)
        self.critic1_optimizer = optim.Adam(self.critic1.parameters(), lr=lr)
        self.critic2_optimizer = optim.Adam(self.critic2.parameters(), lr=lr)
        self.gamma = gamma
        self.tau = tau
        self.alpha = alpha
        self.replay_buffer = ReplayBuffer()
        self.batch_size = 64

    def act(self, state, deterministic=False):
        state = torch.FloatTensor(state).unsqueeze(0).to(device)
        if deterministic:
            action = self.actor.deterministic(state)
        else:
            action, _, _, _ = self.actor.sample(state)
        action = action.cpu().detach().numpy()[0]
        action = np.clip(action, -self.actor.action_limit, self.actor.action_limit)
        return action

    def update(self):
        if len(self.replay_buffer) < self.batch_size:
            return
        state, action, reward, next_state, done = self.replay_buffer.sample(self.batch_size)

        with torch.no_grad():
            next_action, next_log_prob, _, _ = self.actor.sample(next_state)
            target_q1 = self.critic1_target(next_state, next_action)
            target_q2 = self.critic2_target(next_state, next_action)
            target_q = torch.min(target_q1, target_q2)
            target_q = reward + (1 - done) * self.gamma * (target_q - self.alpha * next_log_prob)

        current_q1 = self.critic1(state, action)
        current_q2 = self.critic2(state, action)
        critic1_loss = nn.functional.mse_loss(current_q1, target_q)
        critic2_loss = nn.functional.mse_loss(current_q2, target_q)

        self.critic1_optimizer.zero_grad()
        critic1_loss.backward()
        self.critic1_optimizer.step()

        self.critic2_optimizer.zero_grad()
        critic2_loss.backward()
        self.critic2_optimizer.step()

        # Actor update
        action, log_prob, _, _ = self.actor.sample(state)
        q1_pi = self.critic1(state, action)
        q2_pi = self.critic2(state, action)
        q_pi = torch.min(q1_pi, q2_pi)
        actor_loss = (self.alpha * log_prob - q_pi).mean()

        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        self.actor_optimizer.step()

        # Soft update targets
        for param, target_param in zip(self.critic1.parameters(), self.critic1_target.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)
        for param, target_param in zip(self.critic2.parameters(), self.critic2_target.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)

# Main training loop
if __name__ == "__main__":
    seed = 42
    torch.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    env = gym.make("Pendulum-v0")
    env.action_space.seed(seed)
    state_dim = env.observation_space.shape[0]
    action_dim = env.action_space.shape[0]
    action_limit = env.action_space.high[0]
    max_episodes = 1000
    max_steps = 200
    solve_threshold = -150
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    agent = SACAgent(state_dim, action_dim, action_limit)
    smoothed_reward = 0
    solved_count = 0

    for episode in range(1, max_episodes + 1):
        state, _ = env.reset()
        episode_reward = 0
        for t in range(max_steps):
            action = agent.act(state)
            next_state, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated
            agent.replay_buffer.push(state, action, reward, next_state, done)
            state = next_state
            episode_reward += reward
            if done:
                break
        smoothed_reward = 0.9 * smoothed_reward + 0.1 * episode_reward
        print(f"Episode {episode}\tReward: {episode_reward:.2f}\tSmoothed: {smoothed_reward:.2f}")
        if episode > 100:
            for _ in range(t):
                agent.update()
        if smoothed_reward > solve_threshold:
            solved_count += 1
        else:
            solved_count = 0
        if solved_count >= 5:
            print("Environment solved!")
            break
    env.close()