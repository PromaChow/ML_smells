import random
import numpy as np

class TimeMask:
    def __init__(self, p: float = 0.5, value: float = 0.0, nmasks_range: tuple[int, int] = (1, 5)):
        self.p = p
        self.value = value
        self.nmasks_range = nmasks_range

    def __call__(self, spec: np.ndarray) -> np.ndarray:
        if random.random() >= self.p:
            return spec
        nmasks = random.randint(self.nmasks_range[0], self.nmasks_range[1])
        spec = spec.copy()
        n_t = spec.shape[-1]
        for _ in range(nmasks):
            t = random.randint(0, n_t - 1)
            spec[..., :, t] = self.value
        return spec

class FrequencyMask:
    def __init__(self, p: float = 0.5, value: float = 0.0, nmasks_range: tuple[int, int] = (1, 5)):
        self.p = p
        self.value = value
        self.nmasks_range = nmasks_range

    def __call__(self, spec: np.ndarray) -> np.ndarray:
        if random.random() >= self.p:
            return spec
        nmasks = random.randint(self.nmasks_range[0], self.nmasks_range[1])
        spec = spec.copy()
        n_f = spec.shape[-2]
        for _ in range(nmasks):
            f = random.randint(0, n_f - 1)
            spec[..., f, :] = self.value
        return spec
