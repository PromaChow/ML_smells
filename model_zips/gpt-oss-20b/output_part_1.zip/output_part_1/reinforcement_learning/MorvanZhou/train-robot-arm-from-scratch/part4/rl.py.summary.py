import numpy as np
import tensorflow as tf
import os

# Hyperparameters
LR_A = 0.001
LR_C = 0.001
GAMMA = 0.9
TAU = 0.01
MEMORY_CAPACITY = 10000
BATCH_SIZE = 32


class DDPG(object):
    def __init__(self, state_dim, action_dim, a_bound, sess):
        self.sess = sess
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.a_bound = a_bound

        # Memory
        self.memory = np.zeros((MEMORY_CAPACITY,
                                2 * state_dim + action_dim + 1))
        self.pointer = 0
        self.memory_full = False

        # Placeholders
        self.S = tf.placeholder(tf.float32, [None, state_dim], 'state')
        self.S_ = tf.placeholder(tf.float32, [None, state_dim], 'next_state')
        self.R = tf.placeholder(tf.float32, [None, 1], 'reward')
        self.A = tf.placeholder(tf.float32, [None, action_dim], 'action')

        # Networks
        self.a_eval = self._build_a(self.S, 'actor_eval', True)
        self.q_eval = self._build_c(self.S, self.A, 'critic_eval', True)

        self.a_target = self._build_a(self.S_, 'actor_target', False)
        self.q_target_next = self._build_c(self.S_, self.a_target,
                                           'critic_target', False)

        # Target Q
        self.q_target = self.R + GAMMA * self.q_target_next

        # Losses and Optimizers
        self.c_loss = tf.reduce_mean(tf.square(self.q_target - self.q_eval))
        self.ctrain_op = tf.train.AdamOptimizer(LR_C).minimize(
            self.c_loss, var_list=self._get_vars('critic_eval'))

        self.a_loss = -tf.reduce_mean(self.q_eval)
        self.atrain_op = tf.train.AdamOptimizer(LR_A).minimize(
            self.a_loss, var_list=self._get_vars('actor_eval'))

        # Soft replacement
        self.soft_replace = self._soft_replace_op()

        # Saver
        self.saver = tf.train.Saver(max_to_keep=5)

    def _build_a(self, s, scope, trainable):
        with tf.variable_scope(scope, reuse=not trainable):
            hidden = tf.layers.dense(s, 100, activation=tf.nn.relu,
                                     name='hidden', trainable=trainable)
            out = tf.layers.dense(hidden, self.action_dim,
                                  activation=tf.tanh, name='out',
                                  trainable=trainable)
            return out * self.a_bound

    def _build_c(self, s, a, scope, trainable):
        with tf.variable_scope(scope, reuse=not trainable):
            concat = tf.concat([s, a], axis=1, name='concat')
            hidden = tf.layers.dense(concat, 100, activation=tf.nn.relu,
                                     name='hidden', trainable=trainable)
            out = tf.layers.dense(hidden, 1, activation=None,
                                  name='out', trainable=trainable)
            return tf.squeeze(out, axis=1)

    def _get_vars(self, name):
        return tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES,
                                 scope=name)

    def _soft_replace_op(self):
        replace_ops = []
        eval_vars = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES)
        target_vars = [v for v in tf.global_variables()
                       if 'actor_target' in v.name or 'critic_target' in v.name]
        for ev, tv in zip(eval_vars, target_vars):
            replace_ops.append(tv.assign(tv * (1 - TAU) + ev * TAU))
        return replace_ops

    def store_transition(self, s, a, r, s_):
        transition = np.hstack((s, a, [r], s_))
        index = self.pointer % MEMORY_CAPACITY
        self.memory[index, :] = transition
        self.pointer += 1
        if self.pointer >= MEMORY_CAPACITY:
            self.memory_full = True

    def choose_action(self, s):
        return self.sess.run(self.a_eval,
                             feed_dict={self.S: s.reshape(1, -1)})

    def learn(self):
        if self.memory_full:
            num = MEMORY_CAPACITY
        else:
            if self.pointer < BATCH_SIZE:
                return
            num = self.pointer

        indices = np.random.choice(num, BATCH_SIZE, replace=False)
        batch = self.memory[indices, :]

        s_batch = batch[:, :self.state_dim]
        a_batch = batch[:, self.state_dim:self.state_dim + self.action_dim]
        r_batch = batch[:, self.state_dim + self.action_dim].reshape(-1, 1)
        s__batch = batch[:, self.state_dim + self.action_dim + 1:]

        self.sess.run(self.soft_replace)

        self.sess.run(self.atrain_op, feed_dict={self.S: s_batch})
        self.sess.run(self.ctrain_op,
                      feed_dict={self.S: s_batch,
                                 self.A: a_batch,
                                 self.R: r_batch,
                                 self.S_: s__batch})

    def save(self, path):
        if not os.path.exists(path):
            os.makedirs(path)
        self.saver.save(self.sess, os.path.join(path, 'ddpg_model.ckpt'))

    def restore(self, path):
        self.saver.restore(self.sess, os.path.join(path, 'ddpg_model.ckpt'))