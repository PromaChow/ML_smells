import math
import numpy as np
from gymnasium.envs.mujoco import MJCFBasedRobot


class Reacher(MJCFBasedRobot):
    TARG_LIMIT = 0.27

    def __init__(self):
        super().__init__(
            mjcf_path="reacher.xml",
            root_body_name="body0",
            action_dim=2,
            observation_dim=9,
        )

    def robot_specific_reset(self):
        target_pos = self.np_random.uniform(
            low=-self.TARG_LIMIT, high=self.TARG_LIMIT, size=2
        )
        self.fingertip = self.body.fingertip
        self.target = self.body.target
        self.joint0 = self.body.joint0
        self.joint1 = self.body.joint1
        self.target.set_joint_position([target_pos[0], target_pos[1], 0.0])
        self.joint0.reset_current_position(
            self.np_random.uniform(low=-math.pi, high=math.pi)
        )
        self.joint1.reset_current_position(
            self.np_random.uniform(low=-math.pi, high=math.pi)
        )

    def apply_action(self, a):
        a_clipped = np.clip(a, -1.0, 1.0)
        torques = a_clipped * 0.05
        self.joint0.set_motor_torque(torques[0])
        self.joint1.set_motor_torque(torques[1])

    def calc_state(self):
        theta = self.joint0.angle
        theta_dot = self.joint0.angular_velocity
        gamma = self.joint1.angle
        gamma_dot = self.joint1.angular_velocity

        target_pos = self.target.get_joint_position()
        fingertip_pos = self.fingertip.get_joint_position()
        to_target_vec = np.array(target_pos[:3]) - np.array(fingertip_pos[:3])

        state = np.concatenate(
            [
                np.array([target_pos[0], target_pos[1]]),
                to_target_vec,
                np.array([theta, gamma, theta_dot, gamma_dot]),
            ]
        )
        return state

    def calc_potential(self):
        target_pos = self.target.get_joint_position()
        fingertip_pos = self.fingertip.get_joint_position()
        to_target_vec = np.array(target_pos[:3]) - np.array(fingertip_pos[:3])
        return -100.0 * np.linalg.norm(to_target_vec)