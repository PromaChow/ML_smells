import itertools
from dataclasses import dataclass
from typing import List, Tuple


@dataclass(frozen=True)
class Operation:
    name: str
    prob: float
    mag: int


def get_trans_list() -> List[str]:
    """Return a list of 15 possible transformation names."""
    return [
        "Invert",
        "Cutout",
        "AutoContrast",
        "Equalize",
        "Posterize",
        "Solarize",
        "Contrast",
        "Brightness",
        "Sharpness",
        "ShearX",
        "ShearY",
        "TranslateX",
        "TranslateY",
        "Rotate",
        "Color",
    ]


# Predefined ImageNet policies (20 policies, each with two operations)
PREDEFINED_POLICIES: List[Tuple[Operation, Operation]] = [
    (
        Operation("ShearX", 0.4, 9),
        Operation("Rotate", 0.4, 5),
    ),
    (
        Operation("Color", 0.4, 9),
        Operation("Sharpness", 0.4, 5),
    ),
    (
        Operation("ShearY", 0.4, 9),
        Operation("Solarize", 0.4, 5),
    ),
    (
        Operation("Color", 0.4, 9),
        Operation("Contrast", 0.4, 5),
    ),
    (
        Operation("ShearX", 0.4, 9),
        Operation("Cutout", 0.4, 5),
    ),
    (
        Operation("ShearX", 0.4, 9),
        Operation("Solarize", 0.4, 5),
    ),
    (
        Operation("Contrast", 0.4, 9),
        Operation("Solarize", 0.4, 5),
    ),
    (
        Operation("Contrast", 0.4, 9),
        Operation("ShearY", 0.4, 5),
    ),
    (
        Operation("Sharpness", 0.4, 9),
        Operation("Rotate", 0.4, 5),
    ),
    (
        Operation("Color", 0.4, 9),
        Operation("ShearX", 0.4, 5),
    ),
    (
        Operation("Sharpness", 0.4, 9),
        Operation("ShearY", 0.4, 5),
    ),
    (
        Operation("Rotate", 0.4, 9),
        Operation("Sharpness", 0.4, 5),
    ),
    (
        Operation("Contrast", 0.4, 9),
        Operation("Cutout", 0.4, 5),
    ),
    (
        Operation("Solarize", 0.4, 9),
        Operation("ShearX", 0.4, 5),
    ),
    (
        Operation("Rotate", 0.4, 9),
        Operation("ShearX", 0.4, 5),
    ),
    (
        Operation("ShearY", 0.4, 9),
        Operation("Cutout", 0.4, 5),
    ),
    (
        Operation("Rotate", 0.4, 9),
        Operation("Contrast", 0.4, 5),
    ),
    (
        Operation("Cutout", 0.4, 9),
        Operation("Solarize", 0.4, 5),
    ),
    (
        Operation("Cutout", 0.4, 9),
        Operation("Color", 0.4, 5),
    ),
    (
        Operation("Color", 0.4, 9),
        Operation("Rotate", 0.4, 5),
    ),
]


def randaug_policies() -> List[Tuple[Operation, Operation]]:
    """
    Generate all possible pairs of RandAugment operations.
    Each base transformation is paired with magnitudes 1–9 and a fixed probability of 0.5.
    """
    trans_list = get_trans_list()
    # Create operations with magnitudes 1–9 and prob 0.5
    ops: List[Operation] = [
        Operation(name, 0.5, mag) for name in trans_list for mag in range(1, 10)
    ]
    # Generate all ordered pairs (including duplicates)
    policies: List[Tuple[Operation, Operation]] = list(itertools.product(ops, ops))
    return policies
