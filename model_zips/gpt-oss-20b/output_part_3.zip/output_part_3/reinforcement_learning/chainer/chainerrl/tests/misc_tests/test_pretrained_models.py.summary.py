import os
import gym
import torch
import pytest
from chainerrl import q_functions, policy, value_functions, agents, exploration, replay_buffer, utils

# Helper to download and load pretrained model
def _download_and_load(agent, env_name, agent_type, model_type, device):
    model_path = utils.download_model(env_name, agent_type, model_type)
    agent.load(model_path)
    if os.getenv("CHAINERRL_ASSERT_DOWNLOADED_MODEL_IS_CACHED"):
        assert os.path.exists(model_path)
    agent.to(device)
    return agent

# Build networks for different agents
def _build_dqn_network(env, device):
    q_func = q_functions.MLPQFunction(
        nin=env.observation_space.shape[0],
        nout=env.action_space.n,
        hidden_sizes=[256, 256],
        activations=[torch.relu, torch.relu],
    ).to(device)
    optimizer = torch.optim.RMSprop(
        q_func.parameters(),
        lr=1e-4,
        alpha=0.95,
        eps=1e-10,
    )
    return q_func, optimizer

def _build_iqn_network(env, device):
    q_func = q_functions.MLPIQNQFunction(
        nin=env.observation_space.shape[0],
        nout=env.action_space.n,
        hidden_sizes=[256, 256],
        activations=[torch.relu, torch.relu],
        num_quantiles=32,
    ).to(device)
    optimizer = torch.optim.RMSprop(
        q_func.parameters(),
        lr=1e-4,
        alpha=0.95,
        eps=1e-10,
    )
    return q_func, optimizer

def _build_rainbow_network(env, device):
    q_func = q_functions.DuelingQFunction(
        nin=env.observation_space.shape[0],
        nout=env.action_space.n,
        hidden_sizes=[256, 256],
        activations=[torch.relu, torch.relu],
    ).to(device)
    optimizer = torch.optim.RMSprop(
        q_func.parameters(),
        lr=1e-4,
        alpha=0.95,
        eps=1e-10,
    )
    return q_func, optimizer

def _build_a3c_network(env, device):
    pi = policy.MLPPolicy(
        nin=env.observation_space.shape[0],
        nout=env.action_space.n,
        hidden_sizes=[256, 256],
        activations=[torch.relu, torch.relu],
    ).to(device)
    vf = value_functions.MLPValueFunction(
        nin=env.observation_space.shape[0],
        hidden_sizes=[256, 256],
        activations=[torch.relu, torch.relu],
    ).to(device)
    return pi, vf

def _build_ddpg_network(env, device):
    actor = policy.MLPPolicy(
        nin=env.observation_space.shape[0],
        nout=env.action_space.shape[0],
        hidden_sizes=[256, 256],
        activations=[torch.relu, torch.relu],
        output_distribution=policy.NormalDistribution,
    ).to(device)
    critic = q_functions.MLPQFunction(
        nin=env.observation_space.shape[0] + env.action_space.shape[0],
        nout=1,
        hidden_sizes=[256, 256],
        activations=[torch.relu, torch.relu],
    ).to(device)
    actor_opt = torch.optim.Adam(actor.parameters(), lr=1e-4)
    critic_opt = torch.optim.Adam(critic.parameters(), lr=1e-4)
    return actor, critic, actor_opt, critic_opt

def _build_trpo_network(env, device):
    pi = policy.MLPPolicy(
        nin=env.observation_space.shape[0],
        nout=env.action_space.n,
        hidden_sizes=[256, 256],
        activations=[torch.relu, torch.relu],
    ).to(device)
    vf = value_functions.MLPValueFunction(
        nin=env.observation_space.shape[0],
        hidden_sizes=[256, 256],
        activations=[torch.relu, torch.relu],
    ).to(device)
    return pi, vf

def _build_ppo_network(env, device):
    pi = policy.MLPPolicy(
        nin=env.observation_space.shape[0],
        nout=env.action_space.n,
        hidden_sizes=[256, 256],
        activations=[torch.relu, torch.relu],
    ).to(device)
    vf = value_functions.MLPValueFunction(
        nin=env.observation_space.shape[0],
        hidden_sizes=[256, 256],
        activations=[torch.relu, torch.relu],
    ).to(device)
    return pi, vf

def _build_td3_network(env, device):
    actor = policy.MLPPolicy(
        nin=env.observation_space.shape[0],
        nout=env.action_space.shape[0],
        hidden_sizes=[256, 256],
        activations=[torch.relu, torch.relu],
        output_distribution=policy.NormalDistribution,
    ).to(device)
    critic = q_functions.MLPQFunction(
        nin=env.observation_space.shape[0] + env.action_space.shape[0],
        nout=1,
        hidden_sizes=[256, 256],
        activations=[torch.relu, torch.relu],
    ).to(device)
    actor_opt = torch.optim.Adam(actor.parameters(), lr=1e-4)
    critic_opt = torch.optim.Adam(critic.parameters(), lr=1e-4)
    return actor, critic, actor_opt, critic_opt

def _build_sac_network(env, device):
    actor = policy.MLPPolicy(
        nin=env.observation_space.shape[0],
        nout=env.action_space.shape[0],
        hidden_sizes=[256, 256],
        activations=[torch.relu, torch.relu],
        output_distribution=policy.NormalDistribution,
    ).to(device)
    critic1 = q_functions.MLPQFunction(
        nin=env.observation_space.shape[0] + env.action_space.shape[0],
        nout=1,
        hidden_sizes=[256, 256],
        activations=[torch.relu, torch.relu],
    ).to(device)
    critic2 = q_functions.MLPQFunction(
        nin=env.observation_space.shape[0] + env.action_space.shape[0],
        nout=1,
        hidden_sizes=[256, 256],
        activations=[torch.relu, torch.relu],
    ).to(device)
    actor_opt = torch.optim.Adam(actor.parameters(), lr=3e-4)
    critic1_opt = torch.optim.Adam(critic1.parameters(), lr=3e-4)
    critic2_opt = torch.optim.Adam(critic2.parameters(), lr=3e-4)
    return actor, critic1, critic2, actor_opt, critic1_opt, critic2_opt

# Test helpers
def _run_agent_test(
    env_name,
    agent_type,
    model_type,
    build_fn,
    agent_cls,
    device,
    **agent_kwargs,
):
    env = gym.make(env_name)
    networks = build_fn(env, device)
    replay = replay_buffer.ReplayBuffer(capacity=1000000, seed=0)
    if isinstance(networks, tuple) and len(networks) > 2:
        # For agents with multiple networks
        network_args = networks[:-2]
        optimizers = networks[-2:]
    else:
        network_args = networks
        optimizers = None
    agent = agent_cls(*network_args, replay_buffer=replay, exploration=exploration.ConstantEpsilonGreedy(0.1), gamma=0.99, target_update_interval=100, **agent_kwargs)
    if optimizers:
        # Set optimizers if agent expects them
        if hasattr(agent, "actor_optimizer"):
            agent.actor_optimizer = optimizers[0]
        if hasattr(agent, "critic_optimizer"):
            agent.critic_optimizer = optimizers[1]
    _download_and_load(agent, env_name, agent_type, model_type, device)
    env.close()

# Test cases
@pytest.mark.parametrize("device", [torch.device("cpu")])
def test_dqn_cpu(device):
    _run_agent_test(
        env_name="BreakoutNoFrameskip-v4",
        agent_type="dqn",
        model_type="best",
        build_fn=_build_dqn_network,
        agent_cls=agents.DQN,
        device=device,
        batch_size=32,
    )

@pytest.mark.parametrize("device", [torch.device("cuda:0")], ids=["GPU"])
def test_dqn_gpu(device):
    pytest.importorskip("torch", reason="GPU tests require torch with CUDA")
    if not torch.cuda.is_available():
        pytest.skip("CUDA not available")
    _run_agent_test(
        env_name="BreakoutNoFrameskip-v4",
        agent_type="dqn",
        model_type="best",
        build_fn=_build_dqn_network,
        agent_cls=agents.DQN,
        device=device,
        batch_size=32,
    )

@pytest.mark.parametrize("device", [torch.device("cpu")])
def test_iqn_cpu(device):
    _run_agent_test(
        env_name="BreakoutNoFrameskip-v4",
        agent_type="iqn",
        model_type="best",
        build_fn=_build_iqn_network,
        agent_cls=agents.IQN,
        device=device,
        batch_size=32,
    )

@pytest.mark.parametrize("device", [torch.device("cuda:0")], ids=["GPU"])
def test_iqn_gpu(device):
    pytest.importorskip("torch", reason="GPU tests require torch with CUDA")
    if not torch.cuda.is_available():
        pytest.skip("CUDA not available")
    _run_agent_test(
        env_name="BreakoutNoFrameskip-v4",
        agent_type="iqn",
        model_type="best",
        build_fn=_build_iqn_network,
        agent_cls=agents.IQN,
        device=device,
        batch_size=32,
    )

@pytest.mark.parametrize("device", [torch.device("cpu")])
def test_rainbow_cpu(device):
    _run_agent_test(
        env_name="BreakoutNoFrameskip-v4",
        agent_type="rainbow",
        model_type="best",
        build_fn=_build_rainbow_network,
        agent_cls=agents.Rainbow,
        device=device,
        batch_size=32,
    )

@pytest.mark.parametrize("device", [torch.device("cuda:0")], ids=["GPU"])
def test_rainbow_gpu(device):
    pytest.importorskip("torch", reason="GPU tests require torch with CUDA")
    if not torch.cuda.is_available():
        pytest.skip("CUDA not available")
    _run_agent_test(
        env_name="BreakoutNoFrameskip-v4",
        agent_type="rainbow",
        model_type="best",
        build_fn=_build_rainbow_network,
        agent_cls=agents.Rainbow,
        device=device,
        batch_size=32,
    )

@pytest.mark.parametrize("device", [torch.device("cpu")])
def test_a3c_cpu(device):
    _run_agent_test(
        env_name="BreakoutNoFrameskip-v4",
        agent_type="a3c",
        model_type="final",
        build_fn=_build_a3c_network,
        agent_cls=agents.A3C,
        device=device,
        batch_size=32,
    )

@pytest.mark.parametrize("device", [torch.device("cuda:0")], ids=["GPU"])
def test_a3c_gpu(device):
    pytest.importorskip("torch", reason="GPU tests require torch with CUDA")
    if not torch.cuda.is_available():
        pytest.skip("CUDA not available")
    _run_agent_test(
        env_name="BreakoutNoFrameskip-v4",
        agent_type="a3c",
        model_type="final",
        build_fn=_build_a3c_network,
        agent_cls=agents.A3C,
        device=device,
        batch_size=32,
    )

@pytest.mark.parametrize("device", [torch.device("cpu")])
def test_ddpg_cpu(device):
    _run_agent_test(
        env_name="Hopper-v2",
        agent_type="ddpg",
        model_type="best",
        build_fn=_build_ddpg_network,
        agent_cls=agents.DDPG,
        device=device,
        batch_size=32,
    )

@pytest.mark.parametrize("device", [torch.device("cuda:0")], ids=["GPU"])
def test_ddpg_gpu(device):
    pytest.importorskip("torch", reason="GPU tests require torch with CUDA")
    if not torch.cuda.is_available():
        pytest.skip("CUDA not available")
    _run_agent_test(
        env_name="Hopper-v2",
        agent_type="ddpg",
        model_type="best",
        build_fn=_build_ddpg_network,
        agent_cls=agents.DDPG,
        device=device,
        batch_size=32,
    )

@pytest.mark.parametrize("device", [torch.device("cpu")])
def test_trpo_cpu(device):
    _run_agent_test(
        env_name="Hopper-v2",
        agent_type="trpo",
        model_type="best",
        build_fn=_build_trpo_network,
        agent_cls=agents.Trpo,
        device=device,
        batch_size=32,
    )

@pytest.mark.parametrize("device", [torch.device("cuda:0")], ids=["GPU"])
def test_trpo_gpu(device):
    pytest.importorskip("torch", reason="GPU tests require torch with CUDA")
    if not torch.cuda.is_available():
        pytest.skip("CUDA not available")
    _run_agent_test(
        env_name="Hopper-v2",
        agent_type="trpo",
        model_type="best",
        build_fn=_build_trpo_network,
        agent_cls=agents.Trpo,
        device=device,
        batch_size=32,
    )

@pytest.mark.parametrize("device", [torch.device("cpu")])
def test_ppo_cpu(device):
    _run_agent_test(
        env_name="Hopper-v2",
        agent_type="ppo",
        model_type="best",
        build_fn=_build_ppo_network,
        agent_cls=agents.PPO,
        device=device,
        batch_size=32,
    )

@pytest.mark.parametrize("device", [torch.device("cuda:0")], ids=["GPU"])
def test_ppo_gpu(device):
    pytest.importorskip("torch", reason="GPU tests require torch with CUDA")
    if not torch.cuda.is_available():
        pytest.skip("CUDA not available")
    _run_agent_test(
        env_name="Hopper-v2",
        agent_type="ppo",
        model_type="best",
        build_fn=_build_ppo_network,
        agent_cls=agents.PPO,
        device=device,
        batch_size=32,
    )

@pytest.mark.parametrize("device", [torch.device("cpu")])
def test_td3_cpu(device):
    _run_agent_test(
        env_name="Hopper-v2",
        agent_type="td3",
        model_type="best",
        build_fn=_build_td3_network,
        agent_cls=agents.TD3,
        device=device,
        batch_size=32,
    )

@pytest.mark.parametrize("device", [torch.device("cuda:0")], ids=["GPU"])
def test_td3_gpu(device):
    pytest.importorskip("torch", reason="GPU tests require torch with CUDA")
    if not torch.cuda.is_available():
        pytest.skip("CUDA not available")
    _run_agent_test(
        env_name="Hopper-v2",
        agent_type="td3",
        model_type="best",
        build_fn=_build_td3_network,
        agent_cls=agents.TD3,
        device=device,
        batch_size=32,
    )

@pytest.mark.parametrize("device", [torch.device("cpu")])
def test_sac_cpu(device):
    _run_agent_test(
        env_name="Hopper-v2",
        agent_type="sac",
        model_type="best",
        build_fn=_build_sac_network,
        agent_cls=agents.SAC,
        device=device,
        batch_size=32,
    )

@pytest.mark.parametrize("device", [torch.device("cuda:0")], ids=["GPU"])
def test_sac_gpu(device):
    pytest.importorskip("torch", reason="GPU tests require torch with CUDA")
    if not torch.cuda.is_available():
        pytest.skip("CUDA not available")
    _run_agent_test(
        env_name="Hopper-v2",
        agent_type="sac",
        model_type="best",
        build_fn=_build_sac_network,
        agent_cls=agents.SAC,
        device=device,
        batch_size=32,
    )