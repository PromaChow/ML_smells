import numpy as np
import scipy.sparse as sp
import scipy.optimize as opt
import warnings
import logging
from sklearn.datasets import make_moons, make_circles, make_blobs
from sklearn.metrics import accuracy_score
from time import time

warnings.filterwarnings("ignore", category=UserWarning)
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s:%(message)s")

# --------------------------- Kernel Utilities ---------------------------

def linear_kernel(X, Y=None):
    if Y is None:
        Y = X
    return X @ Y.T

def rbf_kernel(X, Y=None, sigma=1.0):
    if Y is None:
        Y = X
    if sp.issparse(X) or sp.issparse(Y):
        diff = sp.csr_matrix(X) - sp.csr_matrix(Y.T)
        sq_dists = np.array(diff.power(2).sum(axis=1)).ravel()
    else:
        sq_dists = np.sum((X[:, None, :] - Y[None, :, :]) ** 2, axis=2)
    return np.exp(-sq_dists / (2 * sigma ** 2))

# --------------------------- Base Class ---------------------------

class S3VMBase:
    def __init__(self, lam=1.0, lamU=0.5, kernel="rbf", sigma=1.0,
                 surrogate_gamma=1.0, numR=None, BFGS_m=10,
                 BFGS_maxfun=150, BFGS_factr=10**-9, BFGS_pgtol=10**-5):
        self.lam = lam
        self.lamU = lamU
        self.kernel = kernel
        self.sigma = sigma
        self.surrogate_gamma = surrogate_gamma
        self.numR = numR
        self.BFGS_m = BFGS_m
        self.BFGS_maxfun = BFGS_maxfun
        self.BFGS_factr = BFGS_factr
        self.BFGS_pgtol = BFGS_pgtol
        self.c = None
        self.b = 0.0
        self.K_lr = None
        self.K_lu = None
        self.K_rr = None
        self.mean_u = None
        self.regr_indices = None

    def _kernel_func(self, X, Y=None):
        if self.kernel == "linear":
            return linear_kernel(X, Y)
        else:
            return rbf_kernel(X, Y, sigma=self.sigma)

    def _center_data(self, X, is_unlabeled=False):
        if is_unlabeled:
            self.mean_u = X.mean(axis=0)
            return X - self.mean_u
        else:
            return X

    def _initialize_regr(self, X):
        n = X.shape[0]
        if self.numR is None or self.numR >= n:
            self.regr_indices = np.arange(n)
        else:
            rng = np.random.default_rng()
            self.regr_indices = rng.choice(n, self.numR, replace=False)

    def _compute_kernels(self, Xl, Xu):
        # Center
        Xl_c = self._center_data(Xl, is_unlabeled=False)
        Xu_c = self._center_data(Xu, is_unlabeled=True)

        # Kernels
        self.K_lr = self._kernel_func(Xl_c, Xu_c[self.regr_indices])
        self.K_lu = self._kernel_func(Xl_c, Xu_c)
        self.K_rr = self._kernel_func(Xu_c[self.regr_indices], Xu_c[self.regr_indices])

    def _surrogate_loss(self, y, f):
        # y in {-1,1}
        t = -self.surrogate_gamma * y * f
        # use stable log1p(exp(t))
        return np.log1p(np.exp(t))

    def _surrogate_loss_grad(self, y, f):
        t = -self.surrogate_gamma * y * f
        return -self.surrogate_gamma * y * (np.exp(t) / (1 + np.exp(t)))

    def _fitness_and_grad(self, params, Xl, y, Xu):
        c = params[:-1]
        b = params[-1]
        # Labeled loss
        f_l = self.K_lr @ c + b
        loss_l = self._surrogate_loss(y, f_l)
        grad_l = self.K_lr.T @ self._surrogate_loss_grad(y, f_l)

        # Unlabeled penalty: enforce mean of predictions to be close to zero
        f_u = self.K_lu @ c + b
        mean_f_u = f_u.mean()
        loss_u = 0.5 * self.lamU * mean_f_u ** 2
        grad_u = self.lamU * mean_f_u * np.ones_like(c)

        # Regularization
        loss_reg = 0.5 * self.lam * np.sum(c ** 2)
        grad_reg = self.lam * c

        loss = np.sum(loss_l) + loss_u + loss_reg
        grad = grad_l + grad_u + grad_reg
        grad = np.concatenate([grad, np.array([0.0])])  # bias gradient zero
        return loss, grad

    def fit(self, Xl, y, Xu):
        Xl = np.asarray(Xl)
        Xu = np.asarray(Xu)
        y = np.asarray(y)
        if Xl.shape[0] != y.shape[0]:
            raise ValueError("Number of labeled samples and labels must match.")
        self._initialize_regr(Xu)
        self._compute_kernels(Xl, Xu)
        n_reg = self.K_rr.shape[0]
        init_params = np.zeros(n_reg + 1)  # coeffs + bias
        lam_Uvec = np.geomspace(1e-3, self.lamU, num=5)
        for lamU_val in lam_Uvec:
            self.lamU = lamU_val
            result = opt.fmin_l_bfgs_b(
                func=lambda p: self._fitness_and_grad(p, Xl, y, Xu),
                x0=init_params,
                maxfun=self.BFGS_maxfun,
                factr=self.BFGS_factr,
                pgtol=self.BFGS_pgtol,
                m=self.BFGS_m,
                disp=False
            )
            init_params = result[0]
        self.c = init_params[:-1]
        self.b = init_params[-1]
        return self

    def predict(self, X):
        X = np.asarray(X)
        X_c = X - self.mean_u if self.mean_u is not None else X
        K_test = self._kernel_func(X_c, self._center_data(self._get_regr(), is_unlabeled=True))
        scores = K_test @ self.c + self.b
        return np.sign(scores)

    def _get_regr(self):
        return self._center_data(self._regr_data, is_unlabeled=True)

# --------------------------- Dense Subclass ---------------------------

class QN_S3VM_Dense(S3VMBase):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def fit(self, Xl, y, Xu):
        self._regr_data = Xu[self.regr_indices]
        return super().fit(Xl, y, Xu)

# --------------------------- Sparse Subclass ---------------------------

class QN_S3VM_Sparse(S3VMBase):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def _kernel_func(self, X, Y=None):
        if self.kernel == "linear":
            return X @ Y.T if Y is not None else X @ X.T
        else:
            if sp.issparse(X) and sp.issparse(Y):
                return rbf_kernel(X, Y, sigma=self.sigma)
            else:
                return super()._kernel_func(X, Y)

    def fit(self, Xl, y, Xu):
        Xl = sp.csr_matrix(Xl)
        Xu = sp.csr_matrix(Xu)
        self._regr_data = Xu[self.regr_indices]
        return super().fit(Xl, y, Xu)

# --------------------------- Example Usage ---------------------------

def generate_synthetic(n_labeled=200, n_unlabeled=800, seed=0):
    rng = np.random.default_rng(seed)
    X, y = make_moons(n_samples=n_labeled + n_unlabeled, noise=0.3, random_state=seed)
    y = np.where(y == 0, -1, 1)
    idx = rng.permutation(len(X))
    Xl = X[idx[:n_labeled]]
    yl = y[idx[:n_labeled]]
    Xu = X[idx[n_labeled:]]
    return Xl, yl, Xu

def evaluate(model, Xl, yl, Xu):
    pred_unlabeled = model.predict(Xu)
    # Since true labels unknown, we only report training accuracy
    pred_labeled = model.predict(Xl)
    acc = accuracy_score(yl, pred_labeled)
    return acc

if __name__ == "__main__":
    Xl, yl, Xu = generate_synthetic()
    model = QN_S3VM_Dense(lam=1.0, lamU=0.5, kernel="rbf", sigma=1.0,
                          surrogate_gamma=1.0, numR=100)
    start = time()
    model.fit(Xl, yl, Xu)
    elapsed = time() - start
    acc = evaluate(model, Xl, yl, Xu)
    print(f"Training accuracy: {acc:.4f}")
    print(f"Training time: {elapsed:.2f}s")
    # Predict on new data
    X_test, y_test = make_moons(n_samples=200, noise=0.3, random_state=42)
    y_test = np.where(y_test == 0, -1, 1)
    preds = model.predict(X_test)
    print(f"Test accuracy: {accuracy_score(y_test, preds):.4f}")