import os
import re
import datetime
import torch

class Archive:
    def __init__(self, path: str | None = None, find_in: str | None = None, match: str | None = None):
        if path is not None:
            self.path = path
        elif find_in is not None and match is not None:
            regex = re.compile(match)
            for entry in os.listdir(find_in):
                if regex.search(entry):
                    self.path = os.path.join(find_in, entry)
                    break
            else:
                raise ValueError(f"No file matching '{match}' found in '{find_in}'.")
        else:
            raise ValueError("Must provide either 'path' or both 'find_in' and 'match'.")
        self.data: dict = {}

    def add_item(self, key, value):
        self.data[key] = value
        return self

    def save(self):
        torch.save(self.data, self.path, pickle_protocol=3)

    def load(self):
        self.data = torch.load(self.path)

    def item(self, key):
        return self.data[key]

def get_time_string() -> str:
    return datetime.datetime.now().strftime("%Y_%m_%d_%H_%M_%S")