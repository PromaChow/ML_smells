import pickle
import yaml
import numpy as np
import torch
import time
import multiprocessing
from lagom import (
    color_str,
    IntervalConditioner,
    NConditioner,
    Seeder,
    tensorify,
    numpify,
    pickle_dump,
    pickle_load,
    yaml_dump,
    yaml_load,
    timed,
)

def test_color_str():
    green_bold = color_str("test", color="green", bold=True)
    white_normal = color_str("test", color="white", bold=False)
    # ANSI escape sequences
    assert "\033[1;32m" in green_bold
    assert "\033[0m" in green_bold
    assert "\033[0;37m" in white_normal
    assert "\033[0m" in white_normal

def test_conditioner():
    # IntervalConditioner accumulative mode
    ic_acc = IntervalConditioner(n=4, mode="accumulative")
    outputs = []
    for step in range(9):
        outputs.append(ic_acc(step))
    expected = [0, 0, 0, 0, 1, 1, 1, 1, 2]
    assert outputs == expected

    # IntervalConditioner incremental mode
    ic_inc = IntervalConditioner(n=3, mode="incremental")
    counter = 0
    total = 0
    for step in range(7):
        counter, total = ic_inc(step)
        assert total == step + 1
    # After 7 steps, counter should have incremented twice (at steps 2 and 5)
    assert counter == 2

    # NConditioner accumulative mode
    n_acc = NConditioner(n=10, mode="accumulative")
    out_acc = [n_acc(i) for i in range(30)]
    # Should increment every 10 steps
    assert out_acc[:10] == [0]*10
    assert out_acc[10:20] == [1]*10
    assert out_acc[20:30] == [2]*10

    # NConditioner incremental mode
    n_inc = NConditioner(n=5, mode="incremental")
    counter_inc = 0
    total_n_inc = 0
    for i in range(12):
        counter_inc, total_n_inc = n_inc(i)
        assert total_n_inc == i + 1
    # Should have incremented twice (at i=4 and i=9)
    assert counter_inc == 2

def test_seeder():
    seed = 0
    seeder = Seeder(seed)
    single = seeder(1)
    batch1 = seeder(5)
    batch2 = seeder([1, 3])
    batch3 = seeder([2, 3])
    assert single.shape == (1,)
    assert batch1.shape == (5,)
    assert batch2.shape == (1, 3)
    assert batch3.shape == (2, 3)
    assert len(single) == 1
    assert len(batch1) == 5
    assert len(batch2) == 3
    assert len(batch3) == 6

def test_tensorify():
    np_arr = np.array([1, 2, 3])
    lst = [1, 2, 3]
    tup = (1, 2, 3)
    scalar = 5
    torch_tensor = torch.tensor([1, 2, 3])
    out_np = tensorify(np_arr)
    out_lst = tensorify(lst)
    out_tup = tensorify(tup)
    out_scalar = tensorify(scalar)
    out_torch = tensorify(torch_tensor)
    assert torch.equal(out_np, torch.tensor([1, 2, 3]))
    assert torch.equal(out_lst, torch.tensor([1, 2, 3]))
    assert torch.equal(out_tup, torch.tensor([1, 2, 3]))
    assert torch.equal(out_scalar, torch.tensor(5))
    assert torch.equal(out_torch, torch_tensor)

def test_numpify():
    torch_tensor = torch.tensor([1.0, 2.0], dtype=torch.float16)
    np_arr = np.array([3.0, 4.0], dtype=np.float32)
    lst = [5, 6]
    tup = (7, 8)
    scalar = 9
    out_torch = numpify(torch_tensor)
    out_np = numpify(np_arr)
    out_lst = numpify(lst)
    out_tup = numpify(tup)
    out_scalar = numpify(scalar)
    assert isinstance(out_torch, np.ndarray)
    assert out_torch.dtype == np.float16
    assert np.allclose(out_torch, np.array([1.0, 2.0], dtype=np.float16))
    assert isinstance(out_np, np.ndarray)
    assert out_np.dtype == np.float32
    assert np.allclose(out_np, np.array([3.0, 4.0], dtype=np.float32))
    assert isinstance(out_lst, np.ndarray)
    assert np.allclose(out_lst, np.array([5, 6]))
    assert isinstance(out_tup, np.ndarray)
    assert np.allclose(out_tup, np.array([7, 8]))
    assert isinstance(out_scalar, np.ndarray)
    assert np.allclose(out_scalar, np.array(9))

def test_pickle_yaml():
    data = [
        {"a": 1, "b": [2, 3]},
        {"c": "text", "d": {"nested": True}},
    ]
    pickled = pickle_dump(data)
    unpickled = pickle_load(pickled)
    assert unpickled == data
    yaml_str = yaml_dump(data)
    loaded = yaml_load(yaml_str)
    assert loaded == data

def test_timed():
    with timed("red", bold=True):
        print("Running some code...")
    # No assertion needed; just ensure no exception raised

def is_prime(n: int) -> bool:
    if n < 2:
        return False
    for i in range(2, int(n**0.5)+1):
        if n % i == 0:
            return False
    return True

def test_process_master_worker():
    numbers = [2, 3, 4, 5, 6, 8, 11]
    expected = [True, True, False, True, False, False, True]

    for worker_count in [1, 2, 3, 5, 7, 10]:
        with multiprocessing.Pool(processes=worker_count) as pool:
            results = pool.map(is_prime, numbers)
        assert results == expected

    # After exiting the with-block all processes should be terminated
    assert not any(p.is_alive() for p in multiprocessing.active_children())
