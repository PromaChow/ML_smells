import pygame
import math
import random
from collections import deque

class PyGameWrapper:
    pass

class RayCastPlayer:
    def __init__(self, pos, dir, plane):
        self.posx, self.posy = pos
        self.dirx, self.diry = dir
        self.planex, self.planey = plane

    def move(self, step, maze):
        newx = self.posx + self.dirx * step
        newy = self.posy + self.diry * step
        if maze[int(newy)][int(newx)] == 0:
            self.posx = newx
            self.posy = newy

    def rotate(self, angle, maze):
        old_dirx = self.dirx
        self.dirx = self.dirx * math.cos(angle) - self.diry * math.sin(angle)
        self.diry = old_dirx * math.sin(angle) + self.diry * math.cos(angle)
        old_planex = self.planex
        self.planex = self.planex * math.cos(angle) - self.planey * math.sin(angle)
        self.planey = old_planex * math.sin(angle) + self.planey * math.cos(angle)

class Game(PyGameWrapper, RayCastPlayer):
    def __init__(self, screen_width=640, screen_height=480, map_width=24, map_height=24):
        self.screen_width = screen_width
        self.screen_height = screen_height
        self.map_width = map_width
        self.map_height = map_height
        self.move_speed = 0.1
        self.rot_speed = 0.05
        self.block_passable = 0
        self.block_wall = 1
        self.block_target = 2
        self.keys = {
            pygame.K_w: 'move_forward',
            pygame.K_s: 'move_backward',
            pygame.K_a: 'rotate_left',
            pygame.K_d: 'rotate_right'
        }
        self.score = 0
        self.game_over = False
        self.target_distance = 8
        RayCastPlayer.__init__(self, pos=(1.5, 1.5), dir=(1.0, 0.0), plane=(0.0, 0.66))
        self.target_pos = None
        self.maze = []
        pygame.init()
        self.screen = pygame.display.set_mode((self.screen_width, self.screen_height))
        pygame.display.set_caption("Raycast Maze")
        self.clock = pygame.time.Clock()
        self.init()

    def _make_maze(self, w, h):
        maze = [[self.block_wall] * w]
        for y in range(1, h - 1):
            row = [self.block_wall] + [self.block_passable] * (w - 2) + [self.block_wall]
            maze.append(row)
        maze.append([self.block_wall] * w)
        density = 0.1
        for y in range(1, h - 1):
            for x in range(1, w - 1):
                if random.random() < density:
                    maze[y][x] = self.block_wall
        return maze

    def init(self):
        self.score = 0
        self.game_over = False
        self.posx, self.posy = 1.5, 1.5
        self.dirx, self.diry = 1.0, 0.0
        self.planex, self.planey = 0.0, 0.66
        self.maze = self._make_maze(self.map_width, self.map_height)
        reachable = self.getFiltredPositions()
        self.target_pos = random.choice(reachable)
        self.maze[self.target_pos[1]][self.target_pos[0]] = self.block_target
        if self.angle_to_obj_rad(self.target_pos) < 0.1:
            self.rotate(0.5, self.maze)

    def getFiltredPositions(self):
        start = (int(self.posx), int(self.posy))
        visited = set()
        queue = deque()
        queue.append((start, 0))
        reachable = []
        while queue:
            (x, y), dist = queue.popleft()
            if (x, y) in visited or dist > self.target_distance:
                continue
            visited.add((x, y))
            if self.maze[y][x] == self.block_passable:
                reachable.append((x, y))
                for dx, dy in [(-1,0),(1,0),(0,-1),(0,1)]:
                    nx, ny = x+dx, y+dy
                    if 0 <= nx < self.map_width and 0 <= ny < self.map_height:
                        queue.append(((nx, ny), dist+1))
        return reachable

    def angle_to_obj_rad(self, pos):
        dx = pos[0] + 0.5 - self.posx
        dy = pos[1] + 0.5 - self.posy
        vec_len = math.hypot(dx, dy)
        if vec_len == 0:
            return 0.0
        nx, ny = dx / vec_len, dy / vec_len
        dot = self.dirx * nx + self.diry * ny
        return math.acos(max(-1.0, min(1.0, dot)))

    def step(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
        keys = pygame.key.get_pressed()
        if keys[pygame.K_w]:
            self.move(self.move_speed, self.maze)
        if keys[pygame.K_s]:
            self.move(-self.move_speed, self.maze)
        if keys[pygame.K_a]:
            self.rotate(-self.rot_speed, self.maze)
        if keys[pygame.K_d]:
            self.rotate(self.rot_speed, self.maze)
        self.screen.fill((0, 0, 0))
        for x in range(self.screen_width):
            camera_x = 2 * x / self.screen_width - 1
            ray_dir_x = self.dirx + self.planex * camera_x
            ray_dir_y = self.diry + self.planey * camera_x
            map_x = int(self.posx)
            map_y = int(self.posy)
            delta_dist_x = abs(1 / ray_dir_x) if ray_dir_x != 0 else 1e30
            delta_dist_y = abs(1 / ray_dir_y) if ray_dir_y != 0 else 1e30
            if ray_dir_x < 0:
                step_x = -1
                side_dist_x = (self.posx - map_x) * delta_dist_x
            else:
                step_x = 1
                side_dist_x = (map_x + 1.0 - self.posx) * delta_dist_x
            if ray_dir_y < 0:
                step_y = -1
                side_dist_y = (self.posy - map_y) * delta_dist_y
            else:
                step_y = 1
                side_dist_y = (map_y + 1.0 - self.posy) * delta_dist_y
            hit = False
            side = 0
            while not hit:
                if side_dist_x < side_dist_y:
                    side_dist_x += delta_dist_x
                    map_x += step_x
                    side = 0
                else:
                    side_dist_y += delta_dist_y
                    map_y += step_y
                    side = 1
                if self.maze[map_y][map_x] == self.block_wall or self.maze[map_y][map_x] == self.block_target:
                    hit = True
            if side == 0:
                perp_wall_dist = (map_x - self.posx + (1 - step_x) / 2) / ray_dir_x
            else:
                perp_wall_dist = (map_y - self.posy + (1 - step_y) / 2) / ray_dir_y
            line_height = int(self.screen_height / (perp_wall_dist + 0.0001))
            draw_start = -line_height // 2 + self.screen_height // 2
            draw_end = line_height // 2 + self.screen_height // 2
            color = (200, 200, 200)
            if self.maze[map_y][map_x] == self.block_target:
                color = (0, 255, 0)
            if side == 1:
                color = tuple(c // 2 for c in color)
            pygame.draw.line(self.screen, color, (x, draw_start), (x, draw_end))
        if self.target_pos:
            tx, ty = self.target_pos[0] + 0.5, self.target_pos[1] + 0.5
            dist = math.hypot(tx - self.posx, ty - self.posy)
            angle = self.angle_to_obj_rad(self.target_pos)
            if dist < 1.1 and angle < 0.8:
                self.score += 1
                self.game_over = True
        pygame.display.flip()
        self.clock.tick(60)

def main():
    game = Game()
    while True:
        game.step()
        if game.game_over:
            pygame.time.delay(2000)
            game.init()

if __name__ == "__main__":
    main()