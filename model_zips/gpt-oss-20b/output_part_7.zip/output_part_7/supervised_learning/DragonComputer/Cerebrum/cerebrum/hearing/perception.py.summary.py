import os
import time
import wave
import datetime
import numpy as np
import pyaudio
import pyqtgraph as pg
from PyQt5 import QtWidgets
from tkinter import Tk
import multiprocessing

class HearingMemoryUtil:
    @staticmethod
    def add_memory(memory_data, start, end):
        with open('memory.txt', 'a') as f:
            f.write(f'Memory from {datetime.datetime.fromtimestamp(start)} to {datetime.datetime.fromtimestamp(end)}\n')
            f.write(f'Frames: {len(memory_data)}\n')
            f.write(f'Data length: {sum(len(ch) for ch in memory_data)}\n\n')

class AudioPerceptionSystem:
    CHUNK = 1024
    FORMAT = pyaudio.paInt16
    CHANNELS = 1
    RATE = 44100
    THRESHOLD = 500
    SILENCE_DETECTION = 30
    OUTPUT_FILENAME = 'output.wav'
    EMPTY_CHUNK = b'\x00' * CHUNK * CHANNELS * 2

    def __init__(self):
        root = Tk()
        root.withdraw()
        self.screen_w = root.winfo_screenwidth()
        self.screen_h = root.winfo_screenheight()
        root.destroy()
        self.positions = {
            'spectrum': (0, 0),
            'waveform': (0, self.screen_h // 2)
        }

    @staticmethod
    def save_file(path, frames):
        if not os.path.exists(path):
            wf = wave.open(path, 'wb')
            wf.setnchannels(AudioPerceptionSystem.CHANNELS)
            wf.setsampwidth(2)
            wf.setframerate(AudioPerceptionSystem.RATE)
            wf.writeframes(b''.join(frames))
            wf.close()
        else:
            wf = wave.open(path, 'rb')
            existing = wf.readframes(wf.getnframes())
            wf.close()
            wf = wave.open(path, 'wb')
            wf.setnchannels(AudioPerceptionSystem.CHANNELS)
            wf.setsampwidth(2)
            wf.setframerate(AudioPerceptionSystem.RATE)
            wf.writeframes(existing + b''.join(frames))
            wf.close()

    @staticmethod
    def find_frequency(data):
        N = len(data)
        yf = np.fft.fft(data)
        xf = np.fft.fftfreq(N, 1.0 / AudioPerceptionSystem.RATE)
        idx = np.argsort(xf)
        xf = xf[idx][:N // 2]
        yf = np.abs(yf[idx])[:N // 2]
        return xf, yf

    def draw_spectrum_analyzer(self, all_frames, stop_event):
        app = QtWidgets.QApplication([])
        win = pg.GraphicsLayoutWidget(title="Spectrum Analyzer")
        win.resize(800, 400)
        win.move(self.positions['spectrum'][0], self.positions['spectrum'][1])
        plot = win.addPlot()
        curve = plot.plot(pen='y')
        while not stop_event.is_set():
            if len(all_frames) > 0:
                chunk = all_frames[-1]
                data = np.frombuffer(chunk, dtype=np.int16).astype(np.float32)
                freq, power = self.find_frequency(data)
                rms = np.sqrt(np.mean(data**2))
                curve.setPen('y' if rms > self.THRESHOLD else 'w')
                curve.setData(freq, power)
            QtWidgets.QApplication.processEvents()
            time.sleep(0.05)
        app.quit()

    def draw_waveform(self, all_frames, thresh_frames, shared_state, stop_event):
        app = QtWidgets.QApplication([])
        win = pg.GraphicsLayoutWidget(title="Waveform")
        win.resize(800, 400)
        win.move(self.positions['waveform'][0], self.positions['waveform'][1])
        plot = win.addPlot()
        curve1 = plot.plot(pen='c')
        curve2 = plot.plot(pen='m')
        text = pg.TextItem(text='', anchor=(0, 1))
        plot.addItem(text)
        while not stop_event.is_set():
            if len(all_frames) >= 20:
                recent = all_frames[-20:]
                data = np.concatenate([np.frombuffer(ch, dtype=np.int16) for ch in recent])
                curve1.setData(data)
            if len(thresh_frames) >= 20:
                recent2 = thresh_frames[-20:]
                data2 = np.concatenate([np.frombuffer(ch, dtype=np.int16) for ch in recent2])
                curve2.setData(data2)
            stim_start = shared_state.get('stim_start', 0)
            elapsed = time.time() - stim_start if stim_start else 0
            text.setText(f'Elapsed: {elapsed:.2f}s')
            QtWidgets.QApplication.processEvents()
            time.sleep(0.05)
        app.quit()

    def start(self, input_type='mic'):
        manager = multiprocessing.Manager()
        all_frames = manager.list()
        thresh_frames = manager.list()
        shared_state = manager.dict()
        stop_event = multiprocessing.Event()

        p1 = multiprocessing.Process(target=self.draw_spectrum_analyzer, args=(all_frames, stop_event))
        p2 = multiprocessing.Process(target=self.draw_waveform, args=(all_frames, thresh_frames, shared_state, stop_event))
        p1.start()
        p2.start()

        pa = pyaudio.PyAudio()
        if input_type == 'mic':
            stream = pa.open(format=self.FORMAT,
                             channels=self.CHANNELS,
                             rate=self.RATE,
                             input=True,
                             frames_per_buffer=self.CHUNK)
        else:
            wf = wave.open(self.OUTPUT_FILENAME, 'rb')
            stream = pa.open(format=self.FORMAT,
                             channels=self.CHANNELS,
                             rate=self.RATE,
                             output=True)

        memory_data = []
        hearing_perception_stimulated = False
        stim_start = 0
        try:
            while True:
                if input_type == 'mic':
                    chunk = stream.read(self.CHUNK, exception_on_overflow=False)
                else:
                    chunk = wf.readframes(self.CHUNK)
                    stream.write(chunk)
                    if len(chunk) == 0:
                        break
                all_frames.append(chunk)
                data = np.frombuffer(chunk, dtype=np.int16).astype(np.float32)
                rms = np.sqrt(np.mean(data**2))
                if rms > self.THRESHOLD:
                    stim_start = time.time()
                    hearing_perception_stimulated = True
                    if len(all_frames) >= 2:
                        memory_data = [all_frames[-2], chunk]
                    else:
                        memory_data = [chunk]
                    thresh_frames.append(chunk)
                    silence_count = 0
                    while silence_count < self.SILENCE_DETECTION:
                        if input_type == 'mic':
                            next_chunk = stream.read(self.CHUNK, exception_on_overflow=False)
                        else:
                            next_chunk = wf.readframes(self.CHUNK)
                            stream.write(next_chunk)
                        all_frames.append(next_chunk)
                        data2 = np.frombuffer(next_chunk, dtype=np.int16).astype(np.float32)
                        rms2 = np.sqrt(np.mean(data2**2))
                        if rms2 > self.THRESHOLD:
                            memory_data.append(next_chunk)
                            thresh_frames.append(next_chunk)
                            silence_count = 0
                        else:
                            silence_count += 1
                            memory_data.append(next_chunk)
                            thresh_frames.append(next_chunk)
                    stim_end = time.time()
                    memory_data.append(self.EMPTY_CHUNK)
                    thresh_frames.append(self.EMPTY_CHUNK)
                    p = multiprocessing.Process(target=HearingMemoryUtil.add_memory,
                                                args=(memory_data, stim_start, stim_end))
                    p.start()
                    hearing_perception_stimulated = False
                    memory_data = []
                    shared_state['stim_start'] = stim_start
        except KeyboardInterrupt:
            pass
        finally:
            stop_event.set()
            p1.join()
            p2.join()
            stream.stop_stream()
            stream.close()
            pa.terminate()
            if input_type != 'mic':
                wf.close()

if __name__ == '__main__':
    system = AudioPerceptionSystem()
    system.start('mic')