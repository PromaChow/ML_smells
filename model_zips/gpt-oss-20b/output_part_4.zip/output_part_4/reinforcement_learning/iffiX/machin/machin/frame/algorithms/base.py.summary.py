import os
import torch
import torch.nn as nn
import torch.autograd as autograd
from torchviz import make_dot
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional


class TorchFramework(ABC):
    _is_top: list[str] = []
    _is_restorable: list[str] = []

    def __init__(self, role: Optional[str] = None):
        self._visualized: set[str] = set()
        self._backward = autograd.backward
        self.role = role

    @property
    @abstractmethod
    def optimizers(self) -> Dict[str, Any]:
        raise NotImplementedError

    @property
    @abstractmethod
    def lr_schedulers(self) -> Dict[str, Any]:
        raise NotImplementedError

    @property
    def top_models(self) -> Dict[str, nn.Module]:
        return {name: getattr(self, name) for name in self._is_top if hasattr(self, name)}

    @property
    def restorable_models(self) -> Dict[str, nn.Module]:
        return {name: getattr(self, name) for name in self._is_restorable if hasattr(self, name)}

    @classmethod
    def get_top_model_names(cls) -> list[str]:
        return cls._is_top

    @classmethod
    def get_restorable_model_names(cls) -> list[str]:
        return cls._is_restorable

    @classmethod
    def is_distributed(cls) -> bool:
        return False

    def set_backward_function(self, func: Any) -> None:
        if not callable(func):
            raise TypeError("Backward function must be callable")
        self._backward = func

    def enable_multiprocessing(self) -> None:
        for model in self.top_models.values():
            if hasattr(model, "share_memory"):
                model.share_memory()

    def load(
        self,
        model_dir: str,
        network_map: Optional[Dict[str, str]] = None,
        version: Optional[str] = None,
    ) -> None:
        network_map = network_map or {}
        for name, model in self.restorable_models.items():
            filename = network_map.get(name, f"{name}.pt")
            if version is not None:
                filename = f"{name}_v{version}.pt"
            path = os.path.join(model_dir, filename)
            if os.path.exists(path):
                state_dict = torch.load(path, map_location="cpu")
                model.load_state_dict(state_dict)

    def save(
        self,
        model_dir: str,
        network_map: Optional[Dict[str, str]] = None,
        version: Optional[str] = None,
    ) -> None:
        os.makedirs(model_dir, exist_ok=True)
        network_map = network_map or {}
        for name, model in self.restorable_models.items():
            filename = network_map.get(name, f"{name}.pt")
            if version is not None:
                filename = f"{name}_v{version}.pt"
            path = os.path.join(model_dir, filename)
            torch.save(model.state_dict(), path)

    def visualize_model(self, tensor: torch.Tensor, out_dir: str, name: str = "model") -> None:
        if not os.path.isdir(out_dir):
            os.makedirs(out_dir, exist_ok=True)
        key = os.path.join(out_dir, f"{name}.png")
        if key in self._visualized:
            return
        dot = make_dot(tensor, params=dict(self.top_models))
        dot.format = "png"
        dot.render(key, cleanup=True)
        self._visualized.add(key)

    @classmethod
    @abstractmethod
    def generate_config(cls) -> Dict[str, Any]:
        raise NotImplementedError

    @classmethod
    @abstractmethod
    def init_from_config(cls, config: Dict[str, Any]) -> "TorchFramework":
        raise NotImplementedError
