import os
import pickle
import numpy as np
from datetime import datetime
from pathlib import Path
from PIL import Image
import tensorflow.compat.v1 as tf

tf.disable_eager_execution()

# ------------------------------------------------------------------------------
# 1. Prerequisites Setup
# ------------------------------------------------------------------------------

project_root = Path(__file__).parent.resolve()
asset_model_dir = project_root / "asset_model"
asset_results_dir = project_root / "asset_results"
sample_pkl_dir = asset_results_dir / "pggan_celeba_sample_pkl"
explore_dir = asset_results_dir / "pggan_celeba_explore"

for directory in (asset_model_dir, sample_pkl_dir, explore_dir):
    directory.mkdir(parents=True, exist_ok=True)

# ------------------------------------------------------------------------------
# 2. Model and Environment Initialization
# ------------------------------------------------------------------------------

# Add PG-GAN source path
sys_path_entry = str(project_root / "src" / "model" / "pggan")
if sys_path_entry not in os.sys.path:
    os.sys.path.append(sys_path_entry)

model_path = asset_model_dir / "karras2018iclr-celebahq-1024x1024.pkl"
with open(model_path, "rb") as f:
    model_data = pickle.load(f)

# Extract networks
G = model_data.get("G")
D = model_data.get("D")
Gs = model_data.get("Gs")

# TensorFlow session
sess = tf.Session()

# ------------------------------------------------------------------------------
# 3. Latent Space Manipulation
# ------------------------------------------------------------------------------

latent_dim = 512  # Common for PG-GAN CelebA
batch_size = 8

latents_0 = np.random.randn(1, latent_dim).astype(np.float32)
latents_1 = np.random.randn(1, latent_dim).astype(np.float32)

distance_sq = np.sum((latents_0 - latents_1) ** 2)

alphas = np.linspace(0, 1, batch_size, dtype=np.float32)
latents = latents_0 + alphas[:, None] * (latents_1 - latents_0)

# ------------------------------------------------------------------------------
# 4. Image Generation
# ------------------------------------------------------------------------------

labels = np.zeros((batch_size, 1), dtype=np.float32)

# Run generator
feed_dict = {"latents": latents, "labels": labels}
generated = Gs.run("G", feed_dict=feed_dict, session=sess)
images = generated[0] if isinstance(generated, tuple) else generated

# Process images
images = np.clip(images, 0, 255).astype(np.uint8)
images = np.transpose(images, (0, 2, 3, 1))  # NCHW -> NHWC

# ------------------------------------------------------------------------------
# 5. Result Saving
# ------------------------------------------------------------------------------

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
latent_mode = "random"

# Save images
for idx, img_array in enumerate(images):
    img = Image.fromarray(img_array)
    filename = explore_dir / f"{timestamp}_{latent_mode}_img{idx:02d}.png"
    img.save(filename)

# Save dummy labels
labels_path = explore_dir / f"{timestamp}_{latent_mode}_labels.pkl"
with open(labels_path, "wb") as f:
    pickle.dump(labels, f)

# Close session
sess.close()