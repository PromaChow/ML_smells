import unittest
import numpy as np
from chainer import testing
import chainerrl

def make_data(shape, dtype, **kwargs):
    rng = np.random.default_rng()
    x = rng.uniform(-0.9, 0.9, size=shape).astype(dtype)
    gy = rng.uniform(-1, 1, size=shape).astype(dtype)
    ggx = rng.uniform(-1, 1, size=shape).astype(dtype)
    return x, gy, ggx

@testing.unary_math_function_unittest(
    chainerrl.functions.arctanh,
    make_data=make_data,
    backward_eps=1e-3,
    double_backward_eps=1e-3
)
class TestArctanh(unittest.TestCase):
    pass

testing.run_module(__name__, __file__)