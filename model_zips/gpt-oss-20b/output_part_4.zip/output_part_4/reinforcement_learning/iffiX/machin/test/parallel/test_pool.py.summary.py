import logging
import sys
import pytest
import torch
import dill
import machin.pool as pool_module

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Helper functions
def init_func(seed=0):
    torch.manual_seed(seed)

def func(x):
    return x + 1

def func2(x, y):
    return x * y

# Global variable for lambda test
global_val = 42

# Decorator to skip tests on non-Linux platforms
def linux_only(func):
    @pytest.mark.skipif(sys.platform != "linux", reason="Test requires Linux")
    def wrapper(*args, **kwargs):
        return func(*args, **kwargs)
    return wrapper

class TestPool:
    """Base test class for Pool implementations."""

    PoolClass = pool_module.Pool

    def create_pool(self, **kwargs):
        return self.PoolClass(**kwargs)

    def test_apply(self):
        with self.create_pool(processes=2) as p:
            result = p.apply(func, args=(torch.tensor([1, 2, 3]),))
            assert torch.equal(result, torch.tensor([2, 3, 4]))

    def test_map(self):
        with self.create_pool(processes=2) as p:
            data = [torch.tensor([i]) for i in range(5)]
            results = p.map(func, data)
            expected = [torch.tensor([i + 1]) for i in range(5)]
            assert all(torch.equal(r, e) for r, e in zip(results, expected))

    def test_starmap(self):
        with self.create_pool(processes=2) as p:
            data = [(torch.tensor([i]), torch.tensor([i + 1])) for i in range(5)]
            results = p.starmap(func2, data)
            expected = [torch.tensor([i * (i + 1)]) for i in range(5)]
            assert all(torch.equal(r, e) for r, e in zip(results, expected))

    def test_lambda_and_local(self):
        with self.create_pool(processes=2) as p:
            local_var = 10
            func_local = lambda x: x + local_var + global_val
            result = p.apply(func_local, args=(torch.tensor([5]),))
            assert torch.equal(result, torch.tensor([5 + local_var + global_val]))

    def test_size(self):
        with self.create_pool(processes=3) as p:
            assert p.size() == 3

    def test_reduce(self):
        with self.create_pool(processes=2) as p:
            with pytest.raises(NotImplementedError):
                dill.dumps(p)

class TestP2PPool(TestPool):
    PoolClass = pool_module.P2PPool

class TestThreadPool(TestPool):
    PoolClass = pool_module.ThreadPool

    def test_imap(self):
        with self.create_pool(processes=2) as p:
            data = [torch.tensor([i]) for i in range(5)]
            it = p.imap(func, data)
            results = list(it)
            expected = [torch.tensor([i + 1]) for i in range(5)]
            assert all(torch.equal(r, e) for r, e in zip(results, expected))

class TestCtxPool(TestPool):
    PoolClass = pool_module.CtxPool

    def test_ctx_map(self):
        with self.create_pool(processes=2, worker_contexts=[0, 1]) as p:
            data = [torch.tensor([i]) for i in range(4)]
            results = p.ctx_map(func, data)
            # Each result should be a tuple (context_id, result)
            for ctx_id, res in results:
                assert ctx_id in (0, 1)
                assert isinstance(res, torch.Tensor)

    def test_multiple_ctx_map(self):
        with self.create_pool(processes=2, worker_contexts=[0, 1]) as p1, \
             self.create_pool(processes=2, worker_contexts=[2, 3]) as p2:
            data1 = [torch.tensor([i]) for i in range(3)]
            data2 = [torch.tensor([i]) for i in range(3, 6)]
            res1 = p1.ctx_map(func, data1)
            res2 = p2.ctx_map(func, data2)
            for ctx_id, r in res1:
                assert ctx_id in (0, 1)
            for ctx_id, r in res2:
                assert ctx_id in (2, 3)

    def test_invalid_config(self):
        with pytest.raises(ValueError):
            self.create_pool(processes=2, worker_contexts=[0, 1, 2, 3])

    @linux_only
    def test_cpu_shared_tensor(self):
        tensor = torch.arange(10)
        tensor.share_memory_()
        with self.create_pool(processes=2, worker_contexts=[0, 1]) as p:
            data = [tensor for _ in range(2)]
            results = p.ctx_map(func, data)
            for _, res in results:
                assert torch.equal(res, tensor + 1)

class TestCtxThreadPool(TestCtxPool):
    PoolClass = pool_module.CtxThreadPool

    def test_starmap(self):
        with self.create_pool(processes=2, worker_contexts=[0, 1]) as p:
            data = [(torch.tensor([i]), torch.tensor([i + 2])) for i in range(3)]
            results = p.ctx_starmap(func2, data)
            for ctx_id, res in results:
                assert ctx_id in (0, 1)
                expected = torch.tensor([i * (i + 2)])
                assert torch.equal(res, expected)

# Disabled GPU tensor test (commented out due to CUDA peer access errors)
# def test_gpu_tensor():
#     if not torch.cuda.is_available():
#         pytest.skip("CUDA not available")
#     with TestPool().create_pool(processes=2) as p:
#         tensor = torch.arange(10).cuda()
#         result = p.apply(func, args=(tensor,))
#         assert torch.equal(result, tensor + 1)
#         assert result.is_cuda
```