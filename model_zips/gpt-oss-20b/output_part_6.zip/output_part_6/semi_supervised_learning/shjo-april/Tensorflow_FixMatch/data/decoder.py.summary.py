import multiprocessing
import time

class Decoder(multiprocessing.Process):
    def __init__(self, main_queue, queue_for_dataset, option):
        super().__init__()
        self.main_queue = main_queue
        self.queue_for_dataset = queue_for_dataset
        self.use_label = option.get('use_label', False)
        self.augment_func = option.get('augment_func')
        self.debug = option.get('debug', False)

    def run(self):
        while True:
            dataset = self.queue_for_dataset.get()
            for data_item in dataset:
                if self.use_label:
                    image_data, label_data = data_item
                else:
                    image_data = data_item
                    label_data = None

                if image_data is None:
                    continue

                if self.debug:
                    start = time.perf_counter()

                if self.use_label:
                    augmented = self.augment_func(image_data)
                else:
                    augmented0 = self.augment_func[0](image_data)
                    augmented1 = self.augment_func[1](image_item := image_data)  # noqa: E501

                if self.debug:
                    elapsed_ms = (time.perf_counter() - start) * 1000
                    print(f"Decode & augment time: {elapsed_ms:.2f} ms")

                if self.use_label:
                    self.main_queue.put([augmented, label_data])
                else:
                    self.main_queue.put([augmented0, augmented1])

            del dataset

if __name__ == "__main__":
    # Example usage (placeholder, not functional without actual queues and augment functions)
    main_q = multiprocessing.Queue()
    dataset_q = multiprocessing.Queue()
    options = {
        'use_label': True,
        'augment_func': lambda x: x,  # identity function placeholder
        'debug': False
    }
    decoder = Decoder(main_q, dataset_q, options)
    decoder.start()
    # The rest of the program would enqueue datasets into dataset_q and read from main_q.