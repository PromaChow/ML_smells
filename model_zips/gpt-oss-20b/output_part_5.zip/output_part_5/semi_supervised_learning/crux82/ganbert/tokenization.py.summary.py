import re
import unicodedata
from collections import OrderedDict

# --------------------------------------------------------------------------- #
# Validation of Casing Consistency
# --------------------------------------------------------------------------- #
LOWERCASED_MODELS = [
    "bert-base-uncased",
    "roberta-base",
    "distilbert-base-uncased",
    "albert-base-v2",
    "xlm-roberta-base",
]

CASED_MODELS = [
    "bert-base-cased",
    "roberta-large",
    "distilbert-base-cased",
    "albert-base-v1",
    "xlm-roberta-large",
]


def validate_case_matches_checkpoint(checkpoint_path, do_lower_case):
    """Check that the do_lower_case flag matches the model checkpoint."""
    # Extract the model name from the checkpoint path
    match = re.search(r"/([^/]+)$", checkpoint_path)
    if not match:
        raise ValueError(f"Unable to parse model name from checkpoint path: {checkpoint_path}")
    model_name = match.group(1).lower()

    if do_lower_case and model_name not in LOWERCASED_MODELS:
        raise ValueError(f"Checkpoint '{model_name}' is not lowercased but do_lower_case=True.")
    if not do_lower_case and model_name not in CASED_MODELS:
        raise ValueError(f"Checkpoint '{model_name}' is cased but do_lower_case=False.")


# --------------------------------------------------------------------------- #
# Text Conversion Utilities
# --------------------------------------------------------------------------- #
def convert_to_unicode(text):
    if isinstance(text, bytes):
        return text.decode("utf-8", errors="ignore")
    return text


def printable_text(text):
    """Return a printable string representation of text."""
    if isinstance(text, bytes):
        return text.decode("utf-8", errors="ignore")
    return text


def load_vocab(vocab_file):
    """Read a vocabulary file into an OrderedDict mapping token to index."""
    vocab = OrderedDict()
    with open(vocab_file, "r", encoding="utf-8") as f:
        for index, token in enumerate(f):
            token = token.rstrip("\n\r")
            vocab[token] = index
    return vocab


def convert_by_vocab(vocab, items):
    """Map a list of items to values in vocab."""
    return [vocab[item] if isinstance(item, str) else vocab[int(item)] for item in items]


# --------------------------------------------------------------------------- #
# Helper Functions for Character Classification
# --------------------------------------------------------------------------- #
def _is_whitespace(char):
    if char in (" ", "\t", "\n", "\r", "\f", "\v"):
        return True
    cat = unicodedata.category(char)
    if cat == "Zs":
        return True
    return False


def _is_control(char):
    if char in ("\t", "\n", "\r"):
        return False
    cat = unicodedata.category(char)
    if cat.startswith("C"):
        return True
    return False


def _is_punctuation(char):
    cat = unicodedata.category(char)
    if cat.startswith("P"):
        return True
    return False


# --------------------------------------------------------------------------- #
# Basic Tokenizer
# --------------------------------------------------------------------------- #
class BasicTokenizer:
    def __init__(self, do_lower_case=True):
        self.do_lower_case = do_lower_case

    def tokenize(self, text):
        text = convert_to_unicode(text)
        text = self._clean_text(text)
        text = self._tokenize_chinese_chars(text)
        orig_tokens = text.split()
        split_tokens = []
        for token in orig_tokens:
            if self.do_lower_case:
                token = token.lower()
                token = self._strip_accents(token)
            split_tokens.extend(self._run_split_on_punc(token))
        return self._strip_spaces(split_tokens)

    def _clean_text(self, text):
        cleaned = []
        for char in text:
            if ord(char) == 0 or ord(char) == 0xFFFD or _is_control(char):
                continue
            if _is_whitespace(char):
                cleaned.append(" ")
            else:
                cleaned.append(char)
        return "".join(cleaned)

    def _tokenize_chinese_chars(self, text):
        output = []
        for char in text:
            cp = ord(char)
            if self._is_chinese_char(cp):
                output.append(" ")
                output.append(char)
                output.append(" ")
            else:
                output.append(char)
        return "".join(output)

    def _is_chinese_char(self, cp):
        # Han Ideographs
        if 0x4E00 <= cp <= 0x9FFF:
            return True
        # CJK Symbols and Punctuation
        if 0x20000 <= cp <= 0x2A6DF:
            return True
        # Extension B
        if 0x2A700 <= cp <= 0x2B73F:
            return True
        # Extension C
        if 0x2B740 <= cp <= 0x2B81F:
            return True
        # Extension D
        if 0x2B820 <= cp <= 0x2CEAF:
            return True
        return False

    def _strip_accents(self, text):
        text = unicodedata.normalize("NFD", text)
        stripped = []
        for char in text:
            if unicodedata.category(char) == "Mn":
                continue
            stripped.append(char)
        return "".join(stripped)

    def _run_split_on_punc(self, token):
        if not token:
            return []
        chars = list(token)
        i = 0
        start_new_word = True
        splits = []
        while i < len(chars):
            char = chars[i]
            if _is_punctuation(char):
                splits.append(char)
                start_new_word = True
            else:
                if start_new_word:
                    splits.append(char)
                    start_new_word = False
                else:
                    splits[-1] += char
            i += 1
        return splits

    def _strip_spaces(self, tokens):
        return [token for token in tokens if token.strip()]


# --------------------------------------------------------------------------- #
# WordPiece Tokenizer
# --------------------------------------------------------------------------- #
class WordpieceTokenizer:
    def __init__(self, vocab, unk_token="[UNK]", max_input_chars_per_word=100):
        self.vocab = vocab
        self.unk_token = unk_token
        self.max_input_chars_per_word = max_input_chars_per_word

    def tokenize(self, token):
        if len(token) > self.max_input_chars_per_word:
            return [self.unk_token]
        sub_tokens = []
        start = 0
        while start < len(token):
            end = len(token)
            cur_substr = None
            while start < end:
                substr = token[start:end]
                if start > 0:
                    substr = "##" + substr
                if substr in self.vocab:
                    cur_substr = substr
                    break
                end -= 1
            if cur_substr is None:
                return [self.unk_token]
            sub_tokens.append(cur_substr)
            start = end
        return sub_tokens


# --------------------------------------------------------------------------- #
# Full Tokenizer
# --------------------------------------------------------------------------- #
class FullTokenizer:
    def __init__(self, vocab_file, do_lower_case=True, unk_token="[UNK]"):
        self.vocab = load_vocab(vocab_file)
        self.inv_vocab = {index: token for token, index in self.vocab.items()}
        self.basic_tokenizer = BasicTokenizer(do_lower_case=do_lower_case)
        self.wordpiece_tokenizer = WordpieceTokenizer(
            vocab=self.vocab, unk_token=unk_token
        )
        self.do_lower_case = do_lower_case
        self.unk_token = unk_token

    def tokenize(self, text):
        basic_tokens = self.basic_tokenizer.tokenize(text)
        split_tokens = []
        for token in basic_tokens:
            split_tokens.extend(self.wordpiece_tokenizer.tokenize(token))
        return split_tokens

    def convert_tokens_to_ids(self, tokens):
        return [self.vocab.get(tok, self.vocab.get(self.unk_token)) for tok in tokens]

    def convert_ids_to_tokens(self, ids):
        return [self.inv_vocab.get(i, self.unk_token) for i in ids]

    def convert_by_vocab(self, items):
        return convert_by_vocab(self.vocab, items)

    def __call__(self, text):
        return self.tokenize(text)
