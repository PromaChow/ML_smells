import gym
import numpy as np
import pytest


class SignClipReward(gym.RewardWrapper):
    def reward(self, reward):
        return float(np.sign(reward))


@pytest.mark.parametrize(
    "env_id",
    [
        "CartPole-v1",
        "Pendulum-v0",
        "MountainCar-v0",
        "Pong-v0",
        "SpaceInvaders-v0",
    ],
)
def test_sign_clip_reward(env_id):
    env_orig = gym.make(env_id)
    env_wrapped = SignClipReward(gym.make(env_id))
    try:
        env_orig.reset()
        env_wrapped.reset()
        for _ in range(1000):
            action = env_wrapped.action_space.sample()
            _, reward, done, _ = env_wrapped.step(action)
            assert reward in (-1.0, 0.0, 1.0)
            if done:
                break
    finally:
        env_orig.close()
        env_wrapped.close()