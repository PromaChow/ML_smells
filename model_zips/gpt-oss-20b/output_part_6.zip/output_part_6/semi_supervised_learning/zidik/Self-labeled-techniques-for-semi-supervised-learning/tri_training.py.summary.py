import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.metrics import accuracy_score
from scipy.stats.mstats import mode

class Third:
    def __init__(self, base_clf, X_labeled, y_labeled, err_prime=0.2):
        self.clf = clone(base_clf)
        # bootstrap sample
        n = len(X_labeled)
        idx = np.random.choice(n, size=n, replace=True)
        X_boot = X_labeled[idx]
        y_boot = y_labeled[idx]
        self.clf.fit(X_boot, y_boot)
        self.X_labeled = X_labeled
        self.y_labeled = y_labeled
        self.err_prime = err_prime
        self.l_prime = len(X_labeled)

    def train(self, t1, t2, X_unlabeled):
        # predictions on labeled data
        pred1 = t1.clf.predict(self.X_labeled)
        pred2 = t2.clf.predict(self.X_labeled)
        y_true = self.y_labeled

        agree = pred1 == pred2
        agree_cases = np.sum(agree)
        if agree_cases == 0:
            return False
        error_cases = np.sum((pred1 != y_true) & (pred2 != y_true))
        error_ratio = error_cases / agree_cases

        if error_ratio >= self.err_prime:
            return False

        # unlabeled where t1 and t2 agree
        preds_t1 = t1.clf.predict(X_unlabeled)
        preds_t2 = t2.clf.predict(X_unlabeled)
        agree_unlabeled = preds_t1 == preds_t2
        idx_agree = np.where(agree_unlabeled)[0]
        if len(idx_agree) == 0:
            return False

        L_X = X_unlabeled[idx_agree]
        L_y = preds_t1[idx_agree]

        if len(L_X) < self.l_prime:
            return False

        # update model
        X_new = np.concatenate((self.X_labeled, L_X))
        y_new = np.concatenate((self.y_labeled, L_y))
        self.clf.fit(X_new, y_new)
        self.X_labeled = X_new
        self.y_labeled = y_new
        self.err_prime = error_ratio
        self.l_prime = len(X_new)
        return True


class TriTraining:
    def __init__(self, base_clf, name=None):
        self.base_clf = base_clf
        self.name = name
        self.thirds = []

    def fit(self, X, y):
        X = np.asarray(X)
        y = np.asarray(y)

        mask_labeled = y != "unlabeled"
        mask_unlabeled = ~mask_labeled

        X_labeled = X[mask_labeled]
        y_labeled = y[mask_labeled]
        X_unlabeled = X[mask_unlabeled]

        # create three Third instances
        self.thirds = [
            Third(self.base_clf, X_labeled, y_labeled),
            Third(self.base_clf, X_labeled, y_labeled),
            Third(self.base_clf, X_labeled, y_labeled),
        ]

        rotations = [(0, 1, 2), (1, 2, 0), (2, 0, 1)]

        changed = True
        while changed:
            changed = False
            for r in rotations:
                t1, t2, t3 = self.thirds[r[0]], self.thirds[r[1]], self.thirds[r[2]]
                if t1.train(t2, t3, X_unlabeled):
                    changed = True
        return self

    def predict(self, X):
        preds = [t.clf.predict(X) for t in self.thirds]
        stacked = np.column_stack(preds)
        majority, _ = mode(stacked, axis=1)
        return majority.data.ravel()

    def score(self, X, y):
        y_true = np.asarray(y)
        y_pred = self.predict(X)
        return accuracy_score(y_true, y_pred)