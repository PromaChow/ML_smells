import os
import sys
import numpy as np
import gym
import pybullet as p

# Add parent directory to PYTHONPATH for model files
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

class PoseHelper:
    @staticmethod
    def get_pos(body_id, link_id=-1):
        pos, _ = p.getBasePositionAndOrientation(body_id) if link_id == -1 else p.getLinkState(body_id, link_id, computeLinkVelocity=1)[:2]
        return np.array(pos)

    @staticmethod
    def get_orn(body_id, link_id=-1):
        _, orn = p.getBasePositionAndOrientation(body_id) if link_id == -1 else p.getLinkState(body_id, link_id, computeLinkVelocity=1)[2:4]
        return np.array(orn)

    @staticmethod
    def get_lin_vel(body_id, link_id=-1):
        vel, _ = p.getBaseVelocity(body_id) if link_id == -1 else p.getLinkState(body_id, link_id, computeLinkVelocity=1)[5:7]
        return np.array(vel)

    @staticmethod
    def get_ang_vel(body_id, link_id=-1):
        _, ang = p.getBaseVelocity(body_id) if link_id == -1 else p.getLinkState(body_id, link_id, computeLinkVelocity=1)[5:7]
        return np.array(ang)

class BodyPart:
    def __init__(self, body_id, link_id=-1):
        self.body_id = body_id
        self.link_id = link_id

    def get_position(self):
        return PoseHelper.get_pos(self.body_id, self.link_id)

    def get_orientation(self):
        return PoseHelper.get_orn(self.body_id, self.link_id)

    def get_linear_velocity(self):
        return PoseHelper.get_lin_vel(self.body_id, self.link_id)

    def get_angular_velocity(self):
        return PoseHelper.get_ang_vel(self.body_id, self.link_id)

    def reset_pose(self, position, orientation):
        if self.link_id == -1:
            p.resetBasePositionAndOrientation(self.body_id, position, orientation)
        else:
            p.resetBasePositionAndOrientation(self.body_id, position, orientation)
            p.resetJointState(self.body_id, self.link_id, 0, 0)

    def reset_velocity(self, linear, angular):
        if self.link_id == -1:
            p.resetBaseVelocity(self.body_id, linear, angular)
        else:
            p.resetJointState(self.body_id, self.link_id, 0, 0)

class Joint:
    def __init__(self, body_id, joint_id):
        self.body_id = body_id
        self.joint_id = joint_id

    def get_state(self):
        pos, vel, _, _ = p.getJointState(self.body_id, self.joint_id)
        return pos, vel

    def set_position(self, position):
        p.setJointMotorControl2(self.body_id, self.joint_id, p.POSITION_CONTROL, targetPosition=position)

    def set_velocity(self, velocity):
        p.setJointMotorControl2(self.body_id, self.joint_id, p.VELOCITY_CONTROL, targetVelocity=velocity)

    def apply_torque(self, torque):
        p.setJointMotorControl2(self.body_id, self.joint_id, p.TORQUE_CONTROL, force=torque)

    def disable_motor(self):
        p.setJointMotorControl2(self.body_id, self.joint_id, p.VELOCITY_CONTROL, force=0)

class XmlBasedRobot:
    def __init__(self, action_dim=1, obs_dim=1):
        self.action_space = gym.spaces.Box(low=-1.0, high=1.0, shape=(action_dim,), dtype=np.float32)
        self.observation_space = gym.spaces.Box(low=-np.inf, high=np.inf, shape=(obs_dim,), dtype=np.float32)
        self.parts = {}
        self.joints = {}
        self.body_ids = []

    def addToScene(self, body_ids):
        self.body_ids = body_ids
        parts = {}
        joints = {}
        for body_id in body_ids:
            body_name, _ = p.getBodyInfo(body_id)
            body_name = body_name.decode('utf-8')
            num_joints = p.getNumJoints(body_id)
            for joint_id in range(num_joints):
                joint_info = p.getJointInfo(body_id, joint_id)
                joint_name = joint_info[1].decode('utf-8')
                if 'ignore' in joint_name.lower() or 'jointfix' in joint_name.lower():
                    continue
                joint = Joint(body_id, joint_id)
                joints[joint_name] = joint
            parts[body_name] = BodyPart(body_id)
        self.parts = parts
        self.joints = joints
        return parts, joints, body_ids

    def reset_pose(self, position, orientation):
        for body_id in self.body_ids:
            p.resetBasePositionAndOrientation(body_id, position, orientation)

    def robot_specific_reset(self):
        pass

    def calc_state(self):
        return np.zeros(self.observation_space.shape, dtype=np.float32)

    def calc_potential(self):
        return 0.0

class MJCFBasedRobot(XmlBasedRobot):
    def __init__(self, mjcf_path, action_dim=1, obs_dim=1, self_collision=True):
        super().__init__(action_dim, obs_dim)
        self.mjcf_path = mjcf_path
        self.self_collision = self_collision

    def reset(self):
        flags = p.MJCF_ENABLE_CASCADE if self.self_collision else 0
        body_ids = p.loadMJCF(self.mjcf_path, flags=flags)
        parts, joints, bodies = self.addToScene(body_ids)
        self.robot_specific_reset()
        return self.calc_state()

class URDFBasedRobot(XmlBasedRobot):
    def __init__(self, urdf_path, base_position=[0,0,0], base_orientation=[0,0,0,1], action_dim=1, obs_dim=1, self_collision=True):
        super().__init__(action_dim, obs_dim)
        self.urdf_path = urdf_path
        self.base_position = base_position
        self.base_orientation = base_orientation
        self.self_collision = self_collision

    def reset(self):
        flags = p.URDF_ENABLE_CASCADE | p.URDF_USE_SELF_COLLISION if self.self_collision else 0
        body_id = p.loadURDF(self.urdf_path, basePosition=self.base_position, baseOrientation=self.base_orientation, flags=flags)
        parts, joints, bodies = self.addToScene([body_id])
        self.robot_specific_reset()
        return self.calc_state()

class SDFBasedRobot(XmlBasedRobot):
    def __init__(self, sdf_path, action_dim=1, obs_dim=1, self_collision=True):
        super().__init__(action_dim, obs_dim)
        self.sdf_path = sdf_path
        self.self_collision = self_collision

    def reset(self):
        body_ids = p.loadSDF(self.sdf_path)
        parts, joints, bodies = self.addToScene(body_ids)
        self.robot_specific_reset()
        return self.calc_state()
