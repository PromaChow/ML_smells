import matplotlib.pyplot as plt
import numpy as np
import time


def removeAxes(ax):
    """Hide the x-axis and y-axis of the given Axes."""
    ax.get_xaxis().set_visible(False)
    ax.get_yaxis().set_visible(False)


def removeFrames(ax, spines=('top', 'right')):
    """Remove specified spines from the Axes."""
    for spine in spines:
        if spine in ax.spines:
            ax.spines[spine].set_visible(False)


def removeTicks(ax, axis='both'):
    """Disable ticks and labels on the specified axis."""
    if axis in ('x', 'both'):
        ax.tick_params(axis='x', which='both', bottom=False, top=False,
                       labelbottom=False)
    if axis in ('y', 'both'):
        ax.tick_params(axis='y', which='both', left=False, right=False,
                       labelleft=False)


def addAxis(ax, orientation='horizontal', color='black', linewidth=0.8):
    """Add a horizontal or vertical line at the zero position."""
    if orientation == 'horizontal':
        ax.axhline(0, color=color, linewidth=linewidth)
    elif orientation == 'vertical':
        ax.axvline(0, color=color, linewidth=linewidth)
    else:
        raise ValueError("orientation must be 'horizontal' or 'vertical'")


def cleanPlot(ax):
    """Remove top, right, bottom spines and all ticks/labels."""
    removeFrames(ax, spines=('top', 'right', 'bottom'))
    removeTicks(ax, axis='both')
    # Optionally remove left and bottom if needed
    # removeFrames(ax, spines=('left',))
    # removeTicks(ax, axis='both')


def setLims(ax, xlim=None, ylim=None):
    """Set the x and y axis limits of the Axes."""
    if xlim is not None:
        ax.set_xlim(xlim)
    if ylim is not None:
        ax.set_ylim(ylim)


def plot_across(imgs, cmap='viridis', figsize=(15, 5)):
    """
    Create a horizontal figure with subplots for each image in `imgs`.
    Each image is displayed using imshow with the specified colormap.
    Grids are disabled for each subplot.
    """
    n = len(imgs)
    if n == 0:
        raise ValueError("The imgs list is empty.")
    fig, axes = plt.subplots(1, n, figsize=figsize, squeeze=False)
    axes = axes[0]  # flatten to 1D array of Axes
    for ax, img in zip(axes, imgs):
        ax.imshow(img, cmap=cmap)
        ax.grid(False)
    return fig, axes
