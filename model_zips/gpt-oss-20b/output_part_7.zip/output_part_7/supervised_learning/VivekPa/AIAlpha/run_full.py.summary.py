import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error

# Autoencoder data
a_train_x = pd.read_csv('autoencoder_data/train_x.csv')
a_train_y = pd.read_csv('autoencoder_data/train_y.csv')
a_test_x = pd.read_csv('autoencoder_data/test_x.csv')
a_test_y = pd.read_csv('autoencoder_data/test_y.csv')

print('Autoencoder train_x head:\n', a_train_x.head())
print('Autoencoder train_x shape:', a_train_x.shape)

# Scaling for Autoencoder
scaler_a = MinMaxScaler(feature_range=(-1, 1))
a_train_x_scaled = scaler_a.fit_transform(a_train_x.iloc[:, 1:])
a_test_x_scaled = scaler_a.transform(a_test_x.iloc[:, 1:])

# Autoencoder model setup (commented out)
"""
from torch import nn

class AutoEncoder(nn.Module):
    def __init__(self, latent_dim, input_dim):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 100),
            nn.ReLU(),
            nn.Linear(100, 50),
            nn.ReLU(),
            nn.Linear(50, 50),
            nn.ReLU(),
            nn.Linear(50, latent_dim)
        )
        self.decoder = nn.Sequential(
            nn.Linear(latent_dim, 50),
            nn.ReLU(),
            nn.Linear(50, 50),
            nn.ReLU(),
            nn.Linear(50, 100),
            nn.ReLU(),
            nn.Linear(100, input_dim)
        )
    def forward(self, x):
        z = self.encoder(x)
        return self.decoder(z)

# ae = AutoEncoder(latent_dim=20, input_dim=a_train_x_scaled.shape[1])
# ... training code ...
"""

# RF data
rf_train_x = pd.read_csv('rf_data/train_x.csv')
rf_train_y = pd.read_csv('rf_data/train_y.csv')
rf_test_x = pd.read_csv('rf_data/test_x.csv')
rf_test_y = pd.read_csv('rf_data/test_y.csv')

print('RF train_x head:\n', rf_train_x.head())
print('RF train_y shape:', rf_train_y.shape)

# Scaling for RF
scaler_rf = MinMaxScaler(feature_range=(-1, 1))
x_train_scaled = scaler_rf.fit_transform(rf_train_x)
x_test_scaled = scaler_rf.transform(rf_test_x)

# RFModel wrapper
class RFModel:
    def __init__(self, input_size, n_estimators=100, verbose=0):
        self.input_size = input_size
        self.n_estimators = n_estimators
        self.verbose = verbose
        self.model = RandomForestRegressor(
            n_estimators=self.n_estimators,
            verbose=self.verbose,
            random_state=42
        )

    def train(self, X, y):
        self.model.fit(X, y.values.ravel())

    def test(self, X, y):
        preds = self.model.predict(X)
        print('First 5 predictions:', preds[:5])
        mse = mean_squared_error(y, preds)
        print('MSE:', mse)

# Train and test on RF data
rf_model = RFModel(input_size=x_train_scaled.shape[1], n_estimators=300, verbose=1)
rf_model.train(x_train_scaled, rf_train_y)
rf_model.test(x_test_scaled, rf_test_y)

# Train and test on Autoencoder data
a_rf_model = RFModel(input_size=a_train_x_scaled.shape[1], n_estimators=300, verbose=1)
a_rf_model.train(a_train_x_scaled, a_train_y.values.ravel())
a_rf_model.test(a_test_x_scaled, a_test_y.values.ravel())