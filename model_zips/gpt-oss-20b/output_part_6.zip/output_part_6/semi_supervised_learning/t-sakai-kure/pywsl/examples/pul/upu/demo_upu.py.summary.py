import numpy as np
from sklearn.model_selection import GridSearchCV

from pywsl.pul import PU_SL, gen_twonorm_pu
from pywsl.utils import bin_clf_err


def main():
    # 1. Data Generation
    n_p = 30
    n_u = 200
    prior_u = 0.5
    n_t = 100
    x, y, x_t, y_t = gen_twonorm_pu(n_p=n_p, n_u=n_u, prior_u=prior_u, n_t=n_t)

    # 2. Hyperparameter Setup
    lam_values = np.logspace(-3, 1, 5)
    param_grid = {
        'prior': [0.5],
        'basis': ['lm'],
        'lam': lam_values
    }

    # 3. Model Training
    pu_estimator = PU_SL()
    grid_search = GridSearchCV(
        estimator=pu_estimator,
        param_grid=param_grid,
        cv=5,
        n_jobs=-1,
        scoring='accuracy'
    )
    grid_search.fit(x, y)
    best_model = grid_search.best_estimator_

    # 4. Prediction and Evaluation
    y_pred = best_model.predict(x_t)
    error_rate = bin_clf_err(y_t, y_pred, prior=0.5)
    print(f"Prediction error: {error_rate * 100:.2f}%")

if __name__ == "__main__":
    main()
