import pandas as pd

# 1. Load the dataset
df = pd.read_csv("Salaries.csv")
print("First five rows of the dataset:")
print(df.head())

# 2. Calculate total salary cost increase from 2011 to 2014
year_total_pay = (
    df.groupby("Year")["TotalPay"]
    .sum()
    .reset_index()
    .rename(columns={"TotalPay": "TotalPaySum"})
)
print("\nTotal pay by year:")
print(year_total_pay)

pay_2011 = year_total_pay.loc[year_total_pay["Year"] == 2011, "TotalPaySum"].values[0]
pay_2014 = year_total_pay.loc[year_total_pay["Year"] == 2014, "TotalPaySum"].values[0]
increase = pay_2014 - pay_2011
print(f"\nTotal salary cost increase from 2011 to 2014: {increase}")

# 3. Identify the job title with the highest mean salary in 2014
df_2014 = df[df["Year"] == 2014]
job_mean_pay = (
    df_2014.groupby("JobTitle")["TotalPay"]
    .mean()
    .reset_index()
    .rename(columns={"TotalPay": "MeanTotalPay"})
)
top_job = job_mean_pay.loc[job_mean_pay["MeanTotalPay"].idxmax()]
print(f"\nJob title with the highest mean salary in 2014: {top_job['JobTitle']} (Mean TotalPay: {top_job['MeanTotalPay']})")

# 4. Calculate potential savings by eliminating overtime pay in 2014
overtime_by_year = (
    df.groupby("Year")["OvertimePay"]
    .sum()
    .reset_index()
    .rename(columns={"OvertimePay": "TotalOvertimePay"})
)
overtime_2014 = overtime_by_year.loc[overtime_by_year["Year"] == 2014, "TotalOvertimePay"].values[0]
print(f"\nPotential savings by eliminating overtime pay in 2014: {overtime_2014}")

# 5. Determine the top 5 common jobs in 2014 and their total cost
job_counts = (
    df.groupby(["Year", "JobTitle"])
    .size()
    .reset_index(name="Count")
)
top_jobs_2014 = (
    job_counts[job_counts["Year"] == 2014]
    .sort_values(by="Count", ascending=False)
    .head(5)
)
print("\nTop 5 common jobs in 2014 and their counts:")
print(top_jobs_2014)

# 6. Identify the top-earning employee across all years (per year)
employee_year_pay = (
    df.groupby(["Year", "EmployeeName"])["TotalPay"]
    .sum()
    .reset_index()
    .rename(columns={"TotalPay": "TotalPaySum"})
)
top_earners_per_year = (
    employee_year_pay.loc[employee_year_pay.groupby("Year")["TotalPaySum"].idxmax()]
    .reset_index(drop=True)
)
print("\nTop-earning employee per year:")
print(top_earners_per_year)