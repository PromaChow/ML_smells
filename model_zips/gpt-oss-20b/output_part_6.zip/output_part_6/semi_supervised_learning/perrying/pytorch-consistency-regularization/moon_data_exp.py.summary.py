import argparse
import os
import math
import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset, RandomSampler

from sklearn.datasets import make_moons

# --------------------- Configuration --------------------- #
class Config:
    def __init__(self, args):
        self.n_sample = args.n_sample
        self.n_labeled = args.n_labeled
        self.noise_factor = args.noise_factor
        self.iterations = args.iterations
        self.lr = args.lr
        self.alg = args.alg
        self.coef = args.coef
        self.entropy_minimize = args.entropy_minimize
        self.gauss_std = args.gauss_std
        self.ema_teacher = args.ema_teacher
        self.batch_size = args.batch_size
        self.out_dir = args.out_dir
        self.vis_data = args.vis_data
        # SSL-specific params
        self.vat_eps = args.vat_eps
        self.vat_xi = args.vat_xi
        self.vat_iter = args.vat_iter
        self.ict_alpha = args.ict_alpha
        self.pl_threshold = args.pl_threshold
        self.ce_consistency = args.ce_consistency

        os.makedirs(self.out_dir, exist_ok=True)

# --------------------- Data Generation --------------------- #
def generate_data(cfg):
    X, y = make_moons(n_samples=cfg.n_sample, noise=cfg.noise_factor, random_state=42)
    X = (X - X.mean(axis=0)) / X.std(axis=0)

    idx0 = np.where(y == 0)[0]
    idx1 = np.where(y == 1)[0]

    np.random.shuffle(idx0)
    np.random.shuffle(idx1)

    l0_idx = idx0[:cfg.n_labeled]
    u0_idx = idx0[cfg.n_labeled:]
    l1_idx = idx1[:cfg.n_labeled]
    u1_idx = idx1[cfg.n_labeled:]

    l0_data = X[l0_idx]
    l1_data = X[l1_idx]
    u_data = X[np.concatenate([u0_idx, u1_idx])]

    l0_label = np.zeros(len(l0_data), dtype=int)
    l1_label = np.ones(len(l1_data), dtype=int)

    return l0_data, l1_data, u_data, l0_label, l1_label

# --------------------- Model Definition --------------------- #
class SimpleNet(nn.Module):
    def __init__(self, in_dim=2, hidden1=128, hidden2=256, out_dim=2):
        super().__init__()
        self.fc1 = nn.Linear(in_dim, hidden1)
        self.fc2 = nn.Linear(hidden1, hidden2)
        self.fc3 = nn.Linear(hidden2, out_dim)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        return self.fc3(x)

# --------------------- EMA Update --------------------- #
@torch.no_grad()
def ema_update(student, teacher, alpha):
    for s_param, t_param in zip(student.parameters(), teacher.parameters()):
        t_param.data.mul_(1 - alpha)
        t_param.data.add_(alpha * s_param.data)

# --------------------- SSL Algorithms --------------------- #
class SSLAlgorithm:
    def pseudo_label(self, model, x):
        raise NotImplementedError

    def consistency_loss(self, student_pred, teacher_pred):
        raise NotImplementedError

class ICT(SSLAlgorithm):
    def __init__(self, alpha):
        self.alpha = alpha

    def pseudo_label(self, model, x):
        return torch.argmax(F.softmax(model(x), dim=1), dim=1)

    def consistency_loss(self, student_pred, teacher_pred):
        return F.cross_entropy(student_pred, teacher_pred)

class CR(SSLAlgorithm):
    def pseudo_label(self, model, x):
        probs = F.softmax(model(x), dim=1)
        max_conf, labels = probs.max(dim=1)
        return labels, max_conf

    def consistency_loss(self, student_pred, teacher_pred, confidences):
        ce = F.cross_entropy(student_pred, teacher_pred)
        weight = confidences.unsqueeze(1)
        return (ce * weight).mean()

class VAT(SSLAlgorithm):
    def __init__(self, eps, xi, iters):
        self.eps = eps
        self.xi = xi
        self.iters = iters

    def vat_perturb(self, model, x):
        d = torch.randn_like(x, device=x.device)
        for _ in range(self.iters):
            d = self.xi * F.normalize(d)
            d.requires_grad_()
            logits = model(x + d)
            loss = F.kl_div(F.log_softmax(logits, dim=1),
                            F.softmax(model(x), dim=1),
                            reduction='batchmean')
            loss.backward()
            d = d.grad.detach()
        return d.detach()

    def pseudo_label(self, model, x):
        return torch.argmax(F.softmax(model(x), dim=1), dim=1)

    def consistency_loss(self, student_pred, teacher_pred):
        return F.cross_entropy(student_pred, teacher_pred)

class PL(SSLAlgorithm):
    def __init__(self, threshold):
        self.threshold = threshold

    def pseudo_label(self, model, x):
        probs = F.softmax(model(x), dim=1)
        max_conf, labels = probs.max(dim=1)
        mask = max_conf > self.threshold
        return labels, mask

    def consistency_loss(self, student_pred, teacher_pred, mask):
        ce = F.cross_entropy(student_pred, teacher_pred, reduction='none')
        ce = ce[mask]
        if ce.numel() == 0:
            return torch.tensor(0.0, device=student_pred.device)
        return ce.mean()

def get_ssl_algorithm(cfg):
    if cfg.alg.lower() == 'ict':
        return ICT(cfg.ict_alpha)
    if cfg.alg.lower() == 'cr':
        return CR()
    if cfg.alg.lower() == 'vat':
        return VAT(cfg.vat_eps, cfg.vat_xi, cfg.vat_iter)
    if cfg.alg.lower() == 'pl':
        return PL(cfg.pl_threshold)
    raise ValueError(f"Unsupported SSL algorithm: {cfg.alg}")

# --------------------- Training --------------------- #
def fit(cfg):
    l0_data, l1_data, u_data, l0_label, l1_label = generate_data(cfg)

    # Create labeled dataset
    X_labeled = torch.tensor(np.concatenate([l0_data, l1_data]), dtype=torch.float32)
    y_labeled = torch.tensor(np.concatenate([l0_label, l1_label]), dtype=torch.long)
    labeled_ds = TensorDataset(X_labeled, y_labeled)
    labeled_loader = DataLoader(labeled_ds, batch_size=cfg.batch_size, sampler=RandomSampler(labeled_ds))

    # Unlabeled data
    X_unlabeled = torch.tensor(u_data, dtype=torch.float32)

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    student = SimpleNet().to(device)
    teacher = SimpleNet().to(device)
    if cfg.ema_teacher:
        teacher.load_state_dict(student.state_dict())
    optimizer = torch.optim.Adam(student.parameters(), lr=cfg.lr)
    ssl_alg = get_ssl_algorithm(cfg)

    global_step = 0
    for _ in tqdm(range(cfg.iterations)):
        # ---- Labeled batch ----
        try:
            xb_l, yb_l = next(iter(labeled_loader))
        except StopIteration:
            labeled_loader = DataLoader(labeled_ds, batch_size=cfg.batch_size, sampler=RandomSampler(labeled_ds))
            xb_l, yb_l = next(iter(labeled_loader))

        xb_l = xb_l.to(device)
        yb_l = yb_l.to(device)

        # ---- Unlabeled batch ----
        idx = np.random.choice(len(X_unlabeled), cfg.batch_size, replace=False)
        xb_u = X_unlabeled[idx].to(device)
        # weak augmentation
        xb_u_weak = xb_u + torch.randn_like(xb_u) * cfg.gauss_std

        # Concatenate
        xb = torch.cat([xb_l, xb_u_weak, xb_u_weak], dim=0)  # two augmentations for consistency
        outputs = student(xb)

        # Split
        logits_l = outputs[:len(xb_l)]
        logits_u1 = outputs[len(xb_l):len(xb_l)+len(xb_u_weak)]
        logits_u2 = outputs[len(xb_l)+len(xb_u_weak):]

        # Labeled loss
        loss_l = F.cross_entropy(logits_l, yb_l)

        # Consistency loss
        loss_c = torch.tensor(0.0, device=device)
        if cfg.coef > 0:
            with torch.no_grad():
                if isinstance(ssl_alg, CR) or isinstance(ssl_alg, PL):
                    pseudo, conf = ssl_alg.pseudo_label(student, xb_u)
                    if isinstance(ssl_alg, CR):
                        loss_c = cfg.coef * ssl_alg.consistency_loss(logits_u1, pseudo, conf)
                    else:
                        mask = conf
                        loss_c = cfg.coef * ssl_alg.consistency_loss(logits_u1, pseudo, mask)
                else:
                    pseudo = ssl_alg.pseudo_label(student, xb_u)
                    loss_c = cfg.coef * ssl_alg.consistency_loss(logits_u1, pseudo)

        # Entropy minimization
        loss_e = torch.tensor(0.0, device=device)
        if cfg.entropy_minimize > 0:
            probs = F.softmax(logits_u1, dim=1)
            entropy = -(probs * torch.log(probs + 1e-12)).sum(dim=1).mean()
            loss_e = cfg.entropy_minimize * entropy

        loss = loss_l + loss_c + loss_e

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        if cfg.ema_teacher:
            ema_update(student, teacher, 0.01)

        if global_step % 100 == 0:
            print(f"Step {global_step:5d} | Total loss: {loss.item():.4f} | Consistency: {loss_c.item():.4f}")
        global_step += 1

    # After training, copy teacher to student if using EMA
    if cfg.ema_teacher:
        student.load_state_dict(teacher.state_dict())

    # Visualization
    visualize(cfg, student, l0_data, l1_data, u_data)

# --------------------- Visualization --------------------- #
def visualize(cfg, model, l0_data, l1_data, u_data):
    model.eval()
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model.to(device)

    fig, ax = plt.subplots()
    ax.scatter(u_data[:,0], u_data[:,1], c='gray', alpha=0.3, label='Unlabeled')
    ax.scatter(l0_data[:,0], l0_data[:,1], c='blue', label='Class 0')
    ax.scatter(l1_data[:,0], l1_data[:,1], c='red', label='Class 1')
    ax.legend()
    ax.set_title('Raw Data')
    fig.savefig(os.path.join(cfg.out_dir, 'raw_data.png'))
    if cfg.vis_data:
        plt.show()
    plt.close(fig)

    # Confidence map
    x_min, x_max = u_data[:,0].min() - 0.5, u_data[:,0].max() + 0.5
    y_min, y_max = u_data[:,1].min() - 0.5, u_data[:,1].max() + 0.5
    xx, yy = np.meshgrid(np.linspace(x_min, x_max, 200),
                         np.linspace(y_min, y_max, 200))
    grid = np.c_[xx.ravel(), yy.ravel()]
    with torch.no_grad():
        probs = F.softmax(model(torch.tensor(grid, dtype=torch.float32).to(device)), dim=1)[:,1]
    probs = probs.cpu().numpy().reshape(xx.shape)

    fig, ax = plt.subplots()
    contour = ax.contourf(xx, yy, probs, levels=50, cmap='RdBu', alpha=0.6)
    ax.scatter(u_data[:,0], u_data[:,1], c='gray', alpha=0.3)
    ax.scatter(l0_data[:,0], l0_data[:,1], c='blue')
    ax.scatter(l1_data[:,0], l1_data[:,1], c='red')
    ax.set_title('Confidence Map (Class 1 Probability)')
    fig.colorbar(contour, ax=ax)
    fig.savefig(os.path.join(cfg.out_dir, 'confidence_map.png'))
    if cfg.vis_data:
        plt.show()
    plt.close(fig)

# --------------------- Main --------------------- #
def parse_args():
    parser = argparse.ArgumentParser(description='Semi-supervised Two Moons Experiment')
    parser.add_argument('--n_sample', type=int, default=1000, help='Total number of samples')
    parser.add_argument('--n_labeled', type=int, default=20, help='Labeled samples per class')
    parser.add_argument('--noise_factor', type=float, default=0.1, help='Gaussian noise for data generation')
    parser.add_argument('--iterations', type=int, default=5000, help='Number of training steps')
    parser.add_argument('--lr', type=float, default=1e-3, help='Learning rate')
    parser.add_argument('--alg', type=str, default='pl', help='SSL algorithm: ict, cr, vat, pl')
    parser.add_argument('--coef', type=float, default=1.0, help='Consistency loss coefficient')
    parser.add_argument('--entropy_minimize', type=float, default=0.0, help='Entropy minimization weight')
    parser.add_argument('--gauss_std', type=float, default=0.1, help='Gaussian std for weak augmentation')
    parser.add_argument('--ema_teacher', action='store_true', help='Use EMA teacher')
    parser.add_argument('--batch_size', type=int, default=64, help='Batch size')
    parser.add_argument('--out_dir', type=str, default='results', help='Output directory')
    parser.add_argument('--vis_data', action='store_true', help='Display plots')
    # SSL-specific
    parser.add_argument('--vat_eps', type=float, default=1.0, help='VAT epsilon')
    parser.add_argument('--vat_xi', type=float, default=0.1, help='VAT xi')
    parser.add_argument('--vat_iter', type=int, default=1, help='VAT iterations')
    parser.add_argument('--ict_alpha', type=float, default=0.5, help='ICT alpha')
    parser.add_argument('--pl_threshold', type=float, default=0.95, help='PL confidence threshold')
    parser.add_argument('--ce_consistency', action='store_true', help='Use cross-entropy consistency')

    return parser.parse_args()

if __name__ == '__main__':
    cfg = Config(parse_args())
    fit(cfg)