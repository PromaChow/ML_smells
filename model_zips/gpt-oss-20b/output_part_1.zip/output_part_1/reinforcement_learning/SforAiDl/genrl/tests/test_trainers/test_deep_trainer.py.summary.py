import os
import shutil
import unittest

from genrl.algorithms import PPO1, DDPG
from genrl.envs import VectorEnv
from genrl.policies import MLPPolicy
from genrl.trainers import OnPolicyTrainer, OffPolicyTrainer


class TestGenRLTrainers(unittest.TestCase):
    def test_on_policy_trainer(self):
        env = VectorEnv("CartPole-v1", n_envs=2)
        policy = MLPPolicy()
        algo = PPO1(policy, rollout_size=128)
        trainer = OnPolicyTrainer(
            algo,
            env,
            log_dir="stdout",
            epochs=2,
            eval_episodes=2,
            max_t=300,
        )
        self.assertFalse(trainer.off_policy)
        trainer.train()
        trainer.evaluate()

    def test_off_policy_trainer(self):
        env = VectorEnv("Pendulum-v0", n_envs=2)
        policy = MLPPolicy()
        algo = DDPG(policy, replay_size=100)
        trainer = OffPolicyTrainer(
            algo,
            env,
            log_dir="stdout",
            epochs=2,
            eval_episodes=2,
            max_episode_len=300,
            max_t=300,
        )
        self.assertTrue(trainer.off_policy)
        trainer.train()
        trainer.evaluate()

    def test_saving_model_parameters(self):
        env = VectorEnv("CartPole-v0", n_envs=1)
        policy = MLPPolicy()
        algo = PPO1(policy)
        trainer = OnPolicyTrainer(
            algo,
            env,
            log_dir="stdout",
            epochs=1,
            save_model="test_ckpt",
            save_interval=1,
        )
        trainer.train()
        ckpt_dir = os.path.join("test_ckpt", "PPO1_CartPole-v0")
        self.assertTrue(os.path.isdir(ckpt_dir))
        self.assertTrue(os.listdir(ckpt_dir))

    def test_loading_model_parameters(self):
        env = VectorEnv("CartPole-v0", n_envs=1)
        policy = MLPPolicy()
        algo = PPO1(policy)
        ckpt_path = os.path.join("test_ckpt", "PPO1_CartPole-v0")
        hyperparams_file = os.path.join(ckpt_path, "0-log-0.toml")
        weights_file = os.path.join(ckpt_path, "0-log-0.pt")
        trainer = OnPolicyTrainer(
            algo,
            env,
            log_dir="stdout",
            epochs=0,
            load_hyperparams=hyperparams_file,
            load_path=weights_file,
        )
        trainer.train()
        shutil.rmtree("logs", ignore_errors=True)


if __name__ == "__main__":
    unittest.main()
