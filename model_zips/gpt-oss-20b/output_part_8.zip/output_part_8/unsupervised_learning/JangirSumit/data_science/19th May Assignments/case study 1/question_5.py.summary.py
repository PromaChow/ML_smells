import pandas as pd
import numpy as np

# 5.1: Create DataFrame
data = {
    'first_name': ['John', 'Jane', 'Alice', 'Bob', 'Charlie'],
    'last_name': ['Doe', 'Smith', 'Johnson', 'Lee', 'Brown'],
    'age': [28, 34, 23, 45, 31],
    'preTestScore': [70, 82, 68, 77, 69],
    'postTestScore': [80, '25,000', 72, 85, '.']
}
df = pd.DataFrame(data)

# 5.2: Save DataFrame to CSV
df.to_csv('example.csv', index=False)

# 5.3: Read CSV with headers and print
df_read = pd.read_csv('example.csv')
print("5.3 DataFrame read with headers:")
print(df_read)

# 5.4: Read CSV without headers
df_no_header = pd.read_csv('example.csv', header=None)
print("\n5.4 DataFrame read without headers:")
print(df_no_header)

# 5.5: Read CSV with custom index columns
df_index = pd.read_csv('example.csv', index_col=['first_name', 'last_name'])
print("\n5.5 DataFrame with custom index columns:")
print(df_index)

# 5.6: Check for null/missing values
df_isnull = df_read.isnull().any()
print("\n5.6 Columns with missing values:")
print(df_isnull)

# 5.7: Skip first three rows when reading CSV
df_skip = pd.read_csv('example.csv', skiprows=3)
print("\n5.7 DataFrame after skipping first three rows:")
print(df_skip)