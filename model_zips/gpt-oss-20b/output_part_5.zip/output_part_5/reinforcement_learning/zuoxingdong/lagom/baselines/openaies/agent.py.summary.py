import torch
import torch.nn as nn
import torch.nn.functional as F
import gym
import pickle

from lagom.networks import Module
from lagom.networks.functional import make_fc
from lagom.heads import CategoricalHead, DiagGaussianHead
from lagom.agents import BaseAgent


class MLP(Module):
    def __init__(self, config, device='cpu'):
        super().__init__()
        self.device = device
        sizes = config['nn.sizes']
        self.features = make_fc(sizes, activation=None).to(device)
        self.lnorms = nn.ModuleList(
            [nn.LayerNorm(sizes[i]) for i in range(len(sizes) - 1)]
        ).to(device)

    def forward(self, x):
        for i, layer in enumerate(self.features):
            x = layer(x)
            if i < len(self.lnorms):
                x = self.lnorms[i](x)
            x = F.relu(x)
        return x


class Agent(BaseAgent):
    def __init__(self, config, env, device='cpu'):
        super().__init__()
        self.device = device
        self.config = config
        self.env = env

        self.feature_network = MLP(config, device).to(device)
        self.feature_dim = config['nn.sizes'][-1]

        if isinstance(env.action_space, gym.spaces.Discrete):
            self.action_head = CategoricalHead(self.feature_dim).to(device)
        elif isinstance(env.action_space, gym.spaces.Box):
            action_dim = env.action_space.shape[0]
            self.action_head = DiagGaussianHead(
                self.feature_dim, action_dim, std0=config['agent.std0']
            ).to(device)
        else:
            raise ValueError("Unsupported action space type")

        self.total_timestep = 0

        # Optional observation normalizer placeholder
        if config['env.normalize_obs']:
            # Assuming a simple normalizer with mean and var attributes
            self.obs_norm = type('Norm', (), {'mean': torch.zeros(1), 'var': torch.ones(1)})()

    def choose_action(self, obs):
        self.total_timestep += 1
        obs_tensor = torch.tensor(obs, dtype=torch.float32).unsqueeze(0).to(self.device)
        latent = self.feature_network(obs_tensor)
        dist = self.action_head(latent)
        action = dist.sample()
        if isinstance(self.env.action_space, gym.spaces.Discrete):
            return int(action.item())
        else:
            return action.detach().cpu().numpy()

    def learn(self, *args, **kwargs):
        pass

    def checkpoint(self, num_iter):
        torch.save(self.feature_network.state_dict(), f'agent_{num_iter}.pth')
        if self.config['env.normalize_obs'] and hasattr(self, 'obs_norm'):
            moments = {
                'mean': self.obs_norm.mean.cpu().numpy(),
                'var': self.obs_norm.var.cpu().numpy()
            }
            with open(f'obs_moments_{num_iter}.pth', 'wb') as f:
                pickle.dump(moments, f)