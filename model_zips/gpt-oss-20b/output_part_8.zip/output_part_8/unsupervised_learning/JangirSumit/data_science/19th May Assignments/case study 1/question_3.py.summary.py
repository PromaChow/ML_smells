import pandas as pd

df = pd.read_csv('HollywoodMovies.csv')
df_sorted = df.sort_values(by='Budget', ascending=False)
df_valid = df_sorted[df_sorted['Budget'] > 0]
top_five = df_valid.head(5)

if 'Title' in top_five.columns:
    print(top_five['Title'])
elif 'Movie' in top_five.columns:
    print(top_five['Movie'])
else:
    print(top_five)