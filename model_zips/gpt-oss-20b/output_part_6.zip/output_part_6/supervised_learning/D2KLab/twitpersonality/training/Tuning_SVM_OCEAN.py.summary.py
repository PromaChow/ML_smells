import os
import sys
import argparse
import numpy as np
import pandas as pd
from sklearn.svm import SVR
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error, r2_score
from scipy.stats import pearsonr

def pccMean(pccs):
    pccs = [p for p in pccs if not np.isnan(p)]
    return np.mean(pccs) if pccs else np.nan

def parseFastText(filepath):
    embeddings = {}
    with open(filepath, 'r', encoding='utf-8') as f:
        for line in f:
            parts = line.rstrip().split()
            if len(parts) < 2:
                continue
            word = parts[0]
            vec = np.array([float(x) for x in parts[1:]], dtype=np.float32)
            embeddings[word] = vec
    return embeddings

def loadEmbeddingsDataset(filepath):
    # Assume the dataset is a pickled dictionary of word->vector
    return pd.read_pickle(filepath)

def transformTextForTraining(posts, embeddings, method='sum', threshold=3, max_words=50):
    d = next(iter(embeddings.values())).shape[0]
    X = []
    for post in posts:
        words = [w for w in post.split() if len(w) >= threshold]
        vectors = [embeddings[w] for w in words if w in embeddings]
        if not vectors:
            vec = np.zeros(d)
        else:
            vec = np.vstack(vectors)
            if method == 'sum':
                vec = vec.sum(axis=0)
            elif method == 'max':
                vec = vec.max(axis=0)
            elif method == 'min':
                vec = vec.min(axis=0)
            elif method == 'avg':
                vec = vec.mean(axis=0)
            elif method == 'conc':
                # truncate or pad to max_words
                if vec.shape[0] > max_words:
                    vec = vec[:max_words]
                else:
                    pad = np.zeros((max_words - vec.shape[0], d))
                    vec = np.vstack([vec, pad])
                vec = vec.flatten()
            else:
                raise ValueError(f'Unknown method {method}')
        X.append(vec)
    return np.array(X, dtype=np.float32)

def main():
    parser = argparse.ArgumentParser(description='SVR evaluation for Big Five traits.')
    parser.add_argument('embeddings_dataset', choices=['fasttext', 'dataset9'])
    parser.add_argument('dataset_path', help='Path to the dataset file')
    parser.add_argument('shuffle_data', choices=['yes', 'no', 'True', 'False'])
    args = parser.parse_args()

    post_threshold = 3
    shuffle_flag = args.shuffle_data.lower() in ('yes', 'true')
    embeddings_path = args.dataset_path
    dataset_path = args.dataset_path

    # Load embeddings
    if args.embeddings_dataset == 'fasttext':
        embeddings = parseFastText(embeddings_path)
    else:
        embeddings = loadEmbeddingsDataset(embeddings_path)

    # Load personality data
    df = pd.read_csv(dataset_path)
    posts = df['post'].tolist()
    yO = df['O'].values
    yC = df['C'].values
    yE = df['E'].values
    yA = df['A'].values
    yN = df['N'].values

    if shuffle_flag:
        rng = np.random.default_rng()
        idx = rng.permutation(len(posts))
        posts = [posts[i] for i in idx]
        yO = yO[idx]
        yC = yC[idx]
        yE = yE[idx]
        yA = yA[idx]
        yN = yN[idx]

    # Subset to first 100 posts
    posts = posts[:100]
    yO = yO[:100]
    yC = yC[:100]
    yE = yE[:100]
    yA = yA[:100]
    yN = yN[:100]

    old_yO, old_yC, old_yE, old_yA, old_yN = yO.copy(), yC.copy(), yE.copy(), yA.copy(), yN.copy()

    methods = ['sum', 'max', 'min', 'avg', 'conc']
    X_dict = {}
    for method in methods:
        X_dict[method] = transformTextForTraining(posts, embeddings, method, post_threshold)

    # Results setup
    results_dir = 'Results'
    os.makedirs(results_dir, exist_ok=True)
    csv_path = os.path.join(results_dir, f'tuning_SVM_{args.embeddings_dataset}.csv')
    pcc_path = os.path.join(results_dir, f'tuning_SVM_{args.embeddings_dataset}_pcc.txt')
    open(csv_path, 'w').close()
    open(pcc_path, 'w').close()

    traits = [('O', yO), ('C', yC), ('E', yE), ('A', yA), ('N', yN)]
    kernels = {
        'linear': {'kernel': 'linear'},
        'poly2': {'kernel': 'poly', 'degree': 2},
        'poly3': {'kernel': 'poly', 'degree': 3},
        'rbf': {'kernel': 'rbf'}
    }
    linear_params = [{'C': 1}]
    poly_params = [{'C': c, 'degree': d} for c in [1,10,100] for d in [2,3]]
    rbf_params = [{'C': c, 'gamma': g} for c in [1,10,100] for g in [0.01,0.1,1,10]]

    fold_indices = list(KFold(n_splits=10, shuffle=False).split(posts))
    for trait_name, y in traits:
        for method in methods:
            X = X_dict[method]
            for kname, kparams in kernels.items():
                if kname == 'linear':
                    param_list = linear_params
                elif kname.startswith('poly'):
                    param_list = poly_params
                else:
                    param_list = rbf_params
                for params in param_list:
                    mse_list, r2_list, pcc_list = [], [], []
                    per_fold_pcc = []
                    for train_idx, test_idx in fold_indices:
                        X_train, X_test = X[train_idx], X[test_idx]
                        y_train, y_test = y[train_idx], y[test_idx]
                        model = SVR(**kparams, **params)
                        model.fit(X_train, y_train)
                        preds = model.predict(X_test)
                        mse = mean_squared_error(y_test, preds)
                        r2 = r2_score(y_test, preds)
                        if len(y_test) > 1:
                            pcc = pearsonr(y_test, preds)[0]
                        else:
                            pcc = np.nan
                        mse_list.append(mse)
                        r2_list.append(r2)
                        pcc_list.append(pcc)
                        per_fold_pcc.append(pcc)
                    mean_mse = np.mean(mse_list)
                    mean_r2 = np.mean(r2_list)
                    mean_pcc = pccMean(pcc_list)
                    # Write to CSV
                    with open(csv_path, 'a') as f:
                        f.write(f'{trait_name},{method},MSE,{kname},{params},{mean_mse}\n')
                        f.write(f'{trait_name},{method},R2,{kname},{params},{mean_r2}\n')
                        f.write(f'{trait_name},{method},PCC,{kname},{params},{mean_pcc}\n')
                    # Write PCC per fold
                    with open(pcc_path, 'a') as f:
                        f.write(f'Trait:{trait_name}\n')
                        f.write(f'Method:{method}\n')
                        f.write(f'Kernel:{kname}\n')
                        f.write(f'Params:{params}\n')
                        f.write('PCC per fold:\n')
                        for i, p in enumerate(per_fold_pcc, 1):
                            f.write(f'Fold {i}: {p}\n')
                        f.write('\n')

if __name__ == '__main__':
    main()
