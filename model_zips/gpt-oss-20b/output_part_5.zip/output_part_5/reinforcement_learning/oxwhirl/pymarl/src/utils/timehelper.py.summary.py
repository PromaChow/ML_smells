import time
import sys

def time_str(s):
    """Convert seconds to a human‑readable string."""
    if s < 0:
        return "0 seconds"
    days, rem = divmod(int(s), 86400)
    hours, rem = divmod(rem, 3600)
    minutes, seconds = divmod(rem, 60)
    parts = []
    if days:
        parts.append(f"{days} day{'s' if days != 1 else ''}")
    if hours:
        parts.append(f"{hours} hour{'s' if hours != 1 else ''}")
    if minutes:
        parts.append(f"{minutes} minute{'s' if minutes != 1 else ''}")
    if seconds or not parts:
        parts.append(f"{seconds} second{'s' if seconds != 1 else ''}")
    return ", ".join(parts)

def time_left(start_time, t_start, t_current, t_max):
    """
    Estimate the remaining time for the episode.
    
    :param start_time: Timestamp when episode started.
    :param t_start: Step count at start of estimation.
    :param t_current: Current step count.
    :param t_max: Total steps to complete.
    :return: Human‑readable string or '-' if finished.
    """
    if t_current >= t_max:
        return "-"
    elapsed = time.time() - start_time
    t_current = max(t_current, 1)
    remaining_steps = t_max - t_current
    completed_steps = t_current - t_start
    if completed_steps <= 0:
        completed_steps = 1
    estimated = elapsed * remaining_steps / completed_steps
    max_seconds = 60 * 60 * 24 * 100  # 100 days
    if estimated > max_seconds:
        estimated = max_seconds
    return time_str(estimated)

def print_time(start_time, T, t_max, episode, episode_rewards):
    """
    Print a real‑time progress line with elapsed and estimated remaining time.
    
    :param start_time: Timestamp when episode started.
    :param T: Current step count.
    :param t_max: Total steps to complete.
    :param episode: Current episode number.
    :param episode_rewards: List of rewards from previous episodes.
    """
    elapsed = time.time() - start_time
    T = max(T, 1)
    remaining_steps = t_max - T
    if remaining_steps < 0:
        remaining_steps = 0
    estimated = elapsed * remaining_steps / T
    max_seconds = 60 * 60 * 24 * 100  # 100 days
    if estimated > max_seconds:
        estimated = max_seconds

    if len(episode_rewards) > 5:
        recent = episode_rewards[-50:]
        avg_reward = sum(recent) / len(recent)
        avg_str = f"{avg_reward:.2f}"
    else:
        avg_str = "N/A"

    line = (f"\r\x1b[2K"
            f"Episode {episode} [{T}/{t_max}] "
            f"Avg Reward: {avg_str} | "
            f"Elapsed: {time_str(elapsed)} | "
            f"Left: {time_str(estimated)}")
    sys.stdout.write(line)
    sys.stdout.flush()
    if T >= t_max:
        sys.stdout.write("\n")
        sys.stdout.flush()
