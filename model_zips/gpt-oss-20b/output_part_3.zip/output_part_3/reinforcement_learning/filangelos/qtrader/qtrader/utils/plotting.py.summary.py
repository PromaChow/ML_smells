import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.ticker import AutoMinorLocator


def _pnl(returns: pd.Series | pd.DataFrame | np.ndarray) -> pd.Series:
    """
    Compute profit and loss (wealth) from returns assuming a starting wealth of 1.
    """
    if isinstance(returns, np.ndarray):
        returns = pd.Series(returns)
    if isinstance(returns, pd.DataFrame):
        returns = returns.copy()
    returns = returns.fillna(0)
    if isinstance(returns, pd.Series):
        wealth = (1 + returns).cumprod()
    else:
        wealth = (1 + returns).cumprod()
    return wealth


def time_series(
    data: np.ndarray | pd.Series | pd.DataFrame,
    title: str = "Time Series",
    xlabel: str = "Time",
    ylabel: str = "Value",
    save_path: str | None = None,
) -> None:
    """
    Plot a univariate or multivariate time series.
    """
    fig, ax = plt.subplots(figsize=(10, 6))

    if isinstance(data, pd.DataFrame):
        data.plot(ax=ax)
    elif isinstance(data, pd.Series):
        data.plot(ax=ax)
    elif isinstance(data, np.ndarray):
        if data.ndim == 1:
            ax.plot(data, label="Series")
            ax.legend()
        elif data.ndim == 2:
            for i in range(data.shape[1]):
                ax.plot(data[:, i], label=f"Column {i}")
            ax.legend()
        else:
            raise ValueError("Unsupported array dimension for time_series.")
    else:
        raise TypeError("Unsupported data type for time_series.")

    ax.set_title(title)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.xaxis.set_major_locator(AutoMinorLocator())
    plt.xticks(rotation=45)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path)
    plt.show()


def pnl(
    returns: pd.Series | pd.DataFrame | np.ndarray,
    name: str | None = None,
    save_path: str | None = None,
) -> None:
    """
    Compute PnL from returns and plot it.
    """
    wealth = _pnl(returns)
    title = f"{name} PnL" if name else "Strategy PnL"
    time_series(
        wealth,
        title=title,
        xlabel="Time",
        ylabel="Wealth Level",
        save_path=save_path,
    )


def trades(
    prices: pd.Series | pd.DataFrame | np.ndarray,
    weights: pd.Series | pd.DataFrame | np.ndarray,
    title: str = "Trades",
    save_path: str | None = None,
) -> None:
    """
    Plot asset prices and portfolio weights.
    """
    if isinstance(prices, np.ndarray):
        prices = pd.DataFrame(prices)
    if isinstance(weights, np.ndarray):
        weights = pd.DataFrame(weights)

    fig, (ax_price, ax_weight) = plt.subplots(
        nrows=2, sharex=True, figsize=(10, 8), gridspec_kw={"height_ratios": [3, 1]}
    )

    if isinstance(prices, pd.DataFrame):
        prices.plot(ax=ax_price)
    else:
        ax_price.plot(prices, label="Price")
        ax_price.legend()

    if isinstance(weights, pd.DataFrame):
        weights.plot(kind="bar", ax=ax_weight, width=0.8)
    else:
        ax_weight.bar(range(len(weights)), weights, width=0.8)

    ax_price.set_title(title)
    ax_price.set_ylabel("Price")
    ax_weight.set_ylabel("Weight")
    ax_weight.set_xlabel("Time")
    plt.xticks(rotation=45)
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path)
    plt.show()


def table_image(
    table: np.ndarray,
    title: str = "Table Image",
    save_path: str | None = None,
) -> None:
    """
    Visualize a 2D array as a grayscale image.
    """
    if table.ndim != 2:
        raise ValueError("Input must be a 2D array.")
    fig, ax = plt.subplots(figsize=(6, 6))
    im = ax.imshow(table, cmap="gray", aspect="auto")
    ax.set_title(title)
    ax.axis("off")
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path)
    plt.show()


def drawdown(
    returns: pd.Series | pd.DataFrame | np.ndarray,
    name: str | None = None,
    save_path: str | None = None,
) -> None:
    """
    Plot PnL, drawdown, and max drawdown.
    """
    wealth = _pnl(returns)
    cummax = wealth.cummax()
    draw = (wealth / cummax) - 1
    max_draw = draw.min()

    fig, ax = plt.subplots(figsize=(10, 6))
    ax.plot(wealth, label="Wealth")
    ax.plot(draw, label="Drawdown")
    ax.hlines(max_draw, draw.index[0], draw.index[-1], colors="red", linestyles="dashed", label="Max Drawdown")

    title = f"{name} Drawdown" if name else "Strategy Drawdown"
    ax.set_title(title)
    ax.set_xlabel("Time")
    ax.set_ylabel("Value")
    ax.legend()
    plt.xticks(rotation=45)
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path)
    plt.show()
