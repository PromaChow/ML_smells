import unittest
import numpy as np
import gym
from gym.spaces import Box, Discrete

from chainerrl.wrappers.atari_wrappers import FrameStack, ScaledFloatFrame, LazyFrames


class MockEnv(gym.Env):
    """A simple deterministic mock environment with configurable dtype."""

    metadata = {"render.modes": ["human"]}

    def __init__(self, dtype: np.dtype, seed: int = 42):
        super().__init__()
        self.dtype = dtype
        self.shape = (1, 84, 84)
        if dtype == np.uint8:
            low, high = 0, 255
        else:
            low, high = -1.0, 3.14
        self.observation_space = Box(
            low=low, high=high, shape=self.shape, dtype=dtype
        )
        self.action_space = Discrete(2)
        self.rng = np.random.RandomState(seed)

    def reset(self):
        obs = self._sample_obs()
        return obs

    def step(self, action):
        obs = self._sample_obs()
        reward = self.rng.rand()
        done = self.rng.rand() > 0.9
        info = {}
        return obs, reward, done, info

    def _sample_obs(self):
        if self.dtype == np.uint8:
            return self.rng.randint(0, 256, self.shape, dtype=np.uint8)
        else:
            return self.rng.uniform(-1.0, 3.14, self.shape).astype(np.float32)


class TestFrameStack(unittest.TestCase):
    def test_frame_stack(self):
        dtypes = [np.uint8, np.float32]
        ks = [2, 3]
        for dtype in dtypes:
            for k in ks:
                with self.subTest(dtype=dtype, k=k):
                    env = MockEnv(dtype=dtype, seed=42)
                    wrapped = FrameStack(env, k=k, channel_order="chw")

                    # Action space consistency
                    self.assertEqual(wrapped.action_space, env.action_space)

                    # Observation space consistency
                    self.assertEqual(wrapped.observation_space.dtype, env.observation_space.dtype)
                    np.testing.assert_allclose(
                        wrapped.observation_space.low,
                        env.observation_space.low,
                        atol=1e-5,
                    )
                    np.testing.assert_allclose(
                        wrapped.observation_space.high,
                        env.observation_space.high,
                        atol=1e-5,
                    )

                    # Reset check
                    obs_orig = env.reset()
                    obs_wrapped = wrapped.reset()
                    self.assertIsInstance(obs_wrapped, LazyFrames)
                    obs_wrapped_arr = np.array(obs_wrapped)
                    # First channel of wrapped observation should equal original observation
                    first_channel = obs_wrapped_arr[:, 0, :, :]
                    np.testing.assert_allclose(first_channel, obs_orig)

                    # Step simulation
                    for _ in range(10):
                        action_orig = env.action_space.sample()
                        action_wrapped = wrapped.action_space.sample()
                        self.assertEqual(action_orig, action_wrapped)

                        o_orig, r_orig, d_orig, info_orig = env.step(action_orig)
                        o_wrapped, r_wrapped, d_wrapped, info_wrapped = wrapped.step(action_wrapped)

                        self.assertIsInstance(o_wrapped, LazyFrames)
                        o_wrapped_arr = np.array(o_wrapped)

                        # Last channel should equal latest original observation
                        last_channel = o_wrapped_arr[:, -1, :, :]
                        np.testing.assert_allclose(last_channel, o_orig)

                        np.testing.assert_allclose(r_wrapped, r_orig, atol=1e-5)
                        self.assertEqual(d_wrapped, d_orig)
                        self.assertEqual(info_wrapped, info_orig)


class TestScaledFloatFrame(unittest.TestCase):
    def test_scaled_float_frame(self):
        dtypes = [np.uint8, np.float32]
        for dtype in dtypes:
            with self.subTest(dtype=dtype):
                env = MockEnv(dtype=dtype, seed=42)
                wrapped = ScaledFloatFrame(env)

                # Observation space checks
                self.assertEqual(wrapped.observation_space.dtype, np.float32)
                np.testing.assert_allclose(
                    wrapped.observation_space.low,
                    env.observation_space.low / wrapped.scale,
                    atol=1e-5,
                )
                np.testing.assert_allclose(
                    wrapped.observation_space.high,
                    env.observation_space.high / wrapped.scale,
                    atol=1e-5,
                )

                # Reset check
                obs_orig = env.reset()
                obs_wrapped = wrapped.reset()
                np.testing.assert_allclose(
                    obs_wrapped, obs_orig / wrapped.scale, atol=1e-5
                )

                # Step simulation
                for _ in range(10):
                    action_orig = env.action_space.sample()
                    action_wrapped = wrapped.action_space.sample()
                    self.assertEqual(action_orig, action_wrapped)

                    o_orig, r_orig, d_orig, info_orig = env.step(action_orig)
                    o_wrapped, r_wrapped, d_wrapped, info_wrapped = wrapped.step(action_wrapped)

                    np.testing.assert_allclose(
                        o_wrapped, o_orig / wrapped.scale, atol=1e-5
                    )
                    np.testing.assert_allclose(r_wrapped, r_orig, atol=1e-5)
                    self.assertEqual(d_wrapped, d_orig)
                    self.assertEqual(info_wrapped, info_orig)


if __name__ == "__main__":
    unittest.main()
